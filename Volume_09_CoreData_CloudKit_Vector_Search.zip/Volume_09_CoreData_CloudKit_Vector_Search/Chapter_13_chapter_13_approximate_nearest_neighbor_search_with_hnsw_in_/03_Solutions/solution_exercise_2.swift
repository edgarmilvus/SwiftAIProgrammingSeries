
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// A thread-safe registry that maps HNSW integer indices to application-level IDs.
actor VectorRegistry<ID: Hashable & Sendable> {
    // Maps HNSW index -> Application ID
    private var indexToID: [Int: ID] = [:]
    // Maps Application ID -> HNSW index
    private var idToIndex: [ID: Int] = [:]
    // Tracks indices that were deleted and can be reused
    private var freeIndices: [Int] = []
    // The next index to use if no free indices are available
    private var nextAvailableIndex: Int = 0

    /// Adds a new ID to the registry and returns its assigned HNSW index.
    func register(_ id: ID) -> Int {
        if let existingIndex = idToIndex[id] {
            return existingIndex
        }
        
        let index: Int
        if !freeIndices.isEmpty {
            index = freeIndices.removeFirst()
        } else {
            index = nextAvailableIndex
            nextAvailableIndex += 1
        }
        
        indexToID[index] = id
        idToIndex[id] = index
        return index
    }

    /// Removes an ID from the registry, making its index available for reuse.
    func unregister(_ id: ID) {
        guard let index = idToIndex.removeValue(forKey: id) else { return }
        indexToID.removeValue(forKey: index)
        freeIndices.append(index)
        // Sort free indices to keep the graph as contiguous as possible
        freeIndices.sort()
    }

    /// Resolves a list of HNSW search indices into their corresponding application IDs.
    func resolve(indices: [Int]) -> [ID] {
        return indices.compactMap { indexToID[$0] }
    }
    
    /// Returns the number of currently registered vectors.
    var count: Int {
        indexToID.count
    }
}

// MARK: - Usage Example
@available(iOS 18.0, *)
func demonstrateRegistry() async {
    let registry = VectorRegistry<UUID>()
    let photoID = UUID()
    
    let index = await registry.register(photoID)
    print("Registered \(photoID) at index \(index)")
    
    let resolved = await registry.resolve(indices: [index])
    print("Resolved indices \(index) to: \(resolved)")
    
    await registry.unregister(photoID)
    let newIndex = await registry.register(UUID())
    print("New index after unregistering (should reuse): \(newIndex)")
}
