
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import MLX // Assuming MLX is imported

    @available(iOS 18.0, *)
    @Observable
    class TrainingMonitor {
        var currentLoss: Float = 0.0
        var currentEpoch: Int = 0
        var isTraining: Bool = false
        var lastPrediction: String = "N/A"

        // This could be called from an actor or async task
        func updateLoss(_ loss: Float) {
            self.currentLoss = loss
        }
        
        func updateEpoch(_ epoch: Int) {
            self.currentEpoch = epoch
        }

        func setTrainingStatus(_ status: Bool) {
            self.isTraining = status
        }
        
        func updatePrediction(_ prediction: String) {
            self.lastPrediction = prediction
        }
    }

    @available(iOS 18.0, *)
    struct TrainingView: View {
        @State private var monitor = TrainingMonitor()

        var body: some View {
            VStack {
                Text("Epoch: \(monitor.currentEpoch)")
                Text("Loss: \(monitor.currentLoss, format: .number.precision(.fractionLength(4)))")
                Text("Training: \(monitor.isTraining ? "Yes" : "No")")
                Text("Last Prediction: \(monitor.lastPrediction)")
                Button("Start Training (Simulated)") {
                    Task {
                        monitor.setTrainingStatus(true)
                        for i in 0..<5 {
                            // Simulate MLX training
                            await Task.sleep(for: .seconds(0.5))
                            monitor.updateEpoch(i + 1)
                            monitor.updateLoss(Float.random(in: 0.1...0.5))
                        }
                        monitor.setTrainingStatus(false)
                        monitor.updatePrediction("Simulated Cat")
                    }
                }
            }
        }
    }
    