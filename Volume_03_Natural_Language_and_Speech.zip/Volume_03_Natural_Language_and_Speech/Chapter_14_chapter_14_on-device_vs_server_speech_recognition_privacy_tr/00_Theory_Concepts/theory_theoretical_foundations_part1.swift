
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    func startSpeechRecognitionSession() async throws -> AsyncStream<String> {
        let audioStream = AudioInputManager.shared.microphoneAudioStream() // An async stream of audio buffers
        let speechRecognizer = MySpeechRecognizer() // Manages SFSpeechRecognizer internally

        return AsyncStream { continuation in
            Task {
                do {
                    for await audioBuffer in audioStream {
                        let partialTranscription = try await speechRecognizer.process(audioBuffer)
                        continuation.yield(partialTranscription)
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }

    // Usage in a SwiftUI view or view model:
    @available(iOS 18.0, *)
    func listenAndDisplay() {
        Task {
            do {
                for await transcriptionPart in try await startSpeechRecognitionSession() {
                    // Update UI with transcriptionPart on the MainActor
                    await MainActor.run {
                        self.currentTranscription = transcriptionPart
                    }
                }
            } catch {
                await MainActor.run {
                    self.recognitionError = error
                }
            }
        }
    }
    