
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, *)
actor ResilientSSEParser {
    private var partialBuffer: String = ""
    private let decoder = JSONDecoder()
    private let prefix = "data: "
    private let sentinel = "[DONE]"

    /// Processes a single line from the SSE stream.
    /// Returns a chunk if a full object is formed, otherwise nil.
    func process(line: String) throws -> ChatCompletionChunk? {
        // 1. Clean the line
        let cleanedLine = line.hasPrefix(prefix) 
            ? String(line.dropFirst(prefix.count)).trimmingCharacters(in: .whitespacesAndNewlines)
            : line.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // 2. Handle [DONE] sentinel (even if partially buffered)
        if cleanedLine.contains(sentinel) {
            // In a production scenario, you might want to handle 
            // fragmented sentinels like "[DO" + "NE]"
            return nil 
        }
        
        // 3. Combine with existing buffer
        let currentAttempt = partialBuffer + cleanedLine
        
        do {
            // 4. Attempt decoding
            let data = Data(currentAttempt.utf8)
            let chunk = try decoder.decode(ChatCompletionChunk.self, from: data)
            
            // Success! Clear the buffer and return the chunk
            partialBuffer = ""
            return chunk
        } catch {
            // 5. If decoding fails, check if it's a fragment
            // A simple heuristic: if it doesn't end with '}' or '"', it's likely incomplete
            if isLikelyFragment(currentAttempt) {
                partialBuffer = currentAttempt
                return nil
            } else {
                // It's a malformed line, not a fragment. Clear buffer to prevent corruption.
                partialBuffer = ""
                throw error
            }
        }
    }
    
    private func isLikelyFragment(_ text: String) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let last = trimmed.last else { return true }
        // JSON objects/strings usually end with these characters
        return !([",", "{", "[", "\"", ":"].contains(last) && !trimmed.hasSuffix("]")) 
            && !trimmed.hasSuffix("}") 
            && !trimmed.hasSuffix("\"")
    }
}
