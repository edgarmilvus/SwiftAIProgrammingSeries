
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Combine

// MARK: - Models

/// Represents the result of an AI analysis on a spatial object.
/// Conforms to `Sendable` to safely pass between actors in Swift 6.
struct SpatialInsight: Sendable, Identifiable {
    let id = UUID()
    let label: String
    let description: String
    let confidence: Float
}

/// A protocol that defines an entity capable of being analyzed by the AI.
/// This allows us to filter hit-test results to only interact with specific objects.
protocol AnalyzableEntity: Entity {
    var analysisID: String { get }
}

// MARK: - Custom Entity

/// A concrete implementation of an analyzable object in the 3D scene.
/// In a real app, this might be a scanned piece of furniture or a digital twin.
final class SmartObject: Entity, AnalyzableEntity, HasModel, HasCollision {
    let analysisID: String
    
    required init(model: ModelComponent, analysisID: String) {
        self.analysisID = analysisID
        super.init()
        self.components.set(model)
        // Collision is mandatory for hit-testing/gaze detection
        self.generateCollisionShapes(recursive: true)
    }
    
    required init() {
        fatalError("init() has not been implemented")
    }
}

// MARK: - Interaction Manager

/// The `GazeInteractionManager` acts as the brain of the interaction loop.
/// It is marked with `@MainActor` because it manages state that drives the SwiftUI UI.
@MainActor
class GazeInteractionManager: ObservableObject {
    /// The currently identified object being looked at.
    @Published var focusedEntity: AnalyzableEntity?
    
    /// The insight provided by the AI.
    @Published var currentInsight: SpatialInsight?
    
    /// Progress of the "dwell" timer (0.0 to 1.0).
    @Published var dwellProgress: Float = 0.0
    
    private var dwellTimer: Timer?
    private let dwellThreshold: TimeInterval = 1.5 // Seconds required to trigger AI
    private var startTime: Date?

    /// Responds to a new gaze hit.
    /// - Parameter entity: The entity the user is looking at.
    func updateGaze(hit: AnalyzableEntity?) {
        // Case 1: User is looking at a new valid entity
        if hit != nil && hit?.id != focusedEntity?.id {
            startDwell(for: hit)
        } 
        // Case 2: User stopped looking at the entity or looked at nothing
        else if hit == nil || hit?.id != focusedEntity?.id {
            resetDwell()
        }
        // Case 3: User is still looking at the same entity (continue timer)
        // Handled implicitly by the timer running in the background
    }

    private func startDwell(for entity: AnalyzableEntity?) {
        focusedEntity = entity
        startTime = Date()
        
        // Reset timer logic
        dwellTimer?.invalidate()
        
        // Start a timer to update the dwell progress UI
        dwellTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self = self, let start = self.startTime else { return }
            let elapsed = Date().timeIntervalSince(start)
            let progress = Float(min(elapsed / self.dwellThreshold, 1.0))
            
            // Update UI on the MainActor
            Task { @MainActor in
                self.dwellProgress = progress
                if progress >= 1.0 {
                    await self.triggerAIInference(for: entity)
                }
            }
        }
    }

    private func resetDwell() {
        focusedEntity = nil
        dwellProgress = 0
        startTime = nil
        dwellTimer?.invalidate()
        dwellTimer = nil
    }

    /// Simulates an asynchronous AI inference call.
    /// In a production app, this would call a CoreML model via Vision.
    private func triggerAIInference(for entity: AnalyzableEntity?) async {
        guard let entity = entity else { return }
        
        // Prevent multiple triggers for the same dwell event
        resetDwell() 
        
        print("AI: Analyzing entity \(entity.analysisID)...")
        
        // Simulate network or heavy on-device compute latency
        try? await Task.sleep(for: .seconds(0.5))
        
        // Mocking the AI response
        let mockInsight = SpatialInsight(
            label: "Detected Object",
            description: "This is a \(entity.analysisID) located in your living room.",
            confidence: 0.98
        )
        
        self.currentInsight = mockInsight
    }
}

// MARK: - View Layer

struct SpatialAssistantView: View {
    @StateObject private var interactionManager = GazeInteractionManager()
    
    var body: some View {
        ZStack {
            // The 3D Scene
            RealityView { content in
                // Setup a simple scene
                let box = SmartObject(
                    model: ModelComponent(
                        mesh: .generateBox(size: 0.2),
                        materials: [SimpleMaterial(color: .systemBlue, isMetallic: true)]
                    ),
                    analysisID: "Vintage Camera"
                )
                box.position = [0, 1.5, -1.0] // 1 meter in front, 1.5m up
                content.add(box)
                
                let sphere = SmartObject(
                    model: ModelComponent(
                        mesh: .generateSphere(radius: 0.1),
                        materials: [SimpleMaterial(color: .systemRed, isMetallic: false)]
                    ),
                    analysisID: "Ceramic Vase"
                )
                sphere.position = [0.5, 1.2, -1.2]
                content.add(sphere)
            }
            .gesture(
                // In visionOS, we use a SpatialTapGesture or HoverGesture.
                // For true gaze-driven interaction, we monitor the gaze ray 
                // via the HoverGesture which tracks what the eye is focused on.
                HoverGesture()
                    .targetedToAnyEntity()
                    .onChanged { value in
                        // Attempt to cast the hit entity to our protocol
                        if let analyzable = value.entity as? AnalyzableEntity {
                            interactionManager.updateGaze(hit: analyzable)
                        } else {
                            interactionManager.updateGaze(hit: nil)
                        }
                    }
                    .onEnded { _ in
                        interactionManager.updateGaze(hit: nil)
                    }
            )
            
            // UI Overlay: Progress Ring (Visual feedback for dwell)
            if interactionManager.dwellProgress > 0 && interactionManager.dwellProgress < 1.0 {
                Circle()
                    .trim(from: 0, to: CGFloat(interactionManager.dwellProgress))
                    .stroke(Color.white, lineWidth: 5)
                    .frame(width: 50, height: 50)
                    .position(x: 500, y: 100) // Positioned in a corner
                    .animation(.linear, value: interactionManager.dwellProgress)
            }
            
            // UI Overlay: AI Insight Card
            if let insight = interactionManager.currentInsight {
                VStack(alignment: .leading, spacing: 10) {
                    Text(insight.label)
                        .font(.headline)
                    Text(insight.description)
                        .font(.subheadline)
                    Text("Confidence: \(Int(insight.confidence * 100))%")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(15)
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .onAppear {
                    // Auto-dismiss after 5 seconds
                    Task {
                        try? await Task.sleep(for: .seconds(5))
                        await MainActor.run {
                            interactionManager.currentInsight = nil
                        }
                    }
                }
                .position(x: 500, y: 500)
            }
        }
    }
}
