
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Vision
import UIKit

/// A utility class to process images using Vision's VNDetectRectanglesRequest.
/// This class encapsulates the logic for finding rectangular regions within an image,
/// typically used for document scanning, card detection, or other applications
/// requiring precise bounding box detection of quadrilateral shapes.
@available(iOS 13.0, macOS 10.15, *) // VNDetectRectanglesRequest is available from these versions
class DocumentScannerProcessor {

    /// Processes a given image to detect rectangular regions.
    ///
    /// This method leverages the Vision framework's `VNDetectRectanglesRequest`
    /// to identify potential document or object boundaries within an image.
    ///
    /// - Parameters:
    ///   - image: The `UIImage` (or `NSImage` on macOS) to be processed.
    ///   - completion: A closure that will be called upon completion with a `Result`
    ///                 containing an array of `VNRectangleObservation` on success,
    ///                 or an `Error` on failure.
    func processImageForRectangles(image: UIImage, completion: @escaping (Result<[VNRectangleObservation], Error>) -> Void) {
        // 1. Convert UIImage to CGImage
        // Vision framework primarily operates on CGImage.
        guard let cgImage = image.cgImage else {
            completion(.failure(VisionProcessingError.invalidImage))
            return
        }

        // 2. Create a VNDetectRectanglesRequest
        // This request is designed to find rectangular regions in an image.
        // We configure it with various properties to fine-tune the detection.
        let detectRectanglesRequest = VNDetectRectanglesRequest { request, error in
            // This is the completion handler for the Vision request itself.
            // It runs on a background queue managed by Vision.

            if let error = error {
                // If an error occurred during the Vision request, propagate it.
                print("Error detecting rectangles: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            // Ensure the results are of the expected type.
            guard let observations = request.results as? [VNRectangleObservation] else {
                // No observations or unexpected type, consider it a failure or empty result.
                completion(.success([])) // Or .failure(VisionProcessingError.noObservationsFound)
                return
            }

            // Successfully detected rectangles.
            // Sort observations by confidence in descending order, so the most confident
            // detection is first.
            let sortedObservations = observations.sorted { $0.confidence > $1.confidence }
            completion(.success(sortedObservations))
        }

        // Configure the request properties for better detection in a document scanning context.
        // These values are examples and might need tuning for specific use cases.
        detectRectanglesRequest.maximumObservations = 1      // We are typically looking for one main document.
        detectRectanglesRequest.minimumAspectRatio = 0.5     // Minimum width/height ratio (e.g., 1:2 portrait).
        detectRectanglesRequest.maximumAspectRatio = 2.0     // Maximum width/height ratio (e.g., 2:1 landscape).
        detectRectanglesRequest.quadratureTolerance = 10.0   // Tolerance for how "square" the corners need to be (degrees).
                                                             // A value of 10.0 means corners can deviate up to 10 degrees from 90.
        detectRectanglesRequest.minimumSize = 0.2            // Minimum size of the detected rectangle as a fraction of the image's smaller dimension.
                                                             // E.g., 0.2 means the rectangle must be at least 20% of the image's width or height.
        detectRectanglesRequest.minimumConfidence = 0.7      // Only return observations with confidence above 70%.

        // 3. Create a VNImageRequestHandler
        // This handler takes the CGImage and performs one or more Vision requests on it.
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        // 4. Perform the request
        // This is a synchronous call that dispatches the request to Vision's processing pipeline.
        // The actual processing might happen on a background thread, and the request's completion
        // handler will be called when results are ready.
        do {
            try handler.perform([detectRectanglesRequest])
        } catch {
            // Catch errors that might occur during the `perform` call itself
            // (e.g., invalid image format, Vision service unavailable).
            print("Failed to perform Vision request: \(error.localizedDescription)")
            completion(.failure(error))
        }
    }

    /// Custom error types for Vision processing.
    enum VisionProcessingError: Error, LocalizedError {
        case invalidImage
        case noObservationsFound
        case customError(String)

        var errorDescription: String? {
            switch self {
            case .invalidImage:
                return "The provided image could not be converted to a CGImage."
            case .noObservationsFound:
                return "No rectangular observations were found in the image."
            case .customError(let message):
                return message
            }
        }
    }
}

// MARK: - Example Usage in a UIViewController

/// A basic UIViewController demonstrating how to use `DocumentScannerProcessor`.
/// This example simulates loading an image and displaying the detected rectangle
/// by drawing a bounding box on top of the image.
@available(iOS 13.0, macOS 10.15, *)
class RectangleDetectionViewController: UIViewController {

    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.backgroundColor = .systemGray6
        return iv
    }()

    private let processButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Process Image", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        return button
    }()

    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.hidesWhenStopped = true
        return indicator
    }()

    private let processor = DocumentScannerProcessor()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Load a sample image. In a real app, this would come from the camera or photo library.
        // Make sure "sample_document" is added to your Assets.xcassets.
        // For demonstration, we'll create a simple image if not found.
        if let sampleImage = UIImage(named: "sample_document") {
            imageView.image = sampleImage
        } else {
            print("Warning: 'sample_document.png' not found in assets. Creating a dummy image.")
            imageView.image = createDummyImage(size: CGSize(width: 800, height: 1200))
        }
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(imageView)
        view.addSubview(processButton)
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.7), // Take 70% of height

            processButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            processButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            processButton.widthAnchor.constraint(equalToConstant: 200),
            processButton.heightAnchor.constraint(equalToConstant: 50),

            activityIndicator.centerXAnchor.constraint(equalTo: processButton.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: processButton.centerYAnchor)
        ])

        processButton.addTarget(self, action: #selector(processImage), for: .touchUpInside)
    }

    /// Creates a dummy image with a white rectangle on a gray background.
    /// This is useful for testing if a sample_document asset is not available.
    private func createDummyImage(size: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }

        // Draw gray background
        UIColor.systemGray4.setFill()
        context.fill(CGRect(origin: .zero, size: size))

        // Draw a white rectangle in the center, slightly rotated
        let rectWidth = size.width * 0.7
        let rectHeight = size.height * 0.8
        let rectX = (size.width - rectWidth) / 2
        let rectY = (size.height - rectHeight) / 2
        let documentRect = CGRect(x: rectX, y: rectY, width: rectWidth, height: rectHeight)

        context.saveGState()
        context.translateBy(x: size.width / 2, y: size.height / 2)
        context.rotate(by: CGFloat.pi / 30) // Rotate by 6 degrees
        context.translateBy(x: -size.width / 2, y: -size.height / 2)

        UIColor.white.setFill()
        context.fill(documentRect)

        context.restoreGState()

        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }


    @objc private func processImage() {
        guard let image = imageView.image else {
            presentAlert(title: "Error", message: "No image to process.")
            return
        }

        activityIndicator.startAnimating()
        processButton.isEnabled = false

        processor.processImageForRectangles(image: image) { [weak self] result in
            // Ensure UI updates happen on the main thread.
            // Vision's completion handler runs on a background thread.
            DispatchQueue.main.async {
                self?.activityIndicator.stopAnimating()
                self?.processButton.isEnabled = true

                switch result {
                case .success(let observations):
                    if let firstObservation = observations.first {
                        self?.drawBoundingBox(on: image, observation: firstObservation)
                        self?.presentAlert(title: "Success", message: "Found a rectangle with confidence: \(String(format: "%.2f", firstObservation.confidence))")
                    } else {
                        self?.presentAlert(title: "No Rectangles", message: "No significant rectangles were detected.")
                    }
                case .failure(let error):
                    self?.presentAlert(title: "Error", message: "Failed to detect rectangles: \(error.localizedDescription)")
                }
            }
        }
    }

    /// Draws a bounding box on the original image based on the `VNRectangleObservation`.
    ///
    /// - Parameters:
    ///   - originalImage: The image on which to draw.
    ///   - observation: The `VNRectangleObservation` containing the rectangle's coordinates.
    private func drawBoundingBox(on originalImage: UIImage, observation: VNRectangleObservation) {
        guard let cgImage = originalImage.cgImage else { return }

        let imageSize = originalImage.size
        let scale = originalImage.scale

        UIGraphicsBeginImageContextWithOptions(imageSize, false, scale)
        originalImage.draw(at: .zero)

        guard let context = UIGraphicsGetCurrentContext() else {
            UIGraphicsEndImageContext()
            return
        }

        context.saveGState()

        // Vision coordinates are normalized (0-1, origin bottom-left).
        // UIKit coordinates are top-left. We need to flip the Y-axis.
        context.translateBy(x: 0, y: imageSize.height)
        context.scaleBy(x: 1, y: -1)

        // Convert normalized Vision coordinates to UIKit image coordinates.
        // The points are in counter-clockwise order: topLeft, topRight, bottomRight, bottomLeft.
        let topLeft = VNImagePointForNormalizedPoint(observation.topLeft, Int(imageSize.width), Int(imageSize.height))
        let topRight = VNImagePointForNormalizedPoint(observation.topRight, Int(imageSize.width), Int(imageSize.height))
        let bottomRight = VNImagePointForNormalizedPoint(observation.bottomRight, Int(imageSize.width), Int(imageSize.height))
        let bottomLeft = VNImagePointForNormalizedPoint(observation.bottomLeft, Int(imageSize.width), Int(imageSize.height))

        // Draw the polygon
        context.setStrokeColor(UIColor.red.cgColor)
        context.setLineWidth(4.0 / scale) // Adjust line width for image scale

        context.beginPath()
        context.move(to: topLeft)
        context.addLine(to: topRight)
        context.addLine(to: bottomRight)
        context.addLine(to: bottomLeft)
        context.closePath()
        context.strokePath()

        context.restoreGState()

        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        imageView.image = newImage
    }

    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
