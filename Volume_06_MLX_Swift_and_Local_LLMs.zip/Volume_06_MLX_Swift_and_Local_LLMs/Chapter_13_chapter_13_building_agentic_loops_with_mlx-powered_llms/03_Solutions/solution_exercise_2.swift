
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX
import Foundation

// MARK: - Tool Definitions

/// Represents a structured call to a tool.
struct ToolCall: Decodable {
    let tool: String
    let arguments: [String: String]
}

/// A mock service to simulate calendar operations.
@available(iOS 18.0, macOS 15.0, *)
class CalendarService {
    func addEvent(title: String, date: String) -> String {
        // In a real app, this would integrate with EventKit or a backend.
        print("CalendarService: Adding event '\(title)' for date '\(date)'...")
        // Simulate success or failure
        if date.isEmpty || title.isEmpty {
            return "Error: Event title or date cannot be empty."
        }
        return "SUCCESS: Event '\(title)' added to calendar for \(date)."
    }
}

// MARK: - MLX Agent with Tooling

@available(iOS 18.0, macOS 15.0, *)
class MLXToolAgent {
    let chatModel: MLXChatModel // Reusing the model from Exercise 1
    let calendarService = CalendarService()
    
    init(chatModel: MLXChatModel) {
        self.chatModel = chatModel
    }
    
    /// Handles a user request, potentially invoking tools.
    /// - Parameter userQuery: The user's input.
    /// - Returns: The agent's final response.
    func handleUserRequest(userQuery: String) async throws -> String {
        // 1. Craft a prompt that instructs the LLM on tool use and expected JSON format.
        let toolInstructions = """
        You are a helpful assistant. You have access to the following tool:
        - add_to_calendar: Adds an event to the user's calendar.
          Parameters:
            - title (String): The title of the event.
            - date (String, format YYYY-MM-DD): The date for the event.
        
        If the user's request requires adding an event to the calendar, respond with a JSON object in this format:
        {"tool": "add_to_calendar", "arguments": {"title": "event title", "date": "YYYY-MM-DD"}}
        
        Otherwise, respond naturally to the user's query.
        
        User: \(userQuery)
        Assistant:
        """
        
        print("\nAgent: Sending initial prompt to LLM...")
        let llmResponse = try await chatModel.performInference(prompt: toolInstructions)
        print("Agent: LLM responded with: '\(llmResponse)'")
        
        // 2. Attempt to parse the LLM's response as a ToolCall.
        if let data = llmResponse.data(using: .utf8),
           let toolCall = try? JSONDecoder().decode(ToolCall.self, from: data) {
            
            print("Agent: Detected tool call: \(toolCall.tool)")
            
            // 3. Execute the detected tool.
            if toolCall.tool == "add_to_calendar" {
                guard let title = toolCall.arguments["title"],
                      let date = toolCall.arguments["date"] else {
                    return "Error: Missing arguments for calendar tool."
                }
                
                print("Agent: Executing 'add_to_calendar' with title '\(title)' and date '\(date)'...")
                let toolResult = calendarService.addEvent(title: title, date: date)
                print("Agent: Tool execution result: \(toolResult)")
                
                // 4. (Optional but recommended for agentic loops) Feed tool result back to LLM.
                // This allows the LLM to generate a more natural, user-friendly confirmation.
                let followUpPrompt = """
                User: \(userQuery)
                Tool executed: \(toolCall.tool) with arguments \(toolCall.arguments).
                Tool output: \(toolResult)
                
                Based on this, generate a concise, user-friendly response confirming the action.
                Assistant:
                """
                print("Agent: Sending follow-up prompt to LLM with tool result...")
                let finalResponse = try await chatModel.performInference(prompt: followUpPrompt)
                return finalResponse
            } else {
                return "Agent: LLM suggested an unknown tool: \(toolCall.tool). Original LLM response: \(llmResponse)"
            }
        } else {
            // No tool call detected, return the LLM's direct response.
            print("Agent: No tool call detected. Returning direct LLM response.")
            return llmResponse
        }
    }
}

// MARK: - Main Agent Loop

@available(iOS 18.0, macOS 15.0, *)
func runToolAgent() async {
    print("Welcome to the MLX Tool Agent! Type 'exit' to quit.")
    print("Try: 'Add 'Buy groceries' to my calendar for 2024-12-25'")
    print("Or: 'What is the capital of France?'")
    
    let chatModel = MLXChatModel() // Reuse or create a new MLXChatModel
    let toolAgent = MLXToolAgent(chatModel: chatModel)
    
    while true {
        print("\nUser: ", terminator: "")
        guard let input = readLine() else { continue }
        
        if input.lowercased() == "exit" {
            print("Exiting tool agent. Goodbye!")
            break
        }
        
        do {
            let response = try await toolAgent.handleUserRequest(userQuery: input)
            print("Agent Final Response: \(response)")
        } catch {
            print("Error during agent processing: \(error.localizedDescription)")
        }
    }
}

// To run this:
/*
@main
struct MyApp {
    static func main() async {
        await runToolAgent()
    }
}
*/
