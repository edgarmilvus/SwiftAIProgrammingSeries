/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod Schema
const AiResponseSchema = z.object({
  id: z.string(),
  snippets: z.array(z.object({
    text: z.string(),
    confidence: z.number(),
  })),
  timestamp: z.number(),
});

type AiResponse = z.infer<typeof AiResponseSchema>;

// 2. Implement Unsafe Processor
function processDataUnsafe(data: any): string[] {
  // Direct access, assuming data structure is correct
  // This is fast but crashes if data.snippets is undefined or null
  return data.snippets.map((s: any) => s.text.toUpperCase());
}

// 3. Implement Safe Processor
function processDataSafe(data: unknown): string[] {
  // Validate first
  const parsed = AiResponseSchema.safeParse(data);
  if (!parsed.success) {
    console.error("Validation failed:", parsed.error.errors);
    return [];
  }
  // Process validated data
  return parsed.data.snippets.map(s => s.text.toUpperCase());
}

// 4. Simulation Logic
function runSimulation() {
  const ITEM_COUNT = 10000;

  // Generate mock data (Valid)
  const validData: AiResponse[] = Array.from({ length: ITEM_COUNT }, (_, i) => ({
    id: `id-${i}`,
    snippets: [{ text: `Sample text ${i}`, confidence: 0.9 }],
    timestamp: Date.now(),
  }));

  // Generate mock data (Invalid - missing 'text' field in snippets)
  const invalidData: any[] = Array.from({ length: ITEM_COUNT }, (_, i) => ({
    id: `id-${i}`,
    snippets: [{ confidence: 0.9 }], // Missing 'text' field
    timestamp: Date.now(),
  }));

  console.log("--- Starting Simulation ---");

  // Test 1: Unsafe with Valid Data
  console.time("Unsafe (Valid Data)");
  validData.forEach(item => processDataUnsafe(item));
  console.timeEnd("Unsafe (Valid Data)");

  // Test 2: Safe with Valid Data
  console.time("Safe (Valid Data)");
  validData.forEach(item => processDataSafe(item));
  console.timeEnd("Safe (Valid Data)");
  
  // Test 3: Unsafe with Invalid Data (Will likely throw error or return undefined, crashing or logging errors)
  // Note: We wrap this to prevent total script crash, but it highlights the risk.
  try {
    console.time("Unsafe (Invalid Data)");
    invalidData.forEach(item => processDataUnsafe(item));
    console.timeEnd("Unsafe (Invalid Data)");
  } catch (e) {
    console.error("Unsafe processing crashed on invalid data:", e);
  }

  // Test 4: Safe with Invalid Data
  console.time("Safe (Invalid Data)");
  invalidData.forEach(item => processDataSafe(item));
  console.timeEnd("Safe (Invalid Data)");
}

runSimulation();
