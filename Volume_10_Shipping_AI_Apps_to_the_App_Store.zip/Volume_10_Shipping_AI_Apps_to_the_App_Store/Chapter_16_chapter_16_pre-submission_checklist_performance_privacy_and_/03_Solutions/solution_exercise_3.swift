
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Foundation

// --- Data Layer ---
@available(iOS 18.0, *)
actor SummaryStore {
    private var storage: [String: String] = [:]
    
    func save(id: String, summary: String) {
        storage[id] = summary
    }
    
    func purgeCloudData() {
        // In a real app, this would delete files from Disk/CoreData
        storage.removeAll()
        print("Privacy Guard: All cloud-processed summaries purged.")
    }
}

// --- Service Layer (Strategy Pattern) ---
@available(iOS 18.0, *)
protocol SummarizationStrategy: Sendable {
    func summarize(text: String) async throws -> String
}

struct CloudSummarizer: SummarizationStrategy {
    func summarize(text: String) async throws -> String {
        try await Task.sleep(for: .seconds(2)) // Simulate network latency
        return "Cloud-generated summary of: \(text.prefix(10))..."
    }
}

struct LocalSummarizer: SummarizationStrategy {
    func summarize(text: String) async throws -> String {
        try await Task.sleep(for: .seconds(4)) // Simulate heavy local inference
        return "Local-generated (Private) summary of: \(text.prefix(10))..."
    }
}

@available(iOS 18.0, *)
actor SummarizationService {
    enum Mode { case local, cloud }
    
    private(set) var currentMode: Mode = .local
    private var strategy: SummarizationStrategy = LocalSummarizer()
    private let store: SummaryStore
    
    init(store: SummaryStore) {
        self.store = store
    }
    
    func switchMode(to newMode: Mode) async throws {
        // Compliance Requirement: Purge data when switching from Cloud to Local
        if currentMode == .cloud && newMode == .local {
            await store.purgeCloudData()
        }
        
        // Update strategy
        currentMode = newMode
        strategy = (newMode == .local) ? LocalSummarizer() : CloudSummarizer()
    }
    
    func performSummarization(text: String) async throws -> String {
        // Strict Compliance: Ensure we don't call Cloud if mode is Local
        guard currentMode == .local || strategy is CloudSummarizer else {
            throw NSError(domain: "PrivacyError", code: 403, userInfo: [NSLocalizedDescriptionKey: "Privacy Violation Attempted"])
        }
        return try await strategy.summarize(text: text)
    }
}

// --- UI Layer ---
@available(iOS 18.0, *)
@MainActor
class SummarizerViewModel: ObservableObject {
    @Published var mode: SummarizationService.Mode = .local
    @Published var isProcessing = false
    @Published var result = ""
    @Published var showConfirmation = false
    
    private let service: SummarizationService
    
    init(service: SummarizationService) {
        self.service = service
    }
    
    func toggleMode() {
        // Logic to trigger confirmation dialog if moving from Local -> Cloud
        if mode == .local {
            showConfirmation = true
        } else {
            executeModeSwitch(to: .local)
        }
    }
    
    func confirmCloudSwitch() {
        executeModeSwitch(to: .cloud)
    }
    
    private func executeModeSwitch(to newMode: SummarizationService.Mode) {
        Task {
            try? await service.switchMode(to: newMode)
            self.mode = newMode
            self.showConfirmation = false
        }
    }
    
    func runSummarization(text: String) {
        Task {
            isProcessing = true
            result = ""
            do {
                result = try await service.performSummarization(text: text)
            } catch {
                result = "Error: \(error.localizedDescription)"
            }
            isProcessing = false
        }
    }
}

struct PrivacySummarizerView: View {
    @StateObject var viewModel: SummarizerViewModel
    @State private var inputText = "Meeting notes regarding project X..."

    var body: some View {
        List {
            Section("Privacy Settings") {
                Toggle(viewModel.mode == .local ? "Local Mode (Private)" : "Cloud Mode (Standard)", isOn: Binding(
                    get: { viewModel.mode == .local },
                    set: { _ in viewModel.toggleMode() }
                ))
                
                if viewModel.mode == .local {
                    Label("No data leaves this device", systemImage: "lock.fill")
                        .font(.caption).foregroundColor(.green)
                } else {
                    Link("View Privacy Policy", destination: URL(string: "https://example.com/privacy")!)
                        .font(.caption)
                }
            }
            
            Section("Action") {
                TextField("Input text", text: $inputText)
                
                if viewModel.isProcessing {
                    HStack {
                        ProgressView()
                        Text(viewModel.mode == .local ? "Thinking locally..." : "Contacting Cloud...")
                            .font(.caption).italic()
                    }
                } else {
                    Button("Summarize") {
                        viewModel.runSummarization(text: inputText)
                    }
                }
            }
            
            if !viewModel.result.isEmpty {
                Section("Result") {
                    Text(viewModel.result)
                }
            }
        }
        .confirmationDialog("Switch to Cloud Mode?", isPresented: $viewModel.showConfirmation) {
            Button("Use Cloud Mode", role: .destructive) {
                viewModel.confirmCloudSwitch()
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("Switching to Cloud Mode means your text will be sent to our servers for processing. This improves intelligence but reduces privacy.")
        }
    }
}
