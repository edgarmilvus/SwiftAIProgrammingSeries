
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 15.0, *)
class ImageProcessor {
    let visionRequestHandler: VNImageRequestHandler // Assumed to be initialized with a CVPixelBuffer or CGImage

    // Assume 'detectionRequest' is a VNCoreMLRequest or VNRecognizeObjectsRequest
    // and 'detectionModel' is a VNCoreMLModel from a previous chapter's setup.
    let detectionRequest: VNCoreMLRequest

    init(image: CGImage, model: VNCoreMLModel) {
        self.visionRequestHandler = VNImageRequestHandler(cgImage: image, orientation: .up)
        self.detectionRequest = VNCoreMLRequest(model: model)
    }

    /// Performs object detection asynchronously.
    func performDetection() async throws -> [VNRecognizedObjectObservation] {
        try await withCheckedContinuation { continuation in
            let requestHandler = VNImageRequestHandler(cgImage: image, orientation: .up)
            
            // This closure is executed when the request completes.
            detectionRequest.completionHandler = { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                    continuation.resume(returning: []) // No observations or wrong type
                    return
                }
                continuation.resume(returning: observations)
            }

            // Perform the request on a background queue to avoid blocking.
            // In a real app, you might manage a dedicated Vision processing queue.
            Task {
                do {
                    try requestHandler.perform([detectionRequest])
                } catch {
                    // Handle errors during request performance
                    print("Error performing Vision request: \(error)")
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}
