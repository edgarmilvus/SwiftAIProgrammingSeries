
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CreateML

// MARK: - 1. Define Custom Data Structures
struct MotionDataPoint {
    let timestamp: Date
    let x_accel: Double
    let y_accel: Double
    let z_accel: Double
    let x_gyro: Double
    let y_gyro: Double
    let z_gyro: Double
}

struct ActivitySession: MLFeatureProvider {
    let id: UUID
    let activityLabel: String
    let motionData: [MotionDataPoint]
    
    // MARK: - MLFeatureProvider Conformance
    var featureNames: Set<String> {
        return ["accelerometerData", "gyroData", "label"]
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        // Ensure motionData is not empty to calculate relative timestamps
        guard let firstTimestamp = motionData.first?.timestamp else {
            return nil // Or handle error appropriately
        }
        
        switch featureName {
        case "accelerometerData":
            let accelSequenceElements: [MLFeatureValue.SequenceElement] = motionData.map { point in
                let relativeTime = point.timestamp.timeIntervalSince(firstTimestamp)
                let accelDict: [String: MLFeatureValue] = [
                    "x": .double(point.x_accel),
                    "y": .double(point.y_accel),
                    "z": .double(point.z_accel)
                ]
                return MLFeatureValue.SequenceElement(eventTime: relativeTime, featureValue: .dictionary(accelDict))
            }
            return .sequence(accelSequenceElements)
            
        case "gyroData":
            let gyroSequenceElements: [MLFeatureValue.SequenceElement] = motionData.map { point in
                let relativeTime = point.timestamp.timeIntervalSince(firstTimestamp)
                let gyroDict: [String: MLFeatureValue] = [
                    "x": .double(point.x_gyro),
                    "y": .double(point.y_gyro),
                    "z": .double(point.z_gyro)
                ]
                return MLFeatureValue.SequenceElement(eventTime: relativeTime, featureValue: .dictionary(gyroDict))
            }
            return .sequence(gyroSequenceElements)
            
        case "label":
            return .string(activityLabel)
            
        default:
            return nil
        }
    }
}

// MARK: - 3. Simulate Data
func simulateActivitySessions(count: Int) -> [ActivitySession] {
    var sessions: [ActivitySession] = []
    let activities = ["walking", "running", "cycling", "standing"]
    
    for _ in 0..<count {
        let activity = activities.randomElement()!
        var motionPoints: [MotionDataPoint] = []
        let startTime = Date()
        
        let duration = TimeInterval.random(in: 3.0...10.0) // Session duration
        let sampleRate = 50.0 // Hz (50 samples per second)
        let numSamples = Int(duration * sampleRate)
        
        for i in 0..<numSamples {
            let timestamp = startTime.addingTimeInterval(Double(i) / sampleRate)
            
            var x_accel, y_accel, z_accel: Double
            var x_gyro, y_gyro, z_gyro: Double
            
            // Simulate different patterns for activities
            switch activity {
            case "walking":
                x_accel = sin(Double(i) * 0.5) * 0.2 + Double.random(in: -0.1...0.1)
                y_accel = cos(Double(i) * 0.5) * 0.3 + Double.random(in: -0.1...0.1)
                z_accel = 1.0 + sin(Double(i) * 0.5) * 0.1 + Double.random(in: -0.05...0.05)
                x_gyro = sin(Double(i) * 0.5) * 0.05 + Double.random(in: -0.02...0.02)
                y_gyro = cos(Double(i) * 0.5) * 0.07 + Double.random(in: -0.02...0.02)
                z_gyro = Double.random(in: -0.01...0.01)
            case "running":
                x_accel = sin(Double(i) * 1.0) * 0.5 + Double.random(in: -0.2...0.2)
                y_accel = cos(Double(i) * 1.0) * 0.6 + Double.random(in: -0.2...0.2)
                z_accel = 1.0 + sin(Double(i) * 1.0) * 0.3 + Double.random(in: -0.1...0.1)
                x_gyro = sin(Double(i) * 1.0) * 0.1 + Double.random(in: -0.05...0.05)
                y_gyro = cos(Double(i) * 1.0) * 0.15 + Double.random(in: -0.05...0.05)
                z_gyro = Double.random(in: -0.03...0.03)
            case "cycling":
                x_accel = sin(Double(i) * 0.3) * 0.1 + Double.random(in: -0.05...0.05)
                y_accel = cos(Double(i) * 0.3) * 0.1 + Double.random(in: -0.05...0.05)
                z_accel = 1.0 + Double.random(in: -0.02...0.02) // Relatively stable Z
                x_gyro = Double.random(in: -0.01...0.01)
                y_gyro = Double.random(in: -0.01...0.01)
                z_gyro = sin(Double(i) * 0.3) * 0.1 + Double.random(in: -0.03...0.03) // Yaw motion
            case "standing":
                x_accel = Double.random(in: -0.05...0.05)
                y_accel = Double.random(in: -0.05...0.05)
                z_accel = 1.0 + Double.random(in: -0.02...0.02)
                x_gyro = Double.random(in: -0.01...0.01)
                y_gyro = Double.random(in: -0.01...0.01)
                z_gyro = Double.random(in: -0.01...0.01)
            default:
                x_accel = 0; y_accel = 0; z_accel = 0; x_gyro = 0; y_gyro = 0; z_gyro = 0
            }
            
            motionPoints.append(MotionDataPoint(timestamp: timestamp,
                                                x_accel: x_accel, y_accel: y_accel, z_accel: z_accel,
                                                x_gyro: x_gyro, y_gyro: y_gyro, z_gyro: z_gyro))
        }
        sessions.append(ActivitySession(id: UUID(), activityLabel: activity, motionData: motionPoints))
    }
    return sessions
}

// MARK: - Main Training Logic
func runExercise4() async {
    print("\n--- Exercise 4: Smart Activity Tracker with Custom Motion Classification ---")
    
    do {
        // 3. Simulate Data & 4. Create MLDataTable
        let simulatedSessions = simulateActivitySessions(count: 200)
        let dataTable = try MLDataTable(rows: simulatedSessions)
        
        print("Created MLDataTable with \(dataTable.rows.count) rows.")
        print("Columns: \(dataTable.columnNames)")
        
        // Verify column types for motion classifier
        guard dataTable.columnNames.contains("accelerometerData"),
              dataTable.columnNames.contains("gyroData"),
              dataTable.columnNames.contains("label") else {
            fatalError("MLDataTable missing required columns for MLMotionClassifier.")
        }
        
        // 5. Model Training
        let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 0)
        
        print("Training data sessions: \(trainingData.rows.count)")
        print("Testing data sessions: \(testingData.rows.count)")
        
        // MLMotionClassifier expects specific column names: "accelerometerData", "gyroData", and "label"
        // These are provided by our MLFeatureProvider implementation.
        let motionClassifier = try await MLMotionClassifier(trainingData: trainingData,
                                                            sessionColumn: nil, // Not needed when MLDataTable rows are already sessions
                                                            labelColumn: "label")
        
        print("MLMotionClassifier trained successfully.")
        
        // 6. Model Evaluation
        let evaluation = motionClassifier.evaluation(on: testingData)
        let accuracy = (1.0 - evaluation.classificationError) * 100
        print("Model evaluation accuracy on test data: \(String(format: "%.2f", accuracy))%")
        
        // 7. Model Saving
        let tempDirectory = FileManager.default.temporaryDirectory
        let modelURL = tempDirectory.appendingPathComponent("ActivityTracker.mlmodel")
        
        try motionClassifier.write(to: modelURL)
        print("Model saved to: \(modelURL.path)")
        
        // Optional: Clean up
        // try FileManager.default.removeItem(at: modelURL)
        // print("Cleaned up: removed \(modelURL.lastPathComponent)")
        
    } catch {
        print("Error during Exercise 4: \(error.localizedDescription)")
    }
}

// Run the exercise
// Task { await runExercise4() } // Uncomment to run directly if not part of a larger app
