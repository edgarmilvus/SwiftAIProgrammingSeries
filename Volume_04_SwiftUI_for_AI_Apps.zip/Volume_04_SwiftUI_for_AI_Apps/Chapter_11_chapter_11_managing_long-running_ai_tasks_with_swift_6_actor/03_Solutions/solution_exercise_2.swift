
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// 1. Define ImageProcessingRequest
struct ImageProcessingRequest: Identifiable, Hashable {
    let id: UUID
    let imageURL: URL
    let filterType: String
    let creationTime: Date = Date() // For logging order

    // Example for a dummy URL
    static func dummyURL(for id: UUID) -> URL {
        return URL(string: "file:///path/to/image_\(id.uuidString).jpg")!
    }
}

// Custom Error for Image Processing
enum ImageProcessorError: Error, LocalizedError {
    case processingFailed(String)
    case invalidImageURL
    case cancelled

    var errorDescription: String? {
        switch self {
        case .processingFailed(let details): return "Image processing failed: \(details)"
        case .invalidImageURL: return "The provided image URL is invalid."
        case .cancelled: return "Image processing was cancelled."
        }
    }
}

// 2. Define ImageProcessor Actor
actor ImageProcessor {
    // 4. Manage the Processing Queue
    private var processingQueue: [ImageProcessingRequest] = []
    private var isProcessing: Bool = false // Internal state to track if a task is active

    init() {
        print("ImageProcessor initialized.")
    }

    // Public method to enqueue requests
    func enqueue(request: ImageProcessingRequest) async {
        print("ImageProcessor: Enqueuing request for image \(request.id.uuidString.prefix(8)) with filter '\(request.filterType)'")
        processingQueue.append(request)
        // If not currently processing, try to start processing
        if !isProcessing {
            await processNextIfNeeded()
        }
    }

    // Internal method to process the next item in the queue
    private func processNextIfNeeded() async {
        guard !isProcessing, !processingQueue.isEmpty else { return }

        isProcessing = true
        let request = processingQueue.removeFirst()
        print("ImageProcessor: Starting processing for image \(request.id.uuidString.prefix(8)) (Filter: \(request.filterType))")

        do {
            // 3. Implement processImage method (now internal, called by the queue logic)
            let processedURL = try await _processImage(request: request)
            print("ImageProcessor: Finished processing image \(request.id.uuidString.prefix(8)). Output: \(processedURL.lastPathComponent)")
            // Optionally notify UI or external system via a delegate/closure
        } catch {
            print("ImageProcessor: Error processing image \(request.id.uuidString.prefix(8)): \(error.localizedDescription)")
            // Handle error, e.g., move to a failed queue
        }

        isProcessing = false
        // Recursively call to process the next item if available
        await processNextIfNeeded()
    }

    // The actual image processing logic, now a private helper
    private func _processImage(request: ImageProcessingRequest) async throws -> URL {
        // Simulate image processing using Task.sleep
        let processingTime = Double.random(in: 2.0...4.0) // Variable processing time
        try await Task.sleep(for: .seconds(processingTime))

        // Check for cancellation
        guard !Task.isCancelled else {
            print("ImageProcessor: Processing for \(request.id.uuidString.prefix(8)) was cancelled.")
            throw ImageProcessorError.cancelled
        }

        // Simulate a potential failure
        if Bool.random(in: 0...100) < 10 { // 10% chance of failure
            throw ImageProcessorError.processingFailed("Simulated AI model error.")
        }

        // Simulate returning a new URL for the processed image
        let processedImageURL = request.imageURL.deletingPathExtension().appendingPathExtension("processed.jpg")
        return processedImageURL
    }

    // Method to get current queue size for demonstration
    func getQueueSize() -> Int {
        return processingQueue.count
    }
}

// 6. Demonstrate Concurrent Enqueueing
@main
struct PhotoEditorApp {
    static func main() async {
        let processor = ImageProcessor()

        print("\n--- Demonstrating concurrent enqueueing ---")

        // Enqueue multiple requests concurrently
        for i in 1...5 {
            Task {
                let request = ImageProcessingRequest(
                    id: UUID(),
                    imageURL: ImageProcessingRequest.dummyURL(for: UUID()),
                    filterType: "AI Filter \(i)"
                )
                await processor.enqueue(request: request)
            }
        }

        // Enqueue another batch after a short delay
        Task {
            try await Task.sleep(for: .seconds(1))
            for i in 6...8 {
                let request = ImageProcessingRequest(
                    id: UUID(),
                    imageURL: ImageProcessingRequest.dummyURL(for: UUID()),
                    filterType: "AI Filter \(i)"
                )
                await processor.enqueue(request: request)
            }
        }

        // Monitor the queue size periodically
        Task {
            for _ in 1...10 {
                try await Task.sleep(for: .seconds(1))
                let size = await processor.getQueueSize()
                let isProcessing = await processor.isProcessing // Accessing isolated property
                print("App Monitor: Queue size: \(size), Processor busy: \(isProcessing)")
            }
        }

        // Keep the main task alive long enough for all async tasks to complete
        try? await Task.sleep(for: .seconds(30))
        print("\n--- All image processing tasks initiated and monitored. ---")
    }
}
