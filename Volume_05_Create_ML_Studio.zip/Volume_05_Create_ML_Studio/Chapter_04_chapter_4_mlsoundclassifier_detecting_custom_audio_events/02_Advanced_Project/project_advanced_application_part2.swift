
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// SmartHomeSoundMonitorApp.swift
import SwiftUI
import UserNotifications // For local notifications

@main
struct SmartHomeSoundMonitorApp: App {
    // An ObservableObject to manage the SoundMonitorService lifecycle and state
    @StateObject private var monitorService = SoundMonitorService()
    @State private var showingPermissionsAlert = false

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(monitorService) // Make service available to views
                .onAppear {
                    // Request notification permissions when the app launches
                    UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
                        if !granted {
                            print("Notification permission denied.")
                            // Optionally, prompt user to enable notifications in settings
                        }
                    }
                }
                .alert("Microphone Access Required", isPresented: $showingPermissionsAlert) {
                    Button("Open Settings") {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    }
                    Button("Cancel", role: .cancel) { }
                } message: {
                    Text("This app needs microphone access to detect sounds. Please enable it in Settings.")
                }
        }
    }
}

struct ContentView: View {
    @EnvironmentObject var monitorService: SoundMonitorService
    @State private var isMonitoringActive = false
    @State private var lastDetectedEvent: String?
    @State private var lastDetectedTimestamp: Date?

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Smart Home Sound Monitor")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Toggle(isOn: $isMonitoringActive) {
                    Label("Enable Sound Monitoring", systemImage: isMonitoringActive ? "mic.fill" : "mic.slash.fill")
                }
                .padding()
                .background(isMonitoringActive ? Color.green.opacity(0.2) : Color.red.opacity(0.2))
                .cornerRadius(10)
                .onChange(of: isMonitoringActive) { oldValue, newValue in
                    Task {
                        if newValue {
                            await startMonitoring()
                        } else {
                            await stopMonitoring()
                        }
                    }
                }

                if let event = lastDetectedEvent, let timestamp = lastDetectedTimestamp {
                    VStack {
                        Text("Last Detected Event:")
                            .font(.headline)
                        Text("\(event)")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.accentColor)
                        Text("at \(timestamp, formatter: Self.dateFormatter)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(8)
                } else {
                    Text("No events detected yet.")
                        .foregroundColor(.gray)
                }

                Spacer()

                Text("Monitoring Status: \(monitorService.isMonitoring ? "Active" : "Inactive")")
                    .font(.caption)
                    .foregroundColor(monitorService.isMonitoring ? .green : .red)
            }
            .padding()
            .navigationTitle("")
            .navigationBarHidden(true)
        }
        .onReceive(monitorService.$lastDetectedEvent) { event in
            if let eventName = event?.name {
                self.lastDetectedEvent = eventName
                self.lastDetectedTimestamp = Date()
            }
        }
        .onReceive(monitorService.$error) { error in
            if let err = error {
                print("Monitoring Error: \(err.localizedDescription)")
                // Present an alert to the user about the error
            }
        }
    }

    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        return formatter
    }()

    private func startMonitoring() async {
        do {
            try await monitorService.startMonitoring()
            isMonitoringActive = monitorService.isMonitoring // Reflect actual state
        } catch SoundMonitorService.SoundMonitorServiceError.microphonePermissionDenied {
            showingPermissionsAlert = true
            isMonitoringActive = false // Reset toggle if permission denied
        } catch {
            print("Failed to start monitoring: \(error.localizedDescription)")
            isMonitoringActive = false // Reset toggle on other errors
        }
    }

    private func stopMonitoring() async {
        await monitorService.stopMonitoring()
        isMonitoringActive = monitorService.isMonitoring // Reflect actual state
    }
}
