
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

extension OpenAIService {
    
    /// A wrapper that performs the request with an exponential backoff retry strategy.
    func generateCompletionWithRetry(
        for messages: [ChatMessage],
        model: String,
        maxRetries: Int = 3
    ) async throws -> ChatCompletionResponse {
        var currentAttempt = 0
        
        while true {
            do {
                // Attempt the actual request (logic from Ex 1)
                return try await self.generateCompletion(for: messages, model: model)
            } catch let error as OpenAIError {
                currentAttempt += 1
                
                // Only retry if it's a rate limit error and we haven't exhausted retries
                if case .rateLimitExceeded(let retryAfter) = error, currentAttempt <= maxRetries {
                    
                    // 1. Determine delay: Use Retry-After header OR Exponential Backoff
                    let delaySeconds: Double
                    if let retryAfter = retryAfter {
                        delaySeconds = retryAfter
                    } else {
                        // Exponential backoff: 2^n + jitter
                        let exponentialBase = pow(2.0, Double(currentAttempt))
                        let jitter = Double.random(in: 0.1...0.5)
                        delaySeconds = exponentialBase + jitter
                    }
                    
                    print("Rate limited. Retrying in \(delaySeconds)s (Attempt \(currentAttempt)/\(maxRetries))")
                    
                    // 2. Suspend the Task
                    try await Task.sleep(for: .seconds(delaySeconds))
                    
                    // 3. Check for cancellation before retrying
                    try Task.checkCancellation()
                    
                    continue // Proceed to next loop iteration
                } else {
                    // If it's not a rate limit error, or we ran out of retries, rethrow
                    throw error
                }
            } catch {
                // For any other error type, throw immediately
                throw error
            }
        }
    }
}
