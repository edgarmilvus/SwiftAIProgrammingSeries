
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct RAGTriadScore: Sendable {
    let contextRelevance: Double
    let faithfulness: Double
    let answerRelevance: Double
}

@available(iOS 18.0, macOS 15.0, *)
struct EvaluationReport: Sendable {
    let overallPass: Bool
    let averageScores: RAGTriadScore
    let failedQueries: [String]
}

@available(iOS 18.0, macOS 15.0, *)
enum EvaluationError: Error {
    case thresholdNotMet(String)
    case networkFailure
}

@available(iOS 18.0, macOS 15.0, *)
actor AutomatedEvaluator {
    let pipeline: any RAGPipeline
    let faithfulnessService: FaithfulnessService
    let threshold: RAGTriadScore

    init(pipeline: any RAGPipeline, faithfulnessService: FaithfulnessService, threshold: RAGTriadScore) {
        self.pipeline = pipeline
        self.faithfulnessService = faithfulnessService
        self.threshold = threshold
    }

    func runTestSuite(_ testSuite: [TestQuery]) async throws -> EvaluationReport {
        var totalRelevance: Double = 0
        var totalFaithfulness: Double = 0
        var totalAnswerRelevance: Double = 0
        var failedQueries: [String] = []
        
        for query in testSuite {
            do {
                // 1. Run RAG Cycle
                let (context, answer) = try await pipeline.execute(query: query.query)
                
                // 2. Evaluate Triad (Simulated scoring logic)
                // In production, these would be separate LLM calls
                let relevance = context.contains(query.expectedContextSnippet) ? 1.0 : 0.5
                let faithfulness = try await faithfulnessService.checkFaithfulness(context: context, answer: answer).confidenceScore
                let answerRel = 0.9 // Placeholder for Answer Relevance logic
                
                totalRelevance += relevance
                totalFaithfulness += faithfulness
                totalAnswerRelevance += answerRel
                
            } catch {
                failedQueries.append(query.query)
                throw EvaluationError.networkFailure
            }
        }
        
        let count = Double(testSuite.count)
        let avgScores = RAGTriadScore(
            contextRelevance: totalRelevance / count,
            faithfulness: totalFaithfulness / count,
            answerRelevance: totalAnswerRelevance / count
        )
        
        // 3. Threshold Logic (The Gatekeeper)
        let passed = avgScores.contextRelevance >= threshold.contextRelevance &&
                     avgScores.faithfulness >= threshold.faithfulness &&
                     avgScores.answerRelevance >= threshold.answerRelevance
        
        if !passed {
            return EvaluationReport(overallPass: false, averageScores: avgScores, failedQueries: failedQueries)
        }
        
        return EvaluationReport(overallPass: true, averageScores: avgScores, failedQueries: [])
    }
}
