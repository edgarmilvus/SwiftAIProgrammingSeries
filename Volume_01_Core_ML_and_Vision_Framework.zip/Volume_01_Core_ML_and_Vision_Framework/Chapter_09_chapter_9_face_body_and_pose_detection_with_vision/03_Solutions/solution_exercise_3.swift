
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Cocoa
import AVFoundation
import Vision

// MARK: - HandPointerManagerDelegate
protocol HandPointerManagerDelegate: AnyObject {
    func handPointerManager(_ manager: HandPointerManager, didUpdatePointerPosition point: CGPoint?)
    func handPointerManager(_ manager: HandPointerManager, didEncounterError error: Error)
}

// MARK: - HandPointerManager
class HandPointerManager: NSObject {

    weak var delegate: HandPointerManagerDelegate?

    private let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoOutputQueue = DispatchQueue(label: "com.example.handPointerVideoQueue", qos: .userInitiated)
    private var previewLayer: AVCaptureVideoPreviewLayer? // Optional: for debugging or showing camera feed

    // The dimensions of the view where the pointer will be displayed.
    // This is crucial for accurate coordinate transformation.
    var displayViewSize: CGSize = .zero {
        didSet {
            if displayViewSize != oldValue {
                print("Display view size updated to: \(displayViewSize)")
            }
        }
    }

    override init() {
        super.init()
        setupCaptureSession()
    }

    private func setupCaptureSession() {
        // 1. Configure input device (camera)
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            delegate?.handPointerManager(self, didEncounterError: NSError(domain: "HandPointerManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "No front camera found."]))
            return
        }

        guard let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            delegate?.handPointerManager(self, didEncounterError: NSError(domain: "HandPointerManager", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not create video device input."]))
            return
        }

        // 2. Add input to session
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            delegate?.handPointerManager(self, didEncounterError: NSError(domain: "HandPointerManager", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not add video input to session."]))
            return
        }

        // 3. Configure video output
        videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        videoOutput.alwaysDiscardsLateVideoFrames = true // Prioritize fresh frames
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        // 4. Add output to session
        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            delegate?.handPointerManager(self, didEncounterError: NSError(domain: "HandPointerManager", code: 4, userInfo: [NSLocalizedDescriptionKey: "Could not add video output to session."]))
            return
        }

        // 5. Ensure video orientation is correct (important for Vision coordinate mapping)
        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait // Or .landscapeRight if camera is mounted differently
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = true // Mirror front camera output
        }
    }

    func start() {
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard let self = self else { return }
            if granted {
                self.videoOutputQueue.async {
                    self.captureSession.startRunning()
                    print("AVCaptureSession started.")
                }
            } else {
                self.delegate?.handPointerManager(self, didEncounterError: NSError(domain: "HandPointerManager", code: 5, userInfo: [NSLocalizedDescriptionKey: "Camera access denied."]))
            }
        }
    }

    func stop() {
        videoOutputQueue.async {
            self.captureSession.stopRunning()
            print("AVCaptureSession stopped.")
        }
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
extension HandPointerManager: AVCaptureVideoDataOutputSampleBufferDelegate {

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Create a Vision request handler.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:]) // .up is default for most CVPixelBuffers

        // Create a hand pose detection request.
        let request = VNDetectHandPoseRequest()
        request.maximumHandCount = 1 // Focus on a single dominant hand.

        do {
            try handler.perform([request])

            guard let observations = request.results as? [VNHandPoseObservation], let hand = observations.first else {
                // No hand detected, or not enough confidence.
                DispatchQueue.main.async {
                    self.delegate?.handPointerManager(self, didUpdatePointerPosition: nil)
                }
                return
            }

            // Get the index finger tip point.
            guard let indexTip = try? hand.recognizedPoint(.indexTip) else {
                DispatchQueue.main.async {
                    self.delegate?.handPointerManager(self, didUpdatePointerPosition: nil)
                }
                return
            }

            // Check confidence.
            guard indexTip.confidence > 0.3 else { // Adjust confidence threshold as needed.
                DispatchQueue.main.async {
                    self.delegate?.handPointerManager(self, didUpdatePointerPosition: nil)
                }
                return
            }

            // Convert Vision's normalized coordinates to screen coordinates.
            let pointerPosition = convertVisionPointToScreenPoint(indexTip.location, imageSize: CVPixelBufferGetSize(pixelBuffer), displayViewSize: displayViewSize)

            DispatchQueue.main.async {
                self.delegate?.handPointerManager(self, didUpdatePointerPosition: pointerPosition)
            }

        } catch {
            print("Failed to perform hand pose request: \(error)")
            DispatchQueue.main.async {
                self.delegate?.handPointerManager(self, didEncounterError: error)
            }
        }
    }

    /// Converts a Vision normalized point to a point in the target display view's coordinate system.
    /// - Parameters:
    ///   - visionPoint: The normalized point from Vision (0.0-1.0, bottom-left origin).
    ///   - imageSize: The original size of the CVPixelBuffer.
    ///   - displayViewSize: The size of the NSView where the pointer will be displayed (top-left origin).
    /// - Returns: A CGPoint in the display view's coordinate system.
    private func convertVisionPointToScreenPoint(_ visionPoint: CGPoint, imageSize: CGSize, displayViewSize: CGSize) -> CGPoint {
        // Vision's Y-axis is inverted relative to UIKit/AppKit (bottom-left vs top-left).
        // Flip Y-coordinate: 1.0 - visionPoint.y
        let flippedY = 1.0 - visionPoint.y

        // Scale to display view dimensions.
        let screenX = visionPoint.x * displayViewSize.width
        let screenY = flippedY * displayViewSize.height
        
        // Note: This assumes the displayViewSize has the same aspect ratio as the camera feed,
        // or that it's okay to stretch/squash. For precise aspect fit/fill,
        // more complex calculations involving content modes would be needed.
        // For a presentation tool, a direct mapping is often sufficient.

        return CGPoint(x: screenX, y: screenY)
    }
}

// MARK: - HandPointerView (NSView for displaying the pointer)
class HandPointerView: NSView, HandPointerManagerDelegate {

    private let pointerLayer: CALayer = {
        let layer = CALayer()
        layer.backgroundColor = NSColor.red.cgColor
        layer.cornerRadius = 10 // Make it a circle
        layer.bounds = CGRect(x: 0, y: 0, width: 20, height: 20)
        layer.opacity = 0.8
        layer.isHidden = true
        return layer
    }()

    private let handPointerManager = HandPointerManager()

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        // Add the pointer layer to this view's layer hierarchy.
        self.wantsLayer = true // Ensure the view has a backing layer
        self.layer?.addSublayer(pointerLayer)

        handPointerManager.delegate = self
        // Inform the manager about the view's size for coordinate transformation.
        handPointerManager.displayViewSize = self.bounds.size
    }

    override func layout() {
        super.layout()
        // Update manager's displayViewSize if the view's bounds change.
        handPointerManager.displayViewSize = self.bounds.size
    }

    // MARK: - HandPointerManagerDelegate
    func handPointerManager(_ manager: HandPointerManager, didUpdatePointerPosition point: CGPoint?) {
        if let point = point {
            // Update the pointer layer's position.
            // Core Animation positions are anchor point based, so adjust for center.
            pointerLayer.position = CGPoint(x: point.x, y: point.y)
            pointerLayer.isHidden = false
        } else {
            // Hide pointer if no hand is detected or confidence is low.
            pointerLayer.isHidden = true
        }
    }

    func handPointerManager(_ manager: HandPointerManager, didEncounterError error: Error) {
        print("HandPointerManager error: \(error.localizedDescription)")
        // Handle error, e.g., display an alert to the user.
    }

    // MARK: - Control HandPointerManager lifecycle
    func startHandPointer() {
        handPointerManager.start()
    }

    func stopHandPointer() {
        handPointerManager.stop()
    }
}

// MARK: - Example Usage (in an NSViewController or similar)
/*
class MyPresentationViewController: NSViewController {
    var handPointerView: HandPointerView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Create and add the HandPointerView to your view hierarchy.
        // Make sure it covers the area where you want the pointer to appear.
        handPointerView = HandPointerView(frame: view.bounds)
        handPointerView.autoresizingMask = [.width, .height]
        view.addSubview(handPointerView)
    }

    override func viewDidAppear() {
        super.viewDidAppear()
        handPointerView.startHandPointer()
    }

    override func viewWillDisappear() {
        super.viewWillDisappear()
        handPointerView.stopHandPointer()
    }
}
*/
