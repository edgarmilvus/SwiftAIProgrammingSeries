
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation // Provides basic types like Date, TimeInterval, Error

// MARK: - 1. Data Structures for Inference

/// Represents the output from an AI model's inference on a specific image region.
struct InferenceResult: CustomStringConvertible {
    let regionID: Int
    let prediction: String
    let confidence: Double

    var description: String {
        return "Region \(regionID): \(prediction) (Confidence: \(String(format: "%.2f", confidence)))"
    }
}

// MARK: - 2. Image Analysis Service

/// Represents an AI-powered image analysis service.
/// This service is designed to process multiple image regions in parallel
/// and supports cooperative cancellation for its inference tasks.
class ImageAnalysisService {

    /// Simulates processing a single image region using an AI model.
    /// This function performs a mock "inference" by sleeping for a specified duration.
    /// It is designed to be cancellable, meaning it will throw `CancellationError`
    /// if its containing `Task` is cancelled.
    ///
    /// - Parameters:
    ///   - regionID: A unique identifier for the image region being processed.
    ///   - processingTime: The simulated time in seconds this region takes to process.
    /// - Returns: An `InferenceResult` if processing completes successfully.
    ///            Throws `CancellationError` if the task is cancelled mid-way.
    ///            Throws other errors for simulated failures.
    func analyzeRegion(regionID: Int, processingTime: TimeInterval) async throws -> InferenceResult {
        print("[\(regionID)] Starting analysis for region \(regionID). Expected time: \(String(format: "%.1f", processingTime))s...")

        let startTime = Date()
        var elapsed: TimeInterval = 0

        // Simulate work in small, interruptible chunks to allow frequent cancellation checks.
        // This is crucial for cooperative cancellation: tasks must periodically check
        // `Task.isCancelled` or call `Task.checkCancellation()`.
        let checkInterval: TimeInterval = 0.2 // Check for cancellation every 0.2 seconds
        let numChecks = Int(processingTime / checkInterval)

        for i in 0...numChecks {
            // `Task.checkCancellation()` is a convenient way to check for cancellation.
            // If the task has been cancelled, it immediately throws a `CancellationError`.
            // This allows the task to exit early.
            try Task.checkCancellation()

            // Simulate a chunk of work.
            await Task.sleep(for: .milliseconds(Int(checkInterval * 1000)))
            elapsed = Date().timeIntervalSince(startTime)
            print("[\(regionID)] Working... \(String(format: "%.1f", elapsed))s / \(String(format: "%.1f", processingTime))s")
        }

        // A final check after the loop ensures that even if processingTime is very short
        // or the loop completes just before cancellation, we still respect the cancellation.
        try Task.checkCancellation()

        // Simulate the actual inference result.
        let prediction = (regionID % 3 == 0) ? "Person" : (regionID % 2 == 0 ? "Vehicle" : "Animal")
        let confidence = Double.random(in: 0.75...0.99)
        print("[\(regionID)] Analysis for region \(regionID) complete after \(String(format: "%.1f", elapsed))s.")
        return InferenceResult(regionID: regionID, prediction: prediction, confidence: confidence)
    }

    /// Analyzes multiple image regions concurrently using a `TaskGroup`.
    /// This function orchestrates parallel execution of `analyzeRegion` tasks
    /// and demonstrates how cancellation propagates from a parent task to its group and children.
    ///
    /// - Parameters:
    ///   - regionIDs: An array of unique identifiers for the image regions to process.
    ///   - regionProcessingTimes: A dictionary mapping region IDs to their simulated processing times.
    /// - Returns: A dictionary of `InferenceResult` keyed by region ID for all successfully completed analyses.
    ///            Cancelled tasks will not contribute to the results.
    func analyzeImageRegions(regionIDs: [Int], regionProcessingTimes: [Int: TimeInterval]) async -> [Int: InferenceResult] {
        var results: [Int: InferenceResult] = [:]
        print("\n--- Starting parallel analysis for \(regionIDs.count) regions using TaskGroup ---")

        do {
            // `withTaskGroup` creates a structured concurrency group.
            // The `of` parameter specifies the type of value that each child task will return.
            // In this case, we return a tuple `(Int, InferenceResult?)` where `Int` is the region ID
            // and `InferenceResult?` allows us to indicate if a task was cancelled (by returning nil).
            try await withTaskGroup(of: (Int, InferenceResult?).self) { group in
                for id in regionIDs {
                    let processingTime = regionProcessingTimes[id] ?? 1.0 // Default to 1 second
                    // `group.addTask` creates a new child task within the group.
                    // These child tasks run concurrently.
                    // If the `withTaskGroup` block's parent task is cancelled,
                    // this cancellation propagates to all child tasks.
                    group.addTask {
                        do {
                            let result = try await self.analyzeRegion(regionID: id, processingTime: processingTime)
                            return (id, result) // Return the result if successful
                        } catch is CancellationError {
                            // If `analyzeRegion` throws `CancellationError`, it means this specific
                            // child task was cancelled. We handle it gracefully and return `nil`
                            // for the result, indicating it didn't complete.
                            print("[\(id)] Analysis for region \(id) was cancelled by parent task.")
                            return (id, nil)
                        } catch {
                            // Handle any other unexpected errors during inference.
                            print("[\(id)] Analysis for region \(id) failed with error: \(error.localizedDescription)")
                            return (id, nil)
                        }
                    }
                }

                // Iterate over the results of the child tasks as they complete.
                // `for await` ensures we process results in completion order, not submission order.
                for await (id, result) in group {
                    if let result = result {
                        results[id] = result // Only add successful results
                    }
                }
            }
        } catch is CancellationError {
            // This catch block handles cancellation of the `withTaskGroup` itself.
            // This can happen if the parent task is cancelled *before* all child tasks are added,
            // or if the cancellation propagates while `for await` is still collecting results.
            print("Parent task group was cancelled during setup or result collection.")
        } catch {
            // Catch any other unexpected errors that might escape the `withTaskGroup` block.
            print("An unexpected error occurred in the task group: \(error.localizedDescription)")
        }

        print("--- Parallel analysis finished. Completed results: \(results.count) ---")
        return results
    }
}

// MARK: - 3. Main Execution and Demonstration

/// The entry point for demonstrating the `ImageAnalysisService` with Task Groups and Cancellation.
/// This function simulates a UI-driven request and potential cancellation scenarios.
func runExample() async {
    let service = ImageAnalysisService()
    let regionIDs = [101, 102, 103, 104, 105] // IDs for 5 image regions
    let processingTimes: [Int: TimeInterval] = [
        101: 3.0, // Region 101 takes 3 seconds
        102: 1.0, // Region 102 takes 1 second
        103: 5.0, // Region 103 takes 5 seconds
        104: 2.0, // Region 104 takes 2 seconds
        105: 4.0  // Region 105 takes 4 seconds
    ]

    print("--- Demonstrating TaskGroup with Cancellation for AI Image Analysis ---")

    // Scenario 1: Allow all tasks to complete without cancellation
    print("\n=== SCENARIO 1: All tasks complete successfully ===")
    let fullAnalysisTask = Task {
        print("Starting Scenario 1 parent task...")
        let completedResults = await service.analyzeImageRegions(regionIDs: regionIDs, regionProcessingTimes: processingTimes)
        print("Scenario 1 Parent Task finished. Results: \(completedResults.values.map { $0.description }.joined(separator: ", "))")
    }
    await fullAnalysisTask.value // Wait for the entire task (and its children) to finish
    print("Scenario 1 demonstration concluded.\n")


    // Scenario 2: Initiate cancellation mid-way through the parallel processing
    print("\n=== SCENARIO 2: Cancellation in action ===")
    let cancellableAnalysisTask = Task {
        print("Starting Scenario 2 parent task...")
        let completedResults = await service.analyzeImageRegions(regionIDs: regionIDs, regionProcessingTimes: processingTimes)
        print("Scenario 2 Parent Task finished. Results: \(completedResults.values.map { $0.description }.joined(separator: ", "))")
    }

    // Simulate a user action (e.g., navigating away, new image frame)
    // after 2.5 seconds, which should trigger cancellation.
    await Task.sleep(for: .milliseconds(2500))
    print("\n>>> Main task: Simulating user action, cancelling ongoing analysis! <<<\n")
    // Calling `cancel()` on the parent `Task` propagates the cancellation request
    // down to its child tasks (including the `withTaskGroup` and its individual `addTask` children).
    cancellableAnalysisTask.cancel()

    // Wait for the cancellableAnalysisTask to finish.
    // It will complete once all its child tasks have either finished or acknowledged cancellation.
    _ = await cancellableAnalysisTask.value
    print("Scenario 2 demonstration concluded.\n")
}

// MARK: - 4. Application Entry Point

// For a real SwiftUI app, `runExample()` would typically be called from a
// `.task` modifier on a view, or within an `Observable` object's method.
// For this standalone example, we use `@main` to create an async entry point.
@main
struct CancellationApp {
    static func main() async {
        await runExample()
    }
}
