
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
extension Agent {
    func runLoop(initialPrompt: String, maxIterations: Int = 5) async throws {
        var currentPrompt = initialPrompt
        for iteration in 0..<maxIterations {
            print("--- Agent Loop Iteration \(iteration + 1) ---")

            // 1. Reasoning
            print("Reasoning with prompt: \(currentPrompt)")
            let llmOutput = try await reason(prompt: currentPrompt)
            print("LLM Output: \(llmOutput)")

            // Parse LLM output to determine action (simplified for example)
            guard let action = parseLLMOutputToAction(llmOutput) else {
                print("Agent decided to stop or couldn't parse action.")
                break
            }

            // 2. Acting
            print("Executing action: \(action)")
            let toolResult = try await act(action: action)
            print("Action Result: \(toolResult)")

            // 3. Observing
            let observation = processToolResultForObservation(toolResult)
            observe(feedback: observation) // Update internal memory
            print("Observed: \(observation)")

            // Prepare for next iteration
            currentPrompt = "Based on the last action's result: '\(observation)', what should I do next?"
        }
        print("--- Agent Loop Finished ---")
    }

    // Placeholder for parsing LLM output into an action
    private func parseLLMOutputToAction(_ output: String) -> AgentAction? {
        // In a real agent, this would involve sophisticated parsing, e.g., JSON or tool calling format
        if output.contains("CALL_TOOL:fetch_weather") {
            return .callTool(name: "fetch_weather", parameters: ["location": "Cupertino"])
        } else if output.contains("UPDATE_MEMORY:") {
            let memoryData = output.replacingOccurrences(of: "UPDATE_MEMORY:", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
            return .updateMemory(data: memoryData)
        }
        return nil // Agent decides to stop or invalid action
    }

    // Placeholder for processing tool result into an observation
    private func processToolResultForObservation(_ result: ToolOutput) -> String {
        switch result {
        case .success(let message): return "Tool succeeded with: \(message)"
        case .failure(let error): return "Tool failed with error: \(error)"
        }
    }
}
