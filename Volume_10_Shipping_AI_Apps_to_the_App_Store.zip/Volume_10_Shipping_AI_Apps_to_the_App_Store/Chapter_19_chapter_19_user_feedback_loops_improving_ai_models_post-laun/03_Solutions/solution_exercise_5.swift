
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

/// 2. Mock Models
struct GeneratorModel {
    func generate() async -> String {
        try? await Task.sleep(for: .seconds(1))
        return "func hello() { print(\"Hello World\") }" // A valid snippet
    }
}

struct CriticModel {
    func evaluate(_ code: String) async -> Double {
        try? await Task.sleep(for: .seconds(0.5))
        // Simulate a low score if the code is too short
        return code.count > 20 ? 0.9 : 0.4
    }
}

/// 1. Inference Pipeline Actor
actor InferencePipeline {
    private let generator = GeneratorModel()
    private let critic = CriticModel()
    private let maxRetries = 3
    
    /// 4. Implement the Self-Correction Loop
    func generateRefinedCode() async throws -> String {
        return try await attemptGeneration(retryCount: 0)
    }
    
    private func attemptGeneration(retryCount: Int) async throws -> String {
        print("🔄 Generation attempt \(retryCount + 1)...")
        
        // Stage 1: Generation
        let code = await generator.generate()
        
        // Stage 2: Evaluation
        let score = await critic.evaluate(code)
        print("📊 Critic Score: \(score)")
        
        if score >= 0.7 {
            print("✅ Quality threshold met.")
            return code
        } else {
            // Check for "Loop of Death"
            guard retryCount < maxRetries else {
                print("❌ Max retries reached. Returning unrefined code.")
                throw GenerationError.lowQuality
            }
            
            print("⚠️ Quality low. Triggering self-correction...")
            // In a real LLM, you would pass the score/error back to the prompt
            return try await attemptGeneration(retryCount: retryCount + 1)
        }
    }
    
    enum GenerationError: Error {
        case lowQuality
    }
}

// MARK: - Execution
func runCodePilot() async {
    let pipeline = InferencePipeline()
    
    do {
        let finalCode = try await pipeline.generateRefinedCode()
        print("\n🚀 Final Output:\n\(finalCode)")
    } catch {
        print("\n🛑 Failed to generate high-quality code: \(error)")
    }
}
