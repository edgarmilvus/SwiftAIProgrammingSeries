
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - AIResponseSimulatorApp.swift (Application Entry Point)
import SwiftUI

/// The main entry point for the AI Response Simulator application.
/// This structure defines the application's lifecycle and its initial scene.
@main
struct AIResponseSimulatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(minWidth: 400, minHeight: 300) // Set a reasonable default window size for macOS
        }
        // Configure the window for macOS to have a title bar, etc.
        // For production, you might add more specific window customization.
        .windowStyle(.default) // Use the default window style
    }
}

// MARK: - ContentView.swift (Main User Interface)
import SwiftUI

/// The main content view of the AI Response Simulator.
/// It provides an interface for user input and displays AI responses.
struct ContentView: View {
    // State variables to hold the user's input and the AI's response.
    @State private var userInput: String = ""
    @State private var aiResponse: String = "Hello! How can I assist you today?"

    // An instance of our simple AI responder logic.
    private let aiResponder = SimpleAIResponder()

    var body: some View {
        VStack(spacing: 15) { // Vertical stack for UI elements with spacing
            Text("Local AI Assistant Simulator")
                .font(.title)
                .padding(.bottom, 10)

            // Display area for AI responses
            ScrollView {
                Text(aiResponse)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(height: 150) // Fixed height for the response display
            .padding(.horizontal)

            // Input field for the user
            TextField("Type your message here...", text: $userInput)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .onSubmit {
                    // When the user presses Enter, process the input
                    processInput()
                }

            // Button to explicitly send the message
            Button("Send Message") {
                processInput()
            }
            .buttonStyle(.borderedProminent)
            .padding(.bottom)
        }
        .padding() // Overall padding for the VStack
    }

    /// Processes the user's input and updates the AI response.
    /// This function simulates an interaction with an AI model.
    private func processInput() {
        guard !userInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            aiResponse = "Please type something before sending!"
            return
        }

        // Simulate an asynchronous call to an AI model.
        // In a real app, this would involve calling out to Ollama, llama.cpp, etc.
        Task { @MainActor in // Ensure UI updates are on the main actor
            let response = await aiResponder.generateResponse(for: userInput)
            aiResponse = response
            userInput = "" // Clear the input field after sending
        }
    }
}

// MARK: - SimpleAIResponder.swift (Simulated AI Logic)
import Foundation

/// A simple class to simulate AI responses.
/// In a real AI application, this would contain the logic for interacting
/// with a local LLM (e.g., via Ollama, llama.cpp Swift bindings).
class SimpleAIResponder {

    /// Generates a simulated AI response based on the user's input.
    /// This method is asynchronous to mimic real-world LLM inference times.
    /// - Parameter input: The user's message.
    /// - Returns: A simulated AI response string.
    func generateResponse(for input: String) async -> String {
        // Simulate a network/processing delay
        try? await Task.sleep(for: .seconds(0.5))

        let lowercasedInput = input.lowercased()

        if lowercasedInput.contains("hello") || lowercasedInput.contains("hi") {
            return "Greetings! How can I help you today?"
        } else if lowercasedInput.contains("time") {
            let formatter = DateFormatter()
            formatter.timeStyle = .short
            return "The current time is \(formatter.string(from: Date()))."
        } else if lowercasedInput.contains("weather") {
            return "I'm sorry, I cannot provide real-time weather information."
        } else if lowercasedInput.contains("swift") || lowercasedInput.contains("apple silicon") {
            return "Swift and Apple Silicon are a powerful combination for AI development!"
        } else if lowercasedInput.contains("ollama") || lowercasedInput.contains("llama.cpp") {
            return "Running local LLMs with Ollama or llama.cpp is incredibly efficient on Apple Silicon."
        } else if lowercasedInput.contains("thank you") || lowercasedInput.contains("thanks") {
            return "You're welcome! Feel free to ask anything else."
        } else {
            return "That's an interesting query! I'm still learning, but I can tell you more about local AI."
        }
    }
}
