
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation

// Assuming MyInputFeatures is a struct that encapsulates the features
// and conforms to MLFeatureProvider.
// By default, structs composed of Sendable types are Sendable.
struct MyInputFeatures: MLFeatureProvider, Sendable {
    let feature1: Double
    let feature2: Double

    var featureNames: Set<String> {
        return ["feature1", "feature2"]
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        switch featureName {
        case "feature1": return MLFeatureValue(double: feature1)
        case "feature2": return MLFeatureValue(double: feature2)
        default: return nil
        }
    }
}

@available(iOS 18.0, *)
actor PredictionActor {
    private var model: MLModel // Assume this is loaded

    init(model: MLModel) {
        self.model = model
    }

    // This method can now safely accept a MyInputFeatures instance
    func predict(input: MyInputFeatures) async throws -> MLFeatureProvider {
        return try await Task {
            try model.prediction(from: input)
        }.value
    }
}
