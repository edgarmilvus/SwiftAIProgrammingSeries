
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit // For UI elements
import NaturalLanguage // For NLTagger

// NLTagger.TagScheme.sentimentScore is available from iOS 13.0, macOS 10.15.
// @available(iOS 18.0, *) is used here to align with the chapter's implied modern Swift 6 context.
@available(iOS 13.0, *) // Using iOS 13.0 as the minimum for sentimentScore
class SentimentMessagingViewController: UIViewController, UITextViewDelegate {

    // MARK: - UI Elements

    private let messageTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    private let sentimentLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.text = "Sentiment: Neutral (0.00)" // Initial state
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Debouncing Properties

    private var sentimentAnalysisTimer: Timer? // Timer for debouncing sentiment analysis

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Sentiment Messenger"

        // Add UI elements to the view
        view.addSubview(messageTextView)
        view.addSubview(sentimentLabel)

        // Set delegate for real-time text changes
        messageTextView.delegate = self

        // Setup Auto Layout constraints
        NSLayoutConstraint.activate([
            messageTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            messageTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            messageTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            messageTextView.heightAnchor.constraint(equalToConstant: 200),

            sentimentLabel.topAnchor.constraint(equalTo: messageTextView.bottomAnchor, constant: 20),
            sentimentLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            sentimentLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            sentimentLabel.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    // MARK: - UITextViewDelegate

    func textViewDidChange(_ textView: UITextView) {
        // Invalidate any previously scheduled timer to reset the debounce period
        sentimentAnalysisTimer?.invalidate()

        // Schedule a new timer. If the user types again before 0.5 seconds, this timer will be invalidated.
        sentimentAnalysisTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in
            // Perform sentiment analysis only after the user has paused typing for 0.5 seconds
            self?.performSentimentAnalysis()
        }
    }

    // MARK: - Sentiment Analysis Logic

    private func performSentimentAnalysis() {
        guard let text = messageTextView.text, !text.isEmpty else {
            // Reset to neutral if text is empty
            sentimentLabel.text = "Sentiment: Neutral (0.00)"
            sentimentLabel.textColor = .label
            return
        }

        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text

        let (sentimentTag, _) = tagger.tag(at: text.startIndex, unit: .document, scheme: .sentimentScore)

        guard let scoreString = sentimentTag?.rawValue,
              let score = Double(scoreString) else {
            // Handle cases where sentiment analysis might fail
            sentimentLabel.text = "Sentiment: Error"
            sentimentLabel.textColor = .systemRed
            return
        }

        let classification: String
        let textColor: UIColor

        // Define classification thresholds. Slightly wider neutral range for better UI feedback.
        if score > 0.2 {
            classification = "Positive"
            textColor = .systemGreen
        } else if score < -0.2 {
            classification = "Negative"
            textColor = .systemRed
        } else {
            classification = "Neutral"
            textColor = .label // Default text color
        }

        // Update the UI label with the sentiment result
        sentimentLabel.text = "Sentiment: \(classification) (\(String(format: "%.2f", score)))"
        sentimentLabel.textColor = textColor
    }
}

// How to integrate this into a SwiftUI App (for example, using UIViewControllerRepresentable):
/*
import SwiftUI

@available(iOS 13.0, *)
struct SentimentMessagingView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> SentimentMessagingViewController {
        SentimentMessagingViewController()
    }

    func updateUIViewController(_ uiViewController: SentimentMessagingViewController, context: Context) {
        // No update needed for this simple example
    }
}

@available(iOS 13.0, *)
#Preview {
    SentimentMessagingView()
}
*/
