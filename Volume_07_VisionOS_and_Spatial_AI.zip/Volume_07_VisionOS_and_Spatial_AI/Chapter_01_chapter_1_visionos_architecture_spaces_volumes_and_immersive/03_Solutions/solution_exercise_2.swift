
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import RealityKit

struct ArtifactVolumeView: View {
    // State to track the transform of the artifact
    @State private var rotation: Float = 0.0
    @State private var scale: Float = 1.0
    
    var body: some View {
        RealityView { content in
            // 1. Load the artifact (Assuming a USDZ exists in the bundle)
            if let artifact = try? await Entity(named: "GreekAmphora") {
                artifact.name = "artifact"
                // Center the artifact at the volume's origin (0,0,0)
                artifact.position = [0, 0, 0]
                content.add(artifact)
            }
        } update: { content in
            // 2. Update the entity transform based on state
            if let artifact = content.entities.first(where: { $0.name == "artifact" }) {
                artifact.transform.rotation = simd_quatf(angle: rotation, axis: [0, 1, 0])
                artifact.transform.scale = [scale, scale, scale]
            }
        }
        .gesture(
            // 3. Rotation Gesture
            DragGesture()
                .onChanged { value in
                    // Sensitivity adjustment for smooth rotation
                    rotation += Float(value.translation.width) * 0.005
                }
        )
        .gesture(
            // 4. Scaling Gesture
            MagnificationGesture()
                .onChanged { value in
                    // Clamp scaling to prevent the object from becoming too small or too large
                    // and effectively "escaping" the volume bounds
                    let newScale = max(0.5, min(value, 2.0))
                    scale = newScale
                }
        )
    }
}

@main
struct MuseumApp: App {
    var body: some Scene {
        // Standard Window for UI
        WindowGroup {
            Text("Museum Catalog")
                .frame(width: 300, height: 300)
        }

        // The Volumetric Window
        WindowGroup(id: "artifact-viewer") {
            ArtifactVolumeView()
        }
        .windowStyle(.volumetric) // Defines the 3D container
        .defaultSize(width: 0.5, height: 0.5, depth: 0.5, in: .meters) // 0.5m cube
    }
}
