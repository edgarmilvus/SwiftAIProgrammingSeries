
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

struct StaticObjectDetectionView: View {
    // Define a static bounding box in normalized (0-1) coordinates.
    // This box represents 20% from left, 30% from top, 60% width, 40% height of the original image.
    let normalizedBoundingBox = CGRect(x: 0.2, y: 0.3, width: 0.6, height: 0.4)

    var body: some View {
        VStack {
            Text("Static Object Detection")
                .font(.headline)
                .padding()

            // The image to overlay. Using a system symbol for simplicity.
            // .resizable() and .scaledToFit() ensure the image fills the available space
            // while maintaining its aspect ratio, which GeometryReader will then reflect.
            Image(systemName: "photo.fill")
                .resizable()
                .scaledToFit()
                .foregroundColor(.gray) // Make the placeholder image visible
                .padding() // Add padding to make the image smaller than the full screen

            // Overlay the image with a GeometryReader and Canvas
            .overlay(
                GeometryReader { geometry in
                    Canvas { context, size in
                        // Calculate the actual drawing rectangle based on the GeometryReader's size
                        // and the normalized bounding box.
                        let drawRect = CGRect(
                            x: normalizedBoundingBox.origin.x * size.width,
                            y: normalizedBoundingBox.origin.y * size.height,
                            width: normalizedBoundingBox.size.width * size.width,
                            height: normalizedBoundingBox.size.height * size.height
                        )

                        // Create a Path for the rectangle with a corner radius
                        let path = Path(roundedRect: drawRect, cornerRadius: 8)

                        // Draw the path with a red stroke
                        context.stroke(path, with: .color(.red), lineWidth: 3)
                    }
                    // .allowsHitTesting(false) prevents the overlay from capturing taps/gestures
                    // that might be intended for the underlying view.
                    .allowsHitTesting(false)
                }
            )
            .frame(width: 300, height: 200) // Give the image a fixed frame for demonstration
            .background(Color.secondary.opacity(0.1)) // A subtle background for the image frame
        }
    }
}

// Preview Provider
struct StaticObjectDetectionView_Previews: PreviewProvider {
    static var previews: some View {
        StaticObjectDetectionView()
    }
}
