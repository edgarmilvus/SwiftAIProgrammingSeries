
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import MLX

func runExercise4() {
    print("--- Exercise 4: Gradient Computation and Simple Optimization Step ---")

    // MARK: - 1. Define a Simple Model and Loss Function
    // Trainable parameters for the quadratic model: a*x^2 + b*x + c
    // Initialized with `requiresGrad: true` to enable automatic differentiation.
    var a = MLXArray(0.5, requiresGrad: true)
    var b = MLXArray(1.0, requiresGrad: true)
    var c = MLXArray(0.0, requiresGrad: true)

    /// Defines the model's prediction function: `a * x^2 + b * x + c`.
    /// - Parameters:
    ///   - x: Input data.
    ///   - a, b, c: Model coefficients.
    /// - Returns: Predicted values.
    func predict(x: MLXArray, a: MLXArray, b: MLXArray, c: MLXArray) -> MLXArray {
        return a * MLX.square(x) + b * x + c
    }

    /// Defines the Mean Squared Error (MSE) loss function.
    /// - Parameters:
    ///   - predictions: Model's predicted values.
    ///   - targets: True target values.
    /// - Returns: The scalar MSE loss.
    func loss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        return MLX.mean(MLX.square(predictions - targets))
    }

    // MARK: - 2. Generate Dummy Data
    let numSamples = 100
    // Generate x_data linearly spaced from 0 to 10
    let x_data = MLXArray(0..<numSamples).asType(Float.self) / Float(numSamples) * 10.0
    // Generate y_data based on a known quadratic function with some noise
    let true_a: Float = 2.0
    let true_b: Float = 3.0
    let true_c: Float = 1.0
    let noise = MLXArray.randomNormal(shape: [numSamples]).asType(Float.self) * 0.5
    let y_data = true_a * MLX.square(x_data) + true_b * x_data + true_c + noise

    print("Initial parameters: a=\(a.item()), b=\(b.item()), c=\(c.item())")

    // Calculate and print initial loss
    var initialPredictions = predict(x: x_data, a: a, b: b, c: c)
    MLX.eval(initialPredictions) // Ensure predictions are computed
    var initialLoss = loss(predictions: initialPredictions, targets: y_data)
    MLX.eval(initialLoss) // Ensure loss is computed
    print("Initial Loss: \(initialLoss.item())")

    // MARK: - 3. Implement a Single Optimization Step
    let learningRate: Float = 0.01

    print("\nPerforming a single optimization step...")
    let gradientStepStartTime = CFAbsoluteTimeGetCurrent()

    // Use MLX.valueAndGradient to compute both the loss value and its gradients
    // with respect to the trainable parameters (a, b, c).
    // The closure takes the parameters as arguments and returns the loss.
    let (currentLoss, grads) = MLX.valueAndGradient(a, b, c) { a_val, b_val, c_val in
        let predictions = predict(x: x_data, a: a_val, b: b_val, c: c_val)
        return loss(predictions: predictions, targets: y_data)
    }

    // MLX.eval() is crucial here to force the computation of the loss and gradients
    // before attempting to access their values or use the gradients for updates.
    MLX.eval(currentLoss, grads)

    let gradientStepEndTime = CFAbsoluteTimeGetCurrent()
    print("Time taken for valueAndGradient: \(gradientStepEndTime - gradientStepStartTime) seconds")

    // Manual gradient descent update: parameter = parameter - learningRate * gradient
    // MLXArray is a value type, so these assignments create new MLXArray instances.
    a = a - learningRate * grads[a]!
    b = b - learningRate * grads[b]!
    c = c - learningRate * grads[c]!

    // Evaluate the updated parameters to ensure they are materialized if needed
    MLX.eval(a, b, c)

    // MARK: - 4. Verify Parameter Update
    print("\nParameters after one step: a=\(a.item()), b=\(b.item()), c=\(c.item())")

    // Calculate and print the new loss after the update
    let newPredictions = predict(x: x_data, a: a, b: b, c: c)
    MLX.eval(newPredictions) // Ensure predictions are computed
    let newLoss = loss(predictions: newPredictions, targets: y_data)
    MLX.eval(newLoss) // Ensure loss is computed
    print("Loss after one step: \(newLoss.item())")

    print("\n// Discussion: You should observe that the 'Loss after one step' is lower than the 'Initial Loss', and the parameters 'a', 'b', 'c' have adjusted towards the true values. The `MLX.valueAndGradient` function is the core of automatic differentiation in MLX. It efficiently computes the loss and its gradients with respect to all trainable parameters involved in the computation graph. Profiling this function gives insight into the computational cost of the backward pass, which is often the most intensive part of a training step.")
}

runExercise4()
