
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import GRDB

struct HybridSearchEngine {
    let dbPool: DatabasePool
    let alpha: Float // Weight for Semantic Search (0.0 to 1.0)
    
    init(dbPool: DatabasePool, alpha: Float = 0.5) {
        self.dbPool = dbPool
        self.alpha = alpha
    }
    
    func search(queryText: String, queryEmbedding: [Float]) async throws -> [Note] {
        // 1. Perform FTS5 Search (Keyword Precision)
        // We fetch the ID and the BM25 score
        let keywordResults = try await dbPool.read { db in
            try Row.fetchAll(db, sql: """
                SELECT rowid, bm25(notes_fts) as score 
                FROM notes_fts 
                WHERE notes_fts MATCH ?
                """, arguments: [queryText])
        }
        
        // 2. Perform Vector Search (Semantic Recall)
        // (Using the logic from Exercise 2)
        let semanticResults = try await fetchSemanticScores(queryEmbedding)
        
        // 3. Hybrid Scoring (Weighted Scoring Approach)
        // We must normalize scores because BM25 and Cosine are on different scales.
        // For this implementation, we'll use a simplified normalization.
        
        var finalScores: [Int64: Float] = [:]
        
        // Process Keyword Scores
        for row in keywordResults {
            let id: Int64 = row[0]
            let bm25: Double = row[1]
            // Normalize BM25 (which is usually negative, higher is better)
            // Here we convert it to a 0-1 scale for simplicity
            let normalizedKeyword = Float(abs(bm25) / (abs(bm25) + 1.0)) 
            finalScores[id] = (1.0 - alpha) * normalizedKeyword
        }
        
        // Process Semantic Scores
        for (note, similarity) in semanticResults {
            guard let id = note.id else { continue }
            let score = alpha * similarity
            finalScores[id, default: 0] += score
        }
        
        // 4. Sort and Fetch final Note objects
        let sortedIds = finalScores.sorted { $0.value > $1.value }.map { $0.key }
        
        return try await dbPool.read { db in
            try Note.filter(sortedIds.contains(Note.Columns.id))
                .order(sortedIds.map { Note.Columns.id == $0 ? 0 : 1 }) // Keep order
                .fetchAll(db)
        }
    }
    
    private func fetchSemanticScores(_ embedding: [Float]) async throws -> [(Note, Float)] {
        // Placeholder: In real implementation, this calls the logic from Exercise 2
        return [] 
    }
}
