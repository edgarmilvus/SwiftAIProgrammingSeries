
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import AppIntents
import Foundation
import SwiftUI // Required for OpenAppAction and potentially custom views

// MARK: - 1. Simulate Contacts & AppEntity

struct ContactEntity: AppEntity, Identifiable {
    let id: String
    let name: String

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Contact"
    static var defaultQuery = ContactQuery() // Links to the query provider for dynamic resolution

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(name)")
    }
}

struct ContactQuery: EntityQuery {
    func entities(for identifiers: [String]) async throws -> [ContactEntity] {
        return ContactManager.shared.allContacts().filter { identifiers.contains($0.id) }
    }

    func suggestedEntities() async throws -> [ContactEntity] {
        return ContactManager.shared.allContacts()
    }

    func defaultResult() async -> ContactEntity? {
        return ContactManager.shared.allContacts().first
    }
}

class ContactManager {
    static let shared = ContactManager()
    private var contacts: [ContactEntity] = [
        ContactEntity(id: "john_doe", name: "John Doe"),
        ContactEntity(id: "jane_smith", name: "Jane Smith"),
        ContactEntity(id: "alice_williams", name: "Alice Williams"),
        ContactEntity(id: "bob_jones", name: "Bob Jones")
    ]

    func allContacts() -> [ContactEntity] {
        return contacts
    }
}

// MARK: - 2. AppEnum for Event Type (Optional, but good for structured input)

enum EventType: String, AppEnum, CaseIterable {
    case birthday = "Birthday Party"
    case meeting = "Work Meeting"
    case dinner = "Dinner Gathering"
    case casual = "Casual Hangout"

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Event Type"
    static var caseDisplayRepresentations: [EventType: DisplayRepresentation] = [
        .birthday: "Birthday Party",
        .meeting: "Work Meeting",
        .dinner: "Dinner Gathering",
        .casual: "Casual Hangout"
    ]
}

// MARK: - 3. AppIntent with Multi-Step Input and App Integration

@available(iOS 18.0, macOS 15.0, *)
struct PlanEventIntent: AppIntent {
    static var title: LocalizedStringResource = "Plan an Event"
    static var description: IntentDescription = IntentDescription("Helps plan an event, including AI-suggested attendees and locations.", category: .productivity)

    // Event Name is optional initially, allowing us to prompt for it if not provided.
    @Parameter(title: "Event Name", description: "The name of the event.")
    var eventName: String?

    @Parameter(title: "Event Type", description: "The type of event.", default: .casual)
    var eventType: EventType

    // Attendees parameter is an array of AppEntities, automatically using ContactQuery for suggestions.
    @Parameter(title: "Attendees", description: "Who will be attending the event?")
    var attendees: [ContactEntity]?

    init() {}
    init(eventName: String?, eventType: EventType, attendees: [ContactEntity]?) {
        self.eventName = eventName
        self.eventType = eventType
        self.attendees = attendees
    }

    func perform() async throws -> some IntentResult {
        // Step 1: Request Event Name if it hasn't been provided by Siri or Shortcuts.
        let resolvedEventName = try await $eventName.requestValue("What is the name of the event?")

        // Step 2: Request Attendees dynamically. The system will use ContactQuery for suggestions,
        // allowing the user to select multiple contacts.
        let resolvedAttendees = try await $attendees.requestValue("Who should be invited to '\(resolvedEventName)'?")

        // Simulate AI location suggestion based on event type.
        let suggestedLocation: String
        switch eventType {
        case .birthday:
            suggestedLocation = "Local Party Hall"
        case .meeting:
            suggestedLocation = "Conference Room"
        case .dinner:
            suggestedLocation = "Popular Restaurant"
        case .casual:
            suggestedLocation = "Local Cafe"
        }

        let attendeesList = resolvedAttendees.map { $0.name }.joined(separator: ", ")
        let dialogMessage = "Planning '\(resolvedEventName)' (\(eventType.rawValue)) with \(attendeesList.isEmpty ? "no specific attendees" : attendeesList) at a suggested location: \(suggestedLocation)."

        return .result(dialog: dialogMessage) {
            // Offer to open the app for further customization.
            // In a real app, you would typically pass event details as URL parameters
            // to a specific view in your app for deep linking.
            OpenAppAction(title: "Open EventBuddy to Customize")
        }
    }
}

// MARK: - 4. AppShortcutsProvider

@available(iOS 18.0, macOS 15.0, *)
struct EventBuddyAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            // Provide a default intent for initial setup in the Shortcuts app.
            // eventName is optional, so we can pass nil to allow the intent to prompt for it.
            intent: PlanEventIntent(eventName: nil, eventType: .casual, attendees: []),
            phrases: [
                "Plan an event in \(.applicationName)",
                "Schedule a \(.parameter(\.$eventType)) \(.parameter(\.$eventName)) with \(.parameter(\.$attendees)) in \(.applicationName)"
            ],
            shortTitle: "Plan Event",
            systemImageName: "calendar.badge.plus"
        )
    }
}
