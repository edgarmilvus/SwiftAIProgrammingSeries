
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Vision
import ARKit
import RealityKit
import Combine

/// Errors specific to the Spatial Pose Estimation pipeline.
enum PoseEstimationError: Error {
    case visionRequestFailed(Error)
    case depthMappingFailed
    case insufficientLandmarks(String)
    case coordinateSystemMismatch
}

/// A thread-safe representation of a 3D landmark in the ARKit world.
struct SpatialLandmark: Sendable {
    let identifier: VNRecognizedLandmarkRole
    let position: SIMD3<Float> // X, Y, Z in meters
    let confidence: Float
}

/// An actor responsible for high-frequency pose estimation and 3D mapping.
/// Using an actor ensures that the heavy Vision and Math computations 
/// do not block the Main Actor (UI/Rendering).
@available(visionOS 2.0, *)
actor SpatialPoseProcessor {
    
    private let visionRequest = VNDetectHumanBodyPoseRequest()
    private var isProcessing = false
    
    /// Processes a single ARKit frame to extract 3D pose data.
    /// - Parameters:
    ///   - pixelBuffer: The current video frame from the ARKit session.
    ///   - sceneDepth: The depth information from the ARKit scene reconstruction.
    ///   - cameraTransform: The current transform of the camera.
    /// - Returns: An array of spatially localized landmarks.
    func processFrame(
        pixelBuffer: CVPixelBuffer,
        sceneDepth: ARFrame,
        cameraTransform: simd_float4x4
    ) async throws -> [SpatialLandmark] {
        
        // Prevent overlapping processing tasks to maintain real-time throughput
        guard !isProcessing else { return [] }
        isProcessing = true
        defer { isProcessing = false }
        
        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
            
            do {
                try handler.perform([visionRequest])
                
                guard let observation = visionRequest.results?.first else {
                    continuation.resume(returning: [])
                    return
                }
                
                // Extract and localize landmarks
                let landmarks = try localizeLandmarks(
                    observation: observation,
                    depthFrame: sceneDepth,
                    cameraTransform: cameraTransform
                )
                
                continuation.resume(returning: landmarks)
            } catch {
                continuation.resume(throwing: PoseEstimationError.visionRequestFailed(error))
            }
        }
    }
    
    /// Maps 2D Vision landmarks to 3D ARKit coordinates using depth data.
    private func localizeLandmarks(
        observation: VNHumanBodyPoseObservation,
        depthFrame: ARFrame,
        cameraTransform: simd_float4x4
    ) throws -> [SpatialLandmark] {
        
        var spatialLandmarks: [SpatialLandmark] = []
        
        // We iterate through required roles for fitness (e.g., Hip, Knee, Ankle)
        let roles: [VNRecognizedLandmarkRole] = [.hip, .knee, .ankle]
        
        for role in roles {
            guard let point = try? observation.recognizedPoint(role),
                  point.confidence > 0.5 else { continue }
            
            // 1. Convert normalized Vision coordinates (0-1) to Image Space coordinates
            // Vision uses a coordinate system where (0,0) is bottom-left.
            let imagePoint = CGPoint(x: CGFloat(point.location.x), y: CGFloat(point.location.y))
            
            // 2. Perform Raycasting to find the 3D position
            // In a production environment, we use the ARFrame's depth map or 
            // raycast against the scene reconstruction mesh.
            if let worldPosition = performSpatialRaycast(
                from: imagePoint,
                in: depthFrame,
                cameraTransform: cameraTransform
            ) {
                spatialLandmarks.append(SpatialLandmark(
                    identifier: role,
                    position: worldPosition,
                    confidence: point.confidence
                ))
            }
        }
        
        return spatialLandmarks
    }
    
    /// Simulates or performs a raycast into the ARKit depth buffer.
    /// In visionOS, this leverages the Scene Reconstruction API.
    private func performSpatialRaycast(
        from point: CGPoint,
        in frame: ARFrame,
        cameraTransform: simd_float4x4
    ) -> SIMD3<Float>? {
        // Logic:
        // 1. Convert 2D point to a 3D ray direction in camera space.
        // 2. Transform ray direction to world space using cameraTransform.
        // 3. Intersect ray with the ARMeshAnchor or Depth Map.
        
        // Placeholder for the complex ray-mesh intersection logic
        // In actual implementation, this uses: frame.raycast(from: point, ...)
        return SIMD3<Float>(Float(point.x), Float(point.y), 1.5) // Mock depth of 1.5m
    }
}

/// The Analysis Engine responsible for calculating joint angles and form correctness.
struct FormAnalysisEngine {
    
    /// Calculates the angle between three 3D points (e.g., Hip -> Knee -> Ankle).
    /// - Parameters:
    ///   - a: The proximal point (e.g., Hip)
    ///   - b: The vertex point (e.g., Knee)
    ///   - c: The distal point (e.g., Ankle)
    /// - Returns: The angle in degrees.
    static func calculateAngle(a: SIMD3<Float>, b: SIMD3<Float>, c: SIMD3<Float>) -> Float {
        let v1 = a - b
        let v2 = c - b
        
        let dotProduct = simd_dot(v1, v2)
        let magnitudeProduct = simd_length(v1) * simd_length(v2)
        
        guard magnitudeProduct > 0 else { return 0 }
        
        let cosTheta = dotProduct / magnitudeProduct
        // Clamp to avoid NaN from floating point precision errors
        let angleRad = acos(max(-1, min(1, cosTheta)))
        
        return angleRad * (180.0 / .pi)
    }
    
    /// Evaluates if a squat is deep enough based on a target angle.
    /// - Parameter kneeAngle: The current calculated knee angle.
    /// - Returns: A boolean indicating if the form is correct.
    static func isSquatDepthCorrect(kneeAngle: Float, targetThreshold: Float = 90.0) -> Bool {
        return kneeAngle <= targetThreshold
    }
}

/// A RealityKit Component that provides visual feedback in the spatial scene.
@available(visionOS 2.0, *)
class FormFeedbackComponent: Component {
    var isCorrect: Bool = true
    var currentAngle: Float = 0.0
}

/// The main View Model managing the integration of Vision, ARKit, and RealityKit.
@MainActor
class SpatialFitnessViewModel: ObservableObject {
    
    @Published var currentStatus: String = "Initializing..."
    @Published var isFormCorrect: Bool = true
    
    private let poseProcessor = SpatialPoseProcessor()
    private var cancellables = Set<AnyCancellable>()
    
    /// Entry point for the frame update loop.
    /// Called by the ARKit session delegate.
    func update(frame: ARFrame) async {
        do {
            let landmarks = try await poseProcessor.processFrame(
                pixelBuffer: frame.capturedImage,
                depthFrame: frame,
                cameraTransform: frame.camera.transform
            )
            
            try await analyzePose(landmarks: landmarks)
            
        } catch {
            print("Pose Processing Error: \(error)")
            self.currentStatus = "Error: \(error.localizedDescription)"
        }
    }
    
    private func analyzePose(landmarks: [SpatialLandmark]) async throws {
        // Extract specific landmarks for knee angle calculation
        let hip = landmarks.first { $0.identifier == .hip }?.position
        let knee = landmarks.first { $0.identifier == .knee }?.position
        let ankle = landmarks.first { $0.identifier == .ankle }?.position
        
        guard let h = hip, let k = knee, let a = ankle else {
            self.currentStatus = "Positioning..."
            return
        }
        
        let angle = FormAnalysisEngine.calculateAngle(a: h, b: k, c: a)
        let correct = FormAnalysisEngine.isSquatDepthThreshold(kneeAngle: angle)
        
        // Update UI on the Main Actor
        self.isFormCorrect = correct
        self.currentStatus = String(format: "Knee Angle: %.1f°", angle)
    }
}

// Extension for the mock logic used in the example
extension FormAnalysisEngine {
    static func isSquatDepthThreshold(kneeAngle: Float) -> Bool {
        return kneeAngle < 100.0 // Example: Squat is deep enough if angle < 100 deg
    }
}
