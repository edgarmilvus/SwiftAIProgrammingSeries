
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents a single piece of information retrieved from the database.
/// Conforms to Sendable so it can safely move between background tasks and the UI.
struct DocumentChunk: Sendable, Identifiable {
    let id: UUID
    let text: String
    let score: Float // Similarity score
}

/// The VectorStore actor manages the high-dimensional index.
/// Actor isolation prevents data races during concurrent search/write operations.
actor VectorStore {
    private var index: [UUID: [Float]] = [:]
    private var documents: [UUID: String] = [:]

    /// Performs a similarity search.
    /// - Parameter queryVector: The embedding of the user's query.
    /// - Returns: An array of retrieved chunks.
    func search(queryVector: [Float], k: Int) async -> [DocumentChunk] {
        // In a real implementation, this would use Cosine Similarity 
        // or a specialized library like Faiss or an Apple Accelerate implementation.
        // For now, we represent the concept.
        return [] 
    }

    /// Adds a new document to the index.
    func insert(text: String, vector: [Float]) async {
        let id = UUID()
        index[id] = vector
        documents[id] = text
    }
}

/// The RAGEngine orchestrates the retrieval and augmentation process.
@Observable
@available(iOS 18.0, *)
final class RAGEngine {
    private let vectorStore: VectorStore
    private let embeddingService: EmbeddingService // Hypothetical service
    private let llmService: LLMService             // From Chapter 8
    
    var isProcessing: Bool = false
    var lastResponse: String = ""

    init(vectorStore: VectorStore, embeddingService: EmbeddingService, llmService: LLMService) {
        self.vectorStore = vectorStore
        self.embeddingService = embeddingService
        self.llmService = llmService
    }

    /// The core RAG workflow.
    func answer(question: String) async {
        // 1. Update UI state on the MainActor via @Observable
        await MainActor.run { isProcessing = true }

        do {
            // 2. Retrieval Phase: Convert question to embedding
            let queryVector = try await embeddingService.embed(text: question)

            // 3. Retrieval Phase: Search the vector store
            let chunks = await vectorStore.search(queryVector: queryVector, k: 3)

            // 4. Augmentation Phase: Construct the prompt (Context Injection)
            let contextString = chunks.map { $0.text }.joined(separator: "\n\n")
            let augmentedPrompt = """
            Use the following context to answer the question.
            
            CONTEXT:
            \(contextString)
            
            QUESTION:
            \(question)
            """

            // 5. Generation Phase: Call the LLM
            let response = try await llmService.generate(prompt: augmentedPrompt)

            await MainActor.run {
                self.lastResponse = response
                self.isProcessing = false
            }
        } catch {
            await MainActor.run {
                self.lastResponse = "Error: \(error.localizedDescription)"
                self.isProcessing = false
            }
        }
    }
}
