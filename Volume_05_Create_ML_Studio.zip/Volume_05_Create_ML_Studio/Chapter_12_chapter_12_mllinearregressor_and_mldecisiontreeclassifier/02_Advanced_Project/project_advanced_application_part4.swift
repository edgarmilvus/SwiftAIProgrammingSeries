
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import Combine // Required for ObservableObject

/// Custom errors for the UtilityBillPredictor.
enum UtilityBillPredictorError: Error, LocalizedError {
    case modelTrainingFailed(String)
    case dataTableCreationFailed(String)
    case predictionFailed(String)
    case modelNotTrained
    case invalidPredictionInput

    var errorDescription: String? {
        switch self {
        case .modelTrainingFailed(let message):
            return "Model training failed: \(message)"
        case .dataTableCreationFailed(let message):
            return "Failed to create data table: \(message)"
        case .predictionFailed(let message):
            return "Prediction failed: \(message)"
        case .modelNotTrained:
            return "Prediction model is not trained yet."
        case .invalidPredictionInput:
            return "Invalid input data for prediction."
        }
    }
}

/// A class responsible for training an MLLinearRegressor model and making utility bill predictions.
/// It's an `ObservableObject` to facilitate integration with SwiftUI views.
@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 2.0, *)
final class UtilityBillPredictor: ObservableObject {
    @Published var isLoading: Bool = false // Indicates if a long-running operation is in progress
    @Published var predictionResult: Double? // Stores the last prediction result
    @Published var errorMessage: String? // Stores any error messages for UI display

    private var trainedModel: MLLinearRegressor? // The trained linear regression model

    /// Initializes the predictor.
    init() {}

    /// Trains the `MLLinearRegressor` model using historical utility bill data.
    /// This is an asynchronous operation to prevent blocking the UI.
    /// - Parameter historicalData: An array of `UtilityBillData` for training.
    /// - Throws: `UtilityBillPredictorError` if training fails at any stage.
    func trainModel(historicalData: [UtilityBillData]) async throws {
        await MainActor.run { // Update UI state on the main actor
            self.isLoading = true
            self.errorMessage = nil
            self.predictionResult = nil
        }

        do {
            // 1. Prepare the MLDataTable from raw historical data
            let dataTable = try prepareDataTable(from: historicalData)

            // 2. Define features and target column
            let featureColumns = [
                "month",
                "avgTemperatureC",
                "householdOccupants",
                "previousBillAmount"
            ]
            let targetColumn = "actualBillAmount"

            // 3. Train the MLLinearRegressor model
            // MLLinearRegressor finds a linear relationship between input features and the target.
            let model = try MLLinearRegressor(
                trainingData: dataTable,
                featureColumns: featureColumns,
                targetColumn: targetColumn
            )
            self.trainedModel = model

            // Optional: Evaluate the model (for pedagogical depth)
            // In a real app, you'd split data into training and testing sets.
            // let evaluationMetrics = model.evaluation(on: testingDataTable)
            // print("Model Evaluation RMSE: \(evaluationMetrics.rootMeanSquaredError)")

            print("MLLinearRegressor model trained successfully.")

            // Optional: Export the model to a Core ML format for deployment
            // This allows the model to be used efficiently in a deployed app.
            // let fileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("UtilityBillPredictor.mlmodel")
            // try model.write(to: fileURL)
            // print("Model exported to: \(fileURL.path)")

        } catch let mlError as MLModelError {
            // Specific CreateML errors
            throw UtilityBillPredictorError.modelTrainingFailed("CreateML error: \(mlError.localizedDescription)")
        } catch {
            // General errors during data table creation or training
            throw UtilityBillPredictorError.modelTrainingFailed(error.localizedDescription)
        } finally {
            await MainActor.run {
                self.isLoading = false
            }
        }
    }

    /// Makes a prediction for a future utility bill based on new input data.
    /// - Parameter predictionData: A `UtilityBillData` object containing features for the prediction.
    ///                             Note: `actualBillAmount` is ignored as it's the target.
    /// - Returns: The predicted utility bill amount as a `Double`.
    /// - Throws: `UtilityBillPredictorError` if the model is not trained or prediction fails.
    func predictBill(for predictionData: UtilityBillData) async throws -> Double {
        await MainActor.run { // Update UI state on the main actor
            self.isLoading = true
            self.errorMessage = nil
        }

        guard let model = trainedModel else {
            await MainActor.run { self.isLoading = false }
            throw UtilityBillPredictorError.modelNotTrained
        }

        do {
            // 1. Prepare prediction input as an MLDataTable
            // Only include features used for training.
            let inputDictionary: [String: MLDataValueConvertible] = [
                "month": [predictionData.month],
                "avgTemperatureC": [predictionData.avgTemperatureC],
                "householdOccupants": [predictionData.householdOccupants],
                "previousBillAmount": [predictionData.previousBillAmount]
            ]
            let predictionInput = try MLDataTable(dictionary: inputDictionary)

            // 2. Make the prediction
            let predictions = try model.predictions(from: predictionInput)

            // 3. Extract the predicted value
            guard let predictedBill = predictions["actualBillAmount"]?.doubleValue else {
                throw UtilityBillPredictorError.predictionFailed("Could not extract prediction from model output.")
            }

            await MainActor.run {
                self.predictionResult = predictedBill
            }
            return predictedBill

        } catch let mlError as MLModelError {
            throw UtilityBillPredictorError.predictionFailed("CreateML prediction error: \(mlError.localizedDescription)")
        } catch {
            throw UtilityBillPredictorError.predictionFailed(error.localizedDescription)
        } finally {
            await MainActor.run {
                self.isLoading = false
            }
        }
    }
}
