
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AVFoundation
import CoreML
import Combine // For ObservableObject and @Published

// Assume LoudNoiseDetector.mlmodel is added to the project.
// This model should have "LoudNoise" and "BackgroundNoise" classes.
// Input format: MLMultiArray of shape [1, 16000] (1 second @ 16kHz, mono, Float32).

// MARK: - Core ML Model Wrapper (similar to Exercise 1, adapted for LoudNoiseDetector)

struct LoudNoiseDetectorInput {
    let input: MLMultiArray
}

struct LoudNoiseDetectorOutput {
    let label: String
    let labelProbability: [String : Double]
}

final class LoudNoiseClassifierModel {
    private let model: LoudNoiseDetector
    let modelInputLength: Int = 16000 // e.g., 1 second * 16000 samples/sec
    let expectedSampleRate: Double = 16000.0

    init() throws {
        let configuration = MLModelConfiguration()
        self.model = try LoudNoiseDetector(configuration: configuration)
    }

    func predict(input: LoudNoiseDetectorInput) throws -> LoudNoiseDetectorOutput {
        let prediction = try model.prediction(input: input.input)
        return LoudNoiseDetectorOutput(label: prediction.label, labelProbability: prediction.labelProbability)
    }
    
    // Helper to get the expected audio format for the model (mono, Float32, 16kHz)
    var audioFormat: AVAudioFormat {
        return AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: expectedSampleRate, channels: 1, interleaved: false)!
    }
}

// MARK: - Audio Processing & Classification Service

class QuietZoneMonitor: ObservableObject {
    @Published var isLoudNoiseDetected: Bool = false
    @Published var detectionConfidence: Double = 0.0
    @Published var permissionGranted: Bool = false
    @Published var isMonitoring: Bool = false
    @Published var errorMessage: String?

    private let audioEngine = AVAudioEngine()
    private var classifier: LoudNoiseClassifierModel?
    private let audioProcessingQueue = DispatchQueue(label: "com.example.quietZoneAudioProcessing", qos: .userInitiated)
    
    private let confidenceThreshold: Double = 0.85 // Adjustable threshold
    private let quietZoneRevertDelay: TimeInterval = 3.0 // Seconds after last detection to revert to quiet
    private var revertTimer: Timer?

    // Buffer to accumulate audio for classification
    private var audioBuffer: AVAudioPCMBuffer?
    private let bufferCapacity: AVAudioFrameCount // Capacity for one model input (e.g., 1 second)

    init() {
        do {
            classifier = try LoudNoiseClassifierModel()
            bufferCapacity = AVAudioFrameCount(classifier!.modelInputLength)
            audioBuffer = AVAudioPCMBuffer(pcmFormat: classifier!.audioFormat, frameCapacity: bufferCapacity)
            audioBuffer?.frameLength = 0 // Start empty
        } catch {
            errorMessage = "Failed to load ML model: \(error.localizedDescription)"
            print("Error loading model: \(error)")
        }
    }
    
    deinit {
        stopMonitoring()
        revertTimer?.invalidate()
    }

    func requestMicrophonePermission() async {
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        switch status {
        case .authorized:
            permissionGranted = true
        case .notDetermined:
            await AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    self?.permissionGranted = granted
                    if !granted {
                        self?.errorMessage = "Microphone permission denied. Please enable it in System Settings."
                    }
                }
            }
        case .denied, .restricted:
            permissionGranted = false
            errorMessage = "Microphone permission denied. Please enable it in System Settings."
        @unknown default:
            permissionGranted = false
            errorMessage = "Unknown microphone permission status."
        }
    }

    func startMonitoring() {
        guard permissionGranted, classifier != nil else {
            errorMessage = "Microphone permission not granted or model not loaded."
            return
        }

        let inputNode = audioEngine.inputNode
        let bus = 0 // Default input bus
        
        // Configure the input format to match the model's expected sample rate and channel count
        let inputFormat = inputNode.inputFormat(forBus: bus)
        let outputFormat = classifier!.audioFormat // Mono, Float32, 16kHz

        if inputFormat.sampleRate != outputFormat.sampleRate || inputFormat.channelCount != outputFormat.channelCount {
            // Attach a mixer to handle format conversion
            audioEngine.attach(AVAudioMixerNode())
            let mixer = audioEngine.mainMixerNode
            audioEngine.connect(inputNode, to: mixer, format: inputFormat)
            audioEngine.connect(mixer, to: audioEngine.outputNode, format: outputFormat)
            
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(outputFormat.sampleRate / 10), format: outputFormat) { [weak self] buffer, time in
                self?.processAudioBuffer(buffer: buffer)
            }
        } else {
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(inputFormat.sampleRate / 10), format: inputFormat) { [weak self] buffer, time in
                self?.processAudioBuffer(buffer: buffer)
            }
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isMonitoring = true
            errorMessage = nil
            // Invalidate any existing timer when starting
            revertTimer?.invalidate()
            revertTimer = nil
            // Ensure initial state is quiet
            DispatchQueue.main.async {
                self.isLoudNoiseDetected = false
                self.detectionConfidence = 0.0
            }
        } catch {
            errorMessage = "Error starting audio engine: \(error.localizedDescription)"
            print("Error starting audio engine: \(error)")
        }
    }

    func stopMonitoring() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        isMonitoring = false
        audioBuffer?.frameLength = 0 // Clear buffer on stop
        revertTimer?.invalidate()
        revertTimer = nil
        DispatchQueue.main.async {
            self.isLoudNoiseDetected = false
            self.detectionConfidence = 0.0
        }
    }

    private func processAudioBuffer(buffer: AVAudioPCMBuffer) {
        audioProcessingQueue.async { [weak self] in
            guard let self = self, let classifier = self.classifier else { return }

            self.audioBuffer?.append(buffer, startingFrame: 0, frameCount: buffer.frameLength)

            if let currentBuffer = self.audioBuffer, currentBuffer.frameLength >= self.bufferCapacity {
                guard let multiArray = currentBuffer.toMLMultiArray(
                    modelInputLength: classifier.modelInputLength,
                    targetSampleRate: classifier.expectedSampleRate
                ) else {
                    print("Failed to convert buffer to MLMultiArray.")
                    currentBuffer.frameLength = 0
                    return
                }

                do {
                    let prediction = try classifier.predict(input: LoudNoiseDetectorInput(input: multiArray))
                    DispatchQueue.main.async {
                        if prediction.label == "LoudNoise", let confidence = prediction.labelProbability["LoudNoise"], confidence >= self.confidenceThreshold {
                            self.isLoudNoiseDetected = true
                            self.detectionConfidence = confidence
                            self.resetRevertTimer() // Reset timer on new detection
                        } else {
                            // If not a loud noise or below threshold, ensure timer is running to revert
                            if self.isLoudNoiseDetected && self.revertTimer == nil {
                                self.startRevertTimer()
                            }
                        }
                    }
                } catch {
                    print("Error during prediction: \(error)")
                }
                
                currentBuffer.frameLength = 0
            }
        }
    }
    
    private func resetRevertTimer() {
        revertTimer?.invalidate()
        revertTimer = nil // Invalidate and clear any existing timer
        startRevertTimer()
    }

    private func startRevertTimer() {
        // Start a new timer only if one isn't already active
        guard revertTimer == nil else { return }
        
        revertTimer = Timer.scheduledTimer(withTimeInterval: quietZoneRevertDelay, repeats: false) { [weak self] _ in
            DispatchQueue.main.async {
                self?.isLoudNoiseDetected = false
                self?.detectionConfidence = 0.0
                self?.revertTimer = nil // Timer has fired, so clear it
            }
        }
        // Ensure timer runs on the main run loop
        RunLoop.main.add(revertTimer!, forMode: .common)
    }
}

// MARK: - Helper Extension for AVAudioPCMBuffer to MLMultiArray Conversion (Same as Exercise 1)
extension AVAudioPCMBuffer {
    func toMLMultiArray(modelInputLength: Int, targetSampleRate: Double) -> MLMultiArray? {
        guard let floatChannelData = floatChannelData else { return nil }
        guard format.channelCount == 1 else { return nil }
        guard format.sampleRate == targetSampleRate else { return nil }

        let frameCount = Int(frameLength)
        guard frameCount >= modelInputLength else { return nil }

        do {
            let multiArray = try MLMultiArray(shape: [1, NSNumber(value: modelInputLength)], dataType: .float32)
            let bufferPointer = UnsafeMutableBufferPointer(start: floatChannelData[0], count: frameCount)

            for i in 0..<modelInputLength {
                multiArray[i] = NSNumber(value: bufferPointer[i])
            }
            return multiArray
        } catch {
            print("Failed to create MLMultiArray: \(error)")
            return nil
        }
    }
}

// MARK: - SwiftUI View (macOS specific layout)

struct QuietZoneView: View {
    @StateObject private var monitor = QuietZoneMonitor()

    var body: some View {
        VStack {
            Text("Quiet Zone Enforcer")
                .font(.largeTitle)
                .padding()

            if let errorMessage = monitor.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }

            if monitor.permissionGranted {
                Text(monitor.isMonitoring ? "Monitoring Ambient Sound..." : "Ready to Monitor")
                    .font(.headline)
                    .padding()

                Button(action: {
                    if monitor.isMonitoring {
                        monitor.stopMonitoring()
                    } else {
                        monitor.startMonitoring()
                    }
                }) {
                    Text(monitor.isMonitoring ? "Stop Monitoring" : "Start Monitoring")
                        .font(.title2)
                        .padding()
                        .background(monitor.isMonitoring ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()

                Spacer()

                VStack {
                    Text(monitor.isLoudNoiseDetected ? "LOUD NOISE DETECTED!" : "Quiet Zone")
                        .font(.system(size: 60, weight: .bold, design: .rounded))
                        .foregroundColor(monitor.isLoudNoiseDetected ? .white : .green)
                        .padding()
                    
                    if monitor.isLoudNoiseDetected {
                        Text(String(format: "Confidence: %.2f%%", monitor.detectionConfidence * 100))
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(monitor.isLoudNoiseDetected ? Color.red : Color.clear)
                .cornerRadius(20)
                .animation(.easeInOut(duration: 0.3), value: monitor.isLoudNoiseDetected)
                
                Spacer()

            } else {
                Text("Microphone access is required to monitor the quiet zone.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                Button("Request Microphone Access") {
                    Task {
                        await monitor.requestMicrophonePermission()
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .onAppear {
            Task {
                await monitor.requestMicrophonePermission()
            }
        }
        .padding()
        // Ensure the view takes up the full window area for macOS
        .frame(minWidth: 400, minHeight: 300)
    }
}

// MARK: - App Entry Point (for macOS)
/*
@main
struct QuietZoneEnforcerApp: App {
    var body: some Scene {
        WindowGroup {
            QuietZoneView()
        }
        // Add info.plist entry for NSMicrophoneUsageDescription
    }
}
*/
