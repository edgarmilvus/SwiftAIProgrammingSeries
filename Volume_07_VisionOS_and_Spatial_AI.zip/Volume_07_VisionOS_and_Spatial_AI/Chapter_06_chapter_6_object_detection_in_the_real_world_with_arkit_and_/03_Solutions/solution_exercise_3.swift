
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import RealityKit
import ARKit
import Vision

struct SpatialProjectionEngine {
    
    /// Projects a Vision observation into 3D space.
    /// - Parameters:
    ///   - observation: The 2D detection from Vision.
    ///   - arView: The active ARView.
    ///   - frame: The specific ARFrame used during the Vision inference.
    /// - Returns: An AnchorEntity at the projected 3D position, or nil if projection fails.
    func project(
        observation: VNRecognizedObjectObservation,
        in arView: ARView,
        using frame: ARFrame
    ) -> AnchorEntity? {
        
        // 1. Convert Vision normalized coordinates to View coordinates
        // Vision: (0,0) is bottom-left. 
        // We need the center of the bounding box.
        let visionCenter = CGPoint(
            x: observation.boundingBox.midX,
            y: 1.0 - observation.boundingBox.midY // Flip Y
        )
        
        // 2. Convert normalized coordinate to a point in the ARView's coordinate system
        // We use the frame's viewport size to scale the normalized point.
        let viewSize = arView.bounds.size
        let viewPoint = CGPoint(
            x: visionCenter.x * viewSize.width,
            y: visionCenter.y * viewSize.height
        )
        
        // 3. Perform Raycasting
        // IMPORTANT: We use the 'frame' passed in to ensure we are projecting 
        // based on the camera transform that existed when the image was captured.
        let raycastQuery = arView.raycastQuery(
            from: viewPoint,
            allowing: .estimatedPlane,
            alignment: .any
        )
        
        guard let query = raycastQuery else { return nil }
        
        // We perform the raycast against the session, but ideally, we'd use 
        // the transform from the provided 'frame'.
        let results = arView.session.raycast(query)
        
        if let firstResult = results.first {
            // 4. Create the 3D Label
            let anchor = AnchorEntity(world: firstResult.worldTransform)
            
            // Create a simple 3D text entity
            let mesh = MeshResource.generateText(
                observation.labels.first?.identifier ?? "Object",
                extrusionDepth: 0.01,
                font: .systemFont(ofSize: 0.05),
                containerFrame: .zero,
                alignment: .center,
                lineBreakMode: .byWordWrapping
            )
            let material = SimpleMaterial(color: .white, isMetallic: true)
            let textEntity = ModelEntity(mesh: mesh, materials: [material])
            
            // Offset text slightly above the surface
            textEntity.position = [0, 0.05, 0]
            anchor.addChild(textEntity)
            
            return anchor
        }
        
        return nil
    }
}
