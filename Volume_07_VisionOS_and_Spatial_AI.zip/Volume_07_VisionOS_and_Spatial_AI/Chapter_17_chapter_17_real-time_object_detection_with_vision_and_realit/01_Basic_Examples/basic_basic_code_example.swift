
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AVFoundation
import Vision
import RealityKit
import Combine

// MARK: - Models

/// Represents the detection result passed from the Vision engine to the UI/AR layer.
/// Conforming to Sendable ensures safe transfer across concurrency boundaries in Swift 6.
struct DetectionResult: Sendable {
    let boundingBox: CGRect
    let confidence: Float
}

// MARK: - Detection Engine

/// The `ObjectDetector` is responsible for the heavy lifting of image analysis.
/// It runs on a background actor to prevent blocking the Main Actor (UI thread).
@globalActor
actor DetectionActor {
    static let shared = DetectionActor()
}

@DetectionActor
class ObjectDetector: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    /// Callback to send results back to the MainActor for UI/AR updates.
    var onDetectionUpdate: (@MainActor (DetectionResult?) -> Void)?
    
    private var detectionRequest: VNDetectRectanglesRequest?
    private let sequenceQueue = DispatchQueue(label: "com.spatialai.detection.queue")

    override init() {
        super.init()
        setupVision()
    }

    /// Configures the Vision request specifically for rectangle detection.
    private func setupVision() {
        // We use VNDetectRectanglesRequest for this basic example.
        // In a production app, you might use a custom CoreML model via VNCoreMLRequest.
        detectionRequest = VNDetectRectanglesRequest()
        detectionRequest?.minimumAspectRatio = 0.2
        detectionRequest?.maximumObservations = 5
    }

    /// The delegate method called for every single frame captured by the camera.
    /// - Parameter sampleBuffer: The raw video frame data.
    /// - Parameter connection: The connection between the output and the session.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        
        do {
            // Perform the detection request synchronously on this background actor.
            try handler.perform([detectionRequest].compactMap { $0 })
            
            // Process the results
            if let observation = detectionRequest?.results?.first as? VNRectangleObservation {
                let result = DetectionResult(
                    boundingBox: observation.boundingBox,
                    confidence: observation.confidence
                )
                
                // Dispatch the result back to the MainActor for RealityKit interaction
                Task { @MainActor in
                    onDetectionUpdate?(result)
                }
            } else {
                Task { @MainActor in
                    onDetectionUpdate?(nil)
                }
            }
        } catch {
            print("Vision Error: \(error.localizedDescription)")
        }
    }
}

// MARK: - AR View Container

/// A SwiftUI wrapper for the RealityKit ARView.
struct ARViewContainer: UIViewRepresentable {
    @Binding var detection: DetectionResult?

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Add a basic lighting setup
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        arView.session.run(config)
        
        // Create a container for our detection overlays
        let anchor = AnchorEntity(world: .zero)
        anchor.name = "DetectionAnchor"
        arView.scene.addAnchor(anchor)
        
        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        guard let anchor = uiView.scene.findEntity(named: "DetectionAnchor") else { return }
        
        // Remove old overlays to prevent memory bloat
        anchor.children.removeAll()

        // If a detection exists, create a 3D overlay
        if let detection = detection {
            createOverlay(on: anchor, for: detection, in: uiView)
        }
    }

    /// Creates a 3D wireframe box representing the detected object.
    /// - Parameters:
    ///   - anchor: The parent entity in the RealityKit scene.
    ///   - detection: The 2D detection data.
    ///   - arView: The current ARView for coordinate projection.
    private func createOverlay(on anchor: Entity, for detection: DetectionResult, in arView: ARView) {
        // 1. Convert Normalized Vision Coordinates to View Coordinates
        // Vision (0,0 is bottom-left) -> UIKit (0,0 is top-left)
        let viewSize = arView.bounds.size
        let rectInView = CGRect(
            x: detection.boundingBox.origin.x * viewSize.width,
            y: (1 - detection.boundingBox.origin.y - detection.boundingBox.height) * viewSize.height,
            width: detection.boundingBox.width * viewSize.width,
            height: detection.boundingBox.height * viewSize.height
        )

        // 2. Project the 2D point into 3D space
        // For a basic example, we unproject the center of the rectangle.
        let centerPoint = CGPoint(x: rectInView.midX, y: rectInView.midY)
        
        // We attempt to find a 3D position via raycasting against existing planes
        // or by unprojecting a point at a fixed depth.
        if let raycastResult = arView.raycast(from: centerPoint, allowing: .estimatedPlane, alignment: .any).first {
            let worldTransform = raycastResult.worldTransform
            
            // 3. Create the 3D Mesh (A thin box/plane)
            let mesh = MeshResource.generateBox(width: Float(rectInView.width / 1000), // Scaling factor for demo
                                               height: Float(rectInView.height / 1000),
                                               depth: 0.01)
            let material = SimpleMaterial(color: .cyan.withAlphaComponent(0.5), isMetallic: true)
            let modelEntity = ModelEntity(mesh: mesh, materials: [material])
            
            // 4. Position the entity in the world
            modelEntity.setTransformMatrix(worldTransform, relativeTo: nil)
            
            anchor.addChild(modelEntity)
        }
    }
}

// MARK: - Main View

struct SmartScannerView: View {
    @State private var currentDetection: DetectionResult?
    @State private var isCameraRunning = false
    
    // The detector is held in a State variable to manage its lifecycle
    @State private var detector = ObjectDetector()

    var body: some View {
        ZStack {
            // The AR Layer
            ARViewContainer(detection: $currentDetection)
                .edgesIgnoringSafeArea(.all)

            // The UI Layer
            VStack {
                Text("Spatial Scanner")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundStyle(.white)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(15)

                Spacer()

                if let detection = currentDetection {
                    Text("Object Detected: \(Int(detection.confidence * 100))%")
                        .padding()
                        .background(.green.opacity(0.7))
                        .clipShape(Capsule())
                        .foregroundStyle(.white)
                }

                Button(action: toggleCamera) {
                    Label(isCameraRunning ? "Stop Scanning" : "Start Scanning", 
                          systemImage: isCameraRunning ? "stop.fill" : "play.fill")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(isCameraRunning ? .red : .blue)
                        .foregroundStyle(.white)
                        .cornerRadius(12)
                }
                .padding()
            }
        }
        .onAppear {
            setupDetectionCallback()
        }
    }

    private func setupDetectionCallback() {
        // Link the detector's output to our SwiftUI state
        Task {
            await detector.setCallback { result in
                self.currentDetection = result
            }
        }
    }
    
    private func toggleCamera() {
        isCameraRunning.toggle()
        // In a real app, this would trigger the AVFoundation session start/stop
    }
}

// Extension to bridge the Actor-based detector to the MainActor View
extension ObjectDetector {
    func setCallback(_ callback: @escaping @MainActor (DetectionResult?) -> Void) {
        self.onDetectionUpdate = callback
    }
}

// MARK: - App Entry
@main
struct SpatialAIApp: App {
    var body: some Scene {
        WindowGroup {
            SmartScannerView()
        }
    }
}
