
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// Define the flags available in the system
enum FeatureFlag: String, CaseIterable, Sendable {
    case enableAIInsights
    case useAdvancedReasoning
    case experimentalPromptV2
}

// The abstraction that the rest of the app will use
protocol FeatureFlagProvider: Sendable {
    func isEnabled(_ flag: FeatureFlag) async -> Bool
}

// Implementation for Unit Testing
final class MockFeatureFlagProvider: FeatureFlagProvider {
    private let flags: [FeatureFlag: Bool]
    
    init(flags: [FeatureFlag: Bool]) {
        self.flags = flags
    }
    
    func isEnabled(_ flag: FeatureFlag) async -> Bool {
        return flags[flag] ?? false
    }
}

// Implementation for Production (Simulated)
final class RemoteFeatureFlagProvider: FeatureFlagProvider {
    // Simulating a remote configuration dictionary
    private let remoteConfig: [String: Bool] = [
        "enableAIInsights": true,
        "useAdvancedReasoning": false
    ]
    
    func isEnabled(_ flag: FeatureFlag) async -> Bool {
        // Simulate network latency
        try? await Task.sleep(for: .milliseconds(500))
        
        // Simulate a potential network failure/error handling
        // In a real app, we might catch a URLSession error here
        return remoteConfig[flag.rawValue] ?? false // Fallback to default (false)
    }
}

// The Single Source of Truth for the app
actor FeatureFlagManager {
    private var provider: FeatureFlagProvider
    
    init(provider: FeatureFlagProvider) {
        self.provider = provider
    }
    
    func updateProvider(_ newProvider: FeatureFlagProvider) {
        self.provider = newProvider
    }
    
    func isEnabled(_ flag: FeatureFlag) async -> Bool {
        await provider.isEnabled(flag)
    }
}

// Dependency Injection in Action
@MainActor
class JournalViewModel: ObservableObject {
    private let flagManager: FeatureFlagManager
    @Published var insightText: String = "No insights yet."
    
    init(flagManager: FeatureFlagManager) {
        self.flagManager = flagManager
    }
    
    func generateInsight() async {
        let isEnabled = await flagManager.isEnabled(.enableAIInsights)
        
        if isEnabled {
            self.insightText = "AI Insight: You seem to be having a productive day!"
        } else {
            self.insightText = "Standard Journal: Entry saved."
        }
    }
}
