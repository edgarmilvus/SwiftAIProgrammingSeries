
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import MLXNN
import MLXOptimizers
import Foundation

// Re-use LoRALinear from Exercise 1/2 for self-containment
@available(iOS 18.0, macOS 15.0, *)
final class LoRALinear: MLXNN.Module {
    let baseLinear: MLXNN.Linear
    let loraA: MLXNN.Linear
    let loraB: MLXNN.Linear
    let scale: Float

    init(inputFeatures: Int, outputFeatures: Int, rank: Int, scale: Float = 1.0) {
        self.baseLinear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        self.loraA = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: rank, bias: false)
        self.loraB = MLXNN.Linear(inputFeatures: rank, outputFeatures: outputFeatures, bias: false)
        self.scale = scale
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        let baseOutput = baseLinear(x)
        let delta = loraB(loraA(x)) * scale
        return baseOutput + delta
    }

    override var parameters: [MLXArray] {
        return loraA.parameters + loraB.parameters
    }
}

// MARK: - 1. Simplified LLM Architecture

@available(iOS 18.0, macOS 15.0, *)
final class SimpleLLM: MLXNN.Module {
    let embedding: MLXNN.Embedding          // Converts token IDs to dense vectors
    let gru: MLXNN.GRU                      // Recurrent layer for sequence processing
    let adapterLoRA: LoRALinear             // LoRA layer to adapt GRU's output before final projection
    let finalProjection: MLXNN.Linear       // Base final projection to vocabulary logits (frozen)

    init(vocabSize: Int, embedDim: Int, hiddenDim: Int, loraRank: Int) {
        self.embedding = MLXNN.Embedding(outputDimensions: embedDim, inputDimensions: vocabSize)
        self.gru = MLXNN.GRU(inputFeatures: embedDim, hiddenFeatures: hiddenDim)
        
        // LoRA layer to adapt the hidden state from the GRU.
        // It takes the GRU's hidden_dim output and adapts it to another hidden_dim space.
        self.adapterLoRA = LoRALinear(inputFeatures: hiddenDim, outputFeatures: hiddenDim, rank: loraRank)
        
        // Final projection maps the adapted hidden state to the vocabulary size.
        // Its weights are part of `baseLinear` within `adapterLoRA` or effectively frozen here.
        // For this setup, `finalProjection` acts as a frozen base layer that the `adapterLoRA` modifies.
        self.finalProjection = MLXNN.Linear(inputFeatures: hiddenDim, outputFeatures: vocabSize)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // x: [batch, sequence_length] -> embedded: [batch, sequence_length, embed_dim]
        let embedded = embedding(x)

        // GRU expects input as [sequence_length, batch, features] by default.
        let transposed = embedded.permute(1, 0, 2) // [sequence_length, batch, embed_dim]
        let (output, _) = gru(transposed)         // output: [sequence_length, batch, hidden_dim]

        // Reshape GRU output for the linear layers: [seq_len*batch, hidden_dim]
        let reshapedOutput = output.reshaped([output.dim(0) * output.dim(1), output.dim(2)])

        // Apply LoRA adaptation to the GRU's output
        let adaptedHiddenState = adapterLoRA(reshapedOutput) // [seq_len*batch, hidden_dim]

        // Apply the final (frozen) projection to vocabulary logits
        let logits = finalProjection(adaptedHiddenState) // [seq_len*batch, vocabSize]
        return logits
    }

    // Override parameters to only return LoRA weights for training
    override var parameters: [MLXArray] {
        return adapterLoRA.parameters
    }
}

// MARK: - Training Loop and Inference

@available(iOS 18.0, macOS 15.0, *)
func runExercise3() {
    let vocabSize = 100         // Small vocabulary for synthetic data
    let embedDim = 64
    let hiddenDim = 128
    let loraRank = 8
    let learningRate: Float = 1e-3
    let batchSize = 4
    let sequenceLength = 10
    let numSteps = 200

    // 1. Instantiate the LoRA-adapted SimpleLLM
    let model = SimpleLLM(vocabSize: vocabSize, embedDim: embedDim, hiddenDim: hiddenDim, loraRank: loraRank)

    // 2. Optimizer for LoRA parameters only
    let optimizer = MLXNN.Optimizers.AdamW(learningRate: learningRate)

    // 3. Training Loop
    print("Starting LLM LoRA fine-tuning for personalization...")
    for step in 0..<numSteps {
        // Generate synthetic data: input sequence and target next tokens
        let inputSequence = MLXArray.randomUniform(low: 0, high: vocabSize, [batchSize, sequenceLength], type: .int32)
        
        // Create target sequence by shifting the input (next token prediction)
        var targetSequence = MLXArray.zeros([batchSize, sequenceLength], type: .int32)
        if sequenceLength > 1 {
            // Target for position `i` is the token at position `i+1`
            targetSequence[0..<batchSize, 0..<sequenceLength-1] = inputSequence[0..<batchSize, 1..<sequenceLength]
        }
        // Flatten targets to match the model's output shape for cross-entropy loss
        let targets = targetSequence.flatten() // [seq_len*batch]

        // Define the loss function
        let lossFn = { (model: SimpleLLM, inputSeq: MLXArray, targetSeq: MLXArray) -> MLXArray in
            let logits = model(inputSeq) // logits: [seq_len*batch, vocabSize]
            return MLXNN.Loss.crossEntropy(predictions: logits, targets: targetSeq)
        }

        // Compute loss and gradients for LoRA parameters
        let (loss, gradients) = MLX.valueAndGradient(model: model, lossFn, inputSequence, targets)

        // Update LoRA parameters
        optimizer.update(model: model, gradients: gradients)

        // Evaluate and print loss
        let currentLoss = loss.item(Float.self)
        if step % 20 == 0 {
            print("Step \(step), Loss: \(currentLoss)")
        }
    }
    print("LLM LoRA fine-tuning complete for personalized responses.")

    // 4. Example Inference (Greedy Decoding)
    print("\n--- Demonstrating Personalized Inference ---")
    // Simulate a prompt: e.g., token IDs 10, 20, 30
    var promptTokens = MLXArray([Int32(10), Int32(20), Int32(30)], type: .int32).reshaped([1, 3]) // [batch=1, seq_len=3]
    var generatedSequence = promptTokens

    print("Prompt tokens (simulated): \(promptTokens.asArray(Int32.self))")

    for _ in 0..<5 { // Generate 5 new tokens
        let logits = model(generatedSequence) // Logits for all tokens in the sequence
        let lastLogit = logits[logits.dim(0) - 1] // Get logits for the *last* token in the sequence
        let nextToken = MLX.argmax(lastLogit, axis: -1).item(Int32.self) // Greedy pick of the next token
        
        // Append the generated token to the sequence for the next prediction
        generatedSequence = MLXArray.concatenate([generatedSequence, MLXArray(nextToken).reshaped([1, 1])], axis: -1)
    }

    print("Generated sequence (simulated, showing personalization): \(generatedSequence.asArray(Int32.self))")

    print("\n--- Pedagogical Note: Privacy and Unified Memory for LLMs ---")
    print("This local fine-tuning approach directly addresses the 'MyAI Assistant' feature request by ensuring user data (e.g., personal writing style examples) never leaves the device.")
    print("MLX's Unified Memory architecture is absolutely critical for this application:")
    print("- The base LLM parameters (even in this simplified form) reside in the shared memory.")
    print("- The LoRA adapter weights, being small, are also efficiently stored and updated in this shared memory.")
    print("- Crucially, all intermediate activations during sequence processing (embeddings, GRU states, adapted hidden states) are directly allocated and manipulated within Unified Memory.")
    print("This 'zero-copy' benefit eliminates the performance bottlenecks of moving data between discrete CPU and GPU memories, which is a major concern for memory-intensive LLMs.")
    print("It makes on-device LLM fine-tuning both fast and memory-efficient, directly enabling the privacy and personalization requirements of the chatbot feature request on Apple Silicon.")
}

// Call the function to run the exercise
// runExercise3()
