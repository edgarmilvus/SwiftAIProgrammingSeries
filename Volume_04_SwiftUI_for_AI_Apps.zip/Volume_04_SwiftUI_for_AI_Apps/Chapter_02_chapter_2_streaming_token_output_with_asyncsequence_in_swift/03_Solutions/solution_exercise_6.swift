
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.swift
// Description: Solution for Exercise 6
// ==========================================

import SwiftUI
import Foundation

// MARK: - Custom Error for Code Generation

enum CodeGenerationError: Error, LocalizedError {
    case serviceUnavailable
    case invalidPrompt(String)
    case internalServerError(String)

    var errorDescription: String? {
        switch self {
        case .serviceUnavailable:
            return "The AI code generation service is currently unavailable. Please try again later."
        case .invalidPrompt(let details):
            return "Invalid prompt: \(details)"
        case .internalServerError(let details):
            return "An internal server error occurred: \(details)"
        }
    }
}

// MARK: - Error-Prone AsyncSequence

struct CodeGenerationStream: AsyncSequence {
    typealias Element = String
    private let codeSnippet: String
    private let simulateErrorChance: Double // 0.0 to 1.0
    private let errorAfterLines: Int

    init(codeSnippet: String, simulateErrorChance: Double = 0.2, errorAfterLines: Int = 3) {
        self.codeSnippet = codeSnippet
        self.simulateErrorChance = simulateErrorChance
        self.errorAfterLines = errorAfterLines
    }

    func makeAsyncIterator() -> Iterator {
        Iterator(
            lines: codeSnippet.split(separator: "\n", omittingEmptySubsequences: false).map(String.init),
            simulateErrorChance: simulateErrorChance,
            errorAfterLines: errorAfterLines
        )
    }

    struct Iterator: AsyncIteratorProtocol {
        private var lines: [String]
        private let simulateErrorChance: Double
        private let errorAfterLines: Int
        private var linesEmitted: Int = 0

        init(lines: [String], simulateErrorChance: Double, errorAfterLines: Int) {
            self.lines = lines
            self.simulateErrorChance = simulateErrorChance
            self.errorAfterLines = errorAfterLines
        }

        mutating func next() async throws -> String? {
            guard !lines.isEmpty else { return nil }

            // Simulate error
            if Double.random(in: 0..<1) < simulateErrorChance && linesEmitted >= errorAfterLines {
                throw CodeGenerationError.internalServerError("Failed to generate further code due to a backend issue.")
            }

            try await Task.sleep(for: .milliseconds(Int.random(in: 50...200))) // Varying delay
            try Task.checkCancellation()

            linesEmitted += 1
            return lines.removeFirst()
        }
    }
}

// MARK: - Streaming Status Enum

enum StreamingStatus: Equatable {
    case idle
    case streaming
    case completed
    case error(String)

    var isError: Bool {
        if case .error = self { return true }
        return false
    }

    var isLoading: Bool {
        self == .streaming
    }
}

// MARK: - SwiftUI View

struct CodeEditorView: View {
    @State private var userInput: String = ""
    @State private var generatedCode: String = ""
    @State private var status: StreamingStatus = .idle
    @State private var currentStreamTask: Task<Void, Error>?

    private let mockCodeSnippet = """
    