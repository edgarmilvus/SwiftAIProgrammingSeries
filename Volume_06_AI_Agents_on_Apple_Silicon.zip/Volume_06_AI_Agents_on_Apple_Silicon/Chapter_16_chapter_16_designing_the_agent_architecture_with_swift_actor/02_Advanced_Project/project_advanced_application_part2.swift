
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation

/// Represents specific errors that can occur within the agent system.
enum AgentError: Error, LocalizedError, Sendable {
    case documentProcessingFailed(reason: String)
    case llmInferenceFailed(reason: String)
    case llmServiceBusy
    case invalidRequest(reason: String)
    case coordinatorError(reason: String)
    case unknownError(Error)

    var errorDescription: String? {
        switch self {
        case .documentProcessingFailed(let reason):
            return "Document processing failed: \(reason)"
        case .llmInferenceFailed(let reason):
            return "LLM inference failed: \(reason)"
        case .llmServiceBusy:
            return "LLM inference service is currently busy. Please try again shortly."
        case .invalidRequest(let reason):
            return "Invalid request: \(reason)"
        case .coordinatorError(let reason):
            return "Agent coordinator error: \(reason)"
        case .unknownError(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

/// Represents the extracted content of a document.
/// It must be `Sendable` to be passed safely between actors.
struct DocumentContent: Sendable, Identifiable, CustomStringConvertible {
    let id: UUID
    let rawText: String
    let pageCount: Int
    let processedTimestamp: Date

    var description: String {
        "Document(ID: \(id.uuidString.prefix(8))..., Pages: \(pageCount), Processed: \(processedTimestamp))"
    }
}

/// Represents a request to the LLM for a specific task.
/// It must be `Sendable`.
struct LLMRequest: Sendable {
    let documentID: UUID
    let prompt: String
    let context: String // The document content to provide to the LLM
    let temperature: Double
    let maxTokens: Int
}

/// Represents the response received from the LLM.
/// It must be `Sendable`.
struct LLMResponse: Sendable {
    let requestID: UUID
    let generatedText: String
    let modelName: String
    let completionTime: TimeInterval
    let tokensUsed: Int
}

/// Defines the types of analysis tasks the agent can perform.
enum AnalysisTask: Sendable {
    case summarize(length: Int)
    case answerQuestion(question: String)
    case categorize(categories: [String])
    case custom(promptSuffix: String)

    /// Generates a prompt string based on the task type.
    func generatePrompt(with documentText: String) -> String {
        switch self {
        case .summarize(let length):
            return "Summarize the following document in about \(length) words:\n\n\(documentText)"
        case .answerQuestion(let question):
            return "Given the following document, answer the question: '\(question)'\n\nDocument:\n\(documentText)"
        case .categorize(let categories):
            let categoryList = categories.joined(separator: ", ")
            return "Categorize the following document into one of these categories: [\(categoryList)]. Provide only the category name.\n\nDocument:\n\(documentText)"
        case .custom(let promptSuffix):
            return "\(documentText)\n\n\(promptSuffix)"
        }
    }
}
