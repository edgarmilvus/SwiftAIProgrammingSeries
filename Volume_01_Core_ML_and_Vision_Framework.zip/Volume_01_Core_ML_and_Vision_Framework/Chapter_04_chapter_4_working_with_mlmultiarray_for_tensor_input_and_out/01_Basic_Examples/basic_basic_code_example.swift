
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CoreML
import Foundation

// We'll define a simple structure to encapsulate our feature processing logic.
// This would typically be part of a larger VoiceAssistant or AudioProcessor class.
@available(iOS 13.0, macOS 10.15, *) // MLMultiArray is available from these versions
struct AudioFeatureProcessor {

    /// Processes raw audio features, storing them in an MLMultiArray,
    /// and demonstrates basic manipulation.
    /// - Parameters:
    ///   - timeSteps: The number of time slices or frames over which features are extracted.
    ///   - featureCount: The number of distinct features extracted per time step.
    /// - Returns: An MLMultiArray containing the processed features, or nil if creation fails.
    func processAndPrepareFeatures(timeSteps: Int, featureCount: Int) -> MLMultiArray? {
        // 1. Define the shape of our tensor.
        // For audio features, a common shape is [timeSteps, featureCount].
        // This represents a matrix where each row is a feature vector for a given time step.
        let shape: [NSNumber] = [NSNumber(value: timeSteps), NSNumber(value: featureCount)]

        // 2. Specify the data type.
        // Most ML models use 32-bit floating-point numbers (Float).
        // MLMultiArrayDataType.float32 is the corresponding Core ML enum.
        let dataType = MLMultiArrayDataType.float32

        // 3. Create the MLMultiArray instance.
        // This allocates the necessary memory for our 5x10 matrix of floats.
        // It can throw an error if the shape is invalid or memory cannot be allocated.
        guard let featureMultiArray = try? MLMultiArray(shape: shape, dataType: dataType) else {
            print("Error: Could not create MLMultiArray with shape \(shape) and data type \(dataType)")
            return nil
        }

        print("Successfully created MLMultiArray with shape: \(featureMultiArray.shape) and data type: \(featureMultiArray.dataType.rawValue)")
        print("Total number of elements: \(featureMultiArray.count)")

        // 4. Populate the MLMultiArray with sample data.
        // In a real app, this data would come from an audio processing pipeline.
        // We'll simulate it with a simple loop.
        // MLMultiArray uses a flat, row-major memory layout.
        // Accessing elements can be done via a single index for the flattened array,
        // or via multiple indices corresponding to the dimensions (e.g., [timeStep, featureIndex]).

        for t in 0..<timeSteps {
            for f in 0..<featureCount {
                // Simulate some feature data.
                // For demonstration, let's make it dependent on time step and feature index.
                let value = Float(t * 10 + f) * 0.1 + Float.random(in: -0.05...0.05)
                
                // Assign value using multi-dimensional indexing.
                // This is generally safer and more readable than calculating a flat index.
                featureMultiArray[[t, f] as [NSNumber]] = NSNumber(value: value)
            }
        }
        print("\n--- Initial Feature Data (first 3 time steps, first 5 features) ---")
        for t in 0..<min(3, timeSteps) {
            var rowString = "Time Step \(t): ["
            for f in 0..<min(5, featureCount) {
                rowString += String(format: "%.2f", featureMultiArray[[t, f] as [NSNumber]].floatValue)
                if f < min(5, featureCount) - 1 { rowString += ", " }
            }
            rowString += "]"
            print(rowString)
        }
        if timeSteps > 3 || featureCount > 5 {
             print("...")
        }


        // 5. Access and inspect specific elements.
        // Let's get the feature at time step 2, feature index 3.
        let targetTimeStep = 2
        let targetFeatureIndex = 3
        if targetTimeStep < timeSteps && targetFeatureIndex < featureCount {
            let specificFeatureValue = featureMultiArray[[targetTimeStep, targetFeatureIndex] as [NSNumber]].floatValue
            print("\nValue at [\(targetTimeStep), \(targetFeatureIndex)]: \(String(format: "%.2f", specificFeatureValue))")
        }

        // 6. Demonstrate a simple pre-processing step: Scaling.
        // In a real scenario, features might need to be normalized or scaled
        // to a specific range (e.g., 0-1 or -1 to 1) required by the ML model.
        // We'll apply a simple scaling factor.
        let scalingFactor: Float = 0.5
        print("\n--- Applying Scaling (factor: \(scalingFactor)) ---")
        for i in 0..<featureMultiArray.count {
            let originalValue = featureMultiArray[i].floatValue
            let scaledValue = originalValue * scalingFactor
            featureMultiArray[i] = NSNumber(value: scaledValue)
        }

        print("\n--- Scaled Feature Data (first 3 time steps, first 5 features) ---")
        for t in 0..<min(3, timeSteps) {
            var rowString = "Time Step \(t): ["
            for f in 0..<min(5, featureCount) {
                rowString += String(format: "%.2f", featureMultiArray[[t, f] as [NSNumber]].floatValue)
                if f < min(5, featureCount) - 1 { rowString += ", " }
            }
            rowString += "]"
            print(rowString)
        }
        if timeSteps > 3 || featureCount > 5 {
             print("...")
        }

        // The 'featureMultiArray' is now ready to be passed as an input to a Core ML model.
        return featureMultiArray
    }
}

// Example usage within an application context (e.g., a ViewController or AppDelegate)
@available(iOS 13.0, macOS 10.15, *)
func runMLMultiArrayExample() {
    print("--- Starting MLMultiArray Basic Example ---")
    let processor = AudioFeatureProcessor()
    let timeSteps = 5
    let featureCount = 10

    if let processedFeatures = processor.processAndPrepareFeatures(timeSteps: timeSteps, featureCount: featureCount) {
        print("\nMLMultiArray prepared for model input:")
        print("  Shape: \(processedFeatures.shape)")
        print("  Data Type: \(processedFeatures.dataType.rawValue)")
        // In a real app, 'processedFeatures' would now be an input to a Core ML model.
        // For example:
        // let model = try MyMLModel(configuration: MLModelConfiguration())
        // let input = MyMLModelInput(features: processedFeatures)
        // let output = try model.prediction(input: input)
        // Then process 'output' which might also be an MLMultiArray.
    } else {
        print("Failed to prepare features.")
    }
    print("--- MLMultiArray Basic Example Finished ---")
}

// Call the example function to execute the code
runMLMultiArrayExample()
