
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Speech
import AVFoundation

/// A service class responsible for handling live speech recognition.
/// It uses AVAudioEngine to capture microphone input and SFSpeechRecognizer
/// to convert the audio stream into text.
@MainActor
final class LiveSpeechRecognizerService: ObservableObject {
    /// The shared speech recognizer instance.
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))

    /// The audio engine used to capture and process microphone input.
    private var audioEngine: AVAudioEngine?

    /// The recognition request that feeds audio buffers to the speech recognizer.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?

    /// The recognition task that manages the ongoing speech recognition process.
    private var recognitionTask: SFSpeechRecognitionTask?

    /// Published property to inform SwiftUI views about the current transcription.
    @Published var currentTranscription: String = "Tap 'Start' and speak..."

    /// Published property to indicate if the service is currently recording.
    @Published var isRecording: Bool = false

    /// Initializes the speech recognition service.
    /// It checks for speech recognizer availability.
    init() {
        guard speechRecognizer?.isAvailable == true else {
            print("Speech recognizer is not available for this locale.")
            currentTranscription = "Speech recognition not available."
            return
        }
        speechRecognizer?.delegate = self // Set delegate to handle availability changes
    }

    /// Requests necessary permissions for speech recognition and microphone access.
    /// This method must be called before attempting to start recording.
    /// - Throws: `SpeechRecognitionError` if permissions are denied or unavailable.
    func requestPermissions() async throws {
        // Request Speech Recognition authorization
        let speechAuthStatus = await SFSpeechRecognizer.authorizationStatus()
        switch speechAuthStatus {
        case .authorized:
            print("Speech recognition authorized.")
        case .denied:
            throw SpeechRecognitionError.permissionDenied(type: .speechRecognition)
        case .restricted:
            throw SpeechRecognitionError.permissionRestricted(type: .speechRecognition)
        case .notDetermined:
            let newStatus = await SFSpeechRecognizer.requestAuthorization()
            if newStatus != .authorized {
                throw SpeechRecognitionError.permissionDenied(type: .speechRecognition)
            }
        @unknown default:
            throw SpeechRecognitionError.unknownPermissionStatus(type: .speechRecognition)
        }

        // Request Microphone authorization
        let audioSession = AVAudioSession.sharedInstance()
        let micAuthStatus = await audioSession.recordPermission
        switch micAuthStatus {
        case .granted:
            print("Microphone authorized.")
        case .denied:
            throw SpeechRecognitionError.permissionDenied(type: .microphone)
        case .undetermined:
            await audioSession.requestRecordPermission { granted in
                if !granted {
                    Task { @MainActor in
                        throw SpeechRecognitionError.permissionDenied(type: .microphone)
                    }
                }
            }
        @unknown default:
            throw SpeechRecognitionError.unknownPermissionStatus(type: .microphone)
        }
    }

    /// Starts the audio engine and speech recognition process.
    /// - Throws: An error if the audio session or engine setup fails.
    func startRecording() throws {
        // 1. Stop any ongoing recognition task and engine
        stopRecording()

        guard speechRecognizer?.isAvailable == true else {
            throw SpeechRecognitionError.recognizerUnavailable
        }

        currentTranscription = "Listening..."
        isRecording = true

        // 2. Configure the Audio Session
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw SpeechRecognitionError.audioSessionSetupFailed(error)
        }

        // 3. Setup AVAudioEngine
        let newAudioEngine = AVAudioEngine()
        self.audioEngine = newAudioEngine

        // Get the input node from the audio engine (microphone)
        let inputNode = newAudioEngine.inputNode

        // Define the audio format for the recognition request
        // SFSpeechRecognizer generally expects a specific format, often 44.1 kHz, 16-bit, mono.
        let recordingFormat = inputNode.outputFormat(forBus: 0)

        // 4. Create a new SFSpeechAudioBufferRecognitionRequest
        let newRecognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        newRecognitionRequest.shouldReportPartialResults = true // Get results as user speaks
        recognitionRequest = newRecognitionRequest

        // 5. Install a tap on the input node to capture audio buffers
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
            // Append the audio buffer to the recognition request
            self?.recognitionRequest?.append(buffer)
        }

        // 6. Prepare and Start the Audio Engine
        newAudioEngine.prepare()
        do {
            try newAudioEngine.start()
        } catch {
            throw SpeechRecognitionError.audioEngineStartFailed(error)
        }

        // 7. Start the Speech Recognition Task
        recognitionTask = speechRecognizer?.recognitionTask(with: newRecognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                self.currentTranscription = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // Stop the audio engine and recognition task if an error occurs or recognition is final
                self.stopRecording()
                if let error = error {
                    self.currentTranscription = "Error: \(error.localizedDescription)"
                    print("Speech recognition error: \(error.localizedDescription)")
                } else if isFinal {
                    print("Recognition finished.")
                }
            }
        }
    }

    /// Stops the audio engine and speech recognition process, releasing resources.
    func stopRecording() {
        isRecording = false

        // Stop the audio engine
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0) // Remove the tap to prevent memory leaks

        // End the recognition request
        recognitionRequest?.endAudio()
        recognitionRequest = nil

        // Cancel and release the recognition task
        recognitionTask?.cancel()
        recognitionTask = nil

        // Deactivate the audio session
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    /// Resets the transcription and stops any ongoing process.
    func reset() {
        stopRecording()
        currentTranscription = "Tap 'Start' and speak..."
    }

    /// Deinitializes the service, ensuring all resources are properly released.
    deinit {
        stopRecording()
        print("LiveSpeechRecognizerService deinitialized.")
    }
}

// MARK: - SFSpeechRecognizerDelegate

extension LiveSpeechRecognizerService: SFSpeechRecognizerDelegate {
    /// Called when the availability of the speech recognizer changes.
    /// - Parameter speechRecognizer: The recognizer whose availability changed.
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if !available {
            Task { @MainActor in
                self.currentTranscription = "Speech recognition is currently unavailable."
                self.stopRecording()
            }
        }
    }
}

// MARK: - Custom Errors

/// Custom error types for speech recognition operations.
enum SpeechRecognitionError: Error, LocalizedError {
    enum PermissionType {
        case speechRecognition
        case microphone
    }

    case permissionDenied(type: PermissionType)
    case permissionRestricted(type: PermissionType)
    case unknownPermissionStatus(type: PermissionType)
    case recognizerUnavailable
    case audioSessionSetupFailed(Error)
    case audioEngineStartFailed(Error)
    case generalError(String)

    var errorDescription: String? {
        switch self {
        case .permissionDenied(let type):
            return "Permission for \(type == .speechRecognition ? "Speech Recognition" : "Microphone") was denied. Please enable it in Settings."
        case .permissionRestricted(let type):
            return "Permission for \(type == .speechRecognition ? "Speech Recognition" : "Microphone") is restricted. This might be due to parental controls."
        case .unknownPermissionStatus(let type):
            return "Unknown permission status for \(type == .speechRecognition ? "Speech Recognition" : "Microphone")."
        case .recognizerUnavailable:
            return "Speech recognizer is currently unavailable."
        case .audioSessionSetupFailed(let error):
            return "Failed to set up audio session: \(error.localizedDescription)"
        case .audioEngineStartFailed(let error):
            return "Failed to start audio engine: \(error.localizedDescription)"
        case .generalError(let message):
            return message
        }
    }
}

// MARK: - SwiftUI Integration

/// A simple SwiftUI view to demonstrate the LiveSpeechRecognizerService.
/// This view provides buttons to start/stop recording and displays the
/// live transcription.
struct LiveSpeechRecognitionView: View {
    @StateObject private var speechRecognizerService = LiveSpeechRecognizerService()
    @State private var showingSettingsAlert = false
    @State private var permissionError: SpeechRecognitionError?

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            Text("Live Transcription")
                .font(.largeTitle)
                .fontWeight(.bold)

            Text(speechRecognizerService.currentTranscription)
                .font(.title2)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .multilineTextAlignment(.center)
                .lineLimit(nil) // Allow unlimited lines
                .fixedSize(horizontal: false, vertical: true) // Allow vertical expansion

            Spacer()

            HStack(spacing: 20) {
                Button {
                    Task {
                        do {
                            if !speechRecognizerService.isRecording {
                                try await speechRecognizerService.requestPermissions()
                                try speechRecognizerService.startRecording()
                                permissionError = nil // Clear any previous error
                            } else {
                                speechRecognizerService.stopRecording()
                            }
                        } catch let error as SpeechRecognitionError {
                            permissionError = error
                            showingSettingsAlert = true
                            speechRecognizerService.stopRecording() // Ensure recording stops on error
                            print("Permission or setup error: \(error.localizedDescription)")
                        } catch {
                            permissionError = .generalError(error.localizedDescription)
                            showingSettingsAlert = true
                            speechRecognizerService.stopRecording() // Ensure recording stops on error
                            print("Unexpected error: \(error.localizedDescription)")
                        }
                    }
                } label: {
                    Label(speechRecognizerService.isRecording ? "Stop Listening" : "Start Listening",
                          systemImage: speechRecognizerService.isRecording ? "mic.fill" : "mic")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(speechRecognizerService.isRecording ? Color.red : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                }
            }
            .padding(.horizontal)

            Spacer()
        }
        .padding()
        .alert("Permission Required", isPresented: $showingSettingsAlert, presenting: permissionError) { _ in
            Button("Open Settings") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            Button("Cancel", role: .cancel) { }
        } message: { error in
            Text(error.localizedDescription + "\n\nPlease grant access in Settings to use this feature.")
        }
        .onDisappear {
            speechRecognizerService.stopRecording()
        }
    }
}

// MARK: - Preview Provider

@available(iOS 17.0, *)
#Preview {
    LiveSpeechRecognitionView()
}
