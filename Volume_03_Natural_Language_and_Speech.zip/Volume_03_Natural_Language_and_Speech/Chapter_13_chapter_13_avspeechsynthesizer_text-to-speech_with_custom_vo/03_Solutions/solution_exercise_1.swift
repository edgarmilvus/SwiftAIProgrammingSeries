
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AVFoundation

// MARK: - SpeechManager

class SpeechManager: NSObject {
    private let synthesizer = AVSpeechSynthesizer()

    // Curated voice identifiers for easy selection
    private var curatedVoiceIdentifiers: [String: String] = [:]
    private let defaultVoiceLanguage = "en-US" // Fallback if specific curated voices aren't found

    override init() {
        super.init()
        synthesizer.delegate = self // Set delegate for potential future use (Exercise 2)
        setupCuratedVoices()
    }

    private func setupCuratedVoices() {
        let allVoices = AVSpeechSynthesisVoice.speechVoices()

        // Attempt to find a US English female voice
        if let usFemale = allVoices.first(where: { $0.language == "en-US" && $0.gender == .female }) {
            curatedVoiceIdentifiers["US Female"] = usFemale.identifier
            print("Curated Voice: US Female found: \(usFemale.name) (\(usFemale.identifier))")
        } else {
            print("Curated Voice: US Female not found. Using general en-US fallback for this category.")
            // Fallback to any en-US if specific gender not found or on older OS
            if let anyUSVoice = allVoices.first(where: { $0.language == "en-US" }) {
                 curatedVoiceIdentifiers["US Female"] = anyUSVoice.identifier
            }
        }

        // Attempt to find a US English male voice
        if let usMale = allVoices.first(where: { $0.language == "en-US" && $0.gender == .male }) {
            curatedVoiceIdentifiers["US Male"] = usMale.identifier
            print("Curated Voice: US Male found: \(usMale.name) (\(usMale.identifier))")
        } else {
            print("Curated Voice: US Male not found. Using general en-US fallback for this category.")
            if let anyUSVoice = allVoices.first(where: { $0.language == "en-US" }) {
                 curatedVoiceIdentifiers["US Male"] = anyUSVoice.identifier
            }
        }

        // Attempt to find a French voice (fr-FR)
        if let frenchVoice = allVoices.first(where: { $0.language == "fr-FR" }) {
            curatedVoiceIdentifiers["French"] = frenchVoice.identifier
            print("Curated Voice: French found: \(frenchVoice.name) (\(frenchVoice.identifier))")
        } else {
            print("Curated Voice: French (fr-FR) not found. This option will fall back to system default.")
        }
    }

    /// Speaks the given text using the specified voice identifier.
    /// If voiceIdentifier is nil or not found, a default system voice is used.
    ///
    /// - Parameters:
    ///   - text: The text string to be spoken.
    ///   - voiceIdentifier: An optional identifier for the desired voice (e.g., "com.apple.ttsbundle.Samantha-premium").
    ///                    Can also be one of the curated keys like "US Female", "US Male", "French".
    func speak(_ text: String, voiceIdentifier: String? = nil) {
        let utterance = AVSpeechUtterance(string: text)
        var selectedVoice: AVSpeechSynthesisVoice?
        var usedVoiceName: String = "System Default"
        var fallbackOccurred = false

        if let identifier = voiceIdentifier {
            // Check if it's one of our curated keys
            if let curatedID = curatedVoiceIdentifiers[identifier] {
                selectedVoice = AVSpeechSynthesisVoice(identifier: curatedID)
            } else {
                // Try to create a voice directly from the provided identifier
                selectedVoice = AVSpeechSynthesisVoice(identifier: identifier)
            }

            if selectedVoice == nil {
                fallbackOccurred = true
                print("Voice '\(identifier)' not found. Falling back to system default voice.")
            }
        }

        // If no specific voice was selected or found, use system default
        utterance.voice = selectedVoice ?? AVSpeechSynthesisVoice(language: nil) // AVSpeechSynthesisVoice(language: nil) uses system default

        if let finalVoice = utterance.voice {
            usedVoiceName = "\(finalVoice.name) (\(finalVoice.language))"
        }

        if fallbackOccurred {
            print("Fallback: Using voice: \(usedVoiceName)")
        } else {
            print("Speaking with voice: \(usedVoiceName)")
        }

        synthesizer.speak(utterance)
    }

    // Public method to get curated voice keys for UI display
    func getCuratedVoiceKeys() -> [String] {
        return Array(curatedVoiceIdentifiers.keys).sorted()
    }
}

// MARK: - AVSpeechSynthesizerDelegate (for Exercise 1, primarily for future extension)

extension SpeechManager: AVSpeechSynthesizerDelegate {
    // Delegate methods will be implemented in Exercise 2
}

// MARK: - Example Usage

// For demonstration, you'd typically integrate this into a UIViewController or App struct.
// Here, we'll just instantiate and call methods.
func demonstrateExercise1() {
    print("--- Exercise 1 Demonstration ---")
    let speechManager = SpeechManager()

    // 1. Speak with a curated US Female voice
    print("\nAttempting to speak with 'US Female' voice:")
    speechManager.speak("Hello, this is a test from the US female voice.", voiceIdentifier: "US Female")

    // 2. Speak with a curated US Male voice
    print("\nAttempting to speak with 'US Male' voice:")
    speechManager.speak("This is an important announcement from the US male voice.", voiceIdentifier: "US Male")

    // 3. Speak with a curated French voice
    print("\nAttempting to speak with 'French' voice:")
    speechManager.speak("Bonjour le monde, ceci est un test en français.", voiceIdentifier: "French")

    // 4. Speak with an unknown voice identifier (should trigger fallback)
    print("\nAttempting to speak with an unknown voice identifier (should fallback):")
    speechManager.speak("This text should be spoken with the system's default voice due to unknown identifier.", voiceIdentifier: "UnknownVoiceID123")

    // 5. Speak without specifying a voice (should use system default)
    print("\nAttempting to speak without specifying a voice (should use system default):")
    speechManager.speak("This text should use the default system voice.")

    // Give some time for the synthesizer to process utterances
    // In a real app, this would be managed by the run loop or UI interaction.
    // For console demo, a short delay can help observe logs sequentially.
    // Note: This is a blocking delay and should not be used in production UI code.
    Thread.sleep(forTimeInterval: 8.0)
    print("--- Exercise 1 Demonstration Complete ---")
}

// Call the demonstration function to run the example
// demonstrateExercise1()
