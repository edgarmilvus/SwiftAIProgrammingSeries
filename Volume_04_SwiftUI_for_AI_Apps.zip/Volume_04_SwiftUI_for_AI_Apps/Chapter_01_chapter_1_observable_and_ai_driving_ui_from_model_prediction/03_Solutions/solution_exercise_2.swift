
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

// MARK: - 1. Create an Observable Image Predictor
@available(iOS 18.0, *)
@Observable
class ImagePredictionEngine {
    var predictedLabel: String = "Waiting for analysis..."
    var confidence: Double = 0.0
    var isAnalyzing: Bool = false
    
    private let possibleLabels = ["Cat", "Dog", "Car", "Tree", "Building", "Mountain", "Flower"]

    /// Simulates an asynchronous AI image analysis process.
    func analyzeImage() async {
        guard !isAnalyzing else { return } // Prevent multiple analyses simultaneously
        
        isAnalyzing = true
        predictedLabel = "Analyzing..."
        confidence = 0.0 // Reset confidence during analysis
        
        do {
            // Simulate network/model inference delay
            try await Task.sleep(for: .seconds(2))
            
            // Randomly update prediction results
            predictedLabel = possibleLabels.randomElement() ?? "Unknown"
            confidence = Double.random(in: 0.5...0.99) // Realistic confidence range
            
        } catch {
            // Handle cancellation or other errors
            predictedLabel = "Analysis failed."
            confidence = 0.0
        }
        
        isAnalyzing = false
    }
}

// MARK: - 2. Build the SwiftUI View
@available(iOS 18.0, *)
struct ImageRecognitionView: View {
    // Instantiate ImagePredictionEngine using @State
    @State private var predictor = ImagePredictionEngine()
    
    var body: some View {
        VStack(spacing: 25) {
            Text("Image Recognition Result")
                .font(.largeTitle)
                .bold()
                .padding(.bottom, 10)
            
            // Display predicted label
            Text("Predicted: \(predictor.predictedLabel)")
                .font(.headline)
                .foregroundColor(.primary)
                .animation(.easeInOut, value: predictor.predictedLabel)
            
            // Display confidence using a Gauge
            Gauge(value: predictor.confidence, in: 0.0...1.0) {
                Text("Confidence")
            } currentLabel: {
                Text(predictor.confidence, format: .percent)
            }
            .gaugeStyle(.linearCapacity)
            .tint(predictor.confidence > 0.75 ? .green : .orange) // Visual feedback for high confidence
            .padding(.horizontal)
            .animation(.easeInOut, value: predictor.confidence)
            
            // Button to trigger analysis
            Button {
                // Call async method in a Task
                Task {
                    await predictor.analyzeImage()
                }
            } label: {
                if predictor.isAnalyzing {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                } else {
                    Text("Analyze Image")
                }
            }
            .padding()
            .frame(minWidth: 150) // Ensure button has consistent width
            .background(predictor.isAnalyzing ? Color.gray : Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
            .disabled(predictor.isAnalyzing) // Disable button during analysis
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.white.opacity(0.05).ignoresSafeArea())
    }
}

// MARK: - Preview Provider
/*
@available(iOS 18.0, *)
#Preview {
    ImageRecognitionView()
}
*/
