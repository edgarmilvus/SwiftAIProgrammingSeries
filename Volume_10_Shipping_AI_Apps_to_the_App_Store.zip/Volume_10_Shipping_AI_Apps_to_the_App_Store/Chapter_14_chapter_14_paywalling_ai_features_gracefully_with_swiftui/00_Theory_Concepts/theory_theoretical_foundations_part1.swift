
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation

// MARK: - Models

/// Represents the current state of the user's access to AI resources.
/// Conforming to Sendable ensures this can be safely passed between the 
/// Entitlement Actor and the UI.
@Sendable
enum AIEntitlementStatus: Sendable {
    case authorized(remainingCredits: Int)
    case limited(remainingCredits: Int)
    case unauthorized(reason: String)
    case processing
}

// MARK: - The Gatekeeper (Actor)

/// The EntitlementActor is the single source of truth for all monetization logic.
/// It uses actor isolation to prevent race conditions when multiple AI requests
/// are made simultaneously.
actor EntitlementManager {
    private var credits: Int = 5
    private var isSubscribed: Bool = false
    
    /// Validates if a user can perform an AI action.
    /// This is an atomic operation.
    func validateRequest() async -> AIEntitlementStatus {
        // Simulate a small network delay for checking subscription status
        try? await Task.sleep(for: .milliseconds(100))
        
        if isSubscribed {
            return .authorized(remainingCredits: Int.max)
        }
        
        if credits > 0 {
            return .limited(remainingCredits: credits)
        } else {
            return .unauthorized(reason: "Out of credits. Please upgrade to continue.")
        }
    }
    
    /// Deducts a credit after a successful AI generation.
    func consumeCredit() {
        if !isSubscribed {
            credits -= 1
        }
    }
    
    func upgrade() {
        isSubscribed = true
    }
}

// MARK: - The State Orchestrator (@Observable)

/// The ViewModel acts as the bridge between the Actor (Logic) and the View (UI).
/// Using @Observable allows for granular UI updates.
@Observable
@available(iOS 18.0, *)
final class AIViewModel {
    private let entitlementManager = EntitlementManager()
    
    // These properties are observed by the SwiftUI views.
    var status: AIEntitlementStatus = .authorized(remainingCredits: 5)
    var isGenerating: Bool = false
    var outputText: String = ""
    
    /// The core workflow: Validate -> Execute -> Update
    func generateAIContent(prompt: String) async {
        // 1. Check Entitlement (The Pre-Flight Check)
        let currentStatus = await entitlementManager.validateRequest()
        
        // Update UI state to reflect the check
        await MainActor.run {
            self.status = currentStatus
        }
        
        // 2. Handle Unauthorized State
        guard case .authorized, .limited = currentStatus else {
            return // The view will react to the status change and show the paywall
        }
        
        // 3. Execute AI Task (The Flight)
        await MainActor.run { self.isGenerating = true }
        
        let result = await performInference(prompt: prompt)
        
        // 4. Finalize (The Landing)
        await entitlementManager.consumeCredit()
        let newStatus = await entitlementManager.validateRequest()
        
        await MainActor.run {
            self.outputText = result
            self.isGenerating = false
            self.status = newStatus
        }
    }
    
    private func performInference(prompt: String) async -> String {
        // Simulate heavy AI workload
        try? await Task.sleep(for: .seconds(2))
        return "AI Response to: \(prompt)"
    }
    
    func purchaseSubscription() async {
        await entitlementManager.upgrade()
        let newStatus = await entitlementManager.validateRequest()
        await MainActor.run {
            self.status = newStatus
        }
    }
}

// MARK: - The UI Layer (SwiftUI)

@available(iOS 18.0, *)
struct AIControlView: View {
    @State private var viewModel = AIViewModel()
    @State private var prompt: String = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("AI Assistant")
                .font(.largeTitle)
            
            ScrollView {
                Text(viewModel.outputText)
                    .padding()
            }
            .frame(maxHeight: .infinity)
            .background(Color.secondary.opacity(0.1))
            
            TextField("Enter prompt...", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .disabled(viewModel.isGenerating)
            
            if viewModel.isGenerating {
                ProgressView("Thinking...")
            } else {
                Button("Generate") {
                    Task {
                        await viewModel.generateAIContent(prompt: prompt)
                    }
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        // The Graceful Paywall Overlay
        .overlay {
            if case .unauthorized(let reason) = viewModel.status {
                PaywallOverlay(reason: reason) {
                    Task {
                        await viewModel.purchaseSubscription()
                    }
                }
            } else if case .limited(let credits) = viewModel.status {
                Text("Credits remaining: \(credits)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct PaywallOverlay: View {
    let reason: String
    let action: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Limit Reached")
                    .font(.headline)
                Text(reason)
                    .multilineTextAlignment(.center)
                Button("Upgrade Now", action: action)
                    .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(20)
        }
    }
}
