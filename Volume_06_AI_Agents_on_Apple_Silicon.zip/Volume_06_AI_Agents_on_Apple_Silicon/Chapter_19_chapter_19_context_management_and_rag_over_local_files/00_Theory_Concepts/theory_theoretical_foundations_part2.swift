
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import Foundation

    // Assuming a simple in-memory vector store for demonstration
    struct DocumentChunk: Identifiable, Hashable {
        let id: UUID = UUID()
        let text: String
        let embedding: [Float] // Simplified, in reality might be more complex
    }

    // A hypothetical helper for vector similarity (e.g., cosine similarity)
    func cosineSimilarity(vec1: [Float], vec2: [Float]) -> Float {
        guard !vec1.isEmpty && vec1.count == vec2.count else { return 0.0 }
        let dotProduct = zip(vec1, vec2).map(*).reduce(0, +)
        let magnitude1 = sqrt(vec1.map { $0 * $0 }.reduce(0, +))
        let magnitude2 = sqrt(vec2.map { $0 * $0 }.reduce(0, +))
        return magnitude1 == 0 || magnitude2 == 0 ? 0.0 : dotProduct / (magnitude1 * magnitude2)
    }

    @available(iOS 18.0, macOS 15.0, *)
    actor VectorStoreActor {
        private var chunks: [DocumentChunk] = []

        func add(chunk: String, embedding: [Float]) {
            let newChunk = DocumentChunk(text: chunk, embedding: embedding)
            chunks.append(newChunk)
            // In a real system, this would persist to disk or a more robust database
            print("Added chunk with ID: \(newChunk.id)")
        }

        func search(queryEmbedding: [Float], topK: Int) -> [String] {
            guard !chunks.isEmpty else { return [] }

            let rankedChunks = chunks.map { chunk in
                (chunk: chunk.text, similarity: cosineSimilarity(vec1: queryEmbedding, vec2: chunk.embedding))
            }
            .sorted { $0.similarity > $1.similarity } // Descending order of similarity

            return rankedChunks.prefix(topK).map { $0.chunk }
        }
    }
    