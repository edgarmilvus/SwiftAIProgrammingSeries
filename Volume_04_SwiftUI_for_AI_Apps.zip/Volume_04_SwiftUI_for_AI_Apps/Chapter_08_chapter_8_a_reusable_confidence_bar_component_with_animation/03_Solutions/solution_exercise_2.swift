
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

// MARK: - ConfidenceBar Component (from Exercise 1 - no changes needed for this exercise)

struct ConfidenceBar: View {
    let confidence: Double // Value between 0.0 and 1.0
    let barColor: Color
    let height: CGFloat = 20
    let cornerRadius: CGFloat = 8

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: height)

                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(barColor)
                    .frame(width: geometry.size.width * CGFloat(confidence), height: height)
                    .animation(.easeInOut(duration: 0.2), value: confidence) // Slightly faster animation for slider
            }
        }
        .frame(height: height)
    }
}

// MARK: - ContentView Integration

struct ContentView: View {
    // 1. Introduce a @State property for dynamic confidence
    @State private var currentConfidence: Double = 0.75

    var body: some View {
        VStack(spacing: 25) {
            Text("AI Model Confidence")
                .font(.title2)
                .fontWeight(.bold)

            // 2. Display the ConfidenceBar using the dynamic @State confidence
            ConfidenceBar(confidence: currentConfidence, barColor: .blue)
                .padding(.horizontal)

            // 3. Add a Slider to modify the currentConfidence
            Slider(value: $currentConfidence, in: 0.0...1.0, step: 0.01) {
                Text("Confidence Level") // Accessibility label
            } minimumValueLabel: {
                Text("0%")
            } maximumValueLabel: {
                Text("100%")
            }
            .padding(.horizontal)

            // 4. Add Percentage Label
            Text(String(format: "Confidence: %.0f%%", currentConfidence * 100))
                .font(.headline)
                .foregroundColor(.primary)
        }
        .padding() // Add overall padding to the VStack
    }
}

// MARK: - Preview Provider

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
