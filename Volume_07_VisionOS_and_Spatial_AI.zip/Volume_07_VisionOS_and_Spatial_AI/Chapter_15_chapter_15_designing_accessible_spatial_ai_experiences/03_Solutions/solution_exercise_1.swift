
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import RealityKit
import Foundation
import Combine

/// Represents a detected object with semantic metadata.
struct DetectedObjectMetadata: Sendable {
    let label: String
    let confidence: Float
    let spatialContext: String
}

/// A RealityKit entity that bridges 3D presence with semantic accessibility.
@MainActor
class SemanticSpatialEntity: Entity, HasModel, HasCollision {
    private var lastReportedConfidence: Float = 0.0
    private let confidenceThreshold: Float = 0.05 // 5% change required to update
    
    required init() {
        super.init()
    }
    
    init(model: ModelComponent, collision: CollisionComponent, metadata: DetectedObjectMetadata) {
        super.init()
        self.components.set(model)
        self.components.set(collision)
        updateAccessibility(with: metadata)
    }
    
    /// Updates the accessibility properties only if the change is significant.
    /// This prevents "accessibility jitter" in the VoiceOver engine.
    func updateAccessibility(with metadata: DetectedObjectMetadata) {
        // Check if the confidence change warrants an accessibility update
        let confidenceDelta = abs(metadata.confidence - lastReportedConfidence)
        
        guard confidenceDelta >= confidenceThreshold else { return }
        
        self.lastReportedConfidence = metadata.confidence
        
        // Construct a descriptive, spatially-aware label
        // Example: "Chair, 85% confidence, located to your front-left"
        let descriptiveLabel = "\(metadata.label), \(Int(metadata.confidence * 100))% confidence, \(metadata.spatialContext)"
        
        // In visionOS, we map semantic data to the accessibility properties
        // Note: In a real app, this interacts with the AccessibilityView/AccessibilityElement
        self.accessibilityLabel = descriptiveLabel
        self.accessibilityValue = "Confidence: \(Int(metadata.confidence * 100))%"
        
        print("Accessibility updated: \(descriptiveLabel)")
    }
}

// MARK: - Simulation
@MainActor
func simulateAIDetection() async {
    let boxMesh = MeshResource.generateBox(size: 0.2)
    let material = SimpleMaterial(color: .blue, isMetallic: true)
    let model = ModelComponent(mesh: boxMesh, materials: [material])
    let collision = CollisionComponent(shapes: [.generateBox(size: [0.2, 0.2, 0.2])])
    
    let entity = SemanticSpatialEntity(
        model: model,
        collision: collision,
        metadata: DetectedObjectMetadata(label: "Chair", confidence: 0.85, spatialContext: "to your front-left")
    )
    
    // Simulate a small AI update that should be ignored (jitter)
    entity.updateAccessibility(with: DetectedObjectMetadata(label: "Chair", confidence: 0.86, spatialContext: "to your front-left"))
    
    // Simulate a significant AI update that should be processed
    entity.updateAccessibility(with: DetectedObjectMetadata(label: "Chair", confidence: 0.95, spatialContext: "to your front-left"))
}
