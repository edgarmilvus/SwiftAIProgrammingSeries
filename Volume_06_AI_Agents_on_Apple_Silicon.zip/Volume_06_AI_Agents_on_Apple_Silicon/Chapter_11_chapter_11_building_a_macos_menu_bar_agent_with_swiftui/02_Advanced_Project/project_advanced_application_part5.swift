
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import AppKit // For NSPasteboard

// This is a conceptual SwiftUI View, not part of the required script component line count.
// It demonstrates how the CodeExplainerAgent would be used.

struct CodeExplainerView: View {
    @StateObject private var agent: CodeExplainerAgent

    // Inject the agent as an environment object or directly via initializer
    init(ollamaService: OllamaService) {
        _agent = StateObject(wrappedValue: CodeExplainerAgent(ollamaService: ollamaService))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Code Explainer Agent")
                .font(.headline)

            Picker("LLM Model:", selection: $agent.selectedModel) {
                Text("llama2").tag("llama2")
                Text("mistral").tag("mistral")
                Text("codellama").tag("codellama")
                // Add more models as supported by your Ollama instance
            }
            .pickerStyle(.menu)
            .padding(.horizontal)

            ScrollView {
                Text(agent.explanationText)
                    .font(.body)
                    .padding(5)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)
                    .textSelection(.enabled) // Allow copying the explanation
            }
            .frame(minHeight: 150, maxHeight: 300)

            if agent.isLoading {
                ProgressView("Fetching explanation...")
                    .progressViewStyle(.linear)
            }

            if let error = agent.errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .font(.caption)
            }

            Button("Explain Code from Clipboard") {
                Task {
                    await agent.explainCodeFromClipboard()
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(agent.isLoading)
        }
        .padding()
        .frame(width: 400, height: 450) // Typical popover size
    }
}

// Example usage in an App:
// @main
// struct CodeExplainerApp: App {
//     // Instantiate your OllamaAPIClient once
//     let ollamaClient = OllamaAPIClient(baseURLString: "http://localhost:11434")
//
//     var body: some Scene {
//         MenuBarExtra("Code Explainer", systemImage: "text.magnifyingglass") {
//             CodeExplainerView(ollamaService: ollamaClient)
//         }
//         .menuBarExtraStyle(.window)
//     }
// }
