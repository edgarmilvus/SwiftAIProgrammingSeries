
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import Foundation
import CoreML // Placeholder for Apple Intelligence TextGenerationService

// MARK: - Mock Data Store and Models

// Custom AppEnum for different summary purposes
@available(iOS 18.0, macOS 15.0, *)
enum SummaryPurpose: String, AppEnum, CaseIterable, Identifiable {
    case quickOverview = "Quick Overview"
    case actionItems = "Action Items"
    case responseDraft = "Response Draft"
    case keyDecisions = "Key Decisions"

    var id: String { rawValue }

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Summary Purpose"
    static var caseDisplayRepresentations: [Self: DisplayRepresentation] = [
        .quickOverview: "Quick Overview",
        .actionItems: "Action Items",
        .responseDraft: "Response Draft",
        .keyDecisions: "Key Decisions"
    ]

    // Provides a specific prompt prefix for the AI service
    var promptPrefix: String {
        switch self {
        case .quickOverview: return "Summarize the following email thread concisely, providing a quick overview."
        case .actionItems: return "Extract all action items, tasks, and responsible parties from this email thread. List them clearly."
        case .responseDraft: return "Summarize this email thread and suggest a polite, brief response acknowledging the main points and next steps."
        case .keyDecisions: return "Identify and list all key decisions made or discussed in this email thread."
        }
    }
}

// Represents an individual email message
struct EmailMessage: Identifiable, Hashable {
    let id = UUID()
    var sender: String
    var content: String
    var date: Date
}

// Represents an email thread
struct EmailThread: Identifiable, Hashable {
    let id = UUID()
    var subject: String
    var messages: [EmailMessage]

    // Aggregates all message content into a single string, ordered chronologically
    var aggregatedContent: String {
        messages
            .sorted(by: { $0.date < $1.date }) // Sort by date
            .map { "From: \($0.sender) (\($0.date.formatted()))\nContent: \($0.content)" }
            .joined(separator: "\n\n---\n\n")
    }
}

// In-memory mock data store for email threads
class EmailStore {
    static let shared = EmailStore()
    private var threads: [EmailThread] = [
        EmailThread(
            subject: "Project Phoenix Update",
            messages: [
                EmailMessage(sender: "Alice", content: "Team, the Phoenix UI designs are complete. Please review by EOD.", date: Date().addingTimeInterval(-86400 * 3)),
                EmailMessage(sender: "Bob", content: "Reviewed. Looks great, Alice! I'll start implementation on the login flow.", date: Date().addingTimeInterval(-86400 * 2)),
                EmailMessage(sender: "Charlie", content: "I'll handle the API integration for user profiles. Decision: we'll use GraphQL for the new endpoints.", date: Date().addingTimeInterval(-86400 * 1)),
                EmailMessage(sender: "Alice", content: "Great progress, team! Let's aim for a demo next Friday. Action item for Bob: complete login. Action item for Charlie: complete GraphQL API.", date: Date().addingTimeInterval(-3600))
            ]
        ),
        EmailThread(
            subject: "Team Meeting Agenda",
            messages: [
                EmailMessage(sender: "Manager", content: "Upcoming team meeting agenda: Project updates, Q4 planning, and new hire onboarding. Please come prepared.", date: Date().addingTimeInterval(-86400 * 5)),
                EmailMessage(sender: "Sarah", content: "I'd like to propose a discussion on improving our code review process.", date: Date().addingTimeInterval(-86400 * 4)),
                EmailMessage(sender: "Manager", content: "Good idea, Sarah. We'll add that to the agenda. Decision: we'll dedicate 15 mins to code review process discussion.", date: Date().addingTimeInterval(-86400 * 3))
            ]
        )
    ]

    func getThread(bySubject subject: String) -> EmailThread? {
        threads.first { $0.subject.localizedCaseInsensitiveContains(subject) }
    }
}

// MARK: - App Intent Implementation

@available(iOS 18.0, macOS 15.0, *)
struct SummarizeEmailThreadIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Email Thread"
    static var description = IntentDescription("Summarizes an email thread, with an option to specify the purpose of the summary (e.g., action items, quick overview).")
    static var openAppWhenRun: Bool = false

    @Parameter(title: "Thread Subject", description: "The subject of the email thread to summarize.")
    var threadSubject: String

    @Parameter(title: "Summary Purpose", description: "The specific purpose for the summary.", default: .quickOverview)
    var purpose: SummaryPurpose

    init() {}
    init(threadSubject: String, purpose: SummaryPurpose) {
        self.threadSubject = threadSubject
        self.purpose = purpose
    }

    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        guard let thread = EmailStore.shared.getThread(bySubject: threadSubject) else {
            throw AppIntentError.emailThreadNotFound(subject: threadSubject)
        }

        let fullThreadContent = thread.aggregatedContent
        let prompt = purpose.promptPrefix + "\n\nEmail Thread Content:\n" + fullThreadContent

        do {
            let summary = try await TextGenerationService.shared.generateSummary(for: fullThreadContent, prompt: prompt)
            return .result(value: summary, dialog: "Here's the \(purpose.rawValue.lowercased()) summary for '\(thread.subject)': \(summary)")
        } catch let error as TextGenerationService.TextGenerationError {
            throw AppIntentError.summarizationFailed(reason: error.description)
        } catch {
            throw AppIntentError.summarizationFailed(reason: "An unexpected error occurred during summarization: \(error.localizedDescription)")
        }
    }
}

// MARK: - Custom App Intent Errors (Extended for this exercise)

@available(iOS 18.0, macOS 15.0, *)
extension AppIntentError {
    static func emailThreadNotFound(subject: String) -> AppIntentError { .summarizationFailed(reason: "Could not find an email thread with the subject '\(subject)'.") }
}
