
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation
import NaturalLanguage

// MARK: - Data Models

/// Represents the outcome of a content moderation check.
/// Conforms to `Sendable` to ensure safe transfer across actor boundaries in Swift 6.
enum ModerationResult: Sendable, Equatable {
    /// The content is safe for all age ratings.
    case safe
    /// The content contains potentially sensitive material.
    case flagged(reason: String)
    /// The content is strictly prohibited (e.g., hate speech, explicit content).
    case blocked(reason: String)
}

/// A simple structure representing a message in our AI chat interface.
struct ChatMessage: Identifiable, Sendable {
    let id = UUID()
    let text: String
    let isUser: Bool
    let timestamp: Date
}

// MARK: - Moderation Engine

/// The `ContentModerator` is an `actor`, which provides isolation for its state.
/// In a real-world app, this actor would wrap a CoreML model or a call to a 
/// cloud-based moderation API (like OpenAI's Moderation endpoint).
///
/// Using an actor ensures that multiple concurrent moderation requests 
/// do not cause data races and that the heavy lifting happens off the Main Thread.
actor ContentModerator {
    
    /// A list of prohibited keywords for demonstration purposes.
    /// In production, this would be replaced by a sophisticated ML model.
    private let prohibitedTerms = ["badword", "violence", "illegal"]
    
    /// Analyzes a string to determine if it meets safety guidelines.
    /// - Parameter text: The raw input string from the user or AI.
    /// - Returns: A `ModerationResult` indicating the safety status.
    func moderate(_ text: String) async -> ModerationResult {
        // Simulate network or heavy ML processing latency
        try? await Task.sleep(for: .milliseconds(500))
        
        let lowercasedText = text.lowercased()
        
        // 1. Keyword Check (Basic Heuristics)
        for term in prohibitedTerms {
            if lowercasedText.contains(term) {
                return .blocked(reason: "Content contains prohibited language.")
            }
        }
        
        // 2. Sentiment/Toxicity Analysis (Using Apple's NaturalLanguage framework)
        // This demonstrates "Under the Hood" integration with on-device intelligence.
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text
        
        let (sentiment, _) = tagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentimentScore)
        
        if let sentimentScore = sentiment?.rawValue, let score = Double(sentimentScore) {
            // If sentiment is extremely negative, we flag it for review.
            // Note: In a real app, we'd use a specific Toxicity model.
            if score < -0.8 {
                return .flagged(reason: "Highly negative or aggressive tone detected.")
            }
        }
        
        return .safe
    }
}

// MARK: - View Model

/// The `ChatViewModel` manages the application state and coordinates between the UI and the Moderator.
/// It is marked with `@MainActor` to ensure all UI updates happen on the main thread.
@Observable
@MainActor
class ChatViewModel {
    var messages: [ChatMessage] = []
    var inputText: String = ""
    var isProcessing: Bool = false
    var errorMessage: String?
    
    /// The moderator is isolated in an actor, but we hold a reference to it here.
    private let moderator = ContentModerator()
    
    /// Processes the user's input: Moderates it, then "sends" it to the AI.
    /// - Parameter input: The text entered by the user.
    func sendMessage() async {
        let textToProcess = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !textToProcess.isEmpty else { return }
        
        isProcessing = true
        errorMessage = nil
        
        // Step 1: Perform Input Moderation
        // We call the actor method. This is an 'await' because the work is off-thread.
        let moderationStatus = await moderator.moderate(textToProcess)
        
        switch moderationStatus {
        case .safe:
            // Step 2: If safe, add to chat and simulate AI response
            let userMsg = ChatMessage(text: textToProcess, isUser: true, timestamp: .now)
            messages.append(userMsg)
            inputText = "" // Clear input
            
            await simulateAIResponse(to: textToProcess)
            
        case .flagged(let reason):
            errorMessage = "Warning: \(reason)"
            // We might still allow the message but log it for compliance.
            let userMsg = ChatMessage(text: textToProcess, isUser: true, timestamp: .now)
            messages.append(userMsg)
            inputText = ""
            
        case .blocked(let reason):
            errorMessage = "Blocked: \(reason)"
            // Do NOT add the message to the chat.
        }
        
        isProcessing = false
    }
    
    /// Simulates a response from an AI model.
    private func simulateAIResponse(to originalText: String) async {
        // In a real app, this is where your LLM API call happens.
        let aiResponseText = "I received your message: '\(originalText)'. How can I help further?"
        
        // Step 3: Perform Output Moderation (Post-processing)
        // Even if the user is safe, the AI might generate unsafe content.
        let aiModeration = await moderator.moderate(aiResponseText)
        
        if case .safe = aiModeration {
            let aiMsg = ChatMessage(text: aiResponseText, isUser: false, timestamp: .now)
            messages.append(aiMsg)
        } else {
            let aiMsg = ChatMessage(text: "[Content removed due to safety filters]", isUser: false, timestamp: .now)
            messages.append(aiMsg)
        }
    }
}

// MARK: - UI Layer

@available(iOS 18.0, *)
struct ChatView: View {
    @State private var viewModel = ChatViewModel()
    
    var body: some View {
        NavigationStack {
            VStack {
                // Message List
                ScrollViewReader { proxy in
                    List(viewModel.messages) { message in
                        ChatBubble(message: message)
                            .listRowSeparator(.hidden)
                            .id(message.id)
                    }
                    .onChange(of: viewModel.messages.count) {
                        if let lastId = viewModel.messages.last?.id {
                            withAnimation { proxy.scrollTo(lastId, anchor: .bottom) }
                        }
                    }
                }
                
                // Error/Warning Display
                if let error = viewModel.errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.horizontal)
                        .transition(.opacity)
                }
                
                // Input Area
                HStack {
                    TextField("Type a message...", text: $viewModel.inputText)
                        .textFieldStyle(.roundedBorder)
                        .disabled(viewModel.isProcessing)
                    
                    if viewModel.isProcessing {
                        ProgressView()
                            .padding(.horizontal, 5)
                    } else {
                        Button(action: {
                            Task { await viewModel.sendMessage() }
                        }) {
                            Image(systemName: "paperplane.fill")
                                .font(.title2)
                        }
                        .disabled(viewModel.inputText.isEmpty)
                    }
                }
                .padding()
            }
            .navigationTitle("AI Safety Chat")
        }
    }
}

/// A simple view component for chat bubbles.
struct ChatBubble: View {
    let message: ChatMessage
    
    var body: some View {
        HStack {
            if message.isUser { Spacer() }
            
            Text(message.text)
                .padding(12)
                .background(message.isUser ? Color.blue : Color.gray.opacity(0.2))
                .foregroundColor(message.isUser ? .white : .primary)
                .cornerRadius(16)
            
            if !message.isUser { Spacer() }
        }
    }
}

#Preview {
    ChatView()
}
