
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// MARK: - 1. Device State Simulation

enum DeviceType: String, Codable {
    case light = "light"
    case thermostat = "thermostat"
}

struct SmartDeviceState: Codable {
    var type: DeviceType
    var isOn: Bool
    var brightness: Int? // For lights
    var temperature: Double? // For thermostats
    
    // Initializer to ensure correct state based on type
    init(type: DeviceType, isOn: Bool, brightness: Int? = nil, temperature: Double? = nil) {
        self.type = type
        self.isOn = isOn
        switch type {
        case .light:
            self.brightness = brightness ?? (isOn ? 100 : 0)
            self.temperature = nil
        case .thermostat:
            self.temperature = temperature ?? (isOn ? 22.0 : 0.0)
            self.brightness = nil
        }
    }
    
    var description: String {
        var status = "\(isOn ? "On" : "Off")"
        if let brightness = brightness {
            status += ", Brightness: \(brightness)%"
        }
        if let temperature = temperature {
            status += ", Temperature: \(temperature)°C"
        }
        return "\(type.rawValue.capitalized) is \(status)"
    }
}

// In-memory store for device states
var smartDeviceStates: [String: SmartDeviceState] = [
    "Living Room Lights": SmartDeviceState(type: .light, isOn: true, brightness: 80),
    "Bedroom Lamp": SmartDeviceState(type: .light, isOn: false, brightness: 0),
    "Hallway Thermostat": SmartDeviceState(type: .thermostat, isOn: true, temperature: 21.5),
    "Kitchen Lights": SmartDeviceState(type: .light, isOn: true, brightness: 100)
]

// MARK: - 2. Tool Definitions (Swift Functions)

enum SmartHomeError: Error, CustomStringConvertible {
    case deviceNotFound(name: String)
    case invalidDeviceType(name: String, expected: DeviceType, actual: DeviceType)
    case invalidBrightness(level: Int)
    case invalidTemperature(temperature: Double)
    case missingParameter(parameterName: String)
    
    var description: String {
        switch self {
        case .deviceNotFound(let name): return "Device '\(name)' not found."
        case .invalidDeviceType(let name, let expected, let actual): return "Device '\(name)' is a \(actual.rawValue), but expected a \(expected.rawValue)."
        case .invalidBrightness(let level): return "Brightness level \(level) is out of range (0-100%)."
        case .invalidTemperature(let temp): return "Temperature \(temp) is outside typical thermostat range."
        case .missingParameter(let param): return "Missing required parameter: '\(param)'."
        }
    }
}

func turnOnDevice(name: String) throws -> String {
    guard var device = smartDeviceStates[name] else {
        throw SmartHomeError.deviceNotFound(name: name)
    }
    device.isOn = true
    if device.type == .light && device.brightness == 0 {
        device.brightness = 100 // Default to full brightness when turning on light
    } else if device.type == .thermostat && device.temperature == 0 {
        device.temperature = 22.0 // Default to comfortable temp when turning on thermostat
    }
    smartDeviceStates[name] = device
    return "\(name) turned ON. Current state: \(device.description)"
}

func turnOffDevice(name: String) throws -> String {
    guard var device = smartDeviceStates[name] else {
        throw SmartHomeError.deviceNotFound(name: name)
    }
    device.isOn = false
    if device.type == .light {
        device.brightness = 0 // Turn off light by setting brightness to 0
    } else if device.type == .thermostat {
        device.temperature = 0.0 // Turn off thermostat by setting temp to 0
    }
    smartDeviceStates[name] = device
    return "\(name) turned OFF. Current state: \(device.description)"
}

func setBrightness(name: String, level: Int) throws -> String {
    guard var device = smartDeviceStates[name] else {
        throw SmartHomeError.deviceNotFound(name: name)
    }
    guard device.type == .light else {
        throw SmartHomeError.invalidDeviceType(name: name, expected: .light, actual: device.type)
    }
    guard (0...100).contains(level) else {
        throw SmartHomeError.invalidBrightness(level: level)
    }
    
    device.brightness = level
    device.isOn = (level > 0) // Turn on if brightness > 0
    smartDeviceStates[name] = device
    return "\(name) brightness set to \(level)%. Current state: \(device.description)"
}

func setThermostatTemperature(name: String, temperature: Double) throws -> String {
    guard var device = smartDeviceStates[name] else {
        throw SmartHomeError.deviceNotFound(name: name)
    }
    guard device.type == .thermostat else {
        throw SmartHomeError.invalidDeviceType(name: name, expected: .thermostat, actual: device.type)
    }
    guard (10.0...30.0).contains(temperature) else { // Realistic temp range
        throw SmartHomeError.invalidTemperature(temperature: temperature)
    }
    
    device.temperature = temperature
    device.isOn = (temperature > 0) // Turn on if temp > 0
    smartDeviceStates[name] = device
    return "\(name) temperature set to \(temperature)°C. Current state: \(device.description)"
}

// MARK: - 3. Tool Description (JSON Schema - Manual Representation)

let smartHomeToolSchemas: [String: [String: Any]] = [
    "turnOnDevice": [
        "type": "function",
        "function": [
            "name": "turnOnDevice",
            "description": "Turns on a specified smart home device.",
            "parameters": [
                "type": "object",
                "properties": [
                    "name": ["type": "string", "description": "The name of the device (e.g., 'Living Room Lights', 'Hallway Thermostat')"]
                ],
                "required": ["name"]
            ]
        ]
    ],
    "turnOffDevice": [
        "type": "function",
        "function": [
            "name": "turnOffDevice",
            "description": "Turns off a specified smart home device.",
            "parameters": [
                "type": "object",
                "properties": [
                    "name": ["type": "string", "description": "The name of the device"]
                ],
                "required": ["name"]
            ]
        ]
    ],
    "setBrightness": [
        "type": "function",
        "function": [
            "name": "setBrightness",
            "description": "Sets the brightness level (0-100%) for a light device.",
            "parameters": [
                "type": "object",
                "properties": [
                    "name": ["type": "string", "description": "The name of the light device"],
                    "level": ["type": "integer", "description": "The brightness level as a percentage (0-100)"]
                ],
                "required": ["name", "level"]
            ]
        ]
    ],
    "setThermostatTemperature": [
        "type": "function",
        "function": [
            "name": "setThermostatTemperature",
            "description": "Sets the target temperature for a thermostat device.",
            "parameters": [
                "type": "object",
                "properties": [
                    "name": ["type": "string", "description": "The name of the thermostat device"],
                    "temperature": ["type": "number", "description": "The target temperature in Celsius (e.g., 22.5)"]
                ],
                "required": ["name", "temperature"]
            ]
        ]
    ]
]

// MARK: - 4. LLM Integration (Mocking LLM Output with parameter handling)

// Generic Codable structs for flexible tool call parsing
struct GenericToolArguments: Codable {
    let name: String?
    let level: Int? // For brightness
    let temperature: Double? // For thermostat
    
    // Custom decoding to handle missing parameters gracefully
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.level = try container.decodeIfPresent(Int.self, forKey: .level)
        self.temperature = try container.decodeIfPresent(Double.self, forKey: .temperature)
    }
}

struct GenericToolCall: Codable {
    let toolName: String
    let arguments: GenericToolArguments
}

// Simulate LLM's response
func simulateLLMSmartHomeToolCall(for prompt: String) -> GenericToolCall? {
    if prompt.contains("turn on") {
        if prompt.contains("living room lights") {
            return GenericToolCall(toolName: "turnOnDevice", arguments: GenericToolArguments(name: "Living Room Lights", level: nil, temperature: nil))
        } else if prompt.contains("bedroom lamp") {
            return GenericToolCall(toolName: "turnOnDevice", arguments: GenericToolArguments(name: "Bedroom Lamp", level: nil, temperature: nil))
        } else if prompt.contains("thermostat") { // Missing device name
            return GenericToolCall(toolName: "turnOnDevice", arguments: GenericToolArguments(name: nil, level: nil, temperature: nil))
        }
    } else if prompt.contains("turn off") {
        if prompt.contains("kitchen lights") {
            return GenericToolCall(toolName: "turnOffDevice", arguments: GenericToolArguments(name: "Kitchen Lights", level: nil, temperature: nil))
        }
    } else if prompt.contains("set brightness") || prompt.contains("dim") {
        if prompt.contains("bedroom lamp to 50%") {
            return GenericToolCall(toolName: "setBrightness", arguments: GenericToolArguments(name: "Bedroom Lamp", level: 50, temperature: nil))
        } else if prompt.contains("living room lights to 120%") { // Invalid brightness
            return GenericToolCall(toolName: "setBrightness", arguments: GenericToolArguments(name: "Living Room Lights", level: 120, temperature: nil))
        } else if prompt.contains("lights to 70%") { // Missing device name
            return GenericToolCall(toolName: "setBrightness", arguments: GenericToolArguments(name: nil, level: 70, temperature: nil))
        }
    } else if prompt.contains("set thermostat") || prompt.contains("temperature") {
        if prompt.contains("hallway thermostat to 22 degrees") {
            return GenericToolCall(toolName: "setThermostatTemperature", arguments: GenericToolArguments(name: "Hallway Thermostat", level: nil, temperature: 22.0))
        } else if prompt.contains("hallway thermostat to 5 degrees") { // Invalid temperature
            return GenericToolCall(toolName: "setThermostatTemperature", arguments: GenericToolArguments(name: "Hallway Thermostat", level: nil, temperature: 5.0))
        }
    }
    return nil
}

// MARK: - 5. Tool Execution & Conversational Context

var currentPendingToolCall: GenericToolCall? = nil // Simulate conversational state

func executeSmartHomeToolCall(toolCall: GenericToolCall) -> String {
    do {
        switch toolCall.toolName {
        case "turnOnDevice":
            guard let name = toolCall.arguments.name else {
                currentPendingToolCall = toolCall // Store for clarification
                throw SmartHomeError.missingParameter(parameterName: "name")
            }
            return try turnOnDevice(name: name)
        case "turnOffDevice":
            guard let name = toolCall.arguments.name else {
                currentPendingToolCall = toolCall
                throw SmartHomeError.missingParameter(parameterName: "name")
            }
            return try turnOffDevice(name: name)
        case "setBrightness":
            guard let name = toolCall.arguments.name else {
                currentPendingToolCall = toolCall
                throw SmartHomeError.missingParameter(parameterName: "name")
            }
            guard let level = toolCall.arguments.level else {
                currentPendingToolCall = toolCall
                throw SmartHomeError.missingParameter(parameterName: "level")
            }
            return try setBrightness(name: name, level: level)
        case "setThermostatTemperature":
            guard let name = toolCall.arguments.name else {
                currentPendingToolCall = toolCall
                throw SmartHomeError.missingParameter(parameterName: "name")
            }
            guard let temperature = toolCall.arguments.temperature else {
                currentPendingToolCall = toolCall
                throw SmartHomeError.missingParameter(parameterName: "temperature")
            }
            return try setThermostatTemperature(name: name, temperature: temperature)
        default:
            return "Unknown smart home tool: \(toolCall.toolName)"
        }
    } catch let error as SmartHomeError {
        return "Error executing tool '\(toolCall.toolName)': \(error.description)"
    } catch {
        return "An unexpected error occurred: \(error.localizedDescription)"
    }
}

// Function to try to complete a pending tool call with new info
func completePendingToolCall(with newInfo: String) -> String? {
    guard var pendingCall = currentPendingToolCall else { return nil }
    
    // This is a very simplified way to "fill in" missing info for a mock.
    // A real LLM would re-evaluate the prompt with context.
    // Here, we just assume newInfo is the missing 'name'.
    if pendingCall.arguments.name == nil {
        pendingCall = GenericToolCall(toolName: pendingCall.toolName, arguments: GenericToolArguments(name: newInfo, level: pendingCall.arguments.level, temperature: pendingCall.arguments.temperature))
        currentPendingToolCall = nil // Clear after attempting to complete
        return executeSmartHomeToolCall(toolCall: pendingCall)
    }
    return nil
}


// MARK: - Main Interaction Flow (Simulation)

func processUserSmartHomePrompt(prompt: String) {
    print("User: \(prompt)")
    
    if let toolCall = simulateLLMSmartHomeToolCall(for: prompt) {
        print("LLM suggests tool call: \(toolCall.toolName) with arguments: \(String(describing: toolCall.arguments.name ?? "nil")), \(String(describing: toolCall.arguments.level ?? nil)), \(String(describing: toolCall.arguments.temperature ?? nil))")
        let executionResult = executeSmartHomeToolCall(toolCall: toolCall)
        
        if executionResult.contains("Missing required parameter") {
            print("AI Assistant: I need more information to complete that. Which device are you referring to?")
            // The `currentPendingToolCall` is now set, waiting for the next turn.
        } else {
            currentPendingToolCall = nil // Clear pending call on successful execution
            print("Tool Execution Result: \(executionResult)")
            print("AI Assistant: \(executionResult)")
        }
    } else if let pendingResult = completePendingToolCall(with: prompt) { // Check if previous turn was asking for info
        print("Attempting to complete previous command with: \(prompt)")
        if pendingResult.contains("Missing required parameter") { // Still missing
             print("AI Assistant: I still need more information. Can you be more specific?")
        } else {
            print("Tool Execution Result: \(pendingResult)")
            print("AI Assistant: \(pendingResult)")
            currentPendingToolCall = nil
        }
    }
    else {
        print("AI Assistant: I can't find a suitable smart home tool for that request.")
    }
    print("---")
}

// Test cases
print("--- Initial Device States ---")
smartDeviceStates.forEach { name, state in
    print("\(name): \(state.description)")
}
print("----------------------------\n")

processUserSmartHomePrompt(prompt: "Turn on the living room lights.")
processUserSmartHomePrompt(prompt: "Set the bedroom lamp to 50%.")
processUserSmartHomePrompt(prompt: "Set the hallway thermostat to 22 degrees.")
processUserSmartHomePrompt(prompt: "Turn off the kitchen lights.")
processUserSmartHomePrompt(prompt: "Dim the living room lights to 0%.") // Turn off via brightness
processUserSmartHomePrompt(prompt: "Turn on the bedroom lamp.") // Turn on
processUserSmartHomePrompt(prompt: "Set the living room lights to 120%.") // Invalid brightness
processUserSmartHomePrompt(prompt: "Set the hallway thermostat to 5 degrees.") // Invalid temperature
processUserSmartHomePrompt(prompt: "Turn on the AC.") // Device not found

// Conversational turn-taking simulation:
processUserSmartHomePrompt(prompt: "Turn on the thermostat.") // Missing device name
processUserSmartHomePrompt(prompt: "Hallway Thermostat.") // Providing the missing name
processUserSmartHomePrompt(prompt: "Set lights to 70%.") // Missing device name
processUserSmartHomePrompt(prompt: "Bedroom Lamp.") // Providing the missing name
processUserSmartHomePrompt(prompt: "What's the weather?") // No smart home tool
