
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import ARKit
import RealityKit
import Combine
import Foundation

// 1. Define the Semantic Component
struct SemanticComponent: Component, Sendable {
    var personality: String
    var lastFeedback: String = ""
}

// 2. Manager to handle hand tracking and interaction logic
@MainActor
class SemanticInteractionManager: ObservableObject {
    private var handTrackingProvider: HandTrackingProvider?
    private var session: HandTrackingSession?
    private var subscriptions = Set<AnyCancellable>()
    
    // Thresholds for Hysteresis
    private let pinchStartThreshold: Float = 0.02 // 2cm to start
    private let pinchReleaseThreshold: Float = 0.03 // 3cm to release
    private var isPinching = false
    private var attachedEntity: Entity?
    
    // The Trigger Zone (Spatial Boundary)
    private let triggerZoneBounds = BoundingBox(min: [-0.5, -0.5, -0.5], max: [0.5, 0.5, 0.5])
    
    func setup(session: HandTrackingSession, scene: Scene) {
        self.session = session
        
        // Subscribe to hand anchor updates
        session.anchorsPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] anchors in
                self?.update(with: anchors, in: scene)
            }
            .store(in: &subscriptions)
    }
    
    private func update(with anchors: [HandAnchor], in scene: Scene) {
        guard let handAnchor = anchors.first(where: { $0.chirality == .right }) else { return }
        
        let thumbTip = handAnchor.handSkeleton.joint(.thumbTip).anchorPose.position
        let indexTip = handAnchor.handSkeleton.joint(.indexFingerTip).anchorPose.position
        let distance = simd_distance(thumbTip, indexTip)
        
        // Implement Hysteresis logic
        if !isPinching && distance < pinchStartThreshold {
            isPinching = true
            attemptAttachment(at: indexTip, in: scene)
        } else if isPinching && distance > pinchReleaseThreshold {
            isPinching = false
            attachedEntity = nil
        }
        
        // If attached, move entity to hand position
        if isPinching, let entity = attachedEntity {
            entity.position = indexTip
            checkTriggerZone(for: entity)
        }
    }
    
    private func attemptAttachment(at position: SIMD3<Float>, in scene: Scene) {
        // Find nearest entity with SemanticComponent
        let hitEntities = scene.performHitTest(at: position) // Simplified for logic
        if let target = hitEntities.first(where: { $0.components.has(SemanticComponent.self) }) {
            attachedEntity = target
        }
    }
    
    private func checkTriggerZone(for entity: Entity) {
        guard entity.components.has(SemanticComponent.self) else { return }
        
        // Check if entity is within the invisible trigger box
        if triggerZoneBounds.contains(entity.position) {
            triggerAIResponse(for: entity)
        }
    }
    
    private func triggerAIResponse(for entity: Entity) {
        Task {
            // Mock AI Latency and Inference
            try? await Task.sleep(for: .seconds(1))
            let responses = ["I feel much more stable here!", "This spot is quite cozy.", "The lighting is perfect!"]
            let feedback = responses.randomElement() ?? "..."
            
            // Update component (requires re-setting component in RealityKit)
            var semantic = entity.components[SemanticComponent.self]!
            semantic.lastFeedback = feedback
            entity.components[SemanticComponent.self] = semantic
            
            print("AI Feedback: \(feedback)")
        }
    }
}

// Helper for bounding box logic
struct BoundingBox {
    let min: SIMD3<Float>
    let max: SIMD3<Float>
    func contains(_ point: SIMD3<Float>) -> Bool {
        return point.x >= min.x && point.x <= max.x &&
               point.y >= min.y && point.y <= max.y &&
               point.z >= min.z && point.z <= max.z
    }
}
