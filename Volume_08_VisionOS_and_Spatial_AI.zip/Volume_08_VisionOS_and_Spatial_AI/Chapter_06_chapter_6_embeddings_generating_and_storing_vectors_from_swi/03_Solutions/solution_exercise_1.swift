
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// A type alias representing a high-dimensional vector.
typealias Vector = [Float]

/// Encapsulates the relationship between original text and its semantic vector.
struct TextEmbedding: Sendable {
    let text: String
    let vector: Vector
}

/// Custom errors specific to the embedding lifecycle.
enum EmbeddingError: Error, LocalizedError {
    case emptyInput
    case textTooLong
    case networkFailure(Error)
    case invalidResponse
    case decodingError

    var errorDescription: String? {
        switch self {
        case .emptyInput: return "The input text cannot be empty."
        case .textTooLong: return "The input text exceeds the maximum allowed character limit."
        case .networkFailure(let error): return "Network error: \(error.localizedDescription)"
        case .invalidResponse: return "The server returned an invalid response."
        case .decodingError: return "Failed to decode the embedding vector."
        }
    }
}

/// A protocol defining the requirements for an embedding provider, 
/// allowing for easy swapping between OpenAI, Anthropic, or Local models.
protocol EmbeddingProvider: Sendable {
    func generateEmbedding(for text: String) async throws -> Vector
}

/// An actor-based service to ensure thread-safe access to embedding operations.
actor TextEmbeddingService: EmbeddingProvider {
    private let apiKey: String
    private let endpoint = URL(string: "https://api.openai.com/v1/embeddings")!
    private let maxCharacterLimit = 8000
    private let session: URLSession

    init(apiKey: String, session: URLSession = .shared) {
        self.apiKey = apiKey
        self.session = session
    }

    func generateEmbedding(for text: String) async throws -> Vector {
        // 1. Validation
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw EmbeddingError.emptyInput
        }
        
        guard text.count <= maxCharacterLimit else {
            throw EmbeddingError.textTooLong
        }

        // 2. Prepare Request
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "input": text,
            "model": "text-embedding-3-small"
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        // 3. Execute Network Call
        let (data, response) = try await session.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw EmbeddingError.invalidResponse
        }

        // 4. Decode Response
        // Note: In a real app, use Codable structs instead of JSONSerialization
        do {
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            let dataObject = json?["data"] as? [[String: Any]]
            let vectorArray = dataObject?.first?["embedding"] as? [Float]
            
            guard let vector = vectorArray else { throw EmbeddingError.decodingError }
            return vector
        } catch {
            throw EmbeddingError.decodingError
        }
    }
}
