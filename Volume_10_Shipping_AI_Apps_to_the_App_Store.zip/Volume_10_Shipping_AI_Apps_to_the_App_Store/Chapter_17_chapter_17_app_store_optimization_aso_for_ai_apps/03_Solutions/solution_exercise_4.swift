
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import OSLog
import NaturalLanguage

/// Represents a single telemetry data point.
struct PerformanceMetric: Sendable {
    let inferenceDuration: TimeInterval
    let modelType: String
    let sentimentScore: Double // -1.0 to 1.0
}

actor PerformanceASOTracker {
    private let logger = Logger(subsystem: "com.echomind.aso", category: "Telemetry")
    private var metrics: [PerformanceMetric] = []
    private let frustrationThreshold: TimeInterval = 4.5
    
    func logInference(duration: TimeInterval, modelType: String, userReviewText: String?) {
        // 1. Perform Sentiment Analysis
        let sentiment = analyzeSentiment(for: userReviewText)
        
        let metric = PerformanceMetric(
            inferenceDuration: duration,
            modelType: modelType,
            sentimentScore: sentiment
        )
        
        metrics.append(metric)
        logger.info("Logged: \(duration)s | Sentiment: \(sentiment)")
        
        // 2. Check for critical correlation
        checkCorrelation()
    }
    
    private func analyzeSentiment(for text: String?) -> Double {
        guard let text = text, !text.isEmpty else { return 0.0 }
        
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text
        let (sentiment, _) = tagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentimentScore)
        
        return Double(sentiment?.rawValue ?? "0.0") ?? 0.0
    }
    
    private func checkCorrelation() {
        // Find metrics where latency > threshold
        let highLatencyMetrics = metrics.filter { $0.inferenceDuration > frustrationThreshold }
        
        guard !highLatencyMetrics.isEmpty else { return }
        
        let avgSentiment = highLatencyMetrics.reduce(0.0) { $0 + $1.sentimentScore } / Double(highLatencyMetrics.count)
        
        if avgSentiment < -0.2 {
            triggerAlert(averageSentiment: avgSentiment)
        }
    }
    
    private func triggerAlert(averageSentiment: Double) {
        logger.critical("🚨 ASO RISK DETECTED: Latency > \(self.frustrationThreshold)s correlates with sentiment: \(averageSentiment)")
        print("ALERT: Performance is tanking your App Store rating!")
    }
    
    func getSummary() -> String {
        let avgLatency = metrics.reduce(0.0) { $0 + $1.inferenceDuration } / Double(metrics.count)
        let avgSentiment = metrics.reduce(0.0) { $0 + $1.sentimentScore } / Double(metrics.count)
        return "Avg Latency: \(String(format: "%.2f", avgLatency))s | Avg Sentiment: \(String(format: "%.2f", avgSentiment))"
    }
}

// MARK: - Execution
@MainActor
func simulateUserBehavior() async {
    let tracker = PerformanceASOTracker()
    
    print("Simulating fast responses...")
    await tracker.logInference(duration: 1.2, modelType: "On-Device", userReviewText: "This is amazing and fast!")
    
    print("Simulating slow responses...")
    await tracker.logInference(duration: 5.5, modelType: "Cloud", userReviewText: "Way too slow, I hate waiting.")
    await tracker.logInference(duration: 6.2, modelType: "Cloud", userReviewText: "Extremely frustrating experience.")
    
    print("\nFinal Summary: \(await tracker.getSummary())")
}

await simulateUserBehavior()
