
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation

@available(iOS 18.0, *)
class LinearLayer: MLXNN.Module {
    let weight: MLXArray
    let bias: MLXArray?

    // Initializer to set up parameters
    required init(inputFeatures: Int, outputFeatures: Int, hasBias: Bool = true) {
        // Initialize weights with random values, marked as trainable
        self.weight = MLXArray.rand([outputFeatures, inputFeatures], .float32)
        // Initialize bias if requested
        self.bias = hasBias ? MLXArray.zeros([outputFeatures], .float32) : nil
        super.init() // Call super.init()
    }

    // The forward pass method
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        var output = matmul(weight, input) // Matrix multiplication
        if let bias = bias {
            output = output + bias // Add bias
        }
        return output
    }
}

@available(iOS 18.0, *)
func demonstrateModule() {
    let inputData = MLXArray.rand([10, 5], .float32) // Batch size 10, 5 features
    let linear = LinearLayer(inputFeatures: 5, outputFeatures: 3)

    let output = linear(inputData)
    print("Output shape from LinearLayer: \(output.shape)") // Should be [10, 3]
}
