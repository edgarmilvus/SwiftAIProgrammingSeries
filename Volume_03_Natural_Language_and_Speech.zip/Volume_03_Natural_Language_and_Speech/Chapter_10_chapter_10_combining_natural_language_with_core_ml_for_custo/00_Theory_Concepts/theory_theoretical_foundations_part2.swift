
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import NaturalLanguage
    import CoreML

    @available(iOS 18.0, *)
    actor SentimentAnalyzerActor {
        private var model: NLModel?
        private let modelName: String

        init(modelName: String) {
            self.modelName = modelName
        }

        private func ensureModelLoaded() async throws {
            if model == nil {
                guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodel") else {
                    throw NSError(domain: "SentimentAnalyzerActor", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not found"])
                }
                self.model = try await NLModel.load(mlModel: modelURL)
            }
        }

        func analyzeSentiment(for text: String) async throws -> String {
            try await ensureModelLoaded()
            guard let model = self.model else {
                throw NSError(domain: "SentimentAnalyzerActor", code: 2, userInfo: [NSLocalizedDescriptionKey: "Model could not be loaded"])
            }
            return try await model.predictedLabel(for: text)
        }
    }

    @available(iOS 18.0, *)
    func analyzeMultipleTexts() async {
        let analyzer = SentimentAnalyzerActor(modelName: "MyCustomSentimentModel")

        await withTaskGroup(of: (String, String?).self) { group in
            let texts = [
                "I love this new feature!",
                "It's okay, nothing special.",
                "This is terrible, I hate it.",
                "Absolutely amazing experience."
            ]

            for text in texts {
                group.addTask {
                    do {
                        let sentiment = try await analyzer.analyzeSentiment(for: text)
                        return (text, sentiment)
                    } catch {
                        print("Error analyzing '\(text)': \(error.localizedDescription)")
                        return (text, nil)
                    }
                }
            }

            for await (text, sentiment) in group {
                if let sentiment = sentiment {
                    print("Text: '\(text)' -> Sentiment: \(sentiment)")
                } else {
                    print("Failed to analyze text: '\(text)'")
                }
            }
        }
    }
    