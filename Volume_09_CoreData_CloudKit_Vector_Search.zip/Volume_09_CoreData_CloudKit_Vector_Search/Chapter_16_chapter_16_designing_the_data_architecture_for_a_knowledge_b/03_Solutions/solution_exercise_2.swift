
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CoreData
import Combine

@MainActor
class SyncMonitor: ObservableObject {
    @Published var isSyncing: Bool = false
    @Published var lastSyncDate: Date?
    
    private var cancellables = Set<AnyCancellable>()

    init() {
        setupObservers()
    }

    private func setupObservers() {
        // Observe remote changes from CloudKit
        NotificationCenter.default.publisher(for: .NSPersistentStoreRemoteChange)
            .sink { [weak self] _ in
                self?.handleRemoteChange()
            }
            .store(in: &cancellables)
    }

    private func handleRemoteChange() {
        // In a production app, you would trigger a merge or UI refresh here
        self.lastSyncDate = Date()
        print("Remote data detected via CloudKit.")
    }
}

class CloudPersistenceController {
    static let shared = CloudPersistenceController()
    let container: NSPersistentCloudKitContainer

    init() {
        container = NSPersistentCloudKitContainer(name: "LexiconModel")

        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve store description")
        }

        // 1. Enable Remote Change Notifications for CloudKit
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        // 2. Enable History Tracking (Required for CloudKit syncing)
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)

        container.loadPersistentStores { _, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error)")
            }
        }

        // 3. Conflict Resolution Policy
        // We use MergeByPropertyObjectTrump to prioritize the in-memory changes over the store
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        container.viewContext.automaticallyMergesChangesFromParent = true
    }
    
    /// Example of adding an attachment with external storage logic
    /// Note: 'Allows External Storage' is configured in the .xcdatamodeld
    func addAttachment(to node: Node, fileURL: URL) async throws {
        let context = container.newBackgroundContext()
        try await context.perform {
            let attachment = Attachment(context: context)
            attachment.createdAt = Date()
            
            // Core Data handles the heavy lifting of moving this to a separate file 
            // and managing the CKAsset upload via CloudKit automatically.
            attachment.fileData = try Data(contentsOf: fileURL)
            attachment.node = node
            
            try context.save()
        }
    }
}

// MARK: - Entity Mock
@objc(Attachment)
public class Attachment: NSManagedObject, Sendable {
    // Attributes: fileData (Data - "Allows External Storage" enabled), createdAt (Date)
    // Relationships: node (Node)
}
