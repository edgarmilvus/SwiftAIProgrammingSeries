
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet (Illustrative, not strictly needed for CoreML/Vision)
// This would be part of a larger project's Package.swift
// If you were using a custom utility library for, say, image processing beyond Vision,
// you might include it here.

/*
import PackageDescription

let package = Package(
    name: "SmartDocumentScanner",
    platforms: [
        .iOS(.v18) // Targeting iOS 18.0 for latest Swift 6 features and APIs
    ],
    products: [
        .library(
            name: "SmartDocumentScannerCore",
            targets: ["SmartDocumentScannerCore"]),
    ],
    dependencies: [
        // Example: If you had a custom image utility library
        // .package(url: "https://github.com/yourorg/ImageProcessingUtils.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "SmartDocumentScannerCore",
            dependencies: [
                // If 'ImageProcessingUtils' was a dependency, it would be listed here
                // .product(name: "ImageProcessingUtils", package: "ImageProcessingUtils")
            ]),
        .testTarget(
            name: "SmartDocumentScannerCoreTests",
            dependencies: ["SmartDocumentScannerCore"]),
    ]
)
*/
