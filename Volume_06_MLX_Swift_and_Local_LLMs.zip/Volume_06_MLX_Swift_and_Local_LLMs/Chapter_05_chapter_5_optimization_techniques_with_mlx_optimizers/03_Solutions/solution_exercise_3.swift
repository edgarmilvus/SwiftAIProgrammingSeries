
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// Package.swift snippet for MLX Swift dependency
// dependencies: [
//     .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.0.1")
// ]

import MLX
import MLXNN // For MLXNN.Module, MLXNN.Linear

@available(iOS 18.0, macOS 15.0, *)
func exercise3_styleTransferFineTuning() {
    let featureDim = 64 // Dimension of feature vectors representing images

    // 1. Simplified Model Architecture
    // ContentEncoder: Simulates a pre-trained, fixed feature extractor
    class ContentEncoder: MLXNN.Module {
        let linear: MLXNN.Linear
        init(inputFeatures: Int, outputFeatures: Int) {
            self.linear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
            super.init()
        }
        func callAsFunction(_ input: MLXArray) -> MLXArray {
            return relu(linear(input)) // Simple activation
        }
    }

    // StyleAdapter: The module to be fine-tuned
    class StyleAdapter: MLXNN.Module {
        let transform: MLXNN.Linear
        init(inputFeatures: Int, outputFeatures: Int) {
            self.transform = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
            super.init()
        }
        func callAsFunction(_ contentFeatures: MLXArray) -> MLXArray {
            return relu(transform(contentFeatures)) // Adapts content features
        }
    }

    // Combined Model: Composes the encoder and adapter
    class StyleTransferModel: MLXNN.Module {
        let contentEncoder: ContentEncoder
        let styleAdapter: StyleAdapter

        init(inputFeatures: Int, contentFeatures: Int, styleFeatures: Int) {
            self.contentEncoder = ContentEncoder(inputFeatures: inputFeatures, outputFeatures: contentFeatures)
            self.styleAdapter = StyleAdapter(inputFeatures: contentFeatures, outputFeatures: styleFeatures)
            super.init()
        }

        func callAsFunction(_ input: MLXArray) -> MLXArray {
            let encodedContent = contentEncoder(input) // Pass through fixed encoder
            let styledFeatures = styleAdapter(encodedContent) // Pass through trainable adapter
            return styledFeatures
        }
    }

    // 2. Generate Synthetic Data
    func generateSyntheticStyleData(numSamples: Int, featureDim: Int) -> (MLXArray, MLXArray, MLXArray) {
        let inputs = MLXArray.random([numSamples, featureDim], stream: .current, dtype: .float32)
        // Simulate content targets (features that should be preserved from original image)
        let contentTargets = inputs + MLXArray.random([numSamples, featureDim], min: -0.1, max: 0.1, stream: .current, dtype: .float32)
        // Simulate style targets (distinct features representing a desired style)
        let styleTargets = MLXArray.random([numSamples, featureDim], min: 0.5, max: 1.0, stream: .current, dtype: .float32)

        return (inputs, contentTargets, styleTargets)
    }

    let numSamples = 50
    let (inputs, contentTargets, styleTargets) = generateSyntheticStyleData(numSamples: numSamples, featureDim: featureDim)

    // 3. Define a Custom Loss Function
    func styleTransferLoss(
        modelOutput: MLXArray, contentTarget: MLXArray, styleTarget: MLXArray,
        contentWeight: Float, styleWeight: Float
    ) -> MLXArray {
        let contentLoss = (modelOutput - contentTarget).square().mean() // MSE for content preservation
        let styleLoss = (modelOutput - styleTarget).square().mean()     // MSE for style matching
        return contentLoss * contentWeight + styleLoss * styleWeight    // Weighted combination
    }

    // 4. Implement the Fine-Tuning Loop
    let model = StyleTransferModel(inputFeatures: featureDim, contentFeatures: featureDim, styleFeatures: featureDim)

    // Crucially, select ONLY the parameters of the StyleAdapter for optimization
    let adapterParameters = model.styleAdapter.parameters()

    let learningRate: Float = 0.001
    let weightDecay: Float = 0.01 // Weight decay for AdamW
    let optimizer = MLXOptimizers.AdamW(learningRate: learningRate, weightDecay: weightDecay) // AdamW optimizer
    let numEpochs = 300

    let contentWeight: Float = 1.0
    let styleWeight: Float = 2.0 // Give more importance to style learning

    print("Starting fine-tuning of StyleAdapter...")
    print("Initial StyleAdapter Weight (first 5): \(model.styleAdapter.transform.weight.flattened().take(5))")

    for epoch in 0..<numEpochs {
        // Compute loss and gradients using valueAndGradient, specifying ONLY adapterParameters
        let (loss, gradients) = valueAndGradient(parameters: adapterParameters) {
            let predictions = model(inputs) // Forward pass through combined model
            return styleTransferLoss(
                modelOutput: predictions, contentTarget: contentTargets, styleTarget: styleTargets,
                contentWeight: contentWeight, styleWeight: styleWeight
            )
        }

        // Apply gradients ONLY to the style adapter's parameters
        optimizer.update(parameters: adapterParameters, gradients: gradients)

        if epoch % 50 == 0 {
            print("Epoch \(epoch), Total Loss: \(loss.item(Float.self)!)")
        }
    }

    print("\nFine-tuning complete!")
    print("Final StyleAdapter Weight (first 5): \(model.styleAdapter.transform.weight.flattened().take(5))")

    // The contentEncoder's parameters remain unchanged as they were not passed to the optimizer.
    // This demonstrates parameter-efficient fine-tuning.
}
