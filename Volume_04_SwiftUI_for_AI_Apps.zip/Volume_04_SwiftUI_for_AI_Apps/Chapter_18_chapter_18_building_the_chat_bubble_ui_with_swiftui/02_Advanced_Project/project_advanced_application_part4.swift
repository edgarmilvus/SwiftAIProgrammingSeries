
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

/// A utility class to simulate an AI service that streams `MessageContent`.
/// This mimics how a real AI model might send back text tokens and tool calls.
class AIServiceSimulator {
    /// Simulates an AI response, streaming text tokens and potentially a tool call suggestion.
    /// - Parameters:
    ///   - fullResponse: The complete text response to stream.
    ///   - toolCall: An optional `ToolCallSuggestion` to be emitted after the text.
    /// - Returns: An `AsyncThrowingStream` of `MessageContent` items.
    func simulateAITokenStream(
        fullResponse: String,
        toolCall: ToolCallSuggestion? = nil
    ) -> AsyncThrowingStream<MessageContent, Error> {
        AsyncThrowingStream { continuation in
            Task {
                // Simulate streaming text token by token
                for (index, char) in fullResponse.enumerated() {
                    try await Task.sleep(for: .milliseconds(50)) // Simulate network latency
                    continuation.yield(.text(String(char)))
                    
                    // Introduce an error randomly for demonstration
                    if index > fullResponse.count / 2 && Int.random(in: 1...100) == 1 {
                        continuation.finish(throwing: NSError(domain: "AIService", code: 500, userInfo: [NSLocalizedDescriptionKey: "Simulated network error"]))
                        return
                    }
                }
                
                // If a tool call exists, emit it after the text stream
                if let toolCall = toolCall {
                    try await Task.sleep(for: .milliseconds(300)) // Pause before tool call
                    continuation.yield(.toolCallSuggestion(toolCall))
                }
                
                continuation.finish() // Signal the end of the stream
            }
        }
    }
}
