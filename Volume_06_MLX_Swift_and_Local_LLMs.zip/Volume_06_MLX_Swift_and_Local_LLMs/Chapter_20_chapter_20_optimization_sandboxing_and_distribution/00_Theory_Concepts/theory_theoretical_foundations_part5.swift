
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import SwiftUI

@available(iOS 18.0, *)
@Observable
class FineTuningProgress {
    var status: String = "Idle"
    var currentLoss: Float = 0.0
    var progress: Double = 0.0 // 0.0 to 1.0

    // Imagine a method that updates these properties during fine-tuning
    func startFineTuning() async {
        self.status = "Starting..."
        // Simulate fine-tuning steps
        for i in 0..<10 {
            try? await Task.sleep(for: .milliseconds(200))
            await MainActor.run {
                self.status = "Training epoch \(i+1)/10"
                self.currentLoss = Float.random(in: 0.1...(0.5 - Float(i)*0.03)) // Decreasing loss
                self.progress = Double(i + 1) / 10.0
            }
        }
        await MainActor.run {
            self.status = "Completed!"
            self.progress = 1.0
        }
    }
}

// SwiftUI View that observes the progress
/*
@available(iOS 18.0, *)
struct FineTuningView: View {
    @State private var progress = FineTuningProgress()

    var body: some View {
        VStack {
            Text(progress.status)
            ProgressView(value: progress.progress)
            Text("Current Loss: \(progress.currentLoss, specifier: "%.4f")")
            Button("Start Fine-Tuning") {
                Task {
                    await progress.startFineTuning()
                }
            }
        }
    }
}
*/
