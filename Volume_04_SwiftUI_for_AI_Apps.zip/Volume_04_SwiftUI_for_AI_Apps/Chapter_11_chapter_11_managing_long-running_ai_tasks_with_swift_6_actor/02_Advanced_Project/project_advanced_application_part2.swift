
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *) // Targeting iOS 18 for future-proofing and consistency
import Foundation

// MARK: - 1. Data Models and Error Types

/// Represents a document to be processed.
/// Conforms to `Sendable` as it will be passed across concurrency domains.
struct Document: Identifiable, Hashable, Sendable {
    let id: UUID
    let name: String
    let content: String // Simplified: actual content would be URL to file or Data
    
    init(id: UUID = UUID(), name: String, content: String) {
        self.id = id
        self.name = name
        self.content = content
    }
}

/// Represents the comprehensive AI analysis result for a document.
/// Conforms to `Sendable` for safe sharing.
struct AIDocumentAnalysisResult: Identifiable, Hashable, Sendable {
    let id: UUID // Corresponds to the Document's ID
    let ocrText: String
    let sentiment: String // e.g., "Positive", "Neutral", "Negative"
    let keywords: [String]
    let analysisDate: Date
    
    init(id: UUID, ocrText: String, sentiment: String, keywords: [String], analysisDate: Date = Date()) {
        self.id = id
        self.ocrText = ocrText
        self.sentiment = sentiment
        self.keywords = keywords
        self.analysisDate = analysisDate
    }
}

/// Custom error types for AI processing, providing localized descriptions.
/// Conforms to `Sendable` for safe propagation across tasks.
enum AIProcessingError: Error, LocalizedError, Sendable {
    case ocrFailed(String)
    case sentimentAnalysisFailed(String)
    case keywordExtractionFailed(String)
    case documentNotFound(UUID)
    case processingCancelled
    case unexpectedResult(String)
    
    var errorDescription: String? {
        switch self {
        case .ocrFailed(let reason):
            return "OCR processing failed: \(reason)"
        case .sentimentAnalysisFailed(let reason):
            return "Sentiment analysis failed: \(reason)"
        case .keywordExtractionFailed(let reason):
            return "Keyword extraction failed: \(reason)"
        case .documentNotFound(let id):
            return "Document with ID \(id) not found for processing."
        case .processingCancelled:
            return "Document processing was cancelled."
        case .unexpectedResult(let reason):
            return "Unexpected result during AI processing: \(reason)"
        }
    }
}

// MARK: - 2. Simulated AI Document Processor

/// A `Sendable` class simulating a long-running AI model inference.
/// In a real application, this would interact with Core ML models or a remote AI service.
/// It's a class, not an actor, because its methods are pure functions (or interact with external systems)
/// and don't manage mutable internal state that requires actor isolation.
class AIDocumentProcessor: Sendable {
    
    /// Simulates performing OCR on document content.
    /// Introduces artificial delay and a small chance of failure.
    /// - Parameter content: The textual content of the document.
    /// - Returns: The extracted OCR text.
    /// - Throws: `AIProcessingError.ocrFailed` if OCR simulation fails.
    func performOCR(content: String) async throws -> String {
        // Simulate network delay or complex computation
        try await Task.sleep(for: .seconds(Double.random(in: 1.0...3.0)))
        
        // Simulate potential failure
        if Bool.random(probability: 0.05) { // 5% chance of OCR failing
            throw AIProcessingError.ocrFailed("Random OCR engine error.")
        }
        
        // Simple mock OCR: just returns the content as "OCR text"
        return "OCR Text for '\(content.prefix(20))...':\n\(content)"
    }
    
    /// Simulates performing sentiment analysis on text.
    /// Introduces artificial delay and a small chance of failure.
    /// - Parameter text: The text to analyze.
    /// - Returns: The sentiment (e.g., "Positive", "Neutral", "Negative").
    /// - Throws: `AIProcessingError.sentimentAnalysisFailed` if sentiment analysis simulation fails.
    func analyzeSentiment(text: String) async throws -> String {
        try await Task.sleep(for: .seconds(Double.random(in: 0.5...1.5)))
        
        if Bool.random(probability: 0.03) { // 3% chance of sentiment analysis failing
            throw AIProcessingError.sentimentAnalysisFailed("Sentiment model overload.")
        }
        
        // Simple mock sentiment: based on a keyword
        if text.lowercased().contains("excellent") || text.lowercased().contains("great") || text.lowercased().contains("positive") {
            return "Positive"
        } else if text.lowercased().contains("bad") || text.lowercased().contains("error") || text.lowercased().contains("negative") {
            return "Negative"
        } else {
            return "Neutral"
        }
    }
    
    /// Simulates extracting keywords from text.
    /// Introduces artificial delay and a small chance of failure.
    /// - Parameter text: The text to extract keywords from.
    /// - Returns: An array of extracted keywords.
    /// - Throws: `AIProcessingError.keywordExtractionFailed` if keyword extraction simulation fails.
    func extractKeywords(text: String) async throws -> [String] {
        try await Task.sleep(for: .seconds(Double.random(in: 0.8...2.0)))
        
        if Bool.random(probability: 0.02) { // 2% chance of keyword extraction failing
            throw AIProcessingError.keywordExtractionFailed("Keyword extraction service unavailable.")
        }
        
        // Simple mock keyword extraction
        let words = text.lowercased().components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty && $0.count > 3 && $0.count < 15 } // Filter out short/long words
        let uniqueWords = Set(words)
        return Array(uniqueWords.sorted().prefix(5)) // Return up to 5 unique, sorted keywords
    }
}

// Helper for random boolean to simulate failures
extension Bool {
    static func random(probability: Double) -> Bool {
        return Double.random(in: 0.0...1.0) < probability
    }
}

// MARK: - 3. The AIScanningCoordinator Actor

/// Represents the current status of a document processing job.
/// Conforms to `Sendable` for safe sharing, especially with `AsyncStream`.
enum DocumentProcessingStatus: Sendable, Equatable {
    case pending
    case processing(progress: Double)
    case completed(AIDocumentAnalysisResult)
    case failed(Error)
    case cancelled
    
    // Custom Equatable conformance to ignore associated error values for comparison
    static func == (lhs: DocumentProcessingStatus, rhs: DocumentProcessingStatus) -> Bool {
        switch (lhs, rhs) {
        case (.pending, .pending): return true
        case (.processing(let p1), .processing(let p2)): return p1 == p2 // Compare progress
        case (.completed(let r1), .completed(let r2)): return r1 == r2
        case (.failed(_), .failed(_)): return true // Treat all failed states as equal for simplicity
        case (.cancelled, .cancelled): return true
        default: return false
        }
    }
}

/// The `AIScanningCoordinator` actor manages the lifecycle of AI document processing tasks.
/// It handles queuing, concurrent processing, result storage, and progress reporting.
actor AIScanningCoordinator {
    
    /// Internal state for pending documents awaiting initial processing.
    private var pendingDocumentIDs: [UUID] = []
    
    /// Internal state mapping document IDs to their current processing status.
    /// This state is exclusively managed by the actor, ensuring thread safety.
    private var documentProcessingStatuses: [UUID: DocumentProcessingStatus] = [:]
    
    /// Internal state for completed analysis results.
    private var completedAnalysisResults: [UUID: AIDocumentAnalysisResult] = [:]
    
    /// An instance of `AIDocumentProcessor` to perform the actual AI work.
    /// It's a `Sendable` class, so it can be safely used within the actor.
    private let aiProcessor = AIDocumentProcessor()
    
    /// A dictionary to hold `Task` references for ongoing processing, enabling cancellation.
    private var processingTasks: [UUID: Task<Void, Never>] = [:]
    
    // MARK: - Public API for UI/App Logic and Progress Reporting
    
    /// A private `AsyncStream.Continuation` to push status updates to subscribers.
    /// This is the write-end of the `AsyncStream`.
    private var statusContinuation: AsyncStream<[UUID: DocumentProcessingStatus]>.Continuation?
    
    /// A `lazy var` `AsyncStream` that provides real-time updates on document processing status.
    /// This allows the UI to subscribe to changes without directly polling the actor.
    /// `lazy` ensures the stream is only created when first accessed, and the continuation is captured.
    lazy var processingStatusUpdates: AsyncStream<[UUID: DocumentProcessingStatus]> = {
        AsyncStream { continuation in
            self.statusContinuation = continuation
            // `onTermination` callback ensures resources are cleaned up when the stream is no longer observed.
            continuation.onTermination = { @Sendable [weak self] _ in
                Task { await self?.handleStreamTermination() }
            }
        }
    }()
    
    /// Handles stream termination, ensuring the `statusContinuation` is nilled out.
    /// This prevents attempts to yield to a terminated stream.
    private func handleStreamTermination() {
        print("AIScanningCoordinator: Processing status stream terminated.")
        statusContinuation = nil
        // In a more aggressive cleanup, you might cancel all pending tasks here.
    }
    
    /// Initializes the `AIScanningCoordinator`.
    init() {
        print("AIScanningCoordinator initialized.")
    }
    
    /// Deinitializer to ensure the `AsyncStream` continuation is properly finished.
    deinit {
        print("AIScanningCoordinator deinitialized.")
        statusContinuation?.finish() // Signal that no more updates will be sent.
    }
    
    /// Adds a document to the processing queue and initiates its analysis.
    /// A new `Task` is spawned for each document to allow concurrent processing of multiple documents,
    /// while the actor's methods ensure serial access to its internal state.
    /// - Parameter document: The `Document` to be processed.
    func addDocumentForProcessing(_ document: Document) async {
        print("Coordinator: Received document '\(document.name)' (ID: \(document.id.uuidString.prefix(4)))... for processing.")
        pendingDocumentIDs.append(document.id)
        documentProcessingStatuses[document.id] = .pending
        updateStatusStream() // Notify subscribers about the new pending document.
        
        // Spawn a new detached Task for each document. This allows the actor to immediately
        // accept more documents without waiting for the current one to finish processing.
        let task = Task {
            await processDocument(document)
        }
        processingTasks[document.id] = task // Store the task for potential cancellation.
    }
    
    /// Cancels the processing of a specific document.
    /// - Parameter documentID: The ID of the document to cancel.
    func cancelProcessing(for documentID: UUID) async {
        guard let task = processingTasks[documentID] else {
            print("Coordinator: No active task found for document ID \(documentID).")
            return
        }
        
        print("Coordinator: Attempting to cancel processing for document ID \(documentID).")
        task.cancel() // Request cancellation of the underlying task.
        // Update status immediately to reflect cancellation intent.
        documentProcessingStatuses[documentID] = .cancelled
        updateStatusStream()
        // The actual task will observe `Task.isCancelled` and update its final status.
    }
    
    /// Retrieves the current status of a specific document.
    /// - Parameter documentID: The ID of the document.
    /// - Returns: The `DocumentProcessingStatus` for the given document, or `nil` if not found.
    func getDocumentStatus(for documentID: UUID) async -> DocumentProcessingStatus? {
        return documentProcessingStatuses[documentID]
    }
    
    /// Retrieves all completed analysis results.
    /// - Returns: A dictionary of document IDs to `AIDocumentAnalysisResult`.
    func getAllCompletedResults() async -> [UUID: AIDocumentAnalysisResult] {
        return completedAnalysisResults
    }
    
    // MARK: - Internal Processing Logic
    
    /// Processes a single document through multiple AI steps.
    /// This method runs within a `Task` spawned by `addDocumentForProcessing`.
    /// It updates the actor's state serially and reports progress via the `AsyncStream`.
    /// - Parameter document: The `Document` to process.
    private func processDocument(_ document: Document) async {
        let documentID = document.id
        print("Coordinator: Starting processing for document '\(document.name)' (ID: \(documentID.uuidString.prefix(4)))...")
        
        // Remove from pending queue as it's now actively being processed.
        pendingDocumentIDs.removeAll { $0 == documentID }
        
        do {
            // Check for cancellation at the start of the processing pipeline.
            try Task.checkCancellation()
            
            var ocrText: String?
            var sentiment: String?
            var keywords: [String]?
            
            // Step 1: Perform OCR. This is often a prerequisite for other NLP tasks.
            await updateStatus(for: documentID, with: .processing(progress: 0.1))
            ocrText = try await aiProcessor.performOCR(content: document.content)
            print("Coordinator: OCR completed for \(documentID.uuidString.prefix(4))...")
            
            // Check for cancellation after OCR.
            try Task.checkCancellation()
            await updateStatus(for: documentID, with: .processing(progress: 0.3))
            
            // Step 2 & 3: With OCR text available, perform Sentiment Analysis and Keyword Extraction concurrently
            // using a `TaskGroup`. This demonstrates internal concurrency within a single document's processing task.
            await withTaskGroup(of: (String, Any?, Error?).self) { innerGroup in
                innerGroup.addTask {
                    do {
                        print("Coordinator: Starting Sentiment for \(documentID.uuidString.prefix(4))...")
                        await self.updateStatus(for: documentID, with: .processing(progress: 0.4))
                        let s = try await self.aiProcessor.analyzeSentiment(text: ocrText!)
                        print("Coordinator: Sentiment completed for \(documentID.uuidString.prefix(4))...")
                        return ("sentiment", s, nil)
                    } catch {
                        print("Coordinator: Sentiment failed for \(documentID.uuidString.prefix(4))...: \(error.localizedDescription)")
                        return ("sentiment", nil, error)
                    }
                }
                
                innerGroup.addTask {
                    do {
                        print("Coordinator: Starting Keywords for \(documentID.uuidString.prefix(4))...")
                        await self.updateStatus(for: documentID, with: .processing(progress: 0.5))
                        let k = try await self.aiProcessor.extractKeywords(text: ocrText!)
                        print("Coordinator: Keywords completed for \(documentID.uuidString.prefix(4))...")
                        return ("keywords", k, nil)
                    } catch {
                        print("Coordinator: Keywords failed for \(documentID.uuidString.prefix(4))...: \(error.localizedDescription)")
                        return ("keywords", nil, error)
                    }
                }
                
                // Collect results from the TaskGroup. If any sub-task throws, propagate the error.
                for await (type, result, error) in innerGroup {
                    if Task.isCancelled {
                        // If the parent task was cancelled, propagate cancellation.
                        throw AIProcessingError.processingCancelled
                    }
                    if let error = error {
                        throw error // Propagate the first error encountered from sub-tasks.
                    }
                    
                    switch type {
                    case "sentiment": sentiment = result as? String
                    case "keywords": keywords = result as? [String]
                    default: break
                    }
                }
            } // End of inner TaskGroup
            
            // Final check for cancellation before concluding.
            try Task.checkCancellation()
            
            // Ensure all required results are present.
            guard let finalOcrText = ocrText,
                  let finalSentiment = sentiment,
                  let finalKeywords = keywords else {
                throw AIProcessingError.unexpectedResult("One or more AI sub-tasks did not return expected results.")
            }
            
            // Construct the final analysis result.
            let result = AIDocumentAnalysisResult(
                id: documentID,
                ocrText: finalOcrText,
                sentiment: finalSentiment,
                keywords: finalKeywords
            )
            
            await updateStatus(for: documentID, with: .processing(progress: 0.9))
            await completeProcessing(for: documentID, with: result)
            print("Coordinator: Successfully processed document '\(document.name)' (ID: \(documentID.uuidString.prefix(4)))...")
            
        } catch is CancellationError {
            // Catch Swift's built-in CancellationError, which `Task.checkCancellation()` throws.
            await failProcessing(for: documentID, with: AIProcessingError.processingCancelled)
            print("Coordinator: Processing for document '\(document.name)' (ID: \(documentID.uuidString.prefix(4)))... was cancelled.")
        } catch {
            // Catch any other errors and mark the document as failed.
            await failProcessing(for: documentID, with: error)
            print("Coordinator: Failed to process document '\(document.name)' (ID: \(documentID.uuidString.prefix(4)))...: \(error.localizedDescription)")
        }
        
        // Always remove the task from the tracking dictionary after its lifecycle concludes.
        await removeProcessingTask(for: documentID)
    }
    
    /// Helper method to update a document's status and notify `AsyncStream` subscribers.
    /// This method is an actor-isolated function, ensuring safe state modification.
    /// - Parameters:
    ///   - documentID: The ID of the document.
    ///   - status: The new `DocumentProcessingStatus`.
    private func updateStatus(for documentID: UUID, with status: DocumentProcessingStatus) {
        documentProcessingStatuses[documentID] = status
        updateStatusStream()
    }
    
    /// Helper method to mark a document as completed and store its analysis result.
    /// - Parameters:
    ///   - documentID: The ID of the document.
    ///   - result: The `AIDocumentAnalysisResult`.
    private func completeProcessing(for documentID: UUID, with result: AIDocumentAnalysisResult) {
        completedAnalysisResults[documentID] = result
        documentProcessingStatuses[documentID] = .completed(result)
        updateStatusStream()
    }
    
    /// Helper method to mark a document as failed due to an error.
    /// - Parameters:
    ///   - documentID: The ID of the document.
    ///   - error: The `Error` that occurred.
    private func failProcessing(for documentID: UUID, with error: Error) {
        documentProcessingStatuses[documentID] = .failed(error)
        updateStatusStream()
    }
    
    /// Helper method to remove a processing task from the tracking dictionary.
    /// - Parameter documentID: The ID of the document whose task should be removed.
    private func removeProcessingTask(for documentID: UUID) {
        processingTasks.removeValue(forKey: documentID)
    }
    
    /// Notifies the `AsyncStream` subscribers about the updated processing statuses.
    /// This is the mechanism for the actor to push state changes out to the UI.
    private func updateStatusStream() {
        // Yield a copy of the current statuses to the stream.
        statusContinuation?.yield(documentProcessingStatuses)
    }
}

// MARK: - 4. Application Context (Simulated UI Interaction with ViewModel)

/// A class representing a ViewModel for a SwiftUI View or UIKit ViewController.
/// It interacts with the `AIScanningCoordinator` actor and updates `@Published` properties
/// on the `MainActor` for UI binding.
@available(iOS 18.0, macOS 15.0, *)
@MainActor // Ensures all published properties and UI updates happen on the main thread.
class DocumentScannerViewModel: ObservableObject {
    @Published var documentStatuses: [UUID: DocumentProcessingStatus] = [:]
    @Published var completedResults: [UUID: AIDocumentAnalysisResult] = [:]
    @Published var documentsToProcess: [Document] = [] // Tracks documents added by the user
    
    private let coordinator: AIScanningCoordinator
    private var statusObservationTask: Task<Void, Never>? // Task to observe the AsyncStream
    
    init(coordinator: AIScanningCoordinator) {
        self.coordinator = coordinator
        
        // Start observing the coordinator's status updates in a detached Task.
        // `for await` loop consumes the AsyncStream.
        statusObservationTask = Task { [weak self] in
            // Accessing actor properties requires `await`.
            for await statuses in await coordinator.processingStatusUpdates {
                // All UI updates must happen on the MainActor.
                // Since `DocumentScannerViewModel` is `@MainActor`, this `self?.documentStatuses = statuses`
                // is implicitly on the MainActor.
                self?.documentStatuses = statuses
                // Also update completed results if a document moved to .completed
                for (id, status) in statuses {
                    if case .completed(let result) = status {
                        self?.completedResults[id] = result
                    }
                }
            }
        }
    }
    
    /// Deinitializes the ViewModel, ensuring the observation task is cancelled.
    deinit {
        statusObservationTask?.cancel()
        print("DocumentScannerViewModel deinitialized.")
    }
    
    /// Simulates adding a new document from the UI.
    /// Calls the actor method, which is `async`.
    func addDocument(name: String, content: String) async {
        let newDocument = Document(name: name, content: content)
        await coordinator.addDocumentForProcessing(newDocument)
        documentsToProcess.append(newDocument) // Update local list for UI
    }
    
    /// Simulates cancelling a document processing from the UI.
    /// Calls the actor method, which is `async`.
    func cancelDocumentProcessing(id: UUID) async {
        await coordinator.cancelProcessing(for: id)
    }
    
    /// Simulates refreshing all completed results (e.g., for a "Processed Documents" view).
    /// Calls the actor method, which is `async`.
    func refreshCompletedResults() async {
        let results = await coordinator.getAllCompletedResults()
        self.completedResults = results
    }
}

// MARK: - 5. Main Application Entry Point (Simulation)

/// Runs a simulation of the AI Document Scanner app.
@available(iOS 18.0, macOS 15.0, *)
func runAIScannerAppSimulation() async {
    print("--- Starting AI Document Scanner Simulation ---")
    
    let coordinator = AIScanningCoordinator()
    // ViewModel is initialized with the coordinator.
    // Its `statusObservationTask` will immediately start listening to the coordinator.
    let viewModel = DocumentScannerViewModel(coordinator: coordinator)
    
    // Simulate UI observing updates by printing to console.
    // This task will run concurrently with the document processing.
    Task {
        // The viewModel.$documentStatuses.values is an AsyncSequence for @Published properties.
        for await _ in viewModel.$documentStatuses.values {
            // Ensure UI updates are on MainActor, which is already handled by @MainActor on ViewModel
            print("\n--- Current Document Statuses (UI Update) ---")
            if viewModel.documentStatuses.isEmpty {
                print("No documents being processed.")
            } else {
                for (id, status) in viewModel.documentStatuses.sorted(by: { $0.key.uuidString < $1.key.uuidString }) {
                    let shortID = id.uuidString.prefix(4)
                    switch status {
                    case .pending: print("  Document \(shortID)...: Pending")
                    case .processing(let progress): print("  Document \(shortID)...: Processing (\(Int(progress * 100))%)")
                    case .completed(let result): print("  Document \(shortID)...: Completed. Sentiment: \(result.sentiment)")
                    case .failed(let error): print("  Document \(shortID)...: FAILED! \(error.localizedDescription)")
                    case .cancelled: print("  Document \(shortID)...: CANCELLED.")
                    }
                }
            }
            print("------------------------------------------")
        }
    }
    
    // Simulate adding documents from the UI. These calls are `async` and will suspend
    // until the actor's `addDocumentForProcessing` method completes its serial work.
    await viewModel.addDocument(name: "Meeting Notes", content: "The team had an excellent meeting discussing Q3 strategy. We identified key areas for improvement and new growth opportunities. Everyone is very positive about the future.")
    await viewModel.addDocument(name: "Legal Contract", content: "This contract outlines terms and conditions between Party A and Party B. Any breach of terms may result in penalties. Payment is due within 30 days. This is a very important document.")
    await viewModel.addDocument(name: "Research Paper", content: "A new study on Swift 6 actors and their application in AI. The results show significant performance improvements and enhanced concurrency safety. This is a great step forward for reactive AI apps.")
    
    // Simulate cancelling one document after a short delay.
    await Task.sleep(for: .seconds(2.5))
    if let docToCancel = viewModel.documentsToProcess.first(where: { $0.name == "Legal Contract" }) {
        print("\n--- Simulating Cancellation of 'Legal Contract' ---")
        await viewModel.cancelDocumentProcessing(id: docToCancel.id)
    }
    
    // Allow ample time for processing to complete for all documents.
    await Task.sleep(for: .seconds(10))
    
    print("\n--- Simulation Complete ---")
    print("Final Completed Results:")
    // Accessing actor properties (like `getAllCompletedResults()`) requires `await`.
    for (id, result) in await viewModel.coordinator.getAllCompletedResults() {
        let shortID = id.uuidString.prefix(4)
        print("  Document \(shortID)...: OCR: '\(result.ocrText.prefix(30))...', Sentiment: \(result.sentiment), Keywords: \(result.keywords.joined(separator: ", "))")
    }
    
    // The `viewModel` and `coordinator` will deinitialize when they go out of scope,
    // which will automatically clean up the `statusObservationTask` and `statusContinuation`.
    
    // Keep the main task alive long enough for async operations to complete.
    // In a real app, this would be managed by the app's lifecycle.
    _ = viewModel // Retain viewModel to keep its observation task active during simulation.
    _ = coordinator // Retain coordinator to keep actor alive during simulation.
}

// Run the simulation from the global scope.
Task {
    await runAIScannerAppSimulation()
}
