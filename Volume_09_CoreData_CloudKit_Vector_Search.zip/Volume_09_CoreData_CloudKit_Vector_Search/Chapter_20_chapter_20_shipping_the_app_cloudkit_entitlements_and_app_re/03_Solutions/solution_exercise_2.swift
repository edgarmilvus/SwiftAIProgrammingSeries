
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// While the Privacy Manifest is an XML file (.xcprivacy), this Swift structure
/// represents the logical mapping required to satisfy Apple's requirements.
struct PrivacyDisclosureModel {
    
    // MARK: - API Declarations (Required Reason APIs)
    struct RequiredReasonAPIs {
        /// CloudKit and Core Data use Disk Space for local caching and SQLite management.
        static let diskSpaceUsage = "NSPrivacyAccessedAPIType.DiskSpace"
        
        /// CloudKit uses Network to synchronize the private database.
        static let networkUsage = "NSPrivacyAccessedAPIType.Network"
    }
    
    // MARK: - Data Collection Mapping
    struct CollectedDataTypes {
        let typeName = "Semantic Embeddings"
        let isLinkedToUser = true
        let isSensitive = true
        let purpose = "App Functionality: Enabling cross-device semantic search."
    }
    
    // MARK: - User-Facing Disclosure
    /// This string is used in the "Privacy Policy" or "App Privacy" section of the App Store.
    static let userFacingPolicy = """
    LexiSearch uses iCloud to sync your 'Semantic Knowledge Base'. 
    This includes text snippets and their mathematical 'embeddings' (vectors). 
    These vectors are stored exclusively in your private iCloud storage. 
    We do not access your identity, and this data is never shared with third parties or used for advertising.
    """
}

// MARK: - Conceptual XML Representation
/*
 <dict>
    <key>NSPrivacyAccessedAPITypes</key>
    <array>
        <dict>
            <key>NSPrivacyAccessedAPIType</key>
            <string>NSPrivacyAccessedAPIType.DiskSpace</string>
            <key>NSPrivacyAccessedAPITypeReasons</key>
            <array>
                <string>Accessing disk space to manage local Core Data cache.</string>
            </array>
        </dict>
    </array>
    <key>NSPrivacyCollectedDataTypes</key>
    <array>
        <dict>
            <key>NSPrivacyCollectedDataType</key>
            <string>Semantic Embeddings</string>
            <key>NSPrivacyCollectedDataTypeLinkedToUser</key>
            <true/>
            <key>NSPrivacyCollectedDataTypeSensitive</key>
            <true/>
        </dict>
    </array>
 </dict>
*/
