/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// utils/UniversalLogger.ts

/**
 * Determines the current execution environment.
 * @returns 'server' if running in Node.js, 'client' otherwise.
 */
function getEnvironment(): 'server' | 'client' {
  // Check for Node.js global variables
  if (typeof process !== 'undefined' && process.versions && process.versions.node) {
    return 'server';
  }
  // Default to client (Browser or Expo)
  return 'client';
}

/**
 * Logs a message to the appropriate output stream based on the environment.
 * @param tag - A tag to identify the source of the log (e.g., 'Auth', 'DataFetch').
 * @param message - The data to log.
 */
export function logUniversal(tag: string, message: any): void {
  const env = getEnvironment();
  const prefix = env === 'server' ? '[SERVER]' : '[CLIENT]';
  
  // In a real app, you might want to use a more robust logger (e.g., Winston on server).
  // Here we stick to standard console.log/process.stdout for simplicity.
  if (env === 'server') {
    // Node.js environment
    // process.stdout.write is preferred for raw streams, but console.log is fine for debugging
    console.log(`${prefix} [${tag}]`, message); 
  } else {
    // Browser/Expo environment
    console.log(`${prefix} [${tag}]`, message);
  }
}

// components/DebugComponent.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, Button } from 'react-native';
import { logUniversal } from '../utils/UniversalLogger';

// Mock Server Action (Simulated for the exercise context)
// In a real Next.js app, this would be 'use server' in a separate file
const simulateServerAction = async () => {
  'use server'; // Directive for Next.js App Router
  logUniversal('ServerAction', 'Executing server-side logic...');
  return { status: 'success', serverTime: new Date().toISOString() };
};

export default function DebugComponent() {
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    // This runs on the client (or native) when the component mounts
    logUniversal('ComponentMount', 'DebugComponent mounted on client');
  }, []);

  const handlePress = async () => {
    logUniversal('UserInteraction', 'Button pressed, initiating server call');
    
    // Call the server action
    const data = await simulateServerAction();
    setResult(data);
    
    logUniversal('ClientUpdate', `Received data: ${JSON.stringify(data)}`);
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Debug Component</Text>
      <Button title="Trigger Logs & Server Action" onPress={handlePress} />
      {result && <Text>Result: {result.status}</Text>}
    </View>
  );
}
