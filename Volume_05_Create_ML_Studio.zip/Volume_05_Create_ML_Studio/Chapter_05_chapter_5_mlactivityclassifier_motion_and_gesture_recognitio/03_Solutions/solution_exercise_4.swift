
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import CoreML
import CoreMotion

@available(iOS 18.0, *)
class ContextAwareAudioViewController: UIViewController {

    let activityLabel: UILabel = {
        let label = UILabel()
        label.text = "Monitoring activity..."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 20)
        label.numberOfLines = 0
        return label
    }()

    let audioStatusLabel: UILabel = {
        let label = UILabel()
        label.text = "Audio: Playing"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 20, weight: .semibold)
        label.textColor = .systemBlue
        return label
    }()

    private var activityClassifier: MLActivityClassifier?
    var isPlayingAudio: Bool = true {
        didSet {
            audioStatusLabel.text = isPlayingAudio ? "Audio: Playing" : "Audio: Paused"
            audioStatusLabel.textColor = isPlayingAudio ? .systemBlue : .systemRed
            print(isPlayingAudio ? "Audio Resumed: Activity suitable for listening." : "Audio Paused: Intense activity detected.")
            // Trigger haptic feedback for state change
            UIImpactFeedbackGenerator(style: isPlayingAudio ? .soft : .rigid).impactOccurred()
        }
    }

    // Variables for debouncing (e.g., counters for consecutive predictions)
    var consecutiveIntenseActivities: Int = 0
    var consecutiveCalmActivities: Int = 0
    let requiredConsecutivePredictions = 3 // Example threshold: 3 consecutive predictions

    // Define activity categories
    let intenseActivities: Set<String> = ["running", "cycling"]
    let calmActivities: Set<String> = ["still", "walking"]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupActivityClassifier()
    }

    private func setupUI() {
        view.addSubview(activityLabel)
        view.addSubview(audioStatusLabel)

        activityLabel.translatesAutoresizingMaskIntoConstraints = false
        audioStatusLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            activityLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -30),
            activityLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9),

            audioStatusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            audioStatusLabel.topAnchor.constraint(equalTo: activityLabel.bottomAnchor, constant: 20),
            audioStatusLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9)
        ])
    }

    private func setupActivityClassifier() {
        guard MLActivityClassifier.isActivityMonitoringAvailable() else {
            activityLabel.text = "Error: Activity monitoring not available on this device."
            return
        }
        activityClassifier = MLActivityClassifier()
        startActivityMonitoring()
    }

    private func startActivityMonitoring() {
        guard let classifier = activityClassifier else { return }

        classifier.startActivityUpdates(to: .main) { [weak self] (prediction, error) in
            guard let self = self else { return }

            if let error = error {
                DispatchQueue.main.async {
                    self.activityLabel.text = "Error monitoring: \(error.localizedDescription)"
                    print("MLActivityClassifier Error: \(error.localizedDescription)")
                    self.activityClassifier?.stopActivityUpdates()
                }
                return
            }

            if let prediction = prediction {
                DispatchQueue.main.async {
                    self.activityLabel.text = "Current Activity: \(prediction.label.capitalized) (Confidence: \(String(format: "%.2f", prediction.confidence)))"
                    self.handleActivityPrediction(prediction)
                }
            } else {
                DispatchQueue.main.async {
                    self.activityLabel.text = "Monitoring... (No prediction yet)"
                }
            }
        }
        print("Activity monitoring for audio control started.")
    }

    private func handleActivityPrediction(_ prediction: MLActivityClassifier.Prediction) {
        let currentActivity = prediction.label
        
        // Only consider predictions with high confidence to avoid false positives
        guard prediction.confidence > 0.7 else {
            // If confidence is low, we might not want to act on it, but still update the label.
            // For debouncing, it's safer to reset counters if confidence is too low to avoid
            // "sticky" states from an uncertain prediction.
            consecutiveIntenseActivities = 0
            consecutiveCalmActivities = 0
            return
        }

        let isCurrentlyIntense = intenseActivities.contains(currentActivity)
        let isCurrentlyCalm = calmActivities.contains(currentActivity)

        if isCurrentlyIntense {
            consecutiveIntenseActivities += 1
            consecutiveCalmActivities = 0 // Reset calm counter
            if consecutiveIntenseActivities >= requiredConsecutivePredictions && isPlayingAudio == true {
                isPlayingAudio = false // Trigger didSet
            }
        } else if isCurrentlyCalm {
            consecutiveCalmActivities += 1
            consecutiveIntenseActivities = 0 // Reset intense counter
            if consecutiveCalmActivities >= requiredConsecutivePredictions && isPlayingAudio == false {
                isPlayingAudio = true // Trigger didSet
            }
        } else {
            // If the activity is neither intense nor calm (e.g., automotive, unknown),
            // reset both counters to prevent "sticky" states and allow a fresh evaluation.
            consecutiveIntenseActivities = 0
            consecutiveCalmActivities = 0
        }
    }

    deinit {
        activityClassifier?.stopActivityUpdates()
    }
}
