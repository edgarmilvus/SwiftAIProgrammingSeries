
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import RealityKit
import ARKit

// MARK: - 1. The Component (The Data)

/// A component that stores the current emotional and computational state of an AI entity.
/// Components must be structs and conform to `Component`.
/// We use `@available(iOS 18.0, *)` or visionOS 2.0 as per latest SDK requirements.
@available(visionOS 2.0, *)
struct AIStateComponent: Component, Codable {
    /// The current intensity of the AI's activity (0.0 to 1.0).
    /// Used to drive the scale and pulse frequency.
    var intensity: Float = 0.0
    
    /// The current state of the AI assistant.
    enum AIState: Int, Codable {
        case idle
        case listening
        case thinking
    }
    var currentState: AIState = .idle
    
    /// A target color representing the AI's "mood" or "intent".
    var targetColor: SIMD3<Float> = [0.0, 0.5, 1.0] // Default Blue
}

// MARK: - 2. The System (The Logic)

/// A RealityKit System that observes entities with an `AIStateComponent` 
/// and updates their visual representation every frame.
@available(visionOS 2.0, *)
class AIVisualizationSystem: System {
    
    /// The query defines which entities this system cares about.
    /// We only want entities that have an `AIStateComponent`.
    private static let query = EntityQuery(where: .has(AIStateComponent.self))
    
    /// Required initializer for RealityKit Systems.
    required init(scene: Scene) { }
    
    /// The update function is called once per frame by RealityKit.
    /// - Parameter context: Provides access to the scene and the elapsed time.
    func update(context: SceneUpdateContext) {
        let deltaTime = Float(context.deltaTime)
        
        // Iterate through every entity that matches our query.
        context.scene.performQuery(Self.query).forEach { entity in
            // Retrieve the component (we use a guard to ensure it exists).
            guard var aiState = entity.components[AIStateComponent.self] as? AIStateComponent else {
                return
            }
            
            // 1. Calculate Pulse Logic
            // We use a sine wave to create a smooth "breathing" effect.
            // The frequency of the wave is driven by the 'intensity' in our component.
            let time = Float(context.time)
            let pulseSpeed = 1.0 + (aiState.intensity * 10.0) // Higher intensity = faster pulse
            let pulseScale = 1.0 + (sin(time * pulseSpeed) * 0.1 * aiState.intensity)
            
            // 2. Apply Transform
            // We apply the scale to the entity's transform.
            entity.scale = [pulseScale, pulseScale, pulseScale]
            
            // 3. Update Visuals (Material)
            // Note: In a production app, you would ideally use a ShaderGraphMaterial 
            // for complex effects. For this example, we use SimpleMaterial.
            if let modelEntity = entity as? ModelEntity {
                var material = SimpleMaterial(color: .init(red: CGFloat(aiState.targetColor.x),
                                                         green: CGFloat(aiState.targetColor.y),
                                                         blue: CGFloat(aiState.targetColor.z),
                                                         alpha: 1.0),
                                              isMetallic: true)
                material.emissiveColor = .init(color: .init(red: CGFloat(aiState.targetColor.x),
                                                            green: CGFloat(aiState.targetColor.y),
                                                            blue: CGFloat(aiState.targetColor.z),
                                                            alpha: 1.0))
                modelEntity.model?.materials = [material]
            }
            
            // IMPORTANT: Because components are value types (structs), 
            // we must write the modified component back to the entity.
            entity.components[AIStateComponent.self] = aiState
        }
    }
}

// MARK: - 3. The Entity Factory

/// A helper to create our AI Orb entity.
@available(visionOS 2.0, *)
struct AIVisualizerFactory {
    
    /// Creates a sphere entity configured as an AI Assistant.
    /// - Returns: A ModelEntity with the AIStateComponent attached.
    static func createAIOrb() -> ModelEntity {
        // Create a sphere mesh
        let mesh = MeshResource.generateSphere(radius: 0.2)
        
        // Create an initial material
        let material = SimpleMaterial(color: .blue, isMetallic: true)
        
        // Instantiate the entity
        let orb = ModelEntity(mesh: mesh, materials: [material])
        
        // Attach the custom AI component
        let initialState = AIStateComponent(intensity: 0.2, currentState: .idle)
        orb.components.set(initialState)
        
        return orb
    }
}

// MARK: - 4. The UI Integration (SwiftUI)

@available(visionOS 2.0, *)
struct LuminaView: View {
    @State private var orbEntity: ModelEntity?
    
    var body: some View {
        RealityView { content in
            // Create the orb
            let orb = AIVisualizerFactory.createAIOrb()
            orb.position = [0, 1.5, -1.0] // Place it in front of the user
            
            // Add to the scene
            content.add(orb)
            
            // Store reference to manipulate via AI logic later
            self.orbEntity = orb
        }
        .overlay(alignment: .bottom) {
            ControlPanel(orb: orbEntity)
        }
    }
}

/// A simple UI to simulate AI state changes.
@MainActor
struct ControlPanel: View {
    var orb: ModelEntity?
    
    var body: some View {
        HStack(spacing: 20) {
            Button("Idle") { updateAI(state: .idle, intensity: 0.1, color: [0, 0.5, 1]) }
            Button("Listening") { updateAI(state: .listening, intensity: 0.8, color: [1, 0.5, 0]) }
            Button("Thinking") { updateAI(state: .thinking, intensity: 0.4, color: [0.5, 0, 1]) }
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(15)
    }
    
    /// Simulates receiving a signal from an AI model.
    private func updateAI(state: AIStateComponent.AIState, intensity: Float, color: SIMD3<Float>) {
        guard let orb = orb else { return }
        
        // In a real app, this would be called from an async callback from an ML model.
        // We update the component, and the AIVisualizationSystem picks it up next frame.
        var newState = AIStateComponent(intensity: intensity, currentState: state, targetColor: color)
        orb.components.set(newState)
    }
}

// Helper for the enum inside the View
typealias AIState = AIStateComponent.AIState
