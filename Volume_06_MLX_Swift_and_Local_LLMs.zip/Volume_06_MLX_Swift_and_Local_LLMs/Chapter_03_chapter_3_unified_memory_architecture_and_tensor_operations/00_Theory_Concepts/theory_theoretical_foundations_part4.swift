
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation

// @available(iOS 18.0, *)
// func exampleActorUsage() async {
actor ModelService {
    private var model: MySimpleMLP // Our MLXNN.Module model, which is Sendable

    init() {
        self.model = MySimpleMLP()
        // Optionally load pre-trained weights here
    }

    // Perform inference safely
    func infer(_ input: MLXArray) async -> MLXArray {
        // Access to `model` is isolated by the actor
        let output = model(input)
        output.eval() // Explicitly evaluate the graph for the result
        return output
    }

    // Update model parameters (e.g., after fine-tuning)
    func updateModelParameters(newParameters: [String: MLXArray]) async {
        // This operation would typically involve loading new weights
        // For demonstration, let's just show the concept
        print("Updating model parameters...")
        // In a real scenario, you'd iterate through newParameters and assign them
        // to model.parameters, ensuring the MLXArray instances are evaluated.
        // For example: model.linear1.weight = newParameters["linear1.weight"]!
    }
}

// Usage
let service = ModelService()
let inputData = MLXArray.rand([1, 10])

Task {
    let prediction = await service.infer(inputData)
    print("Actor-based prediction: \(prediction.shape)")
}

// Multiple tasks can request inference, the actor ensures safe access
Task {
    let anotherPrediction = await service.infer(MLXArray.rand([1, 10]))
    print("Another actor-based prediction: \(anotherPrediction.shape)")
}
// }
