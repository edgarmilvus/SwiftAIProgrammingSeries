
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
class ImageClassifierTrainer {
    enum TrainingError: Error {
        case dataLoadFailed
        case trainingFailed
    }

    func trainCustomModel(dataDirectory: URL, modelName: String) async throws -> MLImageClassifier.Model {
        do {
            // 1. Load Data Asynchronously
            let dataSource = try MLImageClassifier.DataSource.labeledDirectories(at: dataDirectory)
            print("Data loaded successfully from: \(dataDirectory.lastPathComponent)")

            // 2. Define Model Parameters (optional, using defaults here)
            let parameters = MLImageClassifier.ModelParameters(
                validationData: .split(by: 0.2), // Use 20% for validation
                epochs: 10 // Train for 10 epochs
            )

            // 3. Train the Model Asynchronously
            let model = try await MLImageClassifier.train(dataSource: dataSource, parameters: parameters)
            print("Model training completed for: \(modelName)")

            // 4. Save the Model (can also be async)
            let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent("\(modelName).mlmodel")
            try model.write(to: fileURL)
            print("Model saved to: \(fileURL.lastPathComponent)")

            return model
        } catch {
            print("Training failed with error: \(error.localizedDescription)")
            throw TrainingError.trainingFailed // Re-throw a more specific error
        }
    }
}

// Usage in an async context (e.g., from a Task or an async function)
@available(iOS 18.0, *)
func startTraining() async {
    let trainer = ImageClassifierTrainer()
    if let dataURL = Bundle.main.url(forResource: "TrainingData", withExtension: nil) {
        do {
            let trainedModel = try await trainer.trainCustomModel(dataDirectory: dataURL, modelName: "MyCustomImageClassifier")
            // Use the trainedModel for inference or further processing
        } catch {
            print("Overall training process failed: \(error)")
        }
    } else {
        print("Training data not found.")
    }
}
