
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part8.swift
// Description: Advanced Application
// ==========================================

// MARK: - 6. Application Entry Point

@available(macOS 15.0, *)
@main
struct SmartHomeApp {
    static func main() async {
        print("Starting Smart Home AI Assistant...")

        // Initialize OllamaKit. Ensure Ollama server is running locally.
        let ollama = OllamaKit(baseURL: URL(string: "http://localhost:11434")!)
        
        // Check if Ollama server is reachable (optional, but good practice)
        do {
            _ = try await ollama.isReachable()
            print("Ollama server is reachable.")
        } catch {
            print("ERROR: Ollama server not reachable at http://localhost:11434. Please ensure Ollama is running.")
            print("Error details: \(error.localizedDescription)")
            return
        }

        let toolExecutor = ToolExecutor()
        let agent = LLMAgent(toolExecutor: toolExecutor, ollama: ollama)

        let queries = [
            "Set the living room lights to blue and dim them to 50%.",
            "What's the temperature in the bedroom?",
            "Set the bedroom thermostat to 21.5 degrees.",
            "Play some jazz music in the living room.",
            "Turn on the lights in the kitchen.", // Should trigger a "toolNotFound" or LLM refusal
            "Just tell me a joke." // Should be a direct text response from LLM
        ]

        for query in queries {
            do {
                let finalResponse = try await agent.processUserQuery(query)
                print("Agent Final Response: \(finalResponse)\n")
            } catch {
                print("Agent encountered an error: \(error.localizedDescription)\n")
            }
            try? await Task.sleep(for: .seconds(1)) // Pause between queries
        }
    }
}
