
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
struct Recipe {
    let id: UUID
    let name: String
    let ingredients: [String]
    let instructions: String
    var embedding: MLXArray? // Optional
    
    // Helper to combine text for embedding
    var searchableText: String {
        return "\(name). Ingredients: \(ingredients.joined(separator: ", ")). Instructions: \(instructions)"
    }
}

@available(iOS 18.0, macOS 15.0, *)
class RecipeSearchService {
    private var recipes: [Recipe]
    private let embeddingModel: MLXNN.Module
    private let embeddingDimension: Int

    // A single MLXArray containing all recipe embeddings for efficient search
    private var allRecipeEmbeddings: MLXArray?

    init(recipes: [Recipe], embeddingModel: MLXNN.Module, embeddingDimension: Int) {
        self.recipes = recipes
        self.embeddingModel = embeddingModel
        self.embeddingDimension = embeddingDimension
        
        // Process all recipes in a batch during initialization
        self.generateBatchEmbeddings()
    }

    private func generateBatchEmbeddings() {
        guard !recipes.isEmpty else {
            print("No recipes to embed.")
            return
        }

        print("Generating batch embeddings for \(recipes.count) recipes...")
        let recipeTexts = recipes.map { $0.searchableText }
        
        // Prepare dummy batched input for the embedding model.
        // The MLXArray.ones([batch.count, 1]) provides the necessary shape hint.
        let dummyBatchedInput = String.toDummyMLXInput(batch: recipeTexts)
        
        // Generate embeddings for all recipes in a single batch call.
        // The model returns an MLXArray of shape [batch_size, embedding_dimension].
        let batchedEmbeddings = embeddingModel(dummyBatchedInput)
        
        // Store embeddings back into individual recipe objects
        // We need to split the batchedEmbeddings tensor into individual embeddings.
        // MLX.split can achieve this if we specify the number of splits or sizes.
        // Here, we can iterate and slice, or directly assign if we know the order.
        let embeddingsArray = MLX.split(batchedEmbeddings, numSplits: recipes.count, axis: 0)
        
        for i in 0..<recipes.count {
            var recipe = recipes[i]
            recipe.embedding = embeddingsArray[i] // Assign the i-th embedding
            recipes[i] = recipe // Update the recipe in the array
        }
        
        // Store the concatenated embeddings for faster search operations later
        self.allRecipeEmbeddings = batchedEmbeddings
        print("Batch embedding generation complete.")
    }

    func findSimilarRecipes(query: String, topN: Int) -> [(Recipe, Float)] {
        guard let allEmbeddings = allRecipeEmbeddings, !recipes.isEmpty else {
            print("Recipe store is empty or embeddings not generated.")
            return []
        }

        // 1. Generate embedding for the query
        let queryDummyInput = query.toDummyMLXInput()
        let queryEmbedding = embeddingModel(queryDummyInput)
        
        // Ensure queryEmbedding is 2D for consistent matmul
        let queryEmbedding2D = queryEmbedding.reshaped([1, embeddingDimension])

        // 2. Calculate cosine similarity between query and all stored recipe embeddings
        let similarities = MLXArray.cosineSimilarity(a: queryEmbedding2D, b: allEmbeddings)
        
        // Convert to Swift array of Floats
        let similarityScores = similarities.flattened().toFloatArray()

        // 3. Pair recipes with their scores and sort
        let scoredRecipes = zip(recipes, similarityScores).map { (recipe, score) in
            (recipe, score)
        }
        
        let sortedResults = scoredRecipes.sorted { $0.1 > $1.1 }

        // 4. Return topN results
        return Array(sortedResults.prefix(topN))
    }
}

// MARK: - Demonstration
@available(iOS 18.0, macOS 15.0, *)
func demonstrateRecipeSearch() {
    print("\n--- Exercise 2: Feature Request - Semantic Recipe Search ---")
    let embeddingDimension = 384

    do {
        let model = try EmbeddingModelLoader.loadSentenceTransformerModel(embeddingDimension: embeddingDimension)

        // Sample Recipes
        let recipe1 = Recipe(id: UUID(), name: "Chicken Stir-fry", ingredients: ["chicken breast", "broccoli", "soy sauce", "rice"], instructions: "Cut chicken, stir-fry with broccoli, add sauce, serve over rice. Quick and easy.")
        let recipe2 = Recipe(id: UUID(), name: "Oatmeal with Berries", ingredients: ["oats", "milk", "mixed berries", "honey"], instructions: "Cook oats with milk, top with berries and a drizzle of honey. Healthy breakfast.")
        let recipe3 = Recipe(id: UUID(), name: "Spaghetti Carbonara", ingredients: ["spaghetti", "eggs", "bacon", "parmesan cheese", "black pepper"], instructions: "Cook spaghetti. Fry bacon. Mix eggs, cheese, pepper. Combine hot pasta with sauce.")
        let recipe4 = Recipe(id: UUID(), name: "Vegetable Curry", ingredients: ["mixed vegetables", "coconut milk", "curry paste", "rice"], instructions: "Sauté vegetables, add curry paste and coconut milk, simmer. Serve with rice. Vegetarian dinner.")
        let recipe5 = Recipe(id: UUID(), name: "Grilled Salmon with Asparagus", ingredients: ["salmon fillet", "asparagus", "lemon", "olive oil"], instructions: "Season salmon, grill until flaky. Roast asparagus with lemon. Healthy dinner.")
        let recipe6 = Recipe(id: UUID(), name: "Chocolate Chip Cookies", ingredients: ["flour", "sugar", "butter", "eggs", "chocolate chips"], instructions: "Mix dry and wet ingredients, fold in chocolate chips, bake until golden. Sweet treat.")

        let sampleRecipes = [recipe1, recipe2, recipe3, recipe4, recipe5, recipe6]
        
        let searchService = RecipeSearchService(recipes: sampleRecipes, embeddingModel: model, embeddingDimension: embeddingDimension)

        // Simulate user queries
        let query1 = "quick weeknight dinner with chicken"
        print("\nSearching for: '\(query1)'")
        let results1 = searchService.findSimilarRecipes(query: query1, topN: 2)
        print("Top 2 search results:")
        for (recipe, score) in results1 {
            print(String(format: "- Recipe: '%@' (Score: %.4f)", recipe.name, score))
        }

        let query2 = "healthy breakfast ideas with oats"
        print("\nSearching for: '\(query2)'")
        let results2 = searchService.findSimilarRecipes(query: query2, topN: 1)
        print("Top 1 search result:")
        for (recipe, score) in results2 {
            print(String(format: "- Recipe: '%@' (Score: %.4f)", recipe.name, score))
        }
        
        let query3 = "dessert for baking"
        print("\nSearching for: '\(query3)'")
        let results3 = searchService.findSimilarRecipes(query: query3, topN: 2)
        print("Top 2 search results:")
        for (recipe, score) in results3 {
            print(String(format: "- Recipe: '%@' (Score: %.4f)", recipe.name, score))
        }

    } catch {
        print("Error loading model: \(error)")
    }
}

// Call the demonstration function
// demonstrateRecipeSearch() // Uncomment to run
