
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Vision
import CoreGraphics
import UIKit // For UIImage conversion in example usage

@available(iOS 18.0, macOS 15.0, *)
func cropToLargestFace(image: CGImage) -> CGImage? {
    var croppedFaceImage: CGImage?
    let faceDetectionRequest = VNDetectFaceRectanglesRequest()

    // Use a DispatchGroup to wait for the asynchronous Vision request to complete.
    // Although perform(_:) for CGImage is synchronous, Vision's completion handlers
    // are typically invoked on a background queue, making this a common pattern.
    let dispatchGroup = DispatchGroup()
    dispatchGroup.enter()

    faceDetectionRequest.completionHandler = { request, error in
        defer { dispatchGroup.leave() } // Ensure group.leave() is called in all paths

        if let error = error {
            print("Face detection error: \(error.localizedDescription)")
            return
        }

        guard let observations = request.results as? [VNFaceObservation],
              let largestFace = observations.max(by: { $0.boundingBox.width * $0.boundingBox.height < $1.boundingBox.width * $1.boundingBox.height }) else {
            print("No faces detected or unable to find the largest face.")
            return
        }

        // 1. Convert normalized boundingBox to image coordinates.
        let imageSize = CGSize(width: image.width, height: image.height)
        // VNImageRectForNormalizedRect converts Vision's normalized (0-1) bounding box
        // to a CGRect in the image's coordinate system, handling orientation implicitly.
        var faceRect = VNImageRectForNormalizedRect(largestFace.boundingBox, Int(imageSize.width), Int(imageSize.height))

        // 2. Apply a 10% padding to the calculated CGRect.
        // Expand by 5% on each side (total 10% width/height).
        let paddingWidth = faceRect.width * 0.10
        let paddingHeight = faceRect.height * 0.10

        faceRect = faceRect.insetBy(dx: -paddingWidth / 2, dy: -paddingHeight / 2)

        // 3. Ensure the padded rectangle remains within the original image bounds.
        let imageBounds = CGRect(origin: .zero, size: imageSize)
        faceRect = faceRect.intersection(imageBounds)

        // Ensure the resulting rect is valid for cropping
        guard faceRect.width > 0 && faceRect.height > 0 else {
            print("Calculated face rectangle is invalid after padding/intersection.")
            return
        }

        // 4. Use CGImage.cropping(to:) to crop the original CGImage.
        croppedFaceImage = image.cropping(to: faceRect)
    }

    // Create VNImageRequestHandler using the input CGImage.
    let handler = VNImageRequestHandler(cgImage: image, options: [:])

    // Perform the face detection request.
    do {
        try handler.perform([faceDetectionRequest])
    } catch {
        print("Failed to perform face detection request: \(error.localizedDescription)")
    }

    // Wait for the completion handler to finish before returning.
    // This makes the function effectively synchronous from the caller's perspective,
    // even though Vision's internal processing might be asynchronous.
    dispatchGroup.wait()

    return croppedFaceImage
}

// Example Usage (requires an existing CGImage, e.g., from a UIImage):
// To run this, you'd typically add an image with a face to your project's assets.
// Example: if you have "person_photo.jpg" in your assets:
//
// if let uiImage = UIImage(named: "person_photo"),
//    let cgImage = uiImage.cgImage {
//     if let croppedFaceImage = cropToLargestFace(image: cgImage) {
//         // Display or save croppedFaceImage
//         print("Successfully cropped to largest face. Width: \(croppedFaceImage.width), Height: \(croppedFaceImage.height)")
//         // For UI testing, you could convert back to UIImage and display
//         // let resultUIImage = UIImage(cgImage: croppedFaceImage)
//     } else {
//         print("No face detected or cropping failed.")
//     }
// } else {
//     print("Error: 'person_photo' image not found or could not be loaded.")
// }
