
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Combine // For simulating data streams

// Ensure this code is only compiled and run on platforms that support ARKit/RealityKit features
@available(visionOS 1.0, iOS 18.0, *)
class SpatialAIMaintenanceApp: App {
    var body: some Scene {
        WindowGroup {
            MaintenanceARView()
        }
        .windowStyle(.volumetric) // For immersive AR experiences on visionOS
    }
}

// MARK: - 1. Data Models

/// Represents an identified industrial component with its unique ID, name, and initial spatial pose.
struct IndustrialComponent: Identifiable, Hashable {
    let id: UUID
    let name: String
    var initialPose: Transform // The detected position and orientation in the real world
}

/// Defines the possible operational statuses for an industrial component.
enum ComponentStatus: String, CaseIterable {
    case ok = "OK"
    case warning = "Warning"
    case critical = "Critical"
    case unknown = "Unknown"

    /// Provides a color representation for each status, useful for visual indicators.
    var color: SimpleMaterial.Color {
        switch self {
        case .ok: return .green
        case .warning: return .yellow
        case .critical: return .red
        case .unknown: return .gray
        }
    }
}

/// Represents a real-time status update for a specific component.
struct ComponentStatusUpdate {
    let componentID: UUID
    let status: ComponentStatus
    let timestamp: Date = Date()
}

// MARK: - 2. Simulated AI Object Detector

/// A simulated class that represents an AI model detecting industrial components.
/// In a real application, this would integrate with ARKit's `ARObjectScanningConfiguration`,
/// `RealityKit`'s `AnchorEntity(.object)`, or a custom Core ML model.
class SimulatedAIObjectDetector {
    /// An asynchronous sequence that emits detected industrial components.
    /// This simulates a continuous detection process.
    func detectedComponentsStream() -> AsyncStream<IndustrialComponent> {
        AsyncStream { continuation in
            Task {
                // Simulate detecting a few components after a delay
                try await Task.sleep(for: .seconds(3)) // Initial scan time

                let pumpID = UUID()
                continuation.yield(IndustrialComponent(id: pumpID, name: "Main Pump Assembly", initialPose: Transform(translation: [0.5, 0, -1.5])))

                let valveID = UUID()
                continuation.yield(IndustrialComponent(id: valveID, name: "Pressure Release Valve", initialPose: Transform(translation: [-0.8, 0.2, -1.0])))

                let motorID = UUID()
                continuation.yield(IndustrialComponent(id: motorID, name: "Auxiliary Motor Unit", initialPose: Transform(translation: [1.2, -0.1, -2.0])))

                // In a real scenario, this stream would continue to yield new detections
                // or updated poses as the user moves around and the AI re-evaluates the scene.
                // For this example, we'll just yield a few initial ones.
                continuation.finish()
            }
        }
    }
}

// MARK: - 3. Simulated Sensor Data Manager

/// A simulated class that provides real-time sensor data updates for industrial components.
/// In a real application, this would connect to an IoT platform, SCADA system, or local sensors.
class SimulatedSensorDataManager {
    private var timer: Timer?
    private let subject = PassthroughSubject<ComponentStatusUpdate, Never>()
    private var knownComponentIDs: Set<UUID> = []

    /// Starts simulating sensor data updates for known components.
    /// - Parameter componentIDs: The IDs of components for which to simulate data.
    func startSimulatingUpdates(for componentIDs: [UUID]) {
        knownComponentIDs = Set(componentIDs)
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            self?.generateRandomUpdate()
        }
    }

    /// Stops the sensor data simulation.
    func stopSimulatingUpdates() {
        timer?.invalidate()
        timer = nil
    }

    /// Generates a random status update for one of the known components.
    private func generateRandomUpdate() {
        guard !knownComponentIDs.isEmpty else { return }

        let randomID = knownComponentIDs.randomElement()!
        let randomStatus = ComponentStatus.allCases.randomElement()!
        let update = ComponentStatusUpdate(componentID: randomID, status: randomStatus)
        subject.send(update)
    }

    /// An asynchronous sequence that emits real-time component status updates.
    func statusUpdatesStream() -> AsyncPublisher<PassthroughSubject<ComponentStatusUpdate, Never>> {
        return subject.values
    }

    deinit {
        stopSimulatingUpdates()
    }
}

// MARK: - 4. Spatial Annotation Manager

/// Manages the AR scene, integrates AI detections, and applies spatial annotations.
/// This class is responsible for creating, updating, and removing RealityKit entities
/// based on real-world object detections and sensor data.
@available(visionOS 1.0, iOS 18.0, *)
class SpatialAnnotationManager: ObservableObject {
    let arView: ARView
    private let aiDetector = SimulatedAIObjectDetector()
    private let sensorDataManager = SimulatedSensorDataManager()
    
    // Stores references to the RealityKit entities for quick access and updates.
    private var componentAnchors: [UUID: AnchorEntity] = [:]
    private var componentStatusEntities: [UUID: ModelEntity] = [:]
    private var componentLabelEntities: [UUID: ModelEntity] = [:]
    
    private var detectionTask: Task<Void, Never>?
    private var statusUpdateTask: Task<Void, Never>?
    
    /// Initializes the manager and sets up the ARView.
    init() {
        self.arView = ARView(frame: .zero) // Initialize ARView
        setupARSession()
        startProcessingStreams()
    }

    /// Configures the AR session for world tracking.
    private func setupARSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal, .vertical] // Detect planes for better spatial understanding
        arView.session.run(configuration)
        
        // Add a debug option to show feature points and world origin
        arView.debugOptions = [.showFeaturePoints, .showWorldOrigin]
    }

    /// Starts the asynchronous tasks for processing AI detections and sensor data.
    private func startProcessingStreams() {
        // Task for handling AI object detections
        detectionTask = Task { [weak self] in
            guard let self = self else { return }
            do {
                for await component in self.aiDetector.detectedComponentsStream() {
                    await self.handleNewComponentDetection(component)
                }
                // Once initial components are detected, start sensor data simulation for them
                let detectedIDs = Array(self.componentAnchors.keys)
                self.sensorDataManager.startSimulatingUpdates(for: detectedIDs)
            } catch {
                print("Error processing AI detection stream: \(error.localizedDescription)")
            }
        }

        // Task for handling sensor data updates
        statusUpdateTask = Task { [weak self] in
            guard let self = self else { return }
            do {
                for await update in self.sensorDataManager.statusUpdatesStream() {
                    await self.handleComponentStatusUpdate(update)
                }
            } catch {
                print("Error processing sensor data stream: \(error.localizedDescription)")
            }
        }
    }

    /// Handles a newly detected industrial component.
    /// Creates and anchors RealityKit entities for the component's label and status indicator.
    /// - Parameter component: The detected `IndustrialComponent`.
    @MainActor
    private func handleNewComponentDetection(_ component: IndustrialComponent) {
        guard componentAnchors[component.id] == nil else {
            print("Component \(component.name) (ID: \(component.id)) already anchored.")
            return // Component already anchored
        }

        print("Anchoring new component: \(component.name) at \(component.initialPose.translation)")

        // 1. Create an AnchorEntity at the detected world position.
        // This ensures the labels and indicators stay fixed relative to the real-world object.
        let anchor = AnchorEntity(world: component.initialPose.translation)
        anchor.name = "ComponentAnchor-\(component.id)"
        
        // 2. Create a visual status indicator (e.g., a sphere).
        let statusSphere = ModelEntity(
            mesh: .generateSphere(radius: 0.05),
            materials: [SimpleMaterial(color: ComponentStatus.unknown.color, is
                                       Metallic: false)]
        )
        statusSphere.position = [0, 0.1, 0] // Offset slightly above the anchor point
        statusSphere.name = "StatusIndicator-\(component.id)"

        // 3. Create a text label for the component name and initial status.
        let labelText = ModelEntity(
            mesh: .generateText(
                "\(component.name)\nStatus: \(ComponentStatus.unknown.rawValue)",
                extrusionDepth: 0.005,
                font: .systemFont(ofSize: 0.08),
                containerFrame: CGRect(x: -0.5, y: -0.1, width: 1.0, height: 0.2), // Adjust frame for text wrapping
                alignment: .center
            ),
            materials: [SimpleMaterial(color: .white, isMetallic: false)]
        )
        labelText.position = [0, 0.2, 0] // Offset above the status sphere
        labelText.name = "LabelText-\(component.id)"

        // 4. Add the status sphere and label to the anchor.
        anchor.addChild(statusSphere)
        anchor.addChild(labelText)

        // 5. Add the anchor to the AR scene.
        arView.scene.addAnchor(anchor)

        // 6. Store references for future updates.
        componentAnchors[component.id] = anchor
        componentStatusEntities[component.id] = statusSphere
        componentLabelEntities[component.id] = labelText
    }

    /// Handles a real-time status update for an existing industrial component.
    /// Updates the visual indicator's color and the text label.
    /// - Parameter update: The `ComponentStatusUpdate` received from the sensor data manager.
    @MainActor
    private func handleComponentStatusUpdate(_ update: ComponentStatusUpdate) {
        guard let statusEntity = componentStatusEntities[update.componentID],
              let labelEntity = componentLabelEntities[update.componentID],
              let anchor = componentAnchors[update.componentID] else {
            print("Warning: Received status update for unknown or unanchored component ID: \(update.componentID)")
            return
        }

        print("Updating status for \(anchor.name ?? "Unknown"): \(update.status.rawValue)")

        // 1. Update the color of the status indicator.
        var newMaterial = SimpleMaterial(color: update.status.color, isMetallic: false)
        statusEntity.model?.materials = [newMaterial]

        // 2. Update the text content of the label.
        // We need to regenerate the text mesh to update its content.
        let componentName = anchor.name?.replacingOccurrences(of: "ComponentAnchor-", with: "").prefix(while: { $0 != "-" }) ?? "Unknown Component"
        let newTextMesh = MeshResource.generateText(
            "\(componentName)\nStatus: \(update.status.rawValue)",
            extrusionDepth: 0.005,
            font: .systemFont(ofSize: 0.08),
            containerFrame: CGRect(x: -0.5, y: -0.1, width: 1.0, height: 0.2),
            alignment: .center
        )
        labelEntity.model?.mesh = newTextMesh

        // Optional: Add a subtle animation for status changes
        // For advanced effects, you could use RealityKit's animation system.
        // This is a simple scale pulse.
        let originalScale = statusEntity.scale
        let pulseScale: SIMD3<Float> = [1.2, 1.2, 1.2]
        statusEntity.scale = pulseScale
        Task {
            try? await Task.sleep(for: .milliseconds(200))
            statusEntity.scale = originalScale
        }
    }
    
    /// Cleans up resources when the manager is no longer needed.
    deinit {
        detectionTask?.cancel()
        statusUpdateTask?.cancel()
        sensorDataManager.stopSimulatingUpdates()
        arView.session.pause()
        print("SpatialAnnotationManager deinitialized.")
    }
}

// MARK: - 5. SwiftUI Integration

/// A SwiftUI `View` that wraps the `ARView` managed by `SpatialAnnotationManager`.
/// This allows embedding the AR experience within a SwiftUI application.
@available(visionOS 1.0, iOS 18.0, *)
struct MaintenanceARView: View {
    @StateObject private var manager = SpatialAnnotationManager()

    var body: some View {
        ZStack {
            // The ARView itself, provided by the manager
            ARViewContainer(arView: manager.arView)
                .edgesIgnoringSafeArea(.all)
            
            // Optional: Overlay for debug information or user interaction
            VStack {
                Spacer()
                Text("Look around to detect industrial components.")
                    .font(.headline)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
                    .padding(.bottom, 50)
            }
        }
    }
}

/// A `UIViewRepresentable` (or `ARViewRepresentable` for visionOS) wrapper for `ARView`.
@available(visionOS 1.0, iOS 18.0, *)
struct ARViewContainer: UIViewRepresentable {
    let arView: ARView

    func makeUIView(context: Context) -> ARView {
        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        // No updates needed directly on ARView for this example,
        // as the SpatialAnnotationManager handles scene changes.
    }
    
    static func dismantleUIView(_ uiView: ARView, coordinator: ()) {
        // Perform cleanup if necessary, though the manager's deinit handles most.
        uiView.session.pause()
        uiView.session.delegate = nil
        uiView.scene.anchors.removeAll()
    }
}
