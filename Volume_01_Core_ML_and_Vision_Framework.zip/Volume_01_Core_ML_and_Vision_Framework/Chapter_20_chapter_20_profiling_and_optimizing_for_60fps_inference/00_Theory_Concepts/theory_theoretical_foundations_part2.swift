
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    actor InferenceActor {
        private var coreMLModel: MLModel // The Core ML model instance
        private let visionModel: VNCoreMLModel // The Vision wrapper for Core ML

        init(modelURL: URL) async throws {
            let compiledModelURL = try MLModel.compileModel(at: modelURL)
            self.coreMLModel = try MLModel(contentsOf: compiledModelURL)
            self.visionModel = try VNCoreMLModel(for: self.coreMLModel)
        }

        // Perform inference using Vision framework
        func performVisionInference(pixelBuffer: CVPixelBuffer) async throws -> [VNClassificationObservation] {
            let request = VNCoreMLRequest(model: visionModel)
            request.imageCropAndScaleOption = .centerCrop // Example preprocessing option

            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            try await handler.perform([request]) // Await the Vision request

            guard let observations = request.results as? [VNClassificationObservation] else {
                return []
            }
            return observations
        }
    }
    