/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// packages/utils/src/types.ts
export interface User {
  id: number;
  name: string;
  email: string;
}

export interface Product {
  id: number;
  title: string;
  price: number;
}

export type ApiResponse = User | Product;

// packages/utils/src/guards.ts
import { ApiResponse, User, Product } from './types';

// Type guard for User
export function isUser(value: ApiResponse): value is User {
  // Check for 'email' which is exclusive to User in this context
  return typeof value === 'object' && value !== null && 'email' in value;
}

// Type guard for Product
export function isProduct(value: ApiResponse): value is Product {
  // Check for 'price' which is exclusive to Product
  return typeof value === 'object' && value !== null && 'price' in value;
}

// packages/utils/src/formatter.ts
import { ApiResponse } from './types';
import { isUser, isProduct } from './guards';

export function formatResponse(data: ApiResponse): string {
  // Interactive Challenge: Ternary operator usage
  // We check isUser first. If true, we cast to User. 
  // If false, we assume Product (or handle unknown).
  return isUser(data) 
    ? `User: ${data.name} (${data.email})`
    : `Product: ${data.title} - $${data.price}`;
}

// apps/web/pages/api/demo.ts (or inside a component)
import { ApiResponse, formatResponse } from '@repo/utils';

const mockData: ApiResponse = { id: 1, name: 'Alice', email: 'alice@example.com' };

export function DemoComponent() {
  const display = formatResponse(mockData);
  return <div>{display}</div>;
}
