
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import CoreML
import NaturalLanguage // For tokenization preprocessing

// Assume SentimentClassifier.mlmodel has been added to the project
// and Xcode has automatically generated the SentimentClassifier class.

class SentimentAnalysisViewController: UIViewController {
    // UI Elements
    private let reviewTextView: UITextView = {
        let textView = UITextView()
        textView.font = .systemFont(ofSize: 17)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 5.0
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    private let analyzeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Analyze Sentiment", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let sentimentLabel: UILabel = {
        let label = UILabel()
        label.text = "Sentiment: "
        label.font = .boldSystemFont(ofSize: 20)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // Core ML Model instance
    private var sentimentClassifier: SentimentClassifier?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Sentiment Analyzer"
        view.backgroundColor = .white
        setupUI()
        loadModel()
    }

    private func setupUI() {
        view.addSubview(reviewTextView)
        view.addSubview(analyzeButton)
        view.addSubview(sentimentLabel)

        NSLayoutConstraint.activate([
            reviewTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            reviewTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            reviewTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            reviewTextView.heightAnchor.constraint(equalToConstant: 180),

            analyzeButton.topAnchor.constraint(equalTo: reviewTextView.bottomAnchor, constant: 20),
            analyzeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            analyzeButton.widthAnchor.constraint(equalToConstant: 250),
            analyzeButton.heightAnchor.constraint(equalToConstant: 50),

            sentimentLabel.topAnchor.constraint(equalTo: analyzeButton.bottomAnchor, constant: 30),
            sentimentLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            sentimentLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        analyzeButton.addTarget(self, action: #selector(analyzeSentiment), for: .touchUpInside)
    }

    private func loadModel() {
        do {
            let config = MLModelConfiguration()
            self.sentimentClassifier = try SentimentClassifier(configuration: config)
            print("Core ML model 'SentimentClassifier' loaded successfully.")
        } catch {
            print("Error loading sentiment classifier model: \(error.localizedDescription)")
            sentimentLabel.text = "Error: Model failed to load."
        }
    }

    @objc private func analyzeSentiment() {
        guard let reviewText = reviewTextView.text, !reviewText.isEmpty else {
            sentimentLabel.text = "Sentiment: Please enter a review."
            return
        }

        guard let classifier = sentimentClassifier else {
            sentimentLabel.text = "Sentiment: Model not loaded, cannot analyze."
            return
        }

        // Preprocessing: Tokenization (Optional but good practice if model was trained on tokenized data)
        // For simplicity, Create ML's text classifier often handles raw text well,
        // but explicit tokenization can ensure consistency.
        let tokenizer = NLTokenizer(unit: .word)
        tokenizer.string = reviewText
        let tokens = tokenizer.tokens(for: reviewText.startIndex..<reviewText.endIndex).map { String(reviewText[$0]) }
        let preprocessedText = tokens.joined(separator: " ") // Rejoin tokens if needed by model, or pass original

        // Perform prediction asynchronously
        Task {
            do {
                let prediction = try await classifier.prediction(text: preprocessedText) // Use preprocessedText or original reviewText
                await MainActor.run {
                    sentimentLabel.text = "Sentiment: \(prediction.sentiment.capitalized)"
                    // Update color based on sentiment
                    switch prediction.sentiment {
                    case "positive": sentimentLabel.textColor = .systemGreen
                    case "negative": sentimentLabel.textColor = .systemRed
                    case "neutral": sentimentLabel.textColor = .systemGray
                    default: sentimentLabel.textColor = .black
                    }
                }
            } catch {
                await MainActor.run {
                    sentimentLabel.text = "Sentiment Error: \(error.localizedDescription)"
                    sentimentLabel.textColor = .red
                }
                print("Error making sentiment prediction: \(error.localizedDescription)")
            }
        }
    }
}
