
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML
import UIKit
import Foundation // For FileManager and URLSession

// MARK: - Model Configuration and Management

/// Represents a specific translation model version.
struct TranslationModelInfo: Identifiable, Hashable {
    let id = UUID()
    let languagePair: String // e.g., "en-es"
    let quantization: ModelQuantizationType // From Exercise 2
    let version: Int // For updates
    let estimatedSizeMB: Double? // For download prompt
    
    var assetTag: String {
        // Asset tags are typically lowercase, alphanumeric, no special chars
        return "\(languagePair.replacingOccurrences(of: "-", with: "_"))_\(quantization.rawValue.replacingOccurrences(of: " ", with: "_").lowercased())_v\(version)"
    }
    
    var displayName: String {
        return "\(languagePair.uppercased()) \(quantization.rawValue) (v\(version))"
    }
}

/// Manages downloadable translation models using MLModelAsset/On-Demand Resources.
@Observable
class TranslationModelManager {
    // Available models (could be fetched from a backend or hardcoded)
    // In a real app, this list would likely come from a server API to allow dynamic updates.
    var allAvailableModels: [TranslationModelInfo] = [
        .init(languagePair: "en-es", quantization: .int8, version: 1, estimatedSizeMB: 10.5),
        .init(languagePair: "en-es", quantization: .float16, version: 1, estimatedSizeMB: 20.1),
        .init(languagePair: "en-es", quantization: .fullPrecision, version: 1, estimatedSizeMB: 40.0),
        
        .init(languagePair: "en-fr", quantization: .int8, version: 1, estimatedSizeMB: 11.2),
        .init(languagePair: "en-fr", quantization: .float16, version: 1, estimatedSizeMB: 22.5),
        // Assume en-fr FP32 is not available for download, or is too large
        
        .init(languagePair: "es-en", quantization: .int8, version: 2, estimatedSizeMB: 10.8), // New version!
        .init(languagePair: "es-en", quantization: .float16, version: 1, estimatedSizeMB: 21.0)
    ]
    
    var installedModels: Set<TranslationModelInfo> = [] // Track locally available models
    var activeModel: (TranslationModelInfo, MLModel)?
    var downloadProgress: Progress?
    var downloadError: Error?
    
    init() {
        // On app launch, check which ODR assets are already downloaded
        Task { await updateInstalledModelsList() }
    }
    
    /// Updates the list of currently installed models by checking ODR status.
    func updateInstalledModelsList() async {
        var currentlyInstalled: Set<TranslationModelInfo> = []
        for modelInfo in allAvailableModels {
            // NSBundleResourceRequest can check if a resource is already available
            let request = NSBundleResourceRequest(tags: [modelInfo.assetTag])
            if request.conditionallyBeginAccessingResources() {
                currentlyInstalled.insert(modelInfo)
                request.endAccessingResources() // Release access
            }
        }
        await MainActor.run {
            self.installedModels = currentlyInstalled
            print("Installed models updated: \(currentlyInstalled.map { $0.displayName })")
        }
    }
    
    /// Intelligent model loading logic for a given language pair.
    func loadModel(for languagePair: String) async throws -> MLModel {
        // 1. Prioritize loading the most quantized (smallest) available version first.
        let preferredQuantizationOrder: [ModelQuantizationType] = [.int8, .float16, .fullPrecision]
        
        for qType in preferredQuantizationOrder {
            // Find the best available version for this quantization type
            let candidateModels = allAvailableModels
                .filter { $0.languagePair == languagePair && $0.quantization == qType }
                .sorted { $0.version > $1.version } // Prefer newer versions
            
            if let bestCandidate = candidateModels.first {
                print("Attempting to load \(bestCandidate.displayName)...")
                
                // Check if already installed
                if installedModels.contains(bestCandidate) {
                    print("\(bestCandidate.displayName) is already installed. Loading...")
                    let model = try await loadCoreMLModel(for: bestCandidate)
                    await MainActor.run { self.activeModel = (bestCandidate, model) }
                    return model
                } else {
                    // Not installed, prompt for download if it's the most preferred
                    if qType == preferredQuantizationOrder.first { // Only prompt for the most preferred
                        print("\(bestCandidate.displayName) not installed. Prompting for download.")
                        await MainActor.run {
                            Task {
                                await self.promptAndDownloadModel(bestCandidate)
                            }
                        }
                        // This path will return after download, or throw if cancelled/failed
                        let model = try await loadCoreMLModel(for: bestCandidate)
                        await MainActor.run { self.activeModel = (bestCandidate, model) }
                        return model
                    } else {
                        print("\(bestCandidate.displayName) not installed, but trying less quantized local versions first.")
                        // Continue to next quantization type to check for local availability
                    }
                }
            }
        }
        
        throw TranslationError.noSuitableModelFound(languagePair: languagePair)
    }
    
    /// Handles the download prompt and actual download using NSBundleResourceRequest.
    private func promptAndDownloadModel(_ modelInfo: TranslationModelInfo) async {
        await MainActor.run {
            self.downloadError = nil // Clear previous errors
            // In a real app, this would be a UIAlertController
            print("--- PROMPT: Download \(modelInfo.displayName)? (Estimated size: \(modelInfo.estimatedSizeMB ?? 0) MB) ---")
            print("Simulating user accepting download...")
        }
        
        do {
            let model = try await downloadModel(modelInfo: modelInfo)
            await MainActor.run {
                self.installedModels.insert(modelInfo)
                self.activeModel = (modelInfo, model)
                print("Successfully downloaded and activated \(modelInfo.displayName)")
            }
        } catch {
            await MainActor.run {
                self.downloadError = error
                print("Download failed for \(modelInfo.displayName): \(error.localizedDescription)")
            }
        }
    }
    
    /// Downloads a model using NSBundleResourceRequest.
    private func downloadModel(modelInfo: TranslationModelInfo) async throws -> MLModel {
        let request = NSBundleResourceRequest(tags: [modelInfo.assetTag])
        request.loadingPriority = NSBundleResourceRequest.LoadingPriorityUrgent
        
        // Observe progress
        await MainActor.run {
            self.downloadProgress = request.progress
            request.progress.publisher(for: \.fractionCompleted)
                .sink { progress in
                    print("Download progress for \(modelInfo.displayName): \(Int(progress * 100))%")
                }
                .store(in: &cancellables) // Store subscription to prevent deallocation
        }
        
        do {
            try await request.beginAccessingResources()
            await MainActor.run { self.downloadProgress = nil } // Clear progress
            let model = try await loadCoreMLModel(for: modelInfo)
            request.endAccessingResources()
            return model
        } catch {
            await MainActor.run { self.downloadProgress = nil }
            request.endAccessingResources()
            throw TranslationError.downloadFailed(modelName: modelInfo.displayName, error: error)
        }
    }
    
    /// Loads the actual Core ML model from the MLModelAsset.
    private func loadCoreMLModel(for modelInfo: TranslationModelInfo) async throws -> MLModel {
        guard let modelURL = Bundle.main.url(forResource: modelInfo.assetTag, withExtension: "mlmodelc") else {
            // This should ideally not happen if beginAccessingResources succeeded
            throw TranslationError.modelAssetNotFound(name: modelInfo.assetTag)
        }
        return try await MLModel.load(contentsOf: modelURL)
    }
    
    /// Removes a downloaded model.
    func removeModel(_ modelInfo: TranslationModelInfo) async throws {
        let request = NSBundleResourceRequest(tags: [modelInfo.assetTag])
        request.conditionallyBeginAccessingResources() // Ensure it's accessed before removing
        request.endAccessingResources()
        
        NSBundleResourceRequest.endAccessingResources(with: [modelInfo.assetTag])
        await MainActor.run {
            self.installedModels.remove(modelInfo)
            if self.activeModel?.0 == modelInfo {
                self.activeModel = nil
            }
            print("Removed model: \(modelInfo.displayName)")
        }
    }
    
    private var cancellables = Set<AnyCancellable>() // For Combine publishers
}

// MARK: - Error Handling

enum TranslationError: Error, LocalizedError {
    case noSuitableModelFound(languagePair: String)
    case downloadFailed(modelName: String, error: Error)
    case modelAssetNotFound(name: String)
    
    var errorDescription: String? {
        switch self {
        case .noSuitableModelFound(let pair): return "No suitable model found for \(pair)."
        case .downloadFailed(let name, let error): return "Failed to download \(name): \(error.localizedDescription)"
        case .modelAssetNotFound(let name): return "Model asset '\(name)' not found after download."
        }
    }
}

// MARK: - Example UI (ViewController)

class TranslatorViewController: UIViewController {
    
    let modelManager = TranslationModelManager()
    
    // UI Elements
    let languagePairPicker = UISegmentedControl(items: ["en-es", "en-fr", "es-en"])
    let translateButton = UIButton(type: .system)
    let installedModelsLabel = UILabel()
    let activeModelLabel = UILabel()
    let downloadProgressView = UIProgressView(progressViewStyle: .default)
    let feedbackLabel = UILabel()
    let removeModelButton = UIButton(type: .system)
    
    private var cancellables = Set<AnyCancellable>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        bindViewModel()
        
        // Initial update of installed models
        Task { await modelManager.updateInstalledModelsList() }
    }
    
    private func setupUI() {
        view.backgroundColor = .systemBackground
        
        languagePairPicker.selectedSegmentIndex = 0
        languagePairPicker.addTarget(self, action: #selector(languagePairChanged), for: .valueChanged)
        
        translateButton.setTitle("Translate", for: .normal)
        translateButton.addTarget(self, action: #selector(translateTapped), for: .touchUpInside)
        
        removeModelButton.setTitle("Remove Active Model", for: .normal)
        removeModelButton.addTarget(self, action: #selector(removeActiveModelTapped), for: .touchUpInside)
        
        installedModelsLabel.numberOfLines = 0
        feedbackLabel.numberOfLines = 0
        
        let stack = UIStackView(arrangedSubviews: [
            languagePairPicker,
            translateButton,
            removeModelButton,
            installedModelsLabel,
            activeModelLabel,
            downloadProgressView,
            feedbackLabel
        ])
        stack.axis = .vertical
        stack.spacing = 15
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stack.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            downloadProgressView.widthAnchor.constraint(equalTo: stack.widthAnchor)
        ])
        
        downloadProgressView.isHidden = true
    }
    
    private func bindViewModel() {
        // Observe changes in modelManager using Combine (or KVO/property observers)
        modelManager.$installedModels
            .receive(on: DispatchQueue.main)
            .sink { [weak self] models in
                let modelNames = models.map { $0.displayName }.joined(separator: ", ")
                self?.installedModelsLabel.text = "Installed: \(modelNames.isEmpty ? "None" : modelNames)"
            }
            .store(in: &cancellables)
        
        modelManager.$activeModel
            .receive(on: DispatchQueue.main)
            .sink { [weak self] modelTuple in
                if let (info, _) = modelTuple {
                    self?.activeModelLabel.text = "Active: \(info.displayName)"
                    self?.feedbackLabel.text = "Expected: \(info.quantization.description)"
                    self?.removeModelButton.isEnabled = true
                } else {
                    self?.activeModelLabel.text = "Active: None"
                    self?.feedbackLabel.text = ""
                    self?.removeModelButton.isEnabled = false
                }
            }
            .store(in: &cancellables)
        
        modelManager.$downloadProgress
            .receive(on: DispatchQueue.main)
            .sink { [weak self] progress in
                if let progress = progress {
                    self?.downloadProgressView.isHidden = false
                    self?.downloadProgressView.progress = Float(progress.fractionCompleted)
                    self?.feedbackLabel.text = "Downloading: \(Int(progress.fractionCompleted * 100))%"
                } else {
                    self?.downloadProgressView.isHidden = true
                }
            }
            .store(in: &cancellables)
        
        modelManager.$downloadError
            .receive(on: DispatchQueue.main)
            .sink { [weak self] error in
                if let error = error {
                    self?.feedbackLabel.text = "Download Error: \(error.localizedDescription)"
                    self?.presentAlert(title: "Download Error", message: error.localizedDescription)
                }
            }
            .store(in: &cancellables)
    }
    
    @objc private func languagePairChanged(_ sender: UISegmentedControl) {
        // Clear active model when language pair changes
        modelManager.activeModel = nil
    }
    
    @objc private func translateTapped() {
        guard let selectedLanguagePair = languagePairPicker.titleForSegment(at: languagePairPicker.selectedSegmentIndex) else { return }
        
        feedbackLabel.text = "Loading model for \(selectedLanguagePair)..."
        
        Task {
            do {
                _ = try await modelManager.loadModel(for: selectedLanguagePair)
                await MainActor.run {
                    self.feedbackLabel.text = "Model ready for \(selectedLanguagePair). Start translating!"
                }
                // Here you would perform actual translation inference
                print("Translation inference ready with model: \(modelManager.activeModel?.0.displayName ?? "N/A")")
            } catch {
                await MainActor.run {
                    self.feedbackLabel.text = "Error: \(error.localizedDescription)"
                    self.presentAlert(title: "Model Loading Error", message: error.localizedDescription)
                }
            }
        }
    }
    
    @objc private func removeActiveModelTapped() {
        guard let activeModelInfo = modelManager.activeModel?.0 else { return }
        
        let alert = UIAlertController(title: "Remove Model?", message: "Are you sure you want to remove \(activeModelInfo.displayName)?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Remove", style: .destructive) { _ in
            Task {
                do {
                    try await self.modelManager.removeModel(activeModelInfo)
                    await MainActor.run {
                        self.feedbackLabel.text = "\(activeModelInfo.displayName) removed."
                    }
                } catch {
                    await MainActor.run {
                        self.feedbackLabel.text = "Error removing model: \(error.localizedDescription)"
                        self.presentAlert(title: "Removal Error", message: error.localizedDescription)
                    }
                }
            }
        })
        present(alert, animated: true)
    }
    
    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
