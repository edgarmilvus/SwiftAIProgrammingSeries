
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
import PackageDescription

let package = Package(
    name: "SmartAssistantCore",
    platforms: [
        .macOS(.v14), // For local LLMs, macOS is a primary target
        .iOS(.v18)    // For on-device LLMs on newer iPhones/iPads
    ],
    products: [
        .library(
            name: "SmartAssistantCore",
            targets: ["SmartAssistantCore"]),
    ],
    dependencies: [
        // Example: A hypothetical Swift binding for llama.cpp
        // This would wrap the C++ llama.cpp library for Swift consumption.
        // .package(url: "https://github.com/your-org/llama-cpp-swift", from: "1.0.0"),
        
        // For structured logging (Apple's unified logging system)
        .package(url: "https://github.com/apple/swift-log", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "SmartAssistantCore",
            dependencies: [
                // "llama-cpp-swift", // Uncomment if using a real binding
                .product(name: "Logging", package: "swift-log")
            ],
            // If llama.cpp is integrated directly, you might need C++ settings
            swiftSettings: [.enableUpcomingFeature("BareSlashRegexLiterals")],
            linkerSettings: [
                // Example for linking llama.cpp if built as a local C++ target
                // .linkedLibrary("llama", .when(platforms: [.macOS, .iOS]))
            ]
        ),
        .testTarget(
            name: "SmartAssistantCoreTests",
            dependencies: ["SmartAssistantCore"]),
    ]
)
