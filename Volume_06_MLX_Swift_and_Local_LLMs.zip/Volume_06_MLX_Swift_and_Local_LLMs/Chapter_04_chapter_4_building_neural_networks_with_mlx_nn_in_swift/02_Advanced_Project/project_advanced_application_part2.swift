
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXOptimizers

/// Represents a real-world scenario where a Smart Photo Album app
/// allows users to fine-tune a pre-trained image classification model
/// for specific categories (e.g., different flower types) using a small
/// personal dataset. This demonstrates on-device fine-tuning using MLX Swift.
@available(iOS 18.0, macOS 15.0, *)
actor SmartPhotoAlbumMLService {

    /// Defines the shape of our simulated input images:
    /// [Channels, Height, Width]
    static let imageShape: [Int] = [3, 32, 32] // 3 channels (RGB), 32x32 pixels

    /// The number of custom classes the user wants to fine-tune for.
    let numCustomClasses: Int

    /// The complete fine-tunable model, comprising a feature extractor and a classification head.
    private var model: FineTunableClassifier

    /// Initializes the MLX service for the Smart Photo Album.
    /// - Parameter numCustomClasses: The number of distinct custom categories
    ///   the user wants to train the model for (e.g., 3 for Rose, Tulip, Daisy).
    init(numCustomClasses: Int) {
        self.numCustomClasses = numCustomClasses
        // Initialize the model. In a real app, the FeatureExtractor's weights
        // would be loaded from a pre-trained checkpoint. Here, it's initialized randomly.
        self.model = FineTunableClassifier(numClasses: numCustomClasses)

        // MLX leverages Apple Silicon's Unified Memory. By default, MLX will try to use the GPU.
        // `MLXArray` instances directly reference data in this unified memory,
        // avoiding costly data transfers between CPU and GPU, leading to "zero-copy" benefits.
        MLX.defaultDevice = .gpu // Explicitly set to GPU if available for best performance
        self.model.parameters().eval() // Eagerly evaluate parameters to push them to the device
        print("MLX initialized on device: \(MLX.defaultDevice)")
    }

    // MARK: - 1. Data Simulation Helpers

    /// Helper to generate dummy image data for training or inference.
    /// In a real application, this would load actual image pixels from the device's camera
    /// or photo library, likely after resizing and normalization.
    /// - Parameters:
    ///   - batchSize: The number of images in the batch.
    ///   - label: The class label for these images (optional, for training).
    /// - Returns: An `MLXArray` representing a batch of images.
    ///
    /// The `MLXArray` created here directly utilizes Unified Memory, meaning the underlying
    /// data is accessible by both the CPU and GPU without explicit copying.
    private func generateDummyImageData(batchSize: Int, label: Int? = nil) -> MLXArray {
        // Simulate image data: [batchSize, channels, height, width]
        let shape = [batchSize] + SmartPhotoAlbumMLService.imageShape
        // Random data between 0 and 1, simulating normalized pixel values
        let imageData = MLXArray.randomUniform(low: 0.0, high: 1.0, shape: shape, dtype: .float32)
        return imageData
    }

    /// Helper to generate dummy labels for training.
    /// - Parameters:
    ///   - batchSize: The number of labels to generate.
    ///   - classIndex: The specific class index for all labels in this batch.
    /// - Returns: An `MLXArray` representing a batch of one-hot encoded labels.
    private func generateDummyLabels(batchSize: Int, classIndex: Int) -> MLXArray {
        // Simulate one-hot encoded labels: [batchSize, numClasses]
        let labels = MLXArray.zeros([batchSize, numCustomClasses], dtype: .float32)
        // Set the specific class index to 1.0 for all labels in the batch
        var oneHotLabels = [Float](repeating: 0.0, count: numCustomClasses)
        oneHotLabels[classIndex] = 1.0
        let labelArray = MLXArray(oneHotLabels, dtype: .float32)
        for i in 0..<batchSize {
            labels[i] = labelArray
        }
        return labels
    }

    // MARK: - 2. The Base Feature Extractor (Simulated Pre-trained Backbone)

    /// `FeatureExtractor` represents the initial layers of a pre-trained model.
    /// Its purpose is to transform raw input images into a more abstract,
    /// high-level feature representation. In a real application, this module's
    /// weights would be loaded from a pre-trained checkpoint and typically frozen
    /// during fine-tuning to preserve general knowledge learned from a large dataset.
    ///
    /// By inheriting from `MLXNN.Module`, we gain automatic parameter tracking
    /// and the ability to define the forward pass using `callAsFunction`.
    class FeatureExtractor: MLXNN.Module {
        let conv1: MLXNN.Conv2d
        let conv2: MLXNN.Conv2d
        let pool: MLXNN.MaxPool2d

        override init() {
            // Conv2d(inputChannels: 3, outputChannels: 16, kernelSize: 3, padding: 1)
            // Input: [B, 3, 32, 32] -> Output: [B, 16, 32, 32] (padding=1 keeps size)
            self.conv1 = MLXNN.Conv2d(inputChannels: 3, outputChannels: 16, kernelSize: 3, padding: 1)
            // MaxPool2d(kernelSize: 2, stride: 2)
            // Input: [B, 16, 32, 32] -> Output: [B, 16, 16, 16] (halves spatial dimensions)
            self.pool = MLXNN.MaxPool2d(kernelSize: 2, stride: 2)
            // Conv2d(inputChannels: 16, outputChannels: 32, kernelSize: 3, padding: 1)
            // Input: [B, 16, 16, 16] -> Output: [B, 32, 16, 16]
            self.conv2 = MLXNN.Conv2d(inputChannels: 16, outputChannels: 32, kernelSize: 3, padding: 1)
            super.init()
        }

        /// Defines the forward pass of the feature extractor.
        /// - Parameter x: An `MLXArray` representing the input image batch.
        /// - Returns: An `MLXArray` containing the extracted features.
        override func callAsFunction(_ x: MLXArray) -> MLXArray {
            var x = x
            x = MLXNN.relu(conv1(x)) // Apply convolution and ReLU activation
            x = pool(x)              // Apply max pooling
            x = MLXNN.relu(conv2(x)) // Apply another convolution and ReLU
            x = pool(x)              // Apply another max pooling
            return x
        }
    }

    // MARK: - 3. The Fine-tuning Head

    /// `ClassificationHead` is a new set of layers added on top of the
    /// `FeatureExtractor`. This module is specifically designed to be trained
    /// on the new, smaller dataset for the custom classes. By only training
    /// this head, we leverage the general features learned by the `FeatureExtractor`
    /// while adapting the model to our specific task, a core concept in transfer learning.
    ///
    /// This module also inherits from `MLXNN.Module`.
    class ClassificationHead: MLXNN.Module {
        let linear1: MLXNN.Linear
        let linear2: MLXNN.Linear

        /// Initializes the classification head.
        /// - Parameters:
        ///   - inputFeatures: The number of features received from the `FeatureExtractor`.
        ///   - numClasses: The number of custom classes to classify.
        init(inputFeatures: Int, numClasses: Int) {
            self.linear1 = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: 128)
            self.linear2 = MLXNN.Linear(inputFeatures: 128, outputFeatures: numClasses)
            super.init()
        }

        /// Defines the forward pass of the classification head.
        /// - Parameter x: An `MLXArray` representing the flattened features from the extractor.
        /// - Returns: An `MLXArray` containing the raw logits for each class.
        override func callAsFunction(_ x: MLXArray) -> MLXArray {
            var x = x
            x = MLXNN.relu(linear1(x)) // Apply linear transformation and ReLU
            x = linear2(x)             // Final linear layer for logits (no activation for cross-entropy)
            return x
        }
    }

    // MARK: - 4. The Complete Fine-tunable Model

    /// `FineTunableClassifier` combines the `FeatureExtractor` and `ClassificationHead`
    /// into a single, cohesive model. This structure allows for easy separation
    /// of parameters for fine-tuning, where only the `classificationHead`'s parameters
    /// are updated during training, while the `featureExtractor`'s remain frozen.
    ///
    /// This is the top-level `MLXNN.Module` for our complete model.
    class FineTunableClassifier: MLXNN.Module {
        let featureExtractor: FeatureExtractor
        let classificationHead: ClassificationHead

        /// Initializes the complete classifier.
        /// - Parameter numClasses: The number of custom classes.
        init(numClasses: Int) {
            self.featureExtractor = FeatureExtractor()
            // Calculate input features for the head based on the feature extractor's output:
            // Input: [B, 3, 32, 32]
            // After conv1 + pool: [B, 16, 16, 16]
            // After conv2 + pool: [B, 32, 8, 8]
            // Flattened features = channels * height * width = 32 * 8 * 8 = 2048.
            self.classificationHead = ClassificationHead(inputFeatures: 32 * 8 * 8, numClasses: numClasses)
            super.init()
        }

        /// Defines the forward pass of the entire model.
        /// - Parameter x: An `MLXArray` representing the input image batch.
        /// - Returns: An `MLXArray` containing the raw logits for each class.
        override func callAsFunction(_ x: MLXArray) -> MLXArray {
            var features = featureExtractor(x)
            // Flatten the features from [batch_size, channels, height, width]
            // to [batch_size, channels * height * width] for the linear layers.
            features = features.reshaped([features.shape[0], -1])
            return classificationHead(features)
        }
    }

    // MARK: - 5. Loss Function

    /// Computes the categorical cross-entropy loss.
    /// This function is used to quantify the difference between the model's
    /// predicted logits and the true labels during training.
    /// While `MLXNN.losses.crossEntropy` exists, this custom implementation
    /// provides pedagogical clarity on how such functions are constructed.
    /// - Parameters:
    ///   - predictions: The raw logits output by the model.
    ///   - targets: The one-hot encoded true labels.
    /// - Returns: An `MLXArray` representing the scalar loss value.
    private func crossEntropyLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        // For numerical stability, it's common to compute log_softmax.
        let logSoftmaxPreds = MLXNN.logSoftmax(predictions, axis: -1)
        // Multiply log probabilities by targets (which are 0 or 1 for one-hot)
        // and sum over the class dimension, then negate for negative log likelihood.
        // Finally, take the mean over the batch to get the average loss.
        return -(targets * logSoftmaxPreds).sum(axis: -1).mean()
    }

    // MARK: - 6. Training Loop (Fine-tuning)

    /// Fine-tunes the `ClassificationHead` of the model using a simulated dataset.
    /// This function demonstrates the core training loop, including:
    /// 1. Generating dummy data.
    /// 2. Defining the loss function.
    /// 3. Using `valueAndGradient` for efficient gradient computation.
    /// 4. Applying gradients with an optimizer.
    /// 5. Leveraging Swift 6 concurrency for asynchronous training.
    /// - Parameter epochs: The number of training epochs.
    /// - Parameter batchSize: The number of samples per training batch.
    public func fineTuneModel(epochs: Int = 10, batchSize: Int = 32) async throws {
        print("Starting fine-tuning for \(numCustomClasses) custom classes...")

        // The optimizer will only update the parameters of the classification head.
        // This effectively "freezes" the feature extractor, as its parameters
        // are not passed to the optimizer. This is a key aspect of transfer learning,
        // preserving the general features learned by the backbone.
        let optimizer = MLXOptimizers.Adam(learningRate: 1e-3)
        var headParameters = model.classificationHead.parameters()

        // Define the loss function to be used with valueAndGradient.
        // It takes the model and input data, returning the scalar loss.
        let lossFn = { (model: FineTunableClassifier, x: MLXArray, y: MLXArray) -> MLXArray in
            let predictions = model(x)
            return self.crossEntropyLoss(predictions: predictions, targets: y)
        }

        // `valueAndGradient` is a powerful MLX functional transformation.
        // It computes both the loss value and its gradients with respect to
        // the specified parameters (here, `headParameters`) in a single, optimized pass.
        //
        // MLX employs **lazy evaluation**: operations like `model(x)` or `crossEntropyLoss`
        // do not execute immediately. Instead, they build a computation graph (a Directed Acyclic Graph - DAG).
        // The actual computation (on the GPU/CPU) only occurs when a result is explicitly
        // requested, typically via `eval()` or when converting an `MLXArray` to a Swift type.
        // This allows MLX to optimize the entire graph before execution.
        let vg = MLX.valueAndGradient(lossFn, arguments: headParameters)

        for epoch in 0..<epochs {
            var totalLoss: Float = 0.0
            let numBatches = 5 // Simulate 5 batches per epoch for a small dataset

            for batch in 0..<numBatches {
                // Generate dummy data for the current batch.
                // In a real app, this would load actual images and their corresponding labels
                // from the user's curated dataset.
                let classIndex = batch % numCustomClasses // Cycle through classes for balanced batches
                let (images, labels) = (
                    generateDummyImageData(batchSize: batchSize, label: classIndex),
                    generateDummyLabels(batchSize: batchSize, classIndex: classIndex)
                )

                // Perform the forward pass and compute gradients.
                // At this point, MLX is building the computation graph for the forward and backward passes.
                let (loss, gradients) = vg(model, images, labels)

                // `eval()` triggers the execution of the computation graph on the device.
                // This is where the lazy computation is materialized, and the loss and gradients
                // are computed on the GPU (or CPU, depending on `MLX.defaultDevice`).
                (loss, gradients).eval()

                // Update the model's parameters using the optimizer and gradients.
                // Only `headParameters` (from `model.classificationHead`) are updated.
                optimizer.update(model: model.classificationHead, gradients: gradients)

                // Add the loss to totalLoss. We need to convert MLXArray to Swift Float.
                totalLoss += loss.item(Float.self) ?? 0.0
            }

            let avgLoss = totalLoss / Float(numBatches)
            print("Epoch \(epoch + 1)/\(epochs), Average Loss: \(String(format: "%.4f", avgLoss))")

            // Yield to allow other tasks to run. This is crucial for maintaining
            // UI responsiveness in a real application during long-running computations.
            try Task.checkCancellation() // Check if the task has been cancelled
            await Task.yield()           // Give other tasks a chance to execute
        }

        // After training, ensure all updated parameters are evaluated and ready for inference.
        // This ensures the latest weights are on the device and accessible.
        model.classificationHead.parameters().eval()
        print("Fine-tuning complete. Model ready for inference.")
    }

    // MARK: - 7. Prediction Logic

    /// Performs inference on a batch of new images using the fine-tuned model.
    /// - Parameter images: An `MLXArray` representing a batch of images to classify.
    ///   Expected shape: `[batch_size, channels, height, width]`.
    /// - Returns: An array of `Int` where each element is the predicted class index.
    public func predict(images: MLXArray) async throws -> [Int] {
        guard images.shape.count == 4 && images.shape[1...].elementsEqual(SmartPhotoAlbumMLService.imageShape) else {
            throw MLXServiceError.invalidInputShape(
                expected: "[batch_size, \(SmartPhotoAlbumMLService.imageShape.map { String($0) }.joined(separator: ", "))]",
                actual: images.shape.map { String($0) }.joined(separator: ", ")
            )
        }

        // Perform a forward pass with the model.
        // For inference, we only need the output, not gradients.
        let logits = model(images)

        // Apply softmax to convert logits into probabilities.
        // This is useful for understanding the model's confidence.
        let probabilities = MLXNN.softmax(logits, axis: -1)

        // Get the index of the maximum probability for each sample in the batch.
        // This index corresponds to the predicted class.
        let predictions = probabilities.argmax(axis: -1)

        // `eval()` to force computation and retrieve results from the device.
        // This executes the inference graph.
        predictions.eval()

        // Convert the `MLXArray` of predictions to a Swift array of `Int`.
        guard let result = predictions.toArray(Int.self) as? [Int] else {
            throw MLXServiceError.predictionConversionFailed
        }

        return result
    }

    /// An example of how to use the prediction function with a single image.
    /// - Parameter image: A single image as an `MLXArray`.
    ///   Expected shape: `[channels, height, width]`.
    /// - Returns: The predicted class index as an `Int`.
    public func predictSingleImage(_ image: MLXArray) async throws -> Int {
        guard image.shape.count == 3 && image.shape.elementsEqual(SmartPhotoAlbumMLService.imageShape) else {
            throw MLXServiceError.invalidInputShape(
                expected: SmartPhotoAlbumMLService.imageShape.map { String($0) }.joined(separator: ", "),
                actual: image.shape.map { String($0) }.joined(separator: ", ")
            )
        }
        // Reshape the single image to a batch of one for the model,
        // as models typically expect a batch dimension.
        let batchImage = image.reshaped([1] + SmartPhotoAlbumMLService.imageShape)
        let predictions = try await predict(images: batchImage)
        guard let singlePrediction = predictions.first else {
            throw MLXServiceError.predictionConversionFailed
        }
        return singlePrediction
    }

    // MARK: - Error Handling

    /// Custom error types for the MLX service, providing specific details
    /// for common issues encountered during model operations.
    enum MLXServiceError: Error, LocalizedError {
        case invalidInputShape(expected: String, actual: String)
        case predictionConversionFailed
        case trainingInterrupted

        var errorDescription: String? {
            switch self {
            case .invalidInputShape(let expected, let actual):
                return "Input MLXArray has an unexpected shape. Expected: \(expected), Actual: \(actual)."
            case .predictionConversionFailed:
                return "Failed to convert MLXArray predictions to Swift array."
            case .trainingInterrupted:
                return "Training was interrupted, possibly due to cancellation."
            }
        }
    }
}

// MARK: - 8. App Context Integration (Example Usage)

/// This section demonstrates how the `SmartPhotoAlbumMLService` would be integrated
/// into a larger SwiftUI or UIKit application, typically within an `App` or `SceneDelegate`.
/// It showcases asynchronous model initialization, fine-tuning, and inference.
@available(iOS 18.0, macOS 15.0, *)
@main
struct SmartPhotoAlbumApp {
    static func main() async {
        let numFlowerTypes = 3 // e.g., 0: Rose, 1: Tulip, 2: Daisy
        let mlService = SmartPhotoAlbumMLService(numCustomClasses: numFlowerTypes)

        print("\n--- Smart Photo Album ML Service Demo ---")
        print("Initializing MLX on device: \(MLX.defaultDevice)")
        print("Simulating fine-tuning for \(numFlowerTypes) custom flower types (Rose, Tulip, Daisy).")

        do {
            // Simulate a long-running fine-tuning process.
            // This is wrapped in a `Task` to run asynchronously, preventing UI freezes
            // in a real application. `await trainingTask.result` ensures the main flow
            // waits for training to complete before proceeding to inference.
            let trainingTask = Task {
                try await mlService.fineTuneModel(epochs: 5, batchSize: 16)
            }

            _ = await trainingTask.result // Wait for training to complete or fail

            print("\n--- Inference Demo ---")
            // Simulate new images coming from the camera or photo library.
            // These images would then be preprocessed (resized, normalized)
            // into an MLXArray format.
            let newImageBatch = mlService.generateDummyImageData(batchSize: 2) // Two images for prediction

            // Predict for the batch of images.
            let predictions = try await mlService.predict(images: newImageBatch)
            print("Predicted classes for a batch of new images: \(predictions)") // e.g., [0, 1] might mean Rose, Tulip

            // Predict for a single image.
            // The `squeezed(axis: 0)` removes the batch dimension, making it a single image.
            let singleImage = mlService.generateDummyImageData(batchSize: 1).squeezed(axis: 0)
            let singlePrediction = try await mlService.predictSingleImage(singleImage)
            print("Predicted class for a single new image: \(singlePrediction)") // e.g., 2 might mean Daisy

        } catch {
            print("An error occurred: \(error.localizedDescription)")
            if let mlxError = error as? SmartPhotoAlbumMLService.MLXServiceError {
                print("MLX Specific Error: \(mlxError)")
            }
        }
        print("--- Demo End ---")
    }
}
