
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// Domain-specific errors for the OpenAI Service.
enum OpenAIError: Error, LocalizedError, Sendable {
    case invalidAuthentication
    case rateLimitExceeded(retryAfter: Double?)
    case insufficientQuota
    case contextWindowExceeded
    case networkError(Error)
    case decodingError(DecodingError)
    case unknown(String)

    var errorDescription: String? {
        switch self {
        case .invalidAuthentication:
            return "Invalid API Key. Please check your credentials."
        case .rateLimitExceeded:
            return "Too many requests. Please wait a moment before trying again."
        case .insufficientQuota:
            return "Your OpenAI account has run out of credits. Please check your billing settings."
        case .contextWindowExceeded:
            return "The conversation is too long for the model to process."
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .decodingError:
            return "Failed to parse the response from the server."
        case .unknown(let message):
            return message
        }
    }
}

/// Structure to parse OpenAI's error JSON body.
struct OpenAIErrorResponse: Codable, Sendable {
    let message: String
    let type: String
    let param: String?
}

// --- Extension to the existing OpenAIService from Exercise 1 ---
extension OpenAIService {
    // Note: In a real project, this would replace the error logic in Exercise 1
    private func handleHTTPError(data: Data, response: URLResponse) throws {
        guard let httpResponse = response as? HTTPURLResponse else {
            throw OpenAIError.unknown("Invalid response type.")
        }

        // Attempt to parse OpenAI's specific error JSON
        let errorBody = try? JSONDecoder().decode(OpenAIErrorResponse.self, from: data)

        switch httpResponse.statusCode {
        case 401:
            throw OpenAIError.invalidAuthentication
        case 429:
            // Check for Retry-After header
            let retryAfter = httpResponse.value(forHTTPHeaderField: "Retry-After").flatMap(Double.init)
            throw OpenAIError.rateLimitExceeded(retryAfter: retryAfter)
        case 400...499:
            if let msg = errorBody?.message {
                if msg.contains("insufficient_quota") {
                    throw OpenAIError.insufficientQuota
                } else if msg.contains("context_length_exceeded") {
                    throw OpenAIError.contextWindowExceeded
                }
                throw OpenAIError.unknown(msg)
            }
            throw OpenAIError.unknown("Client error: \(httpResponse.statusCode)")
        default:
            throw OpenAIError.unknown("Server error: \(httpResponse.statusCode)")
        }
    }
}
