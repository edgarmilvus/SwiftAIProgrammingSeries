
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import AppTrackingTransparency
import Combine

// 1. State Management using modern @Observable
@Observable
@MainActor
class PrivacyState {
    var authorizationStatus: ATTrackingManager.AuthorizationStatus = .notDetermined
}

// 2. The PrivacyManager Actor to handle the async request safely
actor PrivacyManager {
    private let state: PrivacyState
    
    init(state: PrivacyState) {
        self.state = state
    }
    
    /// Requests authorization and updates the observable state
    func requestTrackingAuthorization() async {
        // Ensure we are checking the status on the main actor for the UI update
        let status = await ATTrackingManager.requestTrackingAuthorization()
        
        await MainActor.run {
            state.authorizationStatus = status
        }
    }
    
    /// Returns the current status without requesting
    func checkStatus() async -> ATTrackingManager.AuthorizationStatus {
        return ATTrackingManager.trackingAuthorizationStatus
    }
}

// 3. The App Entry Point managing the lifecycle
@main
struct LexiAIApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @State private var privacyState = PrivacyState()
    @State private var privacyManager: PrivacyManager?

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(privacyState)
                .onAppear {
                    // Initialize the actor
                    privacyManager = PrivacyManager(state: privacyState)
                }
                .onChange(of: scenePhase) { oldPhase, newPhase in
                    if newPhase == .active {
                        Task {
                            await privacyManager?.requestTrackingAuthorization()
                        }
                    }
                }
        }
    }
}

// Info.plist Requirement (Pseudo-code representation):
// <key>NSUserTrackingUsageDescription</key>
// <string>Your data helps us refine our AI models to provide more contextually relevant responses across your creative workflows.</string>
