
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import XCTest
import Vision
import CoreML

// 1. Mathematical Utility for Similarity
enum VectorMath {
    static func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// 2. The Comparison Engine
final class ModelComparisonEngine {
    func extractEmbeddings(from image: UIImage) async throws -> [Float] {
        guard let cgImage = image.cgImage else { throw NSError(domain: "ImageError", code: -1) }
        
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNGenerateImageFeaturePrintRequest()
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            
            do {
                try handler.perform([request])
                if let observation = request.results?.first as? VNFeaturePrintObservation {
                    // Convert feature print to a Float array
                    // Note: In a real scenario, you'd extract the raw data from the observation
                    let data = observation.data
                    let floatArray = data.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
                    continuation.resume(returning: floatArray)
                } else {
                    continuation.resume(throwing: NSError(domain: "VisionError", code: -2))
                }
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

// 3. The Regression Test Suite
final class LuminaVisionRegressionTests: XCTestCase {
    let engine = ModelComparisonEngine()
    let similarityThreshold: Float = 0.95
    
    // Mocking the "Golden Set"
    let goldenImages: [UIImage] = [] // Assume these are loaded from the test bundle

    func test_modelV2_regression_against_baseline() async throws {
        // In a real test, these would be actual CoreML models
        // We simulate the feature vectors for the sake of the exercise
        let baselineVector: [Float] = [0.1, 0.5, 0.8, 0.2]
        let candidateVector: [Float] = [0.11, 0.49, 0.79, 0.21] // Very similar
        
        // 1. Performance Benchmarking
        let startV1 = CFAbsoluteTimeGetCurrent()
        // runInference(modelV1)
        let endV1 = CFAbsoluteTimeGetCurrent()
        
        let startV2 = CFAbsoluteTimeGetCurrent()
        // runInference(modelV2)
        let endV2 = CFAbsoluteTimeGetCurrent()
        
        let v1Duration = endV1 - startV1
        let v2Duration = endV2 - startV2
        
        XCTAssertLessThan(v2Duration, v1Duration * 1.15, "Model V2 is too slow (regression in performance)")

        // 2. Semantic Similarity Check
        let similarity = VectorMath.cosineSimilarity(baselineVector, candidateVector)
        
        print("Similarity Score: \(similarity)")
        XCTAssertGreaterThan(similarity, similarityThreshold, "Model V2 output is perceptually too different from V1")
    }
}
