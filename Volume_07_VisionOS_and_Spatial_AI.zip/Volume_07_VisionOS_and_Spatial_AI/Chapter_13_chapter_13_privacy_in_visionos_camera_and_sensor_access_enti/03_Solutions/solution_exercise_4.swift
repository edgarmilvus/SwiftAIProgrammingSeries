
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import ARKit

/// The only data allowed to leave the secure ingestion actor.
/// Being an enum, it is a value type and inherently Sendable.
enum GestureIntent: Sendable {
    case select
    case dismiss
    case zoom(scale: Float)
    case none
}

/// A high-security actor that acts as a "Privacy Sandbox".
/// This actor is the ONLY entity with access to the raw HandAnchor data.
actor SensorIngestionActor {
    private let handProvider = HandTrackingProvider()
    
    /// This function ingests raw data, processes it through a (simulated) CoreML model,
    /// and returns only a high-level intent.
    /// The raw HandAnchor NEVER leaves this actor's scope.
    func processGestures() async -> GestureIntent {
        // 1. Ingest raw sensor data
        // In a real app, we would iterate through handProvider.handAnchors
        let simulatedHandAnchor = HandAnchor() 
        
        // 2. Perform "In-Place" processing
        let intent = await performCoreMLInference(on: simulatedHandAnchor)
        
        // 3. The raw 'simulatedHandAnchor' is now out of scope and will be deallocated.
        // Only the 'intent' (a small enum) is returned to the caller.
        return intent
    }
    
    /// Simulated CoreML inference engine.
    private func performCoreMLInference(on anchor: HandAnchor) async -> GestureIntent {
        // Here, we would extract joint transforms (e.g., thumb tip to index tip distance)
        // and feed them into a CoreML model.
        
        // Simulate a 'Pinch' gesture detection
        let isPinching = true 
        
        if isPinching {
            return .select
        } else {
            return .none
        }
    }
}

/// The dispatcher responsible for executing app logic based on intents.
@MainActor
class IntentDispatcher: ObservableObject {
    private let ingestionActor = SensorIngestionActor()
    
    @Published var currentAction: String = "Waiting..."

    func startListening() {
        Task {
            while true {
                // We call the actor and receive a Sendable enum.
                // The raw coordinates are trapped inside the actor.
                let intent = await ingestionActor.processGestures()
                handleIntent(intent)
                
                // Maintain the 60/90Hz loop
                try? await Task.sleep(for: .milliseconds(16))
            }
        }
    }
    
    private func handleIntent(_ intent: GestureIntent) {
        switch intent {
        case .select:
            currentAction = "Action: Object Selected"
        case .dismiss:
            currentAction = "Action: UI Dismissed"
        case .zoom(let scale):
            currentAction = "Action: Zooming at \(scale)x"
        case .none:
            break
        }
    }
}
