
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import RealityKit
import ARKit

struct ArtifactInfoCard: View {
    let name: String
    let era: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(name).font(.headline).foregroundColor(.white)
            Text(era).font(.subheadline).foregroundColor(.secondary)
            
            // Nested 3D content within the 2D UI
            Model3D(named: "artifact_internal_structure")
                .frame(width: 200, height: 200)
                .aspectRatio(contentMode: .fit)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(20)
    }
}

@MainActor
class MuseumCuratorManager: ObservableObject {
    var arView: ARView
    private var cardEntity: Entity?
    private var targetRotation: simd_quatf = simd_quaternion(0, [0, 1, 0])

    init(arView: ARView) {
        self.arView = arView
    }

    func anchorInfoCard(at transform: simd_float4x4, artifactName: String) {
        let anchor = ARAnchor(name: "ArtifactAnchor", transform: transform)
        arView.session.add(anchor: anchor)
        
        // Create the attachment
        let attachmentID = UUID()
        let card = ViewAttachmentEntity(id: attachmentID, content: ArtifactInfoCard(name: artifactName, era: "Classical Greek"))
        
        let container = Entity()
        container.addChild(card)
        
        let anchorEntity = AnchorEntity(anchor: anchor)
        anchorEntity.addChild(container)
        
        // Apply "Social Distance" offset
        container.position = [0.4, 0, 0] // Offset to the side
        
        arView.scene.addAnchor(anchorEntity)
        self.cardEntity = container
    }

    // Soft Billboarding: Smoothly interpolates rotation
    func updateCardOrientation(cameraTransform: simd_float4x4) {
        guard let card = cardEntity else { return }
        
        let cameraPos = simd_make_float3(cameraTransform.columns.3)
        let cardPos = card.position(relativeTo: nil)
        let direction = simd_normalize(cameraPos - cardPos)
        
        // Calculate the desired rotation
        let desiredRotation = simd_quaternion(direction, [0, 0, 1])
        
        // Soft Billboarding: Use slerp (Spherical Linear Interpolation)
        // 0.1 is the smoothing factor. Lower = smoother/slower.
        card.orientation = simd_slerp(card.orientation, desiredRotation, 0.1)
    }
}
