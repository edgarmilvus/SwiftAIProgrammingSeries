
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftData
import LlamaCpp // Assuming llama.cpp.swift is added as a dependency

// MARK: - 1. KnowledgeChunk Data Model

@Model
final class KnowledgeChunk {
    var id: UUID
    var content: String
    var embeddingData: Data // Stored as Data
    var sourceURL: URL?
    var timestamp: Date
    var documentIdentifier: String? // For tracking original document in later exercises

    init(id: UUID = UUID(), content: String, embeddingData: Data, sourceURL: URL? = nil, timestamp: Date = Date(), documentIdentifier: String? = nil) {
        self.id = id
        self.content = content
        self.embeddingData = embeddingData
        self.sourceURL = sourceURL
        self.timestamp = timestamp
        self.documentIdentifier = documentIdentifier
    }
}

// MARK: - Shared Protocols

protocol EmbeddingService {
    func generateEmbedding(for text: String) async throws -> [Float]
}

protocol TextChunker {
    func chunk(text: String, maxChunkSize: Int, overlapSize: Int) -> [String]
}

protocol LLMService {
    func generateResponse(prompt: String) async throws -> String
}

// MARK: - 2. Implement a Text Chunking Strategy

class SimpleTextChunker: TextChunker {
    // A simple chunking strategy that splits text into sentences or paragraphs.
    // It tries to respect maxChunkSize but doesn't guarantee exact token counts.
    // Overlap is implemented by appending the last part of the previous chunk.
    func chunk(text: String, maxChunkSize: Int, overlapSize: Int = 0) -> [String] {
        var chunks: [String] = []
        let paragraphs = text.split(separator: "\n\n").map(String.init) // Split by paragraphs

        var currentChunk = ""
        var previousChunk = "" // Used for overlap

        for paragraph in paragraphs {
            if currentChunk.isEmpty {
                currentChunk = paragraph
            } else {
                // If adding the next paragraph exceeds maxChunkSize, finalize current chunk
                if (currentChunk + "\n\n" + paragraph).count > maxChunkSize {
                    chunks.append(currentChunk.trimmingCharacters(in: .whitespacesAndNewlines))
                    previousChunk = currentChunk // Store for overlap
                    currentChunk = "" // Reset for new chunk

                    // Add overlap from the previous chunk
                    if overlapSize > 0 && previousChunk.count > overlapSize {
                        currentChunk += previousChunk.suffix(overlapSize) + "\n\n"
                    }
                    currentChunk += paragraph
                } else {
                    currentChunk += "\n\n" + paragraph
                }
            }
        }

        // Add any remaining text as the last chunk
        if !currentChunk.isEmpty {
            chunks.append(currentChunk.trimmingCharacters(in: .whitespacesAndNewlines))
        }

        // Fallback for very long single paragraphs/sentences that exceed maxChunkSize
        // This splits by sentence if a chunk is still too large after paragraph splitting.
        var finalChunks: [String] = []
        for chunk in chunks {
            if chunk.count > maxChunkSize {
                let sentences = chunk.split(separator: ".").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) + "." }
                var subChunk = ""
                for sentence in sentences {
                    if (subChunk + " " + sentence).count > maxChunkSize && !subChunk.isEmpty {
                        finalChunks.append(subChunk)
                        subChunk = sentence
                    } else {
                        subChunk += (subChunk.isEmpty ? "" : " ") + sentence
                    }
                }
                if !subChunk.isEmpty {
                    finalChunks.append(subChunk)
                }
            } else {
                finalChunks.append(chunk)
            }
        }

        return finalChunks.filter { !$0.isEmpty }
    }
}

// MARK: - 3. Integrate a Local Embedding Model (using llama.cpp.swift)

enum EmbeddingServiceError: Error, LocalizedError {
    case modelNotLoaded
    case embeddingFailed(String)
    case dataConversionFailed

    var errorDescription: String? {
        switch self {
        case .modelNotLoaded: return "Embedding model is not loaded or initialized."
        case .embeddingFailed(let message): return "Embedding generation failed: \(message)"
        case .dataConversionFailed: return "Failed to convert embedding data."
        }
    }
}

class LlamaCppEmbeddingService: EmbeddingService {
    private var llamaCpp: LlamaCpp?
    private let modelPath: String
    private let modelLock = NSLock() // To ensure thread-safe model initialization

    init(modelPath: String) {
        self.modelPath = modelPath
    }

    // Lazy initialization of the LlamaCpp model
    func loadModel() async throws {
        modelLock.lock()
        defer { modelLock.unlock() }

        guard llamaCpp == nil else { return } // Model already loaded

        let url = URL(fileURLWithPath: modelPath)
        guard FileManager.default.fileExists(atPath: modelPath) else {
            throw EmbeddingServiceError.modelNotLoaded // More specific error
        }

        do {
            // LlamaCpp.init can be blocking, so perform on a background thread
            llamaCpp = try await Task.detached(priority: .userInitiated) {
                try LlamaCpp(modelPath: url.path, embedding: true)
            }.value
            print("LlamaCpp embedding model loaded successfully from: \(modelPath)")
        } catch {
            print("Failed to load LlamaCpp embedding model: \(error.localizedDescription)")
            throw EmbeddingServiceError.modelNotLoaded
        }
    }

    func generateEmbedding(for text: String) async throws -> [Float] {
        try await loadModel() // Ensure model is loaded

        guard let llamaCpp = self.llamaCpp else {
            throw EmbeddingServiceError.modelNotLoaded
        }

        do {
            // LlamaCpp.generateEmbedding is typically synchronous but can be long-running.
            // Wrap in Task.detached to avoid blocking the caller's actor.
            let embedding = try await Task.detached(priority: .userInitiated) {
                try llamaCpp.generateEmbedding(text: text)
            }.value
            return embedding
        } catch {
            throw EmbeddingServiceError.embeddingFailed(error.localizedDescription)
        }
    }
}

// Helper for [Float] to Data conversion
extension Array where Element == Float {
    var data: Data {
        return withUnsafeBufferPointer { buffer in
            Data(buffer: buffer)
        }
    }

    init?(data: Data) {
        guard data.count % MemoryLayout<Float>.size == 0 else { return nil }
        let floats = data.withUnsafeBytes {
            Array(UnsafeBufferPointer(start: $0.baseAddress!.assumingMemoryBound(to: Float.self), count: $0.count / MemoryLayout<Float>.size))
        }
        self = floats
    }
}

// MARK: - 4. Persist Embeddings & 5. Basic Ingestion CLI

@available(macOS 15.0, *) // SwiftData requires macOS 15+ or iOS 18+
class KnowledgeIngestor {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService
    private let chunker: TextChunker

    init(modelContext: ModelContext, embeddingService: EmbeddingService, chunker: TextChunker) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
        self.chunker = chunker
    }

    func ingestText(text: String, sourceURL: URL? = nil, documentIdentifier: String? = nil, maxChunkSize: Int = 512, overlapSize: Int = 0) async throws {
        print("Ingesting text (length: \(text.count))...")
        let chunks = chunker.chunk(text: text, maxChunkSize: maxChunkSize, overlapSize: overlapSize)
        print("Text chunked into \(chunks.count) pieces.")

        for (index, chunkContent) in chunks.enumerated() {
            print("Generating embedding for chunk \(index + 1)/\(chunks.count)...")
            let embedding = try await embeddingService.generateEmbedding(for: chunkContent)
            let embeddingData = embedding.data

            let knowledgeChunk = KnowledgeChunk(
                content: chunkContent,
                embeddingData: embeddingData,
                sourceURL: sourceURL,
                timestamp: Date(),
                documentIdentifier: documentIdentifier
            )
            modelContext.insert(knowledgeChunk)
            print("Chunk \(index + 1) embedded and persisted.")
        }

        do {
            try modelContext.save()
            print("All chunks saved to SwiftData successfully.")
        } catch {
            print("Failed to save chunks to SwiftData: \(error.localizedDescription)")
            throw error
        }
    }
}

// MARK: - CLI Application Entry Point (for demonstration)

@main
@available(macOS 15.0, *)
struct KnowledgeBaseApp {
    static let embeddingModelPath = "/path/to/your/embedding_model.gguf" // !!! REPLACE THIS !!!
    
    // For a real app, ensure the model is copied into the app bundle or downloaded.
    // Example for copying:
    // 1. Download a suitable embedding model (e.g., all-MiniLM-L6-v2-f16.gguf or a small LLM that supports embeddings)
    //    from Hugging Face (e.g., https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/ggml-model-q4_0.gguf)
    //    and convert to gguf if needed, or find a pre-converted one.
    // 2. Drag it into your Xcode project, ensuring "Copy items if needed" and "Add to targets" are checked.
    // 3. Get the path from the bundle:
    //    `Bundle.main.path(forResource: "embedding_model", ofType: "gguf")`

    static func main() async {
        // --- SwiftData Setup ---
        let schema = Schema([KnowledgeChunk.self])
        let modelConfiguration = ModelConfiguration(schema: schema, is */**
         * For a real app, ensure the model is copied into the app bundle or downloaded.
         * Example for copying:
         * 1. Download a suitable embedding model (e.g., all-MiniLM-L6-v2-f16.gguf or a small LLM that supports embeddings)
         *    from Hugging Face (e.g., https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/ggml-model-q4_0.gguf)
         *    and convert to gguf if needed, or find a pre-converted one.
         * 2. Drag it into your Xcode project, ensuring "Copy items if needed" and "Add to targets" are checked.
         * 3. Get the path from the bundle:
         *    `Bundle.main.path(forResource: "embedding_model", ofType: "gguf")`
         */

        static func main() async {
            // --- SwiftData Setup ---
            let schema = Schema([KnowledgeChunk.self])
            let modelConfiguration = ModelConfiguration(schema: schema, isStoredDynamically: true) // Using in-memory for quick testing
            // For persistence, use: ModelConfiguration(schema: schema, url: URL(fileURLWithPath: "KnowledgeBase.sqlite"))

            guard let modelContainer = try? ModelContainer(for: schema, configurations: [modelConfiguration]) else {
                fatalError("Failed to create ModelContainer.")
            }
            let modelContext = ModelContext(modelContainer)

            // --- Embedding Service Setup ---
            // IMPORTANT: Replace with a valid path to your .gguf embedding model
            // For testing, you might use a tiny LLM model that supports embeddings.
            guard let embeddingModelBundlePath = Bundle.main.path(forResource: "all-MiniLM-L6-v2-f16", ofType: "gguf") else {
                print("Error: Embedding model 'all-MiniLM-L6-v2-f16.gguf' not found in bundle.")
                print("Please download a .gguf embedding model (e.g., from Hugging Face) and add it to your Xcode project's resources.")
                return
            }
            let embeddingService = LlamaCppEmbeddingService(modelPath: embeddingModelBundlePath)
            print("Attempting to load embedding model from: \(embeddingModelBundlePath)")
            do {
                try await embeddingService.loadModel()
                print("Embedding model loaded successfully.")
            } catch {
                print("Failed to load embedding model: \(error.localizedDescription)")
                return
            }

            // --- Text Chunker Setup ---
            let chunker = SimpleTextChunker()

            // --- Ingestor Setup ---
            let ingestor = KnowledgeIngestor(modelContext: modelContext, embeddingService: embeddingService, chunker: chunker)

            // --- CLI Loop ---
            print("\n--- Knowledge Base Ingestion CLI ---")
            print("Type 'ingest' to add new text, 'list' to see all chunks, 'exit' to quit.")

            while true {
                print("\nEnter command: ", terminator: "")
                guard let command = readLine()?.lowercased() else { continue }

                switch command {
                case "ingest":
                    print("Paste text to ingest (type 'END' on a new line to finish):")
                    var fullText = ""
                    while let line = readLine(), line != "END" {
                        fullText += line + "\n"
                    }
                    if !fullText.isEmpty {
                        print("Enter optional source URL (or leave blank): ", terminator: "")
                        let urlString = readLine()
                        let sourceURL = urlString.flatMap { URL(string: $0) }

                        print("Enter optional document identifier (e.g., filename): ", terminator: "")
                        let docId = readLine()

                        do {
                            try await ingestor.ingestText(text: fullText, sourceURL: sourceURL, documentIdentifier: docId, maxChunkSize: 512, overlapSize: 50)
                            print("Text ingested successfully!")
                        } catch {
                            print("Ingestion failed: \(error.localizedDescription)")
                        }
                    } else {
                        print("No text provided for ingestion.")
                    }
                case "list":
                    do {
                        let chunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
                        if chunks.isEmpty {
                            print("No knowledge chunks found.")
                        } else {
                            print("\n--- Stored Knowledge Chunks ---")
                            for (index, chunk) in chunks.enumerated() {
                                print("Chunk \(index + 1) (ID: \(chunk.id.uuidString.prefix(8))):")
                                print("  Content: \(chunk.content.prefix(100))...")
                                print("  Source: \(chunk.sourceURL?.lastPathComponent ?? "N/A")")
                                print("  Timestamp: \(chunk.timestamp)")
                                print("  Embedding Size: \(chunk.embeddingData.count / MemoryLayout<Float>.size) floats")
                                print("--------------------")
                            }
                        }
                    } catch {
                        print("Failed to fetch chunks: \(error.localizedDescription)")
                    }
                case "exit":
                    print("Exiting.")
                    return
                default:
                    print("Unknown command. Try 'ingest', 'list', or 'exit'.")
                }
            }
        }
    }
