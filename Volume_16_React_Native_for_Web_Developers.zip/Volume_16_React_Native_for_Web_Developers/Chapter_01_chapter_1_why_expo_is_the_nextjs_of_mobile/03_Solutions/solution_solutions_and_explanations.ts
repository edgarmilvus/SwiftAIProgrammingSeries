/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/universal.tsx

/**
 * EXERCISE 1: UNIVERSAL APP SKELETON
 * 
 * ROUTING PARALLEL TO NEXT.JS:
 * Expo Router (used in the 'tabs' template) utilizes a file-based routing system
 * similar to Next.js's App Router. 
 * 
 * - In Next.js: A file at `app/about/page.tsx` maps to the `/about` URL.
 * - In Expo Router: A file at `app/universal.tsx` maps to the `/universal` URL.
 * 
 * This abstraction allows a single codebase to handle navigation on iOS, Android, 
 * and Web without configuring native navigation libraries manually.
 */

import { Link } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';

export default function UniversalScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Universal App Skeleton</Text>
      
      <Text style={styles.text}>
        This route (`app/universal.tsx`) demonstrates file-based routing.
        It renders natively on iOS/Android and as standard HTML on Web.
      </Text>

      {/* Using a local asset or a remote image to test asset loading */}
      <Image 
        source={{ uri: 'https://reactnative.dev/img/tiny_logo.png' }} 
        style={styles.logo}
      />

      <View style={styles.linkContainer}>
        <Link href="/" style={styles.link}>
          <Text>← Back to Home</Text>
        </Link>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  text: {
    textAlign: 'center',
    marginBottom: 20,
    fontSize: 16,
    color: '#555',
  },
  logo: {
    width: 50,
    height: 50,
    marginBottom: 20,
  },
  linkContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
  },
  link: {
    color: 'blue',
    fontWeight: '600',
  },
});
