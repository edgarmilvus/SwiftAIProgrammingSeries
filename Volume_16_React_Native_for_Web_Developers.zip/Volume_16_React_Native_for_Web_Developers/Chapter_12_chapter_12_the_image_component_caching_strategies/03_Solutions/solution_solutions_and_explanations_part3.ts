/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: utils/manualImageCache.ts
import AsyncStorage from '@react-native-async-storage/async-storage';
import Crypto from 'crypto-js'; // Assuming a hashing library is available, or use a simple hash function

// 1. Cache Key Generation
// We use a simple hash of the URL to create a valid storage key.
const generateCacheKey = (url: string): string => {
    // In a real app, use a robust hashing algo. Here we simulate it with a simple string manipulation for the example
    // or use CryptoJS if available.
    return `image_cache_${url.replace(/[^a-zA-Z0-9]/g, '_')}`;
};

export const fetchAndCacheImage = async (url: string): Promise<string | null> => {
    const cacheKey = generateCacheKey(url);

    try {
        // 2. Check Cache
        const cachedData = await AsyncStorage.getItem(cacheKey);
        if (cachedData) {
            console.log('Returning cached data for:', url);
            return cachedData; // Returns Base64 string
        }

        // 3. Network Fetch
        console.log('Fetching network data for:', url);
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Convert blob to Base64
        const blob = await response.blob();
        const base64Data = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });

        // 4. Store Cache
        // We store the full DataURL (e.g., "data:image/png;base64,...")
        await AsyncStorage.setItem(cacheKey, base64Data);

        return base64Data;

    } catch (error) {
        // 5. Error Handling
        console.error('Manual Cache Error:', error);
        // Return null or a specific broken image placeholder URI
        return null; 
    }
};
