
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part8.swift
// Description: Advanced Application
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct LocalBrainChatView: View {
    @StateObject private var modelManager = LocalAIModelManager()
    @State private var selectedModel: LLMModelConfiguration = .phi3_mini_4k_instruct
    @State private var chatPrompt: String = ""
    @State private var chatHistory: [String] = []
    @State private var currentStreamedResponse: String = ""
    @State private var isGenerating: Bool = false
    
    var body: some View {
        VStack(spacing: 15) {
            // MARK: - Model Selection
            Picker("Select Model", selection: $selectedModel) {
                ForEach(LLMModelConfiguration.allCases) { model in
                    Text(model.displayName)
                        .tag(model)
                }
            }
            .pickerStyle(.menu)
            .disabled(modelManager.isLoadingModel || isGenerating)
            .onChange(of: selectedModel) { oldModel, newModel in
                // Automatically load the new model when selection changes
                Task { await modelManager.loadModel(newModel) }
            }
            .padding(.horizontal)

            Text(modelManager.statusMessage)
                .font(.caption)
                .foregroundColor(.secondary)
            
            // MARK: - Chat History
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(chatHistory, id: \.self) { message in
                        Text(message)
                            .padding(8)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                    if isGenerating {
                        Text("Assistant: \(currentStreamedResponse)")
                            .padding(8)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.white.opacity(0.05))
            .cornerRadius(10)
            .padding(.horizontal)

            // MARK: - Input Area
            HStack {
                TextField("Ask your local AI...", text: $chatPrompt, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .lineLimit(1...5)
                    .disabled(modelManager.currentModelConfiguration == nil || isGenerating)
                
                if isGenerating {
                    Button("Stop") {
                        modelManager.cancelInference()
                        isGenerating = false
                        currentStreamedResponse = "" // Clear partial response
                    }
                    .buttonStyle(.borderedProminent)
                } else {
                    Button("Send") {
                        sendPrompt()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(chatPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || modelManager.currentModelConfiguration == nil)
                }
            }
            .padding(.horizontal)

            // MARK: - Performance Metrics
            if let result = modelManager.lastInferenceResult {
                VStack(alignment: .leading) {
                    Text("Last Inference:")
                        .font(.headline)
                    Text("Duration: \(String(format: "%.2f", result.inferenceDuration))s")
                    Text("Tokens Generated: \(result.tokenCount)")
                    Text("Tokens/sec: \(String(format: "%.1f", result.tokensPerSecond))")
                }
                .font(.footnote)
                .foregroundColor(.secondary)
                .padding(.horizontal)
            }
        }
        .padding(.vertical)
        .navigationTitle("LocalBrain AI")
        .task {
            // Load the initial model when the view appears
            await modelManager.loadModel(selectedModel)
        }
    }
    
    /// Handles sending the prompt to the LLM manager and processing the streamed response.
    private func sendPrompt() {
        guard !chatPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let currentPrompt = chatPrompt
        chatHistory.append("You: \(currentPrompt)")
        chatPrompt = "" // Clear input field immediately
        currentStreamedResponse = ""
        isGenerating = true

        Task {
            do {
                let stream = modelManager.generateResponse(prompt: currentPrompt)
                for try await token in stream {
                    currentStreamedResponse += token
                }
                // Once stream finishes, add the full response to history
                chatHistory.append("Assistant: \(currentStreamedResponse.trimmingCharacters(in: .whitespacesAndNewlines))")
                currentStreamedResponse = "" // Clear for next response
                isGenerating = false
            } catch {
                chatHistory.append("Assistant (Error): \(error.localizedDescription)")
                isGenerating = false
                currentStreamedResponse = ""
            }
        }
    }
}
