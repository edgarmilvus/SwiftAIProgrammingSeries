
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for Swift Package Manager
// This would be part of your project's Package.swift file
// dependencies: [
//     .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.14.0") // Or the latest version
// ]
// targets: [
//     .target(
//         name: "YourAppTarget",
//         dependencies: ["mlx-swift"]
//     )
// ]

import Foundation
import MLX
import MLXNN // For MLXNN.Module

// MARK: - 1. MLX Embedding Model Definition

/// A simplified MLX embedding model for demonstration purposes.
/// In a real application, this would load a pre-trained model (e.g., a BERT variant
/// converted to MLX format) with multiple layers.
/// This example simulates the final dense layer that projects to an embedding space.
final class EmbeddingModel: MLXNN.Module {
    let projectionLayer: MLXNN.Linear
    let embeddingDimension: Int

    /// Initializes the embedding model.
    /// - Parameters:
    ///   - inputDimension: The expected dimension of the input features (e.g., from a token encoder).
    ///   - embeddingDimension: The desired dimension of the output embeddings.
    ///   - parametersPath: An optional path to load pre-trained parameters.
    ///     For this example, we'll initialize random weights if no path is given.
    init(inputDimension: Int, embeddingDimension: Int, parametersPath: String? = nil) {
        self.embeddingDimension = embeddingDimension
        self.projectionLayer = MLXNN.Linear(inputFeatures: inputDimension, outputFeatures: embeddingDimension)
        super.init()

        // In a real scenario, you'd load actual model weights here.
        // For demonstration, we'll use randomly initialized weights.
        if let parametersPath = parametersPath {
            do {
                let loadedParameters = try MLX.load(parametersPath)
                // Assuming `projectionLayer` parameters are directly accessible and match
                // This part would be more complex for a full model with nested layers
                // and require mapping loaded keys to `Module` properties.
                if let weight = loadedParameters["projectionLayer.weight"],
                   let bias = loadedParameters["projectionLayer.bias"] {
                    self.projectionLayer.weight = weight
                    self.projectionLayer.bias = bias
                    print("Loaded parameters from \(parametersPath)")
                } else {
                    print("Warning: Could not find 'projectionLayer.weight' or 'bias' in loaded parameters.")
                }
            } catch {
                print("Error loading model parameters from \(parametersPath): \(error)")
                print("Using randomly initialized weights for EmbeddingModel.")
            }
        } else {
            print("No parameters path provided. Using randomly initialized weights for EmbeddingModel.")
        }
    }

    /// Performs the forward pass of the model.
    /// - Parameter input: An `MLXArray` representing the input features (e.g., token embeddings).
    /// - Returns: An `MLXArray` containing the generated embeddings.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Apply the linear projection.
        // MLX operations are lazily evaluated, building a computation graph.
        // The actual computation occurs when the result is needed (e.g., `eval()`, `toArray()`).
        let embeddings = projectionLayer(input)
        // Normalize the embeddings to unit length, which is common for cosine similarity.
        let norm = MLX.linalg.norm(embeddings, axis: -1, keepdims: true)
        return embeddings / norm
    }

    /// Generates an embedding for a given text string.
    /// This simulates tokenization and input preparation.
    /// - Parameter text: The input text to embed.
    /// - Returns: An `MLXArray` representing the text embedding.
    /// - Throws: An error if embedding fails.
    func embed(text: String) async throws -> MLXArray {
        // --- Simulated Tokenization and Input Preparation ---
        // In a real application, this would involve:
        // 1. A tokenizer (e.g., Byte-Pair Encoding, WordPiece) to convert text to token IDs.
        // 2. Padding/truncation to a fixed sequence length.
        // 3. Converting token IDs to an MLXArray.
        // 4. Potentially looking up token embeddings from an embedding matrix (if not directly
        //    part of the `EmbeddingModel`'s `callAsFunction`).

        // For this example, we'll simulate a fixed-size input based on string length,
        // which is NOT how real tokenization works but demonstrates MLXArray usage.
        let simulatedTokens = text.utf8.count % projectionLayer.inputFeatures // Simple hash-like value
        let inputData = MLXArray.full([1, projectionLayer.inputFeatures], Float(simulatedTokens) / Float(projectionLayer.inputFeatures))

        // Ensure the input is on the correct device (CPU by default for MLX-Swift, but can be Metal).
        // MLXArray benefits from Unified Memory on Apple Silicon, avoiding data copies
        // between CPU and GPU.
        let embedding = self(inputData)
        
        // Explicitly evaluate the graph to get the concrete result.
        // This is where lazy evaluation triggers the computation.
        MLX.eval(embedding)
        
        return embedding
    }
}

// MARK: - 2. Document Chunk Structure

/// Represents a small, semantically coherent piece of a document.
struct DocumentChunk: Identifiable, Hashable {
    let id = UUID()
    let text: String
    let embedding: MLXArray // Stores the MLXArray embedding directly
    let sourceDocumentId: UUID
    let chunkIndex: Int

    static func == (lhs: DocumentChunk, rhs: DocumentChunk) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

// MARK: - 3. Knowledge Base Manager

/// Manages a local knowledge base of embedded document chunks, enabling semantic search.
@available(iOS 18.0, macOS 15.0, *) // Using async/await and modern Swift features
final class KnowledgeBaseManager {
    private let embeddingModel: EmbeddingModel
    private var documents: [UUID: String] = [:] // Original documents by ID
    private var documentChunks: [DocumentChunk] = [] // All processed chunks
    private let chunker: TextChunker // Helper for splitting text
    private let queue = DispatchQueue(label: "com.example.knowledgeBaseQueue", qos: .userInitiated)

    /// Initializes the KnowledgeBaseManager with an embedding model.
    /// - Parameter embeddingModel: The MLX model used to generate embeddings.
    init(embeddingModel: EmbeddingModel) {
        self.embeddingModel = embeddingModel
        self.chunker = TextChunker(maxChunkSize: 256, overlap: 32) // Example chunking parameters
    }

    /// Adds a new document to the knowledge base, processing it into chunks and generating embeddings.
    /// - Parameter documentText: The full text content of the document.
    /// - Returns: The UUID of the added document.
    /// - Throws: An error if embedding fails for any chunk.
    func addDocument(documentText: String) async throws -> UUID {
        let documentId = UUID()
        self.documents[documentId] = documentText

        let chunks = chunker.split(text: documentText)
        var newDocumentChunks: [DocumentChunk] = []

        // Process chunks concurrently for better performance
        try await withThrowingTaskGroup(of: DocumentChunk.self) { group in
            for (index, chunkText) in chunks.enumerated() {
                group.addTask {
                    // Embed the chunk text. This involves MLX operations.
                    let embedding = try await self.embeddingModel.embed(text: chunkText)
                    return DocumentChunk(text: chunkText, embedding: embedding, sourceDocumentId: documentId, chunkIndex: index)
                }
            }

            for try await chunk in group {
                newDocumentChunks.append(chunk)
            }
        }

        // Synchronize access to `documentChunks`
        queue.sync {
            self.documentChunks.append(contentsOf: newDocumentChunks)
        }
        print("Document \(documentId) added with \(newDocumentChunks.count) chunks.")
        return documentId
    }

    /// Performs a semantic search against the knowledge base.
    /// - Parameters:
    ///   - query: The natural language query.
    ///   - topK: The number of top-matching document chunks to return.
    /// - Returns: An array of `DocumentChunk` instances, sorted by relevance.
    /// - Throws: An error if embedding the query fails.
    func performSemanticSearch(query: String, topK: Int = 5) async throws -> [DocumentChunk] {
        guard !documentChunks.isEmpty else {
            print("Knowledge base is empty. Add documents first.")
            return []
        }

        // 1. Embed the query
        let queryEmbedding = try await embeddingModel.embed(text: query)
        
        // Ensure queryEmbedding is evaluated
        MLX.eval(queryEmbedding)

        // 2. Calculate cosine similarity with all document chunks
        // Cosine similarity = (A . B) / (||A|| * ||B||)
        // Since our embeddings are already normalized to unit length, ||A|| = 1 and ||B|| = 1.
        // So, cosine similarity simplifies to the dot product (A . B).

        var similarities: [(DocumentChunk, Float)] = []

        // Process similarities on a background queue
        await withCheckedContinuation { continuation in
            queue.async {
                for chunk in self.documentChunks {
                    // Perform dot product using MLXArray operations.
                    // MLXArray operations are efficient and leverage Unified Memory.
                    let dotProduct = MLX.dot(queryEmbedding, chunk.embedding.transposed())
                    
                    // The result of MLX.dot is an MLXArray. We need to evaluate it to get the scalar.
                    MLX.eval(dotProduct)
                    
                    guard let similarity = dotProduct.item() as Float? else {
                        print("Warning: Could not get scalar item from dot product.")
                        continue
                    }
                    similarities.append((chunk, similarity))
                }
                continuation.resume(returning: ())
            }
        }

        // 3. Sort by similarity and return top K
        let sortedResults = similarities.sorted { $0.1 > $1.1 }
        return Array(sortedResults.prefix(topK)).map { $0.0 }
    }
}

// MARK: - 4. Text Chunking Helper (Simplified)

/// A helper class to split large texts into smaller, overlapping chunks.
/// This is crucial for embedding models which have input length limits.
class TextChunker {
    let maxChunkSize: Int
    let overlap: Int

    init(maxChunkSize: Int, overlap: Int) {
        self.maxChunkSize = maxChunkSize
        self.overlap = overlap
    }

    /// Splits a given text into chunks.
    /// - Parameter text: The input text.
    /// - Returns: An array of text chunks.
    func split(text: String) -> [String] {
        var chunks: [String] = []
        let words = text.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }
        var currentChunkWords: [String] = []
        var currentIndex = 0

        while currentIndex < words.count {
            currentChunkWords.removeAll()
            var currentWordCount = 0

            // Add words until maxChunkSize is reached or end of text
            while currentIndex < words.count && currentWordCount < maxChunkSize {
                currentChunkWords.append(words[currentIndex])
                currentWordCount += 1
                currentIndex += 1
            }
            chunks.append(currentChunkWords.joined(separator: " "))

            // Prepare for next chunk with overlap
            if currentIndex < words.count {
                currentIndex -= min(overlap, currentWordCount)
                if currentIndex < 0 { currentIndex = 0 } // Prevent negative index
            }
        }
        return chunks
    }
}

// MARK: - 5. Main Application Entry Point (Simulated)

/// Entry point for a simulated SwiftUI application or command-line tool.
@available(iOS 18.0, macOS 15.0, *)
@main
struct AdvancedMLXApp {
    static func main() async {
        print("--- Advanced MLX Local Memory Application ---")

        // Define model parameters.
        // In a real scenario, these would come from the loaded model's config.
        let inputFeatureDimension = 768 // e.g., output dimension of a transformer encoder
        let embeddingOutputDimension = 384 // Common embedding size (e.g., for Sentence-BERT)

        do {
            // 1. Initialize the MLX Embedding Model
            // This model will reside in local memory (Unified Memory on Apple Silicon).
            let embeddingModel = EmbeddingModel(
                inputDimension: inputFeatureDimension,
                embeddingDimension: embeddingOutputDimension
                // parametersPath: "path/to/your/mlx_model_weights.safetensors" // Uncomment to load real weights
            )
            print("Embedding model initialized. Leveraging Apple's Unified Memory for efficient tensor operations.")
            print("MLX uses lazy evaluation: computations are built into a graph and executed when results are needed.")

            // 2. Initialize the Knowledge Base Manager
            let kbManager = KnowledgeBaseManager(embeddingModel: embeddingModel)

            // 3. Add Sample Documents to the Knowledge Base
            print("\n--- Adding documents ---")
            let doc1 = """
            Apple's MLX framework is designed for efficient machine learning on Apple silicon.
            It provides a user-friendly Python API and a Swift API, allowing developers to build
            high-performance AI applications directly on macOS and iOS devices. MLX leverages
            Unified Memory, which eliminates the need for data copies between CPU and GPU,
            significantly improving performance and reducing memory overhead. This makes it
            ideal for local LLM inference and fine-tuning.
            """
            let doc2 = """
            Unified Memory is a key architectural feature of Apple Silicon. It means that
            the CPU and GPU share the same physical memory, leading to zero-copy data transfers.
            This is particularly beneficial for machine learning workloads where large tensors
            are frequently moved between processing units. MLX is built from the ground up to
            take advantage of this, offering a seamless and performant experience for developers.
            """
            let doc3 = """
            Swift 6 introduces powerful new concurrency features, including async/await,
            structured concurrency, and actors. These features make it easier to write
            safe, performant, and readable asynchronous code. When combined with MLX Swift,
            developers can create responsive AI applications that perform complex
            computations in the background without blocking the main thread.
            """
            let doc4 = """
            The latest iPhone models feature advanced neural engines, enabling on-device
            machine learning tasks with incredible speed and efficiency. These neural engines,
            combined with MLX and Swift, open up new possibilities for privacy-preserving
            AI applications that run entirely locally on the user's device.
            """

            _ = try await kbManager.addDocument(documentText: doc1)
            _ = try await kbManager.addDocument(documentText: doc2)
            _ = try await kbManager.addDocument(documentText: doc3)
            _ = try await kbManager.addDocument(documentText: doc4)

            // 4. Perform Semantic Search Queries
            print("\n--- Performing semantic searches ---")

            let query1 = "What is MLX and its benefits?"
            print("\nQuery: \"\(query1)\"")
            let results1 = try await kbManager.performSemanticSearch(query: query1, topK: 2)
            if results1.isEmpty {
                print("No results found for query 1.")
            } else {
                print("Top 2 results:")
                for (index, chunk) in results1.enumerated() {
                    print("  \(index + 1). (Source: \(chunk.sourceDocumentId.uuidString.prefix(8))... Chunk: \(chunk.chunkIndex)) \"\(chunk.text.prefix(100))...\"")
                }
            }

            let query2 = "How does Apple Silicon's memory architecture help ML?"
            print("\nQuery: \"\(query2)\"")
            let results2 = try await kbManager.performSemanticSearch(query: query2, topK: 2)
            if results2.isEmpty {
                print("No results found for query 2.")
            } else {
                print("Top 2 results:")
                for (index, chunk) in results2.enumerated() {
                    print("  \(index + 1). (Source: \(chunk.sourceDocumentId.uuidString.prefix(8))... Chunk: \(chunk.chunkIndex)) \"\(chunk.text.prefix(100))...\"")
                }
            }
            
            let query3 = "Swift concurrency features"
            print("\nQuery: \"\(query3)\"")
            let results3 = try await kbManager.performSemanticSearch(query: query3, topK: 1)
            if results3.isEmpty {
                print("No results found for query 3.")
            } else {
                print("Top 1 result:")
                for (index, chunk) in results3.enumerated() {
                    print("  \(index + 1). (Source: \(chunk.sourceDocumentId.uuidString.prefix(8))... Chunk: \(chunk.chunkIndex)) \"\(chunk.text.prefix(100))...\"")
                }
            }

        } catch {
            print("An error occurred: \(error)")
        }

        print("\n--- Application Finished ---")
    }
}
