
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

/// Represents the specific error types encountered during LLM orchestration.
/// This allows the UI to distinguish between network failures, API limits, and content filtering.
enum LLMError: LocalizedError {
    case invalidURL
    case authenticationFailed
    case rateLimitExceeded
    case contentFiltered
    case providerError(String)
    case decodingError(Error)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The provider URL was malformed."
        case .authenticationFailed: return "API Key is invalid or expired."
        case .rateLimitExceeded: return "Too many requests. Please wait."
        case .contentFiltered: return "The request was blocked by safety filters."
        case .providerError(let msg): return "Provider error: \(msg)"
        case .decodingError: return "Failed to parse the AI response."
        case .unknown(let error): return error.localizedDescription
        }
    }
}

/// Defines the capability of a specific AI provider.
/// By using an async throwing stream, we support real-time token streaming,
/// which is critical for perceived performance in chat interfaces.
protocol LLMProvider: Sendable {
    var name: String { get }
    var modelIdentifier: String { get }
    
    /// Generates a response from the model.
    /// - Parameters:
    ///   - prompt: The user's input text.
    ///   - systemContext: High-level instructions for the model.
    /// - Returns: An AsyncThrowingStream of strings representing the streaming tokens.
    func generateStreamingResponse(
        prompt: String,
        systemContext: String
    ) async throws -> AsyncThrowingStream<String, Error>
}

// MARK: - Anthropic Claude Implementation

/// Implementation for Anthropic's Claude API.
/// Handles the specific JSON schema required by Anthropic (messages array).
final class ClaudeProvider: LLMProvider, Sendable {
    let name = "Anthropic Claude"
    let modelIdentifier: String
    private let apiKey: String
    private let session: URLSession

    init(apiKey: String, model: String = "claude-3-5-sonnet-20240620", session: URLSession = .shared) {
        self.apiKey = apiKey
        self.modelIdentifier = model
        self.session = session
    }

    func generateStreamingResponse(
        prompt: String,
        systemContext: String
    ) async throws -> AsyncThrowingStream<String, Error> {
        let url = URL(string: "https://api.anthropic.com/v1/messages")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "anthropic-version", value: "2023-06-01")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "x-api-key")

        let payload: [String: Any] = [
            "model": modelIdentifier,
            "max_tokens": 1024,
            "system": systemContext,
            "messages": [
                ["role": "user", "content": prompt]
            ],
            "stream": true
        ]

        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        return AsyncThrowingStream { continuation in
            Task {
                do {
                    let (bytes, response) = try await session.bytes(for: request)
                    
                    guard let httpResponse = response as? HTTPURLResponse else {
                        throw LLMError.providerError("Invalid response type")
                    }

                    switch httpResponse.statusCode {
                    case 200: break
                    case 401: throw LLMError.authenticationFailed
                    case 429: throw LLMError.rateLimitExceeded
                    default: throw LLMError.providerError("HTTP \(httpResponse.statusCode)")
                    }

                    // Process the stream of bytes
                    for try await line in bytes.lines {
                        // Anthropic sends SSE (Server-Sent Events)
                        if line.hasPrefix("data: ") {
                            let dataString = line.replacingOccurrences(of: "data: ", with: "")
                            // In a production environment, we would parse the specific JSON 
                            // fragment to extract the 'delta' text.
                            // Simplified for demonstration:
                            continuation.yield(dataString) 
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }
}

// MARK: - Google Gemini Implementation

/// Implementation for Google Gemini API.
/// Handles the Google-specific 'contents' and 'parts' JSON structure.
final class GeminiProvider: LLMProvider, Sendable {
    let name = "Google Gemini"
    let modelIdentifier: String
    private let apiKey: String
    private let session: URLSession

    init(apiKey: String, model: String = "gemini-1.5-pro", session: URLSession = .shared) {
        self.apiKey = apiKey
        self.modelIdentifier = model
        self.session = session
    }

    func generateStreamingResponse(
        prompt: String,
        systemContext: String
    ) async throws -> AsyncThrowingStream<String, Error> {
        let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(modelIdentifier):streamGenerateContent?key=\(apiKey)")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "contents": [
                ["parts": [["text": prompt]]]
            ],
            "systemInstruction": [
                "parts": [["text": systemContext]]
            ]
        ]

        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        return AsyncThrowingStream { continuation in
            Task {
                do {
                    let (bytes, response) = try await session.bytes(for: request)
                    
                    guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                        throw LLMError.providerError("Gemini API unavailable")
                    }

                    for try await line in bytes.lines {
                        // Gemini's streaming format varies; we parse the text content
                        // This logic assumes the line contains the text chunk.
                        if !line.isEmpty {
                            continuation.yield(line)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }
}

// MARK: - The Orchestrator

/// The IntelligenceOrchestrator is an actor, ensuring that access to the 
/// current provider and session state is thread-safe in a highly concurrent environment.
@available(iOS 18.0, macOS 15.0, *)
actor IntelligenceOrchestrator {
    
    enum TaskComplexity {
        case rapidResponse // Use lighter models
        case deepReasoning // Use Claude
        case massiveContext // Use Gemini
    }

    private var providers: [String: LLMProvider] = [:]
    private var preferredProvider: String?

    /// Registers a provider into the orchestration engine.
    func register(provider: LLMProvider) {
        providers[provider.name] = provider
        if preferredProvider == nil {
            preferredProvider = provider.name
        }
    }

    /// The core logic for selecting the best model for the user's specific request.
    private func selectProvider(for complexity: TaskComplexity) -> LLMProvider? {
        switch complexity {
        case .deepReasoning:
            return providers.values.first { $0 is ClaudeProvider }
        case .massiveContext:
            return providers.values.first { $0 is GeminiProvider }
        case .rapidResponse:
            return preferredProvider != nil ? providers[preferredProvider!] : providers.values.first
        }
    }

    /// Executes a request by intelligently routing it to the correct provider.
    /// - Parameters:
    ///   - prompt: The user's query.
    ///   - complexity: The estimated complexity of the task.
    /// - Returns: A stream of tokens.
    func execute(
        prompt: String,
        systemContext: String,
        complexity: TaskComplexity
    ) async throws -> AsyncThrowingStream<String, Error> {
        guard let provider = selectProvider(for: complexity) else {
            throw LLMError.providerError("No suitable provider found for the requested complexity.")
        }
        
        print("🚀 Orchestrator routing task to: \(provider.name)")
        return try await provider.generateStreamingResponse(prompt: prompt, systemContext: systemContext)
    }
}

// MARK: - ViewModel for SwiftUI Integration

@Observable
@available(iOS 18.0, *)
final class ResearchViewModel {
    var chatHistory: [String] = []
    var currentResponse: String = ""
    var isProcessing: Bool = false
    var errorMessage: String?

    private let orchestrator = IntelligenceOrchestrator()

    init() {
        Task {
            // In a real app, these keys would be fetched from the Keychain.
            let claude = ClaudeProvider(apiKey: "sk-ant-...")
            let gemini = GeminiProvider(apiKey: "AIza...")
            
            await orchestrator.register(provider: claude)
            await orchestrator.register(provider: gemini)
        }
    }

    func sendQuery(_ text: String, complexity: IntelligenceOrchestrator.TaskComplexity) {
        isProcessing = true
        errorMessage = nil
        currentResponse = ""
        
        Task {
            do {
                let stream = try await orchestrator.execute(
                    prompt: text,
                    systemContext: "You are a professional research assistant.",
                    complexity: complexity
                )

                for try await token in stream {
                    // Update the UI on the MainActor
                    await MainActor.run {
                        self.currentResponse += token
                    }
                }
                
                await MainActor.run {
                    self.chatHistory.append("User: \(text)")
                    self.chatHistory.append("AI: \(self.currentResponse)")
                    self.isProcessing = false
                }
                
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isProcessing = false
                }
            }
        }
    }
}
