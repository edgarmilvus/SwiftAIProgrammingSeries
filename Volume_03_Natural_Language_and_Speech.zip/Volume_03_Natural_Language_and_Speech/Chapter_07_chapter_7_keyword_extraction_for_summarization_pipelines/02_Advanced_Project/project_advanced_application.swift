
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet (not strictly necessary for NaturalLanguage/Foundation,
// but demonstrates how dependencies would be declared if external ones were used)
//
// import PackageDescription
//
// let package = Package(
//     name: "DocDigestPro",
//     platforms: [
//         .iOS(.v15), // Minimum iOS version for async/await and TaskGroup
//         .macOS(.v12)
//     ],
//     products: [
//         .library(
//             name: "DocDigestProCore",
//             targets: ["DocDigestProCore"]),
//     ],
//     dependencies: [
//         // Example of an external dependency if we needed a more advanced NLP library
//         // .package(url: "https://github.com/some/advanced-nlp-lib.git", from: "1.0.0"),
//     ],
//     targets: [
//         .target(
//             name: "DocDigestProCore",
//             dependencies: []), // NaturalLanguage and Foundation are built-in
//     ]
// )

import Foundation
import NaturalLanguage

// Ensure the code uses modern concurrency features available from iOS 15.0
@available(iOS 15.0, macOS 12.0, *)
enum KeywordExtractionError: Error, LocalizedError {
    case emptyText
    case taggingFailed(String)
    case noKeywordsFound
    case invalidLanguageCode(String)

    var errorDescription: String? {
        switch self {
        case .emptyText:
            return "Input text cannot be empty for keyword extraction."
        case .taggingFailed(let message):
            return "Natural Language tagging failed: \(message)"
        case .noKeywordsFound:
            return "No significant keywords could be extracted from the text."
        case .invalidLanguageCode(let code):
            return "The provided language code '\(code)' is not supported or invalid."
        }
    }
}

/// A service for extracting keywords from text, supporting single or batch processing.
@available(iOS 15.0, macOS 12.0, *)
final class KeywordExtractorService {

    // A simple, hardcoded list of English stop words. In a production app, this would
    // be loaded from a resource file and potentially be language-specific.
    private let englishStopWords: Set<String> = [
        "a", "an", "the", "and", "or", "but", "is", "are", "was", "were", "
        "be", "been", "being", "have", "has", "had", "do", "does", "did",
        "of", "in", "on", "at", "by", "for", "with", "from", "to", "as",
        "it", "its", "he", "him", "his", "she", "her", "hers", "we", "us",
        "our", "ours", "you", "your", "yours", "they", "them", "their", "theirs",
        "this", "that", "these", "those", "i", "me", "my", "mine", "you",
        "your", "yours", "him", "his", "her", "hers", "its", "our", "ours",
        "their", "theirs", "what", "which", "who", "whom", "whose", "where",
        "when", "why", "how", "all", "any", "both", "each", "few", "more",
        "most", "other", "some", "such", "no", "nor", "not", "only", "own",
        "same", "so", "than", "too", "very", "can", "will", "just", "don't",
        "should", "would", "could", "get", "make", "made", "one", "two", "three",
        "new", "used", "also", "many", "much", "even", "back", "up", "down",
        "out", "about", "into", "through", "over", "under", "after", "before",
        "while", "until", "between", "among", "along", "around", "above", "below",
        "against", "without", "during", "then", "now", "well", "ever", "never",
        "always", "often", "seldom", "sometimes", "already", "yet", "still",
        "may", "might", "must", "shall", "can't", "won't", "wouldn't", "couldn't",
        "shouldn't", "isn't", "aren't", " " // Empty string can sometimes appear
    ]

    /// Extracts a list of significant keywords from a given text.
    ///
    /// - Parameters:
    ///   - text: The input string from which to extract keywords.
    ///   - language: The BCP-47 language code (e.g., "en" for English, "fr" for French).
    ///   - maxKeywords: The maximum number of keywords to return.
    /// - Returns: An array of strings representing the most relevant keywords.
    /// - Throws: `KeywordExtractionError` if the text is empty, tagging fails, or no keywords are found.
    func extractKeywords(from text: String, language: String, maxKeywords: Int = 10) async throws -> [String] {
        guard !text.isEmpty else {
            throw KeywordExtractionError.emptyText
        }

        // 1. Initialize NLTagger for tokenization and part-of-speech tagging.
        // We use .lemma for base forms and .tokenType for general word classification.
        let tagger = NLTagger(tagSchemes: [.lemma, .tokenType])
        tagger.string = text
        
        // Use the provided language for more accurate tagging.
        // NLLanguageRecognizer could be used here for auto-detection if 'language' is nil.
        guard NLLanguage(rawValue: language) != nil else {
            throw KeywordExtractionError.invalidLanguageCode(language)
        }
        tagger.setLanguage(NLLanguage(rawValue: language)!, range: text.startIndex..<text.endIndex)

        var keywordCounts: [String: Int] = [:]
        
        // 2. Enumerate tokens and apply filters.
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lemma, options: [.omitWhitespace, .omitOther, .joinNames]) { tag, tokenRange in
            guard let lemma = tag?.rawValue.lowercased(), !lemma.isEmpty else { return true }

            // 3. Filter out stop words.
            if englishStopWords.contains(lemma) { return true }

            // 4. Further filter by token type (e.g., nouns, proper nouns, verbs, adjectives).
            // This requires another tag scheme or a more complex enumeration.
            // For simplicity and to demonstrate core lemma extraction, we'll use a secondary check
            // or assume lemma is sufficient after stop word removal for this example.
            // A more robust solution would enumerate with both .lemma and .partOfSpeech.
            
            // Re-tag with .partOfSpeech for more robust filtering
            let subTagger = NLTagger(tagSchemes: [.partOfSpeech])
            subTagger.string = String(text[tokenRange])
            subTagger.enumerateTags(in: subTagger.string!.startIndex..<subTagger.string!.endIndex, unit: .word, scheme: .partOfSpeech, options: []) { posTag, _ in
                guard let pos = posTag else { return true }
                
                // 5. Prioritize specific parts of speech for keywords.
                switch pos {
                case .noun, .properNoun, .verb, .adjective:
                    keywordCounts[lemma, default: 0] += 1
                default:
                    break // Ignore other parts of speech for keywords
                }
                return true
            }
            return true // Continue enumeration
        }

        guard !keywordCounts.isEmpty else {
            throw KeywordExtractionError.noKeywordsFound
        }

        // 6. Sort keywords by frequency and return the top N.
        let sortedKeywords = keywordCounts.sorted { $0.value > $1.value }
                                            .prefix(maxKeywords)
                                            .map { $0.key }

        return Array(sortedKeywords)
    }

    /// Processes a batch of documents concurrently to extract keywords from each.
    ///
    /// - Parameters:
    ///   - documents: An array of strings, where each string represents a document's text.
    ///   - language: The BCP-47 language code for all documents.
    ///   - maxKeywords: The maximum number of keywords to extract per document.
    /// - Returns: An array of `Result` types, where each `Result` contains either
    ///            an array of keywords for a document or an `KeywordExtractionError`.
    /// - Throws: `KeywordExtractionError` if the language code is invalid or a critical error occurs
    ///           during the overall batch processing setup (individual document errors are captured in `Result`).
    func processDocuments(documents: [String], language: String, maxKeywords: Int = 10) async -> [Result<[String], Error>] {
        guard NLLanguage(rawValue: language) != nil else {
            return documents.map { _ in .failure(KeywordExtractionError.invalidLanguageCode(language)) }
        }

        var results: [Result<[String], Error>] = Array(repeating: .failure(KeywordExtractionError.emptyText), count: documents.count)

        // 7. Use a TaskGroup for concurrent processing of multiple documents.
        // This allows the keyword extraction for each document to run in parallel
        // on available system resources, without blocking the main thread.
        await withTaskGroup(of: (Int, Result<[String], Error>).self) { group in
            for (index, documentText) in documents.enumerated() {
                group.addTask {
                    do {
                        let keywords = try await self.extractKeywords(from: documentText, language: language, maxKeywords: maxKeywords)
                        return (index, .success(keywords))
                    } catch {
                        // 8. Handle individual document errors gracefully within the batch.
                        // The error is captured in the Result type for that specific document.
                        return (index, .failure(error))
                    }
                }
            }

            // 9. Collect results from the TaskGroup as they complete.
            for await (index, result) in group {
                results[index] = result
            }
        }
        return results
    }
}

// MARK: - Example Usage in a DocDigest Pro App ViewModel

/// A ViewModel for managing document processing and keyword display.
@available(iOS 15.0, macOS 12.0, *)
final class DocDigestProViewModel: ObservableObject {
    @Published var documentTexts: [String] = []
    @Published var processedKeywords: [Int: Result<[String], Error>] = [:]
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let keywordExtractor = KeywordExtractorService()

    /// Simulates adding new documents (e.g., from OCR scans).
    func addDocument(_ text: String) {
        documentTexts.append(text)
    }

    /// Processes all added documents to extract keywords.
    func processAllDocuments() {
        guard !documentTexts.isEmpty else {
            errorMessage = "No documents to process."
            return
        }

        isLoading = true
        errorMessage = nil

        Task { @MainActor in // Ensure UI updates happen on the main actor
            let results = await keywordExtractor.processDocuments(documents: documentTexts, language: "en", maxKeywords: 7)
            
            // Map results to the published dictionary, associating them with their original index.
            for (index, result) in results.enumerated() {
                processedKeywords[index] = result
            }
            
            isLoading = false
            
            // Check if any document failed and update error message if needed.
            if results.contains(where: { $0.isFailure }) {
                errorMessage = "Some documents failed to process. Check individual results for details."
            }
        }
    }
}

// MARK: - Helper for Result type to check for failure (Swift 6 pattern)
@available(iOS 15.0, macOS 12.0, *)
extension Result {
    var isFailure: Bool {
        if case .failure = self {
            return true
        }
        return false
    }
}

// MARK: - Application Entry Point (Simulated)
@available(iOS 15.0, macOS 12.0, *)
func runDocDigestProSimulation() async {
    let viewModel = DocDigestProViewModel()

    // Simulate adding documents
    viewModel.addDocument("""
        The recent advancements in large language models have revolutionized natural language processing.
        These models, often based on transformer architectures, exhibit remarkable capabilities in
        understanding and generating human-like text. Research continues to explore their
        applications in various fields, from customer service chatbots to scientific discovery.
        """)
    viewModel.addDocument("""
        Quantum computing is a rapidly emerging technology that harnesses the principles of quantum mechanics
        to solve problems too complex for classical computers. Superposition and entanglement are key concepts.
        Companies like IBM and Google are at the forefront of developing quantum processors and algorithms.
        """)
    viewModel.addDocument("""
        Swift 6 introduces several new features, including improved concurrency with async/await,
        and enhanced data race detection. These features aim to make parallel programming safer and more
        expressive, aligning with Apple's commitment to modern software development practices.
        """)
    viewModel.addDocument("") // Simulate an empty document to test error handling
    viewModel.addDocument("""
        Climate change presents a global challenge requiring urgent action. Rising global temperatures,
        extreme weather events, and sea-level rise are among the critical impacts. Mitigation strategies
        include transitioning to renewable energy sources and carbon capture technologies.
        """)

    print("--- Starting DocDigest Pro Keyword Extraction ---")
    await viewModel.processAllDocuments()

    // Wait for a short period to allow async tasks to complete in a real app context
    // In a test, you might use XCTestExpectation.
    try? await Task.sleep(for: .seconds(1))

    print("\n--- Processing Results ---")
    for (index, result) in viewModel.processedKeywords.sorted(by: { $0.key < $1.key }) {
        switch result {
        case .success(let keywords):
            print("Document \(index + 1) Keywords: \(keywords.joined(separator: ", "))")
        case .failure(let error):
            print("Document \(index + 1) Error: \(error.localizedDescription)")
        }
    }
    print("--- DocDigest Pro Simulation Complete ---")
    
    if let error = viewModel.errorMessage {
        print("\nOverall ViewModel Error: \(error)")
    }
}

// To run this simulation in a Swift Playground or a command-line tool:
// Call 'await runDocDigestProSimulation()' inside an async context.
// For example:
// Task {
//     await runDocDigestProSimulation()
// }
