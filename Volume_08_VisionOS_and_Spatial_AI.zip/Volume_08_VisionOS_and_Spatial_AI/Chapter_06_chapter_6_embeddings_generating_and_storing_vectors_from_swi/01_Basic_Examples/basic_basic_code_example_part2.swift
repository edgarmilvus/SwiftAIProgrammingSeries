
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import OSLog

// MARK: - Models

/// Represents a journal entry in the MindfulNotes app.
/// Conforms to `Sendable` to ensure safety when passing between concurrency domains.
struct JournalEntry: Codable, Sendable, Identifiable {
    let id: UUID
    let content: String
    /// The mathematical representation of the content.
    /// In a real app, this would be stored in a vector database or a specialized Core Data attribute.
    let embedding: [Float]
    let timestamp: Date
}

/// The structure of the OpenAI API response for embeddings.
struct OpenAIEmbeddingResponse: Codable {
    struct Data: Codable {
        let embedding: [Float]
    }
    let data: [Data]
    let model: String
    let usage: Usage

    struct Usage: Codable {
        let promptTokens: Int
    }
}

/// Errors specific to the Embedding workflow.
enum EmbeddingError: Error, LocalizedError {
    case invalidURL
    case requestFailed(Int)
    case decodingError
    case emptyResponse

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The API endpoint URL is invalid."
        case .requestFailed(let code): return "The API request failed with status code: \(code)."
        case .decodingError: return "Failed to decode the response from the AI provider."
        case .emptyResponse: return "The provider returned an empty embedding array."
        }
    }
}

// MARK: - Service Layer

/// An actor that manages the generation of embeddings.
/// Using an `actor` ensures that any internal state (like request counting or caching)
/// is protected from data races in a highly concurrent Swift 6 environment.
@available(iOS 18.0, macOS 15.0, *)
actor EmbeddingService {
    private let apiKey: String
    private let endpoint = "https://api.openai.com/v1/embeddings"
    private let logger = Logger(subsystem: "com.mindfulnotes.ai", category: "EmbeddingService")
    
    /// Initializes the service with a required API key.
    /// - Parameter apiKey: The OpenAI API key.
    init(apiKey: String) {
        self.apiKey = apiKey
    }

    /// Generates a vector embedding for a given string.
    /// - Parameter text: The raw text to be converted.
    /// - Returns: An array of Floats representing the semantic vector.
    /// - Throws: `EmbeddingError` if the network or decoding fails.
    func generateEmbedding(for text: String) async throws -> [Float] {
        guard let url = URL(string: endpoint) else {
            throw EmbeddingError.invalidURL
        }

        // Prepare the request body
        let payload: [String: Any] = [
            "input": text,
            "model": "text-embedding-3-small"
        ]
        
        let jsonData = try JSONSerialization.data(withJSONObject: payload)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData

        logger.info("Requesting embedding for text of length: \(text.count)")

        // Perform the network request using Swift 6 concurrency
        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw EmbeddingError.requestFailed(0)
        }

        guard httpResponse.statusCode == 200 else {
            logger.error("API Error: Status Code \(httpResponse.statusCode)")
            throw EmbeddingError.requestFailed(httpResponse.statusCode)
        }

        // Decode the response
        do {
            let decoder = JSONDecoder()
            let result = try decoder.decode(OpenAIEmbeddingResponse.self, from: data)
            
            guard let firstEmbedding = result.data.first?.embedding else {
                throw EmbeddingError.emptyResponse
            }
            
            logger.info("Successfully generated embedding of dimension: \(firstEmbedding.count)")
            return firstEmbedding
        } catch {
            logger.error("Decoding failed: \(error.localizedDescription)")
            throw EmbeddingError.decodingError
        }
    }
}

// MARK: - View Model / Business Logic

/// The ViewModel responsible for coordinating UI updates and business logic.
/// Marked with `@MainActor` to ensure all updates to the UI-facing properties
/// occur on the main thread, adhering to Swift 6 strict concurrency rules.
@available(iOS 18.0, macOS 15.0, *)
@MainActor
class JournalViewModel: ObservableObject {
    @Published var entries: [JournalEntry] = []
    @Published var isProcessing: Bool = false
    @Published var errorMessage: String?

    private let embeddingService: EmbeddingService

    init(embeddingService: EmbeddingService) {
        self.embeddingService = embeddingService
    }

    /// Adds a new note to the journal and automatically generates its embedding.
    /// - Parameter content: The text written by the user.
    func addNote(content: String) async {
        guard !content.isEmpty else { return }
        
        isProcessing = true
        errorMessage = nil

        do {
            // 1. Generate the embedding via the actor
            // Note: We are calling an actor from a @MainActor context.
            // This is safe; the task will suspend until the actor responds.
            let vector = try await embeddingService.generateEmbedding(for: content)

            // 2. Create the new entry
            let newEntry = JournalEntry(
                id: UUID(),
                content: content,
                embedding: vector,
                timestamp: Date()
            )

            // 3. Update the UI state
            self.entries.append(newEntry)
            isProcessing = false
            
        } catch {
            self.errorMessage = error.localizedDescription
            self.isProcessing = false
        }
    }
}
