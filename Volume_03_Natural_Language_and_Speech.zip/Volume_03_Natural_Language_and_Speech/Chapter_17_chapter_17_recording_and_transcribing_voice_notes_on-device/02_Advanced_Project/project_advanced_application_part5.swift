
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

/// A simple example demonstrating how to use the `VoiceJournalEntryProcessor`.
/// In a real app, `audioFileURL` would come from an `AVAudioRecorder` output
/// after a user records a voice note.
@available(iOS 17.0, macOS 14.0, *)
actor VoiceJournalAppCoordinator {
    private let processor: VoiceJournalEntryProcessor
    private var mockAudioFileURL: URL?

    init() {
        self.processor = VoiceJournalEntryProcessor()
    }

    /// Mocks the creation of an audio file for demonstration purposes.
    /// In a real app, this would be the output of an `AVAudioRecorder`
    /// saving to the app's documents directory or a temporary location.
    /// For this example, it attempts to load a file from the app bundle.
    private func createMockAudioFile() async throws -> URL {
        // For actual transcription, this file needs to contain valid audio data.
        // You MUST add a file named "sample_voice_note.m4a" to your Xcode project's main bundle.
        guard let url = Bundle.main.url(forResource: "sample_voice_note", withExtension: "m4a") else {
            print("ERROR: 'sample_voice_note.m4a' not found in bundle.")
            print("Please add an audio file (e.g., recorded via Voice Memos) named 'sample_voice_note.m4a' to your Xcode project's main bundle.")
            throw VoiceJournalError.audioFileLoadFailed(URL(string: "mock://sample_voice_note.m4a")!)
        }
        self.mockAudioFileURL = url
        return url
    }

    /// Runs the full processing flow: permissions, mock audio creation, transcription, and analysis.
    /// This method demonstrates the typical sequence of operations in a real application.
    func runProcessingExample() async {
        print("--- Starting Voice Journal Entry Processing Example ---")
        do {
            // 1. Request permissions: Crucial first step for any Speech or Microphone usage.
            print("Requesting permissions...")
            try await processor.requestPermissions()
            print("Permissions granted.")

            // 2. Get (or mock) an audio file: Simulate having a recorded voice note.
            print("Creating mock audio file...")
            let audioFile = try await createMockAudioFile()
            print("Mock audio file URL: \(audioFile.lastPathComponent)")

            // 3. Transcribe and analyze: The core advanced application logic.
            print("Transcribing and analyzing audio...")
            let result = try await processor.transcribeAndAnalyze(audioFileURL: audioFile)

            // 4. Display results: Present the extracted insights to the user.
            print("\n--- Analysis Result ---")
            print("Audio File: \(result.audioFileURL.lastPathComponent)")
            print("Transcription: \"\(result.transcription)\"")
            print("Sentiment: \(result.sentimentDescription)")
            print("Raw Sentiment Score: \(result.sentimentScore != nil ? String(format: "%.2f", result.sentimentScore!) : "N/A")")

        } catch let error as VoiceJournalError {
            print("\n--- Processing Failed ---")
            print("Error: \(error.localizedDescription)")
            if case .audioFileLoadFailed = error {
                print("ACTION REQUIRED: Please ensure 'sample_voice_note.m4a' is added to your project's main bundle.")
            }
        } catch {
            print("\n--- An unexpected error occurred ---")
            print("Error: \(error.localizedDescription)")
        }
        print("\n--- Voice Journal Entry Processing Example Finished ---")
    }
}
