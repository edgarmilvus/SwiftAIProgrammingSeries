/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// DeepLinkButton.tsx
import React, { useState } from 'react';
import { Button, Alert, ActivityIndicator, View, Text } from 'react-native';
import * as Linking from 'expo-linking';
import * as Sharing from 'expo-sharing';

type DeepLinkButtonProps = {
  screenName: string;
  params: Record<string, string>;
  buttonText?: string;
  isLoading?: boolean; // To control disabled state
};

const DeepLinkButton: React.FC<DeepLinkButtonProps> = ({ 
  screenName, 
  params, 
  buttonText = 'Share Link', 
  isLoading = false 
}) => {
  const [error, setError] = useState<string | null>(null);

  const handlePress = async () => {
    try {
      setError(null);
      
      // 1. Dynamic URL Construction
      // Constructing query string from params object
      const queryString = Object.entries(params)
        .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
        .join('&');
      
      const url = `${Linking.createURL(`/${screenName}`)}${queryString ? `?${queryString}` : ''}`;

      // 2. Sharing Functionality
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert('Sharing not available on this device');
        return;
      }

      await Sharing.shareAsync(url);
    } catch (err) {
      // 3. Error Boundary (Local)
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(`Unable to generate link: ${errorMessage}`);
      Alert.alert('Error', `Unable to generate link: ${errorMessage}`);
    }
  };

  if (error) {
    return (
      <View style={{ padding: 10, backgroundColor: '#ffebee' }}>
        <Text style={{ color: 'red' }}>{error}</Text>
      </View>
    );
  }

  return (
    <Button 
      title={buttonText} 
      onPress={handlePress} 
      disabled={isLoading} 
    />
  );
};

export default DeepLinkButton;

/*
 * USAGE EXAMPLE: ArticleDetail.tsx
 * 
 * import DeepLinkButton from './DeepLinkButton';
 * 
 * const ArticleDetail = ({ route }) => {
 *   const [article, setArticle] = useState(null);
 *   const [loading, setLoading] = useState(true);
 * 
 *   useEffect(() => {
 *     // Fetch data
 *     setLoading(false);
 *   }, []);
 * 
 *   return (
 *     <View>
 *       <Text>{article?.title}</Text>
 *       
 *       // Conditional rendering based on loading state
 *       {loading ? (
 *         <ActivityIndicator size="small" color="#0000ff" />
 *       ) : (
 *         <DeepLinkButton 
 *           screenName="article" 
 *           params={{ id: route.params.articleId }} 
 *           buttonText="Share this Article"
 *         />
 *       )}
 *     </View>
 *   );
 * };
 */
