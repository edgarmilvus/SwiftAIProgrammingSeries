
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Vision
import UIKit // For UIImage and UI-related classes
import CoreGraphics // For CGImage and CGRect

// Ensure compatibility with modern Swift and SDK features.
// Basic Vision face detection is available from iOS 11.0, but we use a recent version
// for modern context and async/await.
@available(iOS 17.0, *)
/// A utility class designed to analyze images for human faces using Apple's Vision framework.
/// This class can be integrated into photo management tools, privacy-focused apps,
/// or augmented reality applications to identify and process faces.
class PhotoAnalyzer {

    /// Detects human faces within a given `UIImage` and returns their bounding boxes.
    ///
    /// The detection process involves converting the `UIImage` to a `CGImage`,
    /// creating a `VNDetectFaceRectanglesRequest`, and then processing the results
    /// to convert Vision's normalized coordinates into UIKit's pixel-based coordinates.
    ///
    /// - Parameter image: The `UIImage` object to be analyzed for faces.
    /// - Returns: An array of `CGRect` objects, where each rectangle represents the
    ///            bounding box of a detected face within the image's coordinate system.
    ///            Returns an empty array if no faces are found or if an error occurs.
    /// - Throws: An `Error` if the image cannot be processed by the Vision framework
    ///           (e.g., `CGImage` conversion fails, or Vision encounters an internal error).
    func detectFaces(in image: UIImage) async throws -> [CGRect] {
        // 1. Ensure the UIImage has an underlying CGImage.
        // Vision operates directly on Core Graphics images, so this conversion is essential.
        guard let cgImage = image.cgImage else {
            print("Error: Could not retrieve CGImage from UIImage.")
            // Throwing an error here is more robust than returning an empty array silently.
            throw PhotoAnalyzerError.invalidImage
        }

        // Use a Swift Concurrency Task to manage the asynchronous Vision request.
        // `withCheckedThrowingContinuation` allows bridging a callback-based API
        // (Vision's completion handler) to Swift's async/await model.
        return try await withCheckedThrowingContinuation { continuation in
            // 2. Create a Vision request to detect face rectangles.
            // The completion handler is called once Vision has finished processing the image.
            let request = VNDetectFaceRectanglesRequest { request, error in
                // Handle any errors that occurred during the Vision request.
                if let error = error {
                    print("Face detection request failed: \(error.localizedDescription)")
                    continuation.resume(throwing: error)
                    return
                }

                // 3. Process the results.
                // The `request.results` property contains an array of `VNObservation` objects.
                // For a `VNDetectFaceRectanglesRequest`, these are specifically `VNFaceObservation`s.
                guard let observations = request.results as? [VNFaceObservation] else {
                    print("No VNFaceObservation results found or results are of an unexpected type.")
                    continuation.resume(returning: []) // No faces detected, or unexpected results.
                    return
                }

                var detectedFaceRects: [CGRect] = []
                for observation in observations {
                    // Vision's bounding box coordinates are normalized (0.0 to 1.0)
                    // and originate from the bottom-left corner of the image.
                    // UIKit's coordinates are pixel-based and originate from the top-left.
                    // We need to convert Vision's coordinates to UIKit's for display.

                    // 4. Convert normalized Vision bounding box to image-specific UIKit coordinates.
                    let normalizedBoundingBox = observation.boundingBox
                    let imageSize = image.size

                    // `VNImageRectForNormalizedRect` is a helper function that performs
                    // this coordinate system transformation, taking into account the
                    // image's actual pixel dimensions.
                    let uiKitRect = VNImageRectForNormalizedRect(normalizedBoundingBox,
                                                                 Int(imageSize.width),
                                                                 Int(imageSize.height))
                    detectedFaceRects.append(uiKitRect)
                }
                continuation.resume(returning: detectedFaceRects)
            }

            // Optional: Set a minimum face size to filter out very small detections,
            // which can reduce false positives or improve performance.
            // request.minimumFaceSize = 0.1 // e.g., faces must be at least 10% of image height/width

            // 5. Create a Vision image request handler.
            // This handler is responsible for executing one or more Vision requests on a given image.
            // We pass the CGImage and any relevant options (like image orientation, though not strictly
            // necessary for this basic example if the image is always upright).
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

            // 6. Perform the Vision request(s).
            // This call initiates the Vision processing. It can throw an error if the handler
            // cannot perform the request (e.g., due to invalid input or system issues).
            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
                continuation.resume(throwing: error)
            }
        }
    }
}

// Custom error type for better error handling in our PhotoAnalyzer.
@available(iOS 17.0, *)
enum PhotoAnalyzerError: Error, LocalizedError {
    case invalidImage
    case visionProcessingFailed(Error)

    var errorDescription: String? {
        switch self {
        case .invalidImage:
            return "The provided image could not be processed (e.g., no CGImage data)."
        case .visionProcessingFailed(let error):
            return "Vision framework failed to process the image: \(error.localizedDescription)"
        }
    }
}

// MARK: - Example Usage in an iOS App Context

// This `UIViewController` demonstrates how `PhotoAnalyzer` would be used in a typical
// iOS application. It loads a sample image, triggers face detection, and then
// draws bounding boxes around the detected faces.
@available(iOS 17.0, *)
class ViewController: UIViewController {

    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit // Ensures the entire image is visible
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.backgroundColor = .systemGray6
        iv.layer.borderColor = UIColor.systemGray3.cgColor
        iv.layer.borderWidth = 1.0
        iv.clipsToBounds = true // Important for drawing
        return iv
    }()

    private let analyzeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Detect Faces", for: .normal)
        button.titleLabel?.font = .preferredFont(forTextStyle: .headline)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Tap 'Detect Faces' to analyze the image."
        label.textAlignment = .center
        label.numberOfLines = 0
        label.font = .preferredFont(forTextStyle: .subheadline)
        label.textColor = .secondaryLabel
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let photoAnalyzer = PhotoAnalyzer()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Face Detection Demo"
        setupUI()
        loadSampleImage() // Load a default image for immediate demonstration
    }

    /// Sets up the user interface elements and their constraints.
    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(imageView)
        view.addSubview(analyzeButton)
        view.addSubview(statusLabel)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5), // Occupy half of the screen height

            analyzeButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 30),
            analyzeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            analyzeButton.widthAnchor.constraint(equalToConstant: 200),
            analyzeButton.heightAnchor.constraint(equalToConstant: 50),

            statusLabel.topAnchor.constraint(equalTo: analyzeButton.bottomAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        analyzeButton.addTarget(self, action: #selector(detectFacesButtonTapped), for: .touchUpInside)
    }

    /// Loads a sample image for demonstration purposes. In a real app, this would
    /// typically come from `UIImagePickerController` or a network request.
    private func loadSampleImage() {
        // Create a simple UIImage with a "face" for demonstration.
        // For actual face detection, you'd use a photo with real human faces.
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 600, height: 450))
        let sampleImage = renderer.image { context in
            // Background
            UIColor.systemMint.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 600, height: 450))

            // Large yellow "face"
            UIColor.systemYellow.setFill()
            context.cgContext.addEllipse(in: CGRect(x: 180, y: 80, width: 240, height: 240))
            context.cgContext.fillPath()

            // Eyes
            UIColor.black.setFill()
            context.cgContext.addEllipse(in: CGRect(x: 230, y: 140, width: 30, height: 30))
            context.cgContext.fillPath()
            context.cgContext.addEllipse(in: CGRect(x: 340, y: 140, width: 30, height: 30))
            context.cgContext.fillPath()

            // Mouth
            UIColor.red.setStroke()
            context.cgContext.setLineWidth(6)
            context.cgContext.addArc(center: CGPoint(x: 300, y: 240), radius: 50, startAngle: 0, endAngle: .pi, clockwise: false)
            context.cgContext.strokePath()

            // A second, smaller "face"
            UIColor.systemOrange.setFill()
            context.cgContext.addEllipse(in: CGRect(x: 400, y: 300, width: 100, height: 100))
            context.cgContext.fillPath()
            UIColor.black.setFill()
            context.cgContext.addEllipse(in: CGRect(x: 420, y: 320, width: 10, height: 10))
            context.cgContext.fillPath()
            context.cgContext.addEllipse(in: CGRect(x: 460, y: 320, width: 10, height: 10))
            context.cgContext.fillPath()
        }
        imageView.image = sampleImage
        statusLabel.text = "Sample image loaded. Tap 'Detect Faces'."
    }

    /// Action method for the "Detect Faces" button.
    @objc private func detectFacesButtonTapped() {
        guard let imageToAnalyze = imageView.image else {
            statusLabel.text = "Error: No image available for analysis."
            return
        }

        statusLabel.text = "Analyzing image for faces..."
        analyzeButton.isEnabled = false // Disable button during analysis

        // Use a Task to run the async `detectFaces` method.
        // `@MainActor` ensures that subsequent UI updates within this task
        // automatically occur on the main thread.
        Task { @MainActor in
            do {
                // Perform face detection asynchronously.
                let faceRects = try await photoAnalyzer.detectFaces(in: imageToAnalyze)

                // Update the UI with the detected faces.
                self.drawBoundingBoxes(on: imageToAnalyze, faceRects: faceRects)

                if faceRects.isEmpty {
                    self.statusLabel.text = "No faces detected in the image."
                } else {
                    self.statusLabel.text = "Detected \(faceRects.count) face(s)."
                }
            } catch {
                // Handle any errors that occurred during detection.
                self.statusLabel.text = "Face detection failed: \(error.localizedDescription)"
                print("Face detection failed with error: \(error)")
            }
            self.analyzeButton.isEnabled = true // Re-enable button
        }
    }

    /// Draws red bounding boxes on the original image for each detected face.
    /// This creates a new `UIImage` with the drawings and updates the `imageView`.
    ///
    /// - Parameters:
    ///   - originalImage: The `UIImage` on which to draw.
    ///   - faceRects: An array of `CGRect`s representing the face locations in pixel coordinates.
    private func drawBoundingBoxes(on originalImage: UIImage, faceRects: [CGRect]) {
        // If no faces are detected, just show the original image without any drawings.
        guard !faceRects.isEmpty else {
            imageView.image = originalImage
            return
        }

        let imageSize = originalImage.size
        // Begin an image context to draw on the image.
        // `false` for opaque (we want transparency), `0.0` for scale (use device scale).
        UIGraphicsBeginImageContextWithOptions(imageSize, false, 0.0)
        originalImage.draw(at: .zero) // Draw the original image first

        guard let context = UIGraphicsGetCurrentContext() else { return }

        // Set drawing properties for the bounding boxes.
        context.setStrokeColor(UIColor.red.cgColor) // Red color for boxes
        context.setLineWidth(4.0) // Thicker lines

        // Draw each face rectangle.
        for faceRect in faceRects {
            context.stroke(faceRect)
        }

        // Get the new image with the drawings.
        let drawnImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext() // End the image context

        // Update the UIImageView with the new image.
        imageView.image = drawnImage
    }
}
