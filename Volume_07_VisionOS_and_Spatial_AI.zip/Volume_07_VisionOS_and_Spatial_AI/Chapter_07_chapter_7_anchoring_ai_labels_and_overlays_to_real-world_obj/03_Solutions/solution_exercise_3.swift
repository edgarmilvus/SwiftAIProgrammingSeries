
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import RealityKit
import ARKit
import Metal

class MaterialOverlaySystem {
    var arView: ARView
    private var overlayEntity: ModelEntity?

    init(arView: ARView) {
        self.arView = arView
        // Enable scene reconstruction for mesh access
        let config = ARWorldTrackingConfiguration()
        config.sceneReconstruction = .meshWithClassification
        arView.session.run(config)
    }

    /// Applies a marble texture to a detected surface
    func applyMarbleOverlay(to meshAnchor: ARMeshAnchor) {
        // 1. Create the Material
        var marbleMaterial = PhysicallyBasedMaterial()
        if let texture = try? TextureResource.load(named: "marble_diffuse") {
            marbleMaterial.baseColor = .init(tint: .white, texture: .init(texture))
        }
        marbleMaterial.roughness = 0.1 // Make it shiny
        marbleMaterial.metallic = 0.2

        // 2. The "Proxy" Approach: Generate a mesh that matches the anchor's geometry
        // In a production environment, we would use a custom Metal shader 
        // to clip a larger mesh using the segmentation mask.
        let meshGeometry = meshAnchor.geometry
        let vertices = meshGeometry.vertices
        
        // Creating a ModelEntity from ARMeshAnchor geometry
        // Note: This is a simplified conceptual implementation of mesh conversion
        let meshResource = try! MeshResource.generate(from: meshGeometry) 
        let shell = ModelEntity(mesh: meshResource, materials: [marbleMaterial])
        
        // 3. Position the shell at the anchor's transform
        let anchorEntity = AnchorEntity(anchor: meshAnchor)
        anchorEntity.addChild(shell)
        
        arView.scene.addAnchor(anchorEntity)
        self.overlayEntity = shell
    }
}

// Note: In a real implementation, MeshResource.generate(from:) 
// would require a custom Metal-based vertex buffer conversion.
