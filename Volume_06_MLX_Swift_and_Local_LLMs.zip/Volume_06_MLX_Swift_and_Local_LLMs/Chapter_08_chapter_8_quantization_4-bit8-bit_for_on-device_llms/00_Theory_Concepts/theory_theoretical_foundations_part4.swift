
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, macOS 15.0, *)
    func processQuantizedInput(_ inputTensor: MLXArray) async -> MLXArray {
        // inputTensor is Sendable and can be safely passed here
        // Perform some MLX operations, which will leverage lazy evaluation
        let result = MLX.relu(inputTensor + 1)
        return result
    }

    @available(iOS 18.0, macOS 15.0, *)
    func startProcessing() {
        // Assume this tensor is loaded from a quantized model or is a quantized activation
        let quantizedInput = MLXArray.randomUniform([1, 128], type: .int8) // Example Int8 tensor

        Task {
            let processedOutput = await processQuantizedInput(quantizedInput)
            print("Processed quantized output type: \(processedOutput.dtype)")
            // MLX might automatically promote to float for some operations,
            // or keep it in lower precision if possible depending on the graph.
        }
    }
    