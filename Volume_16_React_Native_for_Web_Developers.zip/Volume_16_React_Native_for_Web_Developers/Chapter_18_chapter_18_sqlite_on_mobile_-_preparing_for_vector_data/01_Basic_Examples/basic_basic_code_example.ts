/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/lib/db/vectorService.ts

import * as SQLite from 'expo-sqlite/next';

/**
 * Represents a single item in our vector store with its metadata.
 * @typedef {Object} VectorItem
 * @property {number} id - Unique identifier for the item.
 * @property {string} text - The original text content.
 * @property {number[]} embedding - The vector embedding array (e.g., 1536 dimensions for OpenAI text-embedding-ada-002).
 */
type VectorItem = {
  id: number;
  text: string;
  embedding: number[];
};

/**
 * Opens a connection to the local SQLite database.
 * In a real Expo app, this would be 'my-vector-db.db'.
 * For this example, we use an in-memory database for simplicity.
 * @returns {Promise<SQLite.SQLiteDatabase>} A promise that resolves to the database connection.
 */
async function getDb(): Promise<SQLite.SQLiteDatabase> {
  // In a real app: return SQLite.openDatabase('my-vector-db.db');
  // For this self-contained example, we open an in-memory database.
  return SQLite.openDatabaseAsync(':memory:');
}

/**
 * Initializes the database schema for vector storage.
 * This creates a table with a column of type `vector` to store embeddings.
 * @param {SQLite.SQLiteDatabase} db - The database connection.
 */
async function initializeVectorTable(db: SQLite.SQLiteDatabase): Promise<void> {
  // The `vector` column type is provided by the `expo-sqlite` vector extension.
  // It's crucial to use this specific type for vector operations.
  const createTableSql = `
    CREATE TABLE IF NOT EXISTS vector_store (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL,
      embedding VECTOR(1536) NOT NULL -- Assuming 1536 dimensions for the embedding
    );
  `;
  await db.execAsync(createTableSql);
  console.log('Vector table initialized successfully.');
}

/**
 * Inserts a single vector item into the database.
 * @param {SQLite.SQLiteDatabase} db - The database connection.
 * @param {VectorItem} item - The item to insert.
 */
async function insertVectorItem(db: SQLite.SQLiteDatabase, item: VectorItem): Promise<void> {
  // We use parameterized queries to prevent SQL injection.
  // The embedding array is automatically serialized by the driver.
  const insertSql = `
    INSERT INTO vector_store (text, embedding)
    VALUES (?, ?);
  `;
  await db.runAsync(insertSql, item.text, item.embedding);
  console.log(`Inserted item with text: "${item.text.substring(0, 20)}..."`);
}

/**
 * Performs a similarity search using Cosine Similarity.
 * The `<->` operator is provided by the `expo-sqlite` vector extension for cosine distance.
 * A lower distance means higher similarity.
 * @param {SQLite.SQLiteDatabase} db - The database connection.
 * @param {number[]} queryEmbedding - The embedding vector for the search query.
 * @returns {Promise<VectorItem[]>} A promise that resolves to an array of the most similar items.
 */
async function searchSimilarVectors(
  db: SQLite.SQLiteDatabase,
  queryEmbedding: number[]
): Promise<VectorItem[]> {
  // The `<->` operator calculates the cosine distance between two vectors.
  // We order by this distance (ascending) to get the most similar results first.
  const searchSql = `
    SELECT id, text, embedding, embedding <-> ? AS distance
    FROM vector_store
    ORDER BY distance ASC
    LIMIT 3;
  `;

  // The `queryEmbedding` is passed as a parameter. The driver handles its serialization.
  const rows = await db.getAllAsync<VectorItem & { distance: number }>(searchSql, queryEmbedding);
  
  // Map the result to our expected type, excluding the distance if not needed.
  return rows.map(({ id, text, embedding }) => ({ id, text, embedding }));
}

/**
 * Main function to demonstrate the vector storage and retrieval workflow.
 * This simulates the entire process from DB setup to a final similarity search.
 */
export async function runVectorDemo(): Promise<void> {
  console.log('--- Starting Vector Database Demo ---');
  
  try {
    // 1. Get Database Connection
    const db = await getDb();

    // 2. Initialize Schema
    await initializeVectorTable(db);

    // 3. Define Sample Data (Simulating Embeddings)
    // In a real app, these would be actual vectors from an AI model.
    const item1: VectorItem = {
      id: 1,
      text: 'React Native for Web allows you to build native apps using React.',
      embedding: [0.1, 0.2, 0.3, 0.4, 0.5], // Simplified 5-dim vector for example
    };

    const item2: VectorItem = {
      id: 2,
      text: 'Expo simplifies the development of cross-platform mobile applications.',
      embedding: [0.5, 0.4, 0.3, 0.2, 0.1], // Inverted vector for demonstration
    };

    const item3: VectorItem = {
      id: 3,
      text: 'SQLite is a lightweight, self-contained SQL database engine.',
      embedding: [0.9, 0.8, 0.7, 0.6, 0.5], // Distinct vector
    };

    // 4. Insert Data into the Database
    await insertVectorItem(db, item1);
    await insertVectorItem(db, item2);
    await insertVectorItem(db, item3);

    // 5. Perform a Search
    // Let's search for a query that is conceptually similar to item1.
    // A query embedding for "React Native development".
    const queryEmbedding = [0.15, 0.25, 0.35, 0.45, 0.55];

    console.log('\nSearching for vectors similar to the query...');
    const results = await searchSimilarVectors(db, queryEmbedding);

    console.log('\n--- Search Results ---');
    results.forEach((result, index) => {
      console.log(`${index + 1}. Text: "${result.text}"`);
      // In a real app, you might log the distance score for debugging.
    });

  } catch (error) {
    console.error('An error occurred during the vector demo:', error);
  } finally {
    console.log('\n--- Vector Database Demo Finished ---');
  }
}

// To run this in a Node.js environment for testing (commented out):
// runVectorDemo();
