
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
struct GlossaryTerm {
    let term: String
    let embedding: NLEmbedding.Vector
}

@available(iOS 18.0, macOS 15.0, *)
class GlossarySearchEngine {
    private var glossaryTerms: [GlossaryTerm] = []

    init() {
        // Initialize with your predefined glossary terms
        let predefinedTerms = ["protocol", "struct", "class", "extension", "generic", "closure", "actor", "concurrency", "async/await", "value type", "reference type", "protocol oriented programming", "object oriented programming", "inheritance", "polymorphism", "abstraction"]
        
        for term in predefinedTerms {
            if let embedding = NLEmbedding.embedding(for: term, language: .english) {
                glossaryTerms.append(GlossaryTerm(term: term, embedding: embedding))
            } else {
                print("Could not generate embedding for term: \(term)")
            }
        }
    }

    /// Searches for semantically similar glossary terms.
    /// - Parameters:
    ///   - query: The user's search query.
    ///   - maxResults: The maximum number of results to return.
    /// - Returns: An array of tuples containing the similar term and its distance from the query.
    func search(query: String, maxResults: Int = 5) async -> [(term: String, distance: Double)] {
        guard let queryEmbedding = NLEmbedding.embedding(for: query, language: .english) else {
            print("Could not generate embedding for query: \(query)")
            return []
        }

        var results: [(term: String, distance: Double)] = []
        for termEntry in glossaryTerms {
            let distance = NLEmbedding.distance(between: queryEmbedding, and: termEntry.embedding)
            results.append((term: termEntry.term, distance: distance))
        }

        // Sort by distance (smaller distance means more similar) and take top results
        return results.sorted { $0.distance < $1.distance }.prefix(maxResults).map { $0 }
    }
}

// Example Usage (in an async context, e.g., a Task)
/*
@available(iOS 18.0, macOS 15.0, *)
func demonstrateGlossarySearch() async {
    let engine = GlossarySearchEngine()
    
    print("--- Glossary Search Demo ---")
    
    let query1 = "abstraction"
    let results1 = await engine.search(query: query1, maxResults: 3)
    print("\nSemantic search results for '\(query1)':")
    for result in results1 {
        print("- \(result.term) (Distance: \(String(format: "%.4f", result.distance)))")
    }
    // Expected output might include "protocol", "class"
    
    let query2 = "asynchronous code"
    let results2 = await engine.search(query: query2, maxResults: 3)
    print("\nSemantic search results for '\(query2)':")
    for result in results2 {
        print("- \(result.term) (Distance: \(String(format: "%.4f", result.distance)))")
    }
    // Expected output might include "async/await", "concurrency", "actor"
    
    let query3 = "data structure"
    let results3 = await engine.search(query: query3, maxResults: 3)
    print("\nSemantic search results for '\(query3)':")
    for result in results3 {
        print("- \(result.term) (Distance: \(String(format: "%.4f", result.distance)))")
    }
    // Expected output might include "struct", "class"
}

// To run this example, embed it in a Task:
// Task { await demonstrateGlossarySearch() }
*/
