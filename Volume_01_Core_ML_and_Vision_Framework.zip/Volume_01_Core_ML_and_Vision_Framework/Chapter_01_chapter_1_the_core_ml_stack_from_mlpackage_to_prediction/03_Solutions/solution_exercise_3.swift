
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

#if os(macOS) // This exercise is specific to macOS
import AppKit
import CoreML
import Vision // For image processing utilities

// MARK: - Helper: NSImage to CVPixelBuffer Conversion
// Similar to UIImage conversion, but for macOS NSImage.
extension NSImage {
    /// Converts an NSImage to a CVPixelBuffer, resizing it to the specified dimensions.
    /// - Parameters:
    ///   - width: The target width for the CVPixelBuffer.
    ///   - height: The target height for the CVPixelBuffer.
    ///   - pixelFormatType: The desired pixel format (e.g., kCVPixelFormatType_32BGRA for 8-bit BGRA).
    /// - Returns: An optional CVPixelBuffer.
    func toCVPixelBuffer(width: Int, height: Int, pixelFormatType: OSType) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormatType,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let finalPixelBuffer = pixelBuffer else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(finalPixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(finalPixelBuffer, .readOnly) }

        let pixelData = CVPixelBufferGetBaseAddress(finalPixelBuffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()

        guard let context = CGContext(data: pixelData,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(finalPixelBuffer),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            print("Failed to create CGContext for CVPixelBuffer.")
            return nil
        }

        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        if let cgImage = self.cgImage(forProposedRect: nil, context: nil, hints: nil) {
            context.draw(cgImage, in: rect)
        } else {
            print("Failed to get CGImage from NSImage.")
            return nil
        }
        
        return finalPixelBuffer
    }
}


// MARK: - MyRecipeRecommender (Assumed auto-generated Core ML model interface)
// For demonstration, let's define a simplified mock interface.
// In a real project, Xcode generates this from your .mlpackage.
struct MyRecipeRecommenderInput: MLFeatureProvider {
    var ingredientImage: CVPixelBuffer
    var preferencesText: String

    var featureNames: Set<String> { return ["ingredientImage", "preferencesText"] }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        switch featureName {
        case "ingredientImage": return MLFeatureValue(pixelBuffer: ingredientImage)
        case "preferencesText": return MLFeatureValue(string: preferencesText)
        default: return nil
        }
    }
}

struct MyRecipeRecommenderOutput: MLFeatureProvider {
    // Model output might be an MLMultiArray representing recipe IDs and scores
    var recommendedRecipes: MLMultiArray // e.g., (num_recommendations, 2) where [recipe_id, confidence]

    var featureNames: Set<String> { return ["recommendedRecipes"] }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "recommendedRecipes" {
            return MLFeatureValue(multiArray: recommendedRecipes)
        }
        return nil
    }
}

// Mock MLModel class for demonstration.
class MyRecipeRecommender {
    let model: MLModel
    let modelInputWidth = 299
    let modelInputHeight = 299

    init() throws {
        // In a real app, you would load your model:
        // let config = MLModelConfiguration()
        // self.model = try MyRecipeRecommender(configuration: config).model // assuming MyRecipeRecommender is the generated class

        // For this exercise, we'll create a dummy MLModel that always returns the same prediction
        let url = Bundle.main.url(forResource: "MyRecipeRecommender", withExtension: "mlmodelc")!
        self.model = try MLModel(contentsOf: url)
    }

    func prediction(input: MyRecipeRecommenderInput) throws -> MyRecipeRecommenderOutput {
        // In a real app, you'd call the underlying MLModel's prediction method:
        // let predictionOutput = try model.prediction(from: input)
        // return MyRecipeRecommenderOutput(recommendedRecipes: predictionOutput.recommendedRecipes)

        // For this mock, we return a fixed output
        print("Performing mock multi-input prediction...")
        let numRecommendations = 3
        let multiArray = try MLMultiArray(shape: [NSNumber(value: numRecommendations), 2], dataType: .float32)

        // Simulate recipe recommendations: [recipe_id, confidence]
        multiArray[0] = 101 // Recipe ID
        multiArray[1] = 0.95 // Confidence
        multiArray[2] = 105
        multiArray[3] = 0.88
        multiArray[4] = 203
        multiArray[5] = 0.75

        return MyRecipeRecommenderOutput(recommendedRecipes: multiArray)
    }
}

// MARK: - Recipe Recommendation Service
class RecipeRecommendationService {
    private var recommender: MyRecipeRecommender?

    init() {
        do {
            recommender = try MyRecipeRecommender()
            print("MyRecipeRecommender model loaded successfully.")
        } catch {
            print("Error loading MyRecipeRecommender model: \(error)")
        }
    }

    /// Performs recipe recommendation based on an ingredient image and dietary preferences.
    /// - Parameters:
    ///   - ingredientImage: The NSImage of the ingredient.
    ///   - preferencesText: A string describing dietary preferences.
    ///   - completion: A closure to call with the recommendations or an error.
    func getRecommendations(ingredientImage: NSImage, preferencesText: String, completion: @escaping (Result<[(Int, Double)], Error>) -> Void) {
        guard let recommender = recommender else {
            completion(.failure(RecommendationError.modelNotLoaded))
            return
        }

        // 1. Image Input Preparation
        guard let pixelBuffer = ingredientImage.toCVPixelBuffer(width: recommender.modelInputWidth, height: recommender.modelInputHeight, pixelFormatType: kCVPixelFormatType_32BGRA) else {
            completion(.failure(RecommendationError.imageConversionFailed))
            return
        }

        // 2. Text Input Preparation
        // The preferencesText is directly used to construct the MLFeatureProvider input.

        // 3. Construct Multi-Input MLFeatureProvider
        let input = MyRecipeRecommenderInput(ingredientImage: pixelBuffer, preferencesText: preferencesText)

        // 4. Perform Prediction
        DispatchQueue.global(qos: .userInitiated).async { // Perform prediction on a background thread
            do {
                let output = try recommender.prediction(input: input)

                // 5. Output Interpretation
                var recommendations: [(Int, Double)] = []
                let multiArray = output.recommendedRecipes
                let numRecommendations = multiArray.shape[0].intValue

                for i in 0..<numRecommendations {
                    let recipeID = multiArray[[i, 0] as [NSNumber]].intValue
                    let confidence = multiArray[[i, 1] as [NSNumber]].doubleValue
                    recommendations.append((recipeID, confidence))
                }

                // Sort by confidence (highest first)
                recommendations.sort { $0.1 > $1.1 }

                DispatchQueue.main.async {
                    completion(.success(recommendations))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(RecommendationError.predictionFailed(error)))
                }
            }
        }
    }

    enum RecommendationError: Error, LocalizedError {
        case modelNotLoaded
        case imageConversionFailed
        case predictionFailed(Error)

        var errorDescription: String? {
            switch self {
            case .modelNotLoaded: return "The Core ML model could not be loaded."
            case .imageConversionFailed: return "Failed to convert ingredient image."
            case .predictionFailed(let error): return "Prediction failed: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Example macOS UI (Conceptual, not a full AppKit implementation)
/*
// This would typically be part of a ViewController or AppDelegate in a macOS app.
class RecipeRecommenderApp: NSObject {
    let service = RecipeRecommendationService()
    var selectedImage: NSImage?
    var preferences: String = ""

    func setupUI() {
        // Conceptual UI elements:
        // let imageView = NSImageView(frame: CGRect(x: 50, y: 300, width: 200, height: 200))
        // let selectImageButton = NSButton(title: "Select Image", target: self, action: #selector(selectImage))
        // let preferencesTextField = NSTextField(frame: CGRect(x: 50, y: 250, width: 200, height: 24))
        // preferencesTextField.placeholderString = "e.g., vegetarian, gluten-free"
        // let recommendButton = NSButton(title: "Get Recommendations", target: self, action: #selector(getRecommendationsAction))
        // let resultsTextView = NSTextView(frame: CGRect(x: 50, y: 50, width: 400, height: 150))
    }

    @objc func selectImage() {
        let openPanel = NSOpenPanel()
        openPanel.allowedFileTypes = ["png", "jpg", "jpeg", "heic"]
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        openPanel.allowsMultipleSelection = false

        openPanel.begin { response in
            if response == .OK, let url = openPanel.url, let image = NSImage(contentsOf: url) {
                self.selectedImage = image
                // Update imageView.image = image
                print("Image selected: \(url.lastPathComponent)")
            }
        }
    }

    @objc func getRecommendationsAction() {
        guard let image = selectedImage else {
            print("Please select an ingredient image first.")
            return
        }
        // Assume preferences are read from a text field
        let currentPreferences = "vegetarian" // preferencesTextField.stringValue

        service.getRecommendations(ingredientImage: image, preferencesText: currentPreferences) { result in
            switch result {
            case .success(let recommendations):
                var outputString = "Top Recipe Recommendations:\n"
                for (index, rec) in recommendations.prefix(3).enumerated() {
                    outputString += "\(index + 1). Recipe ID: \(rec.0), Confidence: \(String(format: "%.2f%%", rec.1 * 100))\n"
                }
                print(outputString)
                // Update resultsTextView.string = outputString
            case .failure(let error):
                print("Recommendation error: \(error.localizedDescription)")
                // Show error in UI
            }
        }
    }
}
*/
#endif
