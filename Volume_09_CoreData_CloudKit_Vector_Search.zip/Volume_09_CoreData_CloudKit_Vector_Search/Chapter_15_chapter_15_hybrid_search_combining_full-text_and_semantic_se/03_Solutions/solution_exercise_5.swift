
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import CoreData

// MARK: - Models
struct Document: Sendable {
    let id: UUID
    let text: String
    let hybridScore: Double
}

enum SearchError: Error {
    case databaseError
    case vectorStoreUnavailable
    case emptyResults
}

// MARK: - Service
actor DocumentSearchService {
    private let container: NSPersistentContainer
    
    init(container: NSPersistentContainer) {
        self.container = container
    }
    
    /// Performs the dual-engine search.
    func search(query: String) async throws -> [Document] {
        // We use a TaskGroup to run the SQL and Vector searches in parallel.
        return try await withThrowingTaskGroup(of: SearchResultFragment.self) { group in
            
            // 1. Keyword Phase (Core Data)
            group.addTask {
                let context = self.container.newBackgroundContext()
                return try await context.perform {
                    // Simulate NSFetchRequest
                    // In real code: let request: NSFetchRequest<DocumentMO> = DocumentMO.fetchRequest()
                    // request.predicate = NSPredicate(format: "documentText CONTAINS[cd] %@", query)
                    
                    // Mocking the result of a fetch for the exercise
                    let mockID = UUID()
                    let mockText = "Found via SQL: \(query)"
                    
                    // We return a fragment, NOT the NSManagedObject
                    return .keyword(id: mockID, text: mockText, score: 0.8)
                }
            }
            
            // 2. Vector Phase (Simulated)
            group.addTask {
                try await Task.sleep(nanoseconds: 100_000_000)
                let mockID = UUID() // In real life, this ID matches the SQL ID
                return .vector(id: mockID, score: 0.95)
            }
            
            var keywordResults: [UUID: (text: String, score: Double)] = [:]
            var vectorResults: [UUID: Double] = [:]
            
            for try await fragment in group {
                switch fragment {
                case .keyword(let id, let text, let score):
                    keywordResults[id] = (text, score)
                case .vector(let id, let score):
                    vectorResults[id] = score
                }
            }
            
            // 3. The Merge (Fusion)
            var mergedDocuments: [Document] = []
            
            // Combine all unique IDs from both sets
            let allIDs = Set(keywordResults.keys).union(vectorResults.keys)
            
            for id in allIDs {
                let kData = keywordResults[id]
                let vScore = vectorResults[id]
                
                let finalScore: Double
                let finalText: String
                
                if let k = kData, let v = vScore {
                    // Document found in BOTH: Hybrid Fusion
                    finalScore = (0.5 * v) + (0.5 * k.score)
                    finalText = k.text
                } else if let k = kData {
                    // Only in Keyword
                    finalScore = k.score * 0.5 // Penalty for missing vector match
                    finalText = k.text
                } else if let v = vScore {
                    // Only in Vector
                    finalScore = v * 0.5 // Penalty for missing keyword match
                    finalText = "Vector match (text unknown)"
                } else {
                    continue
                }
                
                mergedDocuments.append(Document(id: id, text: finalText, hybridScore: finalScore))
            }
            
            guard !mergedDocuments.isEmpty else { throw SearchError.emptyResults }
            
            return mergedDocuments.sorted { $0.hybridScore > $1.hybridScore }
        }
    }
    
    // Helper enum to pass data from background tasks to the actor
    private enum SearchResultFragment: Sendable {
        case keyword(id: UUID, text: String, score: Double)
        case vector(id: UUID, score: Double)
    }
}

// MARK: - Mock Setup for Compilation
// (In a real project, these would be actual Core Data entities)
extension NSManagedObjectContext {
    func perform<T>(block: @escaping () throws -> T) async throws -> T {
        try await withCheckedThrowingContinuation { continuation in
            self.perform {
                do {
                    let result = try block()
                    continuation.resume(returning: result)
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}
