
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import WritingTools
import Combine // Required for debounce

@available(iOS 18.0, macOS 15.0, *)
class EmailComposerViewController: UIViewController, WritingToolsServiceDelegate {

    // MARK: - UI Elements

    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        textView.isWritingToolsEnabled = false // Disable system UI for proactive approach
        return textView
    }()

    private lazy var proactiveAssistantButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Proactive Assistant", for: .normal)
        button.setImage(UIImage(systemName: "sparkles"), for: .normal)
        button.tintColor = .white
        button.backgroundColor = .systemGreen
        button.layer.cornerRadius = 22
        button.isHidden = true // Hidden until suggestions are available
        button.addTarget(self, action: #selector(showProactiveSuggestions), for: .touchUpInside)
        return button
    }()

    private lazy var suggestionsBadgeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.backgroundColor = .systemRed
        label.textColor = .white
        label.font = .boldSystemFont(ofSize: 12)
        label.textAlignment = .center
        label.layer.cornerRadius = 10
        label.layer.masksToBounds = true
        label.isHidden = true
        return label
    }()

    // MARK: - WritingToolsService Properties

    var writingToolsService: WritingToolsService?
    private var textDidChangeCancellable: AnyCancellable?
    private var currentGeneralSuggestions: [WritingToolsSuggestion] = []
    private var currentProactiveRefinementOptions: [WritingToolsRefinementResult.Option] = []
    private var proactiveRefinementType: WritingToolsRefinementType? // To track what kind of refinement was offered

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Smart Email Composer"

        setupUI()
        setupWritingToolsService()
        setupTextObservation()
    }

    // MARK: - Setup Methods

    private func setupUI() {
        view.addSubview(textView)
        view.addSubview(proactiveAssistantButton)
        proactiveAssistantButton.addSubview(suggestionsBadgeLabel)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            proactiveAssistantButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            proactiveAssistantButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            proactiveAssistantButton.widthAnchor.constraint(equalToConstant: 180),
            proactiveAssistantButton.heightAnchor.constraint(equalToConstant: 44),

            suggestionsBadgeLabel.topAnchor.constraint(equalTo: proactiveAssistantButton.topAnchor, constant: -5),
            suggestionsBadgeLabel.trailingAnchor.constraint(equalTo: proactiveAssistantButton.trailingAnchor, constant: 5),
            suggestionsBadgeLabel.widthAnchor.constraint(equalToConstant: 20),
            suggestionsBadgeLabel.heightAnchor.constraint(equalToConstant: 20)
        ])

        textView.text = """
        Dear Team,

        I hope this email finds you well. I am writing to inform you that the project status meeting has been moved to a new time. It will now take place on Friday at 2 PM instead of the usual Wednesday morning slot. Please make sure to update your calendars accordingly.

        I understand this might cause some inconvenience, but it was necessary due to a scheduling conflict. I apoligize for any trouble this may cause.

        Best regards,
        [Your Name]
        """
    }

    private func setupWritingToolsService() {
        writingToolsService = WritingToolsService()
        writingToolsService?.delegate = self // For general suggestions
        writingToolsService?.textInput = textView // For general suggestions
        print("WritingToolsService initialized for proactive suggestions.")
    }

    private func setupTextObservation() {
        // Debounce text changes to avoid excessive AI requests
        textDidChangeCancellable = NotificationCenter.default.publisher(
            for: UITextView.textDidChangeNotification,
            object: textView
        )
        .debounce(for: .seconds(2.0), scheduler: RunLoop.main) // Wait 2 seconds after last change
        .sink { [weak self] _ in
            self?.evaluateProactiveRefinements()
        }
    }

    // MARK: - Proactive Evaluation

    private func evaluateProactiveRefinements() {
        guard let fullText = textView.text, !fullText.isEmpty else {
            updateProactiveAssistantUI()
            return
        }

        // --- Heuristic 1: Proactively suggest conciseness for long texts ---
        if fullText.count > 300 && fullText.split(where: \.isNewline).count > 3 { // Heuristic for long, multi-paragraph text
            print("Proactively considering 'Make More Concise'...")
            requestProactiveRefinement(type: .makeMoreConcise, for: NSRange(location: 0, length: fullText.utf16.count))
            return // Only offer one major refinement proactively at a time for simplicity
        }

        // --- Heuristic 2: Proactively suggest tone adjustment if it seems inconsistent (simplified) ---
        // This is a very basic heuristic. A real app would use more sophisticated NLP.
        let lowercaseText = fullText.lowercased()
        let informalKeywords = ["gonna", "wanna", "lol", "btw", "kinda"]
        let formalKeywords = ["furthermore", "consequently", "therefore", "sincerely"]

        let hasInformal = informalKeywords.contains { lowercaseText.contains($0) }
        let hasFormal = formalKeywords.contains { lowercaseText.contains($0) }

        if hasInformal && hasFormal && fullText.count > 100 { // Mixed tone detected
            print("Proactively considering 'Change Tone to Formal'...")
            requestProactiveRefinement(type: .changeTone(to: .formal), for: NSRange(location: 0, length: fullText.utf16.count))
            return
        }

        // If no proactive refinement is triggered, clear previous proactive suggestions
        self.currentProactiveRefinementOptions.removeAll()
        self.proactiveRefinementType = nil
        updateProactiveAssistantUI()
    }

    private func requestProactiveRefinement(type: WritingToolsRefinementType, for range: NSRange) {
        // Only request if a different type or if no options are currently displayed
        if self.proactiveRefinementType != type || self.currentProactiveRefinementOptions.isEmpty {
            print("Requesting proactive refinement: \(type)")
            writingToolsService?.requestRefinement(
                for: textView,
                text: textView.text,
                selection: range,
                refinementType: type
            ) { [weak self] result in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let refinementResult):
                        if let options = refinementResult.options, !options.isEmpty {
                            self?.currentProactiveRefinementOptions = options
                            self?.proactiveRefinementType = type
                            print("Proactive refinement options received for \(type): \(options.map { $0.text })")
                        } else {
                            self?.currentProactiveRefinementOptions.removeAll()
                            self?.proactiveRefinementType = nil
                            print("Proactive refinement for \(type) returned no options.")
                        }
                    case .failure(let error):
                        self?.currentProactiveRefinementOptions.removeAll()
                        self?.proactiveRefinementType = nil
                        print("Proactive refinement for \(type) failed: \(error.localizedDescription)")
                    }
                    self?.updateProactiveAssistantUI()
                }
            }
        }
    }

    // MARK: - Proactive UI Management

    private func updateProactiveAssistantUI() {
        let totalSuggestions = currentGeneralSuggestions.count + currentProactiveRefinementOptions.count

        if totalSuggestions > 0 {
            proactiveAssistantButton.isHidden = false
            suggestionsBadgeLabel.isHidden = false
            suggestionsBadgeLabel.text = "\(totalSuggestions)"
        } else {
            proactiveAssistantButton.isHidden = true
            suggestionsBadgeLabel.isHidden = true
        }
    }

    @objc private func showProactiveSuggestions() {
        var menuElements: [UIMenuElement] = []

        // Add general grammar/spelling suggestions
        if !currentGeneralSuggestions.isEmpty {
            let generalActions = currentGeneralSuggestions.map { suggestion in
                UIAction(title: "Fix: '\(suggestion.text)'", image: UIImage(systemName: "text.badge.checkmark")) { [weak self] _ in
                    self?.applySuggestion(suggestion)
                }
            }
            menuElements.append(UIMenu(title: "Grammar & Spelling", options: .displayInline, children: generalActions))
        }

        // Add proactive refinement options
        if !currentProactiveRefinementOptions.isEmpty, let refinementType = proactiveRefinementType {
            let refinementTitle: String
            switch refinementType {
            case .makeMoreConcise: refinementTitle = "Make More Concise"
            case .changeTone(to: .formal): refinementTitle = "Adjust Tone to Formal"
            case .changeTone(to: .friendly): refinementTitle = "Adjust Tone to Friendly"
            default: refinementTitle = "Refinement"
            }

            let refinementActions = currentProactiveRefinementOptions.map { option in
                UIAction(title: option.text, image: UIImage(systemName: "wand.and.stars")) { [weak self] _ in
                    // Apply the selected option to the full text
                    self?.textView.replace(NSRange(location: 0, length: self?.textView.text.utf16.count ?? 0), with: option.text)
                    self?.currentProactiveRefinementOptions.removeAll() // Clear after applying
                    self?.proactiveRefinementType = nil
                    self?.updateProactiveAssistantUI()
                }
            }
            menuElements.append(UIMenu(title: refinementTitle, options: .displayInline, children: refinementActions))
        }

        guard !menuElements.isEmpty else { return }

        let menu = UIMenu(title: "", children: menuElements)
        let interaction = UIContextMenuInteraction(delegate: self)
        proactiveAssistantButton.addInteraction(interaction)

        // This is a workaround to present a UIMenu from a button without a long press.
        // In a real app, you might use a custom popover or a dedicated suggestions panel.
        let config = UIEditMenuConfiguration(identifier: "proactiveMenu", sourcePoint: proactiveAssistantButton.center)
        let menuInteraction = UIEditMenuInteraction(delegate: self)
        menuInteraction.presentEditMenu(with: config, preferredMenu: menu)
    }

    private func applySuggestion(_ suggestion: WritingToolsSuggestion) {
        textView.apply(suggestion: suggestion)
        print("Applied general suggestion: '\(suggestion.text)' at range \(suggestion.range)")
        // The WritingToolsService will re-evaluate and provide new suggestions
    }

    // MARK: - WritingToolsServiceDelegate

    func writingToolsService(_ service: WritingToolsService, didProvideSuggestions suggestions: [WritingToolsSuggestion], for textInput: any WritingToolsTextInput) {
        // These are general grammar/spelling suggestions provided automatically
        DispatchQueue.main.async {
            self.currentGeneralSuggestions = suggestions
            print("Received \(suggestions.count) general writing suggestions.")
            self.updateProactiveAssistantUI()
        }
    }

    func writingToolsService(_ service: WritingToolsService, didFailWithError error: Error, for textInput: any WritingToolsTextInput) {
        DispatchQueue.main.async {
            print("Writing Tools Service failed: \(error.localizedDescription)")
            // Clear all suggestions on error
            self.currentGeneralSuggestions.removeAll()
            self.currentProactiveRefinementOptions.removeAll()
            self.proactiveRefinementType = nil
            self.updateProactiveAssistantUI()
        }
    }
}

// MARK: - UIContextMenuInteractionDelegate & UIEditMenuInteractionDelegate (for proactive button)

@available(iOS 18.0, *)
extension EmailComposerViewController: UIContextMenuInteractionDelegate, UIEditMenuInteractionDelegate {
    func contextMenuInteraction(_ interaction: UIContextMenuInteraction, configurationForMenuAtLocation location: CGPoint) -> UIContextMenuConfiguration? {
        // This is primarily for the UIContextMenuInteraction, but we are using UIEditMenuInteraction
        // for presenting the actual menu from the button tap.
        return nil
    }

    func editMenuInteraction(_ interaction: UIEditMenuInteraction, menuFor configuration: UIEditMenuConfiguration, suggestedActions: [UIMenuElement]) -> UIMenu? {
        // This method is called by the UIEditMenuInteraction when we manually call presentEditMenu
        var menuElements: [UIMenuElement] = []

        if !currentGeneralSuggestions.isEmpty {
            let generalActions = currentGeneralSuggestions.map { suggestion in
                UIAction(title: "Fix: '\(suggestion.text)'", image: UIImage(systemName: "text.badge.checkmark")) { [weak self] _ in
                    self?.applySuggestion(suggestion)
                }
            }
            menuElements.append(UIMenu(title: "Grammar & Spelling", options: .displayInline, children: generalActions))
        }

        if !currentProactiveRefinementOptions.isEmpty, let refinementType = proactiveRefinementType {
            let refinementTitle: String
            switch refinementType {
            case .makeMoreConcise: refinementTitle = "Make More Concise"
            case .changeTone(to: .formal): refinementTitle = "Adjust Tone to Formal"
            case .changeTone(to: .friendly): refinementTitle = "Adjust Tone to Friendly"
            default: refinementTitle = "Refinement"
            }

            let refinementActions = currentProactiveRefinementOptions.map { option in
                UIAction(title: option.text, image: UIImage(systemName: "wand.and.stars")) { [weak self] _ in
                    // Apply the selected option to the full text
                    self?.textView.replace(NSRange(location: 0, length: self?.textView.text.utf16.count ?? 0), with: option.text)
                    self?.currentProactiveRefinementOptions.removeAll()
                    self?.proactiveRefinementType = nil
                    self?.updateProactiveAssistantUI()
                }
            }
            menuElements.append(UIMenu(title: refinementTitle, options: .displayInline, children: refinementActions))
        }
        return UIMenu(children: menuElements)
    }
}
