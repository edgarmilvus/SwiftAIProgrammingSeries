
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI

// MARK: - 1. Bounding Box Data Structure

/// Represents a single bounding box detection, including its normalized frame and a label.
/// The `normalizedRect` is expected to have coordinates (x, y, width, height)
/// ranging from 0.0 to 1.0, relative to the original image's dimensions.
struct BoundingBox: Identifiable {
    let id = UUID()
    let normalizedRect: CGRect
    let label: String
    let color: Color // Added for visual distinction
}

// MARK: - 2. Main View: ContentView

@available(iOS 17.0, macOS 14.0, *) // Canvas and GeometryReader are available on older OS versions, but 17.0+ for modern SwiftUI features
struct ContentView: View {
    // Sample image name from Assets.xcassets
    let imageName = "sampleImage"

    // Sample bounding box data (normalized coordinates 0.0 to 1.0)
    let detectedBoxes: [BoundingBox] = [
        .init(normalizedRect: CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4), label: "Cat", color: .red),
        .init(normalizedRect: CGRect(x: 0.5, y: 0.1, width: 0.2, height: 0.3), label: "Dog", color: .green),
        .init(normalizedRect: CGRect(x: 0.2, y: 0.6, width: 0.4, height: 0.2), label: "Ball", color: .blue)
    ]

    var body: some View {
        VStack {
            Text("Object Detection Overlay")
                .font(.largeTitle)
                .padding()

            // MARK: - 3. Layering Image and Overlays with ZStack

            ZStack {
                // The base image.
                // It's important to use .resizable() and .scaledToFit() or .scaledToFill()
                // to ensure the image scales within the available space.
                Image(imageName)
                    .resizable()
                    .scaledToFit() // This determines how the image fits its container.
                    .background(Color.gray.opacity(0.2)) // Helps visualize the image's bounds

                // MARK: - 4. GeometryReader for Dynamic Sizing

                // GeometryReader provides the size of the space allocated to it by its parent.
                // We place it on top of the image to get the *displayed* image size.
                GeometryReader { geometry in
                    // MARK: - 5. Canvas for Custom Drawing

                    // Canvas allows for imperative, high-performance custom drawing.
                    // It gives us a GraphicsContext and the current size of the Canvas itself.
                    Canvas { context, size in
                        // The 'size' here is the size of the GeometryReader,
                        // which matches the size of the displayed image (due to .scaledToFit()).

                        // Iterate through each detected bounding box
                        for box in detectedBoxes {
                            // MARK: - 6. Scaling Normalized Coordinates to View Dimensions

                            // Calculate the actual frame in points based on the Canvas's size
                            let x = box.normalizedRect.origin.x * size.width
                            let y = box.normalizedRect.origin.y * size.height
                            let width = box.normalizedRect.size.width * size.width
                            let height = box.normalizedRect.size.height * size.height

                            let rect = CGRect(x: x, y: y, width: width, height: height)

                            // MARK: - 7. Drawing the Bounding Box Rectangle

                            // Create a Path for the rectangle
                            var path = Path()
                            path.addRect(rect)

                            // Draw the path with a stroke
                            context.stroke(path, with: .color(box.color), lineWidth: 2)

                            // MARK: - 8. Drawing the Label Text

                            // Prepare the text label
                            let text = Text(box.label)
                                .font(.caption)
                                .foregroundColor(box.color)

                            // Resolve the text into a Drawable text object
                            let resolvedText = context.resolve(text)

                            // Calculate text position: above the bounding box, centered horizontally
                            let textX = rect.midX
                            // Adjust y to place text slightly above the box
                            let textY = rect.origin.y - (resolvedText.metrics.descent + resolvedText.metrics.ascent) / 2 - 5

                            // Draw the text at the calculated position
                            context.draw(resolvedText, at: CGPoint(x: textX, y: textY))
                        }
                    }
                }
            }
            .border(Color.blue, width: 2) // Visualizes the ZStack's bounds
            .padding()
        }
    }
}

// MARK: - 9. App Entry Point (for Xcode Previews and App Launch)

@available(iOS 17.0, macOS 14.0, *)
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// Remember to add an image named "sampleImage" to your Assets.xcassets
// For example, a 1000x800 pixel image. The normalized coordinates
// will scale correctly regardless of the original image's pixel dimensions,
// as long as the aspect ratio is maintained when displayed.
