/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// utils/linkParser.ts
export function parseStoreLink(url: string): { category: string; itemId: string } | null {
  // Example: myapp://store/electronics/item/456
  const regex = /store\/([^\/]+)\/item\/([^\/]+)/;
  const match = url.match(regex);
  
  if (match) {
    return {
      category: match[1],
      itemId: match[2],
    };
  }
  return null;
}

// App.tsx (Partial integration)
import { CommonActions } from '@react-navigation/native';

// Inside the handleInitialURL effect or a deep link listener:
const handleDeepLink = (url: string) => {
  const parsed = parseStoreLink(url);
  
  if (!parsed) {
    // Fallback for malformed URLs
    navigationRef.current?.navigate('ErrorScreen', { message: 'Invalid Link' });
    return;
  }

  // Reset stack to prevent going back to 'Home' (Initial Screen)
  // This ensures the user starts at the Store Item screen
  navigationRef.current?.dispatch(
    CommonActions.reset({
      index: 0,
      routes: [
        { name: 'StoreItem', params: { category: parsed.category, itemId: parsed.itemId } },
      ],
    })
  );
};

// StoreItemScreen.tsx
const StoreItemScreen = ({ route }: any) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Simulate API call
        const response = await fetch(`https://api.example.com/items/${route.params.itemId}`);
        if (!response.ok) throw new Error('404 Not Found');
        const json = await response.json();
        setData(json);
      } catch (err) {
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [route.params.itemId]);

  if (loading) return <Text>Loading...</Text>;
  if (error) return <Text>Item Not Found. <Button title="Retry" onPress={() => {/* retry logic */}} /></Text>;

  return <Text>Store Item: {data?.name}</Text>;
};
