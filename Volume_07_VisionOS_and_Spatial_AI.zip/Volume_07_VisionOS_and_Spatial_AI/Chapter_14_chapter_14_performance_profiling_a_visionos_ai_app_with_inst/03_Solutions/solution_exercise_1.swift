
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import RealityKit
import ARKit

// 1. Define the Component
struct RepulsionComponent: Component {
    var radius: Float
    var strength: Float
}

// 2. The "Flawed" System
class RepulsionSystem: RealityKit.System {
    // Required initializer for RealityKit System
    required init(scene: RealityKit.Scene) { }

    func update(context: SceneUpdateContext) {
        // Simulated hand position (e.g., from hand tracking)
        let handPosition = SIMD3<Float>(0, 1.5, -0.5)
        
        // Iterate through all entities with RepulsionComponent
        context.entities(matching: EntityQuery(where: .has(RepulsionComponent.self)), updatingSystemAttributes: .transform).forEach { entity in
            guard let repulsion = entity.components[RepulsionComponent.self] as? RepulsionComponent else { return }
            
            let entityPosition = entity.position(relativeTo: nil)
            
            // --- THE FLAW: Non-optimized math ---
            // Using Double-precision math and standard pow/sqrt functions 
            // instead of SIMD-optimized simd_distance.
            // This forces type conversion and avoids hardware acceleration.
            let dx = Double(entityPosition.x - handPosition.x)
            let dy = Double(entityPosition.y - handPosition.y)
            let dz = Double(entityPosition.z - handPosition.z)
            
            let distance = sqrt(pow(dx, 2) + pow(dy, 2) + pow(dz, 2))
            let distanceF = Float(distance)
            
            if distanceF < repulsion.radius {
                let force = (repulsion.radius - distanceF) * repulsion.strength
                let direction = normalize(entityPosition - handPosition)
                entity.position += direction * force * Float(context.deltaTime)
            }
        }
    }
}

@available(visionOS 1.0, *)
struct PhysicsSandboxView: View {
    @State private var sphereCount = 200

    var body: some View {
        RealityView { content in
            // Register the system
            RepulsionSystem.registerSystem()
            
            // Spawn 200 spheres
            for _ in 0..<sphereCount {
                let sphere = ModelEntity(mesh: .generateSphere(radius: 0.05), materials: [SimpleMaterial(color: .blue, isMetallic: true)])
                sphere.position = [
                    Float.random(in: -1...1),
                    Float.random(in: 0...2),
                    Float.random(in: -1...1)
                ]
                sphere.components.set(RepulsionComponent(radius: 0.5, strength: 0.1))
                content.add(sphere)
            }
        }
    }
}
