
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// A utility to convert a Data stream to a String, handling potential encoding issues
extension Data {
    var toString: String {
        String(data: self, encoding: .utf8) ?? String(data: self, encoding: .ascii) ?? ""
    }
}

/// An example of an asynchronous shell command executor.
@available(macOS 13.0, *) // Process.run() requires macOS 13+
actor ShellExecutor {
    private var activeProcesses: [UUID: Process] = [:]

    enum ShellError: Error {
        case commandNotFound(String)
        case executionFailed(command: String, exitCode: Int, stderr: String)
        case cancelled
        case unknown
    }

    /// Executes a shell command asynchronously and returns its stdout.
    /// - Parameters:
    ///   - command: The path to the executable (e.g., "/usr/bin/env").
    ///   - arguments: An array of string arguments.
    ///   - currentDirectoryURL: The working directory for the command.
    ///   - environment: Optional environment variables for the process.
    /// - Returns: The standard output of the command.
    func execute(
        command: String,
        arguments: [String] = [],
        currentDirectoryURL: URL? = nil,
        environment: [String: String]? = nil
    ) async throws -> String {
        let processUUID = UUID()
        let process = Process()
        let outputPipe = Pipe()
        let errorPipe = Pipe()

        process.executableURL = URL(fileURLWithPath: command)
        process.arguments = arguments
        process.standardOutput = outputPipe
        process.standardError = errorPipe
        process.currentDirectoryURL = currentDirectoryURL
        process.environment = environment

        // Store the process in isolated state to allow cancellation
        activeProcesses[processUUID] = process

        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                do {
                    try process.run()
                    process.waitUntilExit() // This is still blocking, but occurs on a detached task or within the continuation's context.

                    let stdoutData = outputPipe.fileHandleForReading.readDataToEndOfFile()
                    let stderrData = errorPipe.fileHandleForReading.readDataToEndOfFile()

                    let stdout = stdoutData.toString
                    let stderr = stderrData.toString

                    if process.terminationStatus == 0 {
                        continuation.resume(returning: stdout)
                    } else {
                        continuation.resume(throwing: ShellError.executionFailed(
                            command: command + " " + arguments.joined(separator: " "),
                            exitCode: Int(process.terminationStatus),
                            stderr: stderr
                        ))
                    }
                } catch let error as NSError {
                    if error.code == 4 && error.domain == NSPOSIXErrorDomain { // ENOENT - No such file or directory
                        continuation.resume(throwing: ShellError.commandNotFound(command))
                    } else {
                        continuation.resume(throwing: error)
                    }
                }
            }
        } onCancel: {
            // Cancellation handler for the Task
            process.terminate() // Attempt to terminate the running process
            Task { @MainActor in
                // Clean up the process from the actor's state on cancellation
                await self.removeProcess(for: processUUID)
            }
        }
    }

    // Actor-isolated method to remove a process from the active list
    private func removeProcess(for uuid: UUID) {
        activeProcesses.removeValue(forKey: uuid)
    }

    /// Cancels a running command by its UUID.
    func cancelCommand(uuid: UUID) {
        activeProcesses[uuid]?.terminate()
        activeProcesses.removeValue(forKey: uuid)
    }
}
