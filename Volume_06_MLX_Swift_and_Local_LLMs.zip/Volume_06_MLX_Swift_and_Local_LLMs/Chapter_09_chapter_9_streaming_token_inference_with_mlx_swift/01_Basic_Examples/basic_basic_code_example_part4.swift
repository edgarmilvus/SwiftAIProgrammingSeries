
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.swift
// Description: Basic Code Example
// ==========================================

@available(iOS 17.0, macOS 14.0, *) // Requires modern async/await features
extension SimpleTokenPredictor {
    /// Generates a sequence of tokens one by one, mimicking a streaming chat bot.
    /// - Parameters:
    ///   - prompt: The initial text prompt to start generation.
    ///   - tokenizer: The tokenizer used to convert text to token IDs and vice-versa.
    ///   - maxLength: The maximum number of tokens to generate.
    ///   - temperature: Controls the randomness of predictions. Higher values make output more random.
    /// - Returns: An `AsyncStream` of `String`s, where each string is a newly generated token.
    func generateStream(
        prompt: String,
        tokenizer: CharacterTokenizer,
        maxLength: Int = 50,
        temperature: Float = 0.8
    ) -> AsyncStream<String> {
        return AsyncStream { continuation in
            Task {
                var currentTokens = tokenizer.encode(prompt)
                
                // Yield the initial prompt immediately
                continuation.yield(prompt)

                for _ in 0..<maxLength {
                    // Ensure we don't exceed a reasonable context window if this were a real LLM
                    // For our simple model, we only care about the last token for prediction.
                    let inputTokens = currentTokens.suffix(1) // Get the last token for prediction
                    
                    // Convert the input tokens to an MLXArray.
                    // Shape: [1, 1] (batch_size=1, sequence_length=1)
                    let inputMLXArray = MLXArray(inputTokens, type: .int32)
                    
                    // Perform the forward pass to get logits for the next token.
                    // MLX uses lazy evaluation, so this builds the computation graph.
                    let logits = self(inputMLXArray)
                    
                    // Apply temperature for sampling.
                    // `MLX.log(logits)` calculates the natural logarithm of the logits.
                    // `MLX.divide(logits, temperature)` scales the logits.
                    // `MLX.softmax` converts logits to probabilities.
                    let scaledLogits = MLX.divide(logits, temperature)
                    let probabilities = MLX.softmax(scaledLogits, axis: -1)
                    
                    // To get the actual result, we need to explicitly evaluate the graph.
                    // `MLX.eval()` forces the computation to run on the device (CPU/GPU).
                    // `probabilities.squeeze()` removes dimensions of size 1 (e.g., [1, vocabSize] -> [vocabSize])
                    // `MLX.random.categorical()` samples a token based on the probabilities.
                    let nextTokenMLXArray = MLX.random.categorical(probabilities.squeeze(0))
                    
                    // Convert the MLXArray result back to a Swift Int.
                    // This also forces evaluation if not already done.
                    let nextTokenID = nextTokenMLXArray.item() as! Int
                    
                    // If the model predicts an unknown token or a stop condition, break.
                    if nextTokenID == tokenizer.unknownTokenID {
                        break
                    }

                    // Decode the new token ID to a character.
                    guard let nextChar = tokenizer.decode([nextTokenID]).first else {
                        break
                    }

                    // Append the new token ID to our sequence for the next iteration.
                    currentTokens.append(nextTokenID)
                    
                    // Yield the newly generated character.
                    continuation.yield(String(nextChar))
                }
                // Signal that generation is complete.
                continuation.finish()
            }
        }
    }
}
