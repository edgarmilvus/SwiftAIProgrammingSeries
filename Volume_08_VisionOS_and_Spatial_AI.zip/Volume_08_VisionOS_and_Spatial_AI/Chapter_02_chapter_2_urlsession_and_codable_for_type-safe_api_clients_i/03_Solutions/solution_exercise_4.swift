
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, *)
import Foundation

enum MessageRole: String, Codable, Sendable {
    case user, assistant, system
}

enum MessageContent: Sendable {
    case text(String)
    case toolCall(id: String, name: String, args: [String: String])
}

struct Message: Decodable, Sendable {
    let id: String
    let role: MessageRole
    let content: MessageContent

    enum CodingKeys: String, CodingKey {
        case id, role, content, toolCalls = "tool_calls"
    }

    enum ToolCallKeys: String, CodingKey {
        case id, type, function
    }

    enum FunctionKeys: String, CodingKey {
        case name, arguments
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(String.self, forKey: .id)
        self.role = try container.decode(MessageRole.self, forKey: .role)

        // 1. Attempt to decode 'content' as a simple String
        if let textContent = try? container.decode(String.self, forKey: .content) {
            self.content = .text(textContent)
        } 
        // 2. If content is missing, check for 'tool_calls'
        else if var toolCallsContainer = try? container.nestedUnkeyedContainer(forKey: .toolCalls),
                !toolCallsContainer.isAtEnd {
            
            // Decode the first tool call (simplified for this exercise)
            let toolCallContainer = try toolCallsContainer.nestedContainer(keyedBy: ToolCallKeys.self)
            let id = try toolCallContainer.decode(String.self, forKey: .id)
            let functionContainer = try toolCallContainer.nestedContainer(keyedBy: FunctionKeys.self, forKey: .function)
            let name = try functionContainer.decode(String.self, forKey: .name)
            
            // 3. Handle the JSON String 'arguments'
            let argsString = try functionContainer.decode(String.self, forKey: .arguments)
            let argsData = Data(argsString.utf8)
            let args = try JSONSerialization.jsonObject(with: argsData) as? [String: String] ?? [:]
            
            self.content = .toolCall(id: id, name: name, args: args)
        } else {
            throw DecodingError.dataCorruptedError(forKey: .content, in: container, debugDescription: "Missing content or tool_calls")
        }
    }
}

struct Conversation: Decodable, Sendable {
    let id: String
    let title: String
    let messages: [Message]
}

struct SyncService {
    let manager = NetworkManager()
    
    func fetchHistory() async throws -> [Conversation] {
        let url = URL(string: "https://api.mindflow.ai/v1/sync")!
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601 // Handles the ISO8601 requirement
        
        // In a real app, the manager would be configured with this decoder
        return try await manager.request(url, method: .get)
    }
}
