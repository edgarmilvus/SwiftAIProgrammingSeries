
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import RealityKit
import GroupActivities
import Foundation
import Combine

struct SpatialTransformUpdate: Codable, Sendable {
    let entityID: UUID
    let position: SIMD3<Float>
}

@Observable
@MainActor
class SpatialSyncEngine {
    private var lastSentPosition: SIMD3<Float> = .zero
    private let movementThreshold: Float = 0.01 // 1cm threshold
    private var updateTask: Task<Void, Never>?
    
    // For smoothing incoming data
    private var targetPosition: SIMD3<Float> = .zero
    
    /// Starts the outbound loop: RealityKit -> GroupSession
    func startOutboundSync(for entity: Entity, session: GroupSession<MoodBoardActivity>) {
        updateTask = Task {
            while !Task.isCancelled {
                let currentPos = entity.position(relativeTo: nil)
                
                // Optimization: Only send if movement exceeds threshold
                if distance(currentPos, lastSentPosition) > movementThreshold {
                    let update = SpatialTransformUpdate(entityID: UUID(), position: currentPos)
                    
                    do {
                        try await session.send(update)
                        lastSentPosition = currentPos
                    } catch {
                        print("Failed to send update: \(error)")
                    }
                }
                
                // Throttle updates to ~30Hz to save bandwidth
                try? await Task.sleep(for: .milliseconds(33))
            }
        }
    }
    
    /// Starts the inbound loop: GroupSession -> RealityKit
    func startInboundSync(for entity: Entity, session: GroupSession<MoodBoardActivity>) {
        Task {
            do {
                for await update in session.updates(as: SpatialTransformUpdate.self) {
                    // In a real app, we'd match update.entityID to the correct entity
                    self.targetPosition = update.position
                }
            } catch {
                print("Inbound sync error: \(error)")
            }
        }
        
        // Smoothing Loop (The "Visual Bridge")
        // Runs at the display refresh rate to interpolate movement
        Timer.scheduledTimer(withTimeInterval: 1/60, repeats: true) { _ in
            Task { @MainActor in
                // Linear Interpolation (lerp) to prevent "teleporting"
                let smoothedPos = mix(entity.position, self.targetPosition, t: 0.15)
                entity.position = smoothedPos
            }
        }
    }
}

// Helper for distance calculation
func distance(_ a: SIMD3<Float>, _ b: SIMD3<Float>) -> Float {
    return simd_distance(a, b)
}

// Helper for linear interpolation
func mix(_ a: SIMD3<Float>, _ b: SIMD3<Float>, t: Float) -> SIMD3<Float> {
    return a + (b - a) * t
}
