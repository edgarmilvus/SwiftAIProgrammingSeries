
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import XCTest

final class ChatUITests: XCTestCase {
    let app = XCUIApplication()

    override func setUpWithError() throws {
        continueAfterFailure = false
        app.launch()
    }

    func test_chatFlow_displaysAIBuddyResponse() throws {
        let textField = app.textFields["chat_input_field"]
        let sendButton = app.buttons["send_button"]
        let typingIndicator = app.otherElements["ai_typing_indicator"]
        let chatBubbleContainer = app.otherElements["chat_bubble_container"]

        // 1. Interaction
        XCTAssertTrue(textField.waitForExistence(timeout: 5))
        textField.tap()
        textField.typeText("Write a short greeting.")
        sendButton.tap()

        // 2. State Transition: Check if "Typing..." appears
        // We don't check the text, we check the accessibilityIdentifier
        XCTAssertTrue(typingIndicator.waitForExistence(timeout: 2), "Typing indicator should appear")
        
        // 3. State Transition: Check if "Typing..." disappears
        // This ensures the AI has finished generating
        let exists = typingIndicator.waitForExistence(timeout: 10)
        XCTAssertFalse(exists, "Typing indicator should disappear after AI finishes")
        
        // 4. Content Assertion: Use Predicates for non-deterministic text
        // We want to ensure the bubble isn't empty and contains meaningful text
        let bubbleText = chatBubbleContainer.staticTexts.firstMatch
        XCTAssertTrue(bubbleText.exists)
        
        // Use an NSPredicate to check if the text contains at least one character 
        // and isn't just whitespace
        let nonEmptyPredicate = NSPredicate(format: "length > 0")
        NSPredicateTesting(bubbleText, nonEmptyPredicate)
        
        // 5. Regex-style check: Ensure there is some punctuation (common in AI responses)
        let textValue = bubbleText.label
        let containsPunctuation = textValue.range(of: #"[.!?,]"#, options: .regularExpression) != nil
        XCTAssertTrue(containsPunctuation, "AI response should contain punctuation.")
    }
}

// Helper for cleaner predicate testing
func NSPredicateTesting(_ element: XCUIElement, _ predicate: NSPredicate) {
    let expectation = XCTNSPredicateExpectation(predicate: predicate, object: element)
    XCTWaiter().wait(for: [expectation], timeout: 5)
}
