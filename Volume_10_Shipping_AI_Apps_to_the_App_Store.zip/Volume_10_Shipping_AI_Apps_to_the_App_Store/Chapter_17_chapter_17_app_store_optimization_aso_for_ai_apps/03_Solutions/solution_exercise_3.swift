
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

enum CloudProvider: String, Sendable {
    case openai, anthropic, custom
}

enum LatencyProfile: Sendable {
    case instant, delayed
}

struct AIConfiguration: Sendable {
    let isOnDeviceEnabled: Bool
    let cloudProvider: CloudProvider?
    let latencyProfile: LatencyProfile
}

struct LocalizedMetadataBundle: Sendable {
    let title: String
    let subtitle: String
    let description: String
    let privacyManifestDescription: String
}

struct PrivacyDataRequirement: Sendable {
    let dataType: String
    let isCollected: Bool
}

actor MetadataOrchestrationService {
    private var currentConfig: AIConfiguration
    
    init(initialConfig: AIConfiguration) {
        self.currentConfig = initialConfig
    }
    
    func updateConfiguration(_ newConfig: AIConfiguration) {
        self.currentConfig = newConfig
    }
    
    func generateMetadata() async -> LocalizedMetadataBundle {
        let config = currentConfig
        
        // 1. Generate Subtitle
        let subtitle = config.isOnDeviceEnabled 
            ? "Private & Secure AI" 
            : "Powerful Cloud Intelligence"
        
        // 2. Generate Description (Complex Logic)
        var descriptionParts: [String] = []
        
        if config.isOnDeviceEnabled {
            descriptionParts.append("Experience lightning-fast, on-device processing.")
            descriptionParts.append("Your data never leaves your device, ensuring total privacy.")
        }
        
        if let provider = config.cloudProvider {
            descriptionParts.append("Leverage the world-class reasoning of \(provider.rawValue.capitalized).")
            descriptionParts.append("Handle complex creative tasks with ease.")
        }
        
        let description = descriptionParts.joined(separator: " ")
        
        // 3. Generate Privacy Manifest Data
        let privacyDescription = config.isOnDeviceEnabled 
            ? "All AI processing occurs locally on your device."
            : "Data is securely transmitted to our cloud providers for processing."
            
        return LocalizedMetadataBundle(
            title: "EchoMind AI",
            subtitle: subtitle,
            description: description,
            privacyManifestDescription: privacyDescription
        )
    }
    
    func getPrivacyRequirements() async -> [PrivacyDataRequirement] {
        if currentConfig.cloudProvider != nil {
            return [
                PrivacyDataRequirement(dataType: "NSPrivacyCollectedDataTypes.userContent", isCollected: true),
                PrivacyDataRequirement(dataType: "NSPrivacyCollectedDataTypes.identifiers", isCollected: true)
            ]
        } else {
            return [
                PrivacyDataRequirement(dataType: "NSPrivacyCollectedDataTypes.userContent", isCollected: false)
            ]
        }
    }
}

// MARK: - Execution
@MainActor
func testOrchestrator() async {
    let initialConfig = AIConfiguration(isOnDeviceEnabled: true, cloudProvider: nil, latencyProfile: .instant)
    let orchestrator = MetadataOrchestrationService(initialConfig: initialConfig)
    
    // Test On-Device Mode
    let onDeviceMetadata = await orchestrator.generateMetadata()
    print("--- ON-DEVICE MODE ---")
    print("Subtitle: \(onDeviceMetadata.subtitle)")
    print("Privacy: \(onDeviceMetadata.privacyManifestDescription)")
    
    // Switch to Hybrid Mode
    let hybridConfig = AIConfiguration(isOnDeviceEnabled: true, cloudProvider: .openai, latencyProfile: .delayed)
    await orchestrator.updateConfiguration(hybridConfig)
    
    let hybridMetadata = await orchestrator.generateMetadata()
    print("\n--- HYBRID MODE ---")
    print("Subtitle: \(hybridMetadata.subtitle)")
    print("Description: \(hybridMetadata.description)")
    
    let privacyReqs = await orchestrator.getPrivacyRequirements()
    print("Privacy Requirements: \(privacyReqs.map { "\($0.dataType): \($0.isCollected)" })")
}

await testOrchestrator()
