
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import MLX
    import MLXNN // Assuming MLXNN is part of your package

    // Package.swift snippet for dependencies
    /*
    // swift-tools-version: 5.9
    import PackageDescription

    let package = Package(
        name: "MyEmbeddingApp",
        platforms: [.iOS(.v18), .macOS(.v15)], // Or other relevant platforms
        products: [
            .library(
                name: "MyEmbeddingApp",
                targets: ["MyEmbeddingApp"]),
        ],
        dependencies: [
            .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.0.1"), // Use the latest version
        ],
        targets: [
            .target(
                name: "MyEmbeddingApp",
                dependencies: [
                    .product(name: "MLX", package: "mlx-swift"),
                    .product(name: "MLXNN", package: "mlx-swift")
                ]),
        ]
    )
    */

    @available(iOS 18.0, *)
    actor EmbeddingService {
        private var model: TextEmbeddingModel // The MLX model
        private var embeddingCache: [String: MLXArray] = [:] // Local memory cache

        init(vocabularySize: Int, embeddingDimension: Int, outputDimension: Int) {
            self.model = TextEmbeddingModel(
                vocabularySize: vocabularySize,
                embeddingDimension: embeddingDimension,
                outputDimension: outputDimension
            )
            // It's good practice to 'warm up' the model by performing a dummy inference
            // to ensure MLX initializes its internal graph and allocates memory.
            let dummyInput = MLXArray.randomUniform(low: 0, high: Float(vocabularySize), [1, 5], type: .int32)
            _ = self.model(dummyInput).eval() // .eval() forces execution
        }

        func getEmbedding(for text: String, tokenizedInput: MLXArray) async throws -> MLXArray {
            if let cachedEmbedding = embeddingCache[text] {
                return cachedEmbedding
            }

            // Perform inference asynchronously
            // MLX operations are synchronous on the calling thread, but the actor
            // prevents blocking the main thread from *other* calls.
            let newEmbedding = self.model(tokenizedInput).eval() // .eval() to get the concrete result
            embeddingCache[text] = newEmbedding
            return newEmbedding
        }

        func clearCache() {
            embeddingCache.removeAll()
        }
    }
    