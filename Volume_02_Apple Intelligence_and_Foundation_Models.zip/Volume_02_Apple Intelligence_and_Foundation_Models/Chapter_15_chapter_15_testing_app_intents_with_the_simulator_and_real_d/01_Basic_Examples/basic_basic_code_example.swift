
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import AppIntents // Essential framework for defining app intents
import SwiftUI    // Potentially useful for DisplayRepresentation, though not strictly required for basic intent logic

// MARK: - 1. Define an AppEnum for Tag Types

/// An `AppEnum` provides a user-friendly, discoverable set of choices for an intent parameter.
/// This allows Siri and Shortcuts to present these options clearly to the user.
///
/// **Why AppEnum?**
/// - **Discoverability:** System interfaces can present these options to the user.
/// - **Type Safety:** Ensures valid, predefined tag types are used.
/// - **Localization:** `DisplayRepresentation` allows for localized names.
///
/// `@available(iOS 18.0, *)` is crucial as `AppIntents` and Apple Intelligence features
/// are primarily available from iOS 18.0 onwards.
@available(iOS 18.0, *)
enum TagType: String, AppEnum, CaseIterable, Identifiable {
    case invoice = "Invoice"
    case receipt = "Receipt"
    case contract = "Contract"
    case report = "Report"
    case personal = "Personal"

    /// Defines how the enum type is displayed to the user in system interfaces.
    static var typeDisplayRepresentation: TypeDisplayRepresentation {
        "Document Tag"
    }

    /// Provides all possible cases, required by `AppEnum` for discoverability.
    static var allCases: [TagType] = [.invoice, .receipt, .contract, .report, .personal]

    /// Conformance to `Identifiable` for SwiftUI compatibility and unique identification.
    var id: String { self.rawValue }

    /// Defines how each individual enum case is displayed to the user.
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(stringLiteral: self.rawValue)
    }
}

// MARK: - 2. Define the App Intent: AddTagToDocumentIntent

/// This `AppIntent` allows users to add a specific tag to a document identified by its ID.
///
/// **How it works:**
/// 1. **`AppIntent` Conformance:** Marks this struct as an actionable intent.
/// 2. **`title` & `description`:** Provide user-facing information about the intent.
/// 3. **`@Parameter`:** Defines inputs the intent expects from the user or system.
/// 4. **`perform()` method:** Contains the actual logic executed when the intent is triggered.
///
/// `@available(iOS 18.0, *)` ensures this intent is only compiled/used on compatible OS versions.
@available(iOS 18.0, *)
struct AddTagToDocumentIntent: AppIntent {
    /// The user-facing title for this intent. This is what appears in Siri suggestions,
    /// the Shortcuts app, and other system interfaces.
    static var title: LocalizedStringResource = "Add Tag to Document"

    /// A more detailed description of what this intent does. This helps users understand
    /// the purpose of the intent when browsing available actions.
    static var description: IntentDescription = "Adds a specified tag to a document in your management system."

    /// An optional system image name to represent the intent visually.
    static var systemImageName: String? = "tag.fill"

    // MARK: - Intent Parameters

    /// The unique identifier of the document to which the tag will be added.
    /// `@Parameter` is a property wrapper that makes `documentID` an input for the intent.
    /// The `title` and `description` here are for the parameter itself, guiding the user
    /// when configuring the intent in Shortcuts or interacting with Siri.
    @Parameter(title: "Document ID", description: "The unique identifier of the document.")
    var documentID: String

    /// The type of tag to add to the document, using our predefined `TagType` enum.
    /// The system will automatically provide a picker for `TagType` values.
    @Parameter(title: "Tag Type", description: "The category or type of tag to apply.")
    var tag: TagType

    // MARK: - Initializers

    /// A default initializer is required by `AppIntent`.
    /// This is used by the system when constructing an instance of your intent.
    init() { }

    /// A custom initializer to allow programmatic creation of the intent with specific parameters.
    /// This is useful for testing or for creating intents from within your app.
    init(documentID: String, tag: TagType) {
        self.documentID = documentID
        self.tag = tag
    }

    // MARK: - The perform method

    /// This is the heart of the intent, where the actual action logic resides.
    /// When a user triggers this intent (e.g., via Siri or a Shortcut), this method is called.
    ///
    /// - Returns: An `IntentResult` which provides feedback to the user (e.g., a dialog message).
    /// - Throws: An error if the operation fails, which the system can then report to the user.
    ///
    /// **Under the Hood:**
    /// - This method is `async` because intent actions often involve asynchronous operations
    ///   like network requests, database access, or interactions with machine learning models.
    /// - `some IntentResult` means the method returns a type conforming to `IntentResult`,
    ///   allowing flexibility in the specific result type (e.g., `Result`, `ConfirmationResult`).
    func perform() async throws -> some IntentResult {
        // In a real Document Management App, this is where you would integrate with your
        // app's data model or backend services.
        // For example:
        // `await DocumentManager.shared.addTag(tag, toDocumentWithID: documentID)`
        // You might also perform validation here, e.g., checking if the documentID exists.

        print("--- Executing AddTagToDocumentIntent ---")
        print("  Attempting to add tag '\(tag.displayRepresentation.string())' to document ID: \(documentID)")

        // Simulate a delay for a network or database operation.
        try await Task.sleep(for: .seconds(0.5))

        // For this example, we'll just print a success message.
        // In a real app, you would check the actual success/failure of the `addTag` operation.
        let success = true // Assume success for demonstration

        if success {
            print("  Successfully processed: Tag '\(tag.displayRepresentation.string())' added to document '\(documentID)'.")
            // Return a successful result with a dialog message for the user.
            return .result(
                dialog: "Successfully added \(tag.displayRepresentation.string()) tag to document \(documentID)."
            )
        } else {
            print("  Failed to add tag: Document ID '\(documentID)' not found or other error.")
            // Return a failure result. You could also throw a specific error.
            throw IntentError.documentNotFound(documentID: documentID)
        }
    }
}

// MARK: - 3. Define an AppShortcutsProvider

/// An `AppShortcutsProvider` makes your intents discoverable by the Shortcuts app and Siri.
/// Without this, users cannot easily add your intent to their personal shortcuts or trigger
/// it via voice.
///
/// **Why AppShortcutsProvider?**
/// - **Siri Integration:** Allows users to trigger the intent with custom voice phrases.
/// - **Shortcuts App:** Makes the intent available as an action block in the Shortcuts app.
/// - **System Suggestions:** Helps the system proactively suggest your intent to users
///   based on their habits and context.
///
/// `@available(iOS 18.0, *)` is required.
@available(iOS 18.0, *)
struct DocumentAppShortcuts: AppShortcutsProvider {
    /// Defines the list of `AppShortcut`s that your app provides.
    /// Each `AppShortcut` links an `AppIntent` to user-facing phrases and metadata.
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: AddTagToDocumentIntent(), // The intent this shortcut will trigger
            phrases: [
                "Add \(.parameter(\.$tag)) tag to document \(.parameter(\.$documentID)) in \(.applicationName)",
                "Tag document \(.parameter(\.$documentID)) as \(.parameter(\.$tag)) in \(.applicationName)",
                "Apply \(.parameter(\.$tag)) to \(.parameter(\.$documentID)) using \(.applicationName)"
            ],
            shortTitle: "Tag Document", // A concise title for the shortcut
            systemImageName: "tag.fill"  // An icon for the shortcut
        )
    }
}

// MARK: - 4. Custom Error Type (for demonstration)

/// A simple custom error type to demonstrate error handling within the `perform` method.
enum IntentError: LocalizedError {
    case documentNotFound(documentID: String)
    case tagOperationFailed(reason: String)

    var errorDescription: String? {
        switch self {
        case .documentNotFound(let id):
            return "Document with ID '\(id)' could not be found."
        case .tagOperationFailed(let reason):
            return "Failed to add tag: \(reason)"
        }
    }
}

// MARK: - Conceptual Demonstration of Intent Invocation

/// This function demonstrates how an intent *could* be invoked programmatically for testing
/// or internal app logic. In a real-world scenario, the system (Siri, Shortcuts) would
/// be responsible for instantiating and calling `perform()`.
///
/// **Note:** Running this in a simple Swift Playground might not fully simulate the `AppIntents`
/// environment, but it shows the structure and how parameters are passed.
@available(iOS 18.0, *)
func demonstrateIntentInvocation() {
    print("\n--- Conceptual Intent Invocation Demonstration ---")

    // 1. Create an instance of the intent with specific parameters.
    // These parameters would typically be derived from user input (voice, text)
    // or from a configured shortcut.
    let intentToPerform = AddTagToDocumentIntent(documentID: "DOC-2024-005", tag: .contract)

    print("Intent created: \(AddTagToDocumentIntent.title)")
    print("  Document ID: \(intentToPerform.documentID)")
    print("  Tag Type: \(intentToPerform.tag.displayRepresentation.string())")

    // 2. Simulate the system calling the `perform()` method.
    // In a real scenario, this `Task` would be managed by the AppIntents framework.
    Task {
        do {
            let result = try await intentToPerform.perform()

            // 3. Process the result. The system would use this to provide feedback.
            if let dialog = result.dialog {
                print("System Feedback Dialog: \"\(dialog.localizedString)\"")
            }
            // Other result types like `ConfirmationResult` could also be handled.

        } catch let error as IntentError {
            print("Intent failed with custom error: \(error.localizedDescription)")
        } catch {
            print("Intent failed with unexpected error: \(error.localizedDescription)")
        }
    }

    // Demonstrate another intent that might fail (e.g., document not found)
    let failingIntent = AddTagToDocumentIntent(documentID: "NON-EXISTENT-DOC", tag: .personal)
    Task {
        do {
            // To simulate failure, we'll modify the perform method temporarily
            // or rely on a more complex mock. For this example, let's assume
            // the `perform` method's `success` flag would be `false` for this ID.
            // (The current `perform` method always succeeds for simplicity, but
            // a real implementation would check the `documentID`.)
            _ = try await failingIntent.perform()
        } catch let error as IntentError {
            print("\nSimulated failure for 'NON-EXISTENT-DOC': \(error.localizedDescription)")
        } catch {
            print("\nSimulated failure for 'NON-EXISTENT-DOC' with unexpected error: \(error.localizedDescription)")
        }
    }

    print("--- End of Conceptual Intent Invocation ---")
}

// To run this demonstration in a Playground or an application:
// Make sure your target's deployment info is set to iOS 18.0 or macOS 15.0 or later.
// demonstrateIntentInvocation()
