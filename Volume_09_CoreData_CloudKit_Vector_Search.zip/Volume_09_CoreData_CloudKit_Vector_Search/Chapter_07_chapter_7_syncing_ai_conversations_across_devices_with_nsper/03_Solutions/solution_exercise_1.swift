
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreData

// Note: In a real app, these changes are primarily made in the .xcdatamodeld editor.
// This code demonstrates the resulting Managed Object structure and the logic 
// required to maintain compatibility.

@objc(AIConversation)
public class AIConversation: NSManagedObject {
    @NSManaged public var id: UUID // Should have a default value in Model Editor: UUID()
    @NSManaged public var title: String? // Refactored to Optional
    @NSManaged public var createdAt: Date? // Refactored to Optional with default: Date()
    @NSManaged public var isArchived: Bool // Refactored to have default: false
    @NSManaged public var messages: NSSet? // Relationship: Nullify rule
}

@objc(Message)
public class Message: NSManagedObject {
    @NSManaged public var text: String? // Refactored to Optional
    @NSManaged public var role: String? // Refactored to Optional (e.g., "user")
    @NSManaged public var timestamp: Date? // Refactored to Optional with default: Date()
    @NSManaged public var conversation: AIConversation? // Relationship: Nullify rule (Changed from Deny)
}

// Implementation logic for safe creation
extension AIConversation {
    static func create(in context: NSManagedObjectContext, title: String) -> AIConversation {
        let conversation = AIConversation(context: context)
        conversation.id = UUID()
        conversation.title = title
        conversation.createdAt = Date()
        conversation.isArchived = false
        return conversation
    }
}
