
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct CompilerTool: Tool {
    let name = "compile_swift_code"
    let description = "Compiles Swift code. Returns 'Success' or a detailed error message."

    func execute(arguments: [String: AnySendable]) async throws -> String {
        guard let code = arguments["code"]?.asString() else {
            return "Error: No code provided."
        }
        
        // Mock Compiler Logic
        // 1. Must contain a function
        if !code.contains("func ") {
            return "Compile Error: Expected function definition (missing 'func')."
        }
        
        // 2. Must have closing brace
        if !code.contains("}") {
            return "Compile Error: Expected '}' at end of file."
        }
        
        // 3. Must use 'Int' for a specific requirement
        if code.contains("return 3.14") && !code.contains("Double") {
            return "Compile Error: Type mismatch. Cannot return Double in an Int function."
        }
        
        return "Success: Code compiled without errors."
    }
}

@available(iOS 18.0, *)
actor CodeArchitectAgent {
    private let compiler = CompilerTool()
    
    func solve(requirement: String) async -> String {
        print("🤖 Agent: Starting task -> \(requirement)")
        
        // The Agent's internal state for the loop
        var currentCode = ""
        var attempts = 0
        let maxAttempts = 3
        
        // The ReAct Loop: Reasoning -> Acting -> Observing -> Correcting
        while attempts < maxAttempts {
            attempts += 1
            print("\n--- Attempt \(attempts) ---")
            
            // 1. Thought & Generation (Simulated LLM)
            currentCode = generateCode(for: requirement, attempt: attempts)
            print("🤔 Thought: I will write the code.")
            print("📝 Generated Code:\n\(currentCode)")
            
            // 2. Action: Compile
            print("🛠 Action: Compiling...")
            let observation = try? await compiler.execute(arguments: ["code": AnySendable(currentCode)])
            
            // 3. Observation & Decision
            if let obs = observation, obs.contains("Success") {
                print("✅ Observation: \(obs)")
                return "Final Code:\n\(currentCode)"
            } else {
                print("❌ Observation: \(observation ?? "Unknown Error")")
                print("🤔 Thought: The compiler failed. I must fix the syntax/types.")
            }
        }
        
        return "Failed to generate working code after \(maxAttempts) attempts."
    }
    
    /// Simulates an LLM that learns from previous errors
    private func generateCode(for requirement: String, attempt: Int) -> String {
        switch attempt {
        case 1:
            // Error 1: Missing 'func'
            return "let fib = (n: Int) -> Int { return 1 }"
        case 2:
            // Error 2: Missing '}'
            return "func fib(n: Int) -> Int { return 1"
        case 3:
            // Success
            return "func fib(n: Int) -> Int { return 1 }"
        default:
            return ""
        }
    }
}

// --- Execution ---
@main
struct CompilerAgentApp {
    static func main() async {
        let agent = CodeArchitectAgent()
        
        // Use a TaskGroup to demonstrate structured concurrency / cancellation
        await withTaskGroup(of: Void.self) { group in
            group.addTask {
                let result = await agent.solve(requirement: "Write a Fibonacci function.")
                print("\n========================================")
                print(result)
                print("========================================\n")
            }
        }
    }
}
