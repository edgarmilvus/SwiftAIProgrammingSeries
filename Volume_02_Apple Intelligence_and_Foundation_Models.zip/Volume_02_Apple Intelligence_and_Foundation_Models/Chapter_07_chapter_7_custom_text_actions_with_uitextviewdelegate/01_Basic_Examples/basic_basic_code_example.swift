
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit

// --- Real-world Context: A Simple Note-Taking App ---
// Imagine a basic note-taking app where users can write and edit text.
// We want to enhance the user experience by adding a custom action
// to the text selection menu: "Reverse Text". This action will take
// the currently selected text and replace it with its reversed version.
// This example illustrates the core mechanics of using UITextViewDelegate
// to customize the text editing menu, a fundamental skill for integrating
// advanced features like Apple Intelligence into text-based applications.

/// A `UIViewController` that displays a `UITextView` and demonstrates
/// how to add a custom action to the text selection edit menu.
/// It conforms to `UITextViewDelegate` to intercept and customize
/// the menu presented when text is selected.
@available(iOS 17.0, *) // The 'editMenuForTextRange' delegate method is available from iOS 17.0.
class NoteEditorViewController: UIViewController, UITextViewDelegate {

    // MARK: - UI Elements

    /// The `UITextView` where the user can input and edit text.
    /// It's configured to be editable and selectable, allowing for text selection.
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false // Enable Auto Layout
        textView.font = UIFont.preferredFont(forTextStyle: .body) // Use dynamic type for accessibility
        textView.isEditable = true // Allow user input
        textView.isSelectable = true // Allow text selection
        textView.text = "Hello, Apple Intelligence! Select some text here to see the custom action."
        textView.backgroundColor = .systemBackground
        textView.textColor = .label
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        return textView
    }()

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Custom Text Actions"
        view.backgroundColor = .systemGroupedBackground

        // 1. Add the UITextView to the view hierarchy.
        // This makes the textView visible and interactive within our view controller.
        view.addSubview(textView)

        // 2. Set up Auto Layout constraints for the UITextView.
        // These constraints position the textView within the safe area of the view.
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 200) // A fixed height for demonstration purposes
        ])

        // 3. Assign the delegate. This is a CRUCIAL step.
        // By setting 'textView.delegate = self', we inform the textView that
        // 'NoteEditorViewController' is responsible for handling its delegate methods.
        // Without this, the 'textView(_:editMenuForTextRange:suggestedActions:)' method
        // (and any other delegate methods) will not be called.
        textView.delegate = self
    }

    // MARK: - UITextViewDelegate

    /// This delegate method is invoked by the system when the edit menu (context menu)
    /// is about to be displayed for a selected text range within the `UITextView`.
    /// It provides an opportunity to customize the menu by adding, removing, or reordering actions.
    ///
    /// - Parameters:
    ///   - textView: The `UITextView` instance that is requesting the edit menu.
    ///   - textRange: A `UITextRange` object representing the currently selected text.
    ///                This is essential for identifying which part of the text the action should apply to.
    ///   - suggestedActions: An array of `UIAction` objects that the system would
    ///     normally suggest for the given text range (e.g., Cut, Copy, Paste).
    /// - Returns: A `UIMenu` object containing all the `UIAction`s you want to display.
    ///            Return `nil` if you want to completely suppress the edit menu.
    func textView(_ textView: UITextView, editMenuForTextRange textRange: UITextRange, suggestedActions: [UIAction]) -> UIMenu? {

        // Ensure there's actual selected text to perform an action on.
        // If 'textRange' is invalid or represents an empty selection, we might
        // choose to return the default menu or even 'nil' to hide it.
        guard let selectedText = textView.text(in: textRange) else {
            // If no text is selected, or textRange is invalid, simply return the default menu.
            // This ensures standard actions are still available even without a selection.
            return UIMenu(children: suggestedActions)
        }

        // 4. Create a custom UIAction for reversing the selected text.
        // A `UIAction` encapsulates a single menu item, including its title,
        // an optional SF Symbol image, and the code block to execute when tapped.
        let reverseAction = UIAction(title: "Reverse Text", image: UIImage(systemName: "arrow.left.arrow.right")) { [weak self] _ in
            // Use '[weak self]' to prevent a retain cycle, as the closure captures 'self'.
            guard let self = self else { return } // Safely unwrap self

            // Retrieve the current full text of the textView and the selected range.
            guard let currentText = textView.text,
                  let range = Range(textRange, in: currentText) else { return }

            // Perform the core logic: reverse the selected text.
            let reversedSelectedText = String(selectedText.reversed())

            // Replace the original selected text with the reversed text.
            // Using 'textStorage.replaceCharacters' is generally preferred for
            // text manipulation in UITextView, especially when dealing with
            // attributed strings or wanting robust undo/redo support.
            if let swiftRange = Range(textRange, in: textView.textStorage.string) {
                textView.textStorage.replaceCharacters(in: swiftRange, with: reversedSelectedText)
            }

            // Optional: Deselect the text after the action is performed for a cleaner UX.
            textView.selectedTextRange = nil

            // In a real-world Apple Intelligence scenario, this is where you'd
            // trigger an on-device LLM call, update a data model, or log the action.
            print("Action Performed: Reversed text from '\(selectedText)' to '\(reversedSelectedText)'")
        }

        // 5. Combine the system's suggested actions with our custom action.
        // We create a new `UIMenu` object. This menu will be displayed to the user.
        // We place our custom action first for prominence.
        // `UIMenu(options: .displayInline, children: suggestedActions)` ensures
        // the default system actions (Copy, Paste, etc.) are displayed directly
        // in the main menu, rather than being nested in a submenu, providing a
        // seamless integration.
        let menu = UIMenu(title: "", children: [
            reverseAction, // Our custom action
            UIMenu(options: .displayInline, children: suggestedActions) // System's default actions
        ])

        // 6. Return the customized menu.
        // The system will now present this 'menu' to the user.
        return menu
    }
}

// MARK: - Previews (for SwiftUI previews, if applicable)
// This section allows you to preview your UIKit ViewController in Xcode's canvas.
// It's typically placed in a separate file (e.g., 'NoteEditorViewController+Previews.swift')
// in a real project, but included here for completeness.
#if DEBUG
import SwiftUI

@available(iOS 17.0, *)
struct NoteEditorViewController_Preview: PreviewProvider {
    static var previews: some View {
        // Embed the UIKit view controller in a SwiftUI container for previewing.
        UIViewControllerPreview {
            NoteEditorViewController()
        }
        .edgesIgnoringSafeArea(.all) // Use this if your UIKit view controller manages its own safe area
        .previewDisplayName("Note Editor with Custom Action")
    }
}

// Helper struct to bridge UIKit ViewControllers to SwiftUI Previews
@available(iOS 13.0, *)
struct UIViewControllerPreview<ViewController: UIViewController>: UIViewControllerRepresentable {
    let viewController: ViewController

    init(_ builder: @escaping () -> ViewController) {
        self.viewController = builder()
    }

    // MARK: - UIViewControllerRepresentable Protocol Methods
    func makeUIViewController(context: Context) -> ViewController {
        // Creates and returns the UIKit view controller instance.
        viewController
    }

    func updateUIViewController(_ uiViewController: ViewController, context: Context) {
        // This method is called when the SwiftUI view updates.
        // For this simple example, no update logic is necessary.
    }
}
#endif
