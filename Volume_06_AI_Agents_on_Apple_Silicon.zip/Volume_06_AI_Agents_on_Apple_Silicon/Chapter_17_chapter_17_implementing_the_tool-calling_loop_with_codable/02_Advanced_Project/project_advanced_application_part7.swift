
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

// MARK: - OllamaKit Chat Message Definitions (Simplified for demonstration)

/// Simplified `ChatMessages` and `ToolOutput` for `OllamaKit` interaction.
/// In a real project, these would come directly from `OllamaKit`.
@available(macOS 15.0, *)
extension LLMAgent {
    struct ToolOutput: Codable {
        let toolCallId: String
        let content: String

        enum CodingKeys: String, CodingKey {
            case toolCallId = "tool_call_id"
            case content
        }
    }

    struct ChatMessages: Codable {
        let role: ChatRole
        var content: String?
        var toolCalls: [SmartHomeTools.ToolCall]? // LLM's suggested tool calls
        var toolOutputs: [ToolOutput]? // Results of tool execution

        enum CodingKeys: String, CodingKey {
            case role, content
            case toolCalls = "tool_calls"
            case toolOutputs = "tool_outputs"
        }

        init(role: ChatRole, content: String? = nil, toolCalls: [SmartHomeTools.ToolCall]? = nil, toolOutputs: [ToolOutput]? = nil) {
            self.role = role
            self.content = content
            self.toolCalls = toolCalls
            self.toolOutputs = toolOutputs
        }
    }

    enum ChatRole: String, Codable {
        case system, user, assistant, tool
    }
}
