
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage
import CoreData

@available(iOS 18.0, *)
actor EmbeddingService: Sendable {
    private let embeddingModel = NLEmbedding.sentenceEmbedding(for: .english)

    /// Generates a [Float] vector from text and converts it to Data for storage.
    func generateAndConvert(for text: String) throws -> Data {
        guard let embeddingModel = embeddingModel,
              let vector = embeddingModel.vector(for: text) else {
            throw EmbeddingError.generationFailed
        }
        
        return convertToData(vector)
    }

    /// Converts a Float array into a raw byte buffer (Data).
    func convertToData(_ vector: [Float]) -> Data {
        return vector.withUnsafeBytes { Data($0) }
    }

    /// Reconstructs a Float array from stored Data.
    func convertFromData(_ data: Data) -> [Float] {
        return data.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
    }

    enum EmbeddingError: Error {
        case generationFailed
    }
}

// Usage in a Repository/ViewModel context
@available(iOS 18.0, *)
struct MessageRepository {
    let embeddingService = EmbeddingService()
    let context: NSManagedObjectContext

    func enrichMessageWithEmbedding(message: Message) async throws {
        let text = message.text
        let data = try await embeddingService.generateAndConvert(for: text)
        
        // Perform the save on the context's private queue
        try await context.perform {
            message.embedding = data // Assuming 'embedding' is a Data attribute in Core Data
            try context.save()
        }
    }
}
