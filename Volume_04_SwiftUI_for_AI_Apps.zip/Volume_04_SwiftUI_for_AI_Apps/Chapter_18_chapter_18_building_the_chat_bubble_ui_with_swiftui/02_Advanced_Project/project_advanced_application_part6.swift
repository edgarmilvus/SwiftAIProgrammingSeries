
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

/// A `ViewModel` responsible for managing the chat state, user input,
/// and interacting with the simulated AI service for streaming responses.
@available(iOS 17.0, *)
class StreamingChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isLoadingAIResponse: Bool = false
    @Published var errorMessage: String?
    
    private let aiService = AIServiceSimulator()
    
    /// Sends a user message and initiates an AI response.
    /// - Parameter text: The text content of the user's message.
    func sendMessage(text: String) {
        // Add user message to the chat
        let userMessage = ChatMessage(text: text, isUserMessage: true)
        messages.append(userMessage)
        
        // Clear any previous error message
        errorMessage = nil
        
        // Simulate AI thinking time
        isLoadingAIResponse = true
        
        // Start processing AI response in a detached task
        Task {
            // Give a slight delay to simulate network round trip for the initial request
            try await Task.sleep(for: .milliseconds(500))
            await processAIResponse(for: text)
        }
    }
    
    /// Processes the AI response by subscribing to the token stream and updating the UI.
    /// - Parameter userQuery: The user's query that prompted this AI response.
    @MainActor // Ensure all UI updates happen on the main actor
    private func processAIResponse(for userQuery: String) async {
        let aiMessageID = UUID()
        var aiMessage = ChatMessage(id: aiMessageID, isUserMessage: false, isStreaming: true)
        messages.append(aiMessage) // Add a placeholder AI message
        
        isLoadingAIResponse = false // AI has started responding
        
        // Determine if this query should trigger a tool call suggestion
        let shouldSuggestToolCall = userQuery.lowercased().contains("weather")
        let toolCall: ToolCallSuggestion? = shouldSuggestToolCall ? .exampleWeather : nil
        
        do {
            // Iterate over the async stream of message content
            for try await contentPart in aiService.simulateAITokenStream(
                fullResponse: generateAIResponseText(for: userQuery),
                toolCall: toolCall
            ) {
                // Find the AI message and append the new content
                if let index = messages.firstIndex(where: { $0.id == aiMessageID }) {
                    if case .text(let newChar) = contentPart {
                        // If it's a text token, append to the last text block or create a new one
                        if let lastContentIndex = messages[index].content.lastIndex(where: {
                            if case .text(_) = $0 { return true } else { return false }
                        }), case .text(var existingText) = messages[index].content[lastContentIndex] {
                            existingText += newChar
                            messages[index].content[lastContentIndex] = .text(existingText)
                        } else {
                            // No existing text block, add a new one
                            messages[index].content.append(.text(newChar))
                        }
                    } else {
                        // For non-text content (like tool calls), just append directly
                        messages[index].content.append(contentPart)
                    }
                }
            }
            
            // Stream finished, mark message as no longer streaming
            if let index = messages.firstIndex(where: { $0.id == aiMessageID }) {
                messages[index].isStreaming = false
            }
            
        } catch {
            // Handle any errors from the streaming service
            if let index = messages.firstIndex(where: { $0.id == aiMessageID }) {
                messages[index].isStreaming = false
                messages[index].content.append(.text("\n(Error: \(error.localizedDescription))"))
            }
            errorMessage = "Failed to get AI response: \(error.localizedDescription)"
            print("Error during AI stream: \(error)")
        }
    }
    
    /// Generates a sample AI response text based on the user's query.
    private func generateAIResponseText(for query: String) -> String {
        if query.lowercased().contains("weather") {
            return "The current weather in Cupertino is sunny with a temperature of 25°C. "
        } else if query.lowercased().contains("hello") {
            return "Hello there! How can I assist you today?"
        } else if query.lowercased().contains("time") {
            let formatter = DateFormatter()
            formatter.timeStyle = .short
            return "The current time is \(formatter.string(from: Date()))."
        } else {
            return "I'm still learning, but I can tell you that the future of AI is exciting!"
        }
    }
    
    /// Placeholder for actual tool call execution.
    /// - Parameter toolCall: The `ToolCallSuggestion` to execute.
    func performToolCall(_ toolCall: ToolCallSuggestion) {
        print("Executing tool call: \(toolCall.name) with parameters: \(toolCall.parameters)")
        // In a real app, this would trigger an API call or local function.
        // For demonstration, we'll add a response message.
        Task { @MainActor in
            let responseText = "Tool '\(toolCall.name)' executed successfully. Results will be displayed soon."
            messages.append(ChatMessage(text: responseText, isUserMessage: false))
        }
    }
    
    /// Handles declining a tool call.
    /// - Parameter toolCall: The `ToolCallSuggestion` that was declined.
    func declineToolCall(_ toolCall: ToolCallSuggestion) {
        print("Declined tool call: \(toolCall.name)")
        Task { @MainActor in
            let responseText = "You declined the suggestion to '\(toolCall.name)'. How else can I help?"
            messages.append(ChatMessage(text: responseText, isUserMessage: false))
        }
    }
}
