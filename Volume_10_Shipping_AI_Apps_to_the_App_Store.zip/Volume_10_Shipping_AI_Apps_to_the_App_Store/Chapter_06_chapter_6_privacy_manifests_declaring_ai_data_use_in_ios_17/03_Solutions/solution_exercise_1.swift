
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// An actor to ensure thread-safe access to AI configuration settings.
/// Using Swift 6 concurrency to manage state and prevent data races.
@available(iOS 17.0, *)
actor AIConfigurationManager {
    private let defaults = UserDefaults.standard
    private let promptKey = "com.llamalite.systemPrompt"
    private let tempKey = "com.llamalite.temperature"

    /// Saves the system prompt used to guide the LLM's behavior.
    func saveSystemPrompt(_ prompt: String) {
        defaults.set(prompt, forKey: promptKey)
    }

    /// Retrieves the system prompt.
    func fetchSystemPrompt() -> String {
        return defaults.string(forKey: promptKey) ?? "You are a helpful assistant."
    }

    /// Saves the temperature setting (0.0 to 1.0).
    func saveTemperature(_ value: Float) {
        defaults.set(value, forKey: tempKey)
    }

    /// Retrieves the temperature setting.
    func fetchTemperature() -> Float {
        return defaults.float(forKey: tempKey)
    }
}

/*
// PrivacyInfo.xcprivacy (Representation)
// ---------------------------------------------------------
// <key>NSPrivacyAccessedAPITypes</key>
// <array>
//    <dict>
//        <key>NSPrivacyAccessedAPIType</key>
//        <string>NSPrivacyAccessedAPITypeUserDefaults</string>
//        <key>NSPrivacyAccessedAPITypeReasons</key>
//        <array>
//            <string>CA92.1</string> // Reason: To store user-specific application settings
//        </array>
//    </dict>
// </array>
*/
