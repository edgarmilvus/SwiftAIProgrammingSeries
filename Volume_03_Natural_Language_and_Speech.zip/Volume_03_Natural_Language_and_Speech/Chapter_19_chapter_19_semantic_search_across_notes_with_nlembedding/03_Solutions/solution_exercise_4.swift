
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
struct NewsArticle: Identifiable, Hashable {
    let id: UUID
    let title: String
    let body: String
}

@available(iOS 18.0, macOS 15.0, *)
class NewsCategorizer {
    // Stores predefined category names and their semantic centroid embeddings
    private var categoryCentroids: [String: NLEmbedding.Vector] = [:]
    // NLTokenizer for splitting article content into sentences for document embedding
    private let tokenizer = NLTokenizer(unit: .sentence)

    init() {
        // Define categories with descriptive texts to generate robust centroid embeddings
        let categories = [
            "Technology": "latest advancements in software and hardware, artificial intelligence, gadgets, programming, cybersecurity, internet trends, new product launches, innovation, data science, machine learning, robotics, startups",
            "Politics": "government, elections, legislation, international relations, public policy, political figures, diplomacy, campaigns, debates, policy reform, democracy, social issues, human rights",
            "Sports": "football, basketball, soccer, olympics, athletic events, team news, athlete performance, championships, scores, tournaments, training, fitness, sportsmanship, leagues",
            "Finance": "stock market, economy, investments, banking, personal finance, cryptocurrency, business news, market trends, inflation, interest rates, mergers, acquisitions, financial technology",
            "Health": "medical research, wellness, public health, fitness, nutrition, disease prevention, healthcare policy, mental health, pharmaceuticals, clinical trials, epidemiology, healthy lifestyle"
        ]

        for (categoryName, description) in categories {
            if let embedding = generateDocumentEmbedding(for: description) {
                categoryCentroids[categoryName] = embedding
            } else {
                print("Failed to generate centroid for category: \(categoryName)")
            }
        }
    }

    /// Generates a document embedding by averaging sentence embeddings within the text.
    /// This method is reused for both category centroids and news articles.
    private func generateDocumentEmbedding(for text: String) -> NLEmbedding.Vector? {
        tokenizer.string = text
        var sentenceEmbeddings: [NLEmbedding.Vector] = []
        
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
            let sentence = String(text[tokenRange])
            if let embedding = NLEmbedding.embedding(for: sentence, language: .english) {
                sentenceEmbeddings.append(embedding)
            }
            return true
        }

        guard !sentenceEmbeddings.isEmpty else { return nil }
        return sentenceEmbeddings.reduce(NLEmbedding.Vector.zero) { $0 + $1 } / Double(sentenceEmbeddings.count)
    }

    /// Assigns a news article to the most semantically similar category.
    /// - Parameter article: The `NewsArticle` to categorize.
    /// - Returns: A tuple containing the assigned category name and the distance to its centroid, or nil if categorization fails.
    func assignCategory(for article: NewsArticle) async -> (category: String, distance: Double)? {
        // Combine title and body to get a comprehensive representation of the article
        let combinedContent = "\(article.title). \(article.body)"
        guard let articleEmbedding = generateDocumentEmbedding(for: combinedContent) else {
            print("Failed to generate embedding for article: \(article.title)")
            return nil
        }

        var closestCategory: String?
        var minDistance: Double = .greatestFiniteMagnitude // Initialize with a very large distance

        // Compare the article's embedding to each category centroid
        for (categoryName, centroidEmbedding) in categoryCentroids {
            let distance = NLEmbedding.distance(between: articleEmbedding, and: centroidEmbedding)
            if distance < minDistance {
                minDistance = distance
                closestCategory = categoryName
            }
        }

        if let category = closestCategory {
            return (category: category, distance: minDistance)
        } else {
            return nil
        }
    }
}

// Example Usage (in an async context)
/*
@available(iOS 18.0, macOS 15.0, *)
func demonstrateNewsCategorization() async {
    let categorizer = NewsCategorizer()

    print("--- News Categorization Demo ---")

    let article1 = NewsArticle(
        id: UUID(),
        title: "Apple Unveils New AI Features for iOS 18",
        body: "During its annual WWDC keynote, Apple showcased a suite of new artificial intelligence capabilities coming to its mobile operating system, focusing on on-device processing and privacy. New Siri features and enhanced photo editing tools were highlighted. Developers are excited about the machine learning APIs."
    )

    let article2 = NewsArticle(
        id: UUID(),
        title: "Global Leaders Discuss Climate Change at Summit",
        body: "Heads of state convened in Geneva to address the pressing issue of climate change, proposing new international agreements and funding mechanisms to combat rising global temperatures and extreme weather events. Diplomacy and public policy were key topics."
    )
    
    let article3 = NewsArticle(
        id: UUID(),
        title: "Local Team Wins Championship in Dramatic Fashion",
        body: "The city's beloved baseball team clinched the national title in a thrilling extra-innings game, sparking celebrations across the region. The star pitcher delivered a career-best performance. Fans celebrated the athletic achievement."
    )

    let article4 = NewsArticle(
        id: UUID(),
        title: "Stock Market Rebounds Amidst Economic Optimism",
        body: "Investors are showing renewed confidence as key economic indicators suggest a strong recovery. Tech stocks led the gains, and analysts predict continued growth in the financial sector. Personal finance tips were also shared."
    )
    
    let article5 = NewsArticle(
        id: UUID(),
        title: "Breakthrough in Cancer Research Announced",
        body: "Scientists have reported a significant discovery in the fight against a rare form of cancer, offering new hope for patients. The medical research involved extensive clinical trials and advanced pharmaceutical development."
    )

    if let result1 = await categorizer.assignCategory(for: article1) {
        print("Article 1 ('\(article1.title)') categorized as: \(result1.category) (Distance: \(String(format: "%.4f", result1.distance)))")
    }
    if let result2 = await categorizer.assignCategory(for: article2) {
        print("Article 2 ('\(article2.title)') categorized as: \(result2.category) (Distance: \(String(format: "%.4f", result2.distance)))")
    }
    if let result3 = await categorizer.assignCategory(for: article3) {
        print("Article 3 ('\(article3.title)') categorized as: \(result3.category) (Distance: \(String(format: "%.4f", result3.distance)))")
    }
    if let result4 = await categorizer.assignCategory(for: article4) {
        print("Article 4 ('\(article4.title)') categorized as: \(result4.category) (Distance: \(String(format: "%.4f", result4.distance)))")
    }
    if let result5 = await categorizer.assignCategory(for: article5) {
        print("Article 5 ('\(article5.title)') categorized as: \(result5.category) (Distance: \(String(format: "%.4f", result5.distance)))")
    }
    // Expected outputs: Technology, Politics, Sports, Finance, Health
}

// To run this example, embed it in a Task:
// Task { await demonstrateNewsCategorization() }
*/
