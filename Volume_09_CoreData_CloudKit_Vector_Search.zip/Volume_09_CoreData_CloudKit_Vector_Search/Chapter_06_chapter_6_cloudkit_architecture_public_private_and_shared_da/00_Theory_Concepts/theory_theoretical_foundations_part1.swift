
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CloudKit
import Foundation

/// An actor-based manager to handle CloudKit operations safely in a concurrent environment.
/// This ensures that all database interactions are isolated, preventing data races
/// when the AI agent is performing background semantic indexing.
@available(iOS 18.0, *)
actor CloudKitMemoryManager {
    private let container: CKContainer
    private let privateDatabase: CKDatabase
    
    init(containerIdentifier: String) {
        self.container = CKContainer(identifier: containerIdentifier)
        self.privateDatabase = container.privateCloudDatabase
    }
    
    /// Fetches a specific semantic record from the private database.
    /// - Parameter recordID: The unique identifier for the memory record.
    /// - Returns: A Sendable CKRecord if found.
    func fetchPersonalMemory(with recordID: CKRecord.ID) async throws -> CKRecord {
        // Using Swift 6's structured concurrency to perform the fetch.
        // The 'await' keyword suspends the actor, allowing other tasks to run 
        // while waiting for the network I/O.
        let record = try await privateDatabase.record(for: recordID)
        return record
    }
    
    /// Saves a new vector embedding record to a custom zone.
    /// - Parameters:
    ///   - record: The CKRecord containing the embedding data.
    ///   - zoneID: The custom CKRecordZone.ID where the memory is stored.
    func saveMemory(_ record: CKRecord, in zoneID: CKRecordZone.ID) async throws {
        // In a real AI app, this record would contain a 'vector' field 
        // (stored as Data) and 'metadata' fields.
        try await privateDatabase.save(record)
    }
}

/// A model representing a piece of AI memory, conforming to Sendable 
/// to ensure it can be safely passed across actor boundaries.
struct AIMemoryRecord: Sendable {
    let id: CKRecord.ID
    let embedding: [Float]
    let textContent: String
    let timestamp: Date
}
