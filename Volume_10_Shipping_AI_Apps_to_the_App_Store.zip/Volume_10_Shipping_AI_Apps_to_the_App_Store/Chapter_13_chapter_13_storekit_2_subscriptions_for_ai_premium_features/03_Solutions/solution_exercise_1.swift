
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import StoreKit
import Foundation

/// Represents the granular subscription states for the AI assistant.
enum SubscriptionStatus: Sendable, Equatable {
    case free
    case pro
    case gracePeriod
}

/// The definitive authority on user entitlements.
/// Using an actor ensures thread-safety when accessed from UI or Networking layers.
@available(iOS 18.0, *)
actor EntitlementManager {
    private let proProductID = "com.lexiai.pro_subscription"
    
    // The single source of truth for the app's UI and logic.
    private(set) var status: SubscriptionStatus = .free
    
    /// Refreshes the local state by inspecting the current verified transactions.
    func refreshEntitlements() async {
        var newStatus: SubscriptionStatus = .free
        
        // Iterate through the asynchronous stream of current entitlements
        for await result in Transaction.currentEntitlements {
            // 1. Cryptographic Verification
            guard case .verified(let transaction) = result else {
                // If unverified, we treat it as invalid for security.
                continue
            }
            
            // 2. Product ID Filtering
            guard transaction.productID == proProductID else { continue }
            
            // 3. Expiration Logic (Hard Mode implementation)
            if let expirationDate = transaction.expirationDate {
                let now = Date()
                
                if expirationDate > now {
                    newStatus = .pro
                } else if expirationDate > now.addingTimeInterval(-86400) { 
                    // If expired within the last 24 hours, consider it a grace period
                    newStatus = .gracePeriod
                }
            } else {
                // Non-expiring products (like lifetime purchases)
                newStatus = .pro
            }
        }
        
        self.status = newStatus
    }
    
    /// Helper property for quick boolean checks in UI logic.
    var isProEnabled: Bool {
        status == .pro || status == .gracePeriod
    }
}
