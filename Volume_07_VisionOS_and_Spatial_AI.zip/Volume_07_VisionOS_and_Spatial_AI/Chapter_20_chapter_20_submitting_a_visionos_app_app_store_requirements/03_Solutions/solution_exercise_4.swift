
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import ARKit

enum SecurityLevel {
    case immersive // High-fidelity, spatial data available
    case windowed  // Standard windowed mode, no spatial data
    case locked    // Permissions denied, content hidden
}

@available(visionOS 1.0, *)
actor EnvironmentMonitor {
    private(set) var isARKitAvailable: Bool = false
    private(set) var permissionsGranted: Bool = false
    
    /// Checks the environment capabilities asynchronously
    func monitorEnvironment() async -> SecurityLevel {
        // Simulate checking ARKit and entitlements
        try? await Task.sleep(for: .seconds(1))
        
        // In a real app, we'd check ARKitSession.capabilities
        isARKitAvailable = true 
        permissionsGranted = true // This would be toggled by a permission observer
        
        if isARKitAvailable && permissionsGranted {
            return .immersive
        } else if isARKitAvailable && !permissionsGranted {
            return .locked
        } else {
            return .windowed
        }
    }
    
    func updatePermissions(granted: Bool) {
        permissionsGranted = granted
    }
}

@available(visionOS 1.0, *)
struct SensitiveDataView: View {
    var body: some View {
        VStack {
            Text("CONFIDENTIAL CORPORATE DATA")
                .font(.headline)
            Text("Project X: Quantum Encryption Specs")
                .font(.caption)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(10)
    }
}

@available(visionOS 1.0, *)
struct SecureSpatialContainer<Content: View>: View {
    @State private var currentLevel: SecurityLevel = .windowed
    let sensitiveContent: Content
    let monitor: EnvironmentMonitor
    
    var body: some View {
        Group {
            switch currentLevel {
            case .immersive:
                // The full immersive experience
                ZStack {
                    Color.blue.opacity(0.1).ignoresSafeArea()
                    sensitiveContent
                }
                .onAppear {
                    print("Entering Immersive Secure Mode")
                }
                
            case .windowed:
                // Fallback to a standard window
                VStack {
                    Text("Secure Windowed Mode")
                        .font(.caption)
                    sensitiveContent
                }
                .frame(width: 400, height: 300)
                .glassBackgroundEffect()
                
            case .locked:
                // Total lockdown
                VStack {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 50))
                    Text("Security Lockdown")
                        .font(.headline)
                    Text("Spatial permissions revoked. Content hidden.")
                        .font(.caption)
                }
                .frame(width: 300, height: 200)
                .glassBackgroundEffect()
            }
        }
        .task {
            // Continuous monitoring loop
            while true {
                let newLevel = await monitor.monitorEnvironment()
                if currentLevel != newLevel {
                    // Ensure UI updates happen on MainActor
                    await MainActor.run {
                        self.currentLevel = newLevel
                    }
                }
                try? await Task.sleep(for: .seconds(2))
            }
        }
    }
}

// --- Usage Example ---
@available(visionOS 1.0, *)
struct SecureAppEntry: View {
    let monitor = EnvironmentMonitor()
    
    var body: some View {
        SecureSpatialContainer(
            sensitiveContent: SensitiveDataView(),
            monitor: monitor
        )
    }
}
