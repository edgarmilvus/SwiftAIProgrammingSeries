
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftUI // For @MainActor, ObservableObject, @Published, View, Text, ProgressView, Chart, LineMark, etc.
import Charts // For Exercise 3
import os.lock // For OSAllocatedUnfairLock, used in MLProgress.CancellationToken

// MARK: - Mock MLProgress and related types for demonstration
// In a real application, these types would be imported from the CreateML framework.
// These mocks are provided to make the examples runnable without a full CreateML project setup.

@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
extension MLProgress {
    /// A value representing a metric, typically a Double.
    struct Metric: Hashable, Sendable {
        let doubleValue: Double
    }

    /// Keys for various metrics.
    struct MetricKey: RawRepresentable, Hashable, Sendable {
        let rawValue: String
        init(rawValue: String) { self.rawValue = rawValue }
        init(_ rawValue: String) { self.rawValue = rawValue }
    }

    /// Common metric keys.
    extension MetricKey {
        static let loss: MLProgress.MetricKey = .init("loss")
        static let accuracy: MLProgress.MetricKey = .init("accuracy")
    }

    /// Represents the current phase of the training process.
    enum Phase: Hashable, Sendable {
        case initializing
        case training
        case validating
        case finalizing
        case unknown(String) // For future phases

        var description: String {
            switch self {
            case .initializing: return "Initializing"
            case .training: return "Training"
            case .validating: return "Validating"
            case .finalizing: return "Finalizing"
            case .unknown(let s): return "Unknown: \(s)"
            }
        }
    }

    /// A snapshot of the training progress at a specific moment.
    struct Snapshot: Sendable {
        let currentIteration: Int
        let phase: Phase
        let fractionCompleted: Double
        let metrics: [MetricKey: Metric]
        let validationMetrics: [MetricKey: Metric]?
    }

    /// Events emitted by MLProgress.
    enum Event: Sendable {
        case snapshot(Snapshot)
        case completed
        case failed(Error)
    }

    /// Errors that can occur during training.
    enum Error: Swift.Error, LocalizedError, Equatable, Sendable {
        case cancelled
        case failedToLoadData(Swift.Error?)
        case invalidInput(String)
        case modelError(Swift.Error?)
        case unknown(Swift.Error?)

        // Equatable conformance for comparison in tests/logic
        static func == (lhs: MLProgress.Error, rhs: MLProgress.Error) -> Bool {
            switch (lhs, rhs) {
            case (.cancelled, .cancelled): return true
            case (.failedToLoadData(_), .failedToLoadData(_)): return true // Simplified
            case (.invalidInput(let l), .invalidInput(let r)): return l == r
            case (.modelError(_), .modelError(_)): return true // Simplified
            case (.unknown(_), .unknown(_)): return true // Simplified
            default: return false
            }
        }

        var errorDescription: String? {
            switch self {
            case .cancelled: return "Training was cancelled."
            case .failedToLoadData(let error): return "Failed to load training data: \(error?.localizedDescription ?? "Unknown error")."
            case .invalidInput(let message): return "Invalid input: \(message)."
            case .modelError(let error): return "Model error: \(error?.localizedDescription ?? "Unknown error")."
            case .unknown(let error): return "An unknown training error occurred: \(error?.localizedDescription ?? "No details")."
            }
        }
    }

    /// A token to signal cancellation to an ongoing training process.
    class CancellationToken: Sendable {
        private let lock = OSAllocatedUnfairLock(initialState: false)
        var isCancelled: Bool {
            lock.withLock { $0 }
        }
        func cancel() {
            lock.withLock { $0 = true }
        }
    }

    /// A reporter for MLProgress events.
    class Reporter: Sendable {
        private let continuation: AsyncStream<Event>.Continuation

        init(continuation: AsyncStream<Event>.Continuation) {
            self.continuation = continuation
        }

        func reportSnapshot(currentIteration: Int, phase: Phase, fractionCompleted: Double, metrics: [MetricKey: Metric], validationMetrics: [MetricKey: Metric]?) {
            let snapshot = Snapshot(
                currentIteration: currentIteration,
                phase: phase,
                fractionCompleted: fractionCompleted,
                metrics: metrics,
                validationMetrics: validationMetrics
            )
            continuation.yield(.snapshot(snapshot))
        }

        func reportCompletion() {
            continuation.yield(.completed)
            continuation.finish()
        }

        func fail(with error: Swift.Error) {
            continuation.yield(.failed(error))
            continuation.finish()
        }
    }
}

/// The mock MLProgress type, conforming to AsyncSequence.
@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
struct MLProgress: AsyncSequence, Sendable {
    typealias Element = MLProgress.Event
    typealias AsyncIterator = AsyncStream<Element>.Iterator

    private let stream: AsyncStream<Element>

    init(_ build: @escaping (MLProgress.Reporter) -> Void) {
        self.stream = AsyncStream { continuation in
            let reporter = Reporter(continuation: continuation)
            build(reporter)
        }
    }

    func makeAsyncIterator() -> AsyncIterator {
        stream.makeAsyncIterator()
    }
}

// Global mock function to create MLProgress for exercises
@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
func createMockMLProgress(
    iterations: Int = 100,
    delay: Duration = .milliseconds(100),
    cancellationToken: MLProgress.CancellationToken? = nil,
    failAtIndex: Int? = nil // Simulate a failure at a specific iteration
) -> MLProgress {
    MLProgress { reporter in
        Task {
            do {
                // Simulate Initialization Phase
                reporter.reportSnapshot(currentIteration: 0, phase: .initializing, fractionCompleted: 0.0, metrics: [:], validationMetrics: nil)
                try await Task.sleep(for: delay)

                // Simulate Training Phase
                for i in 1...iterations {
                    // Check for cancellation from the token
                    if cancellationToken?.isCancelled == true {
                        reporter.fail(with: MLProgress.Error.cancelled)
                        return
                    }
                    // Check for cancellation of the observing Task itself
                    if Task.isCancelled {
                        reporter.fail(with: MLProgress.Error.cancelled)
                        return
                    }

                    // Simulate a specific failure
                    if let failIndex = failAtIndex, i == failIndex {
                        throw NSError(domain: "MockTrainingError", code: 1001, userInfo: [NSLocalizedDescriptionKey: "Simulated critical training error at iteration \(i)"])
                    }

                    let loss = 1.0 / Double(i) + Double.random(in: -0.05...0.05) // Simulate decreasing loss
                    let accuracy = 0.5 + (Double(i) / Double(iterations)) * 0.4 + Double.random(in: -0.02...0.02) // Simulate increasing accuracy

                    reporter.reportSnapshot(
                        currentIteration: i,
                        phase: .training,
                        fractionCompleted: 0.05 + (Double(i) / Double(iterations)) * 0.85, // 5% init, 85% training
                        metrics: [.loss: .init(doubleValue: max(0, loss)), .accuracy: .init(doubleValue: min(1, accuracy))],
                        validationMetrics: [.loss: .init(doubleValue: max(0, loss + 0.1)), .accuracy: .init(doubleValue: min(1, accuracy - 0.05))] // Slightly worse validation
                    )
                    try await Task.sleep(for: delay)
                }

                // Simulate Finalizing Phase
                reporter.reportSnapshot(currentIteration: iterations, phase: .finalizing, fractionCompleted: 0.95, metrics: [:], validationMetrics: nil)
                try await Task.sleep(for: delay)

                reporter.reportCompletion()
            } catch {
                reporter.fail(with: error)
            }
        }
    }
}


### Exercise 1: Basic Textual Progress Display for a Tabular Classifier (Easier)

**The Challenge:** Display the current training iteration and the model's loss value in a UI component as training progresses.

**Swift Solution:**
