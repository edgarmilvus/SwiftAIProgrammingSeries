
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MetricKit
import OSLog

/// A thread-safe actor responsible for managing MetricKit telemetry.
/// Using an `actor` ensures that processing heavy diagnostic payloads 
/// does not interfere with the main thread or cause data races.
@available(iOS 18.0, *)
actor MetricKitManager: NSObject, MXMetricManagerSubscriber {
    
    /// The shared instance for the application.
    static let shared = MetricKitManager()
    
    /// Logger for internal observability of the telemetry system itself.
    private let logger = Logger(subsystem: "com.echoai.app", category: "Telemetry")
    
    /// The metric manager provided by Apple.
    private let metricManager = MXMetricManager.shared
    
    /// Private initializer to enforce singleton pattern.
    private override init() {
        super.init()
    }
    
    /// Starts the monitoring process. 
    /// This must be called early in the app lifecycle (e.g., in @main or AppDelegate).
    func startMonitoring() {
        logger.info("Initializing MetricKit monitoring...")
        metricManager.beginMonitoring(with: self)
    }
    
    // MARK: - MXMetricManagerSubscriber Implementation

    /// Receives aggregated performance metrics.
    /// - Parameter payload: An `MXMetricPayload` containing battery, CPU, and memory data.
    /// - Note: This is called periodically by the system, not on every event.
    nonisolated func didReceive(_ payloads: [MXMetricPayload]) {
        // We transition to the actor context to process the data safely.
        Task {
            await self.processMetrics(payloads)
        }
    }
    
    /// Receives specific diagnostic events like crashes or hangs.
    /// - Parameter payloads: An array of `MXDiagnosticPayload` objects.
    nonisolated func didReceive(_ payloads: [MXDiagnosticPayload]) {
        Task {
            await self.processDiagnostics(payloads)
        }
    }
    
    // MARK: - Private Processing Logic

    /// Processes aggregated metrics to identify performance trends.
    /// - Parameter payloads: The collected metric payloads.
    private func processMetrics(_ payloads: [MXMetricPayload]) {
        for payload in payloads {
            // 1. Analyze CPU Usage
            // For AI apps, high CPU usage often indicates the model is running on 
            // the CPU instead of the Neural Engine/GPU.
            if let cpuMetric = payload.cpuMetric {
                let cpuUsage = cpuMetric.cumulativeCPUUsage
                logger.debug("Cumulative CPU Usage: \(cpuUsage)")
            }
            
            // 2. Analyze Memory Footprint
            // Crucial for AI: If memory peaks during model loading, 
            // the app is at risk of an OOM (Out of Memory) termination.
            if let memoryMetric = payload.memoryMetric {
                let peakMemory = memoryMetric.peakMemoryUsage
                logger.debug("Peak Memory Usage: \(peakMemory) bytes")
            }
            
            // 3. Analyze Battery Impact
            // AI inference is power-intensive. Monitoring this helps optimize 
            // the frequency of background model updates.
            if let batteryMetric = payload.batteryMetric {
                let drain = batteryMetric.cumulativeBatteryLevel
                logger.debug("Battery Level Change: \(drain)")
            }
        }
    }
    
    /// Processes critical diagnostic events.
    /// - Parameter payloads: The collected diagnostic payloads.
    private func processDiagnostics(_ payloads: [MXDiagnosticPayload]) {
        for payload in payloads {
            // 1. Handle Crashes
            // If the app crashes during inference, we need to know the signal.
            if let crash = payload.crashDiagnostic {
                logger.error("Crash Detected! Signal: \(crash.signal)")
                // In a real app, upload 'crash.description' to your server.
            }
            
            // 2. Handle Hangs
            // 'Hangs' are critical for AI. If the LLM inference blocks the 
            // Main Thread, the OS will kill the app.
            if let hang = payload.hangDiagnostic {
                logger.warning("App Hang Detected! Duration: \(hang.duration)s")
                // This helps identify if the model execution is too heavy for the current thread.
            }
            
            // 3. Handle Resource Exhaustion
            // Specifically useful for detecting when the Neural Engine 
            // or GPU is overloaded.
            if let resource = payload.resourceDiagnostic {
                logger.error("Resource Exhaustion: \(resource.description)")
            }
        }
    }
}

// MARK: - Application Entry Point Simulation

@main
struct EchoAIApp {
    static func main() async {
        // Initialize the telemetry system
        await MetricKitManager.shared.startMonitoring()
        
        print("EchoAI is running. Monitoring performance...")
        
        // Simulate an AI Inference Loop
        // In a real app, this would be your LLM or Speech-to-Text engine.
        try? await Task.sleep(for: .seconds(5))
        print("Inference complete.")
    }
}
