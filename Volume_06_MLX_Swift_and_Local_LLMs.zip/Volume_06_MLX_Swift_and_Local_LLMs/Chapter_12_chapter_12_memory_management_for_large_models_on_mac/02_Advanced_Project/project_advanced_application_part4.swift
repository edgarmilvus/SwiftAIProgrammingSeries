
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXOptimizers

// Ensure the code is only available on platforms supporting MLX.
@available(macOS 14.0, iOS 17.0, visionOS 1.0, *)
class DocumentScannerAppCoordinator: ObservableObject {
    @Published var statusMessage: String = "Ready."
    @Published var extractedFeatures: [Float]?
    @Published var lastLoss: Float?

    private let processor: DocumentScannerProcessor

    init() {
        self.processor = DocumentScannerProcessor()
    }

    /// Simulates scanning a document and extracting features.
    /// This would typically be triggered by a UI button or an image capture event.
    func processDocument() {
        statusMessage = "Scanning document and extracting features..."
        Task {
            do {
                // Simulate an input image patch (e.g., a 32x32 grayscale image).
                // In a real app, this would come from `CoreGraphics` or `CoreVideo`.
                let dummyImagePatch: [Float] = Array(repeating: 0.5, count: 32 * 32) // A uniform gray patch
                
                // Introduce some variation for a more "realistic" feature extraction example
                var variedImagePatch = dummyImagePatch
                for i in 0..<100 { // Add a "hotspot"
                    let index = Int.random(in: 0..<(32*32))
                    variedImagePatch[index] = 1.0
                }

                let featuresMLXArray = try await processor.extractFeatures(from: variedImagePatch)
                
                // Convert MLXArray back to Swift Array for UI display or further processing.
                // This is where data might be copied from GPU to CPU if not already there,
                // but still within Unified Memory, so it's a fast operation.
                let features = try featuresMLXArray.toFloatArray()
                
                await MainActor.run {
                    self.extractedFeatures = features
                    self.statusMessage = "Features extracted successfully! Vector size: \(features.count)"
                    print("Extracted Features (first 5): \(features.prefix(5))...")
                }
            } catch {
                await MainActor.run {
                    self.statusMessage = "Error extracting features: \(error.localizedDescription)"
                    print("Error: \(error)")
                }
            }
        }
    }

    /// Simulates a single fine-tuning step.
    /// This would be part of a larger, potentially background, training process.
    func performFineTuneStep() {
        statusMessage = "Performing hypothetical fine-tuning step..."
        Task {
            do {
                // Simulate an input image patch and a target feature vector.
                let dummyImagePatch: [Float] = Array(repeating: 0.6, count: 32 * 32) // Slightly different patch
                let dummyTargetFeatures = MLXArray(Array(repeating: 0.1, count: 128), [1, 128]) // Target vector

                let loss = try await processor.fineTuneStep(imagePatchData: dummyImagePatch, targetFeatures: dummyTargetFeatures)
                
                await MainActor.run {
                    self.lastLoss = loss
                    self.statusMessage = "Fine-tuning step complete. Last Loss: \(String(format: "%.4f", loss))"
                }
            } catch {
                await MainActor.run {
                    self.statusMessage = "Error during fine-tuning: \(error.localizedDescription)"
                    print("Error: \(error)")
                }
            }
        }
    }
}

// Example usage in a hypothetical SwiftUI App (or command-line main function)
@available(macOS 14.0, iOS 17.0, visionOS 1.0, *)
@main
struct DocumentScannerApp {
    static func main() async {
        let coordinator = DocumentScannerAppCoordinator()

        print("--- Document Scanner App Simulation ---")
        
        // Simulate processing a document
        await coordinator.processDocument()
        // Wait a bit for async operation
        try? await Task.sleep(for: .seconds(2))

        // Simulate a fine-tuning step
        await coordinator.performFineTuneStep()
        // Wait a bit
        try? await Task.sleep(for: .seconds(2))

        print("\nFinal Status: \(coordinator.statusMessage)")
        if let features = coordinator.extractedFeatures {
            print("Extracted features available: \(features.count) elements.")
        }
        if let loss = coordinator.lastLoss {
            print("Last recorded loss: \(loss).")
        }
        print("--- Simulation End ---")
    }
}
