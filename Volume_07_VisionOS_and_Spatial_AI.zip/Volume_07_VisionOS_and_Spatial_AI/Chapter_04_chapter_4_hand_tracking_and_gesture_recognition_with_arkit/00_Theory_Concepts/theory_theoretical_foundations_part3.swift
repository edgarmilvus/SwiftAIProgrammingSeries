
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import ARKit
import RealityKit
import SwiftUI

@Observable // Makes this class observable by SwiftUI and other reactive systems
@available(visionOS 1.0, *)
class SpatialInteractionState {
    var recognizedGesture: RecognizedGesture?
    var leftHandPose: ARHandAnchor?
    var rightHandPose: ARHandAnchor?

    // Example of a property that could drive SwiftUI view visibility
    var showPinchFeedback: Bool = false {
        didSet {
            if showPinchFeedback {
                // Start a timer to hide feedback after a short duration
                Task {
                    try await Task.sleep(for: .seconds(0.5))
                    await MainActor.run {
                        self.showPinchFeedback = false
                    }
                }
            }
        }
    }

    func updateHandPose(_ handAnchor: ARHandAnchor) {
        if handAnchor.chirality == .left {
            leftHandPose = handAnchor
        } else if handAnchor.chirality == .right {
            rightHandPose = handAnchor
        }
    }

    func updateRecognizedGesture(_ gesture: RecognizedGesture) {
        self.recognizedGesture = gesture
        if gesture.type == .pinch {
            showPinchFeedback = true
        }
        // Other logic based on gesture
    }
}

// Example SwiftUI View consuming the observable state
struct SpatialInteractionView: View {
    @Environment(SpatialInteractionState.self) private var interactionState

    var body: some View {
        VStack {
            if let gesture = interactionState.recognizedGesture {
                Text("Gesture: \(gesture.type.rawValue)")
                    .font(.largeTitle)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(20)
            }
            if interactionState.showPinchFeedback {
                Text("Pinch Detected!")
                    .font(.headline)
                    .foregroundColor(.accentColor)
            }
        }
        .frame(depth: 0.5) // Position in 3D space
    }
}
