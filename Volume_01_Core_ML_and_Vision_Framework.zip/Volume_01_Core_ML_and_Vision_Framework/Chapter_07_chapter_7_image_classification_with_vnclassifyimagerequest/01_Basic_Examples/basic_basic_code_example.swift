
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit
import Vision
import CoreML // Often implicitly used by Vision, good to include for completeness.

/// A simple `UIViewController` subclass demonstrating image classification.
/// This controller displays an image and a text view to show classification results.
///
/// This example is designed for iOS 18.0+ due to the use of modern async/await patterns
/// with the Vision framework's `perform` method.
@available(iOS 18.0, *)
class SmartPhotoAnalyzerViewController: UIViewController {

    // MARK: - UI Elements

    /// Displays the image that will be classified.
    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .systemGray5
        imageView.layer.cornerRadius = 10
        imageView.clipsToBounds = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()

    /// Button to trigger the image classification process.
    private let classifyButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Classify Image", for: .normal)
        button.titleLabel?.font = .preferredFont(forTextStyle: .headline)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    /// Text view to display the classification results.
    private let resultsTextView: UITextView = {
        let textView = UITextView()
        textView.isEditable = false
        textView.font = .preferredFont(forTextStyle: .body)
        textView.layer.cornerRadius = 8
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Smart Photo Analyzer"
        setupUI()
        // Load a sample image from the asset catalog for demonstration.
        // Make sure you have an image named "sample_image" in your Assets.xcassets.
        if let sampleImage = UIImage(named: "sample_image") {
            imageView.image = sampleImage
            resultsTextView.text = "Image loaded. Tap 'Classify Image' to analyze."
        } else {
            resultsTextView.text = "Error: 'sample_image' not found in assets. Please add one."
            classifyButton.isEnabled = false
        }
    }

    // MARK: - UI Setup

    /// Configures the layout and appearance of the UI elements.
    private func setupUI() {
        view.backgroundColor = .systemBackground
        view.addSubview(imageView)
        view.addSubview(classifyButton)
        view.addSubview(resultsTextView)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4), // 40% of view height

            classifyButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            classifyButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            classifyButton.heightAnchor.constraint(equalToConstant: 48),
            classifyButton.widthAnchor.constraint(equalToConstant: 200),

            resultsTextView.topAnchor.constraint(equalTo: classifyButton.bottomAnchor, constant: 20),
            resultsTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultsTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultsTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        classifyButton.addTarget(self, action: #selector(classifyImageButtonTapped), for: .touchUpInside)
    }

    // MARK: - Actions

    /// Handles the tap event on the classify button.
    /// Initiates the image classification process.
    @objc private func classifyImageButtonTapped() {
        guard let imageToClassify = imageView.image else {
            updateResults(with: "No image available to classify.")
            return
        }

        updateResults(with: "Classifying image...")
        classifyButton.isEnabled = false // Disable button during classification for UX

        // Perform classification in a detached task to avoid blocking the main thread.
        // This allows the UI to remain responsive while the ML model runs.
        Task {
            do {
                let classifications = try await performImageClassification(on: imageToClassify)
                await MainActor.run {
                    updateResults(with: formatClassifications(classifications))
                    classifyButton.isEnabled = true // Re-enable button after completion
                }
            } catch {
                await MainActor.run {
                    updateResults(with: "Classification failed: \(error.localizedDescription)")
                    classifyButton.isEnabled = true // Re-enable button even on error
                }
            }
        }
    }

    // MARK: - Vision Integration

    /// Performs image classification using `VNClassifyImageRequest`.
    ///
    /// This method encapsulates the core logic for interacting with the Vision framework
    /// to get classification observations for a given image.
    ///
    /// - Parameter image: The `UIImage` to classify.
    /// - Returns: An array of `VNClassificationObservation` objects, sorted by confidence.
    /// - Throws: An `ImageClassificationError` if the image is invalid or classification fails.
    private func performImageClassification(on image: UIImage) async throws -> [VNClassificationObservation] {
        // Ensure the UIImage has a valid CGImage, which Vision requires.
        guard let cgImage = image.cgImage else {
            throw ImageClassificationError.invalidImage
        }

        // 1. Create a VNClassifyImageRequest.
        // This request tells the Vision framework to perform general-purpose image classification.
        // Vision automatically selects and uses an appropriate, built-in classification model
        // (e.g., a highly optimized variant of ResNet or MobileNet) for this task.
        // You do not need to provide a custom Core ML model file here.
        let request = VNClassifyImageRequest()

        // 2. Create a VNImageRequestHandler.
        // This handler is responsible for executing Vision requests on a specific image.
        // It manages image preparation (scaling, rotation) before feeding it to the model.
        // It's crucial to pass the correct image orientation to ensure accurate results.
        let handler = VNImageRequestHandler(cgImage: cgImage, orientation: image.imageOrientation.toCGImagePropertyOrientation())

        // 3. Perform the request asynchronously.
        // The `perform` method dispatches the classification task, potentially to the Neural Engine.
        // It is `async` because it can be computationally intensive and `throws` if an error occurs.
        do {
            try await handler.perform([request])
        } catch {
            throw ImageClassificationError.visionError(error)
        }

        // 4. Process the results.
        // After the request is performed, its `results` property will contain an array of observations.
        // We cast these to `VNClassificationObservation`, which holds the identifier (label) and confidence.
        guard let observations = request.results as? [VNClassificationObservation] else {
            throw ImageClassificationError.noObservations
        }

        // Return the top 5 classifications, sorted by confidence in descending order.
        // This provides the most relevant and confident predictions.
        return observations.sorted(by: { $0.confidence > $1.confidence }).prefix(5).map { $0 }
    }

    // MARK: - Helper Methods

    /// Updates the `resultsTextView` on the main thread.
    /// This function is marked `@MainActor` to guarantee its execution on the main thread,
    /// which is essential for UI updates.
    ///
    /// - Parameter text: The text to display in the results view.
    @MainActor
    private func updateResults(with text: String) {
        resultsTextView.text = text
    }

    /// Formats the classification observations into a human-readable string.
    ///
    /// - Parameter observations: An array of `VNClassificationObservation`.
    /// - Returns: A formatted string listing the top classifications and their confidences.
    private func formatClassifications(_ observations: [VNClassificationObservation]) -> String {
        guard !observations.isEmpty else {
            return "No significant classifications found."
        }

        var resultString = "Top Classifications:\n"
        for (index, observation) in observations.enumerated() {
            // Format confidence as a percentage with two decimal places.
            let confidence = String(format: "%.2f", observation.confidence * 100)
            resultString += "\(index + 1). \(observation.identifier) (Confidence: \(confidence)%)\n"
        }
        return resultString
    }
}

// MARK: - Error Handling

/// Custom error types for image classification operations, providing more specific feedback.
enum ImageClassificationError: Error, LocalizedError {
    case invalidImage
    case noObservations
    case visionError(Error)

    /// Provides a user-friendly description for each error case.
    var errorDescription: String? {
        switch self {
        case .invalidImage:
            return "The provided image could not be processed. It might be corrupted or in an unsupported format."
        case .noObservations:
            return "Vision did not return any classification observations for this image. It might be too abstract or empty."
        case .visionError(let error):
            return "A Vision framework error occurred: \(error.localizedDescription)"
        }
    }
}

// MARK: - UIImage Orientation Extension

/// Extension to convert `UIImage.Orientation` to `CGImagePropertyOrientation`.
/// This conversion is critical for Vision to correctly interpret the image's orientation
/// and avoid misclassifications due to rotated input.
extension UIImage.Orientation {
    func toCGImagePropertyOrientation() -> CGImagePropertyOrientation {
        switch self {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default:
            // For any future, unknown orientation cases, default to .up.
            // In a production app, you might log a warning here.
            return .up
        }
    }
}

// MARK: - Usage Example (in an app's SceneDelegate or AppDelegate)
/*
// To integrate this into an iOS app, you would typically set
// SmartPhotoAnalyzerViewController as the root view controller in your SceneDelegate or AppDelegate.

// For an iOS 13+ project (using SceneDelegate):
// 1. Ensure your project target is set to iOS 18.0 or higher.
// 2. Add an image named "sample_image" to your project's Asset Catalog (e.g., a photo of a cat, car, or landscape).

// In SceneDelegate.swift:
import UIKit
import SwiftUI // If your project also uses SwiftUI, otherwise remove.

@available(iOS 18.0, *)
class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        window = UIWindow(windowScene: windowScene)

        // Create an instance of our SmartPhotoAnalyzerViewController
        let viewController = SmartPhotoAnalyzerViewController()
        let navigationController = UINavigationController(rootViewController: viewController) // Embed in nav controller for title
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
    }

    // ... other SceneDelegate methods
}
*/
