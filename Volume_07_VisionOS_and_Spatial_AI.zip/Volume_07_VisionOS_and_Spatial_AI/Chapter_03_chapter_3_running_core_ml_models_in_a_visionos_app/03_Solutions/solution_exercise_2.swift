
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AVFoundation
import Vision

// 1. Actor to manage processing state and prevent backpressure
actor InferenceState {
    private(set) var isProcessing = false
    
    func setProcessing(_ processing: Bool) {
        isProcessing = processing
    }
}

class CameraManager: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    @Published var detections: [VNRecognizedObjectObservation] = []
    private let session = AVCaptureSession()
    private let state = InferenceState()
    private var detectionRequest: VNCoreMLRequest?

    override init() {
        super.init()
        setupSession()
    }

    private func setupSession() {
        session.beginConfiguration()
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let videoDeviceInput = try? AVCaptureDeviceInput(device: videoDevice),
              session.canAddInput(videoDeviceInput) else { return }
        
        session.addInput(videoDeviceInput)
        
        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "camera_queue"))
        if session.canAddOutput(videoOutput) { session.addOutput(videoOutput) }
        session.commitConfiguration()
        
        // Initialize Model
        Task {
            let model = try VNCoreMLModel(for: YOLOv8(configuration: .init()).model)
            self.detectionRequest = VNCoreMLRequest(model: model)
        }
    }

    func start() { session.startRunning() }

    // 2. The Delegate Method (The "Hot Loop")
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        Task {
            // 3. Backpressure Check: Skip frame if still processing previous one
            guard await !state.isProcessing else { return }
            
            await state.setProcessing(true)
            
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
                  let request = detectionRequest else {
                await state.setProcessing(false)
                return
            }

            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            
            do {
                try handler.perform([request])
                let results = request.results as? [VNRecognizedObjectObservation] ?? []
                
                // Update UI on MainActor
                await MainActor.run {
                    self.detections = results
                }
            } catch {
                print("Inference error: \(error)")
            }
            
            await state.setProcessing(false)
        }
    }
}

struct RealTimeScannerView: View {
    @StateObject private var camera = CameraManager()

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // In a real app, this would be a Metal-backed video preview
                Color.black 
                
                // 4. High-performance Drawing with Canvas
                Canvas { context, size in
                    for detection in camera.detections {
                        // 5. Coordinate Mapping (Vision: Bottom-Left -> SwiftUI: Top-Left)
                        let rect = convertRect(detection.boundingBox, to: size)
                        let path = Path(rect)
                        
                        context.stroke(path, with: .color(.green), lineWidth: 3)
                        context.draw(Text(detection.labels.first?.identifier ?? ""), at: CGPoint(x: rect.midX, y: rect.minY - 10))
                    }
                }
            }
            .onAppear { camera.start() }
        }
    }

    // Helper to map normalized Vision coordinates to View coordinates
    private func convertRect(_ normalizedRect: CGRect, to size: CGSize) -> CGRect {
        return CGRect(
            x: normalizedRect.origin.x * size.width,
            y: (1 - normalizedRect.origin.y - normalizedRect.height) * size.height,
            width: normalizedRect.width * size.width,
            height: normalizedRect.height * size.height
        )
    }
}
