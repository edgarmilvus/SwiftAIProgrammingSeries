/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// TransactionBadge.tsx (Component)
import React from 'react';
import { View, Text } from 'react-native';
import { cn } from '@/lib/utils';

interface TransactionBadgeProps {
  type: 'debit' | 'credit';
  amount: string;
}

export const TransactionBadge: React.FC<TransactionBadgeProps> = ({ type, amount }) => {
  // Determine classes based on type
  const badgeClasses = cn(
    'px-3 py-1 rounded-full font-bold text-xs uppercase tracking-wide',
    {
      'bg-brand-primary text-white': type === 'debit',
      'bg-brand-accent text-black': type === 'credit',
    }
  );

  return (
    <View className={badgeClasses}>
      <Text className="font-bold">{type === 'debit' ? '-' : '+'} {amount}</Text>
    </View>
  );
};
