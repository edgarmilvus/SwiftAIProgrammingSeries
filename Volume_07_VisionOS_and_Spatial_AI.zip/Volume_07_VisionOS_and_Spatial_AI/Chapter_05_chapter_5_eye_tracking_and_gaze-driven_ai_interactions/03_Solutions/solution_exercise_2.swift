
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

@available(visionOS 1.0, *)
@MainActor
class GazeInteractionManager: ObservableObject {
    @Published var hoveredElementID: Int? = nil
    @Published var dwellProgress: Double = 0.0 // 0.0 to 1.0
    
    private var dwellTask: Task<Void, Never>? = nil
    private let dwellThreshold: Double = 0.5 // 500ms
    
    func startHover(for id: Int) {
        hoveredElementID = id
        dwellProgress = 0.0
        
        // Cancel any existing timer
        dwellTask?.cancel()
        
        // Start the dwell timer
        dwellTask = Task {
            let startTime = Date()
            while !Task.isCancelled {
                let elapsed = Date().timeIntervalSince(startTime)
                
                // Update progress for the UI ring
                await MainActor.run {
                    self.dwellProgress = min(elapsed / dwellThreshold, 1.0)
                }
                
                if elapsed >= dwellThreshold {
                    break
                }
                
                // 16ms approx for 60fps updates
                try? await Task.sleep(nanoseconds: 16_000_000)
            }
        }
    }
    
    func endHover() {
        hoveredElementID = nil
        dwellProgress = 0.0
        dwellTask?.cancel()
        dwellTask = nil
    }
}

@available(visionOS 1.0, *)
struct SmartDashboardView: View {
    @StateObject private var interactionManager = GazeInteractionManager()
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Spatial Dashboard")
                .font(.largeTitle)
            
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 20) {
                ForEach(0..<4) { index in
                    DashboardButton(index: index, manager: interactionManager)
                }
            }
        }
        .padding(40)
    }
}

@available(visionOS 1.0, *)
struct DashboardButton: View {
    let index: Int
    @ObservedObject var manager: GazeInteractionManager
    
    private var isFocused: Bool {
        manager.hoveredElementID == index
    }
    
    var body: some View {
        Button(action: {
            print("Control \(index) activated")
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(.ultraThinMaterial)
                    .frame(width: 100, height: 100)
                    .shadow(color: isFocused ? .white.opacity(0.3) : .clear, radius: 10)
                    .scaleEffect(isFocused ? 1.05 : 1.0)
                
                VStack {
                    Text("Ctrl \(index)")
                        .font(.caption)
                        .bold()
                    
                    // Progress Ring for Dwell Time
                    if isFocused {
                        Circle()
                            .trim(from: 0, to: manager.dwellProgress)
                            .stroke(Color.blue, lineWidth: 4)
                            .frame(width: 110, height: 110)
                            .animation(.linear, value: manager.dwellProgress)
                    }
                }
            }
        }
        .buttonStyle(.plain)
        .hoverEffect() // System-level highlight
        .onHover { hovering in
            if hovering {
                manager.startHover(for: index)
            } else {
                manager.endHover()
            }
        }
    }
}
