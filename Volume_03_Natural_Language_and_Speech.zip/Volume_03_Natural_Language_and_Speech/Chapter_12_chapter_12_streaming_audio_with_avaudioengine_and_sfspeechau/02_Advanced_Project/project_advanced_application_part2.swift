
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AVFoundation
import Speech

/// @available(iOS 17.0, *) indicates that this code leverages modern concurrency features
/// and frameworks available from iOS 17.0 and above.
@available(iOS 17.0, *)
actor RealtimeVoiceMemoTranscriber {

    /// Defines possible errors that can occur during the transcription process.
    enum TranscriberError: Error, LocalizedError {
        case notAuthorizedForSpeechRecognition
        case notAuthorizedForMicrophone
        case audioSessionActivationFailed(Error)
        case audioEngineConfigurationFailed(Error)
        case speechRecognizerUnavailable
        case recognitionRequestFailed(Error)
        case recordingAlreadyInProgress
        case notRecording
        case unknownError(Error)

        var errorDescription: String? {
            switch self {
            case .notAuthorizedForSpeechRecognition:
                return "Speech recognition authorization denied. Please enable in Settings."
            case .notAuthorizedForMicrophone:
                return "Microphone access denied. Please enable in Settings."
            case .audioSessionActivationFailed(let error):
                return "Failed to activate audio session: \(error.localizedDescription)"
            case .audioEngineConfigurationFailed(let error):
                return "Failed to configure audio engine: \(error.localizedDescription)"
            case .speechRecognizerUnavailable:
                return "Speech recognizer is not available for the current locale."
            case .recognitionRequestFailed(let error):
                return "Speech recognition request failed: \(error.localizedDescription)"
            case .recordingAlreadyInProgress:
                return "Recording is already in progress."
            case .notRecording:
                return "Not currently recording."
            case .unknownError(let error):
                return "An unknown error occurred: \(error.localizedDescription)"
            }
        }
    }

    /// Represents the current state of the transcriber.
    enum TranscriberState {
        case idle        // Initial state, or after stopping.
        case authorizing // Currently requesting permissions.
        case ready       // Permissions granted, ready to start recording.
        case recording   // Audio engine is running, actively transcribing.
        case error(TranscriberError) // An error occurred.
    }

    // MARK: - Private Properties

    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine() // Manages the audio input path.
    private let audioSession = AVAudioSession.sharedInstance() // Manages audio hardware.

    private var _state: TranscriberState = .idle // Internal state, protected by Actor.
    /// Publicly accessible state for observation.
    nonisolated public private(set) var state: TranscriberState {
        get { _state }
        set { _state = newValue } // Only the actor can change this.
    }

    /// An `AsyncStream` to publish real-time transcription updates.
    private var transcriptionContinuation: AsyncStream<String>.Continuation?
    nonisolated public lazy var transcriptionUpdates: AsyncStream<String> = {
        AsyncStream { continuation in
            self.transcriptionContinuation = continuation
            // Ensure continuation is released when stream is cancelled
            continuation.onTermination = { @Sendable [weak self] _ in
                Task { await self?.resetTranscriptionStream() }
            }
        }
    }()

    /// The current partial or final transcription string.
    private var currentTranscription: String = "" {
        didSet {
            // Publish updates whenever the transcription changes.
            transcriptionContinuation?.yield(currentTranscription)
        }
    }

    // MARK: - Initialization

    /// Initializes the transcriber. It's recommended to call `requestAuthorization()` after initialization.
    init() {
        // Initialize speech recognizer for the device's current locale.
        speechRecognizer = SFSpeechRecognizer(locale: Locale.current)
        // Set up delegate to observe recognizer availability changes.
        speechRecognizer?.delegate = self
    }

    // MARK: - Authorization

    /// Requests authorization for both speech recognition and microphone access.
    /// This should be called before attempting to start transcription.
    /// - Throws: `TranscriberError` if authorization is denied for either service.
    public func requestAuthorization() async throws {
        guard state != .authorizing else { return } // Prevent re-entry

        state = .authorizing

        // Request speech recognition authorization.
        let speechAuthStatus = await SFSpeechRecognizer.requestAuthorization()
        guard speechAuthStatus == .authorized else {
            state = .error(.notAuthorizedForSpeechRecognition)
            throw TranscriberError.notAuthorizedForSpeechRecognition
        }

        // Request microphone authorization.
        let audioAuthStatus = await AVCaptureDevice.requestAccess(for: .audio)
        guard audioAuthStatus else {
            state = .error(.notAuthorizedForMicrophone)
            throw TranscriberError.notAuthorizedForMicrophone
        }

        // If both authorized, set state to ready.
        state = .ready
        print("Authorization successful. Transcriber is ready.")
    }

    // MARK: - Transcription Control

    /// Starts the real-time audio capture and speech transcription process.
    /// - Throws: `TranscriberError` if authorization is missing, or if audio engine/session fails.
    public func startTranscription() async throws {
        guard state != .recording else {
            throw TranscriberError.recordingAlreadyInProgress
        }
        guard state == .ready else {
            if state == .idle {
                // If idle, try to authorize first.
                await requestAuthorization()
                guard state == .ready else {
                    // If still not ready after authorization attempt, throw the underlying error.
                    if case .error(let err) = state { throw err }
                    throw TranscriberError.unknownError(
                        NSError(domain: "RealtimeVoiceMemoTranscriber", code: 0, userInfo: [NSLocalizedDescriptionKey: "Transcriber not ready after authorization attempt."])
                    )
                }
            } else {
                // If in an error state or authorizing, prevent starting.
                if case .error(let err) = state { throw err }
                throw TranscriberError.unknownError(
                    NSError(domain: "RealtimeVoiceMemoTranscriber", code: 0, userInfo: [NSLocalizedDescriptionKey: "Transcriber not in a ready state to start."])
                )
            }
        }

        // 1. Reset any previous recognition tasks and requests.
        resetRecognition()

        // 2. Configure and activate the audio session.
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            state = .error(.audioSessionActivationFailed(error))
            throw TranscriberError.audioSessionActivationFailed(error)
        }

        // 3. Set up the SFSpeechAudioBufferRecognitionRequest.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        recognitionRequest?.shouldReportPartialResults = true // Get real-time updates.

        guard let recognitionRequest = recognitionRequest else {
            state = .error(.speechRecognizerUnavailable) // Should not happen if speechRecognizer is valid.
            throw TranscriberError.speechRecognizerUnavailable
        }
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            state = .error(.speechRecognizerUnavailable)
            throw TranscriberError.speechRecognizerUnavailable
        }

        // 4. Create the recognition task.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            Task { @MainActor in // Process results on the main actor to update UI related properties
                guard let self = self else { return }
                guard self.state == .recording else { return } // Only process if still recording

                if let result = result {
                    // Update current transcription with the best transcription.
                    self.currentTranscription = result.bestTranscription.formattedString
                    print("Partial/Final: \(self.currentTranscription)")
                }

                if let error = error {
                    // Handle errors from the recognition task.
                    print("Recognition task error: \(error.localizedDescription)")
                    self.state = .error(.recognitionRequestFailed(error))
                    await self.stopTranscription() // Stop on error.
                }

                // If the result is final, and no error occurred, the task is complete.
                if result?.isFinal == true && error == nil {
                    print("Recognition task finished.")
                    // The task automatically stops when final.
                    // We might want to reset for a new segment or stop entirely.
                }
            }
        }

        // 5. Configure the audio engine for input.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            // Append audio buffers to the recognition request.
            recognitionRequest.append(buffer)
        }
        audioEngine.prepare()

        // 6. Start the audio engine.
        do {
            try audioEngine.start()
            state = .recording
            currentTranscription = "" // Reset transcription for a new recording.
            print("Audio engine started. Transcription in progress...")
        } catch {
            inputNode.removeTap(onBus: 0) // Clean up tap on failure.
            state = .error(.audioEngineConfigurationFailed(error))
            throw TranscriberError.audioEngineConfigurationFailed(error)
        }
    }

    /// Stops the current real-time audio capture and speech transcription.
    public func stopTranscription() async {
        guard state == .recording else {
            print("Attempted to stop transcription when not recording. Current state: \(state)")
            return // Not recording, so nothing to stop.
        }

        print("Stopping transcription...")

        // 1. Stop and reset the audio engine.
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)

        // 2. Cancel and release the recognition task and request.
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest?.endAudio()
        recognitionRequest = nil

        // 3. Deactivate the audio session.
        do {
            try audioSession.setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
            // We don't throw here as the main goal is to stop.
            // But we might log this or update state to reflect a partial cleanup.
        }

        // 4. Reset transcription and update state.
        currentTranscription = ""
        state = .ready // Back to ready state, can restart.
        print("Transcription stopped.")
    }

    /// Resets the internal state of the recognition task and request.
    private func resetRecognition() {
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest?.endAudio() // Signal end of audio for the request.
        recognitionRequest = nil
    }

    /// Resets the AsyncStream continuation. Called when the stream is terminated.
    private func resetTranscriptionStream() {
        transcriptionContinuation = nil
        print("Transcription updates stream terminated.")
    }

    // MARK: - SFSpeechRecognizerDelegate

    /// Conformance to `SFSpeechRecognizerDelegate` to observe availability changes.
    nonisolated func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        Task { @MainActor in // Update state on the main actor
            if available {
                print("Speech recognizer is now available.")
                // If it was in an error state due to unavailability, and now available, reset to ready.
                if case .error(.speechRecognizerUnavailable) = await self.state {
                    await self._state = .ready
                } else if await self.state == .idle { // If idle and becomes available, set to ready.
                    await self._state = .ready
                }
            } else {
                print("Speech recognizer is no longer available.")
                // If it was recording or ready, and now unavailable, transition to error.
                if await self.state == .recording || await self.state == .ready {
                    await self._state = .error(.speechRecognizerUnavailable)
                    await self.stopTranscription() // Automatically stop if recording.
                }
            }
        }
    }
}

// MARK: - SFSpeechRecognizerDelegate Conformance (outside the actor for nonisolated methods)
// Note: Delegate methods must be nonisolated if the delegate is an actor.
extension RealtimeVoiceMemoTranscriber: SFSpeechRecognizerDelegate {}

// MARK: - Example Usage (within a SwiftUI View or ViewController)

/*
/// Example of how to integrate RealtimeVoiceMemoTranscriber into a SwiftUI View.
@available(iOS 17.0, *)
struct VoiceMemoView: View {
    @StateObject private var transcriberViewModel = TranscriberViewModel()

    var body: some View {
        VStack {
            Text(transcriberViewModel.transcribedText)
                .font(.title2)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)

            Spacer()

            if case .error(let error) = transcriberViewModel.transcriberState {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
            } else {
                Text("Status: \(String(describing: transcriberViewModel.transcriberState))")
                    .foregroundColor(.secondary)
            }

            Button(transcriberViewModel.transcriberState == .recording ? "Stop Recording" : "Start Recording") {
                Task {
                    if transcriberViewModel.transcriberState == .recording {
                        await transcriberViewModel.stopRecording()
                    } else {
                        await transcriberViewModel.startRecording()
                    }
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()
            .disabled(transcriberViewModel.transcriberState == .authorizing)
        }
        .padding()
        .task {
            // Request authorization when the view appears.
            await transcriberViewModel.requestAuthorization()
        }
    }
}

@available(iOS 17.0, *)
@MainActor
class TranscriberViewModel: ObservableObject {
    private let transcriber = RealtimeVoiceMemoTranscriber()
    @Published var transcribedText: String = "Tap 'Start Recording' to begin..."
    @Published var transcriberState: RealtimeVoiceMemoTranscriber.TranscriberState = .idle

    private var transcriptionTask: Task<Void, Never>?

    init() {
        // Observe state changes from the actor
        Task {
            for await state in transcriber.stateUpdates { // Assuming stateUpdates property on Actor
                self.transcriberState = state
            }
        }
    }

    func requestAuthorization() async {
        do {
            await transcriber.requestAuthorization()
        } catch {
            print("Authorization failed: \(error.localizedDescription)")
            // State will be set to error by the actor itself.
        }
    }

    func startRecording() async {
        transcribedText = "" // Clear previous text
        transcriptionTask = Task {
            do {
                // Collect transcription updates
                for await text in transcriber.transcriptionUpdates {
                    self.transcribedText = text
                }
            } catch {
                print("Error collecting transcription updates: \(error.localizedDescription)")
            }
        }

        do {
            await transcriber.startTranscription()
        } catch {
            print("Failed to start transcription: \(error.localizedDescription)")
            // State will be set to error by the actor itself.
            transcriptionTask?.cancel()
            transcriptionTask = nil
        }
    }

    func stopRecording() async {
        await transcriber.stopTranscription()
        transcriptionTask?.cancel() // Stop observing updates
        transcriptionTask = nil
    }
}
*/
