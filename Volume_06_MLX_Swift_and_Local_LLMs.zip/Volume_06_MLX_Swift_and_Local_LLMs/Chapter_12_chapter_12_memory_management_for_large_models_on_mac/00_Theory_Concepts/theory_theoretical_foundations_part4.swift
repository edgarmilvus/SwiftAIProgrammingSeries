
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation // For UUID

@available(iOS 18.0, macOS 15.0, *)
@Observable
final class LLMStatus {
    var modelName: String = "No Model Loaded"
    var isLoading: Bool = false
    var lastInferenceTime: TimeInterval = 0.0
    var currentLoss: Float? // For fine-tuning feedback
    var inferenceOutputShape: [Int]?

    private let actor: LLMInferenceActor

    init(actor: LLMInferenceActor) {
        self.actor = actor
    }

    func loadModelAndInfer(input: MLXArray) async {
        isLoading = true
        modelName = "Loading..."
        do {
            try await actor.loadModel()
            modelName = "SimpleLinearModel (Loaded)"
            let startTime = Date()
            let output = try await actor.performInference(input: input)
            lastInferenceTime = Date().timeIntervalSince(startTime)
            inferenceOutputShape = output.shape
            print("Inference complete.")
        } catch {
            print("Error: \(error)")
            modelName = "Error Loading Model"
        }
        isLoading = false
    }
}

// Example SwiftUI usage (conceptual, not full view)
/*
struct ContentView: View {
    @State private var inputData = MLXArray.random(shape: [1, 768])
    @State private var actor = LLMInferenceActor(inputFeatures: 768, outputFeatures: 128)
    @State private var status: LLMStatus // Initialize in .onAppear or similar

    init() {
        _status = State(initialValue: LLMStatus(actor: actor))
    }

    var body: some View {
        VStack {
            Text("Model: \(status.modelName)")
            if status.isLoading {
                ProgressView()
            }
            Text("Last Inference Time: \(status.lastInferenceTime, specifier: "%.2f")s")
            if let shape = status.inferenceOutputShape {
                Text("Output Shape: \(shape.map(String.init).joined(separator: "x"))")
            }
            Button("Load Model & Infer") {
                Task {
                    await status.loadModelAndInfer(input: inputData)
                }
            }
        }
    }
}
*/
