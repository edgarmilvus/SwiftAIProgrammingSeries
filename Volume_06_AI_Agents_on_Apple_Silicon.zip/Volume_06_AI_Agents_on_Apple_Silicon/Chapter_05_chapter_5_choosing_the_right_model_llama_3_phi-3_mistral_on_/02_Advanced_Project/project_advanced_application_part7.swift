
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

// LocalAIModelManager.swift
import Foundation // For TimeInterval, Date, etc.
import Combine    // For @Published and ObservableObject

/// Manages the loading, unloading, and inference for local LLM models.
/// This class uses Swift 6 concurrency and is designed to be integrated with SwiftUI
/// via the ObservableObject protocol and @Published properties.
@available(iOS 18.0, macOS 15.0, *) // Require modern OS versions for full concurrency support
final class LocalAIModelManager: ObservableObject {
    /// The currently selected model configuration.
    @Published private(set) var currentModelConfiguration: LLMModelConfiguration?
    
    /// Indicates whether a model is currently being loaded or unloaded.
    @Published private(set) var isLoadingModel: Bool = false
    
    /// The last successful inference result, including generated text and performance metrics.
    @Published private(set) var lastInferenceResult: LLMInferenceResult?
    
    /// The current state of the model manager, useful for UI feedback.
    @Published private(set) var statusMessage: String = "Ready."
    
    /// The underlying LLM wrapper responsible for actual model interaction.
    private let llmWrapper: LlamaCppWrapperProtocol
    
    /// A Task that holds the current model loading operation, allowing for cancellation.
    private var loadingTask: Task<Void, Never>?
    
    /// A Task that holds the current inference operation, allowing for cancellation.
    private var inferenceTask: Task<Void, Never>?

    /// Initializes the model manager with a specific LLM wrapper implementation.
    /// - Parameter llmWrapper: An object conforming to `LlamaCppWrapperProtocol`.
    init(llmWrapper: LlamaCppWrapperProtocol = MockLlamaCppWrapper()) {
        self.llmWrapper = llmWrapper
    }

    /// Loads the specified LLM model, unloading any previously loaded model first.
    /// This operation is asynchronous and updates the `isLoadingModel` and `statusMessage` properties.
    /// - Parameter modelConfig: The configuration of the model to load.
    func loadModel(_ modelConfig: LLMModelConfiguration) async {
        // Cancel any ongoing loading task to prevent race conditions or stale operations.
        loadingTask?.cancel()
        loadingTask = Task {
            await MainActor.run {
                self.isLoadingModel = true
                self.statusMessage = "Loading \(modelConfig.displayName)..."
            }

            // Ensure previous model is unloaded before loading a new one.
            // This is a critical step to free up resources.
            if let current = currentModelConfiguration, current != modelConfig {
                print("Unloading previous model: \(current.displayName)")
                await llmWrapper.unloadModel()
            }

            do {
                try await llmWrapper.loadModel(from: modelConfig.modelPath)
                await MainActor.run {
                    self.currentModelConfiguration = modelConfig
                    self.statusMessage = "\(modelConfig.displayName) loaded successfully."
                }
                print("\(modelConfig.displayName) loaded.")
            } catch {
                await MainActor.run {
                    self.statusMessage = "Failed to load \(modelConfig.displayName): \(error.localizedDescription)"
                    print("Error loading model: \(error.localizedDescription)")
                }
            }
            await MainActor.run {
                self.isLoadingModel = false
            }
        }
    }

    /// Unloads the currently active LLM model, releasing its resources.
    func unloadCurrentModel() async {
        loadingTask?.cancel() // Cancel any pending load operations
        inferenceTask?.cancel() // Cancel any pending inference operations
        
        await MainActor.run {
            self.isLoadingModel = true
            self.statusMessage = "Unloading current model..."
        }
        await llmWrapper.unloadModel()
        await MainActor.run {
            self.currentModelConfiguration = nil
            self.isLoadingModel = false
            self.statusMessage = "No model loaded."
            self.lastInferenceResult = nil
        }
        print("Current model unloaded.")
    }

    /// Generates a response for a given prompt using the currently loaded LLM.
    /// The response is streamed as an `AsyncThrowingStream` of tokens.
    /// Performance metrics (duration, tokens/sec) are calculated and stored.
    /// - Parameters:
    ///   - prompt: The input text prompt for the LLM.
    ///   - temperature: Controls the randomness of the output.
    ///   - maxTokens: The maximum number of tokens to generate.
    /// - Returns: An `AsyncThrowingStream` of `String` tokens.
    /// - Throws: `LLMInferenceError` if no model is loaded or inference fails.
    func generateResponse(prompt: String, temperature: Float = 0.7, maxTokens: Int = 200) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            // Cancel any previous inference task to ensure only one is active.
            inferenceTask?.cancel()
            inferenceTask = Task {
                await MainActor.run {
                    self.statusMessage = "Generating response..."
                }
                
                let startTime = Date()
                var fullResponse = ""
                var tokenCount = 0

                do {
                    // Check for cancellation before starting inference
                    try Task.checkCancellation()
                    
                    let tokenStream = try await self.llmWrapper.generate(
                        prompt: prompt,
                        temperature: temperature,
                        maxTokens: maxTokens
                    )

                    for try await token in tokenStream {
                        // Check for cancellation during token streaming
                        try Task.checkCancellation()
                        fullResponse += token
                        tokenCount += 1
                        continuation.yield(token) // Yield each token as it's generated
                    }

                    let endTime = Date()
                    let duration = endTime.timeIntervalSince(startTime)
                    let tokensPerSecond = tokenCount > 0 ? Double(tokenCount) / duration : 0.0

                    let result = LLMInferenceResult(
                        generatedText: fullResponse.trimmingCharacters(in: .whitespacesAndNewlines),
                        inferenceDuration: duration,
                        tokensPerSecond: tokensPerSecond,
                        tokenCount: tokenCount
                    )

                    await MainActor.run {
                        self.lastInferenceResult = result
                        self.statusMessage = "Response generated in \(String(format: "%.2f", duration))s (\(String(format: "%.1f", tokensPerSecond)) tokens/s)."
                    }
                    continuation.finish() // Signal that the stream is complete
                    print("Inference completed: \(result)")

                } catch is CancellationError {
                    await MainActor.run {
                        self.statusMessage = "Inference cancelled."
                    }
                    continuation.finish(throwing: LLMInferenceError.cancellationError)
                    print("Inference task was cancelled.")
                } catch {
                    await MainActor.run {
                        self.statusMessage = "Inference failed: \(error.localizedDescription)"
                    }
                    continuation.finish(throwing: error) // Propagate the error through the stream
                    print("Error during inference: \(error.localizedDescription)")
                }
            }
        }
    }
    
    /// Cancels any ongoing inference operation.
    func cancelInference() {
        inferenceTask?.cancel()
        inferenceTask = nil
        // The generateResponse's Task will handle updating status message upon cancellation.
    }
}
