
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// Package.swift (Example for a Swift Package, if you were to encapsulate this logic)
// This specific example is for an iOS app target, so a Package.swift isn't strictly needed
// for the app itself, but good to know for modularity.
/*
import PackageDescription

let package = Package(
    name: "CoreMLVisionClassifier",
    platforms: [.iOS(.v18), .macOS(.v15)], // Targeting latest SDKs for Swift 6
    products: [
        .library(
            name: "CoreMLVisionClassifier",
            targets: ["CoreMLVisionClassifier"]),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "CoreMLVisionClassifier",
            dependencies: []),
        .testTarget(
            name: "CoreMLVisionClassifierTests",
            dependencies: ["CoreMLVisionClassifier"]),
    ]
)
*/

import UIKit
import CoreML
import Vision // Essential for image-based Core ML models

/// A simple iOS ViewController demonstrating image classification using a Core ML model via Vision.
@available(iOS 18.0, *) // Targeting the latest iOS SDK for modern Swift features
final class ImageClassifierViewController: UIViewController {

    // MARK: - UI Elements

    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .systemGray5
        imageView.layer.cornerRadius = 8
        imageView.clipsToBounds = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()

    private let classifyButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Classify Image", for: .normal)
        button.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.preferredFont(forTextStyle: .title2)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Model and Request Properties

    /// The Core ML model instance. Loaded once for efficiency.
    private var coreMLModel: VNCoreMLModel?

    /// The Vision request for image classification.
    private var classificationRequest: VNCoreMLRequest?

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadCoreMLModel()
    }

    /// Sets up the user interface elements and their constraints.
    private func setupUI() {
        view.backgroundColor = .systemBackground

        let stackView = UIStackView(arrangedSubviews: [imageView, classifyButton, resultLabel])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalToConstant: 250),
            imageView.widthAnchor.constraint(equalTo: stackView.widthAnchor),
            classifyButton.widthAnchor.constraint(equalToConstant: 200)
        ])

        classifyButton.addTarget(self, action: #selector(classifyButtonTapped), for: .touchUpInside)

        // Load a default image for demonstration
        if let defaultImage = UIImage(named: "sample_image") { // Make sure you have 'sample_image.jpg' in your Assets.xcassets
            imageView.image = defaultImage
        } else {
            print("Error: 'sample_image' not found in assets.")
            imageView.image = UIImage(systemName: "photo") // Fallback
        }
    }

    // MARK: - Core ML Model Loading

    /// Loads the Core ML model and initializes the Vision request.
    /// This should ideally happen once, e.g., during app launch or view initialization.
    private func loadCoreMLModel() {
        do {
            // 1. Load the Core ML model from the app bundle.
            // Replace 'MobileNetV3_Small_ImageNet' with the actual name of your .mlmodel file.
            // This model is assumed to be an image classifier.
            let modelURL = Bundle.main.url(forResource: "MobileNetV3_Small_ImageNet", withExtension: "mlmodelc")!
            
            // For custom compute units or batch prediction, configure MLModelConfiguration.
            let configuration = MLModelConfiguration()
            // Example: Prioritize neural engine if available, fall back to GPU/CPU.
            configuration.computeUnits = .all
            // For batch prediction (multiple images at once), you might set .cpuAndGPU or .all.

            let model = try MLModel(contentsOf: modelURL, configuration: configuration)

            // 2. Wrap the Core ML model in a VNCoreMLModel for Vision framework compatibility.
            coreMLModel = try VNCoreMLModel(for: model)

            // 3. Create a VNCoreMLRequest. This request will be executed by Vision.
            classificationRequest = VNCoreMLRequest(model: coreMLModel!) { [weak self] request, error in
                // This completion handler is called when the Vision request finishes.
                // It's crucial to dispatch UI updates to the main actor.
                Task { @MainActor in
                    self?.processClassificationResults(for: request, error: error)
                }
            }

            // Optional: Configure the Vision request.
            // For image classification, Vision automatically scales and crops the input image
            // to match the model's expected input size.
            classificationRequest?.imageCropAndScaleOption = .centerCrop // Or .scaleFit, .scaleFill

            print("Core ML model loaded successfully and Vision request initialized.")

        } catch {
            print("Error loading Core ML model or initializing Vision request: \(error.localizedDescription)")
            resultLabel.text = "Error: Model loading failed."
        }
    }

    // MARK: - Classification Logic

    /// Handles the button tap to initiate image classification.
    @objc private func classifyButtonTapped() {
        guard let imageToClassify = imageView.image else {
            resultLabel.text = "No image selected."
            return
        }

        // Convert UIImage to CVPixelBuffer, which Vision prefers.
        // Vision's `VNImageRequestHandler` can often handle `UIImage` directly,
        // but converting to `CGImage` or `CVPixelBuffer` can sometimes offer more control
        // or be necessary for specific Vision requests. For simplicity, we'll let Vision handle
        // the `UIImage` to `CGImage` conversion.
        guard let cgImage = imageToClassify.cgImage else {
            resultLabel.text = "Could not convert UIImage to CGImage."
            return
        }

        guard let request = classificationRequest else {
            resultLabel.text = "Classification request not initialized."
            return
        }
        
        // Indicate that classification is in progress
        resultLabel.text = "Classifying..."
        classifyButton.isEnabled = false

        // 4. Create a VNImageRequestHandler with the image to be classified.
        // The orientation is important for Vision to correctly interpret the image.
        let handler = VNImageRequestHandler(cgImage: cgImage, orientation: .up)

        // 5. Perform the Vision request on a background thread.
        // Vision requests are typically asynchronous and should not block the main thread.
        Task.detached {
            do {
                try handler.perform([request])
            } catch {
                // Handle errors during the Vision request execution
                Task { @MainActor in
                    self.resultLabel.text = "Classification failed: \(error.localizedDescription)"
                    self.classifyButton.isEnabled = true
                }
                print("Failed to perform classification request: \(error.localizedDescription)")
            }
        }
    }

    /// Processes the results from the VNCoreMLRequest.
    /// This method is called within the request's completion handler.
    /// - Parameters:
    ///   - request: The completed Vision request.
    ///   - error: An error if the request failed.
    private func processClassificationResults(for request: VNRequest, error: Error?) {
        classifyButton.isEnabled = true // Re-enable button

        if let error = error {
            resultLabel.text = "Classification Error: \(error.localizedDescription)"
            print("Classification error: \(error.localizedDescription)")
            return
        }

        guard let observations = request.results as? [VNClassificationObservation] else {
            resultLabel.text = "No classification results."
            print("Vision request did not return VNClassificationObservation results.")
            return
        }

        // 6. Extract and display the top classification result.
        // Observations are typically sorted by confidence.
        if let bestObservation = observations.first {
            let confidencePercentage = String(format: "%.2f%%", bestObservation.confidence * 100)
            let resultText = "Result: \(bestObservation.identifier) (\(confidencePercentage))"
            resultLabel.text = resultText
            print("Classification successful: \(resultText)")
        } else {
            resultLabel.text = "No confident classification found."
            print("No confident classification observation found.")
        }
    }
}
