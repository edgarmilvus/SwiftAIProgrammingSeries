
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit

@available(iOS 18.0, *)
class EmailComposerViewController: UIViewController {

    private let emailBodyTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        // Configure writing tools behavior here
        textView.writingToolsBehavior = .init(.email) // Explicitly set email context for writing tools
        return textView
    }()

    private let subjectTextField: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Subject"
        textField.borderStyle = .roundedRect
        textField.font = UIFont.preferredFont(forTextStyle: .headline)
        // Optionally, you could also apply writing tools behavior to the subject field, e.g., .automatic
        // textField.writingToolsBehavior = .automatic
        return textField
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "New Email"

        setupUI()
    }

    private func setupUI() {
        view.addSubview(subjectTextField)
        view.addSubview(emailBodyTextView)

        NSLayoutConstraint.activate([
            subjectTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            subjectTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            subjectTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            subjectTextField.heightAnchor.constraint(equalToConstant: 44),

            emailBodyTextView.topAnchor.constraint(equalTo: subjectTextField.bottomAnchor, constant: 20),
            emailBodyTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            emailBodyTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            emailBodyTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }
}
