
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreML // Needed for the generated model class

// Make sure you have MobileNetV3.mlmodel added to your project.
// You can download it from Apple's Core ML Models page.

class ObjectClassificationViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var classificationTextLayer: CATextLayer!
    private var visionRequest: VNCoreMLRequest!

    // For optional smoothing:
    private var classificationHistory: [String: Int] = [:]
    private let historyCapacity = 5 // Number of frames to consider for smoothing
    private var frameCount = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCoreMLModel()
        setupCamera()
        setupClassificationOverlay()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        videoPreviewLayer?.frame = view.bounds
        // Position text layer at the top
        classificationTextLayer?.frame = CGRect(x: 0, y: view.safeAreaInsets.top + 10, width: view.bounds.width, height: 30)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            DispatchQueue.global(qos: .userInitiated).async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    private func setupCoreMLModel() {
        do {
            // Replace 'MobileNetV3' with the name of your Core ML model class
            let coreMLModel = try VNCoreMLModel(for: MobileNetV3().model)
            visionRequest = VNCoreMLRequest(model: coreMLModel) { [weak self] request, error in
                guard let self = self else { return }
                if let error = error {
                    print("Core ML classification error: \(error.localizedDescription)")
                    return
                }
                self.processClassifications(for: request.results as? [VNClassificationObservation])
            }
            // Set up request to scale the image to the model's input size
            visionRequest.imageCropAndScaleOption = .centerCrop
        } catch {
            print("Failed to load Core ML model: \(error)")
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get the camera device.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                print("Could not add video input to the session")
                return
            }
        } catch {
            print("Could not create video device input: \(error)")
            return
        }

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue", qos: .userInitiated))
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output to the session")
            return
        }

        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }

        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.frame = view.bounds
        view.layer.addSublayer(videoPreviewLayer)
    }

    private func setupClassificationOverlay() {
        classificationTextLayer = CATextLayer()
        classificationTextLayer.foregroundColor = UIColor.white.cgColor
        classificationTextLayer.backgroundColor = UIColor.black.withAlphaComponent(0.6).cgColor
        classificationTextLayer.fontSize = 16
        classificationTextLayer.alignmentMode = .center
        classificationTextLayer.contentsScale = UIScreen.main.scale
        classificationTextLayer.cornerRadius = 8.0
        classificationTextLayer.string = "Point camera at object..."
        videoPreviewLayer.addSublayer(classificationTextLayer)
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Perform Vision request on a background thread
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        do {
            try imageRequestHandler.perform([visionRequest])
        } catch {
            print("Failed to perform Core ML Vision request: \(error)")
        }
    }

    private func processClassifications(for observations: [VNClassificationObservation]?) {
        guard let observations = observations, !observations.isEmpty else {
            DispatchQueue.main.async {
                self.classificationTextLayer.string = "No classification"
            }
            return
        }

        // Get the top classification
        let topClassification = observations[0]
        let label = topClassification.identifier
        let confidence = topClassification.confidence

        // Optional: Smoothing results over a few frames
        DispatchQueue.main.async {
            self.frameCount += 1
            if self.frameCount > self.historyCapacity {
                // Remove oldest entry if capacity exceeded
                if let oldestLabel = self.classificationHistory.keys.first {
                    self.classificationHistory[oldestLabel]? -= 1
                    if self.classificationHistory[oldestLabel] == 0 {
                        self.classificationHistory[oldestLabel] = nil
                    }
                }
            }
            self.classificationHistory[label, default: 0] += 1

            // Find the most frequent label in history
            let mostFrequent = self.classificationHistory.max { $0.value < $1.value }
            let displayLabel = mostFrequent?.key ?? label
            let displayConfidence = mostFrequent != nil ? confidence : topClassification.confidence

            let classificationString = String(format: "%@ (%.1f%%)", displayLabel, displayConfidence * 100)
            self.classificationTextLayer.string = classificationString
        }
    }
}
