
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Example of an Observable status object managed by the actor
@available(iOS 17.0, macOS 14.0, *)
@Observable
class InferenceStatus {
    var isRunning: Bool = false
    var currentProgress: Double = 0.0 // 0.0 to 1.0
    var lastError: String? = nil
    var currentToken: String = ""
}

@available(iOS 18.0, macOS 15.0, *)
actor InferenceEngine {
    // ... (llamaContext and init from above) ...
    let status = InferenceStatus() // The actor owns and updates this observable object

    func generate(prompt: String, maxTokens: Int) async throws -> String {
        await MainActor.run { // Ensure UI-related updates are on main actor
            status.isRunning = true
            status.currentProgress = 0.0
            status.lastError = nil
            status.currentToken = ""
        }

        // Simulate work and progress updates
        let totalSteps = 10
        var generatedTokens = [String]()
        for i in 0..<totalSteps {
            await Task.sleep(for: .milliseconds(200)) // Simulate token generation
            let token = "token_\(i+1)"
            generatedTokens.append(token)
            await MainActor.run {
                status.currentProgress = Double(i + 1) / Double(totalSteps)
                status.currentToken = token
            }
        }

        await MainActor.run {
            status.isRunning = false
            status.currentProgress = 1.0
        }
        return generatedTokens.joined(separator: " ")
    }
    // ... (streamGenerate method could also update status) ...
}

@available(iOS 18.0, macOS 15.0, *)
struct InferenceStatusView: View {
    let engineStatus: InferenceStatus // Observe the status object directly

    var body: some View {
        VStack(alignment: .leading) {
            Text("Inference Status: \(engineStatus.isRunning ? "Running" : "Idle")")
            ProgressView(value: engineStatus.currentProgress)
                .opacity(engineStatus.isRunning ? 1 : 0)
            if !engineStatus.currentToken.isEmpty {
                Text("Last Token: \(engineStatus.currentToken)")
            }
            if let error = engineStatus.lastError {
                Text("Error: \(error)")
                    .foregroundStyle(.red)
            }
        }
        .padding()
    }
}
