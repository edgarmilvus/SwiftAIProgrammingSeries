
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AVFoundation
import Speech

// MARK: - VoiceMemoViewController

@MainActor
class VoiceMemoViewController: UIViewController, SFSpeechRecognizerDelegate, AVAudioPlayerDelegate, UIDocumentPickerDelegate {

    // MARK: - UI Elements
    private let importButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Import Audio & Transcribe", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let searchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.placeholder = "Search keywords..."
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        searchBar.isHidden = true // Hidden until transcription is loaded
        return searchBar
    }()

    private let transcriptionTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.isEditable = false
        textView.isSelectable = true // Allows tapping on attributed text
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Import an audio file to transcribe and search."
        return textView
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready to import."
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var currentTranscription: SFTranscription?
    private var audioFileURL: URL?

    // MARK: - Audio Playback Properties
    private var audioPlayer: AVAudioPlayer?
    private var highlightedSegments: [(segment: SFTranscriptionSegment, range: NSRange)] = []

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestSpeechRecognitionPermission()
        transcriptionTextView.delegate = self // Set delegate for tap handling
        searchBar.delegate = self
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(importButton)
        view.addSubview(statusLabel)
        view.addSubview(searchBar)
        view.addSubview(transcriptionTextView)

        NSLayoutConstraint.activate([
            importButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            importButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            importButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            importButton.heightAnchor.constraint(equalToConstant: 50),

            statusLabel.topAnchor.constraint(equalTo: importButton.bottomAnchor, constant: 10),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 25),

            searchBar.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 10),
            searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            transcriptionTextView.topAnchor.constraint(equalTo: searchBar.bottomAnchor, constant: 10),
            transcriptionTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            transcriptionTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            transcriptionTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        importButton.addTarget(self, action: #selector(importAudioTapped), for: .touchUpInside)
    }

    // MARK: - Speech Recognition Setup & Permissions
    private func setupSpeechRecognizer() {
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US")) // Default to en-US
        speechRecognizer?.delegate = self
    }

    private func requestSpeechRecognitionPermission() {
        Task {
            let status = await SFSpeechRecognizer.requestAuthorization()
            if status != .authorized {
                self.showPermissionAlert(message: "Speech recognition access is required for transcription.")
                importButton.isEnabled = false
                statusLabel.text = "Permissions denied. Check settings."
            } else {
                importButton.isEnabled = true
                statusLabel.text = "Ready to import audio for transcription."
            }
        }
    }

    private func showPermissionAlert(message: String) {
        let alert = UIAlertController(title: "Permission Required", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    // MARK: - Audio File Import
    @objc private func importAudioTapped() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.audio])
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true, completion: nil)
    }

    // MARK: - UIDocumentPickerDelegate
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let selectedURL = urls.first else { return }
        
        // Copy the file to a temporary location in the app's sandbox
        let tempDir = FileManager.default.temporaryDirectory
        let destinationURL = tempDir.appendingPathComponent(selectedURL.lastPathComponent)

        do {
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.copyItem(at: selectedURL, to: destinationURL)
            self.audioFileURL = destinationURL
            statusLabel.text = "Audio file imported. Transcribing..."
            transcribeAudioFile(url: destinationURL)
        } catch {
            print("Error copying audio file: \(error)")
            statusLabel.text = "Error importing audio: \(error.localizedDescription)"
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        statusLabel.text = "Audio import cancelled."
    }

    // MARK: - Transcription Logic
    private func transcribeAudioFile(url: URL) {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            statusLabel.text = "Speech recognizer unavailable or permissions denied."
            return
        }

        // Cancel any existing task
        recognitionTask?.cancel()
        recognitionTask = nil
        currentTranscription = nil
        transcriptionTextView.text = "Transcribing \(url.lastPathComponent)..."
        searchBar.isHidden = true // Hide search bar during transcription

        let request = SFSpeechURLRecognitionRequest(url: url)
        request.shouldReportPartialResults = false // We want the final, full transcription with segments

        recognitionTask = speechRecognizer.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }

            self.recognitionTask = nil // Task completed or failed

            if let result = result {
                self.currentTranscription = result.bestTranscription
                self.displayTranscription(self.currentTranscription)
                self.statusLabel.text = "Transcription complete for \(url.lastPathComponent)."
                self.searchBar.isHidden = false
                self.searchBar.text = nil // Clear previous search
                self.highlightedSegments.removeAll() // Clear previous highlights
            } else if let error = error {
                self.statusLabel.text = "Transcription failed: \(error.localizedDescription)"
                self.transcriptionTextView.text = "Transcription failed: \(error.localizedDescription)"
                self.searchBar.isHidden = true
            }
        }
    }

    private func displayTranscription(_ transcription: SFTranscription?) {
        guard let transcription = transcription else {
            transcriptionTextView.text = "No transcription available."
            return
        }
        
        let attributedString = NSMutableAttributedString(string: transcription.formattedString)
        let fullRange = NSRange(location: 0, length: attributedString.length)
        attributedString.addAttribute(.font, value: UIFont.systemFont(ofSize: 18), range: fullRange)
        attributedString.addAttribute(.foregroundColor, value: UIColor.label, range: fullRange)
        
        // Add tap gesture recognizer for audio navigation
        attributedString.addAttribute(.accessibilityURL, value: "audioTap", range: fullRange) // Dummy URL to make text tappable

        transcriptionTextView.attributedText = attributedString
    }
    
    // MARK: - Keyword Spotting & Highlighting
    private func highlightKeywords(keyword: String) {
        guard let transcription = currentTranscription else { return }
        
        let attributedString = NSMutableAttributedString(string: transcription.formattedString)
        let fullRange = NSRange(location: 0, length: attributedString.length)
        attributedString.addAttribute(.font, value: UIFont.systemFont(ofSize: 18), range: fullRange)
        attributedString.addAttribute(.foregroundColor, value: UIColor.label, range: fullRange)
        
        highlightedSegments.removeAll() // Clear previous highlights

        let searchLowercased = keyword.lowercased()
        var currentOffset = 0

        for segment in transcription.segments {
            let segmentText = segment.substring.trimmingCharacters(in: .whitespacesAndNewlines)
            let segmentRangeInFormattedString = (transcription.formattedString as NSString).range(of: segmentText, options: [], range: NSRange(location: currentOffset, length: transcription.formattedString.count - currentOffset))

            if segmentRangeInFormattedString.location != NSNotFound {
                if segmentText.lowercased().contains(searchLowercased) {
                    attributedString.addAttribute(.backgroundColor, value: UIColor.systemYellow.withAlphaComponent(0.5), range: segmentRangeInFormattedString)
                    highlightedSegments.append((segment: segment, range: segmentRangeInFormattedString))
                }
                currentOffset = segmentRangeInFormattedString.location + segmentRangeInFormattedString.length
            }
        }
        
        transcriptionTextView.attributedText = attributedString
    }

    // MARK: - Audio Navigation
    private func playAudio(from timestamp: TimeInterval) {
        guard let audioURL = audioFileURL else {
            statusLabel.text = "No audio file available to play."
            return
        }

        if audioPlayer?.isPlaying == true {
            audioPlayer?.stop()
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: audioURL)
            audioPlayer?.delegate = self
            audioPlayer?.currentTime = timestamp
            audioPlayer?.play()
            statusLabel.text = "Playing audio from \(String(format: "%.1f", timestamp))s..."
        } catch {
            print("Error playing audio: \(error)")
            statusLabel.text = "Error playing audio: \(error.localizedDescription)"
        }
    }

    // MARK: - AVAudioPlayerDelegate
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        statusLabel.text = "Audio playback finished."
    }

    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        statusLabel.text = "Audio playback error: \(error?.localizedDescription ?? "Unknown error")"
    }

    // MARK: - SFSpeechRecognizerDelegate (for availability changes)
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            importButton.isEnabled = true
            statusLabel.text = "Ready to import audio for transcription."
        } else {
            importButton.isEnabled = false
            statusLabel.text = "Speech recognition currently unavailable."
        }
    }
}

// MARK: - UITextViewDelegate for Tappable Text
extension VoiceMemoViewController: UITextViewDelegate, UISearchBarDelegate {
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        // This is a workaround to make attributed text tappable.
        // We capture the tap and then find which segment was tapped.
        if URL.absoluteString == "audioTap" {
            // Find which segment was tapped
            for (segment, range) in highlightedSegments {
                if NSIntersectionRange(characterRange, range).length > 0 { // Check if the tap range intersects with a highlighted segment
                    playAudio(from: segment.timestamp)
                    return false // Handled
                }
            }
            // If no highlighted segment was tapped, but a general tap occurred on the transcription
            // Find the closest segment to the tap location and play from there
            if let transcription = currentTranscription {
                let tapLocation = textView.offset(from: textView.beginningOfDocument, to: textView.selectedTextRange!.start)
                var closestSegment: SFTranscriptionSegment?
                var minDistance = Int.max

                for segment in transcription.segments {
                    let segmentRange = (transcription.formattedString as NSString).range(of: segment.substring) // This range finding is naive, better to use stored ranges if available
                    if segmentRange.location != NSNotFound {
                        let distance = abs(segmentRange.location - tapLocation)
                        if distance < minDistance {
                            minDistance = distance
                            closestSegment = segment
                        }
                    }
                }
                if let segment = closestSegment {
                     playAudio(from: segment.timestamp)
                     return false
                }
            }
        }
        return true // Let other URLs be handled normally
    }
    
    // MARK: - UISearchBarDelegate
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        if let searchText = searchBar.text, !searchText.isEmpty {
            highlightKeywords(keyword: searchText)
        } else {
            // If search bar is empty, display original transcription without highlights
            displayTranscription(currentTranscription)
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Live search/highlight as user types (optional, but good UX)
        if !searchText.isEmpty {
            highlightKeywords(keyword: searchText)
        } else {
            displayTranscription(currentTranscription) // Clear highlights
        }
    }
}
