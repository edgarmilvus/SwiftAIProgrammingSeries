
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    actor ModelTrainer {
        private var model: SimpleLinearModel
        private var optimizer: Adam

        init(inputFeatures: Int, outputFeatures: Int, learningRate: Float) {
            self.model = SimpleLinearModel(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
            self.optimizer = Adam(learningRate: learningRate)
        }

        func train(x_data: MLXArray, y_data: MLXArray, epochs: Int) async {
            for epoch in 0..<epochs {
                let (loss, gradients) = valueAndGradient(mseLoss)(model, x_data, y_data)
                optimizer.update(model: model, gradients: gradients)
                MLXArray.eval(model.parameters(), optimizer.parameters())
                print("Actor - Epoch \(epoch), Loss: \(loss.item())")
                await Task.yield() // Allow other tasks to run
            }
        }

        func getModelParameters() -> [String: MLXArray] {
            // Return a copy or snapshot of parameters for external use
            return model.parameters()
        }
    }

    // Usage:
    // let trainer = ModelTrainer(inputFeatures: 10, outputFeatures: 1, learningRate: 0.01)
    // Task {
    //     await trainer.train(x_data: x_data, y_data: y_data, epochs: 5)
    // }
    