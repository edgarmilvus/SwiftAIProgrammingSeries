
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

    // DocInsightCore/DocInsightErrors.swift
    import Foundation

    /// Custom error types for the DocInsight application.
    enum DocInsightError: Error, LocalizedError {
        case documentProcessingFailed(description: String)
        case ocrFailed(description: String)
        case intelligenceServiceUnavailable
        case intelligenceRequestFailed(description: String)
        case invalidTextForRefinement
        case missingDataForContextualAction

        var errorDescription: String? {
            switch self {
            case .documentProcessingFailed(let desc):
                return "Document processing failed: \(desc)"
            case .ocrFailed(let desc):
                return "Optical Character Recognition failed: \(desc)"
            case .intelligenceServiceUnavailable:
                return "Apple Intelligence service is currently unavailable. Requires iOS 18 or later."
            case .intelligenceRequestFailed(let desc):
                return "Apple Intelligence request failed: \(desc)"
            case .invalidTextForRefinement:
                return "Invalid text provided for refinement."
            case .missingDataForContextualAction:
                return "Missing data to propose contextual actions."
            }
        }
    }
    