
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import SwiftData
import Foundation

// MARK: - SwiftData Models (from Exercise 1, repeated for completeness)

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Conversation {
    var id: UUID
    var title: String
    var creationDate: Date
    @Relationship(deleteRule: .cascade, inverse: \Message.conversation)
    var messages: [Message]

    init(id: UUID = UUID(), title: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.creationDate = creationDate
        self.messages = []
    }
}

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Message {
    var id: UUID
    var content: String
    var timestamp: Date
    var isFromUser: Bool
    var conversation: Conversation? // Inverse relationship

    init(id: UUID = UUID(), content: String, timestamp: Date = Date(), isFromUser: Bool) {
        self.id = id
        self.content = content
        self.timestamp = timestamp
        self.isFromUser = isFromUser
    }
}

// MARK: - AI Simulation Utility

@available(iOS 18.0, macOS 15.0, *)
func simulateAITokenStream(fullResponse: String, delay: Duration) -> AsyncStream<String> {
    AsyncStream { continuation in
        Task {
            let words = fullResponse.split(separator: " ").map(String.init)
            for word in words {
                try? await Task.sleep(for: delay)
                continuation.yield(word + " ") // Add space back
            }
            continuation.finish()
        }
    }
}

// MARK: - SwiftUI Views

@available(iOS 18.0, macOS 15.0, *)
struct ConversationDetailView: View {
    @Environment(\.modelContext) private var modelContext
    let conversation: Conversation

    @Query private var messages: [Message]
    @State private var newMessageContent: String = ""
    @State private var isStreamingAIResponse: Bool = false

    init(conversation: Conversation) {
        self.conversation = conversation
        _messages = Query(
            filter: #Predicate<Message> { $0.conversation?.id == conversation.id },
            sort: \.timestamp
        )
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                List {
                    ForEach(messages) { message in
                        HStack {
                            if message.isFromUser {
                                Spacer()
                                Text(message.content)
                                    .padding()
                                    .background(Color.blue.opacity(0.8))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            } else {
                                Text(message.content)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                            }
                        }
                        .listRowSeparator(.hidden)
                        .id(message.id)
                    }
                }
                .listStyle(.plain)
                .onChange(of: messages.count) { oldVal, newVal in
                    if newVal > oldVal, let lastMessage = messages.last {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
                .onChange(of: messages.last?.content) { _, _ in
                    // Scroll to bottom if the last message (AI response) is updating
                    if let lastMessage = messages.last, !lastMessage.isFromUser {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }

            HStack {
                TextField("Type a message...", text: $newMessageContent)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    sendUserMessageAndStreamAIResponse()
                }
                .disabled(newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isStreamingAIResponse)
            }
            .padding()
        }
        .navigationTitle(conversation.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func sendUserMessageAndStreamAIResponse() {
        guard !newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        // 1. Create and persist user message
        let userMessage = Message(content: newMessageContent, isFromUser: true)
        conversation.messages.append(userMessage)
        modelContext.insert(userMessage)
        let userMessageContent = newMessageContent // Capture for AI simulation
        newMessageContent = "" // Clear input field

        // 2. Create and persist placeholder AI message
        let aiMessage = Message(content: "", isFromUser: false)
        conversation.messages.append(aiMessage)
        modelContext.insert(aiMessage)

        isStreamingAIResponse = true

        // 3. Simulate AI streaming and update the AI message
        Task {
            // Simulate a slightly different AI response based on user input for realism
            let aiFullResponse = "Okay, you asked about '\(userMessageContent)'. Here is a detailed answer that should help you understand it completely."
            for await token in simulateAITokenStream(fullResponse: aiFullResponse, delay: .milliseconds(70)) {
                // Update the content of the *same* AI message object
                // SwiftData on MainActor automatically propagates changes to UI
                aiMessage.content += token
            }
            isStreamingAIResponse = false
        }
    }

    // `deleteMessages` from Exercise 2 would also be here, omitted for brevity.
}

// ContentView, NewConversationView, and AIApp (from Exercise 1/2) remain unchanged.
// For brevity, not repeated here but would be part of the full app.
// @available(iOS 18.0, macOS 15.0, *) @main struct AIApp: App { ... }
