
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation // For UserDefaults

// MARK: - AppEnum for Photo Filters

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
enum PhotoFilter: String, AppEnum, CaseIterable, Identifiable {
    case sepia = "Sepia"
    case blackAndWhite = "Black & White"
    case vintage = "Vintage"
    case vibrant = "Vibrant"
    case blur = "Blur" // Added another filter for variety

    var id: String { rawValue } // Conformance to Identifiable

    // Defines how the enum type itself is displayed in Shortcuts
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Photo Filter"

    // Defines how each case of the enum is displayed in Shortcuts
    static var caseDisplayRepresentations: [PhotoFilter: DisplayRepresentation] = [
        .sepia: "Sepia",
        .blackAndWhite: "Black & White",
        .vintage: "Vintage",
        .vibrant: "Vibrant",
        .blur: "Blur"
    ]
}

// MARK: - App Intent

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct SetPhotoFilterIntent: AppIntent {
    static var title: LocalizedStringResource = "Set Photo Filter"
    static var description = IntentDescription("Applies a specific photo filter in the PhotoFilter app.")

    // The parameter uses the PhotoFilter AppEnum type, which automatically provides dynamic choices.
    @Parameter(title: "Filter Type", description: "The photo filter to apply.")
    var filter: PhotoFilter

    func perform() async throws -> some IntentResult {
        // Simulate saving the selected filter to UserDefaults
        UserDefaults.standard.set(filter.rawValue, forKey: "selectedPhotoFilter")

        // In a real app, you might also trigger a UI update or a background process
        // to actually apply the filter to photos.
        print("Photo filter set to \(filter.rawValue). Current setting: \(UserDefaults.standard.string(forKey: "selectedPhotoFilter") ?? "None")")

        return .result(dialog: "Photo filter set to \(filter.rawValue).")
    }
}

// MARK: - AppIntent Extension (for discoverability)

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct PhotoFilterAppIntents: AppIntentExtension {
    static var appName: LocalizedStringResource = "PhotoFilter"
    static var category: IntentCategory = .mediaAndPhotos
}
