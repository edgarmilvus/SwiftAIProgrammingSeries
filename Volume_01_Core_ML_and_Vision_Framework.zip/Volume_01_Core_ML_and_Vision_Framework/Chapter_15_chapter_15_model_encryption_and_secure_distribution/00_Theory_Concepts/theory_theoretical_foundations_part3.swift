
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import CoreML

@available(iOS 18.0, *)
@Observable
class ModelLoadingViewModel {
    enum LoadingState {
        case idle
        case loading
        case loaded(MLModel)
        case failed(Error)
    }

    private(set) var state: LoadingState = .idle
    private let secureModelStore: SecureModelStore // Injected dependency

    init(secureModelStore: SecureModelStore) {
        self.secureModelStore = secureModelStore
    }

    @MainActor // Ensure UI updates are on the main actor
    func loadModel() async {
        guard case .idle = state else { return } // Prevent multiple loading attempts
        state = .loading

        do {
            let model = try await secureModelStore.getModel()
            state = .loaded(model)
        } catch {
            state = .failed(error)
            print("Error loading model: \(error.localizedDescription)")
        }
    }
}

// Example SwiftUI View (conceptual)
@available(iOS 18.0, *)
struct ModelLoadingView: View {
    @State private var viewModel: ModelLoadingViewModel

    init(secureModelStore: SecureModelStore) {
        _viewModel = State(initialValue: ModelLoadingViewModel(secureModelStore: secureModelStore))
    }

    var body: some View {
        VStack {
            switch viewModel.state {
            case .idle:
                Text("Tap to load secure model.")
                Button("Load Model") {
                    Task { await viewModel.loadModel() }
                }
            case .loading:
                ProgressView("Loading secure model...")
            case .loaded(_):
                Text("Model ready for inference!")
                // You could pass the model to another view or use it here
                Button("Perform Inference") {
                    // Trigger inference using the loaded model
                }
            case .failed(let error):
                Text("Failed to load model: \(error.localizedDescription)")
                    .foregroundColor(.red)
                Button("Retry") {
                    Task { await viewModel.loadModel() }
                }
            }
        }
        .padding()
    }
}
