
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

// A model for an AI prediction
struct AIPrediction {
    let label: String // e.g., "Object", "Sentiment"
    let value: String // e.g., "Dog", "Positive (92%)"
    let confidence: Double? // e.g., 0.98
    let isInteractive: Bool // Does tapping it reveal more details?
    let hint: String? // Optional hint for interactive cards
}

struct AIPredictionCardView: View {
    let prediction: AIPrediction

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(prediction.label)
                .font(.caption)
                .foregroundColor(.secondary)
                .accessibilityHidden(true) // Label is part of the overall card description

            Text(prediction.value)
                .font(.headline) // Supports Dynamic Type
                .fontWeight(.bold)
                .minimumScaleFactor(0.7) // Allows text to shrink if needed
                .lineLimit(1) // Prevents text from wrapping excessively
        }
        .padding()
        .background(Color.accentColor.opacity(0.1))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal, 4) // Spacing between cards
        // MARK: - Accessibility Modifiers
        .accessibilityElement(children: .ignore) // Treat the entire card as a single accessibility element
        .accessibilityLabel(cardAccessibilityLabel) // Concise summary
        .accessibilityValue(cardAccessibilityValue) // The primary value
        .accessibilityAddTraits(prediction.isInteractive ? .isButton : []) // Add .isButton trait if interactive
        .accessibilityHint(prediction.hint ?? (prediction.isInteractive ? "Double tap for more details." : nil)) // Provide a hint if interactive
        .contentShape(Rectangle()) // Ensure the whole card is tappable for VoiceOver
        .onTapGesture {
            if prediction.isInteractive {
                print("Tapped on interactive prediction: \(prediction.label) - \(prediction.value)")
                // In a real app, this would trigger navigation or show a detail view
            }
        }
    }

    // Computed property for accessibilityLabel
    private var cardAccessibilityLabel: String {
        var label = "\(prediction.label): \(prediction.value)"
        if let confidence = prediction.confidence {
            let percentage = Int(confidence * 100)
            label += ", \(percentage) percent confidence"
        }
        return label
    }

    // Computed property for accessibilityValue (often just the main value)
    private var cardAccessibilityValue: String {
        prediction.value
    }
}

struct AIPredictionCardsDemoView: View {
    let predictions: [AIPrediction] = [
        AIPrediction(label: "Object", value: "Dog", confidence: 0.98, isInteractive: true, hint: "Tap to see bounding box."),
        AIPrediction(label: "Sentiment", value: "Positive (92%)", confidence: 0.92, isInteractive: false, hint: nil),
        AIPrediction(label: "Summary", value: "Brief overview of the document content.", confidence: nil, isInteractive: true, hint: "Tap to read full summary."),
        AIPrediction(label: "Emotion", value: "Joyful", confidence: 0.85, isInteractive: false, hint: nil)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text("AI Insights")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.bottom, 10)

                    ForEach(predictions.indices, id: \.self) { index in
                        AIPredictionCardView(prediction: predictions[index])
                    }
                }
                .padding()
            }
            .navigationTitle("AI Predictions")
        }
    }
}

// Preview Provider
struct AIPredictionCardsDemoView_Previews: PreviewProvider {
    static var previews: some View {
        AIPredictionCardsDemoView()
            .environment(\.dynamicTypeSize, .large) // Test with larger text size
    }
}
