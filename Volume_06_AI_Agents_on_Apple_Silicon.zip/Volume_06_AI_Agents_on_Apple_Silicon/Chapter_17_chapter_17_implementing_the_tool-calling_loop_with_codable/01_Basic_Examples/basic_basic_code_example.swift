
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation

// MARK: - 1. Define Codable Structures for Tool Calls

/// Represents the arguments for the 'get_current_weather' tool.
/// In a real-world scenario, you might have different argument structs for different tools.
struct WeatherArguments: Codable {
    let location: String
    let unit: String? // Optional, e.g., "celsius" or "fahrenheit"

    // Custom CodingKeys can be used if JSON keys differ from Swift property names.
    // In this case, they match, but it's good practice to show.
    enum CodingKeys: String, CodingKey {
        case location
        case unit
    }
}

/// Represents a specific function call within a tool.
/// This structure holds the name of the function and its arguments.
struct FunctionCall: Codable {
    let name: String
    let arguments: WeatherArguments // For simplicity, we directly embed WeatherArguments.
                                   // In more complex cases, 'arguments' might be a raw JSON string
                                   // requiring a second decoding step (see Pitfalls).

    enum CodingKeys: String, CodingKey {
        case name
        case arguments
    }
}

/// Represents a single tool call suggested by the LLM.
/// This includes an ID (for tracking), a type (e.g., "function"), and the function details.
struct ToolCall: Codable {
    let id: String
    let type: String // Typically "function" for function calling
    let function: FunctionCall

    enum CodingKeys: String, CodingKey {
        case id
        case type
        case function
    }
}

/// The top-level structure for the LLM's response payload.
/// It contains a textual message and an optional array of tool calls.
struct AgentResponse: Codable {
    let message: String
    let toolCalls: [ToolCall]? // Optional, as not every response will include tool calls

    enum CodingKeys: String, CodingKey {
        case message
        case toolCalls = "tool_calls" // Map "tool_calls" from JSON to 'toolCalls' in Swift
    }
}

// MARK: - 2. Simulate an LLM's JSON Response

/// This JSON string mimics what an LLM might return when it decides to call a tool.
/// Notice the "tool_calls" array containing a function call.
let simulatedLLMResponseJSON = """
{
  "message": "I need to get the current weather conditions.",
  "tool_calls": [
    {
      "id": "call_12345",
      "type": "function",
      "function": {
        "name": "get_current_weather",
        "arguments": {
          "location": "Cupertino, CA",
          "unit": "fahrenheit"
        }
      }
    }
  ]
}
"""

/// This JSON string mimics an LLM response without any tool calls.
let simulatedLLMTextResponseJSON = """
{
  "message": "The sun is shining today! How can I help you further?",
  "tool_calls": null
}
"""

// MARK: - 3. Implement Parsing Logic

/// A simple class to demonstrate parsing and handling agent responses.
class ChatAgentViewModel {
    /// Processes a raw JSON string from the LLM, decodes it, and dispatches actions.
    /// - Parameter jsonString: The JSON string received from the LLM.
    func processAgentResponse(jsonString: String) {
        guard let jsonData = jsonString.data(using: .utf8) else {
            print("Error: Could not convert JSON string to Data.")
            return
        }

        let decoder = JSONDecoder()

        do {
            let agentResponse = try decoder.decode(AgentResponse.self, from: jsonData)
            print("\n--- Agent Response Processed ---")
            print("Agent Message: \(agentResponse.message)")

            if let toolCalls = agentResponse.toolCalls, !toolCalls.isEmpty {
                print("Tool Calls detected!")
                for toolCall in toolCalls {
                    print("  - Tool ID: \(toolCall.id)")
                    print("  - Tool Type: \(toolCall.type)")
                    print("  - Function Name: \(toolCall.function.name)")
                    print("  - Function Arguments: Location='\(toolCall.function.arguments.location)', Unit='\(toolCall.function.arguments.unit ?? "N/A")'")

                    // MARK: - 4. Simulate Tool Dispatch (Execution)

                    // In a real app, this would involve calling a specific service or method.
                    // We'll use a simple switch statement for demonstration.
                    switch toolCall.function.name {
                    case "get_current_weather":
                        print("    -> Dispatching 'get_current_weather' tool...")
                        // In a real app, you'd call a weather service here:
                        // WeatherService.shared.fetchWeather(location: toolCall.function.arguments.location, unit: toolCall.function.arguments.unit)
                        print("    [Simulated] Fetching weather for \(toolCall.function.arguments.location) with unit \(toolCall.function.arguments.unit ?? "default")...")
                        // After tool execution, you'd typically feed the result back to the LLM
                        // to generate a human-readable response.
                        print("    [Simulated] Weather data received and processed.")
                    case "send_email":
                        print("    -> Dispatching 'send_email' tool (not implemented in this example).")
                    default:
                        print("    -> Unknown tool: \(toolCall.function.name).")
                    }
                }
            } else {
                print("No tool calls detected. Responding with message only.")
            }
        } catch {
            print("\nError decoding LLM response: \(error)")
            // Detailed error logging for debugging
            if let decodingError = error as? DecodingError {
                switch decodingError {
                case .dataCorrupted(let context):
                    print("  Data corrupted: \(context.debugDescription)")
                case .keyNotFound(let key, let context):
                    print("  Key '\(key)' not found: \(context.debugDescription)")
                case .typeMismatch(let type, let context):
                    print("  Type mismatch for '\(type)': \(context.debugDescription)")
                case .valueNotFound(let type, let context):
                    print("  Value not found for '\(type)': \(context.debugDescription)")
                @unknown default:
                    print("  Unknown decoding error.")
                }
            }
        }
    }
}

// MARK: - 5. Demonstrate in a Simulated Chat Flow

/// Create an instance of our ViewModel.
let chatViewModel = ChatAgentViewModel()

print("--- Scenario 1: LLM requests a tool call ---")
chatViewModel.processAgentResponse(jsonString: simulatedLLMResponseJSON)

print("\n--- Scenario 2: LLM responds with text only ---")
chatViewModel.processAgentResponse(jsonString: simulatedLLMTextResponseJSON)

print("\n--- Scenario 3: Invalid JSON (simulating an error) ---")
let invalidJSON = "{ \"message\": \"This is broken\", \"tool_calls\": [ { \"id\": \"1\", \"type\": \"function\", \"function\": { \"name\": \"broken_tool\", \"arguments\": \"not_a_dictionary\" } } ] }"
chatViewModel.processAgentResponse(jsonString: invalidJSON)

