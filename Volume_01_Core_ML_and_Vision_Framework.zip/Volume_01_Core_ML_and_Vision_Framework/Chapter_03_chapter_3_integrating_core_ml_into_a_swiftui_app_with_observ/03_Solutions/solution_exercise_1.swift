
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import PhotosUI
import CoreML
import UIKit
import VideoToolbox // Needed for CVPixelBuffer conversion

// MARK: - UIImage Extension for CVPixelBuffer Conversion

extension UIImage {
    /// Converts a UIImage to a CVPixelBuffer of a specified size and pixel format.
    /// This is crucial for feeding images into Core ML models.
    func toCVPixelBuffer(width: Int, height: Int, pixelFormat: OSType) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: AnyObject] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:] as AnyObject
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        // SqueezeNet expects BGRA 8-bit, so use .noneSkipFirst and .byteOrder32Little
        let context = CGContext(data: pixelData,
                                width: width,
                                height: height,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        guard let cgImage = self.cgImage else {
            CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        // Scale and draw the image into the context
        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

        return pixelBuffer
    }
}

// MARK: - AppState Observable Object

@Observable
class PetClassifierViewModel {
    var selectedImage: UIImage?
    var classificationResult: String?
    var confidence: String?
    var isLoading: Bool = false
    var errorMessage: String?

    // Assuming SqueezeNet.mlmodel is added to the project
    // SqueezeNet expects 227x227 image in BGRA 8-bit format
    private let modelInputWidth: Int = 227
    private let modelInputHeight: Int = 227
    private let modelInputPixelFormat: OSType = kCVPixelFormatType_32BGRA

    @MainActor
    func classifyImage(_ uiImage: UIImage) async {
        isLoading = true
        errorMessage = nil
        classificationResult = nil
        confidence = nil

        guard let pixelBuffer = uiImage.toCVPixelBuffer(width: modelInputWidth, height: modelInputHeight, pixelFormat: modelInputPixelFormat) else {
            errorMessage = "Failed to convert image for classification. Please try another image."
            isLoading = false
            return
        }

        do {
            let model = try SqueezeNet(configuration: MLModelConfiguration()) // Instantiate your Core ML model
            let input = SqueezeNetInput(image: pixelBuffer)
            let output = try await model.prediction(input: input) // Perform asynchronous inference

            // Get the top classification result
            if let (label, confidenceValue) = output.featureValue(for: "classLabelProbs")?.dictionaryValue.max(by: { $0.value.doubleValue < $1.value.doubleValue }) {
                classificationResult = label
                confidence = String(format: "%.2f%%", confidenceValue.doubleValue * 100)
            } else {
                errorMessage = "Could not interpret model output."
            }
        } catch {
            errorMessage = "Classification failed: \(error.localizedDescription)"
            print("Core ML Error: \(error)")
        }

        isLoading = false
    }
}

// MARK: - SwiftUI View

struct PetClassifierView: View {
    @State private var viewModel = PetClassifierViewModel()
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            VStack {
                if let image = viewModel.selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .cornerRadius(10)
                        .padding()
                } else {
                    Text("Select an image to classify your pet!")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding()
                }

                if viewModel.isLoading {
                    ProgressView("Classifying...")
                        .padding()
                } else if let result = viewModel.classificationResult, let conf = viewModel.confidence {
                    VStack {
                        Text("Prediction: \(result)")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("Confidence: \(conf)")
                            .font(.title3)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                } else if let error = viewModel.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                        .padding()
                }

                Spacer()

                PhotosPicker(
                    selection: $selectedPhotoItem,
                    matching: .images,
                    photoLibrary: .shared()
                ) {
                    Label("Select Photo", systemImage: "photo.on.rectangle.angled")
                        .font(.headline)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.bottom)
            }
            .navigationTitle("My Pet Classifier")
            .onChange(of: selectedPhotoItem) { newItem in
                Task {
                    viewModel.selectedImage = nil // Clear previous image
                    if let newItem {
                        do {
                            if let data = try await newItem.loadTransferable(type: Data.self),
                               let uiImage = UIImage(data: data) {
                                viewModel.selectedImage = uiImage
                                await viewModel.classifyImage(uiImage)
                            } else {
                                viewModel.errorMessage = "Could not load selected image."
                            }
                        } catch {
                            viewModel.errorMessage = "Failed to load image: \(error.localizedDescription)"
                        }
                    }
                }
            }
        }
    }
}

// To make this runnable in a preview or as the main app, you'd integrate it:
/*
@main
struct PetClassifierApp: App {
    var body: some Scene {
        WindowGroup {
            PetClassifierView()
        }
    }
}
*/
