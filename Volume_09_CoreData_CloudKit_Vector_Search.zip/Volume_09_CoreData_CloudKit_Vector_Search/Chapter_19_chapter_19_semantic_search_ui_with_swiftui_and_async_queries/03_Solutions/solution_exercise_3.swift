
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage
import CoreData

@available(iOS 18.0, *)
actor MoodSearchService {
    private let container: NSPersistentContainer
    
    init(container: NSPersistentContainer) {
        self.container = container
    }

    func searchEntries(matching moodQuery: String) async throws -> [JournalEntry] {
        // 1. Generate the embedding for the moodQuery
        guard let embedding = NLEmbedding.sentenceEmbedding(for: .english),
              let queryVector = embedding.vector(for: moodQuery) else {
            throw NSError(domain: "MoodSearch", code: 404, userInfo: [NSLocalizedDescriptionKey: "Could not generate embedding"])
        }
        
        // 2. Fetch all JournalEntry objects from Core Data
        let fetchRequest: NSFetchRequest<JournalEntry> = JournalEntry.fetchRequest()
        let context = container.viewContext
        
        // Note: In a real app, we would perform the fetch on a background context
        let allEntries = try context.fetch(fetchRequest)
        
        // 3. Calculate Cosine Similarity for each entry
        // We map the entries to a tuple of (entry, score) to keep them paired during sorting
        let scoredEntries: [(entry: JournalEntry, score: Double)] = allEntries.compactMap { entry in
            // Convert Data back to [Double]
            guard let entryVector = try? decodeVector(from: entry.vectorData) else { return nil }
            
            let similarity = cosineSimilarity(queryVector, entryVector)
            return (entry, similarity)
        }
        
        // 4. Sort by highest similarity score and return just the entries
        let sortedEntries = scoredEntries
            .sorted { $0.score > $1.score }
            .map { $0.entry }
        
        return sortedEntries
    }
    
    // MARK: - Math Helpers
    
    private func cosineSimilarity(_ a: [Double], _ b: [Double]) -> Double {
        guard a.count == b.count else { return 0.0 }
        
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0.0 }
        return dotProduct / (magnitudeA * magnitudeB)
    }
    
    private func decodeVector(from data: Data) throws -> [Double] {
        return try JSONDecoder().decode([Double].self, from: data)
    }
}

// Mock Entity for context
@available(iOS 18.0, *)
@objc(JournalEntry)
class JournalEntry: NSManagedObject, Sendable {
    @NSManaged var content: String
    @NSManaged var vectorData: Data 
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<JournalEntry> {
        return NSFetchRequest<JournalEntry>(entityName: "JournalEntry")
    }
}
