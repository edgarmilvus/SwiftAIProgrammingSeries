
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftUI
import Observation

// MARK: - Model
struct JournalEntry: Identifiable, Sendable {
    let id: UUID
    let date: Date
    let text: String
    
    var formattedForLLM: String {
        "<entry date=\"\(date.iso8601)\">\(text)</entry>"
    }
}

extension Date {
    var iso8601: String {
        let formatter = ISO8601DateFormatter()
        return formatter.string(from: self)
    }
}

// MARK: - Engine
@available(macOS 15.0, *)
struct ChronicleInsightEngine {
    
    func streamInsights(query: String, context: String) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                do {
                    let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:streamGenerateContent?key=YOUR_API_KEY")!
                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    
                    let payload: [String: Any] = [
                        "contents": [[
                            "parts": [
                                ["text": "Context: \(context)\n\nQuestion: \(query)"]
                            ]
                        ]]
                    ]
                    request.httpBody = try JSONSerialization.data(withJSONObject: payload)

                    // 1. Use URLSession.bytes to consume the stream
                    let (bytes, response) = try await URLSession.shared.bytes(for: request)
                    
                    guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                        continuation.finish(throwing: URLError(.badServerResponse))
                        return
                    }

                    // 2. Parse the SSE/Chunked stream
                    // Gemini's streaming returns a series of JSON objects in an array
                    for try await line in bytes.lines {
                        // In a real SSE implementation, we look for "data: " prefixes
                        // For Gemini's specific streaming format, we parse the JSON chunks
                        if let data = line.data(using: .utf8),
                           let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                           let candidates = json["candidates"] as? [[String: Any]],
                           let firstCandidate = candidates.first,
                           let content = firstCandidate["content"] as? [String: Any],
                           let parts = content["parts"] as? [[String: Any]],
                           let text = parts.first?["text"] as? String {
                            
                            continuation.yield(text)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }
}

// MARK: - ViewModel
@available(macOS 15.0, *)
@Observable
class InsightViewModel {
    var streamingResponse: String = ""
    var isAnalyzing: Bool = false
    
    private let engine = ChronicleInsightEngine()

    @MainActor
    func runAnalysis(query: String, entries: [JournalEntry]) async {
        isAnalyzing = true
        streamingResponse = ""
        
        do {
            // 1. Efficiently aggregate massive context
            let context = entries.map { $0.formattedForLLM }.joined(separator: "\n")
            
            // 2. Consume the AsyncThrowingStream
            let stream = engine.streamInsights(query: query, context: context)
            
            for try await chunk in stream {
                // 3. Ensure UI updates happen on the MainActor
                self.streamingResponse += chunk
            }
        } catch {
            self.streamingResponse = "Error: \(error.localizedDescription)"
        }
        isAnalyzing = false
    }
}
