
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// Manages the cumulative epsilon spent during a session.
actor PrivacyBudgetManager {
    private(set) var cumulativeEpsilon: Double = 0.0
    private let maxEpsilon: Double
    
    init(limit: Double = 10.0) {
        self.maxEpsilon = limit
    }
    
    /// Attempts to consume a portion of the privacy budget.
    /// - Parameter epsilon: The amount of epsilon to use for a query.
    /// - Returns: Boolean indicating if the budget was successfully allocated.
    func consume(epsilon: Double) -> Bool {
        if cumulativeEpsilon + epsilon <= maxEpsilon {
            cumulativeEpsilon += epsilon
            return true
        }
        return false
    }
}

/// An engine that applies mathematical noise to protect individual data points.
actor DifferentialPrivacyEngine {
    private let budgetManager = PrivacyBudgetManager(limit: 10.0)
    
    /// Generates noise using the Inverse Transform Sampling method for a Laplace distribution.
    /// Formula: L = -(sensitivity/epsilon) * sgn(U) * ln(1 - 2|U|) where U is Uniform(-0.5, 0.5)
    private func generateLaplaceNoise(sensitivity: Double, epsilon: Double) -> Double {
        let u = Double.random(in: -0.5..<0.5)
        let scale = sensitivity / epsilon
        let sgn = u < 0 ? -1.0 : 1.0
        return -scale * sgn * log(1.0 - 2.0 * abs(u))
    }
    
    /// Applies differential privacy to a value.
    /// - Parameters:
    ///   - value: The true numeric value.
    ///   - sensitivity: The maximum change one individual can cause (Delta f).
    ///   - epsilon: The privacy budget for this specific query.
    /// - Returns: The noisy value.
    func applyPrivacy(to value: Double, sensitivity: Double, epsilon: Double) async throws -> Double {
        guard await budgetManager.consume(epsilon: epsilon) else {
            throw NSError(domain: "PrivacyExhaustion", code: 403, userInfo: [NSLocalizedDescriptionKey: "Privacy budget exceeded."])
        }
        
        let noise = generateLaplaceNoise(sensitivity: sensitivity, epsilon: epsilon)
        return value + noise
    }
    
    func getRemainingBudget() async -> Double {
        return await budgetManager.cumulativeEpsilon
    }
}

// MARK: - Statistical Validation Test
func runStatisticalTest() async {
    let engine = DifferentialPrivacyEngine()
    let trueValue = 100.0
    let sensitivity = 1.0
    let epsilon = 0.5
    let iterations = 10_000
    
    var sumOfNoisyValues = 0.0
    
    print("Running 10,000 iterations to verify unbiased noise...")
    
    for _ in 0..<iterations {
        do {
            // We use a very large budget for testing purposes
            let noisyValue = try await engine.applyPrivacy(to: trueValue, sensitivity: sensitivity, epsilon: epsilon)
            sumOfNoisyValues += noisyValue
        } catch {
            continue
        }
    }
    
    let average = sumOfNoisyValues / Double(iterations)
    print("True Value: \(trueValue)")
    print("Average of Noisy Values: \(average)")
    print("Difference: \(abs(trueValue - average))")
    
    assert(abs(trueValue - average) < 1.0, "The noise is biased! The average should converge to the true value.")
    print("✅ Statistical Test Passed: Noise is unbiased.")
}

// MARK: - Main Execution
@main
struct DPApp {
    static func main() async {
        await runStatisticalTest()
    }
}
