
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import Observation

// MARK: - 1. Shared State & Requests
struct SpatialTransform: Sendable {
    var position: SIMD3<Float>
    var rotation: simd_quatf
}

struct SpatialTransformRequest: Sendable {
    let entityID: UUID
    let newTransform: SpatialTransform
    let timestamp: Date
}

// MARK: - 2. The Session Manager (The Authority)
actor SpatialSessionManager {
    // The authoritative state
    private var authoritativeState: [UUID: SpatialTransform] = [:]
    
    // Subscribers: Closures that receive updates
    private var subscribers: [UUID: (SpatialTransform) -> Void] = [:]
    
    /// Validates and applies a transform request
    func handleRequest(_ request: SpatialTransformRequest) {
        // Simple Conflict Resolution: Last-Writer-Wins based on timestamp
        // In a real app, we would check against the current authoritative timestamp
        authoritativeState[request.entityID] = request.newTransform
        
        // Broadcast the DELTA (only the changed entity) to subscribers
        broadcast(entityID: request.entityID, transform: request.newTransform)
    }
    
    func subscribe(to entityID: UUID, callback: @escaping @Sendable (SpatialTransform) -> Void) {
        subscribers[entityID] = callback
    }
    
    private func broadcast(entityID: UUID, transform: SpatialTransform) {
        // In a real distributed system, this would be a network broadcast
        // Here, we call the local subscribers
        subscribers[entityID]?(transform)
    }
    
    func getTransform(for entityID: UUID) -> SpatialTransform? {
        return authoritativeState[entityID]
    }
}

// MARK: - 3. The Window Coordinator (The Client)
@MainActor
class SpatialWindowCoordinator: ObservableObject {
    private let sessionManager: SpatialSessionManager
    let entityID: UUID
    
    init(sessionManager: SpatialSessionManager, entityID: UUID) {
        self.sessionManager = sessionManager
        self.entityID = entityID
    }
    
    func startSync() {
        Task {
            // Subscribe only to the specific entity this window cares about
            // This implements "Interest Management" to avoid Broadcast Storms
            await sessionManager.subscribe(to: entityID) { [weak self] newTransform in
                Task { @MainActor in
                    self?.applyTransformToScene(newTransform)
                }
            }
        }
    }
    
    func requestMove(to newPosition: SIMD3<Float>) {
        let currentTransform = SpatialTransform(
            position: newPosition, 
            rotation: .init(angle: 0, axis: [0, 1, 0])
        )
        let request = SpatialTransformRequest(
            entityID: entityID,
            newTransform: currentTransform,
            timestamp: Date()
        )
        
        Task {
            await sessionManager.handleRequest(request)
        }
    }
    
    private func applyTransformToScene(_ transform: SpatialTransform) {
        // Logic to move the actual RealityKit Entity
        print("Syncing Entity \(entityID) to position \(transform.position)")
    }
}

// MARK: - 4. View Implementation
struct CollaborativeView: View {
    @StateObject var coordinator: SpatialWindowCoordinator
    
    var body: some View {
        VStack {
            Button("Move Object") {
                coordinator.requestMove(to: [1, 0, 1])
            }
        }
        .onAppear {
            coordinator.startSync()
        }
    }
}
