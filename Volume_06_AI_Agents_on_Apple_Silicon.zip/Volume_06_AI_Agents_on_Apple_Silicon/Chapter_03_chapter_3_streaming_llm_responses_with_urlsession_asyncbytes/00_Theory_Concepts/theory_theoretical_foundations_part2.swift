
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation // For @Observable

// Define a Sendable struct for parsed LLM chunks
struct LLMStreamChunk: Sendable, Identifiable {
    let id = UUID()
    let content: String
    let isFinal: Bool
}

@available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
actor LLMResponseProcessor {
    // @MainActor is not directly applicable to an actor's properties,
    // but the ObservableObject will ensure UI updates on main.
    @MainActor @Observable
    class ResponseViewModel {
        var currentResponse: String = ""
        var isStreaming: Bool = false
        var error: Error?
        
        func appendChunk(_ chunk: LLMStreamChunk) {
            currentResponse += chunk.content
            isStreaming = !chunk.isFinal
        }
        
        func handleError(_ error: Error) {
            self.error = error
            self.isStreaming = false
        }
        
        func reset() {
            currentResponse = ""
            isStreaming = false
            error = nil
        }
    }
    
    // The actor holds a reference to the observable view model.
    // Access to viewModel properties must be on MainActor.
    private let viewModel: ResponseViewModel

    init(viewModel: ResponseViewModel) {
        self.viewModel = viewModel
    }

    // This method is called by the streaming task.
    // It's isolated to the actor, ensuring safe access to its internal state (if any)
    // and then dispatches UI updates to the MainActor.
    func processChunk(_ chunk: LLMStreamChunk) async {
        // Any actor-internal state updates would go here.
        // For UI updates, we must jump to the MainActor.
        await MainActor.run {
            self.viewModel.appendChunk(chunk)
        }
    }
    
    func handleStreamError(_ error: Error) async {
        await MainActor.run {
            self.viewModel.handleError(error)
        }
    }
    
    func startNewStream() async {
        await MainActor.run {
            self.viewModel.reset()
            self.viewModel.isStreaming = true
        }
    }
}
