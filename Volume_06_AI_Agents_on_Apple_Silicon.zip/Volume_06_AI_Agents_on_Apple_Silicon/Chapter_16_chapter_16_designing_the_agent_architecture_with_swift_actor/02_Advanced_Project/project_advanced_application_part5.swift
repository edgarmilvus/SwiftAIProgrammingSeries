
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

/// `LLMInferenceActor` manages interactions with the underlying LLM service.
/// It ensures that LLM inference requests are handled safely and efficiently,
/// potentially managing resource contention for the LLM.
actor LLMInferenceActor {
    private let llmService: LLMServiceProtocol
    private var isBusy: Bool = false // State to manage resource contention for the LLM

    /// Initializes the actor with a specific LLM service implementation.
    /// - Parameter llmService: An instance conforming to `LLMServiceProtocol`.
    init(llmService: LLMServiceProtocol) {
        self.llmService = llmService
    }

    /// Performs an LLM inference request.
    /// - Parameter request: The `LLMRequest` to be processed.
    /// - Returns: An `LLMResponse` from the LLM.
    /// - Throws: `AgentError.llmServiceBusy` if the service is currently processing another request,
    ///           or `AgentError.llmInferenceFailed` if the LLM service encounters an error.
    func performInference(request: LLMRequest) async throws -> LLMResponse {
        // Advanced: Check if the LLM is busy. This is useful if the underlying LLM
        // (e.g., a specific GPU context or hardware accelerator) can only handle one request at a time
        // or if concurrent requests severely degrade performance.
        guard !isBusy else {
            print("[\(Date().formatted(date: .omitted, time: .standard))] LLMInferenceActor: LLM service is busy, rejecting request for \(request.documentID.uuidString.prefix(8))...")
            throw AgentError.llmServiceBusy
        }

        isBusy = true // Mark as busy to prevent other concurrent calls from starting
        defer { isBusy = false } // Ensure busy status is reset when the function exits

        print("[\(Date().formatted(date: .omitted, time: .standard))] LLMInferenceActor: Sending inference request for \(request.documentID.uuidString.prefix(8))...")
        do {
            let response = try await llmService.performInference(request: request)
            print("[\(Date().formatted(date: .omitted, time: .standard))] LLMInferenceActor: Received LLM response for \(request.documentID.uuidString.prefix(8))...")
            return response
        } catch let error as AgentError {
            // Re-throw specific AgentErrors
            throw error
        } catch {
            // Wrap any other errors from the LLM service into our custom AgentError
            throw AgentError.llmInferenceFailed(reason: error.localizedDescription)
        }
    }

    /// Provides the name of the LLM model being used.
    func getModelName() -> String {
        self.llmService.modelName
    }
}
