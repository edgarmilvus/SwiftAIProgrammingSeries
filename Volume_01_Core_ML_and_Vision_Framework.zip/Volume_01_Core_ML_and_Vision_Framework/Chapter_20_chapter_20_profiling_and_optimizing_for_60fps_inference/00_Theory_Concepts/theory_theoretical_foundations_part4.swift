
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    @Observable
    class InferenceViewModel {
        var latestClassification: String = "No detection"
        var inferenceTimeMs: Double = 0.0
        var isInferring: Bool = false

        private let inferenceActor: InferenceActor // Assume initialized

        init(inferenceActor: InferenceActor) {
            self.inferenceActor = inferenceActor
        }

        func startLiveInference(cameraStream: AsyncStream<CVPixelBuffer>) async {
            isInferring = true
            for await pixelBuffer in cameraStream {
                let startTime = Date()
                do {
                    let observations = try await inferenceActor.performVisionInference(pixelBuffer: pixelBuffer)
                    let endTime = Date()
                    let duration = endTime.timeIntervalSince(startTime) * 1000

                    await MainActor.run {
                        self.latestClassification = observations.first?.identifier ?? "Unknown"
                        self.inferenceTimeMs = duration
                        // If duration > 16.67ms, we know we're not hitting 60fps
                    }
                } catch {
                    print("Error during live inference: \(error)")
                }
            }
            isInferring = false
        }
    }
    