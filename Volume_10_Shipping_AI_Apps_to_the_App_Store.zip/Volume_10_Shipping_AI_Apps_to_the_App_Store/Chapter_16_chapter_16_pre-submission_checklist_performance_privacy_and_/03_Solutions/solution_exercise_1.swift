
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CoreML

@available(iOS 18.0, *)
public actor LLMManager {
    private var model: MLModel?
    private var isLoaded = false
    
    /// Refactored loading process to minimize peak memory footprint.
    public func loadModel() async throws {
        print("Starting memory-optimized model load...")
        
        // We use a scoped helper to ensure the 'Data' object's lifecycle 
        // is strictly limited to the initialization phase.
        let loadedModel = try await performScopedLoading()
        
        self.model = loadedModel
        self.isLoaded = true
        print("Model loaded successfully. Peak memory spike minimized.")
    }
    
    /// This helper function ensures that the large Data buffer is 
    /// deallocated immediately after the model is created.
    private func performScopedLoading() async throws -> MLModel {
        // The 'data' variable exists only within this function's scope.
        let simulatedWeightSize = 1_500_000_000 // 1.5 GB
        
        // In a real scenario, we would use Data(contentsOf: url, options: .mappedIfSafe)
        // to leverage virtual memory mapping instead of loading into the heap.
        let data = Data(count: simulatedWeightSize)
        
        // Simulate the heavy I/O and initialization time
        try await Task.sleep(for: .seconds(2))
        
        let model = try await createMockModel(from: data)
        
        // As this function returns, 'data' goes out of scope and is 
        // released before 'self.model' is even assigned in the caller.
        return model
    }
    
    private func createMockModel(from data: Data) async throws -> MLModel {
        // Mocking the creation of an MLModel
        return MLModel() 
    }
    
    public func generateText(prompt: String) async throws -> String {
        guard isLoaded, let _ = model else { 
            throw NSError(domain: "LLMError", code: 1) 
        }
        try await Task.sleep(for: .seconds(1))
        return "Generated response for: \(prompt)"
    }
}

// --- Calling Site Example ---
@MainActor
struct ModelLoaderViewModel: ObservableObject {
    @Published var status: String = "Idle"
    private let manager = LLMManager()
    
    func startLoading() {
        Task {
            status = "Loading..."
            do {
                try await manager.loadModel()
                status = "Ready"
            } catch {
                status = "Error: \(error.localizedDescription)"
            }
        }
    }
}
