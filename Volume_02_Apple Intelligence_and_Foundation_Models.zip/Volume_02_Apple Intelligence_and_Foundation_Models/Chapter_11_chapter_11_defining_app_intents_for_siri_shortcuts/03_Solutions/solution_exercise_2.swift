
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation

// MARK: - Expense Tracker Intent

@available(iOS 18.0, *)
struct RecordTransactionIntent: AppIntent {
    static var intentDisplayName: LocalizedStringResource = "Record Transaction"
    static var description: LocalizedStringResource = "Records a new financial transaction, either an expense or income."

    @Parameter(title: "Amount", description: "The monetary value of the transaction.")
    var amount: Double

    @Parameter(title: "Category", description: "The category for this transaction (e.g., 'Groceries', 'Salary').")
    var category: String

    @Parameter(title: "Is Income", description: "Set to true if this transaction is income, false for an expense.", default: false)
    var isIncome: Bool

    static var parameterSummary: some ParameterSummary {
        // Conditional parameter summary based on the 'isIncome' parameter
        When(\.$isIncome, .equalTo: true) {
            Summary("Record income of \((\.$amount)) in \((\.$category))")
        } otherwise: {
            Summary("Record expense of \((\.$amount)) in \((\.$category))")
        }
    }

    func perform() async throws -> some IntentResult {
        // Simulate saving the transaction to a data store
        let transactionType = isIncome ? "Income" : "Expense"
        let formattedAmount = String(format: "%.2f", amount)

        print("Recorded \(transactionType): $\(formattedAmount) in category '\(category)'")

        // In a real app, this would involve data persistence.
        return .result(
            dialog: "Recorded \(transactionType) of $\(formattedAmount) for '\(category)'."
        )
    }
}

// MARK: - App Shortcuts Provider

@available(iOS 18.0, *)
struct MyAppFinancialShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: RecordTransactionIntent(),
            phrases: [
                "Record \(.dollarSign)\(.\$amount) \(\.$category) expense",
                "Add \(.dollarSign)\(.\$amount) to \(\.$category)", // for income
                "Log a transaction"
            ],
            shortTitle: "Record Transaction",
            systemImageName: "dollarsign.circle.fill"
        )
    }
}
