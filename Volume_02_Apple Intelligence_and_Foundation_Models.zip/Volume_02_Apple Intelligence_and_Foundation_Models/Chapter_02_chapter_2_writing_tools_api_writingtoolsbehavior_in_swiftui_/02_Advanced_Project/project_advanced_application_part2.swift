
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Foundation
import OSLog // For production-quality logging

// MARK: - 1. Data Models

/// Represents the different types of content blocks within a SecureNote.
/// Each type dictates the behavior of Writing Tools.
enum NoteBlockType: String, CaseIterable, Identifiable {
    case normal = "Normal Text"
    case confidential = "Confidential"
    case comment = "Read-Only Comment"

    var id: String { self.rawValue }

    /// A description suitable for display in the UI.
    var displayTitle: String {
        switch self {
        case .normal: return "Normal Content"
        case .confidential: return "Confidential Data"
        case .comment: return "Non-Editable Comment"
        }
    }
}

/// A structure representing a single block of text within a note.
/// It holds the content and its type, which influences Writing Tools behavior.
struct NoteBlock: Identifiable, Equatable {
    let id = UUID()
    var type: NoteBlockType
    var content: String

    static var exampleBlocks: [NoteBlock] {
        [
            NoteBlock(type: .normal, content: "This is a regular note block. You can use all writing tools here to proofread, rewrite, or summarize your text."),
            NoteBlock(type: .confidential, content: "CONFIDENTIAL: Project Chimera's launch date is Q4 2025. This information should not be summarized or rewritten."),
            NoteBlock(type: .comment, content: "This section contains internal team comments and is not editable by the user. Therefore, all writing tools are disabled.")
        ]
    }
}

// MARK: - 2. Helper for Writing Tools Behavior

/// Extension on `NoteBlockType` to easily determine the appropriate `WritingToolsBehavior`.
@available(iOS 18.0, *)
extension NoteBlockType {
    /// Determines the `WritingToolsBehavior` based on the `NoteBlockType`.
    /// This centralizes the logic for how Apple Intelligence features interact with different content.
    var writingToolsBehavior: WritingToolsBehavior {
        switch self {
        case .normal:
            // For normal text, all writing tools are available.
            Logger.writingTools.debug("Applying .automatic behavior for \(self.rawValue)")
            return .automatic
        case .confidential:
            // For confidential text, limit tools to only proofreading and basic formatting.
            // This prevents AI from rewriting or summarizing sensitive data.
            Logger.writingTools.debug("Applying .limited([.proofread, .format]) behavior for \(self.rawValue)")
            return .limited([.proofread, .format])
        case .comment:
            // For read-only comments, disable all writing tools as the content should not be edited.
            Logger.writingTools.debug("Applying .disabled behavior for \(self.rawValue)")
            return .disabled
        }
    }
}

// MARK: - 3. Note Block Editor View

/// A SwiftUI view component that displays and allows editing of a single `NoteBlock`.
/// It dynamically applies `writingToolsBehavior` based on the block's type.
@available(iOS 18.0, *)
struct NoteBlockEditorView: View {
    @Binding var block: NoteBlock
    @FocusState private var isFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(block.type.displayTitle)
                .font(.headline)
                .foregroundColor(block.type == .confidential ? .red : .primary)

            TextEditor(text: $block.content)
                .frame(minHeight: 100, maxHeight: 300)
                .border(Color.gray.opacity(0.3), width: 1)
                .cornerRadius(5)
                .padding(4)
                .focused($isFocused)
                // CRITICAL: Applying the writingToolsBehavior modifier dynamically.
                // This is where the core logic of this advanced application resides.
                .writingToolsBehavior(block.type.writingToolsBehavior)
                .onChange(of: block.content) { oldValue, newValue in
                    Logger.writingTools.info("Content of \(block.type.rawValue) block changed.")
                }
                .onChange(of: block.type) { oldValue, newValue in
                    Logger.writingTools.info("Type of block changed from \(oldValue.rawValue) to \(newValue.rawValue). Writing tools behavior will update.")
                }

            if block.type == .comment {
                Text("Writing tools are disabled for this read-only comment section.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else if block.type == .confidential {
                Text("Only Proofread and Format tools are enabled for confidential content.")
                    .font(.caption)
                    .foregroundColor(.orange)
            } else {
                Text("All writing tools are available.")
                    .font(.caption)
                    .foregroundColor(.green)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

// MARK: - 4. Main SecureNote Editor View

/// The main view for the SecureNote app, managing multiple `NoteBlock` instances.
/// It demonstrates asynchronous loading and dynamic addition of new blocks.
@available(iOS 18.0, *)
struct SecureNoteEditorView: View {
    @State private var noteBlocks: [NoteBlock] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    // Logger for general app events
    private let logger = Logger(subsystem: "com.example.SecureNote", category: "SecureNoteEditorView")

    var body: some View {
        NavigationView {
            Group {
                if isLoading {
                    ProgressView("Loading Note...")
                } else if let errorMessage {
                    ContentUnavailableView("Error Loading Note", systemImage: "xmark.octagon.fill", description: Text(errorMessage))
                        .foregroundColor(.red)
                } else if noteBlocks.isEmpty {
                    ContentUnavailableView("No Content", systemImage: "note.text.badge.plus", description: Text("Add your first note block."))
                } else {
                    List {
                        ForEach($noteBlocks) { $block in
                            NoteBlockEditorView(block: $block)
                                .listRowSeparator(.hidden)
                                .listRowBackground(Color.clear)
                        }
                        .onDelete(perform: deleteBlock)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("SecureNote Editor")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Add Block") {
                        addBlock()
                    }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton() // For deleting blocks
                }
            }
            .task {
                // Simulate asynchronous loading of note blocks
                await loadNoteBlocks()
            }
        }
    }

    /// Simulates loading note blocks asynchronously.
    /// Demonstrates Swift 6 concurrency and basic error handling.
    private func loadNoteBlocks() async {
        isLoading = true
        errorMessage = nil
        do {
            logger.info("Starting asynchronous note block load...")
            // Simulate network delay or complex data processing
            try await Task.sleep(for: .seconds(2))

            // Simulate a potential error condition
            if Bool.random() && noteBlocks.isEmpty { // Only error on initial load for demonstration
                throw NoteLoadingError.networkFailure
            }

            // Load example blocks if none are present
            if noteBlocks.isEmpty {
                noteBlocks = NoteBlock.exampleBlocks
            }
            logger.info("Note blocks loaded successfully.")
        } catch {
            errorMessage = "Failed to load note: \(error.localizedDescription)"
            logger.error("Failed to load note blocks: \(error.localizedDescription)")
        }
        isLoading = false
    }

    /// Adds a new `NoteBlock` of default type to the note.
    private func addBlock() {
        let newBlock = NoteBlock(type: .normal, content: "New content block. Edit me!")
        noteBlocks.append(newBlock)
        logger.info("Added new note block of type: \(newBlock.type.rawValue)")
    }

    /// Deletes a `NoteBlock` at the specified indices.
    private func deleteBlock(at offsets: IndexSet) {
        noteBlocks.remove(atOffsets: offsets)
        logger.info("Deleted note block(s). Remaining: \(noteBlocks.count)")
    }
}

// MARK: - Error Handling Example

/// Custom error types for note loading.
enum NoteLoadingError: LocalizedError {
    case networkFailure
    case dataCorruption
    case unknown

    var errorDescription: String? {
        switch self {
        case .networkFailure: return "Network connection failed while loading note."
        case .dataCorruption: return "Note data is corrupted."
        case .unknown: return "An unknown error occurred."
        }
    }
}

// MARK: - Logger Configuration

/// Extension to `Logger` for specific categories related to Writing Tools.
extension Logger {
    /// A logger specifically for `writingToolsBehavior` related events.
    static let writingTools = Logger(subsystem: "com.example.SecureNote", category: "WritingTools")
}

// MARK: - App Entry Point

/// The main application structure for SecureNote.
@main
@available(iOS 18.0, *)
struct SecureNoteApp: App {
    var body: some Scene {
        WindowGroup {
            SecureNoteEditorView()
        }
    }
}
