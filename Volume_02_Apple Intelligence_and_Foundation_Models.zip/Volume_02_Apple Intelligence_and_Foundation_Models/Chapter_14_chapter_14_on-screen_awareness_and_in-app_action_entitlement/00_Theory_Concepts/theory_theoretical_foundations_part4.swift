
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// Re-visiting the structs from the Actor section, explicitly marking them Sendable.
// If all stored properties are Sendable, the struct is implicitly Sendable.
// For classes or more complex types, manual Sendable conformance might be needed
// or Swift's Sendable checking will guide you.

@available(iOS 18.0, *)
struct ScreenContext: Sendable { // Implicitly Sendable if all properties are Sendable
    let textContent: String
    let interactiveElements: [InteractiveElement]
    // All properties (String, Array of Sendable structs) are Sendable.
}

@available(iOS 18.0, *)
struct InteractiveElement: Sendable { // Implicitly Sendable
    let id: String
    let type: String
    let label: String
}

@available(iOS 18.0, *)
struct AppActionDescription: Sendable, Identifiable { // Implicitly Sendable
    let id: String
    let name: String
    let parameters: [String: ParameterType]
    let requiresConfirmation: Bool
}

@available(iOS 18.0, *)
enum ParameterType: Sendable { // Enums with Sendable associated values are Sendable
    case string
    case int
    case bool
    // ...
}

@available(iOS 18.0, *)
struct AISuggestion: Sendable, Identifiable { // Implicitly Sendable
    let id = UUID()
    let proposedText: String?
    let proposedAction: AppActionDescription?
    let actionID: String?
    let confidence: Double
}
