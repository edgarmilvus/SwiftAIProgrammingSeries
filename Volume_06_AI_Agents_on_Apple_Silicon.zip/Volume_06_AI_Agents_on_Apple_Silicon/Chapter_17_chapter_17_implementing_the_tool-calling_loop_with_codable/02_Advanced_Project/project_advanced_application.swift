
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This file defines your package and its dependencies.
// For a real-world macOS app, this would be part of your main project's Package.swift
// or a separate Swift Package linked to your app target.

import PackageDescription

let package = Package(
    name: "SmartHomeAgent",
    platforms: [
        .macOS(.v15), // Targeting macOS 15.0 for latest Swift Concurrency features
    ],
    products: [
        .library(
            name: "SmartHomeAgent",
            targets: ["SmartHomeAgent"]),
    ],
    dependencies: [
        // OllamaKit for interacting with a local Ollama instance
        .package(url: "https://github.com/ollama-kit/ollama-kit.git", from: "0.1.0"),
        // AsyncAlgorithms for advanced asynchronous stream processing (optional, but good practice)
        .package(url: "https://github.com/apple/swift-async-algorithms.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "SmartHomeAgent",
            dependencies: [
                .product(name: "OllamaKit", package: "ollama-kit"),
                .product(name: "AsyncAlgorithms", package: "swift-async-algorithms"),
            ]),
        .testTarget(
            name: "SmartHomeAgentTests",
            dependencies: ["SmartHomeAgent"]),
    ]
)
