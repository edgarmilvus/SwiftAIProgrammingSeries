
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

        // Example: Simulating an async AI prediction
        func simulateAIInference() async {
            // Perform heavy AI computation on a background thread
            await Task.detached {
                print("Starting AI inference on background thread...")
                try? await Task.sleep(for: .seconds(2)) // Simulate work
                let newConfidence = Double.random(in: 0.0...1.0)
                print("AI inference complete. New confidence: \(newConfidence)")

                // Crucial: Dispatch UI updates back to the main actor
                await MainActor.run {
                    self.voiceUnderstandingConfidence = newConfidence
                    print("UI updated on MainActor.")
                }
            }.value // Await the detached task if you need to ensure completion
        }

        // In ContentView's body, for example:
        Button("Run AI Inference") {
            Task { // Create a new Task to run async code
                await simulateAIInference()
            }
        }
        