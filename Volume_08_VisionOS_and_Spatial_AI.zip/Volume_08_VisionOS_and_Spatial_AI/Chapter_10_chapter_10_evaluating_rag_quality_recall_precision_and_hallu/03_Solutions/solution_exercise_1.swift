
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Represents the outcome of a retrieval evaluation.
struct RetrievalMetrics: Sendable {
    let precision: Double
    let recall: Double
    let f1Score: Double
}

/// An actor responsible for performing thread-safe evaluation of retrieval sets.
@available(iOS 18.0, macOS 15.0, *)
actor RetrievalEvaluator {
    
    /// Evaluates the quality of the retrieved documents against the ground truth.
    /// - Parameters:
    ///   - retrievedIDs: The IDs returned by your vector database.
    ///   - groundTruthIDs: The actual relevant IDs for this query.
    ///   - k: The number of top results to consider.
    /// - Returns: A `RetrievalMetrics` object.
    func evaluate(
        retrievedIDs: Set<UUID>,
        groundTruthIDs: Set<UUID>,
        k: Int
    ) async -> RetrievalMetrics {
        // 1. Take the first 'k' elements from the retrieved set.
        // Since Sets are unordered, in a real RAG system, 'retrievedIDs' 
        // would be an Array of IDs ordered by similarity score.
        // For this exercise, we assume the input set represents the top-K results.
        let topKRetrieved = retrievedIDs.prefix(k)
        let topKSet = Set(topKRetrieved)
        
        // 2. Calculate the intersection with groundTruthIDs.
        let relevantRetrievedCount = topKSet.intersection(groundTruthIDs).count
        
        // 3. Compute the metrics.
        // Precision@K = Relevant in Top K / K
        let precision = k > 0 ? Double(relevantRetrievedCount) / Double(k) : 0.0
        
        // Recall@K = Relevant in Top K / Total Relevant
        let recall = !groundTruthIDs.isEmpty ? Double(relevantRetrievedCount) / Double(groundTruthIDs.count) : 0.0
        
        // F1-Score = Harmonic mean of Precision and Recall
        let f1Score: Double
        if (precision + recall) > 0 {
            f1Score = 2 * (precision * recall) / (precision + recall)
        } else {
            f1Score = 0.0
        }
        
        return RetrievalMetrics(
            precision: precision,
            recall: recall,
            f1Score: f1Score
        )
    }
}

// --- Usage Example ---
// Task {
//     let evaluator = RetrievalEvaluator()
//     let groundTruth: Set<UUID> = [UUID(), UUID(), UUID()]
//     let retrieved: Set<UUID> = [UUID(), UUID(), UUID(), UUID()] // Assume 2 match ground truth
//     let metrics = await evaluator.evaluate(retrievedIDs: retrieved, groundTruthIDs: groundTruth, k: 3)
//     print("Precision: \(metrics.precision)")
// }
