
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

struct LlamaInferenceResult {
    let generatedText: String
    let diagnosticOutput: String // Combined stderr and non-generated stdout
}

enum LlamaInferenceError: Error, LocalizedError {
    case executableNotFound(path: String)
    case modelFileNotFound(path: String)
    case executionFailed(status: Int, stderr: String, stdout: String)
    case invalidArgument(message: String)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .executableNotFound(let path):
            return "llama.cpp 'main' executable not found at '\(path)'. Please verify the path."
        case .modelFileNotFound(let path):
            return "GGUF model file not found at '\(path)'. Please verify the model path."
        case .executionFailed(let status, let stderr, let stdout):
            var description = "llama.cpp inference failed with exit status \(status)."
            if !stderr.isEmpty { description += "\nError: \(stderr)" }
            if !stdout.isEmpty { description += "\nOutput: \(stdout)" } // Sometimes errors are on stdout too
            return description
        case .invalidArgument(let message):
            return "Invalid argument for llama.cpp: \(message)"
        case .unknown(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

class LlamaCppAgent {
    let llamaCppExecutableURL: URL
    let defaultCurrentDirectoryURL: URL? // For llama.cpp's relative paths

    init(llamaCppExecutableURL: URL, defaultCurrentDirectoryURL: URL? = nil) {
        self.llamaCppExecutableURL = llamaCppExecutableURL
        self.defaultCurrentDirectoryURL = defaultCurrentDirectoryURL
    }

    /// Executes llama.cpp for inference with specified parameters.
    /// - Parameters:
    ///   - modelPath: URL to the GGUF model file.
    ///   - prompt: The input prompt string.
    ///   - temperature: Inference temperature (e.g., 0.7).
    ///   - tokenCount: Maximum number of tokens to generate.
    ///   - additionalArguments: Optional array of strings for extra llama.cpp arguments.
    /// - Returns: A LlamaInferenceResult containing generated text and diagnostic output.
    /// - Throws: A LlamaInferenceError if execution fails or arguments are invalid.
    func runInference(
        modelPath: URL,
        prompt: String,
        temperature: Double,
        tokenCount: Int,
        additionalArguments: [String] = []
    ) async throws -> LlamaInferenceResult {
        let process = Process()
        let stdoutPipe = Pipe()
        let stderrPipe = Pipe()

        process.standardOutput = stdoutPipe
        process.standardError = stderrPipe

        // 1. Verify executable and model paths
        guard FileManager.default.fileExists(atPath: llamaCppExecutableURL.path) else {
            throw LlamaInferenceError.executableNotFound(path: llamaCppExecutableURL.path)
        }
        guard FileManager.default.fileExists(atPath: modelPath.path) else {
            throw LlamaInferenceError.modelFileNotFound(path: modelPath.path)
        }
        
        process.executableURL = llamaCppExecutableURL
        
        // Set working directory if provided. Crucial for llama.cpp if it expects files
        // (like vocabularies or other models) relative to its executable.
        if let currentDir = defaultCurrentDirectoryURL {
            process.currentDirectoryURL = currentDir
        } else {
            // Default to the directory containing the executable itself
            process.currentDirectoryURL = llamaCppExecutableURL.deletingLastPathComponent()
        }

        // 2. Construct command-line arguments securely
        var arguments: [String] = []
        arguments.append("-m")
        arguments.append(modelPath.path) // Process.arguments handles path escaping
        
        arguments.append("-p")
        // The prompt string itself needs to be passed as a single argument.
        // Process.arguments handles shell-level quoting for individual elements.
        // If the prompt contains quotes itself, llama.cpp might interpret them.
        // For simplicity, we pass it as a single string.
        arguments.append(prompt)
        
        arguments.append("--temp")
        arguments.append(String(temperature))
        
        arguments.append("-n")
        arguments.append(String(tokenCount))
        
        // Add any additional user-provided arguments
        arguments.append(contentsOf: additionalArguments)
        
        process.arguments = arguments

        do {
            try process.run()
        } catch {
            if let posixError = error as? POSIXError, posixError.code == .ENOENT {
                throw LlamaInferenceError.executableNotFound(path: llamaCppExecutableURL.path)
            }
            throw LlamaInferenceError.unknown(error)
        }

        process.waitUntilExit()

        let stdoutData = stdoutPipe.fileHandleForReading.readDataToEndOfFile()
        let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()

        let stdout = String(data: stdoutData, encoding: .utf8) ?? ""
        let stderr = String(data: stderrData, encoding: .utf8) ?? ""

        guard process.terminationStatus == 0 else {
            throw LlamaInferenceError.executionFailed(status: Int(process.terminationStatus), stderr: stderr, stdout: stdout)
        }

        // 4. Parse generated text from stdout
        // llama.cpp's 'main' typically prints statistics and then the generated text.
        // The generated text is usually the last part of stdout after "prompt: " or similar.
        // A simple heuristic is to find the last occurrence of the prompt if it's echoed,
        // or just consider everything after the initial diagnostic lines.
        // For robustness, we'll try to find the actual generated response marker.
        
        let generatedText: String
        let diagnosticOutput: String
        
        if let promptRange = stdout.range(of: prompt) {
            // If the prompt is echoed, generated text starts after it.
            let textAfterPrompt = String(stdout[promptRange.upperBound...])
            // Trim leading newlines/spaces, sometimes llama.cpp adds a newline after prompt
            generatedText = textAfterPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
            diagnosticOutput = String(stdout[..<promptRange.lowerBound]) + stderr
        } else {
            // Fallback: if prompt isn't echoed, assume all stdout is generated text
            // or try to find common llama.cpp diagnostic patterns.
            // For simplicity, let's assume the generated text is the main output
            // and diagnostics are usually at the beginning or on stderr.
            // A more advanced parser might look for specific "time to generate" lines.
            
            // Heuristic: llama.cpp often prints stats at the end starting with "model_eval_duration"
            // or "total time" etc. The actual generated text is usually before these.
            // Let's assume the generated text is the main body, and we'll separate
            // the stats for diagnostic output.
            
            // This is a common pattern for llama.cpp 'main' output:
            // ... [diagnostic lines] ...
            // prompt: <user prompt>
            // <generated text>
            // ... [more diagnostic lines, e.g., stats] ...

            // To get *only* the generated text, we might need to be more specific.
            // For example, finding the last newline before "main: " or "total time" etc.
            
            // A simpler, yet often effective approach: Take all of stdout as potential generated text,
            // and stderr + start of stdout as diagnostics.
            generatedText = stdout
            diagnosticOutput = stderr
        }
        
        return LlamaInferenceResult(generatedText: generatedText, diagnosticOutput: diagnosticOutput)
    }
}

// Example Usage:
/*
Task {
    // IMPORTANT: Replace with actual paths on your system!
    let llamaCppPath = URL(fileURLWithPath: "/Users/youruser/llama.cpp/main")
    let modelGGUFPath = URL(fileURLWithPath: "/Users/youruser/models/llama-2-7b-chat.Q4_K_M.gguf")
    let llamaCppWorkingDir = URL(fileURLWithPath: "/Users/youruser/llama.cpp") // Directory containing 'main'

    // Verify paths exist before attempting to run
    guard FileManager.default.fileExists(atPath: llamaCppPath.path) else {
        print("Error: llama.cpp executable not found at \(llamaCppPath.path)")
        return
    }
    guard FileManager.default.fileExists(atPath: modelGGUFPath.path) else {
        print("Error: GGUF model file not found at \(modelGGUFPath.path)")
        return
    }

    let agent = LlamaCppAgent(llamaCppExecutableURL: llamaCppPath, defaultCurrentDirectoryURL: llamaCppWorkingDir)

    let prompt = "Explain the concept of quantum entanglement in simple terms."
    let temperature = 0.7
    let tokenCount = 100

    print("Starting llama.cpp inference...")
    print("Prompt: \(prompt)")

    do {
        let result = try await agent.runInference(
            modelPath: modelGGUFPath,
            prompt: prompt,
            temperature: temperature,
            tokenCount: tokenCount,
            additionalArguments: ["--top-k", "40", "--top-p", "0.9"] // Example additional args
        )
        
        print("\n--- Generated Text ---")
        print(result.generatedText)

        if !result.diagnosticOutput.isEmpty {
            print("\n--- Diagnostic Output (from stderr/stdout) ---")
            print(result.diagnosticOutput)
        }

    } catch {
        if let llamaError = error as? LlamaInferenceError {
            print("Llama Inference Error: \(llamaError.localizedDescription)")
        } else {
            print("An unexpected error occurred: \(error.localizedDescription)")
        }
    }
}
*/
