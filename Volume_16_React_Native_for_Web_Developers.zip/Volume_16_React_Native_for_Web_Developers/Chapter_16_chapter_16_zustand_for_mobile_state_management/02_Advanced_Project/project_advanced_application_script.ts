/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/lib/store.ts
// ------------------------------------------------------------
// Zustand Store Configuration & Middleware
// ------------------------------------------------------------

import { create } from 'zustand';
import { persist, createJSONStorage, StateStorage } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

// Simulating AsyncStorage for Web/Next.js environment
// In a real Expo app, import { AsyncStorage } from '@react-native-async-storage/async-storage';
const mockAsyncStorage: StateStorage = {
  getItem: async (key: string) => {
    const value = typeof window !== 'undefined' ? window.localStorage.getItem(key) : null;
    return value;
  },
  setItem: async (key: string, value: string) => {
    if (typeof window !== 'undefined') window.localStorage.setItem(key, value);
  },
  removeItem: async (key: string) => {
    if (typeof window !== 'undefined') window.localStorage.removeItem(key);
  },
};

/**
 * @type {Task}
 * Defines the structure of a single task item in the dashboard.
 */
export type Task = {
  id: string;
  title: string;
  completed: boolean;
  createdAt: number;
};

/**
 * @type {AppState}
 * Defines the shape of the global state managed by Zustand.
 */
export type AppState = {
  user: {
    isAuthenticated: boolean;
    username: string | null;
  };
  tasks: Task[];
  lastSynced: number | null;
};

/**
 * @type {Actions}
 * Defines the action methods available to modify the state.
 */
export type Actions = {
  login: (username: string) => void;
  logout: () => void;
  addTask: (title: string) => void;
  toggleTask: (id: string) => void;
  clearCompleted: () => void;
};

/**
 * @type {AppStore}
 * The complete store type combining state and actions.
 */
export type AppStore = AppState & Actions;

/**
 * useAppStore
 * The primary hook to access the application state and actions.
 * Implements 'immer' for immutable state updates and 'persist' for AsyncStorage.
 */
export const useAppStore = create<AppStore>()(
  immer(
    persist(
      (set, get) => ({
        // Initial State
        user: {
          isAuthenticated: false,
          username: null,
        },
        tasks: [],
        lastSynced: null,

        // Actions
        login: (username) =>
          set((state) => {
            state.user.isAuthenticated = true;
            state.user.username = username;
            state.lastSynced = Date.now();
          }),

        logout: () =>
          set((state) => {
            state.user.isAuthenticated = false;
            state.user.username = null;
            state.tasks = []; // Clear tasks on logout for security
          }),

        addTask: (title) =>
          set((state) => {
            const newTask: Task = {
              id: Math.random().toString(36).substr(2, 9),
              title,
              completed: false,
              createdAt: Date.now(),
            };
            state.tasks.push(newTask);
          }),

        toggleTask: (id) =>
          set((state) => {
            const task = state.tasks.find((t) => t.id === id);
            if (task) {
              task.completed = !task.completed;
            }
          }),

        clearCompleted: () =>
          set((state) => {
            state.tasks = state.tasks.filter((t) => !t.completed);
          }),
      }),
      {
        name: 'saas-dashboard-storage', // Key for localStorage
        storage: createJSONStorage(() => mockAsyncStorage),
        partialize: (state) => ({
          // Persist only specific parts of the state (exclude sensitive or ephemeral data)
          user: state.user,
          tasks: state.tasks,
        }),
      }
    )
  )
);
