
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This snippet demonstrates how you would declare dependencies for an AI agent app.
// In this specific chapter, the focus is on File System Access, but OllamaKit
// is included to maintain context with the broader book topic.

import PackageDescription

let package = Package(
    name: "AIDocumentProcessor",
    platforms: [
        .macOS(.v13) // Security-scoped bookmarks are primarily a macOS feature for directory access.
    ],
    products: [
        .library(
            name: "AIDocumentProcessor",
            targets: ["AIDocumentProcessor"]),
    ],
    dependencies: [
        // For interacting with Ollama local LLM server
        .package(url: "https://github.com/ollama-ai/ollama-swift", from: "0.1.0"),
        // Potentially other dependencies for document parsing (e.g., PDFKit, Vision for OCR)
    ],
    targets: [
        .target(
            name: "AIDocumentProcessor",
            dependencies: [
                .product(name: "OllamaKit", package: "ollama-swift")
            ]),
        .testTarget(
            name: "AIDocumentProcessorTests",
            dependencies: ["AIDocumentProcessor"]),
    ]
)
