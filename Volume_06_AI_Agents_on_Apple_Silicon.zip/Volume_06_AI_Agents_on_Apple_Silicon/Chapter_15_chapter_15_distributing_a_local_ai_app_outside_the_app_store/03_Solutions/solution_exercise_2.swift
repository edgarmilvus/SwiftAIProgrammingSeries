
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import AppKit // For NSOpenPanel, NSAlert
import SwiftUI // For a basic UI demonstration

// MARK: - Entitlements Requirement
/*
   For this solution to work, your app's .entitlements file must include:
   <key>com.apple.security.app-sandbox</key>
   <true/>
   <key>com.apple.security.files.user-selected.read-only</key>
   <true/>
   (Or .read-write if your app needs to modify user-selected files)
*/

// MARK: - ModelManager Class
@available(macOS 14.0, *)
class ModelManager: ObservableObject {
    @Published var currentModelURL: URL?
    @Published var statusMessage: String = "Ready."

    private let bookmarkKey = "persistedModelBookmark"
    private var securityScopedAccessActive: Bool = false // Track active security scope

    init() {
        // Attempt to load a bundled model first
        if let bundledURL = loadBundledModel() {
            self.currentModelURL = bundledURL
            self.statusMessage = "Loaded bundled model: \(bundledURL.lastPathComponent)"
        } else {
            // If no bundled model, try to retrieve a persisted user-selected model
            if let persistedURL = retrievePersistedModelURL() {
                self.currentModelURL = persistedURL
                self.statusMessage = "Loaded persisted model: \(persistedURL.lastPathComponent)"
            } else {
                self.statusMessage = "No model loaded. Please select one."
            }
        }
    }

    /// Attempts to locate and return the URL for a bundled GGUF model.
    func loadBundledModel() -> URL? {
        // Assume 'tinyllama.gguf' is located in the app's Resources folder
        guard let modelURL = Bundle.main.url(forResource: "tinyllama", withExtension: "gguf") else {
            print("Error: Bundled model 'tinyllama.gguf' not found.")
            return nil
        }
        print("Found bundled model at: \(modelURL.path)")
        // In a real app, you would now use llama.cpp Swift bindings to load this model.
        return modelURL
    }

    /// Presents an NSOpenPanel for the user to select a GGUF model file,
    /// then creates and persists a security-scoped bookmark for it.
    func selectAndPersistModelURL() {
        let openPanel = NSOpenPanel()
        openPanel.allowedFileTypes = ["gguf"]
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        openPanel.allowsMultipleSelection = false
        openPanel.prompt = "Select GGUF Model"

        // NSOpenPanel must be run on the main thread.
        DispatchQueue.main.async {
            if openPanel.runModal() == .OK, let url = openPanel.url {
                do {
                    // Before creating a new bookmark, stop access to any previous one.
                    self.stopCurrentModelAccess()

                    // Create a security-scoped bookmark. `.withSecurityScope` is essential.
                    let bookmarkData = try url.bookmarkData(options: .withSecurityScope,
                                                            includingResourceValuesForKeys: nil,
                                                            relativeTo: nil)
                    UserDefaults.standard.set(bookmarkData, forKey: self.bookmarkKey)
                    self.currentModelURL = url
                    self.statusMessage = "Model selected and bookmark saved: \(url.lastPathComponent)"
                    print("Bookmark created and saved for: \(url.path)")

                    // Immediately start accessing the newly selected resource
                    _ = self.startAccessingSecurityScopedResource(for: url)

                } catch {
                    self.statusMessage = "Error creating bookmark: \(error.localizedDescription)"
                    print("Error creating bookmark: \(error.localizedDescription)")
                }
            } else {
                self.statusMessage = "Model selection cancelled."
            }
        }
    }

    /// Retrieves a persisted security-scoped bookmark and resolves it to regain file access.
    /// Handles stale bookmarks by attempting to refresh them.
    func retrievePersistedModelURL() -> URL? {
        guard let bookmarkData = UserDefaults.standard.data(forKey: bookmarkKey) else {
            print("No persisted model bookmark found.")
            return nil
        }

        do {
            var isStale = false
            // Resolve the bookmark. `.withSecurityScope` is crucial for sandboxed apps.
            let url = try URL(resolvingBookmarkData: bookmarkData,
                              options: .withSecurityScope,
                              relativeTo: nil,
                              bookmarkDataIsStale: &isStale)

            if isStale {
                print("Bookmark is stale, attempting to re-save.")
                // If stale, try to recreate and save a fresh bookmark to ensure future access
                let newBookmarkData = try url.bookmarkData(options: .withSecurityScope,
                                                           includingResourceValuesForKeys: nil,
                                                           relativeTo: nil)
                UserDefaults.standard.set(newBookmarkData, forKey: bookmarkKey)
                print("Bookmark refreshed and saved.")
            }

            // Start accessing the resource after successful resolution
            if startAccessingSecurityScopedResource(for: url) {
                return url
            } else {
                // If access fails, clear the bookmark so the user can re-select.
                UserDefaults.standard.removeObject(forKey: bookmarkKey)
                self.statusMessage = "Failed to access persisted model. Please re-select."
                return nil
            }
        } catch {
            print("Error resolving bookmark: \(error.localizedDescription)")
            // If resolving fails, clear the bookmark.
            UserDefaults.standard.removeObject(forKey: bookmarkKey)
            self.statusMessage = "Error resolving persisted model. Please re-select."
            return nil
        }
    }

    /// Starts accessing a security-scoped resource for a given URL.
    /// Returns true on success, false otherwise.
    private func startAccessingSecurityScopedResource(for url: URL) -> Bool {
        // Stop any currently active access before starting a new one.
        stopCurrentModelAccess()

        if url.startAccessingSecurityScopedResource() {
            print("Successfully started accessing security-scoped resource: \(url.path)")
            securityScopedAccessActive = true
            return true
        } else {
            print("Failed to start accessing security-scoped resource: \(url.path). Bookmark might be invalid or permissions revoked.")
            securityScopedAccessActive = false
            return false
        }
    }

    /// Stops accessing the currently active security-scoped resource, if any.
    /// This should be called when the app no longer needs access to the file.
    func stopCurrentModelAccess() {
        // Only stop if there's a current model URL and security-scoped access was active for it.
        if let url = currentModelURL, url.isSecurityScopedResource, securityScopedAccessActive {
            url.stopAccessingSecurityScopedResource()
            print("Stopped accessing security-scoped resource: \(url.path)")
            securityScopedAccessActive = false
        }
    }
}

// MARK: - SwiftUI View for Demonstration
@available(macOS 14.0, *)
struct ModelSelectionView: View {
    @StateObject var modelManager = ModelManager()

    var body: some View {
        VStack(spacing: 20) {
            Text("AI Model Manager")
                .font(.largeTitle)
                .padding()

            Text("Current Model:")
                .font(.headline)
            Text(modelManager.currentModelURL?.lastPathComponent ?? "None")
                .font(.title2)
                .foregroundColor(modelManager.currentModelURL == nil ? .red : .green)
            Text(modelManager.currentModelURL?.path ?? "")
                .font(.caption)
                .lineLimit(1)
                .truncationMode(.head)
                .padding(.horizontal)

            Text("Status: \(modelManager.statusMessage)")
                .font(.subheadline)
                .padding()

            Button("Select Custom Model (GGUF)") {
                modelManager.selectAndPersistModelURL()
            }
            .padding()

            // Simulate using the model
            Button("Simulate Inference") {
                if let modelURL = modelManager.currentModelURL {
                    modelManager.statusMessage = "Performing inference with \(modelURL.lastPathComponent)..."
                    // In a real app, this is where llama.cpp Swift bindings would be used.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        modelManager.statusMessage = "Inference complete: 'Hello from \(modelURL.lastPathComponent)!' "
                    }
                } else {
                    modelManager.statusMessage = "No model loaded for inference."
                }
            }
            .padding()
            .disabled(modelManager.currentModelURL == nil)
        }
        .padding()
        .frame(minWidth: 400, minHeight: 300)
        .onDisappear {
            // Important: Stop accessing the resource when the app is no longer using it.
            // For a model loaded for the app's lifetime, this would be on app termination.
            modelManager.stopCurrentModelAccess()
        }
    }
}

// MARK: - App Entry Point (for demonstration)
@available(macOS 14.0, *)
@main
struct SecureModelApp: App {
    var body: some Scene {
        WindowGroup {
            ModelSelectionView()
        }
    }
}
