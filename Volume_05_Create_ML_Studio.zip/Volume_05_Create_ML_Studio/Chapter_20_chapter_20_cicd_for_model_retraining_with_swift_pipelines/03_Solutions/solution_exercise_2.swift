
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// SentimentModelTrainer.swift

import Foundation
import CreateML

@available(macOS 15.0, *)
@main
struct SentimentModelTrainer {
    static let minAccuracyThreshold: Double = 0.85 // 85% minimum validation accuracy

    static func main() async {
        // MARK: - Configuration
        // Assuming data is relative to the script's execution path.
        // Create these directories and populate them with JSONLines files.
        // Example JSONLines file (e.g., Data/Sentiment/Training/data.jsonlines):
        // {"text": "This is a great movie!", "sentiment": "positive"}
        // {"text": "I hated that experience.", "sentiment": "negative"}
        let scriptDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let trainingDataPath = scriptDirectory.appendingPathComponent("Data/Sentiment/Training")
        let validationDataPath = scriptDirectory.appendingPathComponent("Data/Sentiment/Validation")
        let outputDirectory = scriptDirectory.appendingPathComponent("Models/Sentiment")

        let fileManager = FileManager.default

        // MARK: - Setup Directories
        do {
            if !fileManager.fileExists(atPath: outputDirectory.path) {
                print("Creating output directory: \(outputDirectory.path)")
                try fileManager.createDirectory(at: outputDirectory, withIntermediateDirectories: true, attributes: nil)
            }
        } catch {
            print("Error setting up directories: \(error.localizedDescription)")
            return
        }

        do {
            // MARK: - Load Data
            print("Loading training data from: \(trainingDataPath.path)")
            // MLTextClassifier.DataSource.json expects JSONLines format by default
            let trainingData = try MLTextClassifier.DataSource.json(at: trainingDataPath, textColumn: "text", labelColumn: "sentiment")
            print("Successfully loaded training data.")

            print("Loading validation data from: \(validationDataPath.path)")
            let validationData = try MLTextClassifier.DataSource.json(at: validationDataPath, textColumn: "text", labelColumn: "sentiment")
            print("Successfully loaded validation data.")

            // MARK: - Train Model
            print("Starting MLTextClassifier training...")
            let classifier = try await MLTextClassifier(trainingData: trainingData, validationData: validationData)
            print("Model training complete.")

            // MARK: - Evaluate Model
            let trainingMetrics = classifier.evaluation(on: trainingData)
            let validationMetrics = classifier.evaluation(on: validationData)

            print("\n--- Model Evaluation ---")
            print("Training Accuracy: \(String(format: "%.2f", trainingMetrics.accuracy * 100))%")
            print("Validation Accuracy: \(String(format: "%.2f", validationMetrics.accuracy * 100))%")
            print("------------------------\n")

            // MARK: - Threshold-Based Validation
            if validationMetrics.accuracy >= minAccuracyThreshold {
                print("Validation accuracy (\(String(format: "%.2f", validationMetrics.accuracy * 100))%) meets the threshold (\(String(format: "%.2f", minAccuracyThreshold * 100))%). Proceeding to save model.")

                // MARK: - Version and Archive Model
                let nextVersion = try getNextModelVersion(in: outputDirectory, prefix: "SentimentModel_v1.")
                let modelFileName = "SentimentModel_v\(nextVersion).mlmodel"
                let modelOutputURL = outputDirectory.appendingPathComponent(modelFileName)

                print("Saving model to: \(modelOutputURL.path)")
                try classifier.write(to: modelOutputURL)
                print("Model v\(nextVersion) saved successfully.")
            } else {
                print("Validation accuracy (\(String(format: "%.2f", validationMetrics.accuracy * 100))%) is below the threshold (\(String(format: "%.2f", minAccuracyThreshold * 100))%). Model will NOT be saved.")
            }

        } catch {
            // MARK: - Error Handling
            print("An error occurred during pipeline execution: \(error.localizedDescription)")
        }
    }

    // MARK: - Helper to determine the next minor version
    /// Scans the directory for existing models with a given prefix and increments the minor version.
    /// Assumes a "vMAJOR.MINOR.mlmodel" format, focusing on incrementing MINOR.
    static func getNextModelVersion(in directory: URL, prefix: String) throws -> String {
        let fileManager = FileManager.default
        let contents = try fileManager.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
        
        var maxMinorVersion = 0
        
        for url in contents {
            if url.pathExtension == "mlmodel" && url.lastPathComponent.hasPrefix(prefix) {
                let fileName = url.lastPathComponent
                // Extract version string (e.g., "1.5" from "SentimentModel_v1.5.mlmodel")
                let versionString = fileName.replacingOccurrences(of: prefix, with: "").replacingOccurrences(of: ".mlmodel", with: "")
                
                // Try to parse the minor version part
                if let minorPart = versionString.split(separator: ".").last, let minorVersion = Int(minorPart) {
                    if minorVersion > maxMinorVersion {
                        maxMinorVersion = minorVersion
                    }
                }
            }
        }
        // Assuming major version is always 1 for this exercise's simplicity
        return "1.\(maxMinorVersion + 1)"
    }
}
