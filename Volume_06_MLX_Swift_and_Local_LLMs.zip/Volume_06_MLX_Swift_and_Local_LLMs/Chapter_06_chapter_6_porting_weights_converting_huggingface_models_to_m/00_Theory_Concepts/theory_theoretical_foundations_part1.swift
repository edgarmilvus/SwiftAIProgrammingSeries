
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN // Assuming MLXNN is part of your MLX Swift setup

// Assume a simple linear model for demonstration
@available(iOS 18.0, *)
class SimpleLinearModel: MLXNN.Module {
    let linear: MLXNN.Linear

    required init() {
        self.linear = MLXNN.Linear(inputDimensions: 10, outputDimensions: 1)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        return linear(input)
    }
}

@available(iOS 18.0, *)
func calculateLoss(model: SimpleLinearModel, input: MLXArray, target: MLXArray) -> MLXArray {
    let prediction = model(input)
    // Mean Squared Error loss
    return MLX.mean(MLX.square(prediction - target))
}

@available(iOS 18.0, *)
func demonstrateValueAndGradient() {
    let model = SimpleLinearModel()
    let input = MLXArray.randomUniform(low: 0, high: 1, shape: [1, 10])
    let target = MLXArray.randomUniform(low: 0, high: 1, shape: [1, 1])

    // Define the function whose value and gradient we want to compute
    let lossAndGradientFn = MLX.valueAndGradient(calculateLoss)

    // Execute the function to get the loss and gradients with respect to model parameters
    // The second argument to valueAndGradient is the 'wrt' (with respect to) argument,
    // which specifies the parameters for which gradients should be computed.
    let (loss, gradients) = lossAndGradientFn(model, input, target)

    print("Loss: \(loss.item())")
    // Gradients will be a dictionary of MLXArray for each parameter in the model
    // print("Gradients: \(gradients)") // This would show the dictionary structure
}
