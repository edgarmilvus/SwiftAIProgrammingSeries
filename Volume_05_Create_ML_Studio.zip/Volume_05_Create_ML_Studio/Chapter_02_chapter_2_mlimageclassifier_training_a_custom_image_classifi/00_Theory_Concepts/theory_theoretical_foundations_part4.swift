
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML

// A struct representing training metrics is implicitly Sendable
struct TrainingMetrics: Sendable {
    let epoch: Int
    let trainingLoss: Double
    let validationLoss: Double
    let validationAccuracy: Double
}

// An enum representing a prediction result is implicitly Sendable
enum PredictionResult: Sendable {
    case success(label: String, confidence: Double)
    case failure(Error)
}

// If you have a custom class that needs to be Sendable, it usually implies
// it's immutable or its mutable state is protected.
// For example, a wrapper around a Core ML model, if it's immutable once created.
@available(iOS 18.0, *)
final class ImmutableMLModelWrapper: Sendable {
    let model: MLImageClassifier.Model // MLImageClassifier.Model itself is Sendable

    init(model: MLImageClassifier.Model) {
        self.model = model
    }
    // No mutable state, so it's safe to be Sendable.
    // If it had mutable state, you'd need locks or actor isolation.
}

// Example of a Sendable closure (used less directly in this context but good to know)
func processDataInBackground(completion: @Sendable @escaping (Result<[String], Error>) -> Void) {
    Task.detached {
        // Perform heavy data processing
        let result: Result<[String], Error> = .success(["item1", "item2"])
        completion(result)
    }
}
