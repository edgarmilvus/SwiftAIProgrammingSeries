
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
func saveNewMessageAsync(conversation: Conversation, role: String, content: String) async throws {
    // You can create a new ModelContext for background operations
    // or use an existing one if it's already isolated.
    let backgroundContext = ModelContext(conversation.modelContext!.container) // Re-uses the same container

    await backgroundContext.perform { // Ensures operations are on the context's actor
        let newMessage = Message(role: role, content: content)
        backgroundContext.insert(newMessage)
        // Link to conversation (if conversation was fetched in this context)
        // If conversation is @Bindable and passed, it needs to be re-fetched in this context
        // Or, better, pass the conversation's PersistentIdentifier and re-fetch it.
        // For simplicity, assume conversation is available in this context for now.
        // In a real app, you'd fetch the conversation by its ID in this context.
        // let conversationInContext = try backgroundContext.fetch(FetchDescriptor<Conversation>(predicate: #Predicate { $0.id == conversation.id })).first
        // conversationInContext?.messages.append(newMessage)

        try backgroundContext.save() // Explicit save for background context
    }
}

@available(iOS 18.0, *)
actor PersistenceActor { // A custom actor to encapsulate persistence operations
    private let modelContainer: ModelContainer
    private let modelContext: ModelContext

    init(modelContainer: ModelContainer) {
        self.modelContainer = modelContainer
        self.modelContext = ModelContext(modelContainer)
    }

    func addMessage(conversationID: UUID, role: String, content: String) async throws {
        // All operations within an actor are isolated
        let descriptor = FetchDescriptor<Conversation>(predicate: #Predicate { $0.id == conversationID })
        guard let conversation = try modelContext.fetch(descriptor).first else {
            throw PersistenceError.conversationNotFound
        }

        let newMessage = Message(role: role, content: content)
        conversation.messages.append(newMessage) // Modifying the relationship
        modelContext.insert(newMessage) // Also insert the new message itself
        try modelContext.save()
    }

    enum PersistenceError: Error {
        case conversationNotFound
    }
}
