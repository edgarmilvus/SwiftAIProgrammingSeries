
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import ARKit
import RealityKit
import Observation

@available(visionOS 1.0, *)
@Observable
final class HandTrackingManager {
    // The @Observable macro allows SwiftUI views to react 
    // automatically to changes in the hand state.
    var isLeftHandTracked: Bool = false
    var isRightHandTracked: Bool = false
    
    // We use a Task to manage the lifecycle of the tracking stream
    private var trackingTask: Task<Void, Never>?

    /// Starts the asynchronous stream of hand updates.
    /// This demonstrates the use of Swift 6 concurrency to handle 
    /// high-frequency spatial data.
    func startTracking(session: ARKitSession) {
        trackingTask = Task {
            do {
                // HandTrackingProvider is an actor-isolated provider 
                // that streams HandAnchor updates.
                let handProvider = HandTrackingProvider()
                try await handProvider.startTrackedHands()
                
                // We iterate over the stream of hand anchors using AsyncSequence.
                // This is non-blocking and highly efficient.
                for await update in handProvider.anchorUpdates {
                    await processHandUpdate(update)
                }
            } catch {
                print("Hand tracking failed: \(error)")
            }
        }
    }

    /// Processes updates on the @MainActor to ensure thread-safety 
    /// when updating @Observable properties.
    @MainActor
    private func processHandUpdate(_ update: HandAnchor) {
        // Update the UI state safely on the MainActor.
        // The 'update' object is Sendable, making this transfer safe.
        if update.chirality == .left {
            isLeftHandTracked = true
        } else {
            isRightHandTracked = true
        }
        
        // In a real implementation, we would extract joint transforms here.
        // let indexFingerTip = update.handSkeleton.joint(.indexFingerTip)
    }

    func stopTracking() {
        trackingTask?.cancel()
    }
}
