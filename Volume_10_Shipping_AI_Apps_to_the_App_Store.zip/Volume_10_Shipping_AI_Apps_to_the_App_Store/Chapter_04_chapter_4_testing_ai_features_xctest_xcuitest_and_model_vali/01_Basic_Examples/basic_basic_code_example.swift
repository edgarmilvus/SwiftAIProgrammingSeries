
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import XCTest
import CoreML

// MARK: - Domain Models

/// Represents the possible outcomes of a sentiment analysis task.
/// Conforms to `Sendable` to ensure it can be safely passed across concurrency boundaries in Swift 6.
@available(iOS 18.0, *)
enum SentimentResult: Sendable, Equatable {
    case positive(confidence: Double)
    case negative(confidence: Double)
    case neutral(confidence: Double)
    case failure(Error)
    
    /// A custom error type for AI-specific failures.
    enum AnalysisError: Error, LocalizedError, Sendable {
        case modelLoadingFailed
        case inferenceTimeout
        case invalidInput
        
        var errorDescription: String? {
            switch self {
            case .modelLoadingFailed: return "The ML model could not be loaded into memory."
            case .inferenceTimeout: return "The model took too long to respond."
            case .invalidInput: return "The provided text was empty or invalid."
            }
        }
    }
}

// MARK: - Abstraction Layer

/// The `SentimentModelProtocol` defines the interface for any sentiment analysis engine.
/// This abstraction is critical for testing; it allows us to swap a real CoreML model 
/// with a controlled mock during unit tests.
@available(iOS 18.0, *)
protocol SentimentModelProtocol: Sendable {
    /// Performs inference on the provided text.
    /// - Parameter text: The string to analyze.
    /// - Returns: A `SentimentResult` containing the classification and confidence.
    func predict(text: String) async throws -> SentimentResult
}

// MARK: - Production Implementation

/// A production-ready service that wraps a real CoreML model.
/// Using an `actor` ensures that the state of the service is protected from data races,
/// which is vital when dealing with asynchronous ML inference.
@available(iOS 18.0, *)
actor SentimentService {
    private let model: SentimentModelProtocol
    
    /// Initializes the service with a specific model implementation.
    /// - Parameter model: An object conforming to `SentimentModelProtocol`.
    init(model: SentimentModelProtocol) {
        self.model = model
    }
    
    /// Analyzes the sentiment of a given journal entry.
    /// - Parameter text: The user's input.
    /// - Returns: The analyzed sentiment.
    func analyzeEntry(_ text: String) async -> SentimentResult {
        // 1. Pre-processing validation
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return .failure(SentimentResult.AnalysisError.invalidInput)
        }
        
        do {
            // 2. Perform the asynchronous inference
            return try await model.predict(text: text)
        } catch {
            // 3. Error handling for model-level failures
            return .failure(error)
        }
    }
}

// MARK: - Mock Implementation for Testing

/// A deterministic mock implementation of the sentiment model.
/// This allows us to test how our `SentimentService` reacts to specific outcomes 
/// (positive, negative, or error) without needing a real `.mlmodel` file.
@available(iOS 18.0, *)
struct MockSentimentModel: SentimentModelProtocol {
    /// A closure that allows us to define the behavior of the mock dynamically.
    /// This is a powerful pattern for testing different edge cases.
    let stubbedResult: (String) async throws -> SentimentResult
    
    func predict(text: String) async throws -> SentimentResult {
        return try await stubbedResult(text)
    }
}

// MARK: - Unit Tests

/// The test suite for validating the `SentimentService`.
@available(iOS 18.0, *)
final class SentimentServiceTests: XCTestCase {
    
    /// Tests that the service correctly returns a positive result when the model predicts it.
    func testAnalyzeEntry_WhenModelReturnsPositive_ReturnsPositive() async throws {
        // Arrange: Set up the mock to always return a positive result.
        let mock = MockSentimentModel { _ in
            .positive(confidence: 0.95)
        }
        let sut = SentimentService(model: mock) // sut = System Under Test
        
        // Act: Call the service.
        let result = await sut.analyzeEntry("I had a wonderful day!")
        
        // Assert: Verify the result matches our expectation.
        if case let .positive(confidence) = result {
            XCTAssertEqual(confidence, 0.95, accuracy: 0.001)
        } else {
            XCTFail("Expected .positive, but got \(result)")
        }
    }
    
    /// Tests that the service handles empty input strings gracefully.
    func testAnalyzeEntry_WhenInputIsEmpty_ReturnsInvalidInputError() async {
        // Arrange: Any model will do here.
        let mock = MockSentimentModel { _ in
            .neutral(confidence: 0.5)
        }
        let sut = SentimentService(model: mock)
        
        // Act: Pass an empty string.
        let result = await sut.analyzeEntry("   ")
        
        // Assert: Verify the service catches the error before calling the model.
        if case let .failure(error) = result {
            XCTAssertEqual(error as? SentimentResult.AnalysisError, .invalidInput)
        } else {
            XCTFail("Expected .failure(.invalidInput), but got \(result)")
        }
    }
    
    /// Tests that the service correctly propagates errors from the ML model.
    func testAnalyzeEntry_WhenModelFails_ReturnsFailure() async {
        // Arrange: Set up the mock to throw a specific error.
        let mock = MockSentimentModel { _ in
            throw SentimentResult.AnalysisError.modelLoadingFailed
        }
        let sut = SentimentService(model: mock)
        
        // Act: Call the service.
        let result = await sut.analyzeEntry("Standard text.")
        
        // Assert: Verify the error is propagated.
        if case let .failure(error) = result {
            XCTAssertEqual(error as? SentimentResult.AnalysisError, .modelLoadingFailed)
        } else {
            XCTFail("Expected .failure(.modelLoadingFailed), but got \(result)")
        }
    }
}
