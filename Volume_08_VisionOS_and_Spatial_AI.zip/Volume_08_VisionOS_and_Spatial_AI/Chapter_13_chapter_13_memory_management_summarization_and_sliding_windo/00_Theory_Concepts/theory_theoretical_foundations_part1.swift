
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents a single unit of conversation.
/// Must be Sendable to move between the ContextActor and the MainActor.
struct ChatMessage: Sendable, Identifiable, Hashable {
    let id: UUID
    let role: String // "user" or "assistant"
    let content: String
    let timestamp: Date
}

/// A thread-safe manager that handles the logic of pruning and summarizing.
/// Using an actor ensures that context mutations are atomic.
@available(iOS 18.0, *)
actor ContextManager {
    private var fullHistory: [ChatMessage] = []
    private var runningSummary: String = ""
    
    // Configuration constants
    private let maxWindowTokens: Int = 2000
    private let summarizationThreshold: Int = 5000
    
    /// Adds a message and triggers memory management if thresholds are met.
    func appendMessage(_ message: ChatMessage) async {
        fullHistory.append(message)
        
        if await shouldSummarize() {
            await performSummarization()
        }
        
        await applySlidingWindow()
    }
    
    private func shouldSummarize() async -> Bool {
        // In a real app, use a Tokenizer to get exact counts.
        // Here we simulate based on character count for brevity.
        let totalChars = fullHistory.reduce(0) { $0 + $1.content.count }
        return totalChars > summarizationThreshold
    }
    
    private func performSummarization() async {
        // 1. Extract old messages
        // 2. Call LLM API to summarize
        // 3. Update runningSummary
        // 4. Clear old messages from fullHistory
        print("Performing semantic summarization...")
    }
    
    private func applySlidingWindow() async {
        // Logic to keep only the most recent messages 
        // that fit within maxWindowTokens.
    }
    
    /// Returns the prepared prompt for the LLM.
    /// This is the "Effective Context".
    func getEffectiveContext() -> String {
        let recentContext = fullHistory.map { "\($0.role): \($0.content)" }.joined(separator: "\n")
        return "Summary: \(runningSummary)\n\nRecent History:\n\(recentContext)"
    }
}

/// The ViewModel that the SwiftUI view observes.
@available(iOS 18.0, *)
@Observable
final class ChatViewModel: Sendable {
    // The UI observes this property.
    // Note: We store a 'viewable' version of messages to avoid actor isolation issues.
    var visibleMessages: [ChatMessage] = []
    
    private let contextManager = ContextManager()
    
    @MainActor
    func sendMessage(_ text: String) async {
        let userMsg = ChatMessage(id: UUID(), role: "user", content: text, timestamp: Date())
        
        // 1. Update UI immediately (Optimistic Update)
        visibleMessages.append(userMsg)
        
        // 2. Send to the Actor for processing
        await contextManager.appendMessage(userMsg)
        
        // 3. Fetch response from LLM (Simplified)
        let responseText = await mockLLMResponse(for: text)
        let assistantMsg = ChatMessage(id: UUID(), role: "assistant", content: responseText, timestamp: Date())
        
        // 4. Update Actor and UI
        await contextManager.appendMessage(assistantMsg)
        visibleMessages.append(assistantMsg)
    }
    
    private func mockLLMResponse(for input: String) async -> String {
        try? await Task.sleep(for: .seconds(1))
        return "This is a simulated response to: \(input)"
    }
}
