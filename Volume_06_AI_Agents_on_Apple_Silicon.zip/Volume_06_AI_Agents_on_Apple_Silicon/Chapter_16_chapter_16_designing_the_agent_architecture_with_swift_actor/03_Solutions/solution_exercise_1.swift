
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// Swift 6
@available(iOS 18.0, macOS 15.0, *)
struct LLMService {
    func generateResponse(for prompt: String) async throws -> String {
        // Simulate network latency or computation time
        try await Task.sleep(for: .seconds(1))
        
        if prompt.lowercased().contains("hello") {
            return "Hello there! How can I assist you today?"
        } else if prompt.lowercased().contains("weather") {
            return "I'm sorry, I don't have access to real-time weather data."
        } else if prompt.lowercased().contains("summarize") {
            return "Summary: The provided text is about a project deadline."
        } else if prompt.lowercased().contains("draft a polite reply") {
            return "Draft: Thank you for the update. I will ensure tasks are completed."
        } else if prompt.lowercased().contains("sentiment") {
            return "Sentiment: Neutral"
        } else {
            return "You asked: '\(prompt)'. This is a generic LLM response."
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
actor LLMClientActor {
    private let llmService: LLMService // A simulated or real LLM client

    init(llmService: LLMService) {
        self.llmService = llmService
    }

    /// Sends a prompt to the LLM and returns its response.
    func sendPrompt(text: String) async throws -> String {
        print("LLMClientActor: Received prompt: '\(text)'")
        // Simulate LLM processing
        let response = try await llmService.generateResponse(for: text)
        print("LLMClientActor: Generated response: '\(response)'")
        return response
    }
}

// Example Usage (e.g., from a ViewModel or UI component)
@available(iOS 18.0, macOS 15.0, *)
class ChatViewModel: ObservableObject {
    @Published var currentPrompt: String = ""
    @Published var llmResponse: String = "Waiting for your prompt..."
    
    private let llmClient: LLMClientActor

    init() {
        self.llmClient = LLMClientActor(llmService: LLMService())
    }

    func submitPrompt() {
        let promptToSend = currentPrompt
        currentPrompt = "" // Clear input field
        
        Task {
            do {
                let response = try await llmClient.sendPrompt(text: promptToSend)
                await MainActor.run {
                    self.llmResponse = response
                }
            } catch {
                await MainActor.run {
                    self.llmResponse = "Error: \(error.localizedDescription)"
                }
            }
        }
    }
}
