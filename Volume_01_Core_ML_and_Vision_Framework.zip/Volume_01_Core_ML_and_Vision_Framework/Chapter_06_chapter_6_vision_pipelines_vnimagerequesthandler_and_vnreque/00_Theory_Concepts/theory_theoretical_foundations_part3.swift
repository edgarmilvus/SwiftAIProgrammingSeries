
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import Vision
    import CoreML // For VNCoreMLRequest example

    @available(iOS 18.0, *)
    actor VisionProcessor {
        private var imageRequestHandler: VNImageRequestHandler?

        func processImage(_ pixelBuffer: CVPixelBuffer) async throws -> [VNObservation] {
            // Initialize handler with the image data
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            self.imageRequestHandler = handler // Optional: keep a strong reference if needed for state

            // Create requests
            let faceDetectionRequest = VNDetectFaceRectanglesRequest()
            let textRecognitionRequest = VNRecognizeTextRequest()
            textRecognitionRequest.recognitionLevel = .accurate // Configure properties

            // Example of a custom Core ML model request (assuming 'MyCustomModel' exists)
            // let coreMLModel = try VNCoreMLModel(for: MyCustomModel().model)
            // let customClassificationRequest = VNCoreMLRequest(model: coreMLModel)

            // Perform requests in a background task
            return try await Task.detached {
                // Perform can throw, so it's marked with 'try'
                try handler.perform([faceDetectionRequest, textRecognitionRequest /*, customClassificationRequest */])

                // Aggregate results from all requests
                var allObservations: [VNObservation] = []
                if let faceResults = faceDetectionRequest.results {
                    allObservations.append(contentsOf: faceResults)
                }
                if let textResults = textRecognitionRequest.results {
                    allObservations.append(contentsOf: textResults)
                }
                // if let customResults = customClassificationRequest.results {
                //     allObservations.append(contentsOf: customResults)
                // }
                return allObservations
            }.value
        }
    }

    // Usage example in a UI context (e.g., from an AVCaptureVideoOutput delegate)
    @available(iOS 18.0, *)
    class CameraViewModel: ObservableObject {
        private let visionProcessor = VisionProcessor()
        @Published var detectedObjects: [VNObservation] = []

        func handleNewCameraFrame(pixelBuffer: CVPixelBuffer) {
            Task {
                do {
                    let results = try await visionProcessor.processImage(pixelBuffer)
                    await MainActor.run {
                        self.detectedObjects = results
                    }
                } catch {
                    print("Vision error: \(error)")
                }
            }
        }
    }
    