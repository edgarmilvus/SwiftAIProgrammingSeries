
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreData
import CloudKit
import OSLog

@available(iOS 18.0, macOS 15.0, *)
@MainActor
class PersistenceController {
    static let shared = PersistenceController()
    
    let container: NSPersistentCloudKitContainer
    private let logger = Logger(subsystem: "com.aijournal.app", category: "Persistence")

    init(inMemory: Bool = false) {
        // 1. Initialize the CloudKit-enabled container
        container = NSPersistentCloudKitContainer(name: "AIJournalModel")
        
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve persistent store description.")
        }

        if inMemory {
            description.url = URL(fileURLWithPath: "/dev/null")
        }

        /*
         ENTITLEMENTS REQUIRED (Xcode > Signing & Capabilities):
         1. iCloud: Enable 'CloudKit' and check your specific container identifier.
         2. Background Modes: Enable 'Remote notifications' to allow CloudKit to wake the app for sync.
         3. App Sandbox (macOS): Ensure 'Network: Outgoing Connections' is enabled.
         */

        // 2. Enable History Tracking (Crucial for CloudKit to know what changed)
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)
        
        // 3. Enable Remote Change Notifications (Allows the app to react to cloud updates)
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)

        // 4. Load the stores with granular error handling
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                self.handleLoadingError(error)
            }
        }
        
        // 5. Configure Context for seamless synchronization
        // Automatically merge changes from the cloud into the view context
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        // Use a policy that resolves conflicts by prioritizing the in-memory version 
        // over the disk version during the initial sync/merge process.
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }

    private func handleLoadingError(_ error: NSError) {
        // Check specifically for CloudKit container mismatches or permission issues
        if error.domain == NSCocoaErrorDomain && error.code == NSPersistentStoreSaveError {
            logger.error("Critical: Persistent Store Save Error. Check CloudKit Entitlements.")
        } else if error.domain == CKErrorDomain {
            logger.error("Critical: CloudKit Error. Ensure the Container ID matches Xcode settings: \(error.localizedDescription)")
        } else {
            logger.error("Unresolved error \(error), \(error.userInfo)")
        }
        
        // In a production app, trigger a UI alert rather than fatalError
        fatalError("Unresolved error \(error)")
    }
}
