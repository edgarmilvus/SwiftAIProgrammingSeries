/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * FILE: app/projects/[id]/dashboard/update-form.tsx
 * PURPOSE: Client Component.
 *          Handles user interaction and calls the Server Action.
 * ==============================================================================
 */
'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { updateProjectName } from '@/app/actions'; // Import Server Action

const initialState = {
  message: '',
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button 
      type="submit" 
      disabled={pending}
      className="bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50"
    >
      {pending ? 'Saving...' : 'Save Changes'}
    </button>
  );
}

export function UpdateProjectForm({ projectId, initialName }: { projectId: string; initialName: string }) {
  // useFormState hooks up the form to the Server Action
  const [state, formAction] = useFormState(updateProjectName, initialState);

  return (
    <form action={formAction} className="space-y-3">
      <input type="hidden" name="projectId" value={projectId} />
      
      <div>
        <label className="block text-sm font-medium mb-1">Project Name</label>
        <input 
          name="projectName" 
          defaultValue={initialName}
          className="w-full border p-2 rounded text-black"
        />
      </div>

      <SubmitButton />
      
      {state?.message && (
        <p className="text-sm text-green-600">{state.message}</p>
      )}
    </form>
  );
}
