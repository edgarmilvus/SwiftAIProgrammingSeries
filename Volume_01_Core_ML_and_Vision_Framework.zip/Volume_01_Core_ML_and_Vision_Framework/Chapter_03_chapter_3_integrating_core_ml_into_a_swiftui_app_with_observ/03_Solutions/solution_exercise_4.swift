
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AVFoundation
import CoreML
import UIKit
import VideoToolbox

// MARK: - UIImage Extension (from Exercise 1, reused)

extension UIImage {
    func toCVPixelBuffer(width: Int, height: Int, pixelFormat: OSType) -> CVPixelBuffer? {
        // ... (Same implementation as in Exercise 1) ...
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: AnyObject] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:] as AnyObject
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: width,
                                height: height,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        guard let cgImage = self.cgImage else {
            CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

        return pixelBuffer
    }
}

// MARK: - Camera Preview View Representable

struct CameraPreviewView: UIViewRepresentable {
    class Coordinator: NSObject {
        var parent: CameraPreviewView
        init(_ parent: CameraPreviewView) { self.parent = parent }
    }

    let session: AVCaptureSession

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        if let previewLayer = uiView.layer.sublayers?.first as? AVCaptureVideoPreviewLayer {
            previewLayer.frame = uiView.bounds
        }
    }
}

// MARK: - LiveClassifier Observable Object

@Observable
class LiveClassifierViewModel: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    var classificationResult: String = "Scanning..."
    var confidence: String = ""
    var cameraPermissionGranted: Bool = false
    var isModelLoaded: Bool = false
    var errorMessage: String?

    let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoOutputQueue = DispatchQueue(label: "videoOutputQueue", qos: .userInitiated)

    // Core ML Model and its requirements
    private var coreMLModel: SqueezeNet?
    private let modelInputWidth: Int = 227
    private let modelInputHeight: Int = 227
    private let modelInputPixelFormat: OSType = kCVPixelFormatType_32BGRA

    // Throttling mechanism
    private let inferenceInterval: TimeInterval = 0.5 // Process every 0.5 seconds
    private var lastInferenceTime: Date = .distantPast

    override init() {
        super.init()
        checkCameraPermissions()
        Task { await loadModel() }
    }

    @MainActor
    private func loadModel() async {
        do {
            self.coreMLModel = try SqueezeNet(configuration: MLModelConfiguration())
            self.isModelLoaded = true
            setupCamera() // Setup camera only after model is loaded
        } catch {
            self.errorMessage = "Failed to load Core ML model: \(error.localizedDescription)"
            print("Model Loading Error: \(error)")
        }
    }

    @MainActor
    func checkCameraPermissions() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            cameraPermissionGranted = true
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    self?.cameraPermissionGranted = granted
                    if granted && self?.isModelLoaded == true {
                        self?.setupCamera()
                    }
                }
            }
        case .denied, .restricted:
            cameraPermissionGranted = false
            errorMessage = "Camera access denied. Please enable it in Settings."
        @unknown default:
            cameraPermissionGranted = false
            errorMessage = "Unknown camera permission status."
        }
    }

    @MainActor
    private func setupCamera() {
        guard cameraPermissionGranted && isModelLoaded else { return }

        captureSession.beginConfiguration()
        captureSession.sessionPreset = .vga640x480 // Lower resolution for performance

        // Remove existing inputs/outputs if reconfiguring
        for input in captureSession.inputs { captureSession.removeInput(input) }
        for output in captureSession.outputs { captureSession.removeOutput(output) }

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            errorMessage = "No back camera found."
            captureSession.commitConfiguration()
            return
        }

        guard let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            errorMessage = "Could not create video device input."
            captureSession.commitConfiguration()
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            errorMessage = "Could not add video input to capture session."
            captureSession.commitConfiguration()
            return
        }

        videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        // Ensure pixel format matches Core ML model requirement for direct CVPixelBuffer use
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: modelInputPixelFormat]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            errorMessage = "Could not add video output to capture session."
            captureSession.commitConfiguration()
            return
        }

        // Set orientation for the video output if needed
        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }

        captureSession.commitConfiguration()
        captureSession.startRunning()
    }

    func stopCamera() {
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        let now = Date()
        guard now.timeIntervalSince(lastInferenceTime) > inferenceInterval else { return }
        lastInferenceTime = now

        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            print("Failed to get CVPixelBuffer from CMSampleBuffer.")
            return
        }

        Task { @MainActor in // Perform inference on a background thread, update UI on MainActor
            guard let model = self.coreMLModel else { return }

            // Resize CVPixelBuffer if needed. SqueezeNet expects 227x227.
            // CMSampleBufferGetImageBuffer usually gives the camera's native resolution.
            // We need to convert/resize this CVPixelBuffer to the model's expected size.
            // This is a common bottleneck.
            var resizedPixelBuffer: CVPixelBuffer?
            VTImageBufferCreateThumbnail(allocator: kCFAllocatorDefault,
                                         imageBuffer: pixelBuffer,
                                         maxPixelSize: Int32(max(modelInputWidth, modelInputHeight)),
                                         options: nil,
                                         thumbnailBufferOut: &resizedPixelBuffer)

            guard let finalPixelBuffer = resizedPixelBuffer else {
                print("Failed to resize CVPixelBuffer for model input.")
                return
            }

            do {
                let input = SqueezeNetInput(image: finalPixelBuffer)
                let output = try await model.prediction(input: input)

                if let (label, confidenceValue) = output.featureValue(for: "classLabelProbs")?.dictionaryValue.max(by: { $0.value.doubleValue < $1.value.doubleValue }) {
                    self.classificationResult = label
                    self.confidence = String(format: "%.2f%%", confidenceValue.doubleValue * 100)
                } else {
                    self.classificationResult = "Unknown"
                    self.confidence = "N/A"
                }
            } catch {
                print("Live inference error: \(error.localizedDescription)")
                self.classificationResult = "Error"
                self.confidence = "N/A"
            }
        }
    }
}

// MARK: - SwiftUI View

struct LiveRecipeScannerView: View {
    @State private var viewModel = LiveClassifierViewModel()

    var body: some View {
        ZStack {
            // Camera Preview Layer
            if viewModel.cameraPermissionGranted && viewModel.isModelLoaded {
                CameraPreviewView(session: viewModel.captureSession)
                    .ignoresSafeArea(.all, edges: .all)
            } else if viewModel.errorMessage != nil {
                Text(viewModel.errorMessage!)
                    .foregroundColor(.red)
                    .padding()
            } else if !viewModel.cameraPermissionGranted {
                VStack {
                    Text("Camera access is required for this feature.")
                        .foregroundColor(.white)
                        .padding()
                    Button("Grant Camera Access") {
                        viewModel.checkCameraPermissions() // Re-request permission
                    }
                    .buttonStyle(.borderedProminent)
                }
            } else if !viewModel.isModelLoaded {
                ProgressView("Loading AI Model...")
                    .foregroundColor(.white)
            }

            // Overlay for classification results
            VStack {
                Spacer()
                if viewModel.cameraPermissionGranted && viewModel.isModelLoaded {
                    VStack {
                        Text(viewModel.classificationResult)
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.7), radius: 3, x: 0, y: 0)
                        Text(viewModel.confidence)
                            .font(.title2)
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.7), radius: 3, x: 0, y: 0)
                    }
                    .padding()
                    .background(.black.opacity(0.5))
                    .cornerRadius(10)
                }
                Spacer().frame(height: 50) // Adjust spacing from bottom
            }
        }
        .onAppear {
            // Ensure camera setup happens when view appears
            viewModel.checkCameraPermissions() // Re-check on appear
            if viewModel.cameraPermissionGranted && viewModel.isModelLoaded {
                viewModel.setupCamera()
            }
        }
        .onDisappear {
            viewModel.stopCamera()
        }
        .navigationTitle("Live Recipe Scanner")
        .navigationBarHidden(true) // Hide navigation bar for full screen camera
    }
}

// Don't forget to add NSCameraUsageDescription to Info.plist
// <key>NSCameraUsageDescription</key>
// <string>This app needs camera access to scan ingredients in real-time.</string>
