
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import Speech
import AVFoundation

class SmartAssistantViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.textColor = .systemGray
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let listenButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Listening", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Listening", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemGray
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false
        return button
    }()

    private let transcriptionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .label
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Listening for commands..."
        return label
    }()

    private let commandOutputLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        label.textColor = .systemPurple
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "No command detected."
        return label
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    // MARK: - Command Recognition State
    private let wakeWord = "Aura"
    private var isWaitingForWakeWord = true
    private var commandProcessingTimer: Timer? // To reset state after a command
    private let commandTimeout: TimeInterval = 3.0 // Time to wait for command after wake word

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestAuthorization()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopListening()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Aura Home Assistant"

        let buttonStackView = UIStackView(arrangedSubviews: [listenButton, stopButton])
        buttonStackView.axis = .horizontal
        buttonStackView.distribution = .fillEqually
        buttonStackView.spacing = 16
        buttonStackView.translatesAutoresizingMaskIntoConstraints = false

        let contentStackView = UIStackView(arrangedSubviews: [
            statusLabel,
            buttonStackView,
            transcriptionLabel,
            commandOutputLabel
        ])
        contentStackView.axis = .vertical
        contentStackView.spacing = 20
        contentStackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(contentStackView)

        NSLayoutConstraint.activate([
            contentStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            contentStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            contentStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            contentStackView.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            buttonStackView.heightAnchor.constraint(equalToConstant: 50),
            transcriptionLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 50),
            commandOutputLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 80)
        ])

        listenButton.addTarget(self, action: #selector(startListeningTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopListeningTapped), for: .touchUpInside)
    }

    // MARK: - Speech Recognition Setup
    private func setupSpeechRecognizer() {
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        speechRecognizer?.delegate = self
    }

    // MARK: - Authorization
    private func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    let isAuthorized = (authStatus == .authorized && granted)
                    self.listenButton.isEnabled = isAuthorized
                    self.stopButton.isEnabled = false // Ensure stop is disabled initially

                    if isAuthorized {
                        self.statusLabel.text = "Ready for voice commands. Say '\(self.wakeWord}' to begin."
                        self.statusLabel.textColor = .systemGreen
                    } else {
                        self.statusLabel.text = "Authorization denied. Enable in Settings."
                        self.statusLabel.textColor = .systemRed
                    }
                }
            }
        }
    }

    // MARK: - Listening Actions
    @objc private func startListeningTapped() {
        if audioEngine.isRunning {
            stopListening()
            return
        }

        do {
            try startContinuousListening()
            listenButton.isEnabled = false
            stopButton.isEnabled = true
            transcriptionLabel.text = "Listening..."
            commandOutputLabel.text = "No command detected."
            statusLabel.text = "Say '\(wakeWord}'."
            statusLabel.textColor = .systemBlue
            isWaitingForWakeWord = true
        } catch {
            displayError(error, title: "Listening Error")
            listenButton.isEnabled = true
            stopButton.isEnabled = false
            statusLabel.text = "Error starting listening."
            statusLabel.textColor = .systemRed
        }
    }

    @objc private func stopListeningTapped() {
        stopListening()
        listenButton.isEnabled = true
        stopButton.isEnabled = false
        statusLabel.text = "Listening stopped."
        statusLabel.textColor = .systemGray
        transcriptionLabel.text = "Tap 'Start Listening' to activate."
        commandOutputLabel.text = "No command detected."
    }

    private func startContinuousListening() throws {
        // Cancel previous task if running
        recognitionTask?.cancel()
        recognitionTask = nil

        // Configure audio session
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        // Setup recognition request
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true // Essential for real-time command detection

        // Configure audio engine
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        // Start recognition task
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            if let result = result {
                let transcribedText = result.bestTranscription.formattedString.lowercased()
                DispatchQueue.main.async {
                    self.transcriptionLabel.text = "Heard: \"\(transcribedText)\""
                }

                self.processVoiceCommand(transcribedText: transcribedText, isFinal: result.isFinal)
            }

            if error != nil {
                // If an error occurs, attempt to restart listening for continuous operation
                print("Speech recognition error: \(error!.localizedDescription)")
                DispatchQueue.main.async {
                    self.displayError(error!, title: "Speech Recognition Error")
                    self.stopListening() // Stop current session
                    // Optionally, implement a retry mechanism here
                    self.statusLabel.text = "Error, retrying..."
                    self.statusLabel.textColor = .systemOrange
                    // For this exercise, we'll just stop. A real app might restart after a delay.
                }
            }
        }
    }

    private func stopListening() {
        commandProcessingTimer?.invalidate()
        commandProcessingTimer = nil
        
        audioEngine.stop()
        if let inputNode = audioEngine.inputNode {
            inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - Command Processing
    private func processVoiceCommand(transcribedText: String, isFinal: Bool) {
        // Use a background queue for command parsing to avoid blocking the audio thread or main thread
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }

            if self.isWaitingForWakeWord {
                if transcribedText.contains(self.wakeWord.lowercased()) {
                    DispatchQueue.main.async {
                        self.statusLabel.text = "Wake word detected! Listening for command..."
                        self.statusLabel.textColor = .systemOrange
                        self.commandOutputLabel.text = "Say your command."
                    }
                    self.isWaitingForWakeWord = false
                    // Start a timer to reset if no command is given within timeout
                    self.startCommandProcessingTimer()
                }
            } else {
                // We are in command processing mode
                self.commandProcessingTimer?.invalidate() // Reset timer on new speech
                self.startCommandProcessingTimer() // Restart timer

                // Check for commands
                if transcribedText.contains("turn on") && transcribedText.contains("lights") {
                    self.triggerAction(action: "Turn On", target: "Lights", transcribedText: transcribedText, isFinal: isFinal)
                } else if transcribedText.contains("set") && transcribedText.contains("thermostat") {
                    if let tempRange = transcribedText.range(of: #"\d{1,2}\s*degrees"#, options: .regularExpression),
                       let temp = transcribedText[tempRange].replacingOccurrences(of: "degrees", with: "").trimmingCharacters(in: .whitespacesAndNewlines) {
                        self.triggerAction(action: "Set Thermostat", target: "\(temp) degrees", transcribedText: transcribedText, isFinal: isFinal)
                    } else {
                        self.triggerAction(action: "Set Thermostat", target: "Unknown Temperature", transcribedText: transcribedText, isFinal: isFinal)
                    }
                } else if transcribedText.contains("play") && transcribedText.contains("music") {
                    self.triggerAction(action: "Play", target: "Music", transcribedText: transcribedText, isFinal: isFinal)
                }
                // Add more commands here
            }
        }
    }

    private func triggerAction(action: String, target: String, transcribedText: String, isFinal: Bool) {
        // Only trigger action on final results to mitigate false positives
        guard isFinal else { return }

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.commandOutputLabel.text = "Executing: \(action) \(target)!"
            self.commandOutputLabel.textColor = .systemGreen
            self.transcriptionLabel.text = "Command recognized: \"\(transcribedText)\""
            self.statusLabel.text = "Action complete. Say '\(self.wakeWord}'."
            self.statusLabel.textColor = .systemGreen
        }

        // Reset to waiting for wake word after a command is processed
        self.resetCommandState()
    }

    private func startCommandProcessingTimer() {
        commandProcessingTimer?.invalidate()
        commandProcessingTimer = Timer.scheduledTimer(withTimeInterval: commandTimeout, repeats: false) { [weak self] _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if !self.isWaitingForWakeWord { // Only reset if we were in command processing mode
                    self.resetCommandState()
                    self.statusLabel.text = "Command timed out. Say '\(self.wakeWord}' to restart."
                    self.statusLabel.textColor = .systemOrange
                }
            }
        }
    }

    private func resetCommandState() {
        isWaitingForWakeWord = true
        commandProcessingTimer?.invalidate()
        commandProcessingTimer = nil
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            if self.audioEngine.isRunning {
                self.commandOutputLabel.text = "No command detected."
                self.commandOutputLabel.textColor = .systemPurple
            }
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        DispatchQueue.main.async {
            self.listenButton.isEnabled = available
            self.statusLabel.text = available ? "Ready for voice commands." : "Speech recognition unavailable."
            self.statusLabel.textColor = available ? .systemGreen : .systemRed
        }
    }

    // MARK: - Error Handling
    private func displayError(_ error: Error, title: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
}
