
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML // Assuming CoreML for inference

// A hypothetical struct to represent a single prediction outcome
struct PredictionResult: Sendable { // Must be Sendable for async/actor usage
    let actualLabel: String
    let predictedLabel: String
}

@available(iOS 18.0, *)
actor ModelEvaluator {
    private var results: [PredictionResult] = []
    private var confusionMatrix: ConfusionMatrix = ConfusionMatrix() // Custom struct below

    func addPrediction(actual: String, predicted: String) {
        let result = PredictionResult(actualLabel: actual, predictedLabel: predicted)
        results.append(result)
        confusionMatrix.update(actual: actual, predicted: predicted)
    }

    func evaluateDataset(model: MLModel, dataProvider: some AsyncSequence<Image, Error>) async throws {
        // Assume Image is a type that can be converted to MLFeatureProvider
        for try await image in dataProvider {
            let input = try MLFeatureProvider(image: image) // Hypothetical conversion
            let output = try await model.prediction(from: input)
            
            // Assuming the model outputs a string label
            let predictedLabel = output.featureValue(for: "label")?.stringValue ?? "unknown"
            let actualLabel = image.trueLabel // Hypothetical true label from data
            
            await addPrediction(actual: actualLabel, predicted: predictedLabel)
        }
    }

    // Asynchronously calculate metrics
    func calculateMetrics() async -> (accuracy: Double, precision: Double, recall: Double) {
        // Perform calculations based on the accumulated confusionMatrix
        let tp = confusionMatrix.truePositives
        let fp = confusionMatrix.falsePositives
        let fn = confusionMatrix.falseNegatives
        let tn = confusionMatrix.trueNegatives
        let total = Double(tp + fp + fn + tn)

        let accuracy = total > 0 ? Double(tp + tn) / total : 0.0
        let precision = (tp + fp) > 0 ? Double(tp) / Double(tp + fp) : 0.0
        let recall = (tp + fn) > 0 ? Double(tp) / Double(tp + fn) : 0.0

        return (accuracy, precision, recall)
    }
}
