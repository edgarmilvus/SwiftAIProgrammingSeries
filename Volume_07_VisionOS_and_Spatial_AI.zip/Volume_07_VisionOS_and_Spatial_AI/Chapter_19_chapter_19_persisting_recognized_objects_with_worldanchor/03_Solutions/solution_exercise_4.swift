
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import ARKit
import RealityKit
import SwiftData
import Foundation

@Model
class Artifact {
    var id: UUID
    var name: String
    var anchorID: UUID
    var lastKnownPosition: SIMD3<Float>
    
    init(id: UUID, name: String, anchorID: UUID, position: SIMD3<Float>) {
        self.id = id
        self.name = name
        self.anchorID = anchorID
        self.lastKnownPosition = position
    }
}

@MainActor
class ProximityManager {
    private var modelContext: ModelContext
    private var worldTracking: WorldTrackingProvider?
    private var activeEntities: [UUID: Entity] = [:]
    
    let activationRadius: Float = 3.0
    let deactivationRadius: Float = 7.0

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    func update(userTransform: simd_float4x4) {
        let userPosition = userTransform.columns.3.xyz // Helper to get translation
        
        let descriptor = FetchDescriptor<Artifact>()
        guard let allArtifacts = try? modelContext.fetch(descriptor) else { return }

        for artifact in allArtifacts {
            let distance = simd_distance(userPosition, artifact.lastKnownPosition)
            
            if distance < activationRadius {
                // 1. Needs to be rendered
                if activeEntities[artifact.id] == nil {
                    activateArtifact(artifact)
                }
            } else if distance > deactivationRadius {
                // 2. Too far, remove from scene to save memory/GPU
                if let entity = activeEntities[artifact.id] {
                    entity.removeFromParent()
                    activeEntities.removeValue(forKey: artifact.id)
                }
            }
            // 3. Between 3m and 7m: Do nothing (keep in memory, but not in scene)
        }
    }

    private func activateArtifact(_ artifact: Artifact) {
        // In a real app, we would find the WorldAnchor by its ID
        // and attach the ModelEntity to it.
        let entity = ModelEntity(mesh: .generateSphere(radius: 0.05))
        activeEntities[artifact.id] = entity
        // scene.addAnchor(...)
    }
}

extension simd_float4 {
    var xyz: SIMD3<Float> { SIMD3(x, y, z) }
}
