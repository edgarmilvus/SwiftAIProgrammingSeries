
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CryptoKit

enum ComplianceViolation: Error {
    case forbiddenContent(reason: String)
}

protocol ComplianceRule: Sendable {
    func validate(_ text: String) async -> Bool
    var reason: String { get }
}

struct BlacklistRule: ComplianceRule {
    let keywords: [String]
    let reason = "Contains forbidden keywords."
    
    func validate(_ text: String) async -> Bool {
        !keywords.contains { text.lowercased().contains($0.lowercased()) }
    }
}

struct PatternRule: ComplianceRule {
    let reason = "Detected sensitive pattern (e.g., Bank Account)."
    func validate(_ text: String) async -> Bool {
        // Simple regex for a pattern like XXXX-XXXX-XXXX
        let pattern = /\d{4}-\d{4}-\d{4}/
        return text.firstMatch(of: pattern) == nil
    }
}

actor AuditLogger {
    private let fileURL: URL
    
    init() {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        self.fileURL = paths[0].appendingPathComponent("compliance_audit.log")
    }
    
    func log(userID: String, prompt: String, status: String) async {
        // Use CryptoKit to hash the prompt for privacy-preserving auditing
        let promptData = Data(prompt.utf8)
        let hashedPrompt = SHA256.hash(data: promptData).compactMap { String(format: "%02x", $0) }.joined()
        
        let logEntry = "[\(Date())] User: \(userID) | PromptHash: \(hashedPrompt) | Status: \(status)\n"
        
        print("SECURE LOG: \(logEntry)") // In production, write to fileURL using FileHandle
        
        if let data = logEntry.data(using: .utf8) {
            // Real implementation would use FileHandle to append to the file
            try? data.append(to: fileURL)
        }
    }
}

// Extension to help with file appending
extension Data {
    func append(to url: URL) throws {
        if let handle = try? FileHandle(forWritingTo: url) {
            defer { handle.closeFile() }
            handle.seekToEndOfFile()
            handle.write(self)
        } else {
            try write(to: url)
        }
    }
}

actor SentinelMiddleware {
    private let rules: [ComplianceRule]
    private let logger: AuditLogger
    private let userID: String
    
    init(rules: [ComplianceRule], logger: AuditLogger, userID: String) {
        self.rules = rules
        self.logger = logger
        self.userID = userID
    }
    
    /// Wraps an incoming stream of tokens. If a violation occurs, the stream is terminated.
    func monitorStream(_ stream: AsyncStream<String>) -> AsyncStream<String> {
        let (newStream, continuation) = AsyncStream<String>.makeStream()
        
        Task {
            var accumulatedText = ""
            
            for await token in stream {
                accumulatedText += token
                
                // Check all rules against the current buffer
                var violationFound = false
                for rule in rules {
                    if await !rule.validate(accumulatedText) {
                        await logger.log(userID: userID, prompt: accumulatedText, status: "VIOLATION: \(rule.reason)")
                        continuation.finish() // Terminate the stream immediately
                        violationFound = true
                        break
                    }
                }
                
                if !violationFound {
                    continuation.yield(token)
                } else {
                    // We throw a specialized error by finishing the stream.
                    // In a real UI, the consumer would check for the violation.
                    break 
                }
            }
            continuation.finish()
        }
        
        return newStream
    }
}

// MARK: - Implementation Example
@MainActor
func runSentinelDemo() async {
    let logger = AuditLogger()
    let rules: [ComplianceRule] = [
        BlacklistRule(keywords: ["Proprietary Algorithm", "Secret Sauce"]),
        PatternRule()
    ]
    let sentinel = SentinelMiddleware(rules: rules, logger: logger, userID: "Trader_77")
    
    // Simulating a streaming LLM response
    let (rawStream, rawContinuation) = AsyncStream<String>.makeStream()
    
    Task {
        rawContinuation.yield("This is a ")
        rawContinuation.yield("very ")
        rawContinuation.yield("secure ")
        rawContinuation.yield("Proprietary Algorithm ") // VIOLATION HERE
        rawContinuation.yield("is being leaked.")
        rawContinuation.finish()
    }
    
    let monitoredStream = await sentinel.monitorStream(rawStream)
    
    print("--- Starting Monitored Stream ---")
    for await token in monitoredStream {
        print("Token: \(token)")
    }
    print("--- Stream Terminated ---")
}
