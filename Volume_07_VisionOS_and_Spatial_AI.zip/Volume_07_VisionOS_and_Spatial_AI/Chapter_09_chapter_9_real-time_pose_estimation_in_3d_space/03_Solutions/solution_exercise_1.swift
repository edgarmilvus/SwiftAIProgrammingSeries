
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import RealityKit
import ARKit

@MainActor
class SkeletonManager: ObservableObject {
    // Dictionary to keep track of joint entities for real-time updates
    private var jointEntities: [String: ModelEntity] = [:]
    private var previousPositions: [String: simd_float3] = [:]
    
    // Smoothing factor for Linear Interpolation (0.0 = no movement, 1.0 = instant)
    private let lerpFactor: Float = 0.3 

    func updateSkeleton(with anchor: ARBodyAnchor, in scene: Scene) {
        let skeletonRoot = Entity()
        if scene.findEntity(named: "skeleton_root") == nil {
            scene.addAnchor(AnchorEntity(world: .zero)) // Simplified for example
        }

        // Define the joints we want to visualize
        let jointsToTrack: [String] = ["leftWrist", "rightWrist", "nose", "leftAnkle", "rightAnkle"]

        for jointName in jointsToTrack {
            // 1. Extract the joint transform from the ARBodyAnchor
            guard let jointTransform = anchor.skeleton.modelTransform(for: jointName) else { continue }
            
            // 2. Convert local joint transform to world space
            let worldTransform = anchor.transform * jointTransform
            let currentPosition = simd_make_float3(worldTransform.columns.3)

            // 3. Manage Entity Creation and Updating
            if let entity = jointEntities[jointName] {
                // Apply Linear Interpolation (Lerp) to prevent jitter
                let prevPos = previousPositions[jointName] ?? currentPosition
                let smoothedPos = simd_lerp(prevPos, currentPosition, lerpFactor)
                
                entity.position = smoothedPos
                previousPositions[jointName] = smoothedPos
            } else {
                // Create new sphere for new joint
                let sphere = ModelEntity(mesh: .generateSphere(radius: 0.02), materials: [SimpleMaterial(color: .cyan, isMetallic: true)])
                sphere.position = currentPosition
                jointEntities[jointName] = sphere
                // In a real app, you'd attach this to a specific AnchorEntity
            }
        }
    }
}

#available(iOS 18.0, visionOS 2.0, *)
struct SkeletonView: View {
    @StateObject private var manager = SkeletonManager()

    var body: some View {
        RealityView { content in
            // Initialization logic
        } update: { content in
            // Update loop logic
        }
    }
}
