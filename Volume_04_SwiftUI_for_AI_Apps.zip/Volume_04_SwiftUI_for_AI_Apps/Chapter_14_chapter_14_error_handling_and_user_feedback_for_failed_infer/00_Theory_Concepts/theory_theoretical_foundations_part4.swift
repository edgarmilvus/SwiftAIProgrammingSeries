
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// @available(iOS 18.0, *)
actor InferenceActor<Client: InferenceClient> where Client.Input: Sendable, Client.Output: Sendable {
    private let client: Client
    private var isInferring: Bool = false // Internal state
    private var lastError: InferenceError? // Internal state for last error

    init(client: Client) {
        self.client = client
    }

    func performInference(input: Client.Input) async throws -> Client.Output {
        guard !isInferring else {
            // Potentially throw an error or wait, depending on desired behavior
            throw InferenceError.inferenceFailed(underlyingError: NSError(domain: "InferenceActor", code: 1, userInfo: [NSLocalizedDescriptionKey: "Inference already in progress."]))
        }

        isInferring = true // Mark as inferring
        lastError = nil // Clear previous error

        do {
            let output = try await client.performInference(input: input)
            isInferring = false
            return output
        } catch let error as InferenceError {
            lastError = error // Store the specific error
            isInferring = false
            throw error // Re-throw to caller
        } catch {
            let unknownError = InferenceError.unknown(error)
            lastError = unknownError // Store general error
            isInferring = false
            throw unknownError // Re-throw as our custom error
        }
    }

    // Public method to check status, ensuring thread-safe access
    func status() -> (isInferring: Bool, lastError: InferenceError?) {
        return (isInferring, lastError)
    }
}
