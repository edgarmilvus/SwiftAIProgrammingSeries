
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import ARKit
import RealityKit
import Vision
import Combine

// MARK: - Models

/// Represents a detected object in 3D space.
/// Conforming to Sendable ensures this can safely cross actor boundaries in Swift 6.
struct DetectedSpatialObject: Sendable, Identifiable {
    let id: UUID
    let label: String
    let position: simd_float3
}

// MARK: - AI Engine (The "Thinker")

/// An actor responsible for performing heavy Vision computations.
/// Using an `actor` ensures that the intensive ML inference does not block the Main Thread,
/// maintaining a high frame rate for the AR experience.
actor SpatialDetectionEngine {
    
    /// The Vision request object, reused to save memory and compute.
    private var detectionRequest: VNCoreMLRequest?
    
    /// Initializes the engine with a specific ML Model.
    /// - Parameter model: The compiled CoreML model to use for detection.
    init(model: VNCoreMLModel) {
        self.detectionRequest = VNCoreMLRequest(model: model)
        self.detectionRequest?.imageCropAndScaleOption = .scaleFill
    }
    
    /// Performs detection on a provided pixel buffer.
    /// - Parameters:
    ///   - pixelBuffer: The raw image data from the ARFrame.
    /// - Returns: An array of detected labels and their normalized coordinates.
    func detect(in pixelBuffer: CVPixelBuffer) async throws -> [(label: String, rect: CGRect)] {
        guard let request = detectionRequest else { return [] }
        
        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            
            do {
                try handler.perform([request])
                
                // Extract results from the request
                let observations = request.results as? [VNRecognizedObjectObservation] ?? []
                let detections = observations.map { observation -> (String, CGRect) in
                    // Get the top label for the detected object
                    let label = observation.labels.first?.identifier ?? "Unknown"
                    // Vision uses normalized coordinates (0.0 to 1.0)
                    return (label, observation.boundingBox)
                }
                
                continuation.resume(returning: detections)
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

// MARK: - Coordinator (The "Bridge")

/// The Coordinator manages the lifecycle of the ARSession and bridges the 
/// AI Engine's results to the RealityKit scene.
@MainActor
class SpatialLabelingCoordinator: NSObject, ObservableObject {
    
    /// The RealityKit view to be displayed.
    @Published var arView: ARView = ARView(frame: .zero)
    
    /// The AI engine instance.
    private var detectionEngine: SpatialDetectionEngine?
    
    /// A reference to the current ARSession.
    private var session: ARSession?
    
    /// Keeps track of active labels to prevent duplicates.
    private var activeLabels: [UUID: Entity] = [:]
    
    /// Starts the session and initializes the AI engine.
    /// - Parameter model: The CoreML model to use.
    func setup(with model: VNCoreMLModel) {
        self.detectionEngine = SpatialDetectionEngine(model: model)
        
        // Configure ARKit for world tracking
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal, .vertical]
        
        arView.session.run(configuration)
        self.session = arView.session
        
        // Subscribe to ARFrame updates
        // In a production app, use a Combine publisher or the ARSessionDelegate
        // to process frames at a controlled frequency (e.g., 10Hz instead of 60Hz)
    }
    
    /// This function is called every time a new ARFrame is available.
    /// It handles the complex math of converting 2D Vision results to 3D RealityKit entities.
    func processFrame(_ frame: ARFrame) async {
        guard let engine = detectionEngine else { return }
        
        do {
            // 1. Run AI Inference
            let detections = try await engine.detect(in: frame.capturedImage)
            
            // 2. Process each detection
            for detection in detections {
                try await anchorLabel(for: detection, in: frame)
            }
        } catch {
            print("Detection error: \(error)")
        }
    }
    
    /// Performs the mathematical projection and anchors a 3D entity.
    private func anchorLabel(for detection: (label: String, rect: CGRect), in frame: ARFrame) async throws {
        // Calculate the center of the 2D bounding box
        let centerRect = CGPoint(
            x: detection.rect.midX,
            y: detection.rect.midY
        )
        
        // Convert normalized Vision coordinates (0-1, origin bottom-left) 
        // to Viewport coordinates (0-width, 0-height, origin top-left)
        // Note: Vision's coordinate system is inverted relative to UIKit/ARKit.
        let viewportSize = CGSize(width: frame.camera.imageResolution.width,
                                  height: frame.camera.imageResolution.height)
        
        let viewX = centerRect.x * viewportSize.width
        let viewY = (1.0 - centerRect.y) * viewportSize.height
        
        // 3. Perform Raycasting to find the 3D position
        // We cast a ray from the camera through the center of the 2D bounding box.
        let raycastQuery = arView.raycast(from: CGPoint(x: centerRect.x, y: 1.0 - centerRect.y),
                                          allowing: .estimatedPlane,
                                          alignment: .any)
        
        guard let result = arView.session.raycast(raycastQuery).first else {
            return // No physical surface detected at this point
        }
        
        // 4. Create or Update the 3D Label
        let worldPosition = result.worldTransform.columns.3
        let position3D = simd_float3(worldPosition.x, worldPosition.y, worldPosition.z)
        
        await updateOrCreateEntity(label: detection.label, at: position3D)
    }
    
    /// Manages the RealityKit Entity lifecycle.
    private func updateOrCreateEntity(label: String, at position: simd_float3) async {
        // For this basic example, we create a new label every time.
        // In a production app, you would use a distance-based heuristic 
        // to see if the label already exists and just move it.
        
        let anchor = AnchorEntity(world: position)
        
        // Create a simple 3D Text Mesh
        let mesh = MeshResource.generateText(
            label,
            extrusionDepth: 0.01,
            font: .systemFont(ofSize: 0.05),
            containerFrame: .zero,
            alignment: .center,
            lineBreakMode: .byWordWrapping
        )
        
        let material = SimpleMaterial(color: .white, isMetallic: true)
        let textEntity = ModelEntity(mesh: mesh, materials: [material])
        
        // Offset the text so it floats slightly above the object
        textEntity.position.y = 0.1 
        
        anchor.addChild(textEntity)
        arView.scene.addAnchor(anchor)
        
        // Note: In a real app, you must implement a way to remove these 
        // so you don't leak thousands of entities in the scene.
    }
}

// MARK: - SwiftUI Interface

struct SpatialAIView: View {
    @StateObject private var coordinator = SpatialLabelingCoordinator()
    
    // In a real app, you would pass a loaded CoreML model here
    let model: VNCoreMLModel 

    var body: some View {
        ZStack {
            // The AR View
            ARViewContainer(coordinator: coordinator)
                .edgesIgnoringSafeArea(.all)
            
            // UI Overlay
            VStack {
                Text("Spatial AI Scanner")
                    .font(.headline)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
                Spacer()
            }
            .padding()
        }
        .onAppear {
            coordinator.setup(with: model)
        }
    }
}

struct ARViewContainer: UIViewRepresentable {
    let coordinator: SpatialLabelingCoordinator
    
    func makeUIView(context: Context) -> ARView {
        return coordinator.arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
}
