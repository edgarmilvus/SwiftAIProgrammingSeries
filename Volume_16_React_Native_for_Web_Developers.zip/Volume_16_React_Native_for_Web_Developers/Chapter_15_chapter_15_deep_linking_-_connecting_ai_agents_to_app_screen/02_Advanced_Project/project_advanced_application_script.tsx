/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview AI-Driven Deep Link Orchestrator for SaaS Dashboard.
 * 
 * This script demonstrates a Hierarchical Agentic Workflow where an AI Supervisor
 * interprets user intent and delegates the creation of a deep link to a specialized
 * Worker Agent. The resulting link is used to hydrate a Next.js dashboard screen.
 * 
 * Context: Book 16, Chapter 15 - Deep Linking.
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/router';

// ==========================================
// 1. Agent Definitions (The Agentic Layer)
// ==========================================

/**
 * Represents the structured output of the AI Supervisor after parsing intent.
 * This acts as the "Contract" between the conversational AI and the routing system.
 */
interface AgentIntent {
  targetView: 'sales' | 'users' | 'settings';
  timeRange: 'last_7_days' | 'last_month' | 'last_year';
  filters?: Record<string, string>;
}

/**
 * WORKER AGENT: Link Generator
 * Specialized in converting structured intent into a valid URL string.
 * In a real-world scenario, this agent would ensure URL encoding and validation.
 */
class LinkGeneratorAgent {
  /**
   * Generates a deep link path based on the Supervisor's intent.
   * @param intent - The structured data from the Supervisor Agent.
   * @returns A formatted URL string (e.g., /dashboard?view=sales&period=last_month).
   */
  static generateLink(intent: AgentIntent): string {
    const params = new URLSearchParams({
      view: intent.targetView,
      period: intent.timeRange,
      // Flatten filters into query params if they exist
      ...intent.filters,
    });
    return `/dashboard?${params.toString()}`;
  }
}

/**
 * SUPERVISOR AGENT: Intent Parser
 * The "Brain" that interprets raw user input and delegates to workers.
 */
class SupervisorAgent {
  /**
   * Analyzes natural language input and extracts structured parameters.
   * This simulates an LLM (Large Language Model) function calling capability.
   * @param userInput - The raw string from the chat interface.
   * @returns A structured AgentIntent object.
   */
  static async analyzeIntent(userInput: string): Promise<AgentIntent> {
    // Simulating LLM processing delay
    await new Promise((resolve) => setTimeout(resolve, 300));

    const lowerInput = userInput.toLowerCase();

    // Logic to map natural language to structured data
    if (lowerInput.includes('sales') || lowerInput.includes('revenue')) {
      return {
        targetView: 'sales',
        timeRange: lowerInput.includes('last month') ? 'last_month' : 'last_7_days',
      };
    } else if (lowerInput.includes('user') || lowerInput.includes('accounts')) {
      return {
        targetView: 'users',
        timeRange: 'last_year', // Defaulting for example
      };
    }

    // Fallback intent
    return {
      targetView: 'settings',
      timeRange: 'last_7_days',
    };
  }
}

// ==========================================
// 2. UI Layer (The Application Context)
// ==========================================

/**
 * MOCK DATA: Simulating a backend response based on deep link parameters.
 */
const fetchDashboardData = async (view: string, period: string) => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500));
  return {
    title: `${view.charAt(0).toUpperCase() + view.slice(1)} Overview`,
    period: period.replace('_', ' '),
    data: Array.from({ length: 5 }, (_, i) => ({
      id: i + 1,
      value: Math.floor(Math.random() * 1000),
    })),
  };
};

/**
 * Main Component: AI Deep Link Orchestrator
 * Handles both the generation of links (via AI) and the consumption (via URL params).
 */
const AIDeepLinkDashboard: React.FC = () => {
  const router = useRouter();
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [screenState, setScreenState] = useState<any>(null);

  // Extract query params from Next.js router
  const { view, period } = router.query;

  /**
   * EFFECT: Handle Deep Link Consumption
   * 
   * This effect runs whenever the URL parameters change. It simulates the
   * "Screen Hydration" phase where the app reads the deep link and fetches
   * specific data. This is the "Universal App" behavior in a web context.
   */
  useEffect(() => {
    if (view && period) {
      setIsLoading(true);
      // Fetch data based on the deep link parameters
      fetchDashboardData(String(view), String(period))
        .then((data) => {
          setScreenState(data);
          setIsLoading(false);
        })
        .catch(() => setIsLoading(false));
    }
  }, [view, period]);

  /**
   * Handles the user typing a request and triggers the Agentic Workflow.
   */
  const handleAgentRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    setIsLoading(true);

    try {
      // 1. Supervisor Agent analyzes intent
      const intent = await SupervisorAgent.analyzeIntent(userInput);

      // 2. Worker Agent generates the deep link
      const deepLinkPath = LinkGeneratorAgent.generateLink(intent);

      // 3. Update URL (Router Push)
      // This triggers the useEffect above, completing the loop
      router.push(deepLinkPath, undefined, { shallow: true });
    } catch (error) {
      console.error("Agent Workflow Failed:", error);
      setIsLoading(false);
    }
  };

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <h1>AI-Driven Deep Linking Dashboard</h1>
      
      {/* Input Section: Simulating the Chat Interface */}
      <div style={{ marginBottom: '2rem', padding: '1rem', border: '1px solid #ccc', borderRadius: '8px' }}>
        <p><strong>AI Supervisor:</strong> Ask me to show data (e.g., "Show sales data for last month").</p>
        <form onSubmit={handleAgentRequest} style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            placeholder="Type your request..."
            style={{ flex: 1, padding: '8px' }}
            disabled={isLoading}
          />
          <button type="submit" disabled={isLoading} style={{ padding: '8px 16px' }}>
            {isLoading ? 'Processing...' : 'Ask AI'}
          </button>
        </form>
      </div>

      {/* Output Section: The Screen State Hydration */}
      <div style={{ border: '1px solid #eee', padding: '1.5rem', borderRadius: '8px', background: '#f9f9f9' }}>
        <h2>Screen State (Deep Link Result)</h2>
        
        {!view && !screenState ? (
          <p style={{ color: '#666' }}>Waiting for AI navigation command...</p>
        ) : isLoading ? (
          <p>Loading dashboard data...</p>
        ) : screenState ? (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #333', paddingBottom: '10px', marginBottom: '10px' }}>
              <h3>{screenState.title}</h3>
              <span style={{ background: '#e0e0e0', padding: '4px 8px', borderRadius: '4px' }}>
                Period: {screenState.period}
              </span>
            </div>
            <ul>
              {screenState.data.map((item: any) => (
                <li key={item.id} style={{ padding: '5px 0' }}>
                  Item {item.id}: <strong>{item.value}</strong>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>

      {/* Debug Info: Showing the current Deep Link */}
      {router.asPath !== '/' && (
        <div style={{ marginTop: '1rem', fontSize: '0.85rem', color: '#555' }}>
          <strong>Current Deep Link:</strong> <code>{router.asPath}</code>
        </div>
      )}
    </div>
  );
};

export default AIDeepLinkDashboard;
