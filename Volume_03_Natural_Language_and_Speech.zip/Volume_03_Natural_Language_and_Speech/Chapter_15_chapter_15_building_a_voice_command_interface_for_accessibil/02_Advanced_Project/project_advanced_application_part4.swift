
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import SwiftUI

/// The main view for the Smart Home Voice Control app.
/// This view demonstrates how to integrate and use the `VoiceCommandProcessor`.
@available(iOS 18.0, *)
struct ContentView: View {
    /// The voice command processor, observed for UI updates.
    @StateObject private var voiceCommandProcessor = VoiceCommandProcessor(smartHomeManager: MockSmartHomeManager())

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer()

                // Display current listening status
                Text(voiceCommandProcessor.isListening ? "Listening..." : "Idle")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(voiceCommandProcessor.isListening ? .blue : .gray)
                    .accessibilityLabel(voiceCommandProcessor.isListening ? "Voice command listening" : "Voice command idle")

                // Display recognized text
                Text(voiceCommandProcessor.recognizedText)
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(10)
                    .accessibilityLabel("Recognized text: \(voiceCommandProcessor.recognizedText)")

                // Display parsed command feedback
                Text(voiceCommandProcessor.parsedCommand)
                    .font(.title3)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(10)
                    .accessibilityLabel("Parsed command: \(voiceCommandProcessor.parsedCommand)")

                Spacer()

                // Error message display
                if let errorMessage = voiceCommandProcessor.errorMessage {
                    Text(errorMessage)
                        .font(.callout)
                        .foregroundColor(.red)
                        .padding(.horizontal)
                        .accessibilityLabel("Error: \(errorMessage)")
                }

                // Start/Stop recording button
                Button {
                    if voiceCommandProcessor.isListening {
                        voiceCommandProcessor.stopRecording()
                    } else {
                        Task {
                            do {
                                try await voiceCommandProcessor.startRecording()
                            } catch {
                                voiceCommandProcessor.errorMessage = error.localizedDescription
                            }
                        }
                    }
                } label: {
                    Label(voiceCommandProcessor.isListening ? "Stop Listening" : "Start Listening",
                          systemImage: voiceCommandProcessor.isListening ? "mic.fill" : "mic")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(voiceCommandProcessor.isListening ? Color.red : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                }
                .padding(.horizontal)
                .accessibilityHint("Tap to start or stop voice command input.")
            }
            .navigationTitle("Smart Home Voice Control")
            .navigationBarTitleDisplayMode(.inline)
            .padding()
        }
    }
}
