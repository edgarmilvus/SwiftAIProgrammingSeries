
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@available(macOS 13.0, *)
actor LLMInferenceActor {
    private var model: LLMModel?
    private var isInferring: Bool = false

    // Initializer might load a default model or prepare the environment
    init() {
        // Potentially load a small, default model synchronously or kick off async load
    }

    func loadModel(_ newModel: LLMModel) async throws {
        // Ensure only one model is loaded at a time, or handle model switching safely
        if isInferring {
            throw InferenceError.busy
        }
        self.model = newModel
        print("Actor: Model \(newModel.name) loaded.")
    }

    func generateResponse(prompt: String, parameters: InferenceParameters) async throws -> String {
        guard let currentModel = model else {
            throw InferenceError.modelNotLoaded
        }
        guard !isInferring else {
            throw InferenceError.busy
        }

        isInferring = true
        defer { isInferring = false } // Ensure isInferring is reset

        print("Actor: Generating response for prompt: '\(prompt)' with model \(currentModel.name)")
        // Simulate LLM inference using llama.cpp bindings
        try await Task.sleep(for: .seconds(5)) // Long-running inference
        let response = "Generated response for '\(prompt)' using \(currentModel.name)."
        print("Actor: Inference complete.")
        return response
    }
}

struct LLMModel { let name: String }
struct InferenceParameters: Sendable { /* ... */ } // Must be Sendable
enum InferenceError: Error { case modelNotLoaded, busy }

// Example usage
@available(macOS 13.0, *)
@Observable
class InferenceViewModel {
    let inferenceActor = LLMInferenceActor()
    var currentResponse: String = "No response yet."
    var isGenerating: Bool = false

    func performInference(prompt: String) async {
        isGenerating = true
        do {
            // Ensure the model is loaded before inference
            // (In a real app, this might be handled by the actor's init or a separate loading step)
            if await inferenceActor.model == nil {
                // Simulate loading a model if not already loaded
                let dummyModel = LLMModel(name: "Default LLM")
                try await inferenceActor.loadModel(dummyModel)
            }

            let response = try await inferenceActor.generateResponse(
                prompt: prompt,
                parameters: InferenceParameters()
            )
            // Update UI on the main actor
            await MainActor.run {
                self.currentResponse = response
            }
        } catch {
            await MainActor.run {
                self.currentResponse = "Error: \(error.localizedDescription)"
            }
        }
        isGenerating = false
    }
}
