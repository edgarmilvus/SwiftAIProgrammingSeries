
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import WritingTools // Assuming this framework is available on iOS 18+

@Observable
@available(iOS 18.0, *)
class WritingCanvasViewModel {
    var currentText: String = "The quick brown fox jumps over the lazy dog."
    var suggestions: [WritingToolSuggestion] = []
    var isLoadingSuggestions: Bool = false
    var errorMessage: String?

    private let assistantService = WritingAssistantService()

    @MainActor // UI updates must happen on the main actor
    func generateRephraseSuggestions() async {
        isLoadingSuggestions = true
        errorMessage = nil
        suggestions = [] // Clear previous suggestions

        do {
            let newSuggestions = try await assistantService.getRephraseSuggestions(for: currentText)
            self.suggestions = newSuggestions
        } catch {
            self.errorMessage = "Failed to get suggestions: \(error.localizedDescription)"
            print("Error: \(error)")
        }
        isLoadingSuggestions = false
    }

    @MainActor
    func applySuggestion(_ suggestion: WritingToolSuggestion) {
        // Example: If a suggestion replaces the whole text
        if let newText = suggestion.text {
            currentText = newText
            suggestions = [] // Clear suggestions after applying one
        }
        // More complex logic would involve text ranges if suggestions are partial
    }
}

@available(iOS 18.0, *)
struct WritingCanvasView: View {
    @State private var viewModel = WritingCanvasViewModel()

    var body: some View {
        VStack {
            TextEditor(text: $viewModel.currentText)
                .frame(height: 200)
                .border(Color.gray, width: 1)
                .padding()

            if viewModel.isLoadingSuggestions {
                ProgressView("Generating suggestions...")
            } else if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
            } else if !viewModel.suggestions.isEmpty {
                ScrollView(.horizontal) {
                    HStack {
                        ForEach(viewModel.suggestions, id: \.id) { suggestion in
                            Button(action: {
                                viewModel.applySuggestion(suggestion)
                            }) {
                                Text(suggestion.text ?? "No text") // Assuming suggestion.text exists
                                    .padding(.vertical, 8)
                                    .padding(.horizontal, 12)
                                    .background(Capsule().fill(Color.blue.opacity(0.2)))
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }

            Button("Rephrase Text") {
                Task {
                    await viewModel.generateRephraseSuggestions()
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()
        }
        .navigationTitle("Writing Canvas")
    }
}
