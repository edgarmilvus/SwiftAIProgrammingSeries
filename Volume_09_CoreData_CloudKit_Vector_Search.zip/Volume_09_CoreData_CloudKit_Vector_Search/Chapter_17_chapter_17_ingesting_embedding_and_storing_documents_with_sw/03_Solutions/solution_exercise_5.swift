
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import SwiftData
import PDFKit

@Model
final class LegalDocument {
    var title: String
    var sourceURL: URL
    
    @Relationship(deleteRule: .cascade) 
    var chunks: [DocumentChunk] = []
    
    init(title: String, sourceURL: URL) {
        self.title = title
        self.sourceURL = sourceURL
    }
}

@Model
final class DocumentChunk {
    var text: String
    var embedding: [Float]?
    var pageNumber: Int
    
    init(text: String, embedding: [Float]?, pageNumber: Int) {
        self.text = text
        self.embedding = embedding
        self.pageNumber = pageNumber
    }
}

class DocumentProcessor {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService
    
    init(modelContext: ModelContext, embeddingService: EmbeddingService) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
    }
    
    func processPDF(url: URL) async throws {
        guard let pdfDocument = PDFDocument(url: url) else { return }
        
        let legalDoc = LegalDocument(title: url.lastPathComponent, sourceURL: url)
        modelContext.insert(legalDoc)
        
        // Iterate through pages
        for pageIndex in 0..<pdfDocument.pageCount {
            guard let page = pdfDocument.page(at: pageIndex) else { continue }
            let pageText = page.string ?? ""
            
            // Sliding Window Chunking
            // Window size: 500, Overlap: 100
            let chunkSize = 500
            let overlap = 100
            var start = 0
            
            while start < pageText.count {
                let end = min(start + chunkSize, pageText.count)
                let chunkText = String(pageText[pageText.index(pageText.startIndex, offsetBy: start)..<pageText.index(pageText.startIndex, offsetBy: end)])
                
                // Generate embedding for this specific chunk
                let vector = embeddingService.generateEmbedding(for: chunkText)
                
                let chunk = DocumentChunk(
                    text: chunkText,
                    embedding: vector,
                    pageNumber: pageIndex + 1
                )
                
                legalDoc.chunks.append(chunk)
                
                // Move start pointer forward, accounting for overlap
                start += (chunkSize - overlap)
                
                // Safety break to prevent infinite loops if overlap >= chunkSize
                if chunkSize <= overlap { break }
            }
        }
        
        try modelContext.save()
    }
}

/*
 TIME COMPLEXITY ANALYSIS:
 The complexity is O(n), where 'n' is the total number of characters in the PDF.
 We iterate through the text once via the sliding window. For each chunk, 
 we perform an embedding generation (which is also O(m) where m is chunk length).
 Since chunk length is constant (500), the overall scaling is linear relative 
 to the document size.
*/
