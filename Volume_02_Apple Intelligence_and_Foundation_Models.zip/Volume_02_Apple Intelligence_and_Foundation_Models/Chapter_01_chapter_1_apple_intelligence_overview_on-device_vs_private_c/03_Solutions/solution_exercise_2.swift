
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CoreML // Essential for integrating .mlmodel files

@available(iOS 18.0, macOS 15.0, *)
class JournalSentimentAnalyzer {
    // Define an enum for the possible sentiment outcomes.
    // Swift's raw value string makes it easy to convert to/from model outputs.
    enum Sentiment: String, CaseIterable, CustomStringConvertible {
        case positive = "Positive"
        case negative = "Negative"
        case neutral = "Neutral"
        case unknown = "Unknown" // For cases where analysis fails or is inconclusive

        var description: String {
            return self.rawValue
        }
    }

    /// Analyzes the sentiment of a journal entry using an on-device mechanism.
    /// This method simulates the use of a Core ML model for sentiment analysis.
    /// All processing occurs locally on the user's device, ensuring maximum privacy.
    ///
    /// - Parameter entry: The journal entry text to analyze.
    /// - Returns: The predicted sentiment as a `Sentiment` enum value.
    func analyzeSentiment(entry: String) -> Sentiment {
        // --- ON-DEVICE PROCESSING BEGINS ---
        // This block represents the secure execution of a local Core ML model.
        // No part of the journal entry text is ever sent off the device.

        // In a real scenario, you would load and perform inference with your Core ML model here.
        // The generated Swift class from your .mlmodel file (e.g., `SentimentClassifier`)
        // would typically have an initializer and a `prediction` method.
        /*
        do {
            // Assuming 'SentimentClassifier' is a Core ML model compiled and included in the app bundle.
            let model = try SentimentClassifier(configuration: MLModelConfiguration())
            let prediction = try model.prediction(text: entry) // 'text' is the input feature name
            
            // Map the model's output label to our Sentiment enum.
            // Core ML models often output a string label or probabilities.
            return Sentiment(rawValue: prediction.label) ?? .unknown
        } catch {
            print("Error performing sentiment analysis with Core ML: \(error.localizedDescription)")
            return .unknown // Return unknown if the model inference fails
        }
        */

        // --- MOCK SENTIMENT DETECTION ---
        // For this exercise, we simulate a basic keyword-based sentiment detection.
        // This keeps the logic simple while demonstrating the API structure.
        let lowercasedEntry = entry.lowercased()

        if lowercasedEntry.contains("happy") || lowercasedEntry.contains("joy") ||
           lowercasedEntry.contains("great") || lowercasedEntry.contains("wonderful") ||
           lowercasedEntry.contains("excited") || lowercasedEntry.contains("love") {
            return .positive
        } else if lowercasedEntry.contains("sad") || lowercasedEntry.contains("unhappy") ||
                  lowercasedEntry.contains("terrible") || lowercasedEntry.contains("awful") ||
                  lowercasedEntry.contains("frustrated") || lowercasedEntry.contains("angry") {
            return .negative
        } else if lowercasedEntry.contains("neutral") || lowercasedEntry.contains("okay") ||
                  lowercasedEntry.contains("fine") || lowercasedEntry.contains("normal") {
            return .neutral
        } else {
            // Default to neutral if no strong keywords are found, or unknown if preferred.
            return .neutral
        }
        // --- ON-DEVICE PROCESSING ENDS ---
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func demonstrateSentimentAnalysis() {
    let analyzer = JournalSentimentAnalyzer()

    print("--- Exercise 2: Local Journal Entry Sentiment Analysis ---")

    let entry1 = "Today was a fantastic day! I felt so happy and productive. Everything went great."
    print("Entry 1: '\(entry1)' -> Sentiment: \(analyzer.analyzeSentiment(entry: entry1).description)")

    let entry2 = "I'm feeling a bit down today, things didn't go as planned. It was a terrible experience."
    print("Entry 2: '\(entry2)' -> Sentiment: \(analyzer.analyzeSentiment(entry: entry2).description)")

    let entry3 = "The weather was cloudy with a chance of rain. I just stayed home and watched TV."
    print("Entry 3: '\(entry3)' -> Sentiment: \(analyzer.analyzeSentiment(entry: entry3).description)")

    let entry4 = "I am okay with the outcome, it was fine."
    print("Entry 4: '\(entry4)' -> Sentiment: \(analyzer.analyzeSentiment(entry: entry4).description)")
    print("-----------------------------------------------------------\n")
}

// To run this example in a playground or application:
// demonstrateSentimentAnalysis()
