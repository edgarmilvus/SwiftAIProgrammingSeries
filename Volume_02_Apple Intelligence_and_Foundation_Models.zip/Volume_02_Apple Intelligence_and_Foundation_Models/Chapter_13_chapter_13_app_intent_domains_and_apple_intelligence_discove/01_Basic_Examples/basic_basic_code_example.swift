
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AppIntents // Essential for App Intents
import Foundation // For basic data types like UUID and Date

// MARK: - 1. Data Model for our Note-taking App

/// Represents a single note entry.
/// Conforms to `Identifiable` for use in SwiftUI lists.
struct Note: Identifiable, Codable {
    let id = UUID() // Unique identifier for each note
    var title: String
    var content: String
    var timestamp: Date // When the note was last updated or created
}

/// A simple store to manage notes in our app.
/// This acts as a simplified backend/data layer.
/// `@Observable` makes it reactive to SwiftUI views.
@Observable
class NoteStore {
    var notes: [Note] = [] {
        didSet {
            // In a real app, this would persist to UserDefaults, Core Data, or CloudKit.
            // For this example, we'll just print to show state changes for debugging.
            print("NoteStore updated. Current notes count: \(notes.count)")
        }
    }

    /// Adds a new note to the store.
    /// - Parameters:
    ///   - title: The title of the note.
    ///   - content: The initial content of the note.
    func addNote(title: String, content: String) {
        let newNote = Note(title: title, content: content, timestamp: Date())
        notes.append(newNote)
        print("Added new note: '\(title)' with content: '\(content)'")
    }

    /// Finds a note by title (case-insensitive).
    /// - Parameter title: The title of the note to find.
    /// - Returns: The first note matching the title, or nil if not found.
    func findNote(byTitle title: String) -> Note? {
        return notes.first { $0.title.lowercased() == title.lowercased() }
    }

    /// Adds content to an existing note or creates a new one if not found.
    /// This is the core logic that our App Intent will trigger.
    /// - Parameters:
    ///   - title: The title of the note to update or create.
    ///   - content: The content to append to the note.
    func addContentToNote(title: String, content: String) {
        if let index = notes.firstIndex(where: { $0.title.lowercased() == title.lowercased() }) {
            // If note exists, append content and update timestamp
            notes[index].content += "\n" + content
            notes[index].timestamp = Date()
            print("Appended content to existing note '\(title)': '\(content)'")
        } else {
            // If note doesn't exist, create a new one
            addNote(title: title, content: content)
            print("Note '\(title)' not found, created a new one with content: '\(content)'")
        }
    }
}

// MARK: - 2. Defining the App Intent for Apple Intelligence Discovery

/// This intent allows Apple Intelligence and other system services (like Shortcuts or Siri)
/// to add content to a note within our app, or create a new note if one doesn't exist
/// with the specified title.
///
/// It's marked with `@available(iOS 18.0, *)` because App Intents for Apple Intelligence
/// discovery are specific to iOS 18 and later.
@available(iOS 18.0, *)
struct AddContentToNoteIntent: AppIntent {
    // MARK: - Intent Definition Metadata

    /// The user-facing title of the intent, displayed in system interfaces (e.g., Shortcuts app).
    static var title: LocalizedStringResource = "Add Content to Note"

    /// A brief description of what this intent does, helping the user understand its purpose.
    static var description: IntentDescription = IntentDescription("Adds new content to an existing note, or creates a new note if the title doesn't match an existing one. This intent is discoverable by Apple Intelligence.")

    /// Specifies whether the app should be opened when this intent is run.
    /// `true` is often desirable for intents that modify app data and where the user might
    /// want to see the result immediately.
    static var openAppWhenRun: Bool = true

    // MARK: - Parameters for the Intent

    /// The title of the note to which content should be added.
    /// This parameter is required and will be prompted for by the system if not provided.
    /// Apple Intelligence can infer this from user context.
    @Parameter(title: "Note Title", description: "The title of the note to add content to or create.")
    var noteTitle: String

    /// The content to be added to the note.
    /// This parameter is also required. Apple Intelligence can infer this from user input.
    @Parameter(title: "Content", description: "The new content to add to the note.")
    var content: String

    // MARK: - Intent Performance Logic

    /// The `perform()` method is where the actual logic of the intent is executed.
    /// It's an `async` function because intent operations might involve network requests,
    /// data persistence, or other long-running tasks.
    ///
    /// - Returns: An `IntentResult` indicating the outcome of the intent.
    ///            We can provide a user-facing dialog message here.
    func perform() async throws -> some IntentResult {
        // Access the shared NoteStore instance.
        // In a real app, you would manage this through proper dependency injection
        // or a more robust singleton pattern accessible to background processes.
        // For this example, we use a simple shared instance.
        let noteStore = NoteStore.shared

        // IMPORTANT: Any UI updates or modifications to `@Observable` objects
        // that are observed by SwiftUI views MUST happen on the `MainActor`.
        // App Intents may be executed on a background thread by the system.
        await MainActor.run {
            noteStore.addContentToNote(title: noteTitle, content: content)
        }

        // Return a success message that can be displayed by the system (e.g., Siri or a banner).
        return .result(dialog: "Successfully added content to note '\(noteTitle)'.")
    }
}

// MARK: - 3. App Entry Point and SwiftUI Integration

/// Extend NoteStore to provide a shared instance for demonstration purposes.
/// In a real app, you would manage this lifecycle more robustly, perhaps via an
/// `EnvironmentObject` for SwiftUI views, or a dedicated setup in `AppDelegate`/`SceneDelegate`
/// that ensures the store is available even when the app is running in the background for intents.
extension NoteStore {
    static let shared = NoteStore()
}

/// The main application structure.
@main
struct AppleIntelligenceDiscoveryApp: App {
    /// The shared note store, available throughout the app's hierarchy.
    /// Using `@State` here for simplicity; for larger apps, consider `@StateObject` or `@EnvironmentObject`.
    @State private var noteStore = NoteStore.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(noteStore) // Make the NoteStore available to ContentView
        }
    }
}

/// The main content view of our app, displaying the notes.
struct ContentView: View {
    /// Access the NoteStore from the environment.
    @Environment(NoteStore.self) private var noteStore

    /// State for a simple in-app test of the intent's underlying logic.
    @State private var newNoteTitle: String = ""
    @State private var newNoteContent: String = ""

    var body: some View {
        NavigationView {
            VStack {
                Text("My Notes App")
                    .font(.largeTitle)
                    .padding()

                // List of existing notes
                List {
                    if noteStore.notes.isEmpty {
                        Text("No notes yet. Add one using the form below or via Apple Intelligence / Shortcuts!")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        ForEach(noteStore.notes) { note in
                            VStack(alignment: .leading) {
                                Text(note.title)
                                    .font(.headline)
                                Text(note.content)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                Text(note.timestamp, style: .date)
                                    .font(.caption)
                                    .foregroundColor(.tertiary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
                .listStyle(.insetGrouped) // Modern list style

                Divider()
                    .padding(.vertical)

                // Simple form to add/update notes manually within the app
                VStack(alignment: .leading, spacing: 10) {
                    Text("Add/Update Note (Manual Test)")
                        .font(.title2)
                        .padding(.bottom, 5)

                    TextField("Note Title", text: $newNoteTitle)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)

                    TextField("Content to add", text: $newNoteContent)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)

                    Button("Add/Update Note (Internal)") {
                        // Directly call the NoteStore method, simulating intent's action
                        noteStore.addContentToNote(title: newNoteTitle, content: newNoteContent)
                        newNoteTitle = "" // Clear fields after action
                        newNoteContent = ""
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.horizontal)
                }
                .padding(.bottom)
            }
            .navigationTitle("") // Hide default navigation title
            .navigationBarHidden(true) // Hide the default navigation bar
        }
    }
}
