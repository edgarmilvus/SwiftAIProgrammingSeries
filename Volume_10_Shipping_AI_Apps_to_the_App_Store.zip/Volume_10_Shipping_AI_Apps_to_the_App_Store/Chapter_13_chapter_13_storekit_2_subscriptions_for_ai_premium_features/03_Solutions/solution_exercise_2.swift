
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import StoreKit
import SwiftUI
import Observation

@available(iOS 18.0, *)
@MainActor
@Observable
class ProductProvider {
    enum LoadingState {
        case idle
        case loading
        case loaded([Product])
        case error(String)
    }
    
    var state: LoadingState = .idle
    private var cachedProducts: [Product] = []

    /// Fetches products from Apple's servers and caches them.
    func fetchAvailableProducts(identifiers: [String]) async {
        // Avoid redundant network calls if we already have products
        guard cachedProducts.isEmpty else {
            self.state = .loaded(cachedProducts)
            return
        }
        
        state = .loading
        
        do {
            // Perform the network request to fetch StoreKit products
            let products = try await Product.products(for: identifiers)
            
            if products.isEmpty {
                state = .error("No products found for the provided identifiers.")
            } else {
                self.cachedProducts = products
                self.state = .loaded(products)
            }
        } catch {
            state = .error("Failed to fetch products: \(error.localizedDescription)")
        }
    }
}

struct PaywallView: View {
    @State private var provider = ProductProvider()
    let productIDs = ["com.lexiai.pro_monthly", "com.lexiai.pro_yearly"]

    var body: some View {
        List {
            switch provider.state {
            case .idle:
                Color.clear.onAppear {
                    Task { await provider.fetchAvailableProducts(identifiers: productIDs) }
                }
            case .loading:
                ProgressView("Loading best prices for you...")
            case .loaded(let products):
                ForEach(products, id: \.id) { product in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(product.displayName)
                            .font(.headline)
                        Text(product.description)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(product.displayPrice) // Correctly localized by StoreKit
                            .font(.title3)
                            .bold()
                            .foregroundStyle(.blue)
                    }
                    .padding(.vertical, 4)
                }
            case .error(let message):
                Text(message)
                    .foregroundStyle(.red)
            }
        }
        .navigationTitle("Upgrade to Pro")
    }
}
