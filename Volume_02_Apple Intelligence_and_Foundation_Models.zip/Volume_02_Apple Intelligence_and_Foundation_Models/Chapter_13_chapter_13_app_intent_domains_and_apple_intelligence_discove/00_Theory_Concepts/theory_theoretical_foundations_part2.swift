
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    // Example: An actor managing a document cache for faster access
    actor DocumentCache {
        private var cache: [String: String] = [:]

        func getDocument(id: String) async throws -> String? {
            if let cachedDoc = cache[id] {
                return cachedDoc
            }
            // Simulate fetching from network if not in cache
            let doc = try await fetchDocumentFromNetwork(id: id)
            cache[id] = doc
            return doc
        }

        private func fetchDocumentFromNetwork(id: String) async throws -> String {
            try await Task.sleep(for: .seconds(0.8))
            return "Content for document \(id)" // Placeholder
        }
    }

    @available(iOS 18.0, *)
    struct FetchAndProcessDocumentIntent: AppIntent {
        static var title: LocalizedStringResource = "Fetch and Process Document"
        @Parameter(title: "Document ID")
        var documentID: String

        // Assume a global or injected instance of DocumentCache
        static let sharedCache = DocumentCache()

        func perform() async throws -> some IntentResult {
            let documentContent = try await Self.sharedCache.getDocument(id: documentID)
            // Further processing with LLM on documentContent
            return .result(value: documentContent ?? "No content found.")
        }
    }
    