/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { useColorScheme } from 'nativewind'; // or 'react-native' depending on setup

interface SettingsRowProps {
  label: string;
  onPress?: () => void;
}

export const SettingsRow: React.FC<SettingsRowProps> = ({ label, onPress }) => {
  // 1. Track press state for dynamic styling
  const [isPressed, setIsPressed] = useState(false);

  // 2. Note: In a real app using Nativewind, the 'dark:' modifier automatically 
  // detects the scheme if configured. We simulate the hook usage here for context,
  // though the styling relies purely on the className string.
  const { colorScheme } = useColorScheme(); 

  return (
    <Pressable
      onPressIn={() => setIsPressed(true)}
      onPressOut={() => setIsPressed(false)}
      onPress={onPress}
      // 3. Styling Logic:
      // - Static classes for light mode (bg-white, text-gray-900, border-gray-200)
      // - 'dark:' prefix handles dark mode overrides
      // - Conditional 'opacity-70' applied only when isPressed is true
      className={`
        flex-row items-center justify-between 
        px-4 py-3 
        border-b 
        transition-opacity duration-100
        bg-white dark:bg-gray-800 
        text-gray-900 dark:text-gray-100 
        border-gray-200 dark:border-gray-700
        ${isPressed ? 'opacity-70' : 'opacity-100'}
      `}
    >
      <Text className="text-base font-medium">
        {label}
      </Text>
      {/* Visual indicator for the toggle (placeholder) */}
      <View className="w-10 h-6 bg-gray-300 dark:bg-gray-600 rounded-full relative">
        <View className="w-4 h-4 bg-white rounded-full absolute top-1 left-1" />
      </View>
    </Pressable>
  );
};
