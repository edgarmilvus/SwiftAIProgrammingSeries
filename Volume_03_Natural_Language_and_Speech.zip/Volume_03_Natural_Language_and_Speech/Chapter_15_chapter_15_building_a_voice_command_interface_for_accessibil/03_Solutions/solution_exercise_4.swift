
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Speech
import AVFoundation
import NaturalLanguage // For NLTagger

// Using @available for Swift 6 context, assuming iOS 18.0 / macOS 15.0
@available(iOS 18.0, macOS 15.0, *)
class DocumentEditorState {
    var currentDocumentText: String
    var cursorPosition: Int // 0-indexed, represents insertion point
    var hasSelection: Bool
    var isBoldModeActive: Bool
    var recentActions: [String] // For simulating undo
    
    init(initialText: String = "", cursor: Int = 0, hasSelection: Bool = false, isBold: Bool = false) {
        self.currentDocumentText = initialText
        self.cursorPosition = min(max(0, cursor), initialText.count)
        self.hasSelection = hasSelection
        self.isBoldModeActive = isBold
        self.recentActions = []
    }
    
    func simulateTyping(_ text: String) {
        let prefix = String(currentDocumentText.prefix(cursorPosition))
        let suffix = String(currentDocumentText.suffix(currentDocumentText.count - cursorPosition))
        currentDocumentText = prefix + text + suffix
        cursorPosition += text.count
        hasSelection = false
        recentActions.append("Type '\(text)'")
        print("  STATE: Typed '\(text)'. Cursor at \(cursorPosition).")
    }
    
    func simulateSelection(start: Int, end: Int) {
        cursorPosition = end
        hasSelection = true
        print("  STATE: Selected text from \(start) to \(end). Cursor at \(cursorPosition).")
    }
    
    func simulateDelete(range: NSRange) {
        guard let swiftRange = Range(range, in: currentDocumentText) else { return }
        let deletedText = String(currentDocumentText[swiftRange])
        currentDocumentText.removeSubrange(swiftRange)
        cursorPosition = range.location
        hasSelection = false
        recentActions.append("Delete '\(deletedText)'")
        print("  STATE: Deleted '\(deletedText)'. Cursor at \(cursorPosition).")
    }
    
    func simulateToggleBold() {
        isBoldModeActive.toggle()
        recentActions.append("Toggle Bold")
        print("  STATE: Bold mode is now \(isBoldModeActive ? "ACTIVE" : "INACTIVE").")
    }
    
    func simulateUndo() -> String? {
        if let lastAction = recentActions.popLast() {
            print("  STATE: Undoing action: \(lastAction). (Actual text reversal not implemented for simplicity)")
            return lastAction
        }
        print("  STATE: Nothing to undo.")
        return nil
    }
    
    func printState() {
        print("  --- Current Editor State ---")
        print("  Text: \"\(currentDocumentText)\"")
        print("  Cursor: \(cursorPosition)")
        print("  Selection: \(hasSelection ? "Yes" : "No")")
        print("  Bold Mode: \(isBoldModeActive ? "Active" : "Inactive")")
        print("  Recent Actions: \(recentActions.isEmpty ? "None" : recentActions.joined(separator: ", "))")
        print("  ----------------------------")
    }
}

@available(iOS 18.0, macOS 15.0, *)
class ContextSensitiveEditor: NSObject, SFSpeechRecognizerDelegate {

    private let speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine: AVAudioEngine
    
    private var editorState: DocumentEditorState

    init(initialText: String = "This is a sample document. It has multiple paragraphs. We can test various commands here.") {
        self.audioEngine = AVAudioEngine()
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        self.editorState = DocumentEditorState(initialText: initialText)
        super.init()
        self.speechRecognizer?.delegate = self
        
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized: print("Speech recognition authorized.")
                case .denied, .restricted, .notDetermined: print("Speech recognition authorization denied, restricted, or not determined.")
                @unknown default: print("Unknown speech recognition authorization status.")
                }
            }
        }
    }

    func startListening() throws {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw EditorVoiceError.recognizerUnavailable
        }
        
        recognitionTask?.cancel()
        self.recognitionTask = nil
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw EditorVoiceError.audioSessionSetupFailed(error)
        }
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw EditorVoiceError.recognitionRequestFailed
        }
        
        recognitionRequest.shouldReportPartialResults = false
        
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            if let result = result, result.isFinal {
                self.processVoiceCommand(result.bestTranscription.formattedString)
            } else if let error = error {
                print("Speech recognition error: \(error.localizedDescription)")
            }
            
            self.audioEngine.stop()
            self.audioEngine.inputNode.removeTap(onBus: 0)
            self.recognitionRequest = nil
            self.recognitionTask = nil
        }
        
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
        print("\n--- Listening for editor command... ---")
    }
    
    func stopListening() {
        audioEngine.stop()
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        print("--- Listening stopped manually ---")
    }

    private func processVoiceCommand(_ transcribedText: String) {
        print("\n--- Command Received: \"\(transcribedText)\" ---")
        editorState.printState()
        
        let lowercasedCommand = transcribedText.lowercased()
        
        if lowercasedCommand.contains("select all") {
            print("Interpreted: Select entire document.")
            editorState.simulateSelection(start: 0, end: editorState.currentDocumentText.count)
        } else if lowercasedCommand.contains("delete line") {
            // Context-sensitive: If there's a selection, delete selection. Else, delete current line.
            if editorState.hasSelection {
                print("Interpreted: Delete selection (because text is selected).")
                // For simplicity, we'll just simulate deleting a fixed range if selected.
                // In a real editor, this would involve knowing the selection range.
                editorState.simulateDelete(range: NSRange(location: editorState.cursorPosition - 5, length: 5)) // Placeholder
            } else {
                print("Interpreted: Delete current line.")
                // Simulate finding the start/end of the current line based on cursorPosition
                let text = editorState.currentDocumentText as NSString
                let lineRange = text.lineRange(for: NSRange(location: editorState.cursorPosition, length: 0))
                editorState.simulateDelete(range: lineRange)
            }
        } else if lowercasedCommand.contains("undo") {
            print("Interpreted: Undo last action.")
            _ = editorState.simulateUndo()
        } else if lowercasedCommand.contains("bold selection") || lowercasedCommand.contains("bold") {
            // Context-sensitive: If selection, apply bold. Else, toggle bold mode.
            if editorState.hasSelection {
                print("Interpreted: Apply bold to selection.")
                // In a real editor, this would apply bold to the selected range.
                editorState.recentActions.append("Bold selection")
            } else {
                print("Interpreted: Toggle bold mode.")
                editorState.simulateToggleBold()
            }
        } else if lowercasedCommand.contains("go to next paragraph") {
            print("Interpreted: Move cursor to next paragraph.")
            // Simulate finding next paragraph
            if let rangeOfNextParagraph = (editorState.currentDocumentText as NSString).range(of: "\n\n", options: [], range: NSRange(location: editorState.cursorPosition, length: editorState.currentDocumentText.count - editorState.cursorPosition)) {
                editorState.cursorPosition = rangeOfNextParagraph.location + 2
            } else {
                editorState.cursorPosition = editorState.currentDocumentText.count // Go to end
            }
            editorState.hasSelection = false
            editorState.recentActions.append("Go to next paragraph")
        } else if lowercasedCommand.contains("type") {
            // Extract text to type
            if let match = lowercasedCommand.firstMatch(of: #/type\s+(.*)/#) {
                let textToType = String(match.output.1).trimmingCharacters(in: .whitespacesAndNewlines)
                print("Interpreted: Type \"\(textToType)\".")
                editorState.simulateTyping(textToType)
            } else {
                print("Interpreted: Unknown type command.")
            }
        } else {
            print("Interpreted: Unknown command or no action taken.")
        }
        
        editorState.printState()
        print("------------------------------------------\n")
    }

    // MARK: - SFSpeechRecognizerDelegate
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            print("Speech recognition available.")
        } else {
            print("Speech recognition not available.")
            stopListening()
        }
    }
    
    enum EditorVoiceError: Error, LocalizedError {
        case recognizerUnavailable
        case audioSessionSetupFailed(Error)
        case recognitionRequestFailed
        
        var errorDescription: String? {
            switch self {
            case .recognizerUnavailable: return "Speech recognizer is not available or authorized."
            case .audioSessionSetupFailed(let error): return "Failed to set up audio session: \(error.localizedDescription)"
            case .recognitionRequestFailed: return "Unable to create SFSpeechAudioBufferRecognitionRequest."
            }
        }
    }
}

/*
// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
let editor = ContextSensitiveEditor()

DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
    do {
        try editor.startListening()
        print("Try saying: \"Select all\"")
        print("Then: \"Bold selection\"")
        print("Then: \"Go to next paragraph\"")
        print("Then: \"Type some new text\"")
        print("Then: \"Delete line\"") // Should delete current line
        print("Then: \"Undo\"")
    } catch {
        print("Failed to start listening: \(error.localizedDescription)")
    }
}

// Stop after some time for demonstration
DispatchQueue.main.asyncAfter(deadline: .now() + 30) {
    editor.stopListening()
    print("Demo editor session ended.")
}

RunLoop.current.run(until: Date(timeIntervalSinceNow: 33))
*/
