
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - 1. Necessary Imports and Availability

import AppIntents // Core framework for defining app intents
import Foundation // Standard library for basic types like String, UUID

// Ensure this code is only available on platforms supporting App Intents for Apple Intelligence
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, visionOS 2.0, *)
enum AppIntentAvailability { /* Placeholder for clarity */ }

// MARK: - 2. Data Models (Simulated)

/// A simple struct representing a note in our QuickNotes app.
struct Note: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var content: String
    let creationDate: Date

    init(id: UUID = UUID(), title: String, content: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.content = content
        self.creationDate = creationDate
    }
}

/// A simulated storage manager for notes.
/// In a real app, this would interact with Core Data, SwiftData, or a backend.
class NoteStore {
    static let shared = NoteStore() // Singleton instance

    private var notes: [UUID: Note] = [:]

    private init() {
        // Pre-populate with some sample notes for demonstration
        addNote(Note(title: "Project Alpha Meeting", content: """
            Attendees: John, Sarah, Mike, Emily
            Agenda:
            1. Review Q3 performance: Sales up 15%, customer satisfaction stable.
            2. Discuss Q4 marketing strategy: Focus on social media campaigns and influencer partnerships.
            3. New feature brainstorming: AI-powered search, collaborative editing.
            4. Action items: Sarah to draft Q4 marketing plan by Friday. Mike to research AI search vendors.
            Next meeting: October 26th.
            """))
        addNote(Note(title: "Recipe: Spicy Ramen", content: """
            Ingredients:
            - 1 packet ramen noodles
            - 2 cups chicken broth
            - 1 tbsp soy sauce
            - 1 tsp sriracha
            - 1 soft-boiled egg
            - Green onions, sliced
            - Nori sheets
            Instructions:
            1. Boil broth, add soy sauce and sriracha.
            2. Cook noodles in broth until tender.
            3. Serve in a bowl, top with egg, green onions, and nori.
            """))
        addNote(Note(title: "Daily Journal - Sept 25", content: """
            Woke up early today, felt refreshed. Had a productive morning working on the new Swift project.
            Met with the team for lunch, discussed some architecture patterns.
            In the afternoon, focused on debugging a tricky layout issue. Made good progress.
            Finished the day with a run in the park. Feeling good about the week's progress.
            """))
    }

    /// Adds a new note to the store.
    func addNote(_ note: Note) {
        notes[note.id] = note
    }

    /// Retrieves a note by its title (case-insensitive, partial match).
    func getNote(byTitle title: String) -> Note? {
        notes.values.first { $0.title.localizedCaseInsensitiveContains(title) }
    }

    /// Retrieves all notes.
    func getAllNotes() -> [Note] {
        Array(notes.values).sorted { $0.creationDate > $1.creationDate }
    }
}

// MARK: - 3. Simulated Summarization Service

/// A mock summarization service.
/// In a real application, this would integrate with Apple Intelligence's
/// `TextSummarization` API or a custom ML model.
class MockSummarizer {
    /// Simulates generating a summary for a given text.
    /// For a basic example, we'll just truncate or provide a canned summary.
    ///
    /// - Parameter text: The full text content to summarize.
    /// - Returns: A summarized version of the text.
    func summarize(text: String) async -> String {
        // Simulate a network/computation delay
        try? await Task.sleep(for: .milliseconds(500))

        // Simple summarization logic: take the first few sentences or a fixed length
        let sentences = text.components(separatedBy: CharacterSet(charactersIn: ".!?")).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        if sentences.count > 2 {
            return sentences.prefix(2).joined(separator: ". ") + "."
        } else if !sentences.isEmpty {
            return sentences.joined(separator: ". ") + "."
        } else {
            return "Unable to summarize short or empty text."
        }
    }
}

// MARK: - 4. Defining the App Intent for Summarization

/// An App Intent to summarize a specific note by its title.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, visionOS 2.0, *)
struct SummarizeNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Note"
    static var description = IntentDescription("Summarizes a note from your QuickNotes app.")

    // MARK: - Parameters

    /// The title of the note to summarize.
    /// The `@Parameter` attribute makes this property available for Siri and Shortcuts.
    /// `requestValueDialog` provides a prompt if Siri needs to ask the user for this value.
    @Parameter(title: "Note Title", requestValueDialog: "Which note would you like to summarize?")
    var noteTitle: String

    // MARK: - Perform Method

    /// The asynchronous method that performs the actual summarization logic.
    /// This is where your app's core functionality is exposed to the system.
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        // 1. Fetch the note from our simulated store
        guard let note = NoteStore.shared.getNote(byTitle: noteTitle) else {
            // If the note isn't found, return an error message
            return .failure(error: "Note titled '\(noteTitle)' not found.")
        }

        // 2. Use the mock summarizer (or real Apple Intelligence API)
        let summarizer = MockSummarizer()
        let summary = await summarizer.summarize(text: note.content)

        // 3. Return the summary as an IntentResult
        // `IntentResult.result()` allows us to return a value that Siri can speak or display.
        return .result(value: summary, dialog: "Here's the summary of '\(note.title)': \(summary)")
    }
}

// MARK: - 5. AppIntents Configuration (Entry Point)

/// This struct acts as the entry point for all App Intents provided by your application.
/// You would typically register this in your app's main file or an App delegate.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, visionOS 2.0, *)
struct QuickNotesAppIntents: AppIntentsConfiguration {
    static var intents: [AppIntent.Type] {
        [SummarizeNoteIntent.self] // Register our summarization intent
    }

    // You can also define custom types here if needed for more complex parameters
    // static var customTypes: [AppIntentCustomType.Type] {
    //     [NoteAppEntity.self] // Example: If you wanted to pass a Note object directly
    // }

    // You can define widgets here too
    // static var widgets: [AppIntentWidget.Type] {
    //     [MyNoteSummaryWidget.self]
    // }
}
