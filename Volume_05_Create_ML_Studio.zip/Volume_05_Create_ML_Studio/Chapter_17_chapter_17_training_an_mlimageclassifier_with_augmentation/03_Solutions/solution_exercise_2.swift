
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// MARK: - Create ML Training (macOS Command Line Tool or Playground)
// This code runs on macOS for training the model.

import CreateML
import Foundation

// IMPORTANT: Replace these URLs with actual paths to your dataset.
// Example data structure:
// - plantDataDirectory/
//   - Healthy/
//     - leaf1.jpg
//     - leaf2.jpg
//   - Diseased/
//     - leafA.jpg
//     - leafB.jpg
let plantTrainingDataURL = URL(fileURLWithPath: "/path/to/your/plantTrainingDataDirectory")
let plantValidationDataURL = URL(fileURLWithPath: "/path/to/your/plantValidationDataDirectory")
let plantOutputModelURL = URL(fileURLWithPath: "/path/to/save/PlantHealthClassifier.mlmodel")

@available(macOS 14.0, *)
func trainPlantHealthClassifier() async {
    print("Starting plant health classifier training...")
    do {
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: plantTrainingDataURL)
        let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: plantValidationDataURL)

        // Targeted Augmentation for Plant Leaves
        let builder = MLImageClassifier.Builder(trainingData: trainingData)
            .validationData(validationData)
            .maxEpochs(40)
            .batchSize(32)
            .learningRate(0.0005) // Slightly lower learning rate for fine-tuning
            .augmentationOptions([
                // Geometric variations for different camera angles/distances
                .rotation(minimumAngle: -30, maximumAngle: 30), // Wider range for varied leaf orientations
                .horizontalFlip, // Leaves can appear flipped
                .verticalFlip,   // Leaves can appear upside down
                .crop(minimumScale: 0.7, maximumScale: 1.0), // Simulate zoom in/out, partial views
                .scale(minimum: 0.8, maximum: 1.2), // Adjust overall size

                // Color variations for natural lighting conditions
                .color(saturation: 0.3, brightness: 0.2, contrast: 0.2), // Significant adjustments for natural light
                .blur(radius: 1.0), // Slight blur to simulate focus issues or minor occlusions
            ])
            .baseModel(.visionFeaturePrint) // Use transfer learning

        print("Training model...")
        let model = try builder.train()
        print("Model training complete.")

        let metadata = MLModelMetadata(
            author: "Your Name",
            shortDescription: "Classifies plant leaf health (Healthy/Diseased)",
            version: "1.0",
            license: "MIT",
            additional: nil
        )
        try model.write(to: plantOutputModelURL, metadata: metadata)
        print("Plant health model saved to: \(plantOutputModelURL.path)")

    } catch {
        print("Error during plant health classifier training: \(error.localizedDescription)")
    }
}

// MARK: - iOS App Integration (SwiftUI)
// This code would be part of an iOS SwiftUI application.

import SwiftUI
import CoreML
import Vision
import PhotosUI // For image selection

enum PlantHealthClassifierError: Error, LocalizedError {
    case modelNotFound
    case imageConversionFailed
    case classificationFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelNotFound: return "Plant health model not found in app bundle."
        case .imageConversionFailed: return "Failed to convert selected image for classification."
        case .classificationFailed(let reason): return "Classification failed: \(reason)"
        }
    }
}

@MainActor
class PlantHealthViewModel: ObservableObject {
    @Published var selectedImage: UIImage?
    @Published var classificationResult: String = "Select an image to classify."
    @Published var isLoading: Bool = false
    @Published var error: Error?

    private var visionModel: VNCoreMLModel?

    init() {
        loadModel()
    }

    private func loadModel() {
        do {
            guard let modelURL = Bundle.main.url(forResource: "PlantHealthClassifier", withExtension: "mlmodelc") else {
                throw PlantHealthClassifierError.modelNotFound
            }
            let coreMLModel = try MLModel(contentsOf: modelURL)
            self.visionModel = try VNCoreMLModel(for: coreMLModel)
        } catch {
            self.error = error
            print("Failed to load Core ML model: \(error.localizedDescription)")
        }
    }

    func classifySelectedImage() async {
        guard let image = selectedImage else {
            classificationResult = "No image selected."
            return
        }
        guard let visionModel = visionModel else {
            classificationResult = "Model not loaded."
            return
        }

        isLoading = true
        error = nil
        classificationResult = "Classifying..."

        do {
            guard let cgImage = image.cgImage else {
                throw PlantHealthClassifierError.imageConversionFailed
            }

            let request = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                guard let self = self else { return }
                DispatchQueue.main.async { // Ensure UI updates are on main thread
                    self.isLoading = false
                    if let error = error {
                        self.error = PlantHealthClassifierError.classificationFailed(error.localizedDescription)
                        self.classificationResult = "Error: \(error.localizedDescription)"
                        return
                    }

                    guard let results = request.results as? [VNClassificationObservation],
                          let topResult = results.first else {
                        self.classificationResult = "Could not classify."
                        return
                    }

                    let confidence = String(format: "%.2f", topResult.confidence * 100)
                    self.classificationResult = "\(topResult.identifier) (\(confidence)%)"
                }
            }

            // Set image crop and scale option to match model's expected input
            request.imageCropAndScaleOption = .centerCrop // Or .scaleFit, .scaleFill based on your model's input

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            try handler.perform([request])

        } catch {
            self.isLoading = false
            self.error = error
            self.classificationResult = "Error: \(error.localizedDescription)"
        }
    }
}

struct PlantHealthView: View {
    @StateObject private var viewModel = PlantHealthViewModel()
    @State private var photosPickerItem: PhotosPickerItem?

    var body: some View {
        VStack {
            Text("Plant Health Monitor")
                .font(.largeTitle)
                .padding()

            if let image = viewModel.selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
                    .padding()
            } else {
                Image(systemName: "leaf.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                    .foregroundColor(.green)
                    .padding()
            }

            PhotosPicker(selection: $photosPickerItem, matching: .images) {
                Label("Select Leaf Image", systemImage: "photo.on.rectangle.angled")
            }
            .buttonStyle(.borderedProminent)
            .padding()
            .onChange(of: photosPickerItem) { oldItem, newItem in
                Task {
                    viewModel.selectedImage = nil
                    viewModel.classificationResult = "Loading image..."
                    if let newItem, let data = try? await newItem.loadTransferable(type: Data.self) {
                        if let uiImage = UIImage(data: data) {
                            viewModel.selectedImage = uiImage
                            await viewModel.classifySelectedImage()
                        } else {
                            viewModel.classificationResult = "Failed to load image data."
                        }
                    } else {
                        viewModel.classificationResult = "No image selected."
                    }
                }
            }

            if viewModel.isLoading {
                ProgressView("Classifying...")
                    .padding()
            } else {
                Text(viewModel.classificationResult)
                    .font(.title2)
                    .padding()
            }

            if let error = viewModel.error {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
                    .padding()
            }

            Spacer()
        }
    }
}

// To use in an iOS app:
// @main
// struct PlantHealthApp: App {
//     var body: some Scene {
//         WindowGroup {
//             PlantHealthView()
//         }
//     }
// }
