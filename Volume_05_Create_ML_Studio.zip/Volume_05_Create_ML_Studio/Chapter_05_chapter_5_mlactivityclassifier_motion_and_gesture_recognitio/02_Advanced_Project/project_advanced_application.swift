
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for dependencies
// This component primarily relies on built-in Apple frameworks like CoreML and CoreMotion.
// If you were to integrate external libraries, they would be declared here.
// For this example, we assume CoreML and CoreMotion are linked directly via the target's build phases.
/*
import PackageDescription

let package = Package(
    name: "SmartWorkoutAssistant",
    platforms: [
        .iOS(.v15), // Minimum iOS version for async/await and modern CoreML APIs
        .watchOS(.v8) // MLActivityClassifier is also relevant for watchOS
    ],
    products: [
        .library(
            name: "SmartWorkoutAssistant",
            targets: ["SmartWorkoutAssistant"]),
    ],
    targets: [
        .target(
            name: "SmartWorkoutAssistant",
            dependencies: []), // CoreML and CoreMotion are system frameworks
    ]
)
*/

import CoreMotion
import CoreML
import Foundation // For Date, UUID, etc.

// MARK: - App Context: Smart Workout Assistant

/// **The Smart Workout Assistant App**
///
/// Imagine a fitness application designed to guide users through specific exercise routines,
/// providing real-time feedback on their form and counting repetitions. This advanced component
/// leverages `MLActivityClassifier` (or a custom `MLModel` trained for activity recognition)
/// to interpret motion sensor data from an iPhone or Apple Watch.
///
/// The core problem solved here is the accurate, real-time detection of distinct exercise
/// movements (e.g., "Bicep Curl," "Tricep Extension," "Rest") from continuous sensor streams,
/// enabling an intelligent assistant to:
/// 1.  **Monitor Exercise Execution:** Identify when an exercise starts and stops.
/// 2.  **Count Repetitions:** Increment a counter for each completed repetition of an exercise.
/// 3.  **Provide Timely Feedback:** Potentially trigger audio cues or visual prompts based on detected activity.
/// 4.  **Manage Workout State:** Keep track of the current exercise, reps, and overall session progress.
///
/// This component focuses on the motion detection and classification engine, demonstrating
/// robust sensor data handling, ML inference, state management, and Swift 6 concurrency patterns.

// MARK: - Model Definition Placeholder

/// Represents the output activities our ML model can classify.
/// These should correspond to the labels used during Create ML training.
enum WorkoutActivity: String, CaseIterable, Codable {
    case bicepCurl = "Bicep Curl"
    case tricepExtension = "Tricep Extension"
    case rest = "Rest"
    case unknown = "Unknown" // For when the model is uncertain or not yet trained for a state

    /// A helper to determine if the activity is an active exercise.
    var isExercise: Bool {
        self == .bicepCurl || self == .tricepExtension
    }
}

/// Represents the current state of the workout monitoring process.
enum WorkoutState: Equatable { // Equatable for easier comparison in tests/logic
    case idle // Not monitoring
    case calibrating // Initial phase, e.g., to gather baseline data
    case monitoring(activity: WorkoutActivity, reps: Int) // Actively monitoring an exercise
    case paused // Monitoring is temporarily paused
    case error(String) // An error occurred (using String for simplicity in Equatable)

    // Custom Equatable implementation to handle associated values
    static func == (lhs: WorkoutState, rhs: WorkoutState) -> Bool {
        switch (lhs, rhs) {
        case (.idle, .idle), (.calibrating, .calibrating), (.paused, .paused):
            return true
        case (.monitoring(let lActivity, let lReps), .monitoring(let rActivity, let rReps)):
            return lActivity == rActivity && lReps == rReps
        case (.error(let lError), .error(let rError)):
            return lError == rError // Compare error messages
        default:
            return false
        }
    }
}

/// A structure to encapsulate the result of a single activity classification.
struct ActivityPrediction {
    let activity: WorkoutActivity
    let confidence: Double
    let timestamp: Date
}

// Assume we have an `ExerciseClassifier.mlmodel` generated by Create ML.
// For demonstration, we'll create a mock class that mimics its interface.
/// Mock `ExerciseClassifierInput` class to simulate the input object for a Create ML generated model.
class ExerciseClassifierInput: MLFeatureProvider {
    var featureNames: Set<String> { ["input_sequence"] } // The name of the input feature in the ML model
    private let inputSequence: MLMultiArray

    init(inputSequence: MLMultiArray) {
        self.inputSequence = inputSequence
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "input_sequence" {
            return MLFeatureValue(multiArray: inputSequence)
        }
        return nil
    }
}

/// Mock `ExerciseClassifierOutput` class to simulate the output object from a Create ML generated model.
class ExerciseClassifierOutput: MLFeatureProvider {
    var featureNames: Set<String> { ["label", "label_probabilities"] } // Output feature names
    let label: String
    let label_probabilities: [String: Double]

    init(label: String, label_probabilities: [String: Double]) {
        self.label = label
        self.label_probabilities = label_probabilities
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "label" {
            return MLFeatureValue(string: label)
        }
        if featureName == "label_probabilities" {
            return MLFeatureValue(dictionary: label_probabilities as [AnyHashable : NSNumber])
        }
        return nil
    }
}

/// Mock `ExerciseClassifier` class to simulate a Create ML generated model.
/// In a real app, this would be the actual `ExerciseClassifier` class generated
/// by Xcode when you add an `.mlmodel` file to your project.
class ExerciseClassifier {
    // In a real app, this would be the compiled MLModel instance
    // private let model: MLModel 

    /// Initializes the mock classifier. In a real app, this would load the actual .mlmodel.
    /// - Throws: `MLError` if the model cannot be loaded (simulated).
    init() throws {
        // In a real app, you would load your compiled ML model:
        // let config = MLModelConfiguration()
        // self.model = try ExerciseClassifier(configuration: config).model
        
        // For this example, we just simulate a successful initialization.
        // If we wanted to simulate a loading error, we could throw here.
        print("ExerciseClassifier initialized (mock).")
    }

    /// Performs a prediction using the provided input.
    /// - Parameter input: An `ExerciseClassifierInput` containing the sensor data sequence.
    /// - Returns: An `ExerciseClassifierOutput` with the predicted activity label and probabilities.
    /// - Throws: `MLError` if prediction fails (simulated).
    func prediction(input: ExerciseClassifierInput) async throws -> ExerciseClassifierOutput {
        // Simulate ML model inference time
        try await Task.sleep(for: .milliseconds(50))

        // In a real app, you would call:
        // let predictionOutput = try model.prediction(from: input)
        // return ExerciseClassifierOutput(label: predictionOutput.featureValue(for: "label")!.stringValue,
        //                                 label_probabilities: predictionOutput.featureValue(for: "label_probabilities")!.dictionaryValue as! [String: Double])

        // For this mock, we'll just return a plausible output based on a random choice
        // to simulate different activities and their probabilities.
        let random = Double.random(in: 0...1)
        let predictedActivity: WorkoutActivity
        let probabilities: [String: Double]

        if random < 0.3 {
            predictedActivity = .bicepCurl
            probabilities = ["Bicep Curl": 0.8, "Tricep Extension": 0.1, "Rest": 0.1]
        } else if random < 0.6 {
            predictedActivity = .tricepExtension
            probabilities = ["Tricep Extension": 0.7, "Bicep Curl": 0.2, "Rest": 0.1]
        } else {
            predictedActivity = .rest
            probabilities = ["Rest": 0.9, "Bicep Curl": 0.05, "Tricep Extension": 0.05]
        }

        return ExerciseClassifierOutput(label: predictedActivity.rawValue, label_probabilities: probabilities)
    }
}


// MARK: - Core Logic Breakdown

/// **1. Model Loading and Initialization:**
/// The `WorkoutMonitor` class attempts to load the `ExerciseClassifier.mlmodel` upon initialization.
/// This model, typically generated by Create ML, is crucial for classifying motion data.
/// Error handling is present to catch issues if the model cannot be found or loaded.
///
/// **2. Sensor Data Acquisition (`CMMotionManager`):**
/// `CMMotionManager` is used to access raw accelerometer and gyroscope data.
/// Instead of traditional delegate patterns, we use its handler-based updates, ensuring they run
/// on a dedicated `OperationQueue` (`predictionQueue`) to prevent blocking the main thread.
/// This queue is also used for ML inference.
///
/// **3. Data Buffering and Windowing:**
/// `MLActivityClassifier` models typically require a fixed-size sequence (a "window") of sensor data
/// to make a prediction. As `CMDeviceMotion` updates arrive, their relevant components (acceleration,
/// rotation rates) are extracted and stored in a circular buffer (`sensorDataBuffer`).
/// Once the buffer reaches the required `sequenceLength` (e.g., 50 samples), it's ready for prediction.
///
/// **4. Prediction with `MLActivityClassifier`:**
/// When a full window of data is available, it's converted into an `MLMultiArray` in the format
/// expected by the `ExerciseClassifier` model (e.g., `[sequenceLength, numberOfFeatures]`).
/// The `prediction(input:)` method is called on the `ExerciseClassifier` instance within an `async Task`
/// to perform the ML inference off the main thread, ensuring UI responsiveness.
/// The prediction result includes the classified `WorkoutActivity` and its confidence.
///
/// **5. State Management and Repetition Counting:**
/// The `WorkoutMonitor` maintains a `WorkoutState` (`idle`, `monitoring`, `paused`, `error`).
/// Upon receiving a prediction, the `currentActivity` and `repsCount` are updated.
/// A simple state machine logic is implemented to count repetitions: a transition from an
/// exercise activity (e.g., "Bicep Curl") to a "Rest" state, and then back to the *same*
/// exercise activity, indicates a completed repetition. A `debounce` mechanism prevents
/// over-counting due to transient classifications.
///
/// **6. Concurrency and Error Handling:**
/// Swift's `async/await` is extensively used for asynchronous ML inference and publishing updates.
/// `Task`s are used to manage concurrent operations.
/// `do-catch` blocks handle potential errors during model loading, sensor access, and prediction.
/// `AsyncStream` provides a clean way to observe sensor data and publish activity updates,
/// which can then be consumed by SwiftUI views or other parts of the application.
/// `CMMotionManager` availability is checked, and appropriate errors are propagated.
/// `@MainActor` is used to ensure all state updates that might affect the UI are performed on the main thread.

// MARK: - WorkoutMonitor Component

/// Errors specific to the WorkoutMonitor.
enum WorkoutMonitorError: Error, LocalizedError {
    case motionDataUnavailable
    case modelLoadingFailed(Error)
    case predictionFailed(Error)
    case invalidModelInputFormat
    case invalidModelOutputFormat

    var errorDescription: String? {
        switch self {
        case .motionDataUnavailable:
            return "Motion sensor data is not available on this device."
        case .modelLoadingFailed(let error):
            return "Failed to load ML model: \(error.localizedDescription)"
        case .predictionFailed(let error):
            return "ML prediction failed: \(error.localizedDescription)"
        case .invalidModelInputFormat:
            return "The sensor data format does not match the ML model's expected input."
        case .invalidModelOutputFormat:
            return "The ML model returned an unexpected output format."
        }
    }
}

/// A class responsible for monitoring and classifying exercise activities using motion sensors and an ML model.
@available(iOS 15.0, *) // AsyncStream and modern concurrency require iOS 15+
class WorkoutMonitor {
    // MARK: - Properties

    private let motionManager = CMMotionManager()
    private let exerciseClassifier: ExerciseClassifier
    private let predictionQueue = OperationQueue() // Dedicated queue for sensor updates and ML predictions
    private let sensorUpdateInterval: TimeInterval = 1.0 / 50.0 // 50 Hz update rate
    private let sequenceLength: Int = 50 // Number of sensor samples per prediction window (e.g., 1 second at 50Hz)
    private let numberOfFeatures: Int = 6 // Accel X, Y, Z, Gyro X, Y, Z

    // Buffer to store sensor data before making a prediction
    private var sensorDataBuffer: [MLMultiArray] = []
    private var lastPredictedActivity: WorkoutActivity = .rest
    private var currentReps: Int = 0
    private var lastRepTransitionTime: Date = Date()
    private let repDebounceInterval: TimeInterval = 0.5 // Minimum time between rep counts to avoid over-counting

    private let activityStreamContinuation: AsyncStream<WorkoutState>.Continuation
    /// An `AsyncStream` that provides real-time updates on the workout monitoring state.
    /// Consumers can `await` new `WorkoutState` values to update UI or logic.
    public let activityUpdates: AsyncStream<WorkoutState>

    // MARK: - Initialization

    /// Initializes the workout monitor, attempting to load the ML model.
    /// - Throws: `WorkoutMonitorError.modelLoadingFailed` if the ML model cannot be loaded.
    init() throws {
        // 1. Model Loading and Initialization
        do {
            self.exerciseClassifier = try ExerciseClassifier()
            // Configure prediction queue
            predictionQueue.maxConcurrentOperationCount = 1 // Ensure predictions are processed sequentially
            predictionQueue.qualityOfService = .userInitiated // High priority for responsiveness
        } catch {
            throw WorkoutMonitorError.modelLoadingFailed(error)
        }

        // Initialize the AsyncStream and its continuation
        var streamContinuation: AsyncStream<WorkoutState>.Continuation!
        self.activityUpdates = AsyncStream { continuation in
            streamContinuation = continuation
        }
        self.activityStreamContinuation = streamContinuation // Assign the captured continuation
    }

    // MARK: - Public Methods

    /// Starts monitoring exercise activities.
    /// - Throws: `WorkoutMonitorError.motionDataUnavailable` if motion sensors are not available.
    public func startMonitoring() throws {
        // 2. Sensor Data Acquisition (`CMMotionManager`)
        guard motionManager.isDeviceMotionAvailable else {
            activityStreamContinuation.yield(.error(WorkoutMonitorError.motionDataUnavailable.localizedDescription))
            throw WorkoutMonitorError.motionDataUnavailable
        }

        // Reset state for a new session
        sensorDataBuffer.removeAll()
        lastPredictedActivity = .rest
        currentReps = 0
        lastRepTransitionTime = Date()
        
        // Inform consumers that monitoring is starting
        activityStreamContinuation.yield(.monitoring(activity: .rest, reps: 0))

        motionManager.deviceMotionUpdateInterval = sensorUpdateInterval

        // Start receiving device motion updates on the dedicated predictionQueue
        motionManager.startDeviceMotionUpdates(to: predictionQueue) { [weak self] (motion, error) in
            guard let self = self else { return }

            if let error = error {
                self.activityStreamContinuation.yield(.error(error.localizedDescription))
                self.stopMonitoring() // Stop on error
                return
            }

            guard let motion = motion else { return }

            // 3. Data Buffering and Windowing
            self.processDeviceMotion(motion)
        }
    }

    /// Stops monitoring exercise activities.
    public func stopMonitoring() {
        motionManager.stopDeviceMotionUpdates()
        // Inform consumers that monitoring has stopped and is now idle.
        activityStreamContinuation.yield(.idle)
        // If the stream should be completely finished and not reused, call `activityStreamContinuation.finish()`.
        // For a reusable monitor, we typically just set it to idle.
    }

    // MARK: - Private Sensor Processing

    /// Processes incoming `CMDeviceMotion` data, adds it to the buffer, and triggers prediction.
    /// - Parameter motion: The `CMDeviceMotion` object containing accelerometer and gyroscope data.
    private func processDeviceMotion(_ motion: CMDeviceMotion) {
        // Create an MLMultiArray for the current sample
        guard let currentSample = try? MLMultiArray(shape: [1, numberOfFeatures] as [NSNumber], dataType: .double) else {
            activityStreamContinuation.yield(.error(WorkoutMonitorError.invalidModelInputFormat.localizedDescription))
            return
        }

        // Populate the MLMultiArray with sensor data (user acceleration and rotation rate)
        currentSample[0] = motion.userAcceleration.x as NSNumber
        currentSample[1] = motion.userAcceleration.y as NSNumber
        currentSample[2] = motion.userAcceleration.z as NSNumber
        currentSample[3] = motion.rotationRate.x as NSNumber
        currentSample[4] = motion.rotationRate.y as NSNumber
        currentSample[5] = motion.rotationRate.z as NSNumber

        sensorDataBuffer.append(currentSample)

        // If buffer exceeds sequence length, remove the oldest sample to maintain a sliding window
        if sensorDataBuffer.count > sequenceLength {
            sensorDataBuffer.removeFirst()
        }

        // 4. Prediction with `MLActivityClassifier`
        // Only predict when the buffer is full (i.e., we have enough samples for one window)
        if sensorDataBuffer.count == sequenceLength {
            // Perform prediction in a separate Task to avoid blocking the sensor queue
            // and ensure that state updates (via yield) happen on the MainActor.
            Task { @MainActor in
                do {
                    // Convert the buffered samples into a single MLMultiArray for the model input
                    let inputMultiArray = try self.createInputMultiArray(from: self.sensorDataBuffer)
                    let input = ExerciseClassifierInput(inputSequence: inputMultiArray)
                    
                    // Await the prediction from the ML model
                    let output = try await self.exerciseClassifier.prediction(input: input)

                    // Validate the model output format and convert to WorkoutActivity enum
                    guard let predictedLabel = WorkoutActivity(rawValue: output.label) else {
                        throw WorkoutMonitorError.invalidModelOutputFormat
                    }

                    // For this example, we'll take the top prediction.
                    // In a real app, you might use confidence thresholds to filter uncertain predictions.
                    let confidence = output.label_probabilities[predictedLabel.rawValue] ?? 0.0
                    let prediction = ActivityPrediction(activity: predictedLabel, confidence: confidence, timestamp: Date())

                    // 5. State Management and Repetition Counting
                    self.handlePrediction(prediction)
                } catch {
                    self.activityStreamContinuation.yield(.error(WorkoutMonitorError.predictionFailed(error).localizedDescription))
                }
            }
            // After prediction, clear the buffer for the next window.
            // For a truly continuous recognition with overlapping windows,
            // you might remove only a fraction of samples (e.g., `sequenceLength / 5`)
            // and keep the rest for the next prediction. For simplicity, we clear it.
            sensorDataBuffer.removeAll()
        }
    }

    /// Creates an `MLMultiArray` from the buffered sensor data for model input.
    /// The model expects a single `MLMultiArray` of shape `[sequenceLength, numberOfFeatures]`.
    /// - Parameter buffer: An array of `MLMultiArray` where each represents a single sensor sample.
    /// - Returns: A single `MLMultiArray` suitable for the ML model input.
    /// - Throws: `WorkoutMonitorError.invalidModelInputFormat` if the buffer cannot be converted.
    private func createInputMultiArray(from buffer: [MLMultiArray]) throws -> MLMultiArray {
        guard !buffer.isEmpty, buffer.count == sequenceLength else {
            throw WorkoutMonitorError.invalidModelInputFormat // Buffer not full or empty
        }

        // Initialize the final MLMultiArray with the expected shape
        guard let inputMultiArray = try? MLMultiArray(shape: [sequenceLength as NSNumber, numberOfFeatures as NSNumber], dataType: .double) else {
            throw WorkoutMonitorError.invalidModelInputFormat
        }

        // Copy data from individual sample MLMultiArrays into the combined inputMultiArray
        for (sampleIndex, sample) in buffer.enumerated() {
            for featureIndex in 0..<numberOfFeatures {
                inputMultiArray[[sampleIndex as NSNumber, featureIndex as NSNumber]] = sample[featureIndex]
            }
        }
        return inputMultiArray
    }

    /// Handles a new activity prediction, updates state, and counts repetitions.
    /// Ensures all state updates are performed on the main actor to prevent race conditions
    /// and allow UI elements to safely observe these changes.
    /// - Parameter prediction: The `ActivityPrediction` received from the ML model.
    @MainActor
    private func handlePrediction(_ prediction: ActivityPrediction) {
        // Debounce mechanism for rep counting to prevent rapid toggling due to noisy predictions.
        // We only consider a new "rep transition" if enough time has passed since the last one.
        guard prediction.timestamp.timeIntervalSince(lastRepTransitionTime) > repDebounceInterval else {
            // Still within debounce interval. Update current activity if it's a strong, new prediction,
            // but don't count a rep yet.
            if prediction.activity != lastPredictedActivity && prediction.confidence > 0.7 {
                 lastPredictedActivity = prediction.activity
                 activityStreamContinuation.yield(.monitoring(activity: lastPredictedActivity, reps: currentReps))
            }
            return
        }

        // Repetition counting logic:
        // A rep is typically counted when transitioning from an active exercise to a "Rest" state,
        // and then back to the *same* exercise activity. This prevents counting a rep if the user
        // switches exercises mid-way.
        if lastPredictedActivity.isExercise && prediction.activity == .rest {
            // Transitioned from an exercise to rest. This is the "bottom" of a rep cycle.
            lastPredictedActivity = prediction.activity
            lastRepTransitionTime = prediction.timestamp
            activityStreamContinuation.yield(.monitoring(activity: lastPredictedActivity, reps: currentReps))
        } else if !lastPredictedActivity.isExercise && prediction.activity.isExercise && prediction.activity != .rest {
            // Transitioned from rest back to an exercise (implies a rep completed).
            // We only count if the *type* of exercise is the same as the one we just left,
            // or if we are starting a new exercise from a rest state.
            currentReps += 1
            lastPredictedActivity = prediction.activity
            lastRepTransitionTime = prediction.timestamp
            activityStreamContinuation.yield(.monitoring(activity: lastPredictedActivity, reps: currentReps))
            print("Repetition Count: \(currentReps) for \(prediction.activity.rawValue)")
        } else if prediction.activity != lastPredictedActivity {
            // Activity changed but not a clear rep transition (e.g., Bicep Curl -> Tricep Extension directly).
            // Reset state for new activity.
            lastPredictedActivity = prediction.activity
            lastRepTransitionTime = prediction.timestamp // Reset debounce for the new activity
            activityStreamContinuation.yield(.monitoring(activity: lastPredictedActivity, reps: currentReps))
        }
        // If activity is the same and within debounce, do nothing for rep counting.
    }
}

// MARK: - Example Usage (within an app's lifecycle, e.g., a SwiftUI View or ViewController)

/// This extension provides a simple way to run the example in a playground or an app.
@available(iOS 15.0, *)
extension WorkoutMonitor {
    /// Simulates a workout session, demonstrating how to use `WorkoutMonitor`.
    /// This function would typically be called from a UI event (e.g., button tap).
    static func simulateWorkoutSession() async {
        print("--- Starting Workout Session Simulation ---")
        var monitor: WorkoutMonitor?
        do {
            monitor = try WorkoutMonitor()

            // Observe the activity updates from the monitor in a separate Task.
            // This allows the main thread to remain responsive.
            Task {
                for await state in monitor!.activityUpdates {
                    switch state {
                    case .idle:
                        print("Monitor State: Idle")
                    case .calibrating:
                        print("Monitor State: Calibrating...")
                    case .monitoring(let activity, let reps):
                        print("Monitor State: Monitoring - Current Activity: \(activity.rawValue), Reps: \(reps)")
                    case .paused:
                        print("Monitor State: Paused")
                    case .error(let errorDescription):
                        print("Monitor State: Error - \(errorDescription)")
                        monitor?.stopMonitoring() // Stop monitoring on error
                        return // Exit this observation task
                    }
                }
                print("WorkoutMonitor activity stream finished.")
            }

            // Start monitoring
            try monitor?.startMonitoring()
            print("Monitoring started. Simulating exercise for 10 seconds...")

            // Keep the simulation running for a short period to allow predictions to occur.
            try await Task.sleep(for: .seconds(10))

            print("Simulating stop monitoring...")
            monitor?.stopMonitoring()

            // Give some time for the last updates to propagate and for the observation task to potentially finish.
            try await Task.sleep(for: .seconds(1))

        } catch {
            print("Error during workout session: \(error.localizedDescription)")
        }
        print("--- Workout Session Simulation Ended ---")
    }
}

// To run this in a Swift Playground or a simple command-line tool:
// 1. Ensure your project/playground target links CoreML and CoreMotion frameworks.
// 2. If using a real .mlmodel, ensure it's added to your target's bundle.
//    For this example, the `ExerciseClassifier` is mocked, so no actual .mlmodel file is strictly needed
//    for the code to compile and run, but a warning will be printed if it's not found.

// To run the simulation in a playground:
/*
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

Task {
    await WorkoutMonitor.simulateWorkoutSession()
    PlaygroundPage.current.finishExecution()
}
*/
