
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import NaturalLanguage
import Foundation
import CoreML // Required for MLModel

// Mark: - 1. Define a simple NLModel wrapper for our specific task

/// A utility class to load and use an NLModel for feedback classification.
/// This class assumes a Core ML model named "FeedbackClassifier.mlmodel" is available in the app bundle.
@available(iOS 12.0, *) // NLModel is available from iOS 12.0
class FeedbackClassifier {
    private var model: NLModel?

    /// Initializes the classifier by loading the Core ML model.
    /// - Throws: An error if the model cannot be found or loaded.
    init() throws {
        // 1.1. Locate the Core ML model file in the app bundle.
        // This assumes 'FeedbackClassifier.mlmodel' is added to your Xcode project and included in the target bundle.
        guard let modelURL = Bundle.main.url(forResource: "FeedbackClassifier", withExtension: "mlmodel") else {
            // If the model file is not found, throw a fatal error or a specific error.
            // For a production app, you'd handle this more gracefully (e.g., return nil, throw a custom error).
            throw FeedbackClassifierError.modelNotFound
        }

        // 1.2. Load the Core ML model from the URL.
        // MLModel is the underlying type for all Core ML models.
        let coreMLModel = try MLModel(contentsOf: modelURL)

        // 1.3. Initialize NLModel with the loaded Core ML model.
        // NLModel wraps the Core ML model, providing a simpler API for text-based tasks.
        self.model = NLModel(mlModel: coreMLModel)

        // For demonstration purposes, print a success message.
        print("✅ FeedbackClassifier model loaded successfully.")
    }

    /// Classifies a given text string into one of the predefined categories.
    /// - Parameter text: The feedback text to classify.
    /// - Returns: The predicted category as a String, or nil if classification fails.
    func classify(text: String) -> String? {
        // 1.4. Use the NLModel to predict the category of the input text.
        // The `prediction(for:)` method takes a String and returns an optional String.
        guard let prediction = model?.prediction(for: text) else {
            print("⚠️ Failed to get a prediction for text: \"\(text)\"")
            return nil
        }
        return prediction
    }
}

// Mark: - 2. Define Custom Errors

/// Custom errors for the FeedbackClassifier.
enum FeedbackClassifierError: Error, LocalizedError {
    case modelNotFound
    case classificationFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelNotFound:
            return "The 'FeedbackClassifier.mlmodel' could not be found in the app bundle. Please ensure it's added to your project and target."
        case .classificationFailed(let text):
            return "Classification failed for text: \"\(text)\""
        }
    }
}

// Mark: - 3. Example Usage in an App Context

/// Entry point for demonstrating the FeedbackClassifier.
/// This would typically be called from an AppDelegate, SceneDelegate, or a SwiftUI View.
@available(iOS 12.0, *)
func demonstrateFeedbackClassification() {
    print("\n--- Demonstrating Feedback Classification ---")

    // 3.1. Initialize the classifier.
    // This should ideally happen once, e.g., when your app starts or the feature is first accessed,
    // to avoid repeatedly loading the model.
    let classifier: FeedbackClassifier
    do {
        classifier = try FeedbackClassifier()
    } catch {
        print("❌ Error initializing FeedbackClassifier: \(error.localizedDescription)")
        return
    }

    // 3.2. Prepare sample feedback texts.
    let feedbackTexts = [
        "The app crashed when I tried to open the camera.",
        "Could you add a dark mode option? It would be great for night use.",
        "The user interface is a bit confusing, especially the settings screen.",
        "I love this app! It's so useful.",
        "I have a general question about my account.",
        "The save button doesn't seem to work on the profile page."
    ]

    // 3.3. Classify each feedback text and print the results.
    for text in feedbackTexts {
        if let category = classifier.classify(text: text) {
            print("Text: \"\(text)\"\n  -> Category: \(category)\n")
        } else {
            print("Text: \"\(text)\"\n  -> Category: Unknown (classification failed)\n")
        }
    }

    print("--- End of Demonstration ---")
}

// Mark: - 4. Call the demonstration function (e.g., in an app's lifecycle or playground)

// To run this in an Xcode project, you might call it from `AppDelegate.didFinishLaunchingWithOptions`
// or in a SwiftUI `App` struct's `init()` or `onAppear`.
// For a Swift Playground, simply call it directly.

// Ensure the environment supports iOS 12.0 or later for NLModel.
// This check is good practice for older OS versions, though for modern apps, iOS 12 is very old.
if #available(iOS 12.0, *) {
    demonstrateFeedbackClassification()
} else {
    print("NLModel requires iOS 12.0 or later. This example cannot run on older OS versions.")
}

