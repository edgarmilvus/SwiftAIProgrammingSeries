
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// Define a simple destination type for NavigationPath
enum ChatDestination: Codable, Hashable {
    case chatSession
}

struct ChatSessionManagerApp: App {
    var body: some Scene {
        WindowGroup {
            RootChatView()
        }
    }
}

struct RootChatView: View {
    @State private var path = NavigationPath()

    var body: some View {
        NavigationStack(path: $path) {
            VStack {
                Spacer()
                Text("Welcome to AI Chat")
                    .font(.largeTitle)
                    .padding()

                Button("Start New Chat") {
                    path.append(ChatDestination.chatSession)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                Spacer()
            }
            .navigationTitle("AI Chat")
            .navigationDestination(for: ChatDestination.self) { destination in
                switch destination {
                case .chatSession:
                    ChatView(path: $path) // Pass path for programmatic dismissal
                }
            }
        }
    }
}

struct ChatView: View {
    @Binding var path: NavigationPath // Binding to the NavigationPath for dismissal
    @State private var chatHistory: [String] = ["AI: Hello! How can I help you today?"]
    @State private var newMessage: String = ""

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(chatHistory, id: \.self) { message in
                        Text(message)
                            .padding(8)
                            .background(message.hasPrefix("AI:") ? Color.blue.opacity(0.2) : Color.green.opacity(0.2))
                            .cornerRadius(10)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }

            HStack {
                TextField("Type a message...", text: $newMessage)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button("Send") {
                    if !newMessage.isEmpty {
                        chatHistory.append("You: \(newMessage)")
                        newMessage = ""
                        // Simulate AI response
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            chatHistory.append("AI: I'm processing your request...")
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding(.trailing)
            }
            .padding(.bottom)
        }
        .navigationTitle("Active Chat")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("End Chat") {
                    // Programmatically dismiss the entire chat session
                    // by clearing the navigation path.
                    path.removeAll()
                }
            }
        }
    }
}
