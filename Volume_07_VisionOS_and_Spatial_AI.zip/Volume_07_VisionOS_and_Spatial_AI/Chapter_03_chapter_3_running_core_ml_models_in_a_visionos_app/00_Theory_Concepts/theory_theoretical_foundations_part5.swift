
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation
import CoreGraphics // For CVPixelBuffer

// Define a custom actor for Core ML inference
@globalActor actor CoreMLInferenceActor {
    static let shared = CoreMLInferenceActor()
}

@available(visionOS 1.0, *)
@CoreMLInferenceActor // All members of this class will run on the CoreMLInferenceActor
class InferenceService {
    private var model: MLModel?
    
    // Initializer runs on the CoreMLInferenceActor
    init() {
        Task { // Task is needed because init() cannot be async directly
            do {
                let config = MLModelConfiguration()
                config.computeUnits = .all
                // Assuming MyImageClassifier is the generated class
                let classifier = try MyImageClassifier(configuration: config)
                self.model = classifier.model
                print("Core ML model loaded on InferenceService actor.")
            } catch {
                print("Failed to load Core ML model on InferenceService actor: \(error)")
            }
        }
    }
    
    // This method is isolated to CoreMLInferenceActor
    func predict(imageBuffer: CVPixelBuffer) async throws -> String {
        guard let model = self.model else {
            throw SpatialAIError.modelNotLoaded
        }
        
        // Create input (assuming MyImageClassifierInput is generated)
        let input = MyImageClassifierInput(image: imageBuffer)
        
        // Perform prediction. This call is isolated to the actor's execution context.
        let output = try await model.prediction(from: input)
        
        guard let label = output.featureValue(for: "label")?.stringValue else {
            throw SpatialAIError.outputMissing
        }
        return label
    }
}

// How to use it from the MainActor (e.g., from a RealityView or SwiftUI View)
@available(visionOS 1.0, *)
@MainActor
class ViewModel: ObservableObject {
    private let inferenceService = InferenceService.shared // Access the shared actor instance
    @Published var detectedLabel: String = "Detecting..."
    
    func analyzeFrame(buffer: CVPixelBuffer) {
        Task {
            do {
                // Call the actor's method. The 'await' keyword bridges to the actor's context.
                let label = try await inferenceService.predict(imageBuffer: buffer)
                self.detectedLabel = label // Update @Published property on MainActor
            } catch {
                print("Prediction failed: \(error)")
                self.detectedLabel = "Error"
            }
        }
    }
}
