
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import NaturalLanguage

@available(iOS 18.0, *)
@Observable
class MultilingualViewModel {
    private let detectorActor = NLLanguageDetectorActor() // Our actor for safe detection
    var inputText: String = "" {
        didSet {
            // Trigger detection whenever input text changes
            Task { await detectLanguageForInput() }
        }
    }
    var detectedLanguage: NLLanguage?
    var confidence: Double?
    var allHypotheses: [NLLanguage: Double] = [:]
    var isLoading: Bool = false

    @MainActor // Ensure UI updates happen on the main thread
    private func detectLanguageForInput() async {
        guard !inputText.isEmpty else {
            detectedLanguage = nil
            confidence = nil
            allHypotheses = [:]
            return
        }

        isLoading = true
        let hypotheses = await detectorActor.detectHypotheses(for: inputText)
        isLoading = false

        if let dominant = hypotheses.max(by: { $0.1 < $1.1 }) {
            detectedLanguage = dominant.key
            confidence = dominant.value
        } else {
            detectedLanguage = nil
            confidence = nil
        }
        allHypotheses = hypotheses
    }
}

@available(iOS 18.0, *)
struct LanguageDetectionView: View {
    @State private var viewModel = MultilingualViewModel()

    var body: some View {
        VStack(spacing: 20) {
            TextField("Enter text here...", text: $viewModel.inputText)
                .textFieldStyle(.roundedBorder)
                .padding()

            if viewModel.isLoading {
                ProgressView("Detecting language...")
            } else if let language = viewModel.detectedLanguage {
                Text("Detected Language: \(language.rawValue.capitalized)")
                    .font(.headline)
                if let confidence = viewModel.confidence {
                    Text(String(format: "Confidence: %.2f%%", confidence * 100))
                        .font(.subheadline)
                }

                if !viewModel.allHypotheses.isEmpty {
                    VStack(alignment: .leading) {
                        Text("Other Hypotheses:")
                            .font(.caption)
                        ForEach(viewModel.allHypotheses.sorted(by: { $0.1 > $1.1 }), id: \.key) { lang, conf in
                            if lang != language { // Don't repeat dominant
                                Text("- \(lang.rawValue.capitalized): \(String(format: "%.2f%%", conf * 100))")
                                    .font(.caption2)
                            }
                        }
                    }
                }
            } else {
                Text("Start typing to detect language.")
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .navigationTitle("Language Detector")
    }
}
