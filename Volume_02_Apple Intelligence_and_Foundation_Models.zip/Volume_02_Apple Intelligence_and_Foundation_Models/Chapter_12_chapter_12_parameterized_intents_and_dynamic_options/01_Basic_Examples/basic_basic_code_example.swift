
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import AppIntents // Required for AppIntents framework components

// MARK: - 1. Define the Parameter Type (TaskPriority)

/// Represents the priority level for a task.
/// This enum will be used as a parameter type for our intent.
/// It conforms to `CaseIterable` and `Codable` for convenience and system integration.
/// `AppEnum` conformance is needed for `AppIntents` to recognize it as a discoverable enum type,
/// especially when used with `DynamicOptionsProvider` or directly as an `@Option`.
@available(iOS 18.0, *) // Marking as available for iOS 18 to align with Apple Intelligence context
enum TaskPriority: String, AppEnum, CaseIterable, Codable {
    case low = "Low"
    case medium = "Medium"
    case high = "High"
    case urgent = "Urgent" // This option will be dynamically offered

    /// Provides a user-friendly display string for each enum case.
    static var typeDisplayRepresentation: TypeDisplayRepresentation {
        TypeDisplayRepresentation(name: "Task Priority")
    }

    /// Provides the display representation for each individual case.
    var displayRepresentation: DisplayRepresentation {
        switch self {
        case .low: return DisplayRepresentation(stringLiteral: "Low")
        case .medium: return DisplayRepresentation(stringLiteral: "Medium")
        case .high: return DisplayRepresentation(stringLiteral: "High")
        case .urgent: return DisplayRepresentation(stringLiteral: "Urgent")
        }
    }
}

// MARK: - 2. Implement a Dynamic Options Provider

/// A provider that dynamically offers `TaskPriority` options based on certain conditions.
/// This is the core of demonstrating "Dynamic Options".
/// For a basic example, we'll simulate a condition (e.g., time of day).
@available(iOS 18.0, *) // Marking as available for iOS 18 to align with Apple Intelligence context
struct TaskPriorityProvider: DynamicOptionsProvider {
    /// The type of elements this provider offers.
    typealias Element = TaskPriority

    /// Fetches the dynamic options. This method is called by the system when it needs
    /// to present options for the associated parameter (e.g., in Shortcuts app, or by Siri).
    ///
    /// - Parameter query: An optional query string provided by the system, useful for filtering
    ///                    options based on user input (e.g., "hi" might suggest "High").
    /// - Returns: An `AppEnumResult` containing the available options.
    func results() async throws -> AppEnumResult<TaskPriority> {
        // Simulate a dynamic condition: if it's after 5 PM, suggest "Urgent" priority.
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: Date())

        var availablePriorities: [TaskPriority] = [.low, .medium, .high]

        // Dynamic logic: Add 'Urgent' only if it's late in the day (after 5 PM)
        // This simulates a context-aware suggestion.
        if hour >= 17 { // 5 PM or later
            availablePriorities.append(.urgent)
            print("DEBUG: It's after 5 PM. 'Urgent' priority is now available dynamically.")
        } else {
            print("DEBUG: It's before 5 PM. 'Urgent' priority is not available dynamically.")
        }

        // In a real-world scenario, the 'query' parameter could be used to filter
        // `availablePriorities` based on user input in the Shortcuts app.
        // For instance, if query is "hi", you might only return `[.high]`.

        // Return the dynamically determined list of priorities.
        return AppEnumResult(availablePriorities)
    }
}

// MARK: - 3. Define the Parameterized Intent

/// An `AppIntent` that allows users to add a new task with a specified title and priority.
/// This intent demonstrates how to use a parameterized intent with dynamic options.
@available(iOS 18.0, *) // Marking as available for iOS 18 to align with Apple Intelligence context
struct AddTaskIntent: AppIntent {
    /// The display name for the intent, shown in Siri and Shortcuts.
    static var title: LocalizedStringResource = "Add Task"

    /// A brief description of what the intent does.
    static var description = IntentDescription("Adds a new task to your to-do list.")

    /// The title of the task. This is a required parameter.
    @Parameter(title: "Task Title", description: "The name or description of the task.")
    var title: String

    /// The priority of the task. This parameter uses our `TaskPriorityProvider`
    /// to offer dynamic options.
    @Parameter(title: "Priority", description: "The priority level for the task.")
    @OptionsProvider(TaskPriorityProvider.self) // Link to our dynamic options provider
    var priority: TaskPriority

    /// The actual action performed by the intent.
    /// This method is asynchronous because `DynamicOptionsProvider` can perform async work,
    /// and the intent itself might involve async operations (e.g., saving to a database).
    func perform() async throws -> some IntentResult {
        // In a real app, you would save this task to a database, Core Data, or CloudKit.
        print("--- Adding Task ---")
        print("Title: \(title)")
        print("Priority: \(priority.displayRepresentation.stringLiteral)")
        print("-------------------")

        // Return a successful result.
        // For a more advanced intent, you might return a custom `IntentResult`
        // that includes the newly created task's ID or other details.
        return .result(
            value: "Task '\(title)' with priority '\(priority.displayRepresentation.stringLiteral)' added successfully.",
            dialog: "I've added \(title) with \(priority.displayRepresentation.stringLiteral) priority to your list."
        )
    }
}

// MARK: - 4. Make the Intent Discoverable (for Siri/Shortcuts)

/// Provides a list of `AppIntent`s that your app makes available to the system.
/// This is how Siri and Shortcuts discover your app's capabilities.
@available(iOS 18.0, *) // Marking as available for iOS 18 to align with Apple Intelligence context
struct TaskManagerAppShortcuts: AppShortcutsProvider {
    /// The category under which your app's shortcuts will appear.
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: AddTaskIntent(),
            phrases: [
                "Add a new task with \(.parameter(\.$title)) and \(.parameter(\.$priority)) priority in \(.applicationName)",
                "Create task \(.parameter(\.$title)) with \(.parameter(\.$priority))",
                "Add \(.parameter(\.$title)) to my list"
            ],
            shortTitle: "Add Task",
            systemImageName: "checklist"
        )
    }
}

// MARK: - Example Usage (Conceptual - how it would be invoked)

/*
    // This part is conceptual as `AppIntents` are invoked by the system (Siri, Shortcuts).
    // You wouldn't typically call `perform()` directly in your main app code for this example,
    // but rather define the intent for the system to use.

    // To simulate the dynamic options, let's imagine a scenario:

    // Scenario 1: Before 5 PM (e.g., 2 PM)
    // If a user opens Shortcuts or asks Siri "Add a task: Prepare presentation with priority",
    // the system would query `TaskPriorityProvider`.
    // The provider would return [.low, .medium, .high].
    // The user would NOT see "Urgent" as an option.

    // Scenario 2: After 5 PM (e.g., 7 PM)
    // If a user opens Shortcuts or asks Siri "Add a task: Prepare presentation with priority",
    // the system would query `TaskPriorityProvider`.
    // The provider would return [.low, .medium, .high, .urgent].
    // The user WOULD see "Urgent" as an option, potentially suggested by Apple Intelligence
    // if the context (e.g., time of day, other tasks) makes it relevant.

    // For testing the `perform` logic directly (not recommended for AppIntents in production):
    // @MainActor // AppIntents often require @MainActor for UI-related interactions, though perform() itself might not directly touch UI.
    // func simulateAddTaskIntent() async {
    //     print("\nSimulating AddTaskIntent before 5 PM logic (Urgent not available)...")
    //     // Simulate an intent call where priority is 'high'
    //     let intent1 = AddTaskIntent()
    //     intent1.title = "Review Chapter 12 Notes"
    //     intent1.priority = .high // This would be selected by user or AI
    //
    //     do {
    //         let result = try await intent1.perform()
    //         print("Simulation Result 1: \(result.dialog.value)")
    //     } catch {
    //         print("Simulation Error 1: \(error)")
    //     }
    //
    //     // To truly test the dynamic options, you'd need to mock the `Date()`
    //     // or run the simulation at different times.
    //     // For this example, the `print` statements in `TaskPriorityProvider`
    //     // will show when 'Urgent' is considered available.
    // }

    // Call the simulation (e.g., from an AppDelegate or SwiftUI App struct)
    // Task { await simulateAddTaskIntent() }
*/
