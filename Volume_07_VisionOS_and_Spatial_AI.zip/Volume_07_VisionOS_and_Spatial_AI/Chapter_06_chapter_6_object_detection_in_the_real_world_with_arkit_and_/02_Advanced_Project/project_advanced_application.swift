
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import Vision
import RealityKit
import Combine

// MARK: - Models

/// Represents a detected physical asset in 3D space.
/// Conforms to Sendable to safely pass between the DetectionActor and the MainActor.
struct DetectedAsset: Sendable, Identifiable {
    let id: UUID
    let label: String
    let confidence: Float
    let worldTransform: simd_float4x4
    let boundingBox: CGRect
}

/// Errors specific to the Spatial Intelligence pipeline.
enum SpatialScannerError: Error {
    case frameCaptureFailed
    case visionInferenceFailed(Error)
    case coordinateMappingFailed
    case sessionNotRunning
}

// MARK: - Detection Engine

/// An actor that handles heavy Vision inference off the main thread.
/// Using an actor ensures that multiple frames don't trigger overlapping 
/// inference tasks, preventing CPU saturation.
@available(iOS 18.0, *)
actor SpatialDetectionActor {
    private var isProcessing = false
    private let visionQueue = DispatchQueue(label: "com.spatial.vision.queue", qos: .userInitiated)
    
    /// The CoreML model used for detection. 
    /// In a real app, this would be a custom-trained YOLO or SSD model.
    private var detectionRequest: VNCoreMLRequest?

    init(model: VNCoreMLModel) {
        // Initialize the request with the provided model
        self.detectionRequest = VNCoreMLRequest(model: model) { [weak self] request, error in
            // Handle completion within the actor's context if necessary
        }
    }

    /// Performs object detection on a provided pixel buffer.
    /// - Parameter pixelBuffer: The CVPixelBuffer from the ARFrame.
    /// - Returns: An array of detected objects with their 2D bounding boxes.
    func detectObjects(in pixelBuffer: CVPixelBuffer) async throws -> [VNRecognizedObjectObservation] {
        // Prevent re-entry if an inference is already in progress
        guard !isProcessing else { return [] }
        isProcessing = true
        
        // Ensure we clean up the processing state regardless of success/failure
        defer { isProcessing = false }

        return try await withCheckedThrowingContinuation { continuation in
            visionQueue.async {
                let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
                do {
                    try handler.perform([self.detectionRequest!])
                    let observations = self.detectionRequest?.results as? [VNRecognizedObjectObservation] ?? []
                    continuation.resume(returning: observations)
                } catch {
                    continuation.resume(throwing: SpatialScannerError.visionInferenceFailed(error))
                }
            }
        }
    }
}

// MARK: - Main Manager

/// The primary coordinator for the Spatial Scanning experience.
/// This class manages the ARSession, coordinates with the DetectionActor,
/// and updates the RealityKit scene.
@available(iOS 18.0, *)
@MainActor
class SpatialScannerManager: NSObject, ObservableObject {
    
    // MARK: Properties
    
    @Published private(set) var detectedAssets: [DetectedAsset] = []
    @Published var isScanning = false
    
    private let arView: ARView
    private let detectionActor: SpatialDetectionActor
    private var session: ARSession { arView.session }
    
    // To prevent flooding the system, we use a simple throttle mechanism
    private var lastDetectionTime: Date = .distantPast
    private let detectionInterval: TimeInterval = 0.5 

    // MARK: Initialization

    /// Initializes the scanner with a RealityKit view and a CoreML model.
    /// - Parameters:
    ///   - arView: The ARView used for rendering.
    ///   - model: The CoreML model for object detection.
    init(arView: ARView, model: VNCoreMLModel) {
        self.arView = arView
        self.detectionActor = SpatialDetectionActor(model: model)
        super.init()
        setupARSession()
    }

    private func setupARSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal, .vertical]
        configuration.environmentTexturing = .automatic
        
        // Enable scene reconstruction for better raycasting accuracy
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            configuration.sceneReconstruction = .mesh
        }
        
        arView.session.delegate = self
        arView.session.run(configuration)
    }

    // MARK: Public API

    /// Starts the scanning process.
    func startScanning() {
        isScanning = true
    }

    /// Stops the scanning process.
    func stopScanning() {
        isScanning = false
    }

    // MARK: Private Logic

    /// Converts a 2D Vision observation into a 3D Spatial Asset.
    /// This is the "Magic" step where 2D meets 3D.
    private func processObservations(_ observations: [VNRecognizedObjectObservation], in frame: ARFrame) {
        let transform = frame.displayTransform(for: .portrait, viewportSize: arView.bounds.size)
        
        for observation in observations {
            // 1. Get the center of the bounding box
            let rect = observation.boundingBox
            let centerPoint = CGPoint(x: rect.midX, y: rect.midY)
            
            // 2. Convert Vision normalized coordinates to Viewport coordinates
            // Vision (0,0 is top-left) -> ARKit Viewport (0,0 is top-left)
            // Note: Vision coordinates are often flipped relative to UIKit
            let viewportPoint = CGPoint(
                x: centerPoint.x * arView.bounds.width,
                y: (1 - centerPoint.y) * arView.bounds.height
            )
            
            // 3. Perform Raycasting to find the 3D position
            // We use the unprojected point to find where the user is "looking" at the object
            let raycastResults = arView.raycast(from: viewportPoint, allowing: .estimatedPlane, alignment: .any)
            
            if let firstResult = raycastResults.first {
                let label = observation.labels.first?.identifier ?? "Unknown"
                let confidence = observation.confidence
                
                let asset = DetectedAsset(
                    id: UUID(),
                    label: label,
                    confidence: confidence,
                    worldTransform: firstResult.worldTransform,
                    boundingBox: rect
                )
                
                self.detectedAssets.append(asset)
                self.attachVisualFeedback(for: asset)
            }
        }
    }

    /// Adds a RealityKit entity to the scene to represent the detected object.
    private func attachVisualFeedback(for asset: DetectedAsset) {
        // Create a simple 3D anchor
        let anchorEntity = AnchorEntity(world: asset.worldTransform)
        
        // Create a visual representation (e.g., a floating label or a glowing ring)
        let mesh = MeshResource.generateSphere(radius: 0.05)
        let material = SimpleMaterial(color: .systemBlue.withAlphaComponent(0.5), isMetallic: true)
        let modelEntity = ModelEntity(mesh: mesh, materials: [material])
        
        anchorEntity.addChild(modelEntity)
        arView.scene.addAnchor(anchorEntity)
        
        // In a production app, we would use a more sophisticated approach 
        // like updating existing anchors rather than adding new ones.
    }
}

// MARK: - ARSessionDelegate

extension SpatialScannerManager: ARSessionDelegate {
    
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard isScanning else { return }
        
        // Throttle detection to avoid overwhelming the Neural Engine
        let now = Date()
        guard now.timeIntervalSince(lastDetectionTime) > detectionInterval else { return }
        lastDetectionTime = now
        
        // Capture the current frame's pixel buffer
        let pixelBuffer = frame.capturedImage
        
        // Offload inference to the actor
        Task {
            do {
                let observations = try await detectionActor.detectObjects(in: pixelBuffer)
                
                // Return to the MainActor to update UI and RealityKit
                if !observations.isEmpty {
                    processObservations(observations, in: frame)
                }
            } catch {
                print("Detection Error: \(error.localizedDescription)")
            }
        }
    }
}
