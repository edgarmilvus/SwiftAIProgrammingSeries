
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import Speech
import AVFoundation

class MultiLanguageTranscriptionViewController: UIViewController, SFSpeechRecognizerDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    // MARK: - UI Elements
    private let textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 18)
        tv.isEditable = false
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 18)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 18)
        button.backgroundColor = .systemRed
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false
        return button
    }()

    private let localePicker: UIPickerView = {
        let picker = UIPickerView()
        picker.translatesAutoresizingMaskIntoConstraints = false
        return picker
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer? // Now optional and mutable
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    private var supportedLocales: [Locale] = []
    private var selectedLocale: Locale? {
        didSet {
            // Re-initialize speech recognizer when locale changes
            setupSpeechRecognizer()
            updateUIForRecognizerAvailability()
        }
    }

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupButtons()
        populateLocales()
        requestPermissions()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopRecording()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        let stackView = UIStackView(arrangedSubviews: [startButton, stopButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(statusLabel)
        view.addSubview(localePicker)
        view.addSubview(textView)
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            localePicker.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 10),
            localePicker.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            localePicker.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            localePicker.heightAnchor.constraint(equalToConstant: 100),

            textView.topAnchor.constraint(equalTo: localePicker.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: stackView.topAnchor, constant: -20),

            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func setupButtons() {
        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)
    }

    // MARK: - Locale Management
    private func populateLocales() {
        supportedLocales = Array(SFSpeechRecognizer.supportedLocales()).sorted { $0.localizedString(forIdentifier: $0.identifier) ?? "" < $1.localizedString(forIdentifier: $1.identifier) ?? "" }
        localePicker.delegate = self
        localePicker.dataSource = self

        // Select default locale (e.g., en-US or first available)
        if let defaultLocale = supportedLocales.first(where: { $0.identifier == "en-US" }) ?? supportedLocales.first,
           let index = supportedLocales.firstIndex(of: defaultLocale) {
            selectedLocale = defaultLocale
            localePicker.selectRow(index, inComponent: 0, animated: false)
        }
    }

    private func setupSpeechRecognizer() {
        // If recording, stop it gracefully before changing the recognizer
        if audioEngine.isRunning {
            stopRecording()
        }

        guard let locale = selectedLocale else {
            speechRecognizer = nil
            return
        }
        speechRecognizer = SFSpeechRecognizer(locale: locale)
        speechRecognizer?.delegate = self // Set delegate to receive availability updates
    }

    // MARK: - Permissions
    private func requestPermissions() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            DispatchQueue.main.async { // Use DispatchQueue.main.async for consistency
                switch authStatus {
                case .authorized:
                    self.statusLabel.text = "Ready"
                case .denied:
                    self.statusLabel.text = "Speech recognition denied."
                case .restricted:
                    self.statusLabel.text = "Speech recognition restricted."
                case .notDetermined:
                    self.statusLabel.text = "Speech recognition not authorized."
                @unknown default:
                    self.statusLabel.text = "Unknown speech recognition status."
                }
                self.requestMicrophonePermission()
            }
        }
    }

    private func requestMicrophonePermission() {
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                if !granted {
                    self?.statusLabel.text = "Microphone access denied."
                }
                self?.updateUIForRecognizerAvailability() // Update button state based on both permissions and recognizer availability
            }
        }
    }

    private func updateUIForRecognizerAvailability() {
        let isSpeechRecognizerAvailable = speechRecognizer?.isAvailable ?? false
        let isMicrophoneGranted = AVAudioSession.sharedInstance().recordPermission == .granted
        let isSpeechAuthGranted = SFSpeechRecognizer.authorizationStatus() == .authorized

        startButton.isEnabled = isSpeechRecognizerAvailable && isMicrophoneGranted && isSpeechAuthGranted
        if !startButton.isEnabled && !audioEngine.isRunning {
            // Only update status if not currently recording or in an error state
            if !isSpeechAuthGranted {
                statusLabel.text = "Speech recognition not authorized."
            } else if !isMicrophoneGranted {
                statusLabel.text = "Microphone access denied."
            } else if !isSpeechRecognizerAvailable {
                statusLabel.text = "Recognizer not available for selected locale."
            } else {
                statusLabel.text = "Ready" // Should not happen if all are true
            }
        } else if startButton.isEnabled && !audioEngine.isRunning {
            statusLabel.text = "Ready"
        }
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        textView.text = ""
        statusLabel.text = "Recording..."
        startButton.isEnabled = false
        stopButton.isEnabled = true
        localePicker.isUserInteractionEnabled = false // Disable locale changes during recording

        do {
            try startAudioEngineAndRecognition()
        } catch {
            statusLabel.text = "Error starting recording: \(error.localizedDescription)"
            stopRecording() // Clean up on error
        }
    }

    @objc private func stopRecordingTapped() {
        stopRecording()
        statusLabel.text = "Processing..."
    }

    private func startAudioEngineAndRecognition() throws {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw SpeechRecognitionError.recognizerNotAvailable
        }

        if let recognitionTask = recognitionTask {
            recognitionTask.cancel()
            self.recognitionTask = nil
        }

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true

        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                self.textView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                self.stopRecording()
                if let error = error {
                    self.statusLabel.text = "Recognition error: \(error.localizedDescription)"
                } else if isFinal {
                    self.statusLabel.text = "Ready"
                }
            }
        }
    }

    private func stopRecording() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil

        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }

        DispatchQueue.main.async {
            self.updateUIForRecognizerAvailability() // Re-evaluate button state
            self.stopButton.isEnabled = false
            self.localePicker.isUserInteractionEnabled = true // Re-enable locale changes
            if self.statusLabel.text != "Recognition error..." {
                self.statusLabel.text = "Ready"
            }
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        DispatchQueue.main.async {
            self.updateUIForRecognizerAvailability()
        }
    }

    // MARK: - UIPickerViewDataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return supportedLocales.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let locale = supportedLocales[row]
        return locale.localizedString(forIdentifier: locale.identifier)
    }

    // MARK: - UIPickerViewDelegate
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedLocale = supportedLocales[row]
    }

    // MARK: - Custom Errors
    enum SpeechRecognitionError: Error, LocalizedError {
        case recognizerNotAvailable
        var errorDescription: String? {
            switch self {
            case .recognizerNotAvailable:
                return "Speech recognizer is not available for the selected locale."
            }
        }
    }
}
