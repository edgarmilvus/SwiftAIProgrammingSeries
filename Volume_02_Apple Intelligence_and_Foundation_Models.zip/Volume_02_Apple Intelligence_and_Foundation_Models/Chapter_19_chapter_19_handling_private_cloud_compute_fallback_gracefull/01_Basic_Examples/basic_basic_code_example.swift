
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI // For @MainActor and UI-related types

/// Enum representing the developer's preferred compute policy for an AI task.
@available(iOS 18.0, macOS 15.0, *)
enum AIComputePolicy: String, CaseIterable, Identifiable {
    case onDeviceOnly = "On-Device Only"
    case onDevicePreferred = "On-Device Preferred (Fallback to PCC)"
    case privateCloudOnly = "Private Cloud Compute Only"

    var id: String { self.rawValue }
}

/// Enum representing the actual source where the AI computation took place.
@available(iOS 18.0, macOS 15.0, *)
enum AIComputeSource: String {
    case onDevice = "On-Device"
    case privateCloudCompute = "Private Cloud Compute"
}

/// A custom error type for AI processing.
@available(iOS 18.0, macOS 15.0, *)
enum AIProcessingError: Error, LocalizedError {
    case notAvailable(String)
    case processingFailed(String)
    case networkError(String)

    var errorDescription: String? {
        switch self {
        case .notAvailable(let message): return "AI Service Not Available: \(message)"
        case .processingFailed(let message): return "AI Processing Failed: \(message)"
        case .networkError(let message): return "Network Error: \(message)"
        }
    }
}

/// The result structure for our simulated AI processing.
@available(iOS 18.0, macOS 15.0, *)
struct AIProcessingResult {
    let summary: String
    let source: AIComputeSource
}
