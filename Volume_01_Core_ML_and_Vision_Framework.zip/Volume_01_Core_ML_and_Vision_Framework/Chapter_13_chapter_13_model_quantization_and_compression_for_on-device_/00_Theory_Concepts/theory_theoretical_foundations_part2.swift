
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import CoreML
import Vision // Often used with Core ML for image processing

/// An observable class to manage image classification state.
@available(iOS 18.0, *)
@Observable
class LiveImageClassifier {
    private let modelManager = MLModelManager() // Our actor from above
    var currentClassification: String = "Analyzing..."
    var isAnalyzing: Bool = false
    var lastAnalysisTime: TimeInterval?

    // Example of how to prepare input for a Vision-CoreML pipeline
    func classify(image: CGImage) async {
        isAnalyzing = true
        let startTime = Date()

        do {
            // Load model (or retrieve from cache)
            let model = try await modelManager.loadModel(from: Bundle.main.url(forResource: "MyQuantizedModel", withExtension: "mlmodelc")!, named: "MyQuantizedModel")
            
            // Create a Vision request for the Core ML model
            let visionModel = try VNCoreMLModel(for: model)
            let request = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                guard let self = self else { return }
                if let error = error {
                    self.currentClassification = "Error: \(error.localizedDescription)"
                    return
                }
                
                guard let observations = request.results as? [VNClassificationObservation],
                      let topClassification = observations.first else {
                    self.currentClassification = "No classification found."
                    return
                }
                
                self.currentClassification = "\(topClassification.identifier) (\(String(format: "%.2f", topClassification.confidence * 100))%)"
            }
            
            request.imageCropAndScaleOption = .centerCrop // Or other options based on model input requirements
            
            // Perform the Vision request on a background queue
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            try handler.perform([request])

        } catch {
            currentClassification = "Model Error: \(error.localizedDescription)"
        }
        
        lastAnalysisTime = Date().timeIntervalSince(startTime)
        isAnalyzing = false
    }
}

// Example SwiftUI View
@available(iOS 18.0, *)
struct ClassifierView: View {
    @State private var classifier = LiveImageClassifier()
    @State private var selectedImage: UIImage? // Assume this comes from a PhotoPicker

    var body: some View {
        VStack {
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
            } else {
                Text("Select an image to classify.")
            }

            Text(classifier.currentClassification)
                .font(.headline)
                .padding()

            if classifier.isAnalyzing {
                ProgressView()
            }

            if let time = classifier.lastAnalysisTime {
                Text("Analysis took \(String(format: "%.2f", time)) seconds.")
                    .font(.caption)
            }
            
            Button("Classify Image") {
                if let cgImage = selectedImage?.cgImage {
                    Task {
                        await classifier.classify(image: cgImage)
                    }
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(classifier.isAnalyzing || selectedImage == nil)
        }
        .padding()
        // In a real app, you'd integrate a PhotoPicker here to set selectedImage
    }
}
