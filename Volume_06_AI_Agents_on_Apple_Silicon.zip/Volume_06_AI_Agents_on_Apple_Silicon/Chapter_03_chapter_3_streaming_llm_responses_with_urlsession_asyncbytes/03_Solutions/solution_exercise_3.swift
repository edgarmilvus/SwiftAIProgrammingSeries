
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit // Use AppKit for macOS
import Foundation

// Reusing LLMStreamResponse struct from Exercise 2
struct LLMStreamResponse: Decodable {
    let response: String?
    let done: Bool?
}

// MARK: - ChatViewController

@available(iOS 18.0, macOS 15.0, *)
class ChatViewController: UIViewController, UITextFieldDelegate { // Or NSViewController, NSTextFieldDelegate for macOS

    // MARK: - UI Elements

    private lazy var chatTextView: UITextView = { // Or NSTextView for macOS
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.isEditable = false
        tv.font = .systemFont(ofSize: 16)
        tv.backgroundColor = .systemGray6
        tv.textColor = .label
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()

    private lazy var inputTextField: UITextField = { // Or NSTextField for macOS
        let tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Type your message..."
        tf.borderStyle = .roundedRect
        tf.delegate = self
        return tf
    }()

    private lazy var sendButton: UIButton = { // Or NSButton for macOS
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Send", for: .normal)
        button.addTarget(self, action: #selector(sendButtonTapped), for: .touchUpInside)
        return button
    }()

    private lazy var stopButton: UIButton = { // Or NSButton for macOS
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Stop Generating", for: .normal)
        button.tintColor = .systemRed
        button.isEnabled = false // Initially disabled
        button.addTarget(self, action: #selector(stopButtonTapped), for: .touchUpInside)
        return button
    }()

    // MARK: - Properties

    private let streamingURL = URL(string: "http://127.0.0.1:5000/stream/json")!
    private var currentLLMTask: Task<Void, Error>? // Hold reference to the streaming task

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        currentLLMTask?.cancel() // Cancel ongoing task if view disappears
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "AI Chatbot"

        let stackView = UIStackView(arrangedSubviews: [inputTextField, sendButton, stopButton])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .horizontal
        stackView.spacing = 8
        stackView.alignment = .center
        stackView.distribution = .fill

        view.addSubview(chatTextView)
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            chatTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            chatTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            chatTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            stackView.topAnchor.constraint(equalTo: chatTextView.bottomAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalToConstant: 44), // Ensure input field and buttons have a reasonable height

            sendButton.widthAnchor.constraint(equalToConstant: 80),
            stopButton.widthAnchor.constraint(equalToConstant: 140)
        ])
    }

    // MARK: - Actions

    @objc private func sendButtonTapped() {
        guard let message = inputTextField.text, !message.isEmpty else { return }

        // Display user message
        appendMessage("You: \(message)\n", isUser: true)
        inputTextField.text = "" // Clear input

        // Disable send, enable stop
        sendButton.isEnabled = false
        stopButton.isEnabled = true

        // Cancel any previous streaming task before starting a new one
        currentLLMTask?.cancel()
        currentLLMTask = Task {
            defer { // Ensure UI is reset when task finishes, errors, or cancels
                Task { @MainActor in
                    self.sendButton.isEnabled = true
                    self.stopButton.isEnabled = false
                }
            }
            await streamLLMResponse(for: message)
        }
    }

    @objc private func stopButtonTapped() {
        print("Stop button tapped. Cancelling LLM task.")
        currentLLMTask?.cancel() // Request cancellation
        // UI will be reset by the defer block in streamLLMResponse when CancellationError is caught
    }

    // MARK: - Streaming Logic

    private func streamLLMResponse(for prompt: String) async {
        await MainActor.run {
            chatTextView.text.append("\nAI: ") // Start AI response on a new line
            let bottom = NSRange(location: chatTextView.text.count - 1, length: 1)
            chatTextView.scrollRangeToVisible(bottom)
        }

        do {
            // In a real scenario, you'd send the 'prompt' to the LLM endpoint.
            // For this exercise, we use the simulated JSON stream.
            let (bytes, response) = try await URLSession.shared.bytes(for: streamingURL)

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                throw URLError(.badServerResponse)
            }

            var buffer = Data()
            let newline = Data([0x0A]) // ASCII for '\n'

            for await chunk in bytes {
                try Task.checkCancellation() // Check for cancellation
                buffer.append(chunk)

                while let range = buffer.range(of: newline) {
                    let jsonLineData = buffer.prefix(upTo: range.lowerBound)
                    buffer.removeSubrange(0...range.lowerBound)

                    if jsonLineData.isEmpty { continue }

                    do {
                        let decoder = JSONDecoder()
                        let streamResponse = try decoder.decode(LLMStreamResponse.self, from: jsonLineData)

                        if let responseText = streamResponse.response, !responseText.isEmpty {
                            await appendMessage(responseText, isUser: false)
                        }

                        if streamResponse.done == true {
                            print("LLM stream finished (done: true received).")
                            return
                        }

                    } catch {
                        print("Error decoding JSON line: \(error.localizedDescription)")
                    }
                }
            }
            print("LLM stream finished (no more bytes).")

        } catch is CancellationError {
            print("LLM stream was cancelled.")
            await appendMessage(" (Generation Cancelled)\n", isUser: false, isError: true)
        } catch {
            print("Error during LLM streaming: \(error.localizedDescription)")
            await appendMessage(" (Error: \(error.localizedDescription))\n", isUser: false, isError: true)
        }
    }

    // MARK: - Helper Methods

    @MainActor
    private func appendMessage(_ text: String, isUser: Bool, isError: Bool = false) {
        let attributedString = NSMutableAttributedString(string: text)
        let range = NSRange(location: 0, length: attributedString.length)

        if isUser {
            attributedString.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 16), range: range)
            attributedString.addAttribute(.foregroundColor, value: UIColor.systemBlue, range: range)
        } else if isError {
            attributedString.addAttribute(.font, value: UIFont.italicSystemFont(ofSize: 16), range: range)
            attributedString.addAttribute(.foregroundColor, value: UIColor.systemRed, range: range)
        } else {
            attributedString.addAttribute(.font, value: UIFont.systemFont(ofSize: 16), range: range)
            attributedString.addAttribute(.foregroundColor, value: UIColor.label, range: range)
        }

        chatTextView.textStorage.append(attributedString)
        let bottom = NSRange(location: chatTextView.text.count - 1, length: 1)
        chatTextView.scrollRangeToVisible(bottom)
    }

    // MARK: - UITextFieldDelegate

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        sendButtonTapped()
        textField.resignFirstResponder() // Dismiss keyboard
        return true
    }
}
