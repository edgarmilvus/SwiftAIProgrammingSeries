
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift equivalent for dependencies.
// In a real project, AVFoundation is part of the system frameworks and doesn't need explicit SPM declaration.
// Observation is also part of SwiftUI starting iOS 17.
// For clarity, if we were using a third-party library, it would look like this:
/*
import PackageDescription

let package = Package(
    name: "RealtimeAudioAI",
    platforms: [.iOS(.v17)], // Or .v18 if using iOS 18 specific features
    products: [
        .library(
            name: "RealtimeAudioAI",
            targets: ["RealtimeAudioAI"]),
    ],
    dependencies: [
        // Example for a hypothetical external dependency, not needed here.
        // .package(url: "https://github.com/some/audio-processing-lib.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "RealtimeAudioAI",
            dependencies: []), // No external dependencies for this core example
        .testTarget(
            name: "RealtimeAudioAITests",
            dependencies: ["RealtimeAudioAI"]),
    ]
)
*/

import SwiftUI
import AVFoundation
import Observation // For @Observable (iOS 17+), part of SwiftUI framework

/// The `WaveformData` struct encapsulates the processed audio samples and peak amplitude
/// ready for visualization. This separation ensures the UI only deals with display-ready data,
/// not raw audio buffers.
struct WaveformData: Equatable {
    /// An array of normalized amplitude values representing the waveform.
    /// These are typically downsampled from the raw audio buffer for efficient drawing.
    var samples: [Float] = []
    
    /// The current peak amplitude detected in the most recent audio buffer.
    /// Useful for indicators like a "hot mic" or clipping warning.
    var peakAmplitude: Float = 0.0
    
    /// A timestamp when this data was generated, useful for debugging or time-sensitive animations.
    var timestamp: Date = Date()
}

/// `AudioProcessorError` defines specific errors that can occur during audio capture and processing.
/// This provides clear, actionable feedback for developers and users.
enum AudioProcessorError: Error, LocalizedError {
    case audioSessionSetupFailed(Error)
    case inputNodeMissing
    case audioEngineStartFailed(Error)
    case audioEngineStopFailed(Error)
    case microphonePermissionDenied
    
    var errorDescription: String? {
        switch self {
        case .audioSessionSetupFailed(let error):
            return "Failed to set up audio session: \(error.localizedDescription)"
        case .inputNodeMissing:
            return "Audio input node is missing."
        case .audioEngineStartFailed(let error):
            return "Failed to start audio engine: \(error.localizedDescription)"
        case .audioEngineStopFailed(let error):
            return "Failed to stop audio engine: \(error.localizedDescription)"
        case .microphonePermissionDenied:
            return "Microphone permission denied. Please enable it in Settings."
        }
    }
}

/// `AudioProcessor` is responsible for capturing real-time audio, processing it,
/// and providing downsampled waveform data. It leverages `AVAudioEngine` for robust
/// and low-latency audio input.
///
/// **Under the Hood:**
/// - `AVAudioEngine`: The core object for real-time audio processing graphs.
/// - `AVAudioInputNode`: Represents the microphone input.
/// - `installTap`: A crucial method that allows us to intercept audio buffers
///   from a specific node (here, the input node) for processing. The callback
///   is executed on a high-priority audio thread.
/// - `AVAudioPCMBuffer`: The container for raw audio samples.
/// - `frameLength`: The number of audio frames in the buffer.
/// - `floatChannelData`: Provides direct access to the raw PCM samples as `Float` values.
///
/// **Concurrency:** The `installTap` callback runs on a dedicated audio thread.
/// It's critical to avoid heavy, blocking operations here. Data destined for the UI
/// must be dispatched to the main actor.
@MainActor // Ensures all public methods are called on the main actor, simplifying UI integration.
class AudioProcessor: ObservableObject { // Using ObservableObject for broader compatibility, @Observable could be used for iOS 17+
    private let audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode?
    
    /// A closure that will be called with processed `WaveformData`.
    /// This allows the `ViewModel` to receive updates without tight coupling.
    var onWaveformDataUpdate: ((WaveformData) -> Void)?
    
    /// The buffer size for the audio tap. A smaller buffer means lower latency but
    /// more frequent callbacks. 1024 frames is a common compromise.
    private let bufferSize: AVAudioFrameCount = 1024
    
    /// The number of samples to keep for visualization. Downsampling is crucial
    /// for performance and smooth UI updates.
    private let visualizationSampleCount = 60
    
    /// Initializes the audio processor. Sets up the audio session and engine components.
    init() {
        setupAudioSession()
        setupAudioEngine()
    }
    
    /// Configures the shared `AVAudioSession` for recording.
    /// This must be done before starting the audio engine.
    private func setupAudioSession() {
        do {
            // 1. Set audio session category to record.
            try AVAudioSession.sharedInstance().setCategory(.record, mode: .measurement, options: .duckOthers)
            // 2. Activate the audio session.
            try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("Failed to set up audio session: \(error.localizedDescription)")
            // In a real app, you'd propagate this error to the UI.
        }
    }
    
    /// Configures the `AVAudioEngine` by attaching the input node and connecting it.
    private func setupAudioEngine() {
        inputNode = audioEngine.inputNode
        guard let inputNode = inputNode else {
            print("Error: Audio input node is nil.")
            return
        }
        
        // Connect the input node to the main mixer node.
        // This is necessary even if we only tap the input node.
        let format = inputNode.inputFormat(forBus: 0)
        audioEngine.attach(inputNode) // Input node is already attached via `audioEngine.inputNode`
        audioEngine.connect(inputNode, to: audioEngine.mainMixerNode, format: format)
    }
    
    /// Requests microphone permission and starts the audio engine.
    /// This method is `async` because `requestRecordPermission` is asynchronous.
    /// - Throws: `AudioProcessorError` if permission is denied or engine fails to start.
    func start() async throws {
        // 1. Request microphone permission if not already granted.
        let granted = await AVAudioSession.sharedInstance().requestRecordPermission()
        guard granted else {
            throw AudioProcessorError.microphonePermissionDenied
        }
        
        guard let inputNode = inputNode else {
            throw AudioProcessorError.inputNodeMissing
        }
        
        // 2. Install a tap on the input node to capture audio buffers.
        // The tap is installed on bus 0 (the default input bus).
        // The bufferSize determines the chunk of audio received per callback.
        // The format specifies the desired audio format for the buffer.
        inputNode.installTap(onBus: 0, bufferSize: bufferSize, format: inputNode.inputFormat(forBus: 0)) { [weak self] buffer, time in
            // This closure runs on a high-priority audio thread.
            // Avoid heavy computations or UI updates directly here.
            self?.processAudioBuffer(buffer: buffer)
        }
        
        // 3. Start the audio engine.
        // This operation can fail, so it's wrapped in a do-catch block.
        do {
            try audioEngine.start()
            print("Audio engine started.")
        } catch {
            // Clean up the tap if engine fails to start.
            inputNode.removeTap(onBus: 0)
            throw AudioProcessorError.audioEngineStartFailed(error)
        }
    }
    
    /// Stops the audio engine and removes the tap.
    /// - Throws: `AudioProcessorError` if the engine fails to stop.
    func stop() throws {
        guard let inputNode = inputNode else {
            throw AudioProcessorError.inputNodeMissing
        }
        
        // 1. Remove the tap to stop receiving audio buffers.
        inputNode.removeTap(onBus: 0)
        
        // 2. Stop the audio engine.
        audioEngine.stop()
        print("Audio engine stopped.")
        
        // 3. Deactivate audio session to release resources.
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            throw AudioProcessorError.audioSessionSetupFailed(error) // Re-using error type for session deactivation.
        }
        
        // Clear waveform data when stopped.
        Task { @MainActor in
            onWaveformDataUpdate?(WaveformData(samples: [], peakAmplitude: 0.0))
        }
    }
    
    /// Processes the raw `AVAudioPCMBuffer` received from the audio tap.
    /// This method is called on an audio thread. It performs downsampling and
    /// amplitude calculation before dispatching the `WaveformData` to the main actor.
    /// - Parameter buffer: The `AVAudioPCMBuffer` containing raw audio samples.
    private func processAudioBuffer(buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData else { return }
        let samples = channelData[0] // Assuming mono audio or taking the first channel.
        let frameLength = Int(buffer.frameLength)
        
        var currentSamples: [Float] = []
        var maxAmplitude: Float = 0.0
        
        // 1. Downsample the audio buffer for visualization.
        // We take `visualizationSampleCount` samples from the buffer.
        // This is a simple peak-picking or average-picking downsampling.
        let step = max(1, frameLength / visualizationSampleCount)
        for i in stride(from: 0, to: frameLength, by: step) {
            let sample = abs(samples[i]) // Absolute value for amplitude.
            currentSamples.append(sample)
            if sample > maxAmplitude {
                maxAmplitude = sample
            }
        }
        
        // Ensure the sample array doesn't exceed the desired count.
        if currentSamples.count > visualizationSampleCount {
            currentSamples = Array(currentSamples.prefix(visualizationSampleCount))
        }
        
        // 2. Normalize the samples to a 0-1 range for easier drawing.
        // If maxAmplitude is 0, avoid division by zero.
        let normalizedMaxAmplitude = maxAmplitude > 0 ? maxAmplitude : 1.0
        let normalizedSamples = currentSamples.map { $0 / normalizedMaxAmplitude }
        
        // 3. Dispatch the processed data to the main actor for UI update.
        // This is crucial to avoid UI blocking and ensure thread safety.
        Task { @MainActor in
            self.onWaveformDataUpdate?(WaveformData(samples: normalizedSamples, peakAmplitude: maxAmplitude, timestamp: Date()))
        }
    }
}

/// `WaveformView` is a SwiftUI `Shape` that draws the audio waveform.
/// It's designed to be efficient by only redrawing when its `waveformData` changes.
struct WaveformView: View {
    let waveformData: WaveformData
    
    // Using a GeometryReader to get the available size for drawing.
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                guard !waveformData.samples.isEmpty else { return }
                
                let width = geometry.size.width
                let height = geometry.size.height
                let midY = height / 2
                
                // Calculate the horizontal spacing between samples.
                let xIncrement = width / CGFloat(waveformData.samples.count - 1)
                
                // Move to the starting point of the waveform.
                // The waveform is drawn symmetrically around the midY.
                path.move(to: CGPoint(x: 0, y: midY))
                
                // 1. Draw the top half of the waveform.
                for (index, sample) in waveformData.samples.enumerated() {
                    let x = CGFloat(index) * xIncrement
                    // Scale the sample (0-1) to the actual view height.
                    let y = midY - (CGFloat(sample) * midY)
                    path.addLine(to: CGPoint(x: x, y: y))
                }
                
                // 2. Draw the bottom half (mirror image) to complete the shape.
                // Go back to the end of the top half.
                path.addLine(to: CGPoint(x: width, y: midY)) // Connect back to the middle line at the end
                
                // Iterate in reverse for the bottom half to create a closed shape.
                for (index, sample) in waveformData.samples.enumerated().reversed() {
                    let x = CGFloat(index) * xIncrement
                    let y = midY + (CGFloat(sample) * midY)
                    path.addLine(to: CGPoint(x: x, y: y))
                }
                
                // Close the path back to the starting point.
                path.closeSubpath()
            }
            .fill(
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.blue.opacity(0.6),
                        Color.purple.opacity(0.6)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .stroke(
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.blue,
                        Color.purple
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                ),
                lineWidth: 2
            )
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Audio Waveform")
        .accessibilityValue("Current peak amplitude: \(waveformData.peakAmplitude, format: .percent)")
    }
}

/// `VoiceAssistantViewModel` acts as the bridge between the `AudioProcessor`
/// and the SwiftUI `ContentView`. It manages the state, handles audio events,
/// and provides data to the UI.
///
/// **Production Patterns:**
/// - `@Observable`: Modern way to manage observable state in SwiftUI (iOS 17+).
/// - `Task` and `async/await`: For managing asynchronous operations like starting/stopping audio.
/// - Error Handling: Catches errors from `AudioProcessor` and presents them to the user.
/// - Simulated AI: Includes a placeholder for real-time AI inference (e.g., wake word detection).
/// - `debounceTask`: A common pattern to prevent excessive calls to a function (e.g., AI inference)
///   when data streams rapidly.
@Observable
final class VoiceAssistantViewModel {
    private let audioProcessor: AudioProcessor
    
    /// The current waveform data to be displayed by `WaveformView`.
    var waveformData: WaveformData = WaveformData()
    
    /// Indicates whether the audio input is currently active.
    var isListening: Bool = false
    
    /// Stores any error that occurred, to be displayed to the user.
    var errorMessage: String?
    
    /// Controls the visibility of the error alert.
    var showingErrorAlert: Bool = false
    
    /// A simulated "wake word" detection state.
    var wakeWordDetected: Bool = false
    
    /// A task to debounce AI processing. This prevents the simulated AI from being
    /// triggered on every single audio buffer, which would be inefficient.
    private var debounceTask: Task<Void, Never>?
    
    init() {
        self.audioProcessor = AudioProcessor()
        // Set up the callback from the AudioProcessor to update the ViewModel.
        self.audioProcessor.onWaveformDataUpdate = { [weak self] newWaveformData in
            guard let self = self else { return }
            self.waveformData = newWaveformData
            
            // Simulate real-time AI processing.
            // This is debounced to avoid triggering too often.
            self.debounceTask?.cancel() // Cancel previous debounce task
            self.debounceTask = Task {
                try? await Task.sleep(nanoseconds: 500_000_000) // Debounce for 0.5 seconds
                guard !Task.isCancelled else { return }
                self.simulateRealtimeAI(peakAmplitude: newWaveformData.peakAmplitude)
            }
        }
    }
    
    /// Starts the real-time audio capture and processing.
    /// Uses `async/await` for permission requests and engine start.
    func startListening() {
        guard !isListening else { return }
        errorMessage = nil
        showingErrorAlert = false
        
        Task {
            do {
                try await audioProcessor.start()
                isListening = true
                print("ViewModel: Started listening.")
            } catch {
                if let audioError = error as? AudioProcessorError {
                    errorMessage = audioError.localizedDescription
                } else {
                    errorMessage = "An unknown error occurred: \(error.localizedDescription)"
                }
                showingErrorAlert = true
                isListening = false
                print("ViewModel: Error starting listening: \(error.localizedDescription)")
            }
        }
    }
    
    /// Stops the real-time audio capture.
    func stopListening() {
        guard isListening else { return }
        
        do {
            try audioProcessor.stop()
            isListening = false
            wakeWordDetected = false // Reset wake word state
            debounceTask?.cancel() // Cancel any pending AI tasks
            print("ViewModel: Stopped listening.")
        } catch {
            if let audioError = error as? AudioProcessorError {
                errorMessage = audioError.localizedDescription
            } else {
                errorMessage = "An unknown error occurred while stopping: \(error.localizedDescription)"
            }
            showingErrorAlert = true
            print("ViewModel: Error stopping listening: \(error.localizedDescription)")
        }
    }
    
    /// A placeholder for real-time AI inference.
    /// In a real application, this would involve passing audio features to a Core ML model
    /// or a custom inference engine.
    /// - Parameter peakAmplitude: The current peak amplitude, used here as a simple feature.
    private func simulateRealtimeAI(peakAmplitude: Float) {
        // For demonstration, let's say a "wake word" is detected if the amplitude
        // is consistently high for a short period.
        let wakeWordThreshold: Float = 0.5 // Normalized amplitude
        
        if peakAmplitude > wakeWordThreshold {
            if !wakeWordDetected {
                print("Simulated AI: Wake word detected! Peak: \(peakAmplitude)")
                wakeWordDetected = true
                // In a real app, you'd trigger a follow-up action here,
                // like starting a transcription session or responding to a command.
            }
        } else {
            if wakeWordDetected {
                print("Simulated AI: Wake word no longer active. Peak: \(peakAmplitude)")
                wakeWordDetected = false
            }
        }
    }
}

/// The main `ContentView` for the voice assistant application.
/// It integrates the `VoiceAssistantViewModel` and `WaveformView` to create
/// a reactive user interface.
struct ContentView: View {
    // For iOS 17+, @State var viewModel = VoiceAssistantViewModel() is preferred.
    // @StateObject is used here for broader compatibility (iOS 14+), ensuring the ViewModel's
    // lifecycle is managed correctly across view updates.
    @StateObject private var viewModel = VoiceAssistantViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Real-Time Audio AI Assistant")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Spacer()
            
            // 1. Waveform Visualization
            WaveformView(waveformData: viewModel.waveformData)
                .frame(height: 150)
                .padding(.horizontal)
                .background(Color.black.opacity(0.1))
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(viewModel.isListening ? Color.blue : Color.gray, lineWidth: 2)
                )
            
            // 2. AI Status Indicator
            HStack {
                Image(systemName: viewModel.wakeWordDetected ? "mic.fill" : "mic")
                    .font(.title)
                    .foregroundColor(viewModel.wakeWordDetected ? .red : .primary)
                Text(viewModel.wakeWordDetected ? "Wake Word Detected!" : "Listening...")
                    .font(.headline)
                    .foregroundColor(viewModel.wakeWordDetected ? .red : .primary)
            }
            .opacity(viewModel.isListening ? 1 : 0)
            .animation(.easeInOut, value: viewModel.isListening)
            .animation(.spring, value: viewModel.wakeWordDetected)
            
            // 3. Peak Amplitude Indicator
            HStack {
                Text("Peak: \(viewModel.waveformData.peakAmplitude, format: .percent)")
                    .font(.caption)
                    .foregroundColor(viewModel.waveformData.peakAmplitude > 0.8 ? .red : .secondary)
                ProgressView(value: viewModel.waveformData.peakAmplitude)
                    .progressViewStyle(.linear)
                    .tint(viewModel.waveformData.peakAmplitude > 0.8 ? .red : .blue)
            }
            .frame(width: 200)
            .opacity(viewModel.isListening ? 1 : 0)
            .animation(.easeInOut, value: viewModel.isListening)
            
            Spacer()
            
            // 4. Start/Stop Button
            Button {
                if viewModel.isListening {
                    viewModel.stopListening()
                } else {
                    viewModel.startListening()
                }
            } label: {
                Label(viewModel.isListening ? "Stop Listening" : "Start Listening",
                      systemImage: viewModel.isListening ? "stop.circle.fill" : "play.circle.fill")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(viewModel.isListening ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding(.horizontal)
            .buttonStyle(.plain) // Use plain style to allow custom button appearance
        }
        .padding()
        .alert("Error", isPresented: $viewModel.showingErrorAlert) {
            Button("OK") { viewModel.showingErrorAlert = false }
        } message: {
            Text(viewModel.errorMessage ?? "An unknown error occurred.")
        }
        .onAppear {
            // Request microphone permission on appear if not already done,
            // though `startListening` also handles it.
            // This is more for initial setup clarity.
            Task {
                _ = await AVAudioSession.sharedInstance().requestRecordPermission()
            }
        }
    }
}

// MARK: - App Entry Point (for Xcode Previews and actual app)
@main
struct RealtimeAudioAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
