
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CloudKit
import Observation

@available(iOS 18.0, *)
@Observable
class SyncMonitor {
    enum SyncStatus: Equatable {
        case synced
        case syncing
        case error(message: String, canRetry: Bool)
        case iCloudAccountRequired
    }
    
    var currentStatus: SyncStatus = .synced
    
    /// Maps a CloudKit error to a user-friendly SyncStatus.
    func handleCloudKitError(_ error: Error) {
        guard let ckError = error as? CKError else {
            currentStatus = .error(message: "An unknown error occurred.", canRetry: true)
            return
        }
        
        switch ckError.code {
        case .notAuthenticated:
            currentStatus = .iCloudAccountRequired
            
        case .quotaExceeded:
            currentStatus = .error(message: "Your iCloud storage is full. Please free up space to sync.", canRetry: false)
            
        case .networkUnavailable, .networkFailure:
            currentStatus = .error(message: "Connection lost. We'll try again when you're back online.", canRetry: true)
            
        case .serviceUnavailable, .requestRateLimited:
            // Handle the critical 'retryAfterSeconds' property
            let retryDelay = ckError.userInfo[CKErrorRetryAfterKey] as? Double ?? 3.0
            currentStatus = .error(message: "Server is busy. Retrying in \(Int(retryDelay))s...", canRetry: true)
            scheduleRetry(after: retryDelay)
            
        case .zoneNotFound:
            currentStatus = .error(message: "Sync configuration error. A local reset may be required.", canRetry: false)
            
        default:
            currentStatus = .error(message: "Sync encountered an issue. Please try again later.", canRetry: true)
        }
    }
    
    private func scheduleRetry(after delay: Double) {
        Task {
            try? await Task.sleep(for: .seconds(delay))
            // In a real app, this would trigger the CloudKitManager to attempt a re-sync
            print("Attempting automated retry...")
        }
    }
    
    func markSyncing() {
        currentStatus = .syncing
    }
    
    func markSynced() {
        currentStatus = .synced
    }
}
