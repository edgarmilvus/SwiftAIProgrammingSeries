
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor CameraProcessingActor {
    private var latestDetection: String?
    private var frameCount: Int = 0

    // This property could be observed by a UI component
    var currentDetection: String? { latestDetection }
    var currentFrameCount: Int { frameCount }

    func processFrame(_ pixelBuffer: CVPixelBuffer, coreMLRequest: VNCoreMLRequest) async throws -> [VNClassificationObservation]? {
        frameCount += 1 // Safely update internal state
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        return try await withCheckedThrowingContinuation { continuation in
            coreMLRequest.completionHandler = { req, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                let observations = req.results as? [VNClassificationObservation]
                // Safely update actor's state after processing
                self.latestDetection = observations?.first?.identifier
                continuation.resume(returning: observations)
            }
            
            do {
                try handler.perform([coreMLRequest])
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

// Inside the AVCaptureVideoDataOutputSampleBufferDelegate:
@available(iOS 18.0, *)
class CameraDelegate: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    let processingActor = CameraProcessingActor()
    // ... setup coreMLRequest ...

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        // Offload processing to the actor
        Task {
            do {
                let observations = try await processingActor.processFrame(pixelBuffer, coreMLRequest: self.coreMLRequest!)
                // Use observations or let the actor manage its internal state
            } catch {
                print("Actor processing failed: \(error)")
            }
        }
    }
}
