
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXOptimizers

// This annotation ensures the code is only available on platforms supporting the required APIs.
// MLX itself is cross-platform, but for a real-world app context, it's good practice.
@available(iOS 17.0, macOS 14.0, *)
class MLXSensorCalibrator {

    /// A simple linear model for sensor calibration: y = mx + b
    /// Inheriting from `MLXNN.Module` allows MLX to automatically track trainable parameters
    /// (like `weight` and `bias`) and provides a structured way to define the forward pass.
    class LinearModel: MLXNN.Module {
        // MARK: - Parameters

        /// The learnable weight (slope) of the linear model.
        /// Initialized randomly to break symmetry and allow learning.
        /// `MLXArray` is the fundamental tensor type in MLX.
        /// It benefits from Apple's Unified Memory architecture, meaning data
        /// often doesn't need to be copied between CPU and GPU, reducing overhead.
        @MLXNN.Parameter var weight: MLXArray

        /// The learnable bias (y-intercept) of the linear model.
        /// Initialized to zero.
        @MLXNN.Parameter var bias: MLXArray

        // MARK: - Initialization

        /// Initializes the LinearModel with specified input and output feature dimensions.
        /// - Parameters:
        ///   - inputFeatures: The number of input features (e.g., 1 for a single sensor reading).
        ///   - outputFeatures: The number of output features (e.g., 1 for a single calibrated value).
        init(inputFeatures: Int, outputFeatures: Int) {
            // Initialize weight with random values from a normal distribution.
            // This is crucial for neural networks to start learning effectively.
            self._weight = MLXNN.Parameter(MLXArray.randomn([outputFeatures, inputFeatures]))
            // Initialize bias with zeros.
            self._bias = MLXNN.Parameter(MLXArray.zeros([outputFeatures]))
            super.init() // Call the superclass initializer
        }

        // MARK: - Forward Pass

        /// Defines the forward computation of the model.
        /// When you call `model(input)`, this method is executed.
        /// - Parameter x: The input `MLXArray` (e.g., raw sensor readings).
        /// - Returns: The predicted output `MLXArray` (e.g., calibrated sensor readings).
        override func callAsFunction(_ x: MLXArray) -> MLXArray {
            // Matrix multiplication of input `x` with `weight`, then add `bias`.
            // MLX operations are lazily evaluated, meaning the computation graph is built,
            // but actual computation only happens when `eval()` is called or results are accessed.
            return MLX.matmul(x, weight.T) + bias
        }
    }

    /// Calculates the Mean Squared Error (MSE) loss between predictions and true values.
    /// MSE is a common loss function for regression tasks, measuring the average squared difference.
    /// - Parameters:
    ///   - predictions: The model's output `MLXArray`.
    ///   - targets: The true values `MLXArray`.
    /// - Returns: An `MLXArray` containing the scalar loss value.
    func mseLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        let difference = predictions - targets
        let squaredDifference = MLX.square(difference)
        return MLX.mean(squaredDifference)
    }

    /// Runs the sensor calibration training process.
    func calibrateSensor() {
        print("Starting MLX Sensor Calibration Example...")

        // 1. Model and Optimizer Initialization
        // ------------------------------------
        // We're simulating a sensor that takes one input and produces one output.
        let model = LinearModel(inputFeatures: 1, outputFeatures: 1)

        // The SGD (Stochastic Gradient Descent) optimizer is a classic choice.
        // It adjusts model parameters in the direction opposite to the gradient of the loss.
        // The `learningRate` controls the step size of these adjustments.
        let optimizer = MLXOptimizers.SGD(learningRate: 0.01)

        print("Initial Model Parameters:")
        print("  Weight: \(model.weight.item(Float.self))")
        print("  Bias: \(model.bias.item(Float.self))")

        // 2. Generate Synthetic Training Data
        // ----------------------------------
        // For a real app, this would come from actual sensor readings.
        // We'll create a simple linear relationship with some noise: y = 2x + 5 + noise
        let numSamples = 100
        let trueWeight: Float = 2.0
        let trueBias: Float = 5.0

        // `MLXArray` can be created from Swift arrays.
        // `reshape` is used to ensure the input has the correct shape for matrix multiplication.
        // (num_samples, input_features) -> (100, 1)
        let x_train = MLXArray(
            (0..<numSamples).map { Float($0) / Float(numSamples) * 10.0 },
            type: .float32
        ).reshaped([numSamples, 1])

        // Add some random noise to make the learning task more realistic.
        let noise = MLXArray.randomn(x_train.shape) * 0.5
        let y_train = (x_train * trueWeight) + trueBias + noise

        print("Generated \(numSamples) synthetic data points.")

        // 3. Define the Training Step Function
        // ------------------------------------
        // This closure encapsulates the forward pass and loss calculation.
        // `valueAndGradient` expects a function that takes the model's parameters
        // (or the model itself if it's an `MLXNN.Module`) and returns the loss.
        let trainStep = { (model: LinearModel, x: MLXArray, y: MLXArray) -> MLXArray in
            let predictions = model(x) // Forward pass
            return self.mseLoss(predictions: predictions, targets: y) // Calculate loss
        }

        // 4. The Optimization Loop
        // ------------------------
        let numEpochs = 500
        print("Starting training for \(numEpochs) epochs...")

        for epoch in 1...numEpochs {
            // `valueAndGradient` is a core MLX functional transformation.
            // It takes a function (our `trainStep`) and computes both its return value (the loss)
            // and the gradients of that value with respect to the *trainable parameters* of the model.
            // MLX builds a computation graph during the forward pass and then efficiently
            // traverses it backwards to compute gradients.
            let (loss, gradients) = MLX.valueAndGradient(trainStep)(model, x_train, y_train)

            // Apply the computed gradients to update the model's parameters.
            // `optimizer.update` takes the current parameters and the gradients,
            // and returns a new set of parameters (or updates in-place depending on the optimizer).
            // For MLXNN.Module, `model.update(parameters: newParameters)` applies the changes.
            optimizer.update(parameters: model.parameters(), gradients: gradients)
            model.update(parameters: optimizer.parameters())

            // Force evaluation of the loss for printing.
            // MLX uses lazy evaluation; operations are only computed when their results are needed,
            // for example, when converting to a Swift type (`item(Float.self)`) or calling `eval()`.
            if epoch % 50 == 0 {
                print("Epoch \(epoch): Loss = \(loss.item(Float.self))")
            }
        }

        print("\nTraining complete!")
        print("Final Model Parameters:")
        print("  Weight: \(model.weight.item(Float.self)) (True: \(trueWeight))")
        print("  Bias: \(model.bias.item(Float.self)) (True: \(trueBias))")

        // Example prediction with the trained model
        let testInput = MLXArray([7.5], type: .float32).reshaped([1, 1])
        let predictedOutput = model(testInput).item(Float.self)
        let trueOutput = trueWeight * 7.5 + trueBias
        print("Test Input (7.5): Predicted Output = \(predictedOutput), True Output = \(trueOutput)")
    }
}

// To run this in a Playground or an app:
// Ensure you have the MLX Swift package added.
//
// let calibrator = MLXSensorCalibrator()
// calibrator.calibrateSensor()
