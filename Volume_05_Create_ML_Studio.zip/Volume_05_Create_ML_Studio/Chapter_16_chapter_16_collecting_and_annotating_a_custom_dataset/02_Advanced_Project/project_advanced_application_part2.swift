
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import UIKit // For UIImage and Core Image integration
import CoreImage // For advanced image processing filters
import Combine // Included for completeness; async/await is primary for concurrency here.

// MARK: - 1. Error Handling for Dataset Operations

/// Custom error types for document processing and annotation.
/// This enum provides specific, localized error descriptions, making debugging and user feedback clearer.
enum DocumentAnnotationError: Error, LocalizedError {
    case invalidImage
    case imageProcessingFailed(Error)
    case fileSystemError(Error)
    case annotationCancelled
    case directoryCreationFailed(URL)
    case imageSavingFailed(URL)
    case metadataSavingFailed(URL)
    case noDocumentsFoundForExport
    case zipCreationFailed(Error)
    case documentNotFound(UUID)

    /// Provides a user-friendly description for each error case.
    var errorDescription: String? {
        switch self {
        case .invalidImage:
            return "The provided image data is invalid or could not be processed."
        case .imageProcessingFailed(let error):
            return "Image quality assessment or processing failed: \(error.localizedDescription)"
        case .fileSystemError(let error):
            return "A file system operation failed: \(error.localizedDescription)"
        case .annotationCancelled:
            return "Document annotation was cancelled by the user."
        case .directoryCreationFailed(let url):
            return "Failed to create necessary directory at \(url.lastPathComponent)."
        case .imageSavingFailed(let url):
            return "Failed to save image to \(url.lastPathComponent)."
        case .metadataSavingFailed(let url):
            return "Failed to save metadata to \(url.lastPathComponent)."
        case .noDocumentsFoundForExport:
            return "No new annotated documents found for export."
        case .zipCreationFailed(let error):
            return "Failed to create zip archive for export: \(error.localizedDescription)"
        case .documentNotFound(let id):
            return "Document with ID \(id) not found."
        }
    }
}

// MARK: - 2. Data Model: AnnotatedDocument

/// Represents a single document entry in our custom dataset.
/// This struct is `Codable` to facilitate easy serialization to JSON for metadata storage.
/// It includes essential information for dataset management and Create ML training.
struct AnnotatedDocument: Codable, Identifiable, Hashable {
    let id: UUID // A unique identifier for the document, crucial for file naming and tracking.
    let originalFilename: String? // The original filename, useful for debugging or provenance.
    var annotationLabel: String // The category assigned by the user (e.g., "Receipt", "Invoice"). This is the 'label' for Create ML.
    let imageRelativePath: String // Relative path to the stored image file within the data directory.
    let timestamp: Date // The date and time when the document was annotated.
    let qualityScore: Double? // An optional score indicating image quality (e.g., blurriness, brightness). Useful for filtering.
    var isExported: Bool // A flag to track if this document has been included in an export batch.

    // MARK: - Coding Keys
    // Custom coding keys improve the readability and consistency of the JSON output,
    // especially when interacting with external systems or APIs.
    enum CodingKeys: String, CodingKey {
        case id
        case originalFilename = "original_filename"
        case annotationLabel = "annotation_label"
        case imageRelativePath = "image_relative_path"
        case timestamp
        case qualityScore = "quality_score"
        case isExported = "is_exported"
    }

    /// Initializes a new `AnnotatedDocument` instance.
    /// - Parameters:
    ///   - id: A unique identifier for the document. Defaults to a new UUID.
    ///   - originalFilename: The original filename, if any.
    ///   - annotationLabel: The label assigned to the document.
    ///   - imageRelativePath: The path to the image file relative to the base data directory.
    ///   - timestamp: The date and time of annotation. Defaults to the current date.
    ///   - qualityScore: An optional score representing the image quality.
    ///   - isExported: A boolean indicating if the document has been exported. Defaults to `false`.
    init(id: UUID = UUID(), originalFilename: String?, annotationLabel: String, imageRelativePath: String, timestamp: Date = Date(), qualityScore: Double? = nil, isExported: Bool = false) {
        self.id = id
        self.originalFilename = originalFilename
        self.annotationLabel = annotationLabel
        self.imageRelativePath = imageRelativePath
        self.timestamp = timestamp
        self.qualityScore = qualityScore
        self.isExported = isExported
    }
}

// MARK: - 3. Image Quality Assessment Utility

/// A utility class for programmatically assessing image quality using Core Image filters.
/// This is an "advanced application" aspect, as it allows for automated pre-filtering of data,
/// reducing the need for manual review of low-quality samples and improving dataset integrity.
class ImageQualityAssessor {
    private let ciContext = CIContext(options: nil) // Re-use CIContext for performance.

    /// Assesses the blurriness of a `UIImage` using the Laplacian operator.
    /// A sharper image will have more distinct edges, leading to higher pixel values after applying the Laplacian filter.
    /// The average pixel value of the filtered image is used as a blurriness metric.
    /// - Parameter image: The `UIImage` to assess.
    /// - Returns: A `Double` representing the blurriness score (higher values generally mean less blur).
    ///            Returns `nil` if the image cannot be processed into a `CIImage`.
    func assessBlurriness(of image: UIImage) -> Double? {
        guard let ciImage = CIImage(image: image) else { return nil }

        // 1. Apply CILaplacian filter to detect edges.
        // CILaplacian computes the second spatial derivative of the image intensity.
        // Areas with rapid intensity changes (edges) will have high Laplacian values.
        guard let laplacianFilter = CIFilter(name: "CILaplacian") else { return nil }
        laplacianFilter.setValue(ciImage, forKey: kCIInputImageKey)

        guard let outputImage = laplacianFilter.outputImage else { return nil }

        // 2. Compute the average pixel value of the output image.
        // A higher average value indicates more prominent edges, thus less blur.
        let extent = outputImage.extent

        // CIAreaAverage calculates the average color for a specified region.
        // We use it to get a single average value across the entire filtered image.
        guard let averageFilter = CIFilter(name: "CIAreaAverage") else { return nil }
        averageFilter.setValue(outputImage, forKey: kCIInputImageKey)
        averageFilter.setValue(CIVector(cgRect: extent), forKey: kCIInputExtentKey)

        guard let averageOutput = averageFilter.outputImage else { return nil }

        var bitmap = [UInt8](repeating: 0, count: 4) // Buffer for RGBA pixel data
        // Render the single-pixel average output to our bitmap buffer.
        ciContext.render(averageOutput, toBitmap: &bitmap, rowBytes: 4, bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: .RGBA8, colorSpace: nil)

        // The blurriness score is derived from the average intensity.
        // We sum the R, G, B components and normalize. Higher values mean sharper.
        let averageIntensity = Double(bitmap[0] + bitmap[1] + bitmap[2]) / 3.0
        return averageIntensity
    }

    /// Assesses the average brightness of a `UIImage`.
    /// This method converts the image to grayscale (implicitly by averaging RGB) and then calculates the average pixel intensity.
    /// - Parameter image: The `UIImage` to assess.
    /// - Returns: A `Double` representing the average brightness (0.0 for black to 1.0 for white).
    ///            Returns `nil` if the image cannot be processed into a `CIImage`.
    func assessBrightness(of image: UIImage) -> Double? {
        guard let ciImage = CIImage(image: image) else { return nil }

        let extent = ciImage.extent

        // Use CIAreaAverage to get the average color of the entire image.
        guard let averageFilter = CIFilter(name: "CIAreaAverage") else { return nil }
        averageFilter.setValue(ciImage, forKey: kCIInputImageKey)
        averageFilter.setValue(CIVector(cgRect: extent), forKey: kCIInputExtentKey)

        guard let outputImage = averageFilter.outputImage else { return nil }

        var bitmap = [UInt8](repeating: 0, count: 4) // Buffer for RGBA pixel data
        ciContext.render(outputImage, toBitmap: &bitmap, rowBytes: 4, bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: .RGBA8, colorSpace: nil)

        // Calculate average brightness from the RGB components, normalized to 0-1.
        let brightness = Double(bitmap[0] + bitmap[1] + bitmap[2]) / (3.0 * 255.0)
        return brightness
    }

    /// Determines if an image meets a minimum quality threshold based on blurriness and brightness.
    /// This function acts as a pre-filter, preventing low-quality images from entering the dataset.
    /// - Parameters:
    ///   - image: The `UIImage` to check.
    ///   - minBlurScore: Minimum acceptable blurriness score. Higher values mean sharper images. Default is 10.0.
    ///   - minBrightness: Minimum acceptable average brightness (0.0-1.0). Default is 0.1.
    ///   - maxBrightness: Maximum acceptable average brightness (0.0-1.0). Default is 0.9.
    /// - Returns: `true` if the image meets all quality criteria, `false` otherwise.
    func meetsQualityCriteria(image: UIImage, minBlurScore: Double = 10.0, minBrightness: Double = 0.1, maxBrightness: Double = 0.9) -> Bool {
        guard let blurScore = assessBlurriness(of: image),
              let brightness = assessBrightness(of: image) else {
            print("Warning: Could not fully assess quality for image. Assuming low quality.")
            return false // If assessment fails, err on the side of caution.
        }

        let isSharpEnough = blurScore >= minBlurScore
        let isBrightnessAcceptable = brightness >= minBrightness && brightness <= maxBrightness

        if !isSharpEnough {
            print("Image rejected: Too blurry (score: \(String(format: "%.2f", blurScore))) - Required: \(minBlurScore)")
        }
        if !isBrightnessAcceptable {
            print("Image rejected: Brightness out of range (score: \(String(format: "%.2f", brightness))) - Required: [\(minBrightness)-\(maxBrightness)]")
        }

        return isSharpEnough && isBrightnessAcceptable
    }
}

// MARK: - 4. Document Annotation Manager

/// `DocumentAnnotationManager` is the core class responsible for orchestrating the
/// collection, annotation, and structured storage of document images for a custom Create ML dataset.
/// It integrates file system management, image quality checks, and metadata persistence,
/// demonstrating a robust, production-quality approach to dataset creation.
@available(iOS 15.0, *) // Requires async/await, available from iOS 15.0
class DocumentAnnotationManager {
    // MARK: - Properties
    private let fileManager: FileManager
    private let dataDirectoryURL: URL // The base URL for storing all annotated data.
    private let qualityAssessor: ImageQualityAssessor
    // `annotatedDocuments` is an in-memory cache of all documents.
    // Access is managed on the MainActor to ensure thread safety, especially if bound to UI.
    @MainActor private var annotatedDocuments: [AnnotatedDocument] = []

    // MARK: - Configuration
    /// The predefined set of labels that users can assign to documents.
    /// These correspond to the classes a Create ML classifier will be trained on.
    let supportedAnnotationLabels: [String] = ["Receipt", "Invoice", "Contract", "Personal Note", "Other"]
    /// The JPEG compression quality for saving images (0.0 - 1.0).
    /// Higher quality means larger files, lower quality means smaller files but potential loss of detail.
    let imageCompressionQuality: CGFloat = 0.8

    // MARK: - Initialization
    /// Initializes the `DocumentAnnotationManager`.
    /// This setup involves determining the storage location and ensuring it exists,
    /// and then loading any previously annotated documents.
    /// - Parameters:
    ///   - fileManager: The `FileManager` instance to use. Defaults to `.default`.
    ///   - appSupportDirectoryName: The name of the subdirectory within the application's support directory
    ///                              where all annotated data will be stored.
    /// - Throws: `DocumentAnnotationError.directoryCreationFailed` if the data directory cannot be created.
    init(fileManager: FileManager = .default, appSupportDirectoryName: String = "AnnotatedDocumentData") throws {
        self.fileManager = fileManager
        self.qualityAssessor = ImageQualityAssessor()

        // 1. Locate the application's support directory.
        // This is the standard location for app-specific data files that are not directly
        // exposed to the user (unlike the `Documents` directory).
        guard let appSupportURL = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw DocumentAnnotationError.fileSystemError(NSError(domain: "DocumentAnnotationManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Application Support directory not found."]))
        }

        // 2. Construct the full path to our custom data directory.
        self.dataDirectoryURL = appSupportURL.appendingPathComponent(appSupportDirectoryName, isDirectory: true)

        // 3. Create the data directory if it doesn't exist.
        // `withIntermediateDirectories: true` ensures parent directories are also created if missing.
        do {
            try fileManager.createDirectory(at: dataDirectoryURL, withIntermediateDirectories: true, attributes: nil)
            print("Data directory created or already exists at: \(dataDirectoryURL.path)")
        } catch {
            throw DocumentAnnotationError.directoryCreationFailed(dataDirectoryURL)
        }

        // 4. Load existing annotated documents from storage asynchronously.
        // This ensures the UI remains responsive during startup.
        Task {
            await loadAnnotatedDocuments()
        }
    }

    // MARK: - Private Helper Methods (File System Paths)
    /// Constructs the file URL for storing metadata (`.json`) for a given document ID.
    /// - Parameter documentID: The unique identifier of the document.
    /// - Returns: The `URL` to the metadata file.
    private func metadataURL(for documentID: UUID) -> URL {
        return dataDirectoryURL
            .appendingPathComponent(documentID.uuidString)
            .appendingPathExtension("json")
    }

    /// Constructs the file URL for storing the image (`.jpeg`) for a given document ID.
    /// - Parameter documentID: The unique identifier of the document.
    /// - Returns: The `URL` to the image file.
    private func imageURL(for documentID: UUID) -> URL {
        return dataDirectoryURL
            .appendingPathComponent(documentID.uuidString)
            .appendingPathExtension("jpeg")
    }

    // MARK: - Public Methods: Dataset Management

    /// Loads all existing annotated documents from the file system into memory.
    /// This operation is performed asynchronously to avoid blocking the main thread.
    /// It uses `withTaskGroup` to concurrently decode multiple metadata files,
    /// improving performance for large datasets.
    func loadAnnotatedDocuments() async {
        print("Loading existing annotated documents...")
        var loadedDocs: [AnnotatedDocument] = []
        do {
            // 1. Enumerate all files in the data directory.
            let fileURLs = try fileManager.contentsOfDirectory(at: dataDirectoryURL, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)

            // 2. Filter for metadata files (.json).
            let metadataURLs = fileURLs.filter { $0.pathExtension == "json" }

            // 3. Asynchronously decode each metadata file using a task group.
            // This allows parallel processing of metadata files.
            await withTaskGroup(of: AnnotatedDocument?.self) { group in
                for url in metadataURLs {
                    group.addTask {
                        do {
                            let data = try Data(contentsOf: url)
                            let document = try JSONDecoder().decode(AnnotatedDocument.self, from: data)
                            return document
                        } catch {
                            print("Error decoding metadata from \(url.lastPathComponent): \(error.localizedDescription)")
                            return nil
                        }
                    }
                }
                // 4. Collect results from all tasks.
                for await document in group {
                    if let doc = document {
                        loadedDocs.append(doc)
                    }
                }
            }
            // 5. Update the in-memory cache on the MainActor for thread safety.
            await MainActor.run {
                self.annotatedDocuments = loadedDocs
                print("Loaded \(loadedDocs.count) annotated documents.")
            }
        } catch {
            print("Error loading annotated documents: \(error.localizedDescription)")
        }
    }

    /// Simulates a UI interaction to get an annotation label from the user.
    /// In a real application, this would involve presenting an `UIAlertController` or a custom UI view
    /// and using `await withCheckedContinuation` to bridge the callback-based UI interaction
    /// to the `async/await` world.
    /// - Returns: The selected annotation label as a `String`.
    /// - Throws: `DocumentAnnotationError.annotationCancelled` if the user cancels the interaction.
    private func promptForAnnotationLabel() async throws -> String {
        print("\n--- Annotation Required ---")
        print("Available labels: \(supportedAnnotationLabels.joined(separator: ", "))")
        print("Please choose a label for the document (e.g., 'Receipt'):")

        // For demonstration purposes, we simulate user input by picking a random label.
        // In a real app, this would be an actual user interaction.
        let chosenLabel = supportedAnnotationLabels.randomElement() ?? "Other"
        print("Simulating user choosing label: '\(chosenLabel)'")

        // Uncomment the line below to simulate a user cancelling the annotation process.
        // if Bool.random() { throw DocumentAnnotationError.annotationCancelled }

        return chosenLabel
    }

    /// Processes a raw `UIImage`, performs automated quality checks, prompts the user for annotation,
    /// and then saves the image and its associated metadata to the file system.
    /// This function encapsulates the advanced workflow for collecting and annotating data.
    /// - Parameters:
    ///   - image: The `UIImage` to process and annotate.
    ///   - originalFilename: The original filename of the image, if available (e.g., from `PHAsset`).
    /// - Returns: The `AnnotatedDocument` that was successfully created and stored.
    /// - Throws: `DocumentAnnotationError` if any step (validation, quality check, saving) fails.
    func processAndAnnotateDocument(image: UIImage, originalFilename: String? = nil) async throws -> AnnotatedDocument {
        let documentID = UUID() // Generate a unique identifier for this new document.

        // 1. Initial validation: Convert UIImage to JPEG data.
        // This also implicitly checks if the UIImage is valid and can be represented as JPEG.
        guard let imageData = image.jpegData(compressionQuality: imageCompressionQuality) else {
            throw DocumentAnnotationError.invalidImage
        }

        // 2. Perform automated image quality assessment.
        // This is a key "advanced" step. By filtering out blurry or poorly lit images early,
        // we ensure a higher quality dataset for Create ML training, reducing noise and improving model performance.
        let qualityScore = qualityAssessor.assessBlurriness(of: image) // Store blur score for metadata.
        if !qualityAssessor.meetsQualityCriteria(image: image) {
            print("Image did not meet quality criteria. Skipping annotation.")
            throw DocumentAnnotationError.imageProcessingFailed(
                NSError(domain: "DocumentAnnotationManager", code: 2, userInfo: [NSLocalizedDescriptionKey: "Image quality too low (blurry or poor brightness)."])
            )
        }
        print("Image passed quality check (Blur score: \(String(format: "%.2f", qualityScore ?? -1.0))).")

        // 3. Prompt the user for an annotation label.
        // This is the manual labeling step, critical for supervised learning.
        let annotationLabel = try await promptForAnnotationLabel()

        // 4. Define file paths for the image and its metadata.
        let imagePath = imageURL(for: documentID)
        let metadataPath = metadataURL(for: documentID)
        // The relative path is stored in metadata for portability and easier reconstruction.
        let imageRelativePath = dataDirectoryURL.lastPathComponent + "/" + documentID.uuidString + ".jpeg"

        // 5. Save the image data to the file system asynchronously.
        do {
            try imageData.write(to: imagePath)
            print("Image saved to: \(imagePath.lastPathComponent)")
        } catch {
            throw DocumentAnnotationError.imageSavingFailed(imagePath)
        }

        // 6. Create the `AnnotatedDocument` metadata object.
        let newDocument = AnnotatedDocument(
            id: documentID,
            originalFilename: originalFilename,
            annotationLabel: annotationLabel,
            imageRelativePath: imageRelativePath,
            timestamp: Date(),
            qualityScore: qualityScore
        )

        // 7. Save the metadata as a JSON file.
        // This ensures that the annotation label and other details are persistently linked to the image.
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted // Makes the JSON human-readable for inspection.
            let metadataData = try encoder.encode(newDocument)
            try metadataData.write(to: metadataPath)
            print("Metadata saved to: \(metadataPath.lastPathComponent)")
        } catch {
            // If metadata saving fails, clean up the already saved image to prevent orphaned files.
            try? fileManager.removeItem(at: imagePath)
            throw DocumentAnnotationError.metadataSavingFailed(metadataPath)
        }

        // 8. Add the newly created document to our in-memory cache.
        // This update happens on the MainActor for thread safety.
        await MainActor.run {
            self.annotatedDocuments.append(newDocument)
            print("Document '\(newDocument.id.uuidString.prefix(8))' annotated as '\(newDocument.annotationLabel)' and stored.")
        }

        return newDocument
    }

    /// Retrieves all currently stored `AnnotatedDocument` objects from the in-memory cache.
    /// Access is performed on the MainActor to ensure thread safety.
    /// - Returns: An array of `AnnotatedDocument` objects.
    func getAllAnnotatedDocuments() async -> [AnnotatedDocument] {
        await MainActor.run {
            self.annotatedDocuments
        }
    }

    /// Prepares all unexported annotated documents for export by zipping them into a single archive.
    /// This archive can then be easily uploaded to a server or shared for Create ML training.
    /// The structure inside the zip will be:
    /// `dataset.zip/`
    ///   `metadata.json` (containing an array of all AnnotatedDocument metadata)
    ///   `images/`
    ///     `{UUID}.jpeg`
    ///     `{UUID}.jpeg`
    /// - Returns: The `URL` of the created zip file.
    /// - Throws: `DocumentAnnotationError` if no documents are found or zipping fails.
    func exportAnnotatedDataset() async throws -> URL {
        // Filter for documents that have not yet been marked as exported.
        let documentsToExport = await annotatedDocuments.filter { !$0.isExported }

        guard !documentsToExport.isEmpty else {
            throw DocumentAnnotationError.noDocumentsFoundForExport
        }

        // Define temporary directories for staging the export files.
        let exportDirectory = fileManager.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let imagesExportDirectory = exportDirectory.appendingPathComponent("images", isDirectory: true)
        let zipFileURL = fileManager.temporaryDirectory.appendingPathComponent("annotated_dataset_\(UUID().uuidString).zip")

        do {
            // 1. Create temporary directories.
            try fileManager.createDirectory(at: exportDirectory, withIntermediateDirectories: true, attributes: nil)
            try fileManager.createDirectory(at: imagesExportDirectory, withIntermediateDirectories: true, attributes: nil)

            // 2. Create a single `metadata.json` file containing an array of all document metadata.
            // This aggregated metadata file is convenient for bulk processing by Create ML or a backend.
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let allMetadataData = try encoder.encode(documentsToExport)
            let metadataExportURL = exportDirectory.appendingPathComponent("metadata.json")
            try allMetadataData.write(to: metadataExportURL)
            print("Preparing \(documentsToExport.count) documents for export.")

            // 3. Copy image files to the temporary `images` export directory.
            // Each image is named by its UUID for consistency.
            for document in documentsToExport {
                let sourceImageURL = imageURL(for: document.id)
                let destinationImageURL = imagesExportDirectory.appendingPathComponent(document.id.uuidString).appendingPathExtension("jpeg")
                if fileManager.fileExists(atPath: sourceImageURL.path) {
                    try fileManager.copyItem(at: sourceImageURL, to: destinationImageURL)
                } else {
                    print("Warning: Image file not found for document ID: \(document.id). Skipping copy.")
                }
            }

            // 4. Zip the temporary export directory into a single archive.
            // NOTE: Swift's Foundation framework does not provide a native way to create ZIP archives directly.
            // In a real production app, you would integrate a third-party library (e.g., `Zip` from Swift Package Index)
            // or use `Process` to execute the system's `zip` command.
            // For this pedagogical example, we simulate the zip creation by creating a dummy file.
            print("Simulating zip creation for dataset at \(zipFileURL.path)")
            let dummyZipContent = "This is a placeholder for the zipped dataset. In a real app, libraries like 'Zip' (https://github.com/marmelroy/Zip) would create a proper archive."
            try dummyZipContent.data(using: .utf8)?.write(to: zipFileURL)

            // 5. Mark exported documents as `isExported = true` and persist this change.
            // This prevents them from being re-exported in subsequent calls unless explicitly reset.
            await MainActor.run {
                for i in 0..<self.annotatedDocuments.count {
                    if documentsToExport.contains(where: { $0.id == self.annotatedDocuments[i].id }) {
                        self.annotatedDocuments[i].isExported = true
                    }
                }
            }
            // Persist the updated `isExported` status back to individual metadata files.
            await persistAllDocumentMetadata()

            print("Dataset exported to: \(zipFileURL.lastPathComponent)")
            return zipFileURL
        } catch {
            // Clean up any temporary files if the export process fails.
            try? fileManager.removeItem(at: exportDirectory)
            try? fileManager.removeItem(at: zipFileURL)
            throw DocumentAnnotationError.zipCreationFailed(error)
        } finally {
            // In a real scenario with actual zipping, you'd typically remove the `exportDirectory` here
            // after the zip file has been successfully created.
            try? fileManager.removeItem(at: exportDirectory)
        }
    }

    /// Persists the current state (including `isExported` status) of all documents
    /// back to their respective metadata files on the file system.
    /// This ensures that changes made in memory are saved persistently.
    private func persistAllDocumentMetadata() async {
        let documents = await self.getAllAnnotatedDocuments() // Get current state of documents.
        await withTaskGroup(of: Void.self) { group in
            for document in documents {
                group.addTask {
                    do {
                        let encoder = JSONEncoder()
                        encoder.outputFormatting = .prettyPrinted
                        let metadataData = try encoder.encode(document)
                        let metadataPath = self.metadataURL(for: document.id)
                        try metadataData.write(to: metadataPath)
                    } catch {
                        print("Error persisting metadata for document \(document.id): \(error.localizedDescription)")
                    }
                }
            }
        }
        print("All document metadata persisted.")
    }

    /// Deletes a specific annotated document (its image and metadata file) from storage.
    /// - Parameter documentID: The `UUID` of the document to delete.
    /// - Throws: `DocumentAnnotationError.fileSystemError` if file deletion fails.
    func deleteDocument(id documentID: UUID) async throws {
        let imagePath = imageURL(for: documentID)
        let metadataPath = metadataURL(for: documentID)

        do {
            if fileManager.fileExists(atPath: imagePath.path) {
                try fileManager.removeItem(at: imagePath)
            }
            if fileManager.fileExists(atPath: metadataPath.path) {
                try fileManager.removeItem(at: metadataPath)
            } else {
                print("Warning: Metadata file not found for document ID \(documentID).")
            }
            // Remove from in-memory cache on MainActor.
            await MainActor.run {
                self.annotatedDocuments.removeAll { $0.id == documentID }
            }
            print("Document \(documentID.uuidString.prefix(8))... and its metadata deleted.")
        } catch {
            throw DocumentAnnotationError.fileSystemError(error)
        }
    }

    /// Clears all annotated documents and their associated files from storage.
    /// This effectively resets the entire dataset.
    /// - Throws: `DocumentAnnotationError.fileSystemError` if directory removal or recreation fails.
    func deleteAllDocuments() async throws {
        do {
            // Remove the entire data directory.
            if fileManager.fileExists(atPath: dataDirectoryURL.path) {
                try fileManager.removeItem(at: dataDirectoryURL)
            }
            // Recreate an empty data directory.
            try fileManager.createDirectory(at: dataDirectoryURL, withIntermediateDirectories: true, attributes: nil)
            // Clear the in-memory cache on MainActor.
            await MainActor.run {
                self.annotatedDocuments.removeAll()
            }
            print("All annotated documents and data cleared.")
        } catch {
            throw DocumentAnnotationError.fileSystemError(error)
        }
    }
}

// MARK: - 5. Real-World Application Context: Document Categorizer App

/// A `DocumentCategorizerApp` class that demonstrates how `DocumentAnnotationManager`
/// would be integrated into a typical iOS application flow. This acts as a conceptual
/// ViewModel or Controller for our example.
@available(iOS 15.0, *)
class DocumentCategorizerApp {
    let annotationManager: DocumentAnnotationManager

    /// Initializes the application context, setting up the `DocumentAnnotationManager`.
    init() {
        do {
            annotationManager = try DocumentAnnotationManager()
        } catch {
            // In a real app, this would be handled gracefully (e.g., show an error to the user),
            // but for a demonstration, a fatal error is acceptable.
            fatalError("Failed to initialize DocumentAnnotationManager: \(error.localizedDescription)")
        }
    }

    /// Simulates a user selecting an image (e.g., from the Photos library or camera).
    /// In a real app, this would be triggered by delegate methods from `UIImagePickerController`
    /// or `PHPickerViewController`.
    /// - Parameters:
    ///   - image: The `UIImage` provided by the user.
    ///   - originalFilename: The original filename, if available.
    func simulateImageSelection(image: UIImage, originalFilename: String? = nil) async {
        print("\n--- Simulating Image Selection ---")
        do {
            let annotatedDoc = try await annotationManager.processAndAnnotateDocument(image: image, originalFilename: originalFilename)
            print("Successfully annotated: \(annotatedDoc.id.uuidString.prefix(8))... as '\(annotatedDoc.annotationLabel)'")
        } catch {
            print("Failed to annotate document: \(error.localizedDescription)")
            if let docError = error as? DocumentAnnotationError {
                switch docError {
                case .imageProcessingFailed(let underlyingError):
                    print("Reason: Image quality issue. Underlying: \(underlyingError.localizedDescription)")
                case .annotationCancelled:
                    print("Reason: User cancelled annotation process.")
                default:
                    print("Reason: \(docError.errorDescription ?? "Unknown error")")
                }
            }
        }
        await printCurrentDatasetStatus() // Update status after each operation.
    }

    /// Simulates a user requesting to export the entire collected dataset.
    /// This would typically be a button tap in the app's UI.
    func simulateDatasetExport() async {
        print("\n--- Simulating Dataset Export ---")
        do {
            let zipURL = try await annotationManager.exportAnnotatedDataset()
            print("Dataset successfully exported to: \(zipURL.path)")
            // In a real app, you would typically present a `UIActivityViewController` here
            // to allow the user to share the zip file (e.g., AirDrop, Mail, Cloud Storage).
            // Example: `let activityVC = UIActivityViewController(activityItems: [zipURL], applicationActivities: nil)`
            // `present(activityVC, animated: true)`
        } catch {
            print("Failed to export dataset: \(error.localizedDescription)")
        }
        await printCurrentDatasetStatus() // Update status after export.
    }

    /// Prints the current status of all annotated documents, including their export status.
    func printCurrentDatasetStatus() async {
        let documents = await annotationManager.getAllAnnotatedDocuments()
        print("\n--- Current Dataset Status (\(documents.count) documents) ---")
        if documents.isEmpty {
            print("No documents annotated yet.")
        } else {
            for doc in documents {
                let status = doc.isExported ? "EXPORTED" : "PENDING"
                let quality = String(format: "%.2f", doc.qualityScore ?? 0.0)
                print("  - [\(status)] ID: \(doc.id.uuidString.prefix(8))... Label: '\(doc.annotationLabel)' Quality: \(quality)")
            }
        }
    }

    /// Simulates a user initiating a clear-all-data operation.
    func simulateClearAllData() async {
        print("\n--- Simulating Clear All Data ---")
        do {
            try await annotationManager.deleteAllDocuments()
            print("All data cleared successfully.")
        } catch {
            print("Failed to clear all data: \(error.localizedDescription)")
        }
        await printCurrentDatasetStatus() // Update status after clearing.
    }
}

// MARK: - 6. Utility: UIImage Extension for Dummy Image Creation

/// An extension to `UIImage` to easily create solid-color images for testing and demonstration.
extension UIImage {
    /// Creates a solid color `UIImage` of a specified size.
    /// - Parameters:
    ///   - color: The `UIColor` to fill the image with.
    ///   - size: The `CGSize` of the desired image.
    /// - Returns: A new `UIImage` instance, or `nil` if image creation fails.
    convenience init?(color: UIColor, size: CGSize) {
        let rect = CGRect(origin: .zero, size: size)
        UIGraphicsBeginImageContextWithOptions(size, false, 1.0) // Begin image context
        color.setFill() // Set the fill color
        UIRectFill(rect) // Fill the rectangle with the color
        let image = UIGraphicsGetImageFromCurrentImageContext() // Get the image from the context
        UIGraphicsEndImageContext() // End the image context
        guard let cgImage = image?.cgImage else { return nil }
        self.init(cgImage: cgImage) // Initialize UIImage with the CGImage
    }
}

// MARK: - 7. Main Execution Block (Entry Point)

/// The main entry point for our advanced document annotation application demonstration.
/// This `struct` uses `@main` to define the application's starting point,
/// executing a sequence of simulated user interactions to showcase the `DocumentAnnotationManager`.
@available(iOS 15.0, *)
@main
struct AdvancedAnnotationAppEntryPoint {
    static func main() async {
        let app = DocumentCategorizerApp()

        // Optional: Uncomment the line below to ensure a clean slate for each run.
        // This is useful for testing, but in a real app, you'd typically persist data across launches.
        // try? await app.annotationManager.deleteAllDocuments()

        await app.printCurrentDatasetStatus() // Initial status check.

        // --- Scenario 1: Annotate a few "good" images ---
        print("\n=== Scenario 1: Annotating Good Images ===")
        // Create dummy images that are likely to pass quality checks.
        let goodImage1 = UIImage(color: .systemGreen, size: CGSize(width: 800, height: 600))!
        await app.simulateImageSelection(image: goodImage1, originalFilename: "receipt_001.jpg")

        let goodImage2 = UIImage(color: .systemBlue, size: CGSize(width: 1200, height: 900))!
        await app.simulateImageSelection(image: goodImage2, originalFilename: "invoice_001.png")

        // --- Scenario 2: Try to annotate a "bad" image (e.g., blurry or too dark/bright) ---
        print("\n=== Scenario 2: Attempting to Annotate a Low-Quality Image ===")
        // A solid black image will have a very low blur score and low brightness,
        // triggering the quality assessment rejection.
        let lowQualityImage = UIImage(color: .black, size: CGSize(width: 100, height: 100))!
        await app.simulateImageSelection(image: lowQualityImage, originalFilename: "blurry_dark_doc.jpg")

        // --- Scenario 3: Export the collected dataset ---
        print("\n=== Scenario 3: Exporting the Collected Dataset ===")
        await app.simulateDatasetExport()

        // --- Scenario 4: Annotate more images after an export ---
        // These new images should be marked as "PENDING" for the next export.
        print("\n=== Scenario 4: Annotating More Images (after initial export) ===")
        let goodImage3 = UIImage(color: .systemYellow, size: CGSize(width: 1000, height: 750))!
        await app.simulateImageSelection(image: goodImage3, originalFilename: "contract_001_page1.jpg")

        // --- Scenario 5: Export again (should only export the newly added documents) ---
        print("\n=== Scenario 5: Exporting Dataset Again ===")
        await app.simulateDatasetExport()

        // --- Scenario 6: Demonstrate clearing all data ---
        print("\n=== Scenario 6: Clearing All Annotated Data ===")
        await app.simulateClearAllData()
    }
}
