
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import ARKit
import RealityKit
import SwiftUI

@MainActor
class MeshDebugManager: ObservableObject {
    let session = ARKitSession()
    let sceneReconstruction = SceneReconstructionProvider()
    
    @Published var isDebugModeEnabled = false
    private var meshEntities: [UUID: ModelEntity] = [:]

    func toggleDebugMode() {
        isDebugModeEnabled.toggle()
    }

    func startMonitoring(in content: RealityViewContent) async {
        do {
            try await session.run([sceneReconstruction])
            
            // Listen to the AsyncSequence of MeshAnchors
            for await anchor in sceneReconstruction.anchors {
                guard isDebugModeEnabled else { 
                    clearMeshes()
                    continue 
                }
                
                updateMesh(anchor: anchor, in: content)
            }
        } catch {
            print("Scene reconstruction failed: \(error)")
        }
    }

    private func updateMesh(anchor: MeshAnchor, in content: RealityViewContent) {
        // 1. Create a MeshResource from the anchor's geometry
        // In a production environment, you'd optimize this to avoid frame drops
        guard let meshResource = try? MeshResource.generate(from: anchor.geometry) else { return }
        
        // 2. Use an UnlitMaterial for a "holographic" wireframe look
        // UnlitMaterial ignores scene lighting, making it perfect for debug overlays
        var material = UnlitMaterial(color: .green.withAlphaComponent(0.5))
        material.blending = .transparent
        
        let entity = ModelEntity(mesh: meshResource, materials: [material])
        entity.transform = Transform(matrix: anchor.originFromAnchorTransform)

        // 3. Manage the lifecycle of mesh chunks
        // Remove old version of this specific mesh chunk if it exists
        if let oldEntity = meshEntities[anchor.id] {
            oldEntity.removeFromParent()
        }
        
        meshEntities[anchor.id] = entity
        content.add(entity)
    }

    private func clearMeshes() {
        for entity in meshEntities.values {
            entity.removeFromParent()
        }
        meshEntities.removeAll()
    }
}

struct MeshInspectorView: View {
    @StateObject private var debugManager = MeshDebugManager()

    var body: some View {
        RealityView { content in
            Task {
                await debugManager.startMonitoring(in: content)
            }
        }
        .overlay(alignment: .topTrailing) {
            Button("Toggle Mesh Debug") {
                debugManager.toggleDebugMode()
            }
            .padding()
            .buttonStyle(.borderedProminent)
        }
    }
}
