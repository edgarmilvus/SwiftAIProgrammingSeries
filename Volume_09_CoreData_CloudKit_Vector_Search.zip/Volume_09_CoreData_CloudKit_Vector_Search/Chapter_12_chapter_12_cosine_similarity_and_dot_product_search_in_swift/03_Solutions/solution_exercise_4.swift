
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Accelerate

@available(iOS 18.0, *)
struct Song: Identifiable, Sendable {
    let id: UUID
    let title: String
    let artist: String
    let sonicEmbedding: [Float]
}

enum VibeMatchError: Error {
    case invalidEmbedding
    case computationFailed
}

/// A simple Min-Heap to maintain the Top-K elements efficiently.
struct MinHeap<T> {
    private var elements: [T]
    private let priorityFunction: (T, T) -> Bool

    init(priorityFunction: @escaping (T, T) -> Bool) {
        self.elements = []
        self.priorityFunction = priorityFunction
    }

    var count: Int { elements.count }
    var min: T? { elements.first }

    mutating func insert(_ element: T) {
        elements.append(element)
        siftUp(elements.count - 1)
    }

    mutating func popMin() -> T? {
        guard !elements.isEmpty else { return nil }
        if elements.count == 1 { return elements.removeFirst() }
        let min = elements[0]
        elements[0] = elements.removeLast()
        siftDown(0)
        return min
    }

    private mutating func siftUp(_ index: Int) {
        var childIndex = index
        let child = elements[childIndex]
        var parentIndex = (childIndex - 1) / 2
        while childIndex > 0 && priorityFunction(child, elements[parentIndex]) {
            elements[childIndex] = elements[parentIndex]
            childIndex = parentIndex
            parentIndex = (childIndex - 1) / 2
        }
        elements[childIndex] = child
    }

    private mutating func siftDown(_ index: Int) {
        var parentIndex = index
        while true {
            let leftChildIndex = 2 * parentIndex + 1
            let rightChildIndex = 2 * parentIndex + 2
            var candidateIndex = parentIndex
            if leftChildIndex < elements.count && priorityFunction(elements[leftChildIndex], elements[candidateIndex]) {
                candidateIndex = leftChildIndex
            }
            if rightChildIndex < elements.count && priorityFunction(elements[rightChildIndex], elements[candidateIndex]) {
                candidateIndex = rightChildIndex
            }
            if candidateIndex == parentIndex { return }
            elements.swapAt(parentIndex, candidateIndex)
            parentIndex = candidateIndex
        }
    }
}

actor VibeMatchService {
    private var songLibrary: [Song] = [] // Assume this is populated

    func findVibeMatch(for currentSong: Song) async -> Result<[Song], VibeMatchError> {
        // Requirement: Use Task.detached for heavy computation to avoid blocking the actor
        return await Task.detached(priority: .userInitiated) {
            guard !currentSong.sonicEmbedding.isEmpty else {
                return .failure(.invalidEmbedding)
            }
            
            // Check for zero-magnitude (corrupted) embedding
            var sumSq: Float = 0
            vDSP_dotpr(currentSong.sonicEmbedding, 1, currentSong.sonicEmbedding, 1, &sumSq, vDSP_Length(currentSong.sonicEmbedding.count))
            if sumSq <= 0 { return .failure(.invalidEmbedding) }

            // Min-Heap to keep track of top 10 songs: O(N log K)
            // We want the SMALLEST similarity in the heap to be at the top, 
            // so we can easily replace it when we find a larger one.
            var topKHeap = MinHeap<(score: Float, song: Song)>(priorityFunction: { $0.score < $1.score })

            for song in self.songLibrary {
                let score = self.calculateCosine(currentSong.sonicEmbedding, song.sonicEmbedding)
                
                if topKHeap.count < 10 {
                    topKHeap.insert((score, song))
                } else if let minScore = topKHeap.min?.score, score > minScore {
                    _ = topKHeap.popMin()
                    topKHeap.insert((score, song))
                }
            }

            // Extract songs from heap and sort descending
            var results: [(score: Float, song: Song)] = []
            while let item = topKHeap.popMin() {
                results.append(item)
            }
            
            let sortedSongs = results.sorted { $0.score > $1.score }.map { $0.song }
            return .success(sortedSongs)
        }.value
    }

    private func calculateCosine(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        let n = vDSP_Length(a.count)
        var dot: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dot, n)
        var sA: Float = 0; var sB: Float = 0
        vDSP_dotpr(a, 1, a, 1, &sA, n)
        vDSP_dotpr(b, 1, b, 1, &sB, n)
        let mag = sqrt(sA) * sqrt(sB)
        return mag > 0 ? dot / mag : 0
    }
}
