
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
@Observable
@MainActor
class ChatViewModel {
    var accumulatedResponse: String = ""
    var isGenerating: Bool = false
    var errorMessage: String? = nil

    func startStreaming(with stream: AsyncThrowingStream<ChatCompletionChunk, Error>) async {
        // Prepare UI state
        isGenerating = true
        accumulatedResponse = ""
        errorMessage = nil
        
        do {
            // Iterate through the stream as it arrives
            for try await chunk in stream {
                // Extract the text delta
                if let content = chunk.choices.first?.delta.content {
                    // Since the class is @MainActor, this update is safe and direct
                    accumulatedResponse += content
                }
            }
        } catch is CancellationError {
            // Handle intentional cancellation without showing an error to the user
            print("Stream was cancelled by the user.")
        } catch {
            // Handle actual network or decoding errors
            errorMessage = "Failed to fetch response: \(error.localizedDescription)"
        }
        
        // Reset state once stream ends or fails
        isGenerating = false
    }
}

@available(iOS 18.0, *)
struct ChatView: View {
    @State private var viewModel = ChatViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            ScrollView {
                Text(viewModel.accumulatedResponse)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .background(Color.secondary.opacity(0.1))
            .cornerRadius(12)
            
            if viewModel.isGenerating {
                ProgressView("AI is thinking...")
            }
            
            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .font(.caption)
            }
        }
        .padding()
    }
}
