
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Vision
import RealityKit
import ARKit
import Observation

/// A thread-safe container for detection results, 
/// ensuring data can safely cross actor boundaries.
@Sendable
struct DetectedObjectState: Sendable {
    let id: UUID
    let label: String
    let confidence: Float
    let worldPosition: SIMD3<Float>
}

/// The 'Percussionist': An Actor responsible for heavy ML inference.
/// It lives off the MainActor to prevent frame drops.
actor ObjectDetectionEngine {
    private var detectionRequest: VNCoreMLRequest?
    
    init(model: MLModel) throws {
        // Initialize the Vision request with the provided Core ML model
        let visionModel = try VNCoreMLModel(for: model)
        self.detectionRequest = VNCoreMLRequest(model: visionModel)
    }
    
    /// Performs inference on a provided pixel buffer.
    /// - Parameter pixelBuffer: The raw image data from the camera.
    /// - Returns: An array of detected objects with their semantic data.
    func detect(in pixelBuffer: CVPixelBuffer) async throws -> [VNRecognizedObjectObservation] {
        guard let request = detectionRequest else {
            throw DetectionError.requestNotInitialized
        }
        
        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            
            do {
                try handler.perform([request])
                // Extract observations from the request
                let observations = request.results as? [VNRecognizedObjectObservation] ?? []
                continuation.resume(returning: observations)
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
    
    enum DetectionError: Error {
        case requestNotInitialized
    }
}

/// The 'Conductor/State': An Observable object that lives on the @MainActor.
/// It bridges the gap between the Detection Engine and the RealityKit View.
@Observable
@MainActor
class SpatialAwarenessManager {
    /// The current collection of detected objects projected into 3D space.
    var detectedEntities: [UUID: DetectedObjectState] = [:]
    
    private let engine: ObjectDetectionEngine
    
    init(engine: ObjectDetectionEngine) {
        self.engine = engine
    }
    
    /// The main loop entry point.
    /// This would be called by a RealityKit System or an ARFrame delegate.
    func processFrame(_ frame: ARFrame) async {
        let pixelBuffer = frame.capturedImage
        
        do {
            // 1. THINK: Offload to the Actor
            let observations = try await engine.detect(in: pixelBuffer)
            
            // 2. TRANSFORM: Convert 2D observations to 3D positions
            // This happens on the MainActor to allow interaction with ARFrame
            let newStates = try transformObservationsToWorldSpace(
                observations, 
                in: frame
            )
            
            // 3. ACT: Update the observable state
            // This triggers SwiftUI/RealityKit updates
            for state in newStates {
                self.detectedEntities[state.id] = state
            }
        } catch {
            print("Detection failed: \(error)")
        }
    }
    
    /// Performs the mathematical unprojection from 2D to 3D.
    private func transformObservationsToWorldSpace(
        _ observations: [VNRecognizedObjectObservation],
        in frame: ARFrame
    ) throws -> [DetectedObjectState] {
        var results: [DetectedObjectState] = []
        
        for observation in observations {
            // Use the center of the bounding box
            let boundingBox = observation.boundingBox
            let center = CGPoint(x: boundingBox.midX, y: boundingBox.midY)
            
            // Perform a raycast to find the 3D position
            // In a real implementation, we would use the camera intrinsics 
            // and the depth map for higher precision.
            let raycastResults = frame.raycast(from: center, allowing: .estimatedPlane, alignment: .any)
            
            if let firstResult = raycastResults.first {
                let worldTransform = firstResult.worldTransform
                let position = SIMD3<Float>(
                    worldTransform.columns.3.x,
                    worldTransform.columns.3.y,
                    worldTransform.columns.3.z
                )
                
                let label = observation.labels.first?.identifier ?? "Unknown"
                let confidence = observation.confidence
                
                results.append(DetectedObjectState(
                    id: UUID(), // In a real app, use a persistent ID from the model
                    label: label,
                    confidence: confidence,
                    worldPosition: position
                ))
            }
        }
        
        return results
    }
}
