
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftData
import NaturalLanguage

// MARK: - Models
@Model
final class JournalEntry {
    var id: UUID
    var text: String
    var date: Date
    @Relationship(deleteRule: .cascade) var chunks: [TextChunk] = []
    
    init(text: String, date: Date = .now) {
        self.id = UUID()
        self.text = text
        self.date = date
    }
}

// MARK: - Ingestion Pipeline
actor IngestionService {
    private let container: ModelContainer
    private let embeddingService: EmbeddingService

    init(container: ModelContainer, embeddingService: EmbeddingService) {
        self.container = container
        self.embeddingService = embeddingService
    }

    func processNewEntry(_ entry: JournalEntry) async {
        // Sliding Window Chunking (500 chars with 50 overlap)
        let chunks = chunkText(entry.text, chunkSize: 500, overlap: 50)
        
        await withTaskGroup(of: Void.self) { group in
            for chunkText in chunks {
                group.addTask {
                    do {
                        let vector = try await self.embeddingService.getEmbedding(for: chunkText, sourceID: entry.id.uuidString)
                        await self.persistChunk(text: chunkText, vector: vector, entryID: entry.id)
                    } catch {
                        print("Failed to embed chunk: \(error)")
                    }
                }
            }
        }
    }

    private func chunkText(_ text: String, chunkSize: Int, overlap: Int) -> [String] {
        var results: [String] = []
        var start = text.startIndex
        
        while start < text.endIndex {
            let end = text.index(start, offsetBy: chunkSize, limitedBy: text.endIndex) ?? text.endIndex
            results.append(String(text[start..<end]))
            let nextStart = text.index(end, offsetBy: -overlap, limitedBy: text.startIndex) ?? text.startIndex
            if nextStart <= start { break }
            start = nextStart
        }
        return results
    }

    @MainActor
    private func persistChunk(text: String, vector: [Float], entryID: UUID) {
        let context = ModelContext(container)
        // Logic to find entry and link chunk...
    }
}

// MARK: - Search Interface
@MainActor
class SearchViewModel: ObservableObject {
    @Published var results: [JournalEntry] = []
    @Published var errorMessage: String?
    
    private let searchEngine: VectorSearchEngine
    private let embeddingService: EmbeddingService

    init(searchEngine: VectorSearchEngine, embeddingService: EmbeddingService) {
        self.searchEngine = searchEngine
        self.embeddingService = embeddingService
    }

    func performSearch(query: String) async {
        do {
            // 1. Attempt to embed query (Requires Internet)
            let queryVector = try await embeddingService.getEmbedding(for: query, sourceID: "query_temp")
            
            // 2. Search local cache
            let chunks = try await searchEngine.findNearestNeighbors(to: queryVector, limit: 5)
            
            // 3. Map chunks back to parent entries (Logic simplified)
            // self.results = ... 
            
        } catch {
            // 3. Hybrid Error Handling
            self.errorMessage = "Search requires an internet connection to understand your question, but your notes are safe and searchable once you're back online."
        }
    }
}
