
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// Custom Error for Chat Agent
enum AIChatAgentError: Error, LocalizedError {
    case generationFailed(String)
    case cancelled
    case historyError(String)

    var errorDescription: String? {
        switch self {
        case .generationFailed(let details): return "AI generation failed: \(details)"
        case .cancelled: return "AI response was cancelled."
        case .historyError(let details): return "Conversation history error: \(details)"
        }
    }
}

// 1. Define AIChatAgent Actor
actor AIChatAgent {
    // 2. Manage Conversation History
    private var conversationHistory: [String] = []
    private var currentResponseTask: Task<Void, Error>? // To manage cancellation of ongoing streams

    init() {
        print("AIChatAgent initialized.")
    }

    // 3. Implement streamResponse
    func streamResponse(for message: String) -> AsyncThrowingStream<String, Error> {
        // Cancel any existing streaming task before starting a new one
        currentResponseTask?.cancel()
        currentResponseTask = nil // Clear the old task reference

        // Append user's message to history
        conversationHistory.append("User: \(message)")
        print("AIChatAgent: User message added to history. Current history count: \(conversationHistory.count)")

        // Return an AsyncThrowingStream for token streaming
        return AsyncThrowingStream { continuation in
            // Create a new Task for the AI generation, capturing it for potential cancellation
            self.currentResponseTask = Task { [weak self] in
                let fullResponse = self?.generateSimulatedAIResponse(for: message) ?? "I am unable to generate a response at this moment."
                let tokens = fullResponse.components(separatedBy: " ")

                var aiResponseBuilder = ""

                for token in tokens {
                    // Crucially, respect Task cancellation
                    guard !Task.isCancelled else {
                        print("AIChatAgent: AI response generation for '\(message)' cancelled internally.")
                        continuation.finish(throwing: AIChatAgentError.cancelled)
                        return
                    }

                    // Simulate AI model latency for token generation
                    try await Task.sleep(for: .milliseconds(100))

                    // Yield token to the stream
                    continuation.yield(token + " ")
                    aiResponseBuilder += (token + " ")
                }

                // After generation, append the AI's full response to history
                await self?.appendAIResponseToHistory(aiResponseBuilder.trimmingCharacters(in: .whitespacesAndNewlines))
                continuation.finish() // Signal completion of the stream
            }
        }
    }

    // Helper to simulate AI response based on message
    private func generateSimulatedAIResponse(for message: String) -> String {
        let lowercasedMessage = message.lowercased()
        if lowercasedMessage.contains("hello") || lowercasedMessage.contains("hi") {
            return "Hello there! How can I assist you today?"
        } else if lowercasedMessage.contains("swift") {
            return "Swift is a powerful and intuitive programming language developed by Apple. It's great for building apps across all Apple platforms and beyond!"
        } else if lowercasedMessage.contains("actor") {
            return "Actors in Swift provide a safe way to manage mutable state in concurrent environments by ensuring exclusive access to their isolated state."
        } else if lowercasedMessage.contains("weather") {
            return "I'm sorry, I don't have access to real-time weather information."
        } else {
            return "That's an interesting query! Could you please elaborate or ask something else?"
        }
    }

    // Isolated method to append AI response to history
    private func appendAIResponseToHistory(_ response: String) {
        conversationHistory.append("AI: \(response)")
        print("AIChatAgent: AI response added to history. Current history count: \(conversationHistory.count)")
    }

    // 4. Implement resetConversation()
    func resetConversation() async {
        currentResponseTask?.cancel() // Cancel any ongoing task before clearing history
        currentResponseTask = nil
        conversationHistory.removeAll()
        print("AIChatAgent: Conversation history reset.")
    }

    // Optional: Get history for debugging/display
    func getConversationHistory() -> [String] {
        return conversationHistory
    }
}

// 5. Demonstrate UI Integration and Cancellation (simulated SwiftUI View)
@main
@available(iOS 18.0, *) // AsyncThrowingStream init with Task requires iOS 18+ or macOS 15+
struct ChatApp {
    static func main() async {
        let agent = AIChatAgent()
        var currentUIMessage = ""
        var currentResponseTask: Task<Void, Error>?

        print("\n--- Demonstrating AI Chat Agent ---")

        // Simulate user asking a question
        let userQuery1 = "Tell me about Swift Actors."
        print("\nUI: User asks: '\(userQuery1)'")
        currentResponseTask = Task {
            do {
                let stream = await agent.streamResponse(for: userQuery1)
                print("UI: Receiving AI response:")
                for try await token in stream {
                    currentUIMessage += token
                    print("UI-Display: \(currentUIMessage)") // Simulate UI updating
                }
                print("UI: AI response complete: \(currentUIMessage)")
                currentUIMessage = "" // Clear for next response
            } catch {
                if error is CancellationError || error is AIChatAgentError {
                    print("UI: AI response was cancelled or failed: \(error.localizedDescription)")
                } else {
                    print("UI: An unexpected error occurred: \(error.localizedDescription)")
                }
                currentUIMessage = ""
            }
        }

        // Simulate user cancelling the first response after a short time and asking a new question
        Task {
            try await Task.sleep(for: .seconds(1))
            print("\nUI: User decides to cancel and asks a new question.")
            currentResponseTask?.cancel() // Cancel the ongoing task

            let userQuery2 = "What is the weather like today?"
            print("UI: User asks: '\(userQuery2)'")
            currentResponseTask = Task {
                do {
                    let stream = await agent.streamResponse(for: userQuery2)
                    print("UI: Receiving AI response for new query:")
                    for try await token in stream {
                        currentUIMessage += token
                        print("UI-Display: \(currentUIMessage)")
                    }
                    print("UI: AI response complete: \(currentUIMessage)")
                    currentUIMessage = ""
                } catch {
                    if error is CancellationError || error is AIChatAgentError {
                        print("UI: AI response was cancelled or failed: \(error.localizedDescription)")
                    } else {
                        print("UI: An unexpected error occurred: \(error.localizedDescription)")
                    }
                    currentUIMessage = ""
                }
            }
        }

        // Simulate resetting the conversation
        Task {
            try await Task.sleep(for: .seconds(5))
            print("\nUI: User decides to reset conversation.")
            await agent.resetConversation()
            let history = await agent.getConversationHistory()
            print("UI: Conversation history after reset: \(history.isEmpty ? "Empty" : "Not Empty")")
        }

        // Keep the main task alive long enough for all async tasks to complete
        try? await Task.sleep(for: .seconds(10))
        print("\n--- All chat agent tasks initiated. ---")
    }
}
