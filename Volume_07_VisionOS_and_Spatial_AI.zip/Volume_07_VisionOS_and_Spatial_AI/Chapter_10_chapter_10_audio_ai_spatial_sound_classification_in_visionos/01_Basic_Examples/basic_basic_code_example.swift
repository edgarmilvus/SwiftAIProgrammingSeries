
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import AVFoundation
import CoreML
import Observation
import SwiftUI

// MARK: - Models

/// Represents the result of a sound classification event.
struct SoundClassification: Sendable, Identifiable {
    let id = UUID()
    let label: String
    let confidence: Float
    let timestamp: Date
}

// MARK: - Core Logic

/// `SoundClassifierEngine` manages the audio lifecycle and ML inference.
/// It is marked as an `actor` to ensure thread-safe access to the audio engine 
/// and to prevent data races during high-frequency audio processing.
@available(iOS 18.0, visionOS 2.0, *)
actor SoundClassifierEngine {
    
    private let audioEngine = AVAudioEngine()
    private var classificationModel: MLModel?
    
    // The expected sample rate for our ML model (e.g., 16kHz or 44.1kHz)
    private let targetSampleRate: Double = 44100.0
    
    /// Initializes the engine and loads the ML model.
    /// - Parameter modelURL: The location of the compiled .mlmodelc file.
    init(modelURL: URL? = nil) {
        // In a real app, you would load your specific .mlmodel here.
        // For this example, we simulate the model loading.
        self.classificationModel = try? MLModel(contentsOf: modelURL ?? URL(fileURLWithPath: ""))
    }

    /// Starts the audio engine and installs a tap on the input bus.
    /// - Throws: An error if the audio engine fails to start.
    func startProcessing() throws {
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)

        // Ensure the audio session is configured for recording.
        try configureAudioSession()

        // Install a tap on the input node to receive audio buffers.
        // The tap provides a continuous stream of AVAudioPCMBuffer objects.
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, time in
            // We move the processing to a detached task to avoid blocking the audio thread.
            Task { [weak self] in
                await self?.processBuffer(buffer)
            }
        }

        audioEngine.prepare()
        try audioEngine.start()
    }

    /// Stops the audio engine and removes the tap.
    func stopProcessing() {
        audioEngine.inputNode.removeTap(onBus: 0)
        audioEngine.stop()
    }

    /// Configures the AVAudioSession for ambient recording.
    private func configureAudioSession() throws {
        let session = AVAudioSession.sharedInstance()
        // .playAndRecord is required for simultaneous microphone use and system audio.
        try session.setCategory(.playAndRecord, mode: .measurement, options: [.defaultToSpeaker, .allowBluetooth])
        try session.setActive(true)
    }

    /// The core processing loop.
    /// - Parameter buffer: The raw audio buffer received from the tap.
    private func processBuffer(_ buffer: AVAudioPCMBuffer) async {
        guard let model = classificationModel else {
            // Simulation: If no model is provided, we simulate a detection for demonstration.
            try? await Task.sleep(for: .seconds(2))
            return 
        }

        // 1. Feature Extraction (Under the hood: Converting PCM to Mel-Spectrogram)
        // In a real implementation, you would convert the buffer to an MLMultiArray.
        let inputFeatures = try? extractFeatures(from: buffer)
        
        guard let features = inputFeatures else { return }

        // 2. Inference
        do {
            let prediction = try await model.prediction(from: features)
            // 3. Handle the result (Logic for mapping output to labels)
            // This is where you would parse the MLMultiArray output.
        } catch {
            print("Inference Error: \(error)")
        }
    }
    
    /// Placeholder for the complex math of turning audio waves into ML inputs.
    private func extractFeatures(from buffer: AVAudioPCMBuffer) throws -> MLFeatureProvider {
        // In a real-world scenario, you would use Accelerate.framework to perform
        // an FFT (Fast Fourier Transform) and create a spectrogram.
        fatalError("Feature extraction implementation depends on specific model architecture.")
    }
    
    /// A simulated method to demonstrate how data flows to the UI.
    /// Used for the 'Basic Code Example' to ensure it is runnable without a custom .mlmodel.
    func simulateDetection() async -> SoundClassification {
        try? await Task.sleep(for: .seconds(3))
        return SoundClassification(label: "Siren Detected", confidence: 0.92, timestamp: Date())
    }
}

// MARK: - ViewModel

/// `SoundAwarenessViewModel` acts as the bridge between the background Actor 
/// and the Main Actor-bound UI.
@available(iOS 18.0, visionOS 2.0, *)
@Observable
class SoundAwarenessViewModel {
    
    var latestClassification: SoundClassification?
    var isRunning = false
    var errorMessage: String?
    
    private let engine = SoundClassifierEngine()

    /// Starts the engine and begins the simulation/processing loop.
    func start() {
        isRunning = true
        
        Task {
            do {
                try await engine.startProcessing()
                
                // Simulation loop for the sake of this beginner example
                while isRunning {
                    let detection = await engine.simulateDetection()
                    
                    // CRITICAL: We must update the UI on the MainActor.
                    // Since this is an @Observable class, updating its properties 
                    // from a background task requires explicit MainActor dispatch.
                    await MainActor.run {
                        self.latestClassification = detection
                    }
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isRunning = false
                }
            }
        }
    }

    func stop() {
        isRunning = false
        Task {
            await engine.stopProcessing()
        }
    }
}

// MARK: - UI Layer

@available(iOS 18.0, visionOS 2.0, *)
struct SoundAwarenessView: View {
    @State private var viewModel = SoundAwarenessViewModel()

    var body: some View {
        VStack(spacing: 30) {
            Text("Spatial Sound Assistant")
                .font(.largeTitle)
                .fontWeight(.bold)

            if let classification = viewModel.latestClassification {
                VStack {
                    Text(classification.label)
                        .font(.system(size: 40, weight: .medium, design: .rounded))
                        .foregroundColor(.accentColor)
                    
                    ProgressView(value: classification.confidence)
                        .frame(width: 200)
                    
                    Text("Confidence: \(Int(classification.confidence * 100))%")
                        .font(.caption)
                }
                .transition(.asymmetric(insertion: .scale, removal: .opacity))
            } else {
                Text("Listening for ambient sounds...")
                    .font(.headline)
                    .foregroundStyle(.secondary)
            }

            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
            }

            Button(action: {
                viewModel.isRunning ? viewModel.stop() : viewModel.start()
            }) {
                Label(viewModel.isRunning ? "Stop Listening" : "Start Listening", 
                      systemImage: viewModel.isRunning ? "stop.circle.fill" : "mic.circle.fill")
                    .font(.title2)
                    .padding()
            }
            .buttonStyle(.borderedProminent)
            .tint(viewModel.isRunning ? .red : .blue)
        }
        .padding(40)
        .frame(width: 500, height: 400)
    }
}
