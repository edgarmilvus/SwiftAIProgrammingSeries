
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreML
import Vision
import OSLog

// MARK: - Models

/// Represents the result of a document scan operation.
/// Conforms to `Sendable` to safely pass data across actor boundaries in Swift 6.
struct ScanResult: Sendable, Identifiable {
    let id = UUID()
    let detectedText: String
    let confidence: Float
    let timestamp: Date
}

// MARK: - Inference Engine

/// An Actor that encapsulates the Core ML model and the Vision request logic.
/// By using an `actor`, we ensure that the heavy model loading and inference
/// happen in a synchronized, isolated context, preventing data races.
@available(iOS 18.0, *)
actor DocumentScannerEngine {
    
    private let logger = Logger(subsystem: "com.ai.scanner", category: "InferenceEngine")
    
    /// The Vision request object, which wraps our Core ML model.
    private var visionRequest: VNCoreMLRequest?
    
    /// The underlying Core ML model. 
    /// We hold this in an actor to ensure it is only accessed from this isolated context.
    private var model: VNCoreMLModel?

    /// Initializes the engine and loads the model into memory.
    /// - Throws: An error if the model fails to load.
    init() async throws {
        // In a real app, you would use: try VNCoreMLModel(for: YourModel().model)
        // For this example, we simulate the loading process.
        try await loadModel()
    }

    /// Simulates the loading of a Core ML model.
    /// In a production environment, this involves disk I/O and memory allocation.
    private func loadModel() async throws {
        logger.info("Loading Core ML model into memory...")
        
        // Simulate heavy I/O delay
        try await Task.sleep(for: .seconds(1))
        
        // Placeholder for actual model initialization
        // let config = MLModelConfiguration()
        // config.computeUnits = .all // Crucial for performance profiling
        // let model = try YourModel(configuration: config).model
        // self.model = try VNCoreMLModel(for: model)
        
        logger.info("Model loaded successfully.")
    }

    /// Performs text recognition on a provided image buffer.
    /// - Parameter pixelBuffer: The raw image data from the camera.
    /// - Returns: A `ScanResult` containing the extracted text and confidence.
    /// - Throws: Errors related to Vision or Core ML execution.
    func performInference(on pixelBuffer: CVPixelBuffer) async throws -> ScanResult {
        logger.debug("Starting inference on new buffer...")
        
        // In a real implementation, we would use the Vision framework:
        // 1. Create a VNCoreMLRequest with the loaded model.
        // 2. Perform a VNImageRequestHandler.
        
        // SIMULATION: We simulate the heavy CPU/ANE computation of a neural network.
        // This is where the 'Time Profiler' in Instruments will show significant activity.
        try await Task.sleep(for: .milliseconds(500)) 
        
        let mockText = "Extracted Document Text"
        let mockConfidence: Float = 0.98
        
        logger.info("Inference complete.")
        
        return ScanResult(
            detectedText: mockText,
            confidence: mockConfidence,
            timestamp: Date()
        )
    }
}

// MARK: - View Model

/// The ViewModel manages the state of the scanner UI.
/// It is marked with `@MainActor` to ensure all updates to `@Published` properties
/// occur on the main thread, preventing UI-related crashes and race conditions.
@available(iOS 18.0, *)
@MainActor
class ScannerViewModel: ObservableObject {
    
    @Published var isProcessing = false
    @Published var lastResult: ScanResult?
    @Published var errorMessage: String?
    
    /// The isolated engine performing the heavy lifting.
    private var engine: DocumentScannerEngine?
    
    init() {
        // We trigger the async initialization in a detached task to avoid 
        // blocking the main thread during app launch.
        Task {
            do {
                self.engine = try await DocumentScannerEngine()
            } catch {
                self.errorMessage = "Failed to initialize AI Engine."
            }
        }
    }

    /// Simulates the user triggering a scan (e.g., pressing a button).
    func triggerScan() {
        guard let engine = engine else {
            errorMessage = "Engine not ready."
            return
        }
        
        // Prevent concurrent scans if one is already in progress.
        guard !isProcessing else { return }
        
        isProcessing = true
        
        // We create a new Task to handle the asynchronous inference.
        // This task inherits the @MainActor context from the class, 
        // but the call to `engine.performInference` will hop to the Actor's context.
        Task {
            do {
                // Create a dummy pixel buffer for simulation
                let dummyBuffer = createDummyPixelBuffer()
                
                // THE CRITICAL POINT FOR PROFILING:
                // The execution jumps from the MainActor (ViewModel) 
                // to the DocumentScannerEngine (Actor).
                let result = try await engine.performInference(on: dummyBuffer)
                
                // After the 'await', we jump back to the MainActor to update the UI.
                self.lastResult = result
                self.isProcessing = false
            } catch {
                self.errorMessage = error.localizedDescription
                self.isProcessing = false
            }
        }
    }
    
    /// Helper to create a dummy CVPixelBuffer for demonstration.
    private func createDummyPixelBuffer() -> CVPixelBuffer {
        var pixelBuffer: CVPixelBuffer?
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
                     kCVPixelBufferCGBitmapInfoKey: kCVPixelFormatType_32BGRA] as CFDictionary
        CVPixelBufferCreate(kCFAllocatorDefault, 1080, 1920, kCVPixelFormatType_32BGRA, attrs, &pixelBuffer)
        return pixelBuffer!
    }
}

// MARK: - View Layer

@available(iOS 18.0, *)
struct ScannerView: View {
    @StateObject private var viewModel = ScannerViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("AI Document Scanner")
                .font(.largeTitle)
                .bold()
            
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.secondary.opacity(0.2))
                    .frame(height: 300)
                
                if viewModel.isProcessing {
                    ProgressView("Analyzing Document...")
                        .scaleEffect(1.5)
                } else if let result = viewModel.lastResult {
                    VStack {
                        Text(result.detectedText)
                            .font(.headline)
                        Text("Confidence: \(Int(result.confidence * 100))%")
                            .font(.caption)
                    }
                } else {
                    Text("Ready to Scan")
                        .foregroundColor(.secondary)
                }
            }
            .padding()

            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .font(.callout)
            }

            Button(action: {
                viewModel.triggerScan()
            }) {
                Text(viewModel.isProcessing ? "Processing..." : "Start Scan")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(viewModel.isProcessing ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(viewModel.isProcessing)
            .padding(.horizontal)
            
            Spacer()
        }
        .padding()
    }
}

// MARK: - App Entry Point

@main
struct ScannerApp: App {
    var body: some Scene {
        WindowGroup {
            ScannerView()
        }
    }
}
