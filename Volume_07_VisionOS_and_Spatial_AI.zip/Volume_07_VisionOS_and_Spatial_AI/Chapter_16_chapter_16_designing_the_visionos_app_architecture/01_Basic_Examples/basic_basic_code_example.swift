
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation
import RealityKit

// MARK: - Model Layer

/// Represents a historical artifact within the museum.
/// We conform to `Sendable` to ensure it can safely be passed across 
/// concurrency boundaries in Swift 6.
struct Artifact: Identifiable, Sendable, Hashable {
    let id: UUID
    let name: String
    let description: String
    let modelName: String // The name of the USDZ file in the bundle
}

// MARK: - ViewModel Layer

/// The central brain of the application.
/// Using the `@Observable` macro (introduced in Swift 5.9/iOS 17+) 
/// provides much more granular updates than the older `ObservableObject`.
/// We mark it with `@MainActor` to ensure all state changes 
/// occur on the main thread, preventing data races in the UI.
@Observable
@MainActor
final class MuseumViewModel {
    
    /// The collection of artifacts available in the museum.
    var artifacts: [Artifact] = []
    
    /// The currently selected artifact that will be displayed in the Immersive Space.
    var selectedArtifact: Artifact?
    
    /// Tracks whether the immersive space is currently active.
    var isImmersiveSpaceActive: Bool = false
    
    init() {
        // Mock data initialization
        self.artifacts = [
            Artifact(id: UUID(), name: "Golden Mask", description: "A ceremonial mask.", modelName: "mask_usd"),
            Artifact(id: UUID(), name: "Ancient Vase", description: "Greek pottery.", modelName: "vase_usd"),
            Artifact(id: UUID(), name: "Roman Sword", description: "A sharp gladius.", modelName: "sword_usd")
        ]
    }
    
    /// Selects an artifact and prepares the state for the immersive transition.
    /// - Parameter artifact: The artifact selected by the user.
    func selectArtifact(_ artifact: Artifact) {
        self.selectedArtifact = artifact
    }
    
    /// Updates the immersion status.
    /// - Parameter active: The new state of the immersive space.
    func setImmersion(active: Bool) {
        self.isImmersiveSpaceActive = active
    }
}

// MARK: - View Layer (2D Window)

/// A standard SwiftUI view presented in a visionOS WindowGroup.
/// This acts as the "Control Center" for the user.
struct ArtifactListView: View {
    /// We inject the ViewModel from the environment to ensure 
    /// the same instance is shared across the app.
    @Environment(MuseumViewModel.self) private var viewModel
    
    /// An environment value to trigger the opening of an Immersive Space.
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    var body: some View {
        NavigationStack {
            List(viewModel.artifacts) { artifact in
                VStack(alignment: .leading) {
                    Text(artifact.name)
                        .font(.headline)
                    Text(artifact.description)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    // 1. Update the shared state
                    viewModel.selectArtifact(artifact)
                    
                    // 2. Attempt to open the immersive space
                    Task {
                        do {
                            let result = try await openImmersiveSpace(id: "MuseumSpace")
                            if result == .opened {
                                viewModel.setImmersion(active: true)
                            }
                        } catch {
                            print("Failed to open immersive space: \(error)")
                        }
                    }
                }
            }
            .navigationTitle("Museum Catalog")
        }
    }
}

// MARK: - View Layer (Immersive Space)

/// A 3D view presented within an ImmersiveSpace.
/// This view uses RealityKit to render the spatial content.
@available(visionOS 1.0, *)
struct ImmersiveMuseumView: View {
    /// Accessing the same shared ViewModel instance.
    @Environment(MuseumViewModel.self) private var viewModel
    
    var body: some View {
        RealityView { content in
            // This closure runs when the Immersive Space is first loaded.
            // We can perform initial setup here.
        } update: { content in
            // This closure runs whenever the view's state changes.
            // Because the ViewModel is @Observable, this updates 
            // automatically when viewModel.selectedArtifact changes.
            
            if let artifact = viewModel.selectedArtifact {
                // In a real app, you would load the USDZ model:
                // let entity = try? await Entity(named: artifact.modelName)
                // if let entity = entity { content.add(entity) }
                
                // For this example, we'll use a placeholder concept
                print("Updating spatial content to: \(artifact.name)")
            }
        }
    }
}

// MARK: - App Entry Point

@main
struct MuseumApp: App {
    /// The single source of truth for the entire application.
    /// By initializing it here and injecting it via `.environment`,
    /// we ensure that the Window and the Immersive Space share the same data.
    @State private var viewModel = MuseumViewModel()

    var body: some Scene {
        // The primary 2D interface
        WindowGroup {
            ArtifactListView()
                .environment(viewModel)
        }

        // The 3D spatial interface
        ImmersiveSpace(id: "MuseumSpace") {
            ImmersiveMuseumView()
                .environment(viewModel)
        }
    }
}
