
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Intelligence // Requires iOS 18.0 / macOS 15.0 or later

/// Represents an extracted action item from meeting notes.
struct ActionItem: Codable, Identifiable {
    let id = UUID()
    let description: String
    let assignee: String?
    let deadline: String? // Using String for simplicity; could be Date for robust parsing

    /// Provides a user-friendly description of the action item.
    var displayString: String {
        var parts: [String] = []
        parts.append(description)
        if let assignee = assignee {
            parts.append("Assignee: \(assignee)")
        }
        if let deadline = deadline {
            parts.append("Deadline: \(deadline)")
        }
        return parts.joined(separator: " - ")
    }
}

/// Represents the comprehensive processed output of meeting notes.
struct ProcessedMeetingNotes {
    let summary: String
    let actionItems: [ActionItem]
    let draftedEmail: String
}

/// Custom errors for the MeetingNoteProcessor.
enum MeetingNoteProcessorError: Error, LocalizedError {
    case emptyTranscript
    case generationFailed(String)
    case invalidActionItemsFormat(String)
    case unknown

    var errorDescription: String? {
        switch self {
        case .emptyTranscript:
            return "The meeting transcript cannot be empty."
        case .generationFailed(let detail):
            return "Text generation failed: \(detail)"
        case .invalidActionItemsFormat(let detail):
            return "Failed to parse action items due to invalid format: \(detail)"
        case .unknown:
            return "An unknown error occurred during processing."
        }
    }
}

/// A service class to process meeting transcripts using Apple Intelligence.
@available(iOS 18.0, *)
final class MeetingNoteProcessor {
    private let textGenerator: TextGeneration.Generator

    /// Initializes the processor.
    /// - Parameter model: The TextGeneration.Model to use. Defaults to `.onDevice`.
    init(model: TextGeneration.Model = .onDevice) {
        // Initialize the TextGeneration.Generator with the specified model.
        // For privacy-sensitive data like meeting notes, `.onDevice` is crucial.
        self.textGenerator = TextGeneration.Generator(model: model)
    }

    /// Generates a concise summary of the provided meeting transcript.
    /// - Parameter transcript: The full meeting transcript.
    /// - Returns: A string containing the summary.
    /// - Throws: `MeetingNoteProcessorError` if generation fails.
    private func generateSummary(from transcript: String) async throws -> String {
        // Construct a clear prompt for summarization.
        // Good prompt engineering is key for effective LLM output.
        let prompt = "Summarize the following meeting transcript concisely, highlighting key decisions and discussion points:\n\n\(transcript)"

        do {
            // Asynchronously generate text using the on-device LLM.
            let result = try await textGenerator.generate(prompt)
            // Ensure the generated text is not empty.
            guard !result.isEmpty else {
                throw MeetingNoteProcessorError.generationFailed("Summary generation returned empty result.")
            }
            return result
        } catch {
            // Wrap any underlying errors in our custom error type for better context.
            throw MeetingNoteProcessorError.generationFailed(error.localizedDescription)
        }
    }

    /// Extracts action items from the meeting transcript, aiming for a structured JSON output.
    /// - Parameter transcript: The full meeting transcript.
    /// - Returns: An array of `ActionItem` objects.
    /// - Throws: `MeetingNoteProcessorError` if generation fails or JSON parsing fails.
    private func extractActionItems(from transcript: String) async throws -> [ActionItem] {
        // Prompt engineering to request JSON output for action items.
        // This makes programmatic parsing much easier and more reliable.
        let prompt = """
        From the following meeting transcript, identify all action items. For each action item, extract its description, who it's assigned to (if mentioned), and any specified deadline (if mentioned).
        Format the output as a JSON array of objects, where each object has 'description', 'assignee' (optional), and 'deadline' (optional) keys.
        Example: [{"description": "Review Q3 report", "assignee": "Alice", "deadline": "Friday"}, {"description": "Schedule follow-up"}]

        Meeting Transcript:
        \(transcript)
        """

        do {
            let jsonString = try await textGenerator.generate(prompt)
            // Attempt to decode the JSON string into an array of ActionItem.
            guard let jsonData = jsonString.data(using: .utf8) else {
                throw MeetingNoteProcessorError.invalidActionItemsFormat("Could not convert generated string to Data.")
            }
            let decoder = JSONDecoder()
            return try decoder.decode([ActionItem].self, from: jsonData)
        } catch let decodingError as DecodingError {
            // Provide specific error details for decoding failures.
            throw MeetingNoteProcessorError.invalidActionItemsFormat("JSON decoding failed: \(decodingError.localizedDescription)")
        } catch {
            throw MeetingNoteProcessorError.generationFailed(error.localizedDescription)
        }
    }

    /// Drafts a follow-up email based on the meeting summary and action items.
    /// - Parameters:
    ///   - summary: The generated meeting summary.
    ///   - actionItems: The extracted action items.
    /// - Returns: A string containing the drafted email content.
    /// - Throws: `MeetingNoteProcessorError` if generation fails.
    private func draftFollowUpEmail(summary: String, actionItems: [ActionItem]) async throws -> String {
        // Format action items for inclusion in the email.
        let actionItemsList = actionItems.isEmpty ? "No specific action items identified." :
            actionItems.enumerated().map { (index, item) in
                "\(index + 1). \(item.displayString)"
            }.joined(separator: "\n")

        // Craft a prompt to generate a professional follow-up email.
        let prompt = """
        Draft a professional follow-up email for a meeting.
        Subject: Meeting Follow-up - [Meeting Topic/Date]

        Body:
        Here's a summary of our discussion:
        \(summary)

        Key Action Items:
        \(actionItemsList)

        Please review and let me know if you have any questions or require further clarification.
        """

        do {
            let emailDraft = try await textGenerator.generate(prompt)
            guard !emailDraft.isEmpty else {
                throw MeetingNoteProcessorError.generationFailed("Email drafting returned empty result.")
            }
            return emailDraft
        } catch {
            throw MeetingNoteProcessorError.generationFailed(error.localizedDescription)
        }
    }

    /// Processes a full meeting transcript to generate a summary, extract action items, and draft a follow-up email.
    /// This is the main public interface for the processor.
    /// - Parameter transcript: The raw text transcript of the meeting.
    /// - Returns: A `ProcessedMeetingNotes` object containing all generated outputs.
    /// - Throws: `MeetingNoteProcessorError` if any step of the processing fails.
    public func processMeetingNotes(transcript: String) async throws -> ProcessedMeetingNotes {
        // Input validation: ensure transcript is not empty.
        guard !transcript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw MeetingNoteProcessorError.emptyTranscript
        }

        // Use a TaskGroup or sequential async calls. For clarity and dependency, sequential is fine here.
        // Each step builds upon the previous or uses the original transcript.

        // 1. Generate Summary
        let summary = try await generateSummary(from: transcript)
        print("Generated Summary:\n\(summary)\n---")

        // 2. Extract Action Items
        let actionItems = try await extractActionItems(from: transcript)
        print("Extracted Action Items:")
        actionItems.forEach { print("- \($0.displayString)") }
        print("---\n")

        // 3. Draft Follow-up Email
        let draftedEmail = try await draftFollowUpEmail(summary: summary, actionItems: actionItems)
        print("Drafted Follow-up Email:\n\(draftedEmail)\n---")

        return ProcessedMeetingNotes(summary: summary, actionItems: actionItems, draftedEmail: draftedEmail)
    }
}

// MARK: - Example Usage (within an iOS 18+ application context)

/// Simulates a UI component or view model that interacts with the MeetingNoteProcessor.
@available(iOS 18.0, *)
class MeetingNotesViewModel: ObservableObject {
    @Published var processedNotes: ProcessedMeetingNotes?
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false

    private let processor = MeetingNoteProcessor() // Using the default on-device model

    /// Processes a given meeting transcript.
    /// This method would typically be called from a UI action (e.g., button tap).
    /// - Parameter transcript: The raw text of the meeting.
    func process(transcript: String) {
        isLoading = true
        errorMessage = nil
        processedNotes = nil

        Task {
            do {
                let notes = try await processor.processMeetingNotes(transcript: transcript)
                // Update UI on the main actor.
                await MainActor.run {
                    self.processedNotes = notes
                    self.isLoading = false
                }
            } catch {
                // Handle errors and update UI on the main actor.
                await MainActor.run {
                    if let processorError = error as? MeetingNoteProcessorError {
                        self.errorMessage = processorError.localizedDescription
                    } else {
                        self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                    }
                    self.isLoading = false
                }
            }
        }
    }
}

// --- Example of how to use it in a SwiftUI View (Conceptual) ---
/*
import SwiftUI

@available(iOS 18.0, *)
struct MeetingNotesView: View {
    @StateObject private var viewModel = MeetingNotesViewModel()
    @State private var meetingTranscript: String = """
    Attendees: Alice, Bob, Charlie, David
    Date: October 26, 2024
    Topic: Q4 Project Planning and Budget Review

    Meeting started at 10:00 AM.
    Alice presented the Q3 performance review, noting a 15% increase in user engagement but a 5% dip in subscription renewals.
    Bob proposed a new marketing campaign targeting lapsed subscribers, suggesting a budget of $20,000 for social media ads. He needs to prepare a detailed proposal by next Wednesday.
    Charlie raised concerns about server capacity for the anticipated Q4 user growth. He will investigate scaling options and present findings by end of week.
    David suggested exploring partnership opportunities to expand market reach. Alice agreed to research potential partners and set up initial calls by the end of November.
    We decided to prioritize the marketing campaign and server scaling for Q4.
    Follow-up meeting scheduled for November 8th to review Bob's proposal and Charlie's findings.
    Meeting adjourned at 11:30 AM.
    """

    var body: some View {
        NavigationView {
            Form {
                Section("Meeting Transcript") {
                    TextEditor(text: $meetingTranscript)
                        .frame(minHeight: 150)
                        .border(Color.gray.opacity(0.2), width: 1)
                }

                Button("Process Notes with Apple Intelligence") {
                    viewModel.process(transcript: meetingTranscript)
                }
                .disabled(viewModel.isLoading)

                if viewModel.isLoading {
                    ProgressView("Processing...")
                }

                if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                }

                if let notes = viewModel.processedNotes {
                    Section("Summary") {
                        Text(notes.summary)
                    }
                    Section("Action Items") {
                        ForEach(notes.actionItems) { item in
                            Text(item.displayString)
                        }
                    }
                    Section("Drafted Follow-up Email") {
                        Text(notes.draftedEmail)
                    }
                }
            }
            .navigationTitle("Smart Meeting Notes")
        }
    }
}

// To run this in a preview or an actual app:
// @main
// struct SmartMeetingNotesApp: App {
//     var body: some Scene {
//         WindowGroup {
//             MeetingNotesView()
//         }
//     }
// }
*/
