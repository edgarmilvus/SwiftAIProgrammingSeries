
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct Email: Sendable, Identifiable {
    let id: String
    let sender: String
    let snippet: String
}

@available(iOS 18.0, *)
actor MailboxState {
    private var processedEmailIDs: Set<String> = []
    
    func markAsProcessed(_ id: String) {
        processedEmailIDs.insert(id)
    }
    
    func hasProcessed(_ id: String) -> Bool {
        processedEmailIDs.contains(id)
    }
}

@available(iOS 18.0, *)
struct EmailTool: Tool {
    let name = "email_tool"
    let description = "Handles email operations. Use fetchUnreadEmails, getThread, or createDraft."
    let mailboxState: MailboxState

    func execute(arguments: [String: AnySendable]) async throws -> String {
        let action = arguments["action"]?.asString() ?? ""
        
        switch action {
        case "fetchUnreadEmails":
            // Mocked data
            return "IDs: [eml_1, eml_2]. Snippets: [eml_1: Meeting request; eml_2: Lunch?]"
            
        case "getThread":
            guard let id = arguments["email_id"]?.asString() else { throw ToolError.missingArgument("email_id") }
            
            // PREVENT INFINITE LOOP: Check memory
            if await mailboxState.hasProcessed(id) {
                return "Observation: You have already processed this email: \(id)."
            }
            
            await mailboxState.markAsProcessed(id)
            return "Full Thread for \(id): 'Hi, can we meet at 3 PM?'"
            
        case "createDraft":
            return "Draft created with ID: draft_99"
            
        default:
            return "Error: Unknown action."
        }
    }
}

@available(iOS 18.0, *)
actor MailAgentEngine {
    private let emailTool: EmailTool
    private let mailboxState = MailboxState()
    
    init() {
        self.emailTool = EmailTool(mailboxState: mailboxState)
    }
    
    func processRequest(_ prompt: String) async {
        print("🚀 Starting MailFlow Agent for: \(prompt)")
        
        // Step 1: Fetching
        print("🤔 Thought: I need to see what the unread emails are.")
        let obs1 = try? await emailTool.execute(arguments: ["action": AnySendable("fetchUnreadEmails")])
        print("👁 Observation: \(obs1 ?? "No emails")")
        
        // Step 2: Reading specific email
        print("🤔 Thought: I will read the first email.")
        let obs2 = try? await emailTool.execute(arguments: [
            "action": AnySendable("getThread"),
            "email_id": AnySendable("eml_1")
        ])
        print("👁 Observation: \(obs2 ?? "Failed")")
        
        // Step 3: Attempting to read the same email again (Testing loop prevention)
        print("🤔 Thought: I'll check that email again just in case.")
        let obs3 = try? await emailTool.execute(arguments: [
            "action": AnySendable("getThread"),
            "email_id": AnySendable("eml_1")
        ])
        print("👁 Observation: \(obs3 ?? "Failed")")
        
        // Step 4: Drafting
        print("🤔 Thought: I'll draft a reply.")
        let obs4 = try? await emailTool.execute(arguments: [
            "action": AnySendable("createDraft"),
            "body": AnySendable("I am available at 3 PM.")
        ])
        print("✅ Final Result: \(obs4 ?? "Draft failed")")
    }
}

// --- Execution ---
@main
struct MailFlowApp {
    static func main() async {
        let engine = MailAgentEngine()
        await engine.processRequest("Summarize my unread emails and draft a reply.")
    }
}
