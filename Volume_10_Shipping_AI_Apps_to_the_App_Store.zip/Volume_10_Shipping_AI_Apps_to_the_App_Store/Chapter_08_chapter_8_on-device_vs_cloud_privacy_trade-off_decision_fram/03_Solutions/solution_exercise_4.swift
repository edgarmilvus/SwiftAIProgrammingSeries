
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

enum JournalSensitivity {
    case high
    case general
}

struct JournalEntry: Sendable, Identifiable {
    let id: UUID = UUID()
    let text: String
    let date: Date
}

/// Manages user consent for cloud usage.
actor ConsentManager {
    private var cloudInsightsEnabled: Bool {
        get { UserDefaults.standard.bool(forKey: "allow_cloud_insights") }
        set { UserDefaults.standard.set(newValue, forKey: "allow_cloud_insights") }
    }

    func setConsent(_ allowed: Bool) { cloudInsightsEnabled = allowed }
    func isConsentGranted() -> Bool { cloudInsightsEnabled }
}

/// The core engine for ZenJournal's reflection feature.
actor WeeklyReflectionEngine {
    private let consentManager: ConsentManager
    private let sensitiveKeywords = ["depression", "trauma", "anxiety", "suicide", "harm"]

    init(consentManager: ConsentManager) {
        self.consentManager = consentManager
    }

    /// Analyzes a single entry to determine sensitivity.
    private func analyzeSensitivity(for entry: JournalEntry) -> JournalSensitivity {
        let lowercased = entry.text.lowercased()
        
        // Check for explicit keywords
        for word in sensitiveKeywords {
            if lowercased.contains(word) { return .high }
        }
        
        // Use NaturalLanguage for sentiment analysis
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = entry.text
        let (sentiment, _) = tagger.tag(at: entry.text.startIndex, unit: .paragraph, scheme: .sentimentScore)
        
        if let scoreString = sentiment?.rawValue, let score = Double(scoreString), score < -0.5 {
            return .high // Very negative sentiment is treated as sensitive
        }
        
        return .general
    }

    /// Generates a summary using TaskGroups for parallel analysis.
    func generateWeeklySummary(entries: [JournalEntry]) async throws -> String {
        // 1. Parallel Sensitivity Analysis
        let sensitivityResults = await withTaskGroup(of: (UUID, JournalSensitivity).self) { group in
            for entry in entries {
                group.addTask {
                    let sensitivity = self.analyzeSensitivity(for: entry)
                    return (entry.id, sensitivity)
                }
            }
            
            var results: [UUID: JournalSensitivity] = [:]
            for await (id, sensitivity) in group {
                results[id] = sensitivity
            }
            return results
        }

        // 2. Determine Tier
        let containsHighSensitivity = sensitivityResults.values.contains(.high)
        let consentGranted = await consentManager.isConsentGranted()

        if containsHighSensitivity || !consentGranted {
            return try await runLocalSummarization(entries: entries)
        } else {
            return try await runCloudSummarization(entries: entries)
        }
    }

    private func runLocalSummarization(entries: [JournalEntry]) async throws -> String {
        print("Executing Tier 1: Local-Only Summarization...")
        try await Task.sleep(for: .seconds(1))
        return "[Local Summary]: Your week was emotionally complex. Focus on mindfulness."
    }

    private func runCloudSummarization(entries: [JournalEntry]) async throws -> String {
        print("Executing Tier 2: Cloud-Hybrid Summarization...")
        try await Task.sleep(for: .seconds(2))
        return "[Cloud Deep Insight]: You showed resilience through various activities this week..."
    }
}

// MARK: - Execution Example
@main
struct ZenJournalApp {
    static func main() async {
        let consent = ConsentManager()
        await consent.setConsent(true)
        
        let engine = WeeklyReflectionEngine(consentManager: consent)
        
        let entries = [
            JournalEntry(text: "I went to the park and had coffee.", date: Date()),
            JournalEntry(text: "I am feeling a lot of anxiety lately.", date: Date()), // High sensitivity
            JournalEntry(text: "The sunset was beautiful.", date: Date())
        ]

        print("--- Requesting Weekly Reflection ---")
        do {
            let summary = try await engine.generateWeeklySummary(entries: entries)
            print("Final Result: \(summary)")
        } catch {
            print("Error: \(error)")
        }
    }
}
