
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import AppKit // For NSAlert, NSWorkspace
import SwiftUI // For UI demonstration

// MARK: - Remote Version Manifest Structure
struct UpdateManifest: Decodable {
    let latestVersion: String
    let downloadURL: URL
    let releaseNotes: String?
}

// MARK: - AppUpdater Class
@available(macOS 14.0, *)
class AppUpdater: ObservableObject {
    private let updateManifestURL = URL(string: "https://yourdomain.com/update_manifest.json")! // <--- REPLACE WITH YOUR ACTUAL MANIFEST URL
    @Published var updateStatus: String = "Checking for updates..."
    @Published var downloadProgress: Double = 0.0 // 0.0 to 1.0
    @Published var isDownloading: Bool = false

    private var downloadTask: URLSessionDownloadTask?

    /// Retrieves the current application version from Info.plist.
    func getCurrentAppVersion() -> String? {
        return Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
    }

    /// Checks for updates by fetching the remote manifest and comparing versions.
    func checkForUpdates() async {
        guard let currentVersion = getCurrentAppVersion() else {
            DispatchQueue.main.async {
                self.updateStatus = "Could not determine current app version."
            }
            return
        }

        DispatchQueue.main.async {
            self.updateStatus = "Checking for updates..."
            self.isDownloading = false
            self.downloadProgress = 0.0
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: updateManifestURL)
            let manifest = try JSONDecoder().decode(UpdateManifest.self, from: data)

            // Compare versions numerically. `compare` with `.numeric` option is robust.
            if manifest.latestVersion.compare(currentVersion, options: .numeric) == .orderedDescending {
                DispatchQueue.main.async {
                    self.showUpdateAlert(manifest: manifest)
                }
            } else {
                DispatchQueue.main.async {
                    self.updateStatus = "You are running the latest version (\(currentVersion))."
                }
            }
        } catch {
            DispatchQueue.main.async {
                self.updateStatus = "Failed to check for updates: \(error.localizedDescription)"
            }
            print("Error checking for updates: \(error.localizedDescription)")
        }
    }

    /// Displays an NSAlert to the user about a new version.
    private func showUpdateAlert(manifest: UpdateManifest) {
        let alert = NSAlert()
        alert.messageText = "New Version Available: \(manifest.latestVersion)"
        alert.informativeText = "Your current version is \(getCurrentAppVersion() ?? "unknown").\n\nRelease Notes:\n\(manifest.releaseNotes ?? "No release notes provided.")"
        alert.addButton(withTitle: "Update Now")
        alert.addButton(withTitle: "Later")
        alert.alertStyle = .informational

        if alert.runModal() == .alertFirstButtonReturn {
            downloadUpdate(url: manifest.downloadURL)
        } else {
            self.updateStatus = "Update postponed."
        }
    }

    /// Initiates the download of the new application package.
    private func downloadUpdate(url: URL) {
        DispatchQueue.main.async {
            self.updateStatus = "Downloading update..."
            self.isDownloading = true
            self.downloadProgress = 0.0
        }

        let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        downloadTask = session.downloadTask(with: url)
        downloadTask?.resume()
    }

    /// Cancels any ongoing download task.
    func cancelDownload() {
        downloadTask?.cancel()
        DispatchQueue.main.async {
            self.isDownloading = false
            self.updateStatus = "Download cancelled."
            self.downloadProgress = 0.0
        }
    }
}

// MARK: - URLSessionDownloadDelegate for progress tracking
@available(macOS 14.0, *)
extension AppUpdater: URLSessionDownloadDelegate {
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        DispatchQueue.main.async {
            self.isDownloading = false
            self.downloadProgress = 1.0 // Ensure 100% on completion
        }

        do {
            let fileName = downloadTask.originalRequest?.url?.lastPathComponent ?? "update.dmg"
            let destinationURL = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)

            // Move the downloaded file from the temporary location to our desired temporary location
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.moveItem(at: location, to: destinationURL)

            DispatchQueue.main.async {
                self.updateStatus = "Download complete. Opening installer..."
                NSWorkspace.shared.open(destinationURL) { success in
                    if success {
                        // Optionally, prompt user to quit current app to install the new one.
                        let alert = NSAlert()
                        alert.messageText = "Update Downloaded"
                        alert.informativeText = "The new version has been downloaded and is now open. Please quit the current application and launch the new one from the installer to complete the update."
                        alert.addButton(withTitle: "Quit App")
                        alert.addButton(withTitle: "Later")
                        alert.alertStyle = .informational
                        if alert.runModal() == .alertFirstButtonReturn {
                            NSApplication.shared.terminate(nil)
                        }
                    } else {
                        self.updateStatus = "Failed to open downloaded installer."
                        print("Error: Failed to open downloaded installer at \(destinationURL.path)")
                    }
                }
            }
        } catch {
            DispatchQueue.main.async {
                self.updateStatus = "Error saving or opening downloaded file: \(error.localizedDescription)"
            }
            print("Error saving or opening downloaded file: \(error.localizedDescription)")
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        if totalBytesExpectedToWrite > 0 {
            let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
            DispatchQueue.main.async {
                self.downloadProgress = progress
                self.updateStatus = String(format: "Downloading... %.0f%%", progress * 100)
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error as? URLError, error.code == .cancelled {
            // Handled by cancelDownload()
            return
        }

        if let error = error {
            DispatchQueue.main.async {
                self.isDownloading = false
                self.updateStatus = "Download failed: \(error.localizedDescription)"
            }
            print("Download task failed with error: \(error.localizedDescription)")
        }
    }
}

// MARK: - SwiftUI View for Demonstration
@available(macOS 14.0, *)
struct UpdateView: View {
    @StateObject private var appUpdater = AppUpdater()

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "arrow.triangle.2.circlepath")
                .resizable()
                .scaledToFit()
                .frame(width: 60, height: 60)
                .foregroundColor(.blue)

            Text("App Updater")
                .font(.largeTitle)

            Text("Current Version: \(appUpdater.getCurrentAppVersion() ?? "Unknown")")
                .font(.headline)

            Text("Status: \(appUpdater.updateStatus)")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            if appUpdater.isDownloading {
                ProgressView(value: appUpdater.downloadProgress)
                    .progressViewStyle(.linear)
                    .frame(width: 200)
                Text(String(format: "%.0f%%", appUpdater.downloadProgress * 100))
                    .font(.caption)
                Button("Cancel Download") {
                    appUpdater.cancelDownload()
                }
            } else {
                Button("Check for Updates") {
                    Task {
                        await appUpdater.checkForUpdates()
                    }
                }
                .disabled(appUpdater.isDownloading)
            }
        }
        .padding(40)
        .frame(minWidth: 400, minHeight: 300)
        .onAppear {
            Task {
                await appUpdater.checkForUpdates()
            }
        }
    }
}

// MARK: - App Entry Point (for demonstration)
@available(macOS 14.0, *)
@main
struct SelfUpdatingApp: App {
    var body: some Scene {
        WindowGroup {
            UpdateView()
        }
    }
}

/*
// To make this runnable, you need to:
// 1. Create a new macOS App project (SwiftUI).
// 2. Set a 'Version' (CFBundleShortVersionString) in your project's Info.plist or Build Settings.
// 3. Host a `update_manifest.json` file publicly (e.g., GitHub Pages, S3).
//    Example `update_manifest.json`:
//    {
//      "latestVersion": "1.2.0",
//      "downloadURL": "https://yourdomain.com/downloads/MyAIAgent_1.2.0.dmg",
//      "releaseNotes": "Bug fixes, performance improvements, and support for new GGUF models."
//    }
// 4. Create a dummy `.dmg` or `.zip` file for testing the download and link it in your manifest.
// 5. Replace `https://yourdomain.com/update_manifest.json` in `AppUpdater` with your actual URL.
// 6. Replace the default App.swift content with the SelfUpdatingApp struct and UpdateView.
*/
