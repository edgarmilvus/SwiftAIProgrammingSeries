
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import CoreData
import Foundation

// MARK: - Optimized Data Model Architecture

/*
 ARCHITECTURAL NOTE:
 To prevent large blobs from choking the sync engine, we use a "Split-Entity" pattern.
 
 Entity 1: SnippetMetadata
 - text: String
 - timestamp: Date
 - relationship: embedding -> SnippetEmbedding (One-to-One, Nullable)
 
 Entity 2: SnippetEmbedding
 - embeddingData: Data (Set to "Allows External Binary Storage")
*/

@available(iOS 18.0, macOS 15.0, *)
class KnowledgeManager {
    let container: NSPersistentCloudKitContainer
    let maxEmbeddingSize = 1_000_000 // 1MB Threshold
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }
    
    func saveSnippet(text: String, embedding: Data) async throws {
        let context = container.newBackgroundContext()
        
        try await context.perform {
            // 1. Size Validation (Error Mitigation)
            guard embedding.count <= self.maxEmbeddingSize else {
                throw NSError(domain: "KnowledgeError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Embedding too large for standard sync."])
            }
            
            // 2. Create Metadata (The "Fast" Sync Entity)
            let metadata = SnippetMetadata(context: context)
            metadata.text = text
            metadata.timestamp = Date()
            
            // 3. Create Embedding (The "Heavy" Sync Entity)
            let embeddingEntity = SnippetEmbedding(context: context)
            embeddingEntity.embeddingData = embedding
            
            // 4. Establish Relationship
            metadata.embedding = embeddingEntity
            
            try context.save()
        }
    }
    
    /// Performs a high-performance search that avoids loading heavy embeddings into memory.
    func fetchAllMetadata() throws -> [SnippetMetadata] {
        let request: NSFetchRequest<SnippetMetadata> = SnippetMetadata.fetchRequest()
        
        // OPTIMIZATION: Only fetch the properties we need for the list view.
        // This prevents the 'embedding' relationship from being faulted into memory.
        request.propertiesToFetch = ["text", "timestamp"]
        request.returnsObjectsAsFaults = true 
        
        return try container.viewContext.fetch(request)
    }
}
