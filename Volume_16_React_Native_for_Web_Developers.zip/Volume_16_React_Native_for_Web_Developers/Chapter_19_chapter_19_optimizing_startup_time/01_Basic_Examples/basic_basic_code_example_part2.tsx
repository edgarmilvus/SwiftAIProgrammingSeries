/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: pages/index.tsx (or app/page.tsx in Next.js App Router)
// The main entry point demonstrating lazy loading.

import React, { Suspense, useState } from 'react';

// 1. DYNAMIC IMPORT (Code Splitting)
// We use Next.js's dynamic import with `ssr: false` to ensure this component 
// is not rendered on the server, effectively splitting the bundle.
// In a pure React app, this would be: const Dashboard = React.lazy(() => import('./Dashboard'));
const Dashboard = React.lazy(() => import('./Dashboard'));

/**
 * @description The main application component.
 * @returns {JSX.Element} The rendered app with a lazy-loaded section.
 */
export default function Home() {
  const [showDashboard, setShowDashboard] = useState(false);

  return (
    <div>
      <h1>SaaS Platform - Home</h1>
      <p>Initial load is fast because the Dashboard is not included in the main bundle.</p>
      
      <button 
        onClick={() => setShowDashboard(true)}
        style={{ padding: '10px 20px', cursor: 'pointer' }}
      >
        Load Dashboard
      </button>

      {/* 2. SUSPENSE BOUNDARY */}
      {/* The Suspense boundary catches the lazy component loading state. 
          While the Dashboard code is being fetched, the fallback UI is shown. */}
      <Suspense fallback={<div>Loading Dashboard...</div>}>
        {showDashboard && <Dashboard />}
      </Suspense>
    </div>
  );
}
