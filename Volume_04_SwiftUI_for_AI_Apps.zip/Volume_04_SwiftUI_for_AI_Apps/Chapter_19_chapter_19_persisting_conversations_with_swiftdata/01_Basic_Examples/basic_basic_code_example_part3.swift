
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import SwiftData

@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    // 1. Access the ModelContext from the environment
    @Environment(\.modelContext) private var modelContext

    // 2. Query all Message objects, sorted by timestamp
    @Query(sort: \Message.timestamp) private var messages: [Message]

    // State for a new message input
    @State private var newMessageContent: String = ""

    var body: some View {
        NavigationView {
            VStack {
                // Display existing messages
                ScrollViewReader { proxy in
                    List {
                        ForEach(messages) { message in
                            MessageRow(message: message)
                                .id(message.id) // Use message.id for ScrollViewReader
                        }
                        .onDelete(perform: deleteMessages) // 3. Delete functionality
                    }
                    .onChange(of: messages.count) {
                        // Scroll to the bottom when a new message is added
                        if let lastMessage = messages.last {
                            proxy.scrollTo(lastMessage.id, anchor: .bottom)
                        }
                    }
                }
                .navigationTitle("AI Chat")

                // Input field for new messages
                HStack {
                    TextField("Enter message...", text: $newMessageContent)
                        .textFieldStyle(.roundedBorder)
                        .padding(.vertical, 8)

                    Button("Send") {
                        addMessage(content: newMessageContent, isUser: true)
                        newMessageContent = "" // Clear input
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding()
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton() // For deleting multiple items
                }
            }
        }
    }

    /// Adds a new message to the SwiftData store.
    /// - Parameters:
    ///   - content: The text content of the message.
    ///   - isUser: `true` if the message is from the user, `false` if from the AI.
    private func addMessage(content: String, isUser: Bool) {
        guard !content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        // Create a new Message instance
        let newMessage = Message(content: content, timestamp: Date(), isUser: isUser)

        // Insert the new message into the model context
        modelContext.insert(newMessage)

        // SwiftData automatically saves changes periodically,
        // but you can explicitly save if needed (e.g., before app termination).
        // For simple inserts, the automatic saving is often sufficient.
        // try? modelContext.save()
    }

    /// Deletes a set of messages from the SwiftData store.
    /// - Parameter offsets: The `IndexSet` of messages to delete.
    private func deleteMessages(offsets: IndexSet) {
        for index in offsets {
            let message = messages[index]
            modelContext.delete(message) // Delete the message from the context
        }
        // SwiftData will automatically save the deletion.
        // try? modelContext.save()
    }
}

/// A helper view to display a single message.
@available(iOS 18.0, macOS 15.0, *)
struct MessageRow: View {
    let message: Message

    var body: some View {
        HStack {
            if message.isUser {
                Spacer()
                Text(message.content)
                    .padding(10)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            } else {
                Text(message.content)
                    .padding(10)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                Spacer()
            }
        }
        .padding(.horizontal, message.isUser ? 10 : 0)
        .padding(.vertical, 2)
    }
}
