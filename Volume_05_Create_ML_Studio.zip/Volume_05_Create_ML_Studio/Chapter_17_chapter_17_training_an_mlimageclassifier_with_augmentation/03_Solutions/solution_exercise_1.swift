
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// MARK: - Create ML Training (macOS Command Line Tool or Playground)
// This part of the code is designed to be run in a macOS environment,
// typically within a Create ML Playground or a macOS command-line tool.
// It requires the CreateML framework, which is macOS-only for training.

import CreateML
import Foundation

// Define paths for your simulated dataset
// IMPORTANT: Replace these URLs with actual paths to your data.
// The structure should be:
// - trainingDataDirectory/
//   - Invoice/
//     - invoice1.png
//     - invoice2.png
//   - Receipt/
//     - receipt1.png
//     - receipt2.png
//   - Letter/
//     - letter1.png
//     - letter2.png
// - validationDataDirectory/ (similar structure)
let trainingDataURL = URL(fileURLWithPath: "/path/to/your/trainingDataDirectory")
let validationDataURL = URL(fileURLWithPath: "/path/to/your/validationDataDirectory")
let outputModelURL = URL(fileURLWithPath: "/path/to/save/DocumentClassifier.mlmodel")

@available(macOS 14.0, *) // Create ML is generally available on macOS
func trainDocumentClassifier() async {
    print("Starting document classifier training...")
    do {
        // 1. Data Preparation: Load data from labeled directories
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
        let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: validationDataURL)

        // 2. Model Training with Basic Augmentation
        let builder = MLImageClassifier.Builder(trainingData: trainingData)
            .validationData(validationData)
            .maxEpochs(30) // A reasonable number for a basic model
            .batchSize(32) // Standard batch size
            .learningRate(0.001) // Default learning rate is often a good start
            .augmentationOptions([
                .rotation(minimumAngle: -5, maximumAngle: 5), // Slight rotations for scanning angle
                .horizontalFlip, // Useful if documents can be scanned upside down or mirrored (less common for text, but fine for general images)
                // .verticalFlip, // Could be useful, but less common for documents
                .crop(minimumScale: 0.9, maximumScale: 1.0), // Simulate slight misalignments or zoom
                .color(saturation: 0.1, brightness: 0.1, contrast: 0.1) // Simulate slight lighting variations
            ])
            .baseModel(.visionFeaturePrint) // Use a pre-trained base model for better performance

        print("Training model...")
        let model = try builder.train()
        print("Model training complete.")

        // 3. Model Evaluation (Create ML provides this during training)
        // You would typically inspect the training log for accuracy, loss, etc.
        // The builder.train() method returns the trained model.

        // Save the trained model
        let metadata = MLModelMetadata(
            author: "Your Name",
            shortDescription: "Classifies document types (Invoice, Receipt, Letter)",
            version: "1.0",
            license: "MIT",
            additional: nil
        )
        try model.write(to: outputModelURL, metadata: metadata)
        print("Model saved to: \(outputModelURL.path)")

    } catch {
        print("Error during training: \(error.localizedDescription)")
    }
}

// To run the training in a Playground:
// await trainDocumentClassifier()

// To run in a command-line tool:
// @main
// struct DocumentClassifierTrainer {
//     static func main() async {
//         await trainDocumentClassifier()
//     }
// }


// MARK: - macOS App Integration (Command Line Tool Example)
// This part would be in a separate macOS command-line tool project
// or an AppKit application to classify images.

import CoreML
import Vision
import Cocoa // For NSImage

// Assume your trained model is bundled with the app or accessible
// Replace "DocumentClassifier" with the actual name of your .mlmodel file
// (e.g., if you saved it as DocumentClassifier.mlmodel)
struct DocumentClassifier {
    private let model: VNCoreMLModel

    init() async throws {
        // Find the compiled model in the app bundle
        guard let modelURL = Bundle.main.url(forResource: "DocumentClassifier", withExtension: "mlmodelc") else {
            // For a command-line tool, you might need to load from a specific path
            // instead of the bundle. For simplicity, we assume it's compiled and ready.
            // If running directly from a .mlmodel path:
            // let uncompiledModelURL = URL(fileURLWithPath: "/path/to/DocumentClassifier.mlmodel")
            // let compiledModelURL = try await MLModel.compileModel(at: uncompiledModelURL)
            // let coreMLModel = try MLModel(contentsOf: compiledModelURL)
            fatalError("Could not find DocumentClassifier.mlmodelc in app bundle. Ensure it's compiled and added to your target.")
        }

        // Compile the model if it's an .mlmodel, or load directly if .mlmodelc
        // For models bundled with the app, Xcode usually compiles them automatically to .mlmodelc
        let coreMLModel = try MLModel(contentsOf: modelURL)
        self.model = try VNCoreMLModel(for: coreMLModel)
    }

    func classifyImage(at imageURL: URL) async throws -> (String, Float)? {
        guard let image = NSImage(contentsOf: imageURL),
              let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            throw ImageClassificationError.invalidImage
        }

        return try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: self.model) { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                guard let results = request.results as? [VNClassificationObservation],
                      let topResult = results.first else {
                    continuation.resume(returning: nil)
                    return
                }
                continuation.resume(returning: (topResult.identifier, topResult.confidence))
            }

            // Perform the request on a background queue to not block the main thread
            // This is especially important for AppKit apps.
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try handler.perform([request])
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    enum ImageClassificationError: Error, LocalizedError {
        case invalidImage
        var errorDescription: String? {
            switch self {
            case .invalidImage: return "Could not load or convert image."
            }
        }
    }
}

// Example usage for a macOS command-line tool:
// @main
// struct ClassifierCLI {
//     static func main() async {
//         guard CommandLine.arguments.count > 1 else {
//             print("Usage: \(CommandLine.arguments[0]) <image_path>")
//             return
//         }
//         let imagePath = CommandLine.arguments[1]
//         let imageURL = URL(fileURLWithPath: imagePath)

//         do {
//             let classifier = try await DocumentClassifier()
//             if let (type, confidence) = try await classifier.classifyImage(at: imageURL) {
//                 print("Predicted Document Type: \(type) (Confidence: \(String(format: "%.2f", confidence * 100))%)")
//             } else {
//                 print("Could not classify the image.")
//             }
//         } catch {
//             print("Error: \(error.localizedDescription)")
//         }
//     }
// }
