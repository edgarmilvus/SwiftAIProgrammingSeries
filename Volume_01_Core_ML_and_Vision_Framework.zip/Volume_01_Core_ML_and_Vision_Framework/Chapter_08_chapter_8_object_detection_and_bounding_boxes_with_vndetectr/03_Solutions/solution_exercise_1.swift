
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Vision
import PhotosUI // For UIImagePickerController on iOS 14+

// Helper extension for coordinate conversion
extension UIImage {
    /// Returns the rect of the image within the given UIImageView's bounds,
    /// considering its contentMode.
    func rectForImageView(imageView: UIImageView) -> CGRect {
        let imageViewSize = imageView.bounds.size
        let imageSize = self.size

        let scaleWidth = imageViewSize.width / imageSize.width
        let scaleHeight = imageViewSize.height / imageSize.height

        var scale: CGFloat
        var xOffset: CGFloat = 0
        var yOffset: CGFloat = 0

        switch imageView.contentMode {
        case .scaleAspectFit:
            scale = min(scaleWidth, scaleHeight)
            xOffset = (imageViewSize.width - imageSize.width * scale) / 2.0
            yOffset = (imageViewSize.height - imageSize.height * scale) / 2.0
        case .scaleAspectFill:
            scale = max(scaleWidth, scaleHeight)
            xOffset = (imageViewSize.width - imageSize.width * scale) / 2.0
            yOffset = (imageViewSize.height - imageSize.height * scale) / 2.0
        case .center:
            scale = 1.0 // Assuming no scaling, just centering
            xOffset = (imageViewSize.width - imageSize.width) / 2.0
            yOffset = (imageViewSize.height - imageSize.height) / 2.0
        case .scaleToFill:
            // Scale to fill, no aspect ratio maintained
            return imageView.bounds
        default: // .topLeft, .topRight, etc. or .redraw
            scale = 1.0 // Default to no scaling, top-left alignment
        }

        return CGRect(x: xOffset, y: yOffset, width: imageSize.width * scale, height: imageSize.height * scale)
    }
}

class DocumentDetectionViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private let imageView = UIImageView()
    private let selectImageButton = UIButton(type: .system)
    private var overlayLayers: [CALayer] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .lightGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        selectImageButton.setTitle("Select Image", for: .normal)
        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        selectImageButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImageButton)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor, multiplier: 3/4), // Example aspect ratio

            selectImageButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    @objc private func selectImageTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }

    // MARK: - UIImagePickerControllerDelegate

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) { [weak self] in
            guard let self = self, let originalImage = info[.originalImage] as? UIImage else { return }
            self.imageView.image = originalImage
            self.detectDocument(in: originalImage)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    // MARK: - Document Detection

    private func detectDocument(in image: UIImage) {
        // Clear previous overlays
        overlayLayers.forEach { $0.removeFromSuperlayer() }
        overlayLayers.removeAll()

        guard let cgImage = image.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return
        }

        let request = VNDetectRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                print("Rectangle detection error: \(error.localizedDescription)")
                return
            }

            guard let observations = request.results as? [VNRectangleObservation],
                  let bestObservation = observations.max(by: { $0.confidence < $1.confidence }) else {
                print("No rectangles detected or could not cast results.")
                return
            }

            DispatchQueue.main.async {
                self.drawBoundingBox(for: bestObservation, on: image)
            }
        }

        // Optional: Configure request parameters
        request.minimumAspectRatio = 0.5 // Allow a wide range of aspect ratios
        request.maximumAspectRatio = 2.0
        request.minimumSize = 0.2 // Only detect rectangles that occupy at least 20% of the image area
        request.quadratureTolerance = 15 // Allow some deviation from perfect right angles
        request.maximumObservations = 1 // We only care about the most confident one

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        Task {
            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
            }
        }
    }

    private func drawBoundingBox(for observation: VNRectangleObservation, on image: UIImage) {
        guard let image = imageView.image else { return }

        // 1. Get the rect of the image within the UIImageView
        let imageRectInView = image.rectForImageView(imageView: imageView)

        // 2. Convert normalized Vision rect to image coordinates, then to view coordinates
        let normalizedBoundingBox = observation.boundingBox
        let visionRectInImageCoords = VNImageRectForNormalizedRect(normalizedBoundingBox, Int(image.size.width), Int(image.size.height))

        // Scale and offset to match the image's display within the UIImageView
        let scaledRect = CGRect(
            x: imageRectInView.origin.x + visionRectInImageCoords.origin.x * imageRectInView.width / image.size.width,
            y: imageRectInView.origin.y + (image.size.height - visionRectInImageCoords.origin.y - visionRectInImageCoords.height) * imageRectInView.height / image.size.height, // Vision Y is flipped
            width: visionRectInImageCoords.width * imageRectInView.width / image.size.width,
            height: visionRectInImageCoords.height * imageRectInView.height / image.size.height
        )

        // Draw the bounding box
        let boundingBoxLayer = CAShapeLayer()
        boundingBoxLayer.frame = scaledRect
        boundingBoxLayer.path = UIBezierPath(rect: CGRect(origin: .zero, size: scaledRect.size)).cgPath
        boundingBoxLayer.strokeColor = UIColor.red.cgColor
        boundingBoxLayer.lineWidth = 3.0
        boundingBoxLayer.fillColor = nil // No fill
        imageView.layer.addSublayer(boundingBoxLayer)
        overlayLayers.append(boundingBoxLayer)

        // Draw corner points
        let cornerPoints = [observation.topLeft, observation.topRight, observation.bottomRight, observation.bottomLeft]
        for corner in cornerPoints {
            // Convert normalized corner point to image coordinates, then to view coordinates
            let visionPointInImageCoords = VNImagePointForNormalizedPoint(corner, Int(image.size.width), Int(image.size.height))
            let scaledPoint = CGPoint(
                x: imageRectInView.origin.x + visionPointInImageCoords.x * imageRectInView.width / image.size.width,
                y: imageRectInView.origin.y + (image.size.height - visionPointInImageCoords.y) * imageRectInView.height / image.size.height // Vision Y is flipped
            )

            let circleLayer = CAShapeLayer()
            let circleRadius: CGFloat = 8.0
            circleLayer.path = UIBezierPath(ovalIn: CGRect(x: scaledPoint.x - circleRadius, y: scaledPoint.y - circleRadius, width: circleRadius * 2, height: circleRadius * 2)).cgPath
            circleLayer.fillColor = UIColor.blue.cgColor
            imageView.layer.addSublayer(circleLayer)
            overlayLayers.append(circleLayer)
        }
    }
}
