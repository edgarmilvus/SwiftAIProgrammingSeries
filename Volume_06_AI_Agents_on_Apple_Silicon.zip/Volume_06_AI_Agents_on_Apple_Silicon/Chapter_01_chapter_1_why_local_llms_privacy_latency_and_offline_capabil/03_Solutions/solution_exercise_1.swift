
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// A utility for redacting sensitive information from text locally.
@available(iOS 18.0, macOS 15.0, *)
struct SensitiveDataRedactor {

    // MARK: - Regular Expression Patterns

    /// Regex for email addresses.
    /// This pattern is robust enough for common email formats.
    private static let emailPattern = #"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"#

    /// Regex for common phone number formats (e.g., (123) 456-7890, 123-456-7890, 123.456.7890, +1 123 456 7890).
    /// This pattern tries to capture various common formats including optional country code and separators.
    private static let phonePattern = #"\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"#

    /// Regex for 16-digit credit card numbers (simplified for exercise).
    /// This pattern looks for four groups of four digits, separated by space or hyphen.
    /// In a real-world scenario, more specific patterns (e.g., Luhn algorithm, specific prefixes for card types) would be used.
    private static let creditCardPattern = #"\b(?:\d{4}[- ]){3}\d{4}\b"#

    // MARK: - Redaction Method

    /// Redacts sensitive information from the given text.
    /// All processing happens strictly on-device, ensuring privacy.
    /// - Parameter text: The input string potentially containing sensitive data.
    /// - Returns: A new string with identified sensitive data redacted.
    func redactSensitiveInformation(from text: String) -> String {
        var redactedText = text

        // Apply redaction for each defined pattern sequentially.
        // The order might matter if patterns could overlap, but for these distinct types, it's generally fine.
        redactedText = redact(in: redactedText, pattern: Self.emailPattern, replacement: "[REDACTED_EMAIL]")
        redactedText = redact(in: redactedText, pattern: Self.phonePattern, replacement: "[REDACTED_PHONE]")
        redactedText = redact(in: redactedText, pattern: Self.creditCardPattern, replacement: "[REDACTED_CREDIT_CARD]")

        return redactedText
    }

    /// Helper function to perform redaction using a given regex pattern.
    /// - Parameters:
    ///   - text: The string to perform redaction on.
    ///   - pattern: The regular expression pattern to search for.
    ///   - replacement: The string to replace matched patterns with.
    /// - Returns: The modified string with matches replaced.
    private func redact(in text: String, pattern: String, replacement: String) -> String {
        do {
            // NSRegularExpression is used for powerful pattern matching and replacement.
            // .caseInsensitive option makes the pattern match regardless of case.
            let regex = try NSRegularExpression(pattern: pattern, options: .caseInsensitive)
            // Create an NSRange that covers the entire string.
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            // Perform the replacement.
            return regex.stringByReplacingMatches(in: text, options: [], range: range, withTemplate: replacement)
        } catch {
            // Log the error for debugging but return the original text to prevent data loss.
            print("Error creating regex for pattern '\(pattern)': \(error)")
            return text // Return original text if regex creation fails
        }
    }
}

// MARK: - Conceptual Unit Tests

/*
// Example of how conceptual unit tests would look:

import XCTest

@available(iOS 18.0, macOS 15.0, *)
class SensitiveDataRedactorTests: XCTestCase {

    let redactor = SensitiveDataRedactor()

    func testRedactEmail() {
        let input = "My email is test@example.com and also user.name@domain.co.uk."
        let expected = "My email is [REDACTED_EMAIL] and also [REDACTED_EMAIL]."
        XCTAssertEqual(redactor.redactSensitiveInformation(from: input), expected)
    }

    func testRedactPhoneNumber() {
        let input = "Call me at (123) 456-7890 or 123.456.7890 or +1 555 123 4567."
        let expected = "Call me at [REDACTED_PHONE] or [REDACTED_PHONE] or [REDACTED_PHONE]."
        XCTAssertEqual(redactor.redactSensitiveInformation(from: input), expected)
    }

    func testRedactCreditCard() {
        let input = "My card is 1111-2222-3333-4444 and another is 5555 6666 7777 8888."
        let expected = "My card is [REDACTED_CREDIT_CARD] and another is [REDACTED_CREDIT_CARD]."
        XCTAssertEqual(redactor.redactSensitiveInformation(from: input), expected)
    }

    func testRedactMixedData() {
        let input = "Contact john@doe.com at (987)654-3210. Card: 9999-8888-7777-6666."
        let expected = "Contact [REDACTED_EMAIL] at [REDACTED_PHONE]. Card: [REDACTED_CREDIT_CARD]."
        XCTAssertEqual(redactor.redactSensitiveInformation(from: input), expected)
    }

    func testNoSensitiveData() {
        let input = "This is a normal sentence with no sensitive information."
        XCTAssertEqual(redactor.redactSensitiveInformation(from: input), input)
    }

    func testEmptyString() {
        XCTAssertEqual(redactor.redactSensitiveInformation(from: ""), "")
    }
}
*/
