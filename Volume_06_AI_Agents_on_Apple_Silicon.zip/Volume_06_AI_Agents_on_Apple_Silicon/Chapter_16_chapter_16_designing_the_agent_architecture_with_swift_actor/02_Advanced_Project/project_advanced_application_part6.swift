
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

/// `AgentCoordinatorActor` orchestrates the entire document analysis workflow.
/// It acts as the primary interface for external requests, delegating tasks to
/// specialized actors and managing the overall state and error handling of the agent.
@available(iOS 18.0, macOS 15.0, *) // Using modern concurrency features
actor AgentCoordinatorActor {
    private let documentProcessor: DocumentProcessingActor
    private let llmInferrer: LLMInferenceActor

    /// Initializes the coordinator with references to its worker actors.
    /// - Parameters:
    ///   - documentProcessor: The actor responsible for document content extraction.
    ///   - llmInferrer: The actor responsible for LLM inference.
    init(documentProcessor: DocumentProcessingActor, llmInferrer: LLMInferenceActor) {
        self.documentProcessor = documentProcessor
        self.llmInferrer = llmInferrer
        print("[\(Date().formatted(date: .omitted, time: .standard))] AgentCoordinatorActor: Initialized.")
    }

    /// Handles a complete document analysis request from the user.
    /// This method orchestrates the document processing and LLM inference.
    /// - Parameters:
    ///   - rawDocumentData: The raw input data of the document (e.g., a PDF string).
    ///   - task: The `AnalysisTask` to perform (e.g., summarize, answer a question).
    /// - Returns: The `LLMResponse` containing the result of the analysis.
    /// - Throws: `AgentError` if any part of the process fails.
    func handleDocumentAnalysisRequest(rawDocumentData: String, task: AnalysisTask) async throws -> LLMResponse {
        print("[\(Date().formatted(date: .omitted, time: .standard))] AgentCoordinatorActor: Received document analysis request.")
        do {
            // 1. Process the document to extract content
            let documentContent = try await documentProcessor.processDocument(rawDocumentData: rawDocumentData)
            print("[\(Date().formatted(date: .omitted, time: .standard))] AgentCoordinatorActor: Document content extracted for \(documentContent.id.uuidString.prefix(8))...")

            // 2. Generate the LLM prompt based on the task and document content
            let prompt = task.generatePrompt(with: documentContent.rawText)

            // 3. Prepare the LLM request
            let llmRequest = LLMRequest(
                documentID: documentContent.id,
                prompt: prompt,
                context: documentContent.rawText, // Providing full context
                temperature: 0.7,
                maxTokens: 500
            )

            // 4. Perform LLM inference
            let llmResponse = try await llmInferrer.performInference(request: llmRequest)
            print("[\(Date().formatted(date: .omitted, time: .standard))] AgentCoordinatorActor: LLM inference completed for \(documentContent.id.uuidString.prefix(8))...")

            return llmResponse
        } catch let error as AgentError {
            // Propagate known AgentErrors
            print("[\(Date().formatted(date: .omitted, time: .standard))] AgentCoordinatorActor: Error during analysis: \(error.localizedDescription)")
            throw error
        } catch {
            // Wrap any unexpected errors
            print("[\(Date().formatted(date: .omitted, time: .standard))] AgentCoordinatorActor: An unexpected error occurred: \(error.localizedDescription)")
            throw AgentError.coordinatorError(reason: "An unexpected error occurred: \(error.localizedDescription)")
        }
    }
}
