
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    // Package.swift snippet for NaturalLanguage framework
    // No specific package needed for NaturalLanguage as it's a system framework.
    // Ensure your target links against NaturalLanguage.framework.

    import NaturalLanguage
    import CoreML // NLModel is built on CoreML

    @available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
    struct SentimentClassifier {
        private let model: NLModel

        init() throws {
            // 1. Load the compiled Core ML model (e.g., "SentimentClassifier.mlmodel")
            // This model would have been created by Create ML.
            guard let modelURL = Bundle.main.url(forResource: "SentimentClassifier", withExtension: "mlmodelc") else {
                throw SentimentClassifierError.modelNotFound
            }

            // 2. Initialize NLModel with the URL to the compiled model
            self.model = try NLModel(contentsOf: modelURL)
        }

        enum SentimentClassifierError: Error {
            case modelNotFound
            case predictionFailed(Error)
        }

        /// Classifies the sentiment of the given text.
        /// This method is designed to be asynchronous as model inference can be computationally intensive.
        func classifySentiment(for text: String) async throws -> String {
            do {
                // 3. Perform prediction using the NLModel instance
                // NLModel.predictedLabel(for:) is a synchronous method,
                // but we wrap it in a Task to demonstrate async context for larger operations.
                return await Task.detached {
                    self.model.predictedLabel(for: text) ?? "unknown"
                }.value
            } catch {
                throw SentimentClassifierError.predictionFailed(error)
            }
        }
    }
    