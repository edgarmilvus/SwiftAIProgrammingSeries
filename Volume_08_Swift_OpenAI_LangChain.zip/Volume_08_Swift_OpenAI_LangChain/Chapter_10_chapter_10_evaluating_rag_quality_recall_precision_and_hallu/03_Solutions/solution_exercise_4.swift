
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
enum GroundingStatus: Sendable {
    case supported(sourceSnippet: String)
    case unsupported
    case ambiguous
}

@available(iOS 18.0, macOS 15.0, *)
struct SentenceGrounding: Sendable {
    let text: String
    let status: GroundingStatus
}

@available(iOS 18.0, macOS 15.0, *)
actor GroundingEngine {
    let llmService: FaithfulnessService 

    init(llmService: FaithfulnessService) {
        self.llmService = llmService
    }

    func analyzeGrounding(answer: String, context: String) async throws -> [SentenceGrounding] {
        // 1. Use NLTokenizer to split 'answer' into sentences
        let tokenizer = NLTokenizer(unit: .sentence)
        tokenizer.string = answer
        
        var sentences: [String] = []
        tokenizer.enumerateTokens(in: answer.startIndex..<answer.endIndex) { range, _ in
            sentences.append(String(answer[range]))
            return true
        }
        
        // 2. Process sentences in parallel using a TaskGroup
        return try await withThrowingTaskGroup(of: SentenceGrounding.self) { group in
            for sentence in sentences {
                group.addTask {
                    // a. Call the LLM to verify the sentence
                    // We reuse the FaithfulnessService logic here
                    do {
                        let result = try await self.llmService.checkFaithfulness(context: context, answer: sentence)
                        
                        if result.isFaithful {
                            // In a real app, we'd ask the LLM to return the snippet.
                            // For this implementation, we'll simulate finding it in context.
                            return SentenceGrounding(text: sentence, status: .supported(sourceSnippet: "[Extracted Snippet]"))
                        } else {
                            return SentenceGrounding(text: sentence, status: .unsupported)
                        }
                    } catch {
                        return SentenceGrounding(text: sentence, status: .ambiguous)
                    }
                }
            }
            
            var groundedSentences: [SentenceGrounding] = []
            for try await grounding in group {
                groundedSentences.append(grounding)
            }
            
            // Note: TaskGroup doesn't guarantee order. 
            // In a production app, you'd want to sort these back to the original sentence order.
            return groundedSentences
        }
    }
}
