
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation // For @Observable

@available(iOS 18.0, macOS 15.0, *)
@Observable
class RAGViewModel {
    private let ragService: RAGService // The service holding embedding model and vector store
    private let llmService: LLMService // The LLM inference service (from previous chapters)

    var currentQuery: String = ""
    var ragResponse: String = "Ask me anything..."
    var isLoading: Bool = false
    var statusMessage: String = ""

    init(ragService: RAGService, llmService: LLMService) {
        self.ragService = ragService
        self.llmService = llmService
    }

    func performRAGQuery() async {
        guard !currentQuery.isEmpty else { return }
        isLoading = true
        statusMessage = "Searching knowledge base..."
        ragResponse = ""

        do {
            // 1. Retrieve relevant chunks
            let retrievedChunks = try await ragService.retrieveAndAugment(query: currentQuery)
            let context = retrievedChunks.joined(separator: "\n\n")

            // 2. Augment prompt
            let augmentedPrompt = """
            Based on the following context:
            \(context)

            Answer the question: \(currentQuery)
            """

            statusMessage = "Generating response with LLM..."
            // 3. Generate with LLM (assuming LLMService has a generate method)
            let llmOutput = try await llmService.generate(prompt: augmentedPrompt)
            ragResponse = llmOutput
            statusMessage = "Done."

        } catch {
            ragResponse = "Error: \(error.localizedDescription)"
            statusMessage = "Failed."
        }
        isLoading = false
    }

    // Function to initiate document indexing (e.g., from a file picker)
    func indexDocument(url: URL) async {
        isLoading = true
        statusMessage = "Indexing document..."
        do {
            let documentText = try String(contentsOf: url)
            await ragService.processDocumentForIndexing(documentText: documentText)
            statusMessage = "Document indexed successfully."
        } catch {
            statusMessage = "Failed to index document: \(error.localizedDescription)"
        }
        isLoading = false
    }
}
