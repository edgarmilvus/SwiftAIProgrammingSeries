
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CoreData

@available(iOS 18.0, *)
enum MessageRole: String, CaseIterable {
    case user, assistant, system
}

@available(iOS 18.0, *)
class Conversation: NSManagedObject {
    @NSManaged var id: UUID
    @NSManaged var title: String
    @NSManaged var lastInteraction: Date
    @NSManaged var messages: NSSet?
}

@available(iOS 18.0, *)
class Message: NSManagedObject {
    @NSManaged var text: String
    @NSManaged var role: String // Stored as String, backed by MessageRole enum
    @NSManaged var timestamp: Date
    @NSManaged var conversation: Conversation?
    
    var roleEnum: MessageRole {
        get { MessageRole(rawValue: role) ?? .user }
        set { role = newValue.rawValue }
    }
}

@available(iOS 18.0, *)
actor CoreDataStack {
    static let shared = CoreDataStack()
    let container: NSPersistentContainer

    init() {
        // In a real app, this loads the .xcdatamodeld file
        container = NSPersistentContainer(name: "LexiModel")
        container.loadPersistentStores { _, error in
            if let error = error { fatalError("Core Data failed: \(error)") }
        }
        container.viewContext.automaticallyMergesChangesFromParent = true
    }

    /// Fetches the last N messages for a specific conversation to build an AI context window.
    func fetchContextWindow(for conversationID: UUID, limit: Int) async throws -> [Message] {
        let context = container.newBackgroundContext()
        return try await context.perform {
            let request: NSFetchRequest<Message> = NSFetchRequest(entityName: "Message")
            request.predicate = NSPredicate(format: "conversation.id == %@", conversationID as CVarArg)
            // Sort by timestamp descending to get the most recent first
            request.sortDescriptors = [NSSortDescriptor(keyPath: \Message.timestamp, ascending: false)]
            request.fetchLimit = limit
            
            return try context.fetch(request)
        }
    }
}
