
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData
import NaturalLanguage
import Vision
import PDFKit

/// Custom errors encountered during the ingestion pipeline.
enum IngestionError: Error, LocalizedError {
    case extractionFailed(String)
    case embeddingGenerationFailed
    case persistenceError(String)
    case invalidDocument
    
    var errorDescription: String? {
        switch self {
        case .extractionFailed(let msg): return "Failed to extract text: \(msg)"
        case .embeddingGenerationFailed: return "Could not generate semantic embeddings."
        case .persistenceError(let msg): return "SwiftData error: \(msg)"
        case .invalidDocument: return "The provided URL does not point to a valid document."
        }
    }
}

// MARK: - Models

/// Represents a high-level document in the user's knowledge base.
@available(iOS 18.0, macOS 15.0, *)
@Model
final class ResearchDocument {
    @Attribute(.unique) var id: UUID
    var title: String
    var createdAt: Date
    var sourceURL: URL
    
    /// The relationship to the individual semantic chunks.
    /// Using cascade ensures that if a document is deleted, its chunks are also removed.
    @Relationship(deleteRule: .cascade, inverse: \TextChunk.document)
    var chunks: [TextChunk] = []
    
    init(title: String, sourceURL: URL) {
        self.id = UUID()
        self.title = title
        self.sourceURL = sourceURL
        self.createdAt = Date()
    }
}

/// Represents a granular piece of text paired with its high-dimensional vector.
@available(iOS 18.0, macOS 15.0, *)
@Model
final class TextChunk {
    var text: String
    var index: Int
    
    /// The embedding vector. Stored as an array of Floats.
    /// In a production vector database, this would be a specialized type,
    /// but for SwiftData, [Float] is the most compatible approach.
    var embedding: [Float]
    
    var document: ResearchDocument?
    
    init(text: String, index: Int, embedding: [Float]) {
        self.text = text
        self.index = index
        self.embedding = embedding
    }
}

// MARK: - Ingestion Engine

/// A specialized Actor that handles the heavy lifting of document processing.
/// By conforming to `ModelActor`, we ensure all SwiftData operations happen 
/// on a private background executor, preventing UI hangs and data races.
@available(iOS 18.0, macOS 15.0, *)
@ModelActor
actor DocumentIngestionActor {
    
    /// Configuration for the chunking strategy.
    struct IngestionConfig {
        let chunkSize: Int = 500 // Characters per chunk
        let overlap: Int = 100   // Overlap to preserve context
    }
    
    private let config = IngestionConfig()

    /// The primary entry point for ingesting a new document.
    /// - Parameter url: The local file URL of the document.
    /// - Throws: `IngestionError` if any stage of the pipeline fails.
    func ingest(documentURL: URL) async throws {
        // 1. Extraction Stage
        let rawText = try await extractText(from: documentURL)
        
        // 2. Create the parent ResearchDocument in the actor's context
        let document = ResearchDocument(
            title: documentURL.lastPathComponent,
            sourceURL: documentURL
        )
        modelContext.insert(document)
        
        // 3. Chunking & Embedding Stage
        let chunks = segmentAndEmbed(text: rawText)
        
        // 4. Persistence Stage
        for (index, (chunkText, vector)) in chunks.enumerated() {
            let newChunk = TextChunk(text: chunkText, index: index, embedding: vector)
            newChunk.document = document
            modelContext.insert(newChunk)
        }
        
        // 5. Finalize
        try modelContext.save()
        print("Successfully ingested: \(document.title) with \(chunks.count) chunks.")
    }

    /// Extracts text from a URL using PDFKit or basic String reading.
    /// - Parameter url: The file URL.
    /// - Returns: A continuous string of text.
    private func extractText(from url: URL) async throws -> String {
        // In a real app, we would check file extensions and use Vision for OCR
        // or PDFKit for digital PDFs.
        if url.pathExtension.lowercased() == "pdf" {
            guard let pdf = PDFDocument(url: url) else {
                throw IngestionError.extractionFailed("Could not open PDF.")
            }
            let fullText = pdf.string ?? ""
            if fullText.isEmpty {
                throw IngestionError.extractionFailed("PDF contains no extractable text.")
            }
            return fullText
        } else {
            // Fallback for plain text files
            do {
                return try String(contentsOf: url, encoding: .utf8)
            } catch {
                throw IngestionError.extractionFailed(error.localizedDescription)
            }
        }
    }

    /// Performs the "Sliding Window" chunking and vectorization.
    /// - Parameter text: The full text of the document.
    /// - Returns: An array of tuples containing the text chunk and its embedding.
    private func segmentAndEmbed(text: String) -> [(String, [Float])] {
        var results: [(String, [Float])] = []
        
        // Initialize the embedding model (using NaturalLanguage framework)
        // 'sentenceTransformer' is a common high-quality embedding model type.
        guard let embeddingModel = NLEmbedding.sentenceEmbedding(for: .english) else {
            // In a real-world scenario, handle this more gracefully.
            return []
        }

        let characters = Array(text)
        var start = 0
        
        while start < characters.count {
            let end = min(start + config.chunkSize, characters.count)
            let chunkRange = start..<end
            let chunkString = String(characters[chunkRange])
            
            // Generate the vector for the chunk
            if let vector = embeddingModel.vector(for: chunkString) {
                results.append((chunkString, vector))
            }
            
            // Move the window forward, but subtract the overlap to maintain context
            start += (config.chunkSize - config.overlap)
            
            // Safety break to prevent infinite loops
            if start >= characters.count || config.overlap >= config.chunkSize {
                break
            }
        }
        
        return results
    }
    
    /// Performs a semantic search across all ingested chunks.
    /// - Parameters:
    ///   - query: The natural language string to search for.
    ///   - limit: The number of top results to return.
    /// - Returns: An array of `TextChunk` objects ordered by similarity.
    func semanticSearch(query: String, limit: Int = 5) throws -> [TextChunk] {
        guard let embeddingModel = NLEmbedding.sentenceEmbedding(for: .english),
              let queryVector = embeddingModel.vector(for: query) else {
            return []
        }
        
        // Fetch all chunks (In a real-world app, we'd use a more efficient 
        // vector index, but here we demonstrate the mathematical principle).
        let descriptor = FetchDescriptor<TextChunk>(sortBy: [SortDescriptor(\.index)])
        let allChunks = try modelContext.fetch(descriptor)
        
        // Calculate Cosine Similarity for each chunk
        let scoredChunks = allChunks.map { chunk -> (TextChunk, Float) in
            let similarity = cosineSimilarity(queryVector, chunk.embedding)
            return (chunk, similarity)
        }
        
        // Sort by highest similarity and return the top N
        return scoredChunks
            .sorted { $0.1 > $1.1 }
            .prefix(limit)
            .map { $0.0 }
    }
    
    /// Mathematical implementation of Cosine Similarity.
    /// Measures the cosine of the angle between two vectors.
    /// 1.0 = identical direction; 0.0 = orthogonal; -1.0 = opposite.
    private func cosineSimilarity(_ vectorA: [Float], _ vectorB: [Float]) -> Float {
        guard vectorA.count == vectorB.count else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var normA: Float = 0.0
        var normB: Float = 0.0
        
        for i in 0..<vectorA.count {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        
        let denominator = sqrt(normA) * sqrt(normB)
        return denominator == 0 ? 0 : dotProduct / denominator
    }
}
