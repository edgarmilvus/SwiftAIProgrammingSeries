
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for demonstrating @Observable dependency
// This is conceptual for theoretical explanation, @Observable is built-in for Swift 5.9+
// and available for specific OS versions.
/*
// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AIAgentApp",
    platforms: [.macOS(.v14)], // @Observable requires macOS 14+
    products: [
        .library(
            name: "AIAgentApp",
            targets: ["AIAgentApp"]),
    ],
    targets: [
        .target(
            name: "AIAgentApp")
    ]
)
*/

@available(macOS 14.0, *) // @Observable requires macOS 14+
@Observable
class AgentState {
    var currentPrompt: String = ""
    var llmOutput: String = "Waiting for input..."
    var isLoading: Bool = false
    var conversation: [String] = []

    // This class would typically interact with the AIAgent actor
    // and update its properties based on the actor's responses.
    func sendPrompt(_ prompt: String, agent: AIAgent, model: String) async {
        isLoading = true
        defer { isLoading = false } // Ensure loading state is reset

        do {
            let response = try await agent.processPrompt(prompt, model: model)
            await MainActor.run { // Ensure UI updates on the main actor
                self.llmOutput = response
                self.conversation = await agent.getHistory() // Fetch updated history
            }
        } catch {
            await MainActor.run {
                self.llmOutput = "Error: \(error.localizedDescription)"
            }
        }
    }
}

// In a SwiftUI View:
/*
@available(macOS 14.0, *)
struct AgentView: View {
    @State private var agentState = AgentState()
    @State private var ollamaClient = OllamaClient(baseURL: URL(string: "http://localhost:11434")!)
    @State private var agent: AIAgent // Initialize with ollamaClient in .onAppear or similar

    init() {
        _agent = State(initialValue: AIAgent(ollamaClient: ollamaClient))
    }

    var body: some View {
        VStack {
            ScrollView {
                ForEach(agentState.conversation, id: \.self) { message in
                    Text(message)
                }
            }
            TextField("Enter your prompt", text: $agentState.currentPrompt)
            Button("Send") {
                Task {
                    await agentState.sendPrompt(agentState.currentPrompt, agent: agent, model: "llama2")
                    agentState.currentPrompt = ""
                }
            }
            .disabled(agentState.isLoading)
            if agentState.isLoading {
                ProgressView()
            }
        }
    }
}
*/
The `AgentState` class, marked with `@Observable`, automatically notifies SwiftUI whenever its properties change. This allows views to reactively update, displaying the LLM's output or the agent's loading status without manual binding or complex state management.

#### 4. Data Safety with `Sendable`

When passing data between asynchronous tasks, actors, or other concurrency domains, ensuring data integrity is paramount. Swift's `Sendable` protocol guarantees that a type can be safely passed across concurrency boundaries without introducing data races.

**The "Why":** In an AI agent, prompts, LLM responses, configuration objects, or even parts of the agent's memory might need to be passed between different tasks or actors. If these types are not `Sendable`, they could be simultaneously modified by different threads, leading to unpredictable behavior. Swift automatically infers `Sendable` conformance for many common types (e.g., structs with `Sendable` members, enums with `Sendable` associated values), and you can explicitly mark custom types.

