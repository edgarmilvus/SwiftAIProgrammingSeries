
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// Represents a simulated on-device Large Language Model.
/// This struct is `Sendable` by default as it contains no mutable state
/// and its properties are `Sendable`.
struct SimulatedOnDeviceLLM: Sendable {
    let modelIdentifier: String = "AppleIntelligence_LLM_v1.0"

    /// Simulates processing text with an LLM, introducing an artificial delay.
    /// - Parameter text: The input text to process.
    /// - Returns: A transformed version of the input text.
    func process(text: String) async -> String {
        print("[\(Thread.current.description)] LLM: Starting processing for: '\(text.prefix(20))...'")
        // Simulate computational intensity and delay
        try? await Task.sleep(for: .seconds(Double.random(in: 0.8...1.5)))
        let processedText = text.uppercased() + " (Processed by LLM - \(modelIdentifier))"
        print("[\(Thread.current.description)] LLM: Finished processing for: '\(text.prefix(20))...'")
        return processedText
    }
}

/// An actor that acts as a centralized manager for interacting with a simulated LLM.
actor LLMServiceActor {
    private let llm: SimulatedOnDeviceLLM
    private var requestCounter: Int = 0 // To observe serialization order

    init(llm: SimulatedOnDeviceLLM) {
        self.llm = llm
        print("LLMServiceActor initialized with model: \(llm.modelIdentifier)")
    }

    /// Transforms input text using the simulated LLM.
    /// Due to actor isolation, multiple concurrent calls to this method will be serialized.
    /// - Parameter text: The text to be transformed.
    /// - Returns: The transformed text.
    func transform(text: String) async -> String {
        requestCounter += 1 // This update is safe due to actor isolation
        let currentRequestNum = requestCounter
        print("[\(Thread.current.description)] LLMServiceActor: Request #\(currentRequestNum) received for '\(text.prefix(20))...'")

        // The call to `llm.process` happens within the actor's isolation domain.
        // Even though `llm.process` is `async` and might suspend, the actor
        // ensures that no other isolated methods run until this one completes or suspends.
        let transformedText = await llm.process(text: text)

        print("[\(Thread.current.description)] LLMServiceActor: Request #\(currentRequestNum) completed for '\(text.prefix(20))...'")
        return transformedText
    }
}

// MARK: - Concurrency Demonstration

@main
struct Exercise2 {
    static func main() async {
        let simulatedLLM = SimulatedOnDeviceLLM()
        let llmService = LLMServiceActor(llm: simulatedLLM)

        print("\n--- Starting LLMServiceActor Concurrency Demonstration ---")

        let textsToProcess = [
            "Hello, world! This is a test sentence.",
            "Summarize this paragraph for me.",
            "Translate 'Bonjour' to English.",
            "Rephrase this sentence to be more concise.",
            "What is the capital of France?",
            "Generate a short poem about nature.",
            "Analyze the sentiment of this review.",
            "Extract entities from the following text."
        ]

        let startTime = Date()

        await withTaskGroup(of: (String, String).self) { group in
            for (index, text) in textsToProcess.enumerated() {
                group.addTask {
                    // Introduce slight random delays to make the concurrent calls less predictable
                    try? await Task.sleep(for: .milliseconds(Int.random(in: 0...100)))
                    let result = await llmService.transform(text: text)
                    return (text, result)
                }
            }

            for await (originalText, transformedText) in group {
                print("[\(Thread.current.description)] Result for '\(originalText.prefix(20))...': '\(transformedText.prefix(40))...'")
            }
        }

        let endTime = Date()
        let duration = endTime.timeIntervalSince(startTime)
        print("\n--- All LLM transformation requests completed in \(String(format: "%.2f", duration)) seconds ---")
        print("Expected duration for 8 requests with ~1s delay each, if serialized, is ~8 seconds.")
    }
}
