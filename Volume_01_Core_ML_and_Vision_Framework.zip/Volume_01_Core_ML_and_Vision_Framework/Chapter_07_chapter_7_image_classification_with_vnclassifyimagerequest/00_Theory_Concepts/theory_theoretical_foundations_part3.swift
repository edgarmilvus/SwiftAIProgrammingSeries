
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Vision
import UIKit
import SwiftUI

// Assume ImageClassifierError is defined as before
@available(iOS 18.0, *)
@Observable
class ImageClassificationViewModel {
    var currentImage: UIImage?
    var classifications: [VNClassificationObservation] = []
    var isLoading: Bool = false
    var errorMessage: String?

    private let classificationRequest = VNClassifyImageRequest()

    func classifyCurrentImage() async {
        guard let image = currentImage, let cgImage = image.cgImage else {
            errorMessage = "No image available for classification."
            return
        }

        isLoading = true
        errorMessage = nil
        classifications = [] // Clear previous results

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        do {
            try await withCheckedThrowingContinuation { continuation in
                do {
                    try handler.perform([classificationRequest])
                    if let observations = classificationRequest.results as? [VNClassificationObservation] {
                        continuation.resume(returning: observations)
                    } else {
                        continuation.resume(throwing: ImageClassifier.ImageClassifierError.noResults)
                    }
                } catch {
                    continuation.resume(throwing: ImageClassifier.ImageClassifierError.classificationFailed(error))
                }
            }
            // Update @Observable properties on the main actor
            await MainActor.run {
                self.classifications = classificationRequest.results as? [VNClassificationObservation] ?? []
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
            }
        }
        await MainActor.run {
            self.isLoading = false
        }
    }
}

// Example SwiftUI View (conceptual)
/*
@available(iOS 18.0, *)
struct ClassificationView: View {
    @State private var viewModel = ImageClassificationViewModel()
    @State private var selectedImage: UIImage?

    var body: some View {
        VStack {
            if let image = viewModel.currentImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
            } else {
                Text("Select an image")
            }

            Button("Select Image") {
                // Present image picker and set viewModel.currentImage
            }
            .buttonStyle(.borderedProminent)

            Button("Classify Image") {
                Task {
                    await viewModel.classifyCurrentImage()
                }
            }
            .buttonStyle(.bordered)
            .disabled(viewModel.isLoading || viewModel.currentImage == nil)

            if viewModel.isLoading {
                ProgressView()
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundStyle(.red)
            } else if !viewModel.classifications.isEmpty {
                List(viewModel.classifications, id: \.identifier) { obs in
                    Text("\(obs.identifier) (\(obs.confidence * 100, specifier: "%.2f")%)")
                }
            }
        }
    }
}
*/
