/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// src/components/NotificationButton/NotificationButton.tsx

import React from 'react';
import { View, Text, TouchableOpacity, Platform } from 'react-native';
import { requestPermissions } from './NotificationLogic'; // Metro resolves this automatically

/**
 * @description A component that demonstrates platform-specific UI and logic.
 * - On iOS/Android: Uses a native TouchableOpacity and calls native APIs.
 * - On Web: Uses a standard HTML button and calls the browser Notification API.
 */
export const NotificationButton = () => {
  const [status, setStatus] = React.useState<string>('Idle');

  const handlePress = async () => {
    try {
      setStatus('Requesting...');
      const granted = await requestPermissions();
      setStatus(granted ? 'Permission Granted!' : 'Permission Denied');
    } catch (error) {
      setStatus('Error occurred');
      console.error(error);
    }
  };

  return (
    <View style={{ padding: 20, alignItems: 'center' }}>
      <Text style={{ marginBottom: 10, fontFamily: 'System' }}>
        Current Status: {status}
      </Text>
      
      {/* 
        We use a standard TouchableOpacity here. 
        On Web, React Native Web maps this to a <button> element.
        The logic inside `handlePress` is where the platform divergence happens.
      */}
      <TouchableOpacity
        onPress={handlePress}
        style={{
          backgroundColor: '#007AFF',
          paddingVertical: 12,
          paddingHorizontal: 24,
          borderRadius: 8,
        }}
      >
        <Text style={{ color: 'white', fontWeight: 'bold' }}>
          Enable Notifications
        </Text>
      </TouchableOpacity>
    </View>
  );
};
