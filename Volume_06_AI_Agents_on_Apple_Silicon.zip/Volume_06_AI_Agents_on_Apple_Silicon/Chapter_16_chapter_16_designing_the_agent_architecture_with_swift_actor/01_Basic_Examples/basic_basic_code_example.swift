
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// Package.swift: No special dependencies are required for this basic example
// beyond the standard Swift toolchain and Apple SDKs (Foundation, SwiftUI, Combine).

import Foundation // For basic types like String, and Task.sleep
import SwiftUI    // For the UI example
import Combine    // For ObservableObject and @Published in the ViewModel

// MARK: - 1. The Agent Actor Definition

/// `VoiceCommandProcessor` is an actor representing a core component of a voice assistant agent.
/// It encapsulates mutable state (command history, processing status) and ensures
/// that access to this state is synchronized, preventing data races.
///
/// Actors are available from iOS 15.0, macOS 12.0, tvOS 15.0, watchOS 8.0.
@available(iOS 15.0, macOS 12.0, *)
actor VoiceCommandProcessor {
    // Internal state of the agent, isolated by the actor.
    // These properties can only be accessed directly from within the actor's own methods.
    private var commandHistory: [String] = []
    private var isProcessing: Bool = false

    /// Initializes a new `VoiceCommandProcessor` actor.
    init() {
        print("VoiceCommandProcessor agent initialized.")
    }

    /// Processes a given voice command asynchronously.
    /// This method updates the agent's internal state (`commandHistory`, `isProcessing`)
    /// safely within the actor's isolated context.
    ///
    /// The `async` keyword indicates that this function can suspend its execution
    /// while awaiting other asynchronous operations (like `Task.sleep`).
    ///
    /// - Parameter command: The voice command string to process.
    /// - Returns: A `Bool` indicating if the command was successfully processed.
    func processCommand(command: String) async -> Bool {
        // Actor isolation ensures only one `processCommand` can modify `isProcessing` at a time.
        // This 'guard' statement adds an additional layer of business logic:
        // we don't want to start a new command if one is already in progress.
        guard !isProcessing else {
            print("Agent is already processing a command. Please wait.")
            return false
        }

        // Safely update the internal state. No other concurrent access is possible here.
        isProcessing = true
        print("Agent received command: \"\(command)\"")

        // Simulate a complex, asynchronous AI processing task.
        // In a real agent, this might involve calling an LLM, performing a search,
        // interacting with a Core ML model, or making a network request.
        // `await Task.sleep` suspends this actor's execution, allowing other tasks
        // (potentially even other methods on *this* actor if it were reentrant and
        // not guarded by `isProcessing`) to run, but crucially, it does *not* block
        // the underlying thread.
        try? await Task.sleep(for: .seconds(Double.random(in: 1.0...3.0))) // Simulate work

        // Safely update internal state again after the simulated work.
        commandHistory.append(command)
        isProcessing = false
        print("Agent finished processing command: \"\(command)\". History count: \(commandHistory.count)")
        return true
    }

    /// Retrieves the current command history.
    /// This method is also isolated by the actor, ensuring the history is read consistently.
    /// - Returns: An array of processed command strings.
    func getCommandHistory() async -> [String] {
        // Reading state is also isolated. The actor ensures that `commandHistory`
        // is not being modified by another task at the exact moment it's read.
        return commandHistory
    }

    /// Clears the agent's command history.
    func clearHistory() async {
        commandHistory.removeAll()
        print("Agent command history cleared.")
    }

    /// Provides the current processing status of the agent.
    func getIsProcessing() async -> Bool {
        return isProcessing
    }
}

// MARK: - 2. ViewModel for UI Interaction

/// `VoiceAssistantViewModel` acts as an intermediary between the SwiftUI View and the `VoiceCommandProcessor` actor.
/// It uses `@MainActor` to ensure all UI-related state updates happen on the main thread,
/// which is a fundamental requirement for SwiftUI and AppKit/UIKit.
/// It observes the actor's state and exposes it to the View using `@Published` properties.
@MainActor // Ensures all methods and published properties are accessed on the main actor
@available(iOS 15.0, macOS 12.0, *)
class VoiceAssistantViewModel: ObservableObject {
    // @Published properties automatically notify SwiftUI views of changes, triggering UI updates.
    @Published var commands: [String] = []
    @Published var currentCommandInput: String = ""
    @Published var isAgentBusy: Bool = false
    @Published var statusMessage: String = "Ready."

    // The actor instance managed by the ViewModel.
    // This is the bridge to our agent's core logic.
    private let agent: VoiceCommandProcessor

    /// Initializes the ViewModel with a new `VoiceCommandProcessor` instance.
    init() {
        self.agent = VoiceCommandProcessor()
        // Start a detached task to periodically update UI based on agent's state.
        // This task runs in the background and updates @Published properties on the MainActor.
        Task.detached { await self.updateAgentStatus() }
    }

    /// Sends the `currentCommandInput` to the agent for processing.
    /// This method is called from a UI action (e.g., a button tap).
    func sendCommand() {
        let commandToSend = currentCommandInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !commandToSend.isEmpty else {
            statusMessage = "Command cannot be empty."
            return
        }

        // Use a Task to call the async actor method from a synchronous context (like a button action).
        // The ViewModel itself is on the MainActor, so `Task { ... }` ensures the async work
        // doesn't block the main thread.
        Task {
            // Await the actor's state to determine if it's busy before attempting to send.
            isAgentBusy = await agent.getIsProcessing()
            guard !isAgentBusy else {
                statusMessage = "Agent is busy, please wait."
                return
            }

            statusMessage = "Sending command: '\(commandToSend)'..."
            currentCommandInput = "" // Clear input immediately for better UX

            // Await the actual processing by the agent. This is where the actor's isolation
            // and asynchronous nature shine.
            let success = await agent.processCommand(command: commandToSend)

            // Update UI based on the processing result.
            if success {
                // Fetch the updated command history from the actor.
                commands = await agent.getCommandHistory()
                statusMessage = "Command processed successfully."
            } else {
                statusMessage = "Failed to process command."
            }
            // Update the busy status after processing is complete.
            isAgentBusy = await agent.getIsProcessing()
        }
    }

    /// Clears the agent's history and updates the UI.
    func clearHistory() {
        Task {
            await agent.clearHistory() // Call the actor's method to clear its state
            commands = await agent.getCommandHistory() // Fetch the now-empty history
            statusMessage = "History cleared."
        }
    }

    /// Periodically updates the `isAgentBusy` status from the actor.
    /// This demonstrates how to observe actor state for UI updates in a simple polling manner.
    /// This method is `async` and runs in a `Task.detached` to avoid blocking the main actor.
    private func updateAgentStatus() async {
        // This task runs indefinitely to keep the UI updated.
        // In a real app, you might want more sophisticated observation (e.g., Combine publishers
        // emitted from actors, or more targeted updates, but for a basic example, polling is illustrative).
        while true {
            // Because `self` (the ViewModel) is `@MainActor`, accessing its properties
            // like `isAgentBusy` and `statusMessage` automatically hops to the main actor.
            let currentAgentBusyStatus = await agent.getIsProcessing()
            if isAgentBusy != currentAgentBusyStatus { // Only update if status changed
                isAgentBusy = currentAgentBusyStatus
                if isAgentBusy {
                    statusMessage = "Agent is busy..."
                } else {
                    statusMessage = "Ready."
                }
            }
            try? await Task.sleep(for: .seconds(0.5)) // Check every half second
        }
    }
}

// MARK: - 3. SwiftUI View

/// `VoiceAssistantView` provides the user interface for interacting with the `VoiceAssistantViewModel`.
/// It displays the command history, an input field, and a status message.
///
/// Views are available from iOS 13.0, macOS 10.15, but actors and `async/await` require iOS 15.0+.
@available(iOS 15.0, macOS 12.0, *)
struct VoiceAssistantView: View {
    // @StateObject manages the lifecycle of the ViewModel, ensuring it's created once
    // and retained for the lifetime of the view hierarchy.
    @StateObject private var viewModel = VoiceAssistantViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Voice Assistant Agent")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                TextField("Enter command...", text: $viewModel.currentCommandInput)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                    // Disable input when the agent is busy to prevent user frustration
                    .disabled(viewModel.isAgentBusy)

                Button(action: viewModel.sendCommand) {
                    Label("Send Command", systemImage: "paperplane.fill")
                }
                .buttonStyle(.borderedProminent)
                // Disable send button if input is empty or agent is busy
                .disabled(viewModel.currentCommandInput.isEmpty || viewModel.isAgentBusy)

                Button(action: viewModel.clearHistory) {
                    Label("Clear History", systemImage: "trash.fill")
                }
                .buttonStyle(.bordered)
                // Disable clear button if history is empty or agent is busy
                .disabled(viewModel.commands.isEmpty || viewModel.isAgentBusy)

                Divider()

                Text("Status: \(viewModel.statusMessage)")
                    .font(.headline)
                    .foregroundColor(viewModel.isAgentBusy ? .orange : .green)

                List {
                    Section("Command History") {
                        if viewModel.commands.isEmpty {
                            Text("No commands processed yet.")
                                .foregroundColor(.gray)
                        } else {
                            ForEach(viewModel.commands, id: \.self) { command in
                                Text(command)
                            }
                        }
                    }
                }
                .listStyle(.plain)

                Spacer()
            }
            .padding()
            .navigationTitle("Agent Demo")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - 4. App Entry Point

/// The main application structure for the SwiftUI app.
/// `@main` identifies the entry point of the application.
@available(iOS 15.0, macOS 12.0, *)
@main
struct AgentDemoApp: App {
    var body: some Scene {
        WindowGroup {
            VoiceAssistantView()
        }
    }
}
