
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
extension Array where Element == Float {
    /// Calculates the dot product of two vectors.
    func dotProduct(with other: [Float]) -> Float? {
        guard self.count == other.count else { return nil }
        return zip(self, other).map(*).reduce(0, +)
    }

    /// Calculates the magnitude (Euclidean norm) of a vector.
    var magnitude: Float {
        sqrt(self.map { $0 * $0 }.reduce(0, +))
    }

    /// Calculates the cosine similarity between two vectors.
    func cosineSimilarity(with other: [Float]) -> Float? {
        guard self.count == other.count else { return nil }

        let dot = self.dotProduct(with: other) ?? 0
        let magSelf = self.magnitude
        let magOther = other.magnitude

        // Avoid division by zero if either vector has zero magnitude
        guard magSelf > .ulpOfOne && magOther > .ulpOfOne else {
            return 0.0 // Or handle as an error if appropriate
        }

        return dot / (magSelf * magOther)
    }
}
