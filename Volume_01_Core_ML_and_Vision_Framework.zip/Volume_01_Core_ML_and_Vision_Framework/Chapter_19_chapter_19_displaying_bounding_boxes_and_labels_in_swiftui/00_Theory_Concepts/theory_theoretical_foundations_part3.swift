
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 17.0, *)
    @MainActor // Ensures all access to this class happens on the main actor
    @Observable
    class DetectionResultsViewModel {
        var detectedObjects: [DetectedObject] = [] // This property updates the UI

        func update(with observations: [VNRecognizedObjectObservation], imageSize: CGSize) {
            // This method will be executed on the MainActor
            // Transform observations and update `detectedObjects`
            self.detectedObjects = observations.map { observation in
                // ... coordinate transformation logic ...
                return DetectedObject(/* ... */)
            }
        }

        // Example of calling from an async background task
        func processImageAndDisplay(image: CGImage, model: VNCoreMLModel) async {
            let processor = ImageProcessor(model: model)
            do {
                let observations = try await processor.performDetection(on: image)
                // Jump to MainActor to update UI state
                await MainActor.run {
                    self.update(with: observations, imageSize: CGSize(width: image.width, height: image.height))
                }
            } catch {
                print("Detection failed: \(error)")
            }
        }
    }
    