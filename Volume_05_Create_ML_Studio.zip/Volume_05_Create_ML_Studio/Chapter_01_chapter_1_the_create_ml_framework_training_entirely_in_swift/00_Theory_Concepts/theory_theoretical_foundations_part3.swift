
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // For @Observable

// Placeholder types
struct MLTrainingData: Sendable {}
struct MLModel: Sendable {}
struct TrainingMetrics: Sendable {
    var epoch: Int
    var loss: Double
    var accuracy: Double
}

@available(iOS 18.0, macOS 15.0, *)
@Observable
class TrainingSession {
    var isTraining: Bool = false
    var progress: Double = 0.0 // 0.0 to 1.0
    var currentEpoch: Int = 0
    var latestLoss: Double?
    var latestAccuracy: Double?
    var statusMessage: String = "Ready to train"
    var trainedModel: MLModel?

    // An actor to encapsulate the actual training logic
    private let trainer = MLTrainer() // Assuming MLTrainer actor is defined above

    func startTrainingPipeline(data: MLTrainingData) async {
        await MainActor.run {
            self.isTraining = true
            self.progress = 0.0
            self.currentEpoch = 0
            self.latestLoss = nil
            self.latestAccuracy = nil
            self.statusMessage = "Starting training..."
            self.trainedModel = nil
        }

        do {
            // Start the actual training on the actor
            let trainingTask = Task {
                try await trainer.startTraining(data: data)
            }

            // Monitor progress and update observable properties
            while await trainer.getTrainingProgress() < 1.0 {
                await MainActor.run {
                    self.progress = await trainer.getTrainingProgress()
                    if let metrics = await trainer.getLatestMetrics() {
                        self.currentEpoch = metrics.epoch
                        self.latestLoss = metrics.loss
                        self.latestAccuracy = metrics.accuracy
                        self.statusMessage = "Epoch \(metrics.epoch) – Loss: \(String(format: "%.2f", metrics.loss)), Acc: \(String(format: "%.2f", metrics.accuracy * 100))%"
                    }
                }
                try await Task.sleep(for: .milliseconds(500)) // Update UI twice a second
            }

            // Wait for training to fully complete
            _ = await trainingTask.result

            await MainActor.run {
                self.isTraining = false
                self.progress = 1.0
                self.statusMessage = "Training complete!"
                self.trainedModel = await trainer.getTrainedModel()
            }
        } catch {
            await MainActor.run {
                self.isTraining = false
                self.statusMessage = "Training failed: \(error.localizedDescription)"
                print("Training failed: \(error)")
            }
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct TrainingView: View {
    @State private var session = TrainingSession()

    var body: some View {
        VStack(spacing: 20) {
            Text("ML Model Training")
                .font(.largeTitle)

            ProgressView(value: session.progress) {
                Text(session.statusMessage)
            } currentValueLabel: {
                Text(String(format: "%.0f%%", session.progress * 100))
            }
            .progressViewStyle(.linear)
            .padding()

            if session.isTraining {
                Text("Epoch: \(session.currentEpoch)")
                if let loss = session.latestLoss {
                    Text("Current Loss: \(String(format: "%.4f", loss))")
                }
                if let accuracy = session.latestAccuracy {
                    Text("Current Accuracy: \(String(format: "%.2f%%", accuracy * 100))")
                }
            } else if session.trainedModel != nil {
                Text("Model trained successfully!")
                    .foregroundColor(.green)
            }

            Button(session.isTraining ? "Training..." : "Start Training") {
                Task {
                    await session.startTrainingPipeline(data: MLTrainingData())
                }
            }
            .disabled(session.isTraining)
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}
