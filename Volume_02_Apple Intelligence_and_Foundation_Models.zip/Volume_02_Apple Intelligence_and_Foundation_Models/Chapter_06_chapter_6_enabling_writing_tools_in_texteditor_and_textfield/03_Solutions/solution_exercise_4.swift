
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct SecureMessageComposerView: View {
    @State private var messageContent: String = "This is a draft of the quarterly report. Please review the figures carefully."
    @State private var isConfidential: Bool = false

    // A computed property to dynamically determine the WritingToolsConfiguration
    private var messageWritingToolsConfiguration: WritingToolsConfiguration {
        if isConfidential {
            // When confidential, disable summarization and rephrasing
            return WritingToolsConfiguration.default.excluding(.summarize, .rephrase)
        } else {
            // Otherwise, enable all default tools
            return .default
        }
    }

    var body: some View {
        VStack {
            Toggle("Mark as Confidential", isOn: $isConfidential)
                .padding()
                .accessibilityLabel("Toggle to mark message as confidential")

            TextEditor(text: $messageContent)
                // Apply the conditional writingTools modifier using the computed property
                .writingTools(messageWritingToolsConfiguration)
                .border(Color.gray.opacity(0.5))
                .padding()
                .accessibilityLabel("Message Content")
        }
        .padding()
        .navigationTitle("Secure Message")
    }
}
