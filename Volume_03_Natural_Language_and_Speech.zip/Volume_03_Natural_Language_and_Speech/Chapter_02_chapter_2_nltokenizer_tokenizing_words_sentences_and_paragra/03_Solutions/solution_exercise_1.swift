
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage

/// Analyzes the given text to count the total number of words and sentences.
///
/// - Parameter text: The input string to analyze.
/// - Returns: A tuple containing `wordCount` and `sentenceCount`.
func analyzeTextStatistics(text: String) -> (wordCount: Int, sentenceCount: Int) {
    // Handle empty text as an edge case immediately.
    guard !text.isEmpty else {
        return (wordCount: 0, sentenceCount: 0)
    }

    var wordCount = 0
    var sentenceCount = 0

    // MARK: - Word Counting
    // Initialize NLTokenizer for word units.
    // NLTokenizer is efficient and handles various languages and tokenization rules.
    let wordTokenizer = NLTokenizer(unit: .word)
    wordTokenizer.string = text // Assign the string to be tokenized.

    // Enumerate over the tokens to count words.
    // The options `NLTokenizer.Options.omitWhitespace` and `.omitOther` ensure
    // we only count actual words and ignore spaces, punctuation, etc., that aren't part of a word.
    wordTokenizer.enumerateTokens(in: text.startIndex..<text.endIndex, unit: .word, using: { tokenRange, _ in
        // The closure is called for each identified word token.
        // We simply increment the counter for each valid token.
        wordCount += 1
        return true // Continue enumeration
    })

    // MARK: - Sentence Counting
    // Initialize NLTokenizer for sentence units.
    let sentenceTokenizer = NLTokenizer(unit: .sentence)
    sentenceTokenizer.string = text // Assign the string to be tokenized.

    // Enumerate over the tokens to count sentences.
    // For sentences, we typically don't need special options unless we want to filter
    // out specific types of sentence-like structures. Default behavior is usually sufficient.
    sentenceTokenizer.enumerateTokens(in: text.startIndex..<text.endIndex, unit: .sentence, using: { tokenRange, _ in
        // The closure is called for each identified sentence token.
        sentenceCount += 1
        return true // Continue enumeration
    })

    return (wordCount: wordCount, sentenceCount: sentenceCount)
}

// Example Usage:
let sampleText1 = "Hello, world! This is a test. How many words and sentences are here?"
let stats1 = analyzeTextStatistics(text: sampleText1)
print("Text 1: '\(sampleText1)'")
print("Words: \(stats1.wordCount), Sentences: \(stats1.sentenceCount)\n")
// Expected output: Words: 14, Sentences: 3

let sampleText2 = "One sentence. Two sentences!"
let stats2 = analyzeTextStatistics(text: sampleText2)
print("Text 2: '\(sampleText2)'")
print("Words: \(stats2.wordCount), Sentences: \(stats2.sentenceCount)\n")
// Expected output: Words: 4, Sentences: 2

let emptyText = ""
let statsEmpty = analyzeTextStatistics(text: emptyText)
print("Text Empty: '\(emptyText)'")
print("Words: \(statsEmpty.wordCount), Sentences: \(statsEmpty.sentenceCount)\n")
// Expected output: Words: 0, Sentences: 0

let punctuationOnly = "!!!???"
let statsPunctuation = analyzeTextStatistics(text: punctuationOnly)
print("Text Punctuation: '\(punctuationOnly)'")
print("Words: \(statsPunctuation.wordCount), Sentences: \(statsPunctuation.sentenceCount)\n")
// Expected output: Words: 0, Sentences: 1 (NLTokenizer might consider a sequence of punctuation as a sentence boundary)

let numbersAndSymbols = "123-abc. Def-456!"
let statsNumbers = analyzeTextStatistics(text: numbersAndSymbols)
print("Text Numbers: '\(numbersAndSymbols)'")
print("Words: \(statsNumbers.wordCount), Sentences: \(statsNumbers.sentenceCount)\n")
// Expected output: Words: 4 (123, abc, Def, 456), Sentences: 2
