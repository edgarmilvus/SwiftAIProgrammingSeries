
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import Speech
import AVFoundation

class WordLevelTranscriptionViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.textColor = .systemGray
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemRed
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false
        return button
    }()

    private let fullTranscriptionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        label.textColor = .label
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Full Transcription:"
        return label
    }()

    private let fullTranscriptionTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.textColor = .label
        textView.backgroundColor = .systemBackground
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "..."
        return textView
    }()

    private let wordDetailsLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        label.textColor = .label
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Word-Level Details:"
        return label
    }()

    private let wordDetailsTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.monospacedSystemFont(ofSize: 14, weight: .regular) // Monospaced for alignment
        textView.textColor = .secondaryLabel
        textView.backgroundColor = .systemBackground
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Words will appear here with timestamp, duration, and confidence."
        return textView
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestAuthorization()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopRecording()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Granular Transcription"

        let buttonStackView = UIStackView(arrangedSubviews: [startButton, stopButton])
        buttonStackView.axis = .horizontal
        buttonStackView.distribution = .fillEqually
        buttonStackView.spacing = 16
        buttonStackView.translatesAutoresizingMaskIntoConstraints = false

        let contentStackView = UIStackView(arrangedSubviews: [
            statusLabel,
            buttonStackView,
            fullTranscriptionLabel,
            fullTranscriptionTextView,
            wordDetailsLabel,
            wordDetailsTextView
        ])
        contentStackView.axis = .vertical
        contentStackView.spacing = 15
        contentStackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(contentStackView)

        NSLayoutConstraint.activate([
            contentStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            contentStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            contentStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            contentStackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            buttonStackView.heightAnchor.constraint(equalToConstant: 50),
            fullTranscriptionTextView.heightAnchor.constraint(equalToConstant: 100),
            wordDetailsTextView.heightAnchor.constraint(greaterThanOrEqualToConstant: 150) // Allow to grow
        ])

        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)
    }

    // MARK: - Speech Recognition Setup
    private func setupSpeechRecognizer() {
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        speechRecognizer?.delegate = self
    }

    // MARK: - Authorization
    private func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    let isAuthorized = (authStatus == .authorized && granted)
                    self.startButton.isEnabled = isAuthorized
                    self.stopButton.isEnabled = false // Ensure stop is disabled initially

                    if isAuthorized {
                        self.statusLabel.text = "Ready to record."
                        self.statusLabel.textColor = .systemGreen
                    } else {
                        self.statusLabel.text = "Authorization denied. Enable in Settings."
                        self.statusLabel.textColor = .systemRed
                    }
                }
            }
        }
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        if audioEngine.isRunning {
            stopRecording()
            return
        }

        do {
            try startRecording()
            startButton.isEnabled = false
            stopButton.isEnabled = true
            fullTranscriptionTextView.text = ""
            wordDetailsTextView.text = ""
            statusLabel.text = "Recording..."
            statusLabel.textColor = .systemBlue
        } catch {
            displayError(error, title: "Recording Error")
            startButton.isEnabled = true
            stopButton.isEnabled = false
            statusLabel.text = "Error starting recording."
            statusLabel.textColor = .systemRed
        }
    }

    @objc private func stopRecordingTapped() {
        stopRecording()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        statusLabel.text = "Recording stopped."
        statusLabel.textColor = .systemGray
    }

    private func startRecording() throws {
        recognitionTask?.cancel()
        recognitionTask = nil

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true

        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false
            var detailedTranscription = ""

            if let result = result {
                self.fullTranscriptionTextView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal

                // Extract and format word-level data
                for segment in result.bestTranscription.segments {
                    let confidence = String(format: "%.2f", segment.confidence)
                    let timestamp = String(format: "%.2f", segment.timestamp)
                    let duration = String(format: "%.2f", segment.duration)
                    let finalityIndicator = isFinal ? " (Final)" : " (Partial)"

                    detailedTranscription += "Word: \"\(segment.substring)\"\(finalityIndicator)\n"
                    detailedTranscription += "  Time: \(timestamp)s, Duration: \(duration)s, Confidence: \(confidence)\n\n"
                }
                self.wordDetailsTextView.text = detailedTranscription
            }

            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil

                DispatchQueue.main.async {
                    self.startButton.isEnabled = true
                    self.stopButton.isEnabled = false
                    if error != nil {
                        self.displayError(error!, title: "Speech Recognition Error")
                        self.statusLabel.text = "Error during recognition."
                        self.statusLabel.textColor = .systemRed
                    } else if isFinal {
                        self.statusLabel.text = "Transcription complete."
                        self.statusLabel.textColor = .systemGreen
                        // Ensure the final detailed transcription is shown
                        self.wordDetailsTextView.text = detailedTranscription.replacingOccurrences(of: " (Partial)", with: " (Final)")
                    }
                }
            }
        }
    }

    private func stopRecording() {
        audioEngine.stop()
        if let inputNode = audioEngine.inputNode {
            inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        DispatchQueue.main.async {
            self.startButton.isEnabled = available
            self.statusLabel.text = available ? "Ready to record." : "Speech recognition unavailable."
            self.statusLabel.textColor = available ? .systemGreen : .systemRed
        }
    }

    // MARK: - Error Handling
    private func displayError(_ error: Error, title: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
}
