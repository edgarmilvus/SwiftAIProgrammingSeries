
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog

/// Represents specific error states encountered when communicating with the OpenAI API.
/// Conforming to `LocalizedError` allows for user-friendly error messages in the UI.
enum OpenAIError: Error, LocalizedError {
    case invalidURL
    case authenticationFailed
    case rateLimitExceeded(retryAfter: TimeInterval?)
    case serverError(statusCode: Int)
    case decodingError(Error)
    case networkError(Error)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The API endpoint URL is invalid."
        case .authenticationFailed: return "API Key authentication failed. Please check your settings."
        case .rateLimitExceeded: return "Too many requests. Please wait a moment before trying again."
        case .serverError(let code): return "OpenAI server returned an error (Status: \(code))."
        case .decodingError: return "Failed to process the response from the server."
        case .networkError(let error): return "Network error: \(error.localizedDescription)"
        case .unknown(let error): return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}

/// Defines the different types of endpoints available in the OpenAI API.
/// This provides type-safety, preventing the construction of malformed URLs.
enum OpenAIEndpoint {
    case chatCompletions(model: String)
    case embeddings(model: String)

    var path: String {
        switch self {
        case .chatCompletions: return "/v1/chat/completions"
        case .embeddings: return "/v1/embeddings"
        }
    }

    var baseURL: String {
        return "https://api.openai.com"
    }

    func url(apiKey: String) throws -> URL {
        let fullString = baseURL + path
        guard let url = URL(string: fullString) else {
            throw OpenAIError.invalidURL
        }
        return url
    }
}

/// A configuration object to hold sensitive and environmental data.
/// Marked as `Sendable` to ensure it can be safely passed across concurrency boundaries.
struct OpenAIConfiguration: Sendable {
    let apiKey: String
    let maxRetries: Int
    let baseDelay: TimeInterval // Starting delay for exponential backoff
}

/// The core service actor responsible for all OpenAI interactions.
/// Using an `actor` ensures that internal state (like retry counts or session data)
/// is isolated and thread-safe in a Swift 6 environment.
@available(iOS 18.0, macOS 15.0, *)
actor OpenAIClient {
    private let config: OpenAIConfiguration
    private let logger = Logger(subsystem: "com.app.OpenAIService", category: "APIClient")
    private let session: URLSession

    /// Initializes the client with a configuration and a custom URLSession.
    /// - Parameters:
    ///   - config: The authentication and retry settings.
    ///   - session: The URLSession to use (allows for dependency injection during testing).
    init(config: OpenAIConfiguration, session: URLSession = .shared) {
        self.config = config
        self.session = session
    }

    /// Performs a Chat Completion request with built-in retry logic and exponential backoff.
    /// - Parameters:
    ///   - model: The OpenAI model identifier (e.g., "gpt-4o").
    ///   - messages: An array of message objects representing the conversation history.
    /// - Returns: A decoded `ChatCompletionResponse` object.
    func chatCompletion(model: String, messages: [[String: String]]) async throws -> ChatCompletionResponse {
        let endpoint = OpenAIEndpoint.chatCompletions(model: model)
        let url = try endpoint.url(apiKey: config.apiKey)
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(config.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let payload: [String: Any] = [
            "model": model,
            "messages": messages
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        // Execute the request with retry logic
        return try await performWithRetry(request: request, attempt: 0)
    }

    /// The private workhorse that handles the execution and the retry loop.
    /// This demonstrates the "Exponential Backoff" pattern.
    private func performWithRetry<T: Decodable>(request: URLRequest, attempt: Int) async throws -> T {
        do {
            let (data, response) = try await session.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw OpenAIError.networkError(NSError(domain: "Non-HTTP Response", code: 0))
            }

            // Handle success
            if (200...299).contains(httpResponse.statusCode) {
                do {
                    return try JSONDecoder().decode(T.self, from: data)
                } catch {
                    throw OpenAIError.decodingError(error)
                }
            }

            // Handle Rate Limiting (429)
            if httpResponse.statusCode == 429 {
                if attempt < config.maxRetries {
                    // Calculate delay: baseDelay * 2^attempt (e.g., 1s, 2s, 4s, 8s...)
                    let delay = config.baseDelay * pow(2.0, Double(attempt))
                    logger.warning("Rate limit hit. Retrying in \(delay) seconds (Attempt \(attempt + 1))")
                    
                    // Use Swift 6's ContinuousClock for precise, non-blocking sleep
                    try await Task.sleep(for: .seconds(delay))
                    return try await performWithRetry(request: request, attempt: attempt + 1)
                } else {
                    throw OpenAIError.rateLimitExceeded(retryAfter: nil)
                }
            }

            // Handle other server errors
            throw OpenAIError.serverError(statusCode: httpResponse.statusCode)

        } catch let error as OpenAIError {
            throw error
        } catch {
            // If it's a network-level error (no internet), we might also want to retry
            if attempt < config.maxRetries {
                let delay = config.baseDelay * pow(2.0, Double(attempt))
                try await Task.sleep(for: .seconds(delay))
                return try await performWithRetry(request: request, attempt: attempt + 1)
            }
            throw OpenAIError.networkError(error)
        }
    }
}

// MARK: - Supporting Models

/// Represents the expected response structure from OpenAI's Chat Completion endpoint.
struct ChatCompletionResponse: Codable, Sendable {
    let id: String
    let choices: [Choice]
    
    struct Choice: Codable, Sendable {
        let message: Message
        let finishReason: String?
        
        struct Message: Codable, Sendable {
            let role: String
            let content: String
        }
    }
}

// MARK: - Application Integration (The ViewModel)

/// A ViewModel that manages the state of a "Smart Journal" feature.
/// It interacts with the `OpenAIClient` to provide AI-driven insights.
@MainActor
class JournalViewModel: ObservableObject {
    @Published var journalEntry: String = ""
    @Published var aiInsight: String = ""
    @Published var isAnalyzing: Bool = false
    @Published var errorMessage: String?

    private let aiClient: OpenAIClient

    init(aiClient: OpenAIClient) {
        self.aiClient = aiClient
    }

    /// Triggers the AI analysis of the current journal entry.
    func analyzeMood() async {
        guard !journalEntry.isEmpty else { return }
        
        isAnalyzing = true
        errorMessage = nil
        
        let messages = [
            ["role": "system", "content": "You are a compassionate mental health assistant. Analyze the mood of the journal entry and provide a one-sentence empathetic reflection."],
            ["role": "user", "content": journalEntry]
        ]

        do {
            // The call to the actor is awaited, ensuring the UI remains responsive.
            let response = try await aiClient.chatCompletion(model: "gpt-4o", messages: messages)
            self.aiInsight = response.choices.first?.message.content ?? "No insight provided."
        } catch {
            self.errorMessage = error.localizedDescription
            self.aiInsight = ""
        }
        
        isAnalyzing = false
    }
}
