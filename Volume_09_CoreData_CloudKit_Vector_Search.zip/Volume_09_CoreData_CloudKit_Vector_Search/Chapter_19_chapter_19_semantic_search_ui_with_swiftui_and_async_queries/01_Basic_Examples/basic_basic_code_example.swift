
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation
import Foundation

// MARK: - Models

/// Represents a piece of information in our knowledge base.
/// In a real app, this would be a CoreData entity with a 'vector' attribute.
struct KnowledgeNote: Identifiable, Hashable, Sendable {
    let id: UUID
    let title: String
    let content: String
    let semanticScore: Double // Represents how close the match is (0.0 to 1.0)
}

/// Represents the various states of a semantic search operation.
enum SearchState: Equatable {
    case idle
    case searching
    case success([KnowledgeNote])
    case error(String)
}

// MARK: - Search Engine (The Actor)

/// The `SemanticSearchActor` is responsible for the heavy lifting.
/// By using an `actor`, we ensure that the vector search process is thread-safe
/// and does not block the Main Actor (the UI thread).
actor SemanticSearchActor {
    
    /// Simulates a high-dimensional vector search.
    /// - Parameter query: The natural language string provided by the user.
    /// - Returns: An array of notes sorted by semantic similarity.
    func performSemanticSearch(for query: String) async throws -> [KnowledgeNote] {
        // 1. Simulate the latency of generating an embedding via an LLM/Local Model
        // In a real app, this would call: try await embeddingModel.generate(query)
        try await Task.sleep(for: .seconds(1.5))
        
        // 2. Simulate the vector similarity search against a database
        // We are simulating a return of "conceptually related" items.
        let mockDatabase = [
            KnowledgeNote(id: UUID(), title: "Fruit Biology", content: "Apples are pomaceous fruits.", semanticScore: 0.95),
            KnowledgeNote(id: UUID(), title: "Cooking Tips", content: "How to bake an apple pie.", semanticScore: 0.88),
            KnowledgeNote(id: UUID(), title: "Tech News", content: "New smartphone released today.", semanticScore: 0.10),
            KnowledgeNote(id: UUID(), title: "Gardening", content: "Growing apple trees in spring.", semanticScore: 0.82)
        ]
        
        // 3. Filter based on the "semantic" similarity (simulated)
        // In a real app, this uses Cosine Similarity on vectors.
        let results = mockDatabase.filter { note in
            // Dummy logic: if query is in content or title, or just return all for demo
            query.lowercased().contains("apple") || query.count > 3
        }
        
        return results
    }
}

// MARK: - View Model

/// The `SearchViewModel` manages the UI state and coordinates between the View and the Actor.
/// It is marked with `@MainActor` to ensure all updates to `@Published` or `@Observable` 
/// properties occur on the main thread, preventing data races in the UI.
@Observable
@MainActor
class SearchViewModel {
    /// The current text in the search bar.
    var searchText: String = ""
    
    /// The current state of the search operation.
    var state: SearchState = .idle
    
    /// The underlying engine for semantic search.
    private let searchEngine = SemanticSearchActor()
    
    /// A reference to the currently running search task to allow for cancellation.
    private var searchTask: Task<Void, Never>?
    
    /// Initiates the search process with debouncing and cancellation logic.
    /// - Parameter query: The raw input string.
    func updateSearch(with query: String) {
        // 1. Immediate UI feedback: if query is empty, reset state.
        guard !query.trimmingCharacters(in: .whitespaces).isEmpty else {
            state = .idle
            searchText = query
            return
        }
        
        searchText = query
        
        // 2. Cancel any existing search task. 
        // This is critical for semantic search to prevent "stale" results from 
        // overwriting newer results (Race Condition).
        searchTask?.cancel()
        
        // 3. Start a new task for the debounced search.
        searchTask = Task {
            // A. Debouncing: Wait for the user to stop typing.
            // This prevents calling the expensive embedding model on every single keystroke.
            do {
                try await Task.sleep(for: .milliseconds(500))
                
                // Check if the task was cancelled during the sleep period.
                try Task.checkCancellation()
                
                // B. Set state to searching.
                state = .searching
                
                // C. Perform the actual search via the actor.
                let results = try await searchEngine.performSemanticSearch(for: query)
                
                // D. Check cancellation again before updating UI.
                try Task.checkCancellation()
                
                // E. Update state with results.
                state = .success(results)
                
            } catch is CancellationError {
                // Task was cancelled; we do nothing and let the next task take over.
                print("Search task cancelled.")
            } catch {
                // Handle actual errors (e.g., model loading failed).
                state = .error(error.localizedDescription)
            }
        }
    }
}

// MARK: - View Layer

/// The main interface for the Semantic Search functionality.
@available(iOS 18.0, *)
struct SemanticSearchView: View {
    @State private var viewModel = SearchViewModel()
    
    var body: some View {
        NavigationStack {
            VStack {
                // Search Input Area
                searchBar
                
                // Results Area
                Group {
                    switch viewModel.state {
                    case .idle:
                        ContentUnavailableView("Search for Knowledge", 
                                               systemImage: "magnifyingglass", 
                                               description: Text("Try searching for 'Apple' to see semantic results."))
                        
                    case .searching:
                        VStack(spacing: 20) {
                            ProgressView()
                                .controlSize(.large)
                            Text("Analyzing semantic meaning...")
                                .foregroundStyle(.secondary)
                                .font(.caption)
                        }
                        .frame(maxHeight: .infinity)
                        
                    case .success(let results):
                        if results.isEmpty {
                            ContentUnavailableView("No matches found", 
                                                   systemImage: "doc.text.magnifyingglass")
                        } else {
                            resultsList(results)
                        }
                        
                    case .error(let message):
                        ContentUnavailableView("Search Error", 
                                               systemImage: "exclamationmark.triangle", 
                                               description: Text(message))
                    }
                }
            }
            .navigationTitle("Smart Search")
        }
    }
    
    /// A custom search bar that triggers the ViewModel's update logic.
    private var searchBar: some View {
        TextField("Search concepts (e.g., 'fruit')...", text: $viewModel.searchText)
            .textFieldStyle(.roundedBorder)
            .padding()
            .onChange(of: viewModel.searchText) { _, newValue in
                viewModel.updateSearch(with: newValue)
            }
    }
    
    /// The list rendering logic for successful search results.
    @ViewBuilder
    private func resultsList(_ results: [KnowledgeNote]) -> some View {
        List(results) { note in
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(note.title)
                        .font(.headline)
                    Spacer()
                    // Visualizing the "Semantic Strength"
                    Text("\(Int(note.semanticScore * 100))%")
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.blue.opacity(0.1))
                        .clipShape(Capsule())
                }
                
                Text(note.content)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            .padding(.vertical, 4)
        }
        .listStyle(.plain)
    }
}

// MARK: - Preview

#Preview {
    SemanticSearchView()
}
