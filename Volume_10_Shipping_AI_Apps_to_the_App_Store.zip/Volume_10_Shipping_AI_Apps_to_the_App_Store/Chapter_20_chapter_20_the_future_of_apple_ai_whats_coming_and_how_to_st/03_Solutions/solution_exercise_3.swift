
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Vision
import CoreVideo
import Foundation

// 1. Structured data for the "Distillation" step
struct Ingredient: Sendable, CustomStringConvertible {
    let name: String
    let confidence: Float
    var description: String { "\(name) (\(Int(confidence * 100))%)" }
}

// 2. The Multimodal Coordinator
final class VisionChefCoordinator {
    
    // High-latency LLM call (simulated)
    private func performLLMInference(ingredients: [Ingredient], dietaryRestrictions: String) async throws -> String {
        let prompt = """
        Act as a professional chef. 
        Given these ingredients: \(ingredients.map { $0.description }.joined(separator: ", ")).
        User Dietary Restrictions: \(dietaryRestrictions).
        Culinary Style: Mediterranean.
        Please provide a recipe.
        """
        
        // Simulate high-latency reasoning
        try await Task.sleep(for: .seconds(3))
        return "Recipe: Mediterranean Salad using \(ingredients.first?.name ?? "unknown")."
    }

    // 3. The Pipeline: Frame -> Vision -> Distilled Text -> LLM
    func processFrame(_ pixelBuffer: CVPixelBuffer, dietaryRestrictions: String) async throws -> String {
        // Step A: Vision Analysis (High Frequency, High Priority)
        let ingredients = try await detectIngredients(in: pixelBuffer)
        
        guard !ingredients.isEmpty else {
            return "No ingredients detected. Point the camera at food."
        }
        
        // Step B: Multimodal Bridge (Distillation)
        // We don't pass the pixel buffer to the LLM; we pass the 'distilled' text.
        
        // Step C: LLM Inference (Low Frequency, Low Priority)
        return try await performLLMInference(ingredients: ingredients, dietaryRestrictions: dietaryRestrictions)
    }

    private func detectIngredients(in pixelBuffer: CVPixelBuffer) async throws -> [Ingredient] {
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNDetectRectanglesRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                
                // In a real app, you'd use a CoreML model for specific food detection.
                // Here, we simulate finding three food items.
                let simulatedResults = [
                    Ingredient(name: "Tomato", confidence: 0.95),
                    Ingredient(name: "Cucumber", confidence: 0.88),
                    Ingredient(name: "Feta Cheese", confidence: 0.75)
                ]
                continuation.resume(returning: simulatedResults)
            }
            
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

// 4. Execution with proper Task Priorities
@MainActor
func startVisionChef() {
    let coordinator = VisionChefCoordinator()
    // In a real app, this buffer comes from an AVCaptureVideoDataOutput
    let dummyBuffer = CVPixelBuffer() // Note: This would actually be a real buffer
    
    // We use a Task to prevent blocking the UI/Camera preview
    Task(priority: .userInitiated) {
        do {
            print("Scanning ingredients...")
            let recipe = try await coordinator.processFrame(dummyBuffer, dietaryRestrictions: "Vegan")
            print("Result: \(recipe)")
        } catch {
            print("Pipeline error: \(error)")
        }
    }
}
