
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreML
import Vision
import Observation

// MARK: - Models

/// Represents the result of a single object detection.
/// Conforms to Sendable to safely pass between the detection actor and the UI.
struct DetectedObject: Sendable, Identifiable {
    let id = UUID()
    let label: String
    let confidence: Float
    let boundingBox: CGRect
}

// MARK: - Detection Service

/// An actor that handles the heavy lifting of Core ML inference.
/// Using an `actor` ensures that the model instance is protected from data races
/// and that inference runs on a background thread, preserving visionOS frame rates.
@available(visionOS 1.0, *)
actor ObjectDetectionService {
    
    /// The Vision request object that wraps our Core ML model.
    private var visionRequest: VNCoreMLRequest?
    
    /// The underlying Core ML model.
    private let model: VNCoreMLModel

    /// Initializes the service by loading the Core ML model.
    /// - Throws: An error if the model fails to load or the configuration is invalid.
    init() throws {
        // 1. Configure the ML Model to utilize the Neural Engine (ANE) for maximum efficiency.
        let config = MLModelConfiguration()
        config.computeUnits = .all // Allows usage of CPU, GPU, and Neural Engine.
        
        // 2. Initialize the compiled Core ML model.
        // Note: 'ObjectClassifier' is the auto-generated class from your .mlmodel file.
        let coreMLModel = try ObjectClassifier(configuration: config).model
        
        // 3. Wrap the Core ML model in a Vision-compatible model.
        self.model = try VNCoreMLModel(for: coreMLModel)
        
        // 4. Create the Vision request.
        self.visionRequest = VNCoreMLRequest(model: self.model) { [weak self] request, error in
            // This completion handler is called when inference is complete.
            // Because this is a closure, we must handle the results carefully.
            if let error = error {
                print("Vision Error: \(error.localizedDescription)")
                return
            }
            // Results are processed in the next step of the logic.
        }
        
        // Ensure the request performs image scaling automatically to match model input.
        self.visionRequest?.imageCropAndScaleOption = .centerCrop
    }

    /// Performs inference on a provided pixel buffer.
    /// - Parameter pixelBuffer: The raw image data from the camera or ARKit.
    /// - Returns: An array of detected objects.
    func detectObjects(in pixelBuffer: CVPixelBuffer) async throws -> [DetectedObject] {
        guard let request = visionRequest else {
            throw NSError(domain: "ObjectDetectionService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Request not initialized"])
        }

        // 5. Create a request handler for the specific image buffer.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        
        // 6. Perform the request asynchronously.
        // We wrap the synchronous Vision call in a checked continuation or use the built-in async patterns.
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            do {
                try handler.perform([request])
                continuation.resume()
            } catch {
                continuation.resume(throwing: error)
            }
        }

        // 7. Extract and map the results from the Vision request.
        guard let observations = request.results as? [VNClassificationObservation] else {
            return []
        }

        return observations.map { observation in
            DetectedObject(
                label: observation.identifier,
                confidence: observation.confidence,
                boundingBox: .zero // In a classification task, bounding boxes are often not provided.
            )
        }
    }
}

// MARK: - View Model

/// The ViewModel manages the state of the UI and bridges the Actor and the View.
@Observable
@MainActor
@available(visionOS 1.0, *)
class ScannerViewModel {
    /// The list of objects currently identified in the scene.
    var detectedObjects: [DetectedObject] = []
    /// Tracks whether an inference is currently in progress.
    var isProcessing: Bool = false
    /// Error state for UI feedback.
    var errorMessage: String?

    private let detectionService: ObjectDetectionService?

    init() {
        // Initialize the service. Since it's an actor, we must handle its creation carefully.
        do {
            self.detectionService = try ObjectDetectionService()
        } catch {
            self.detectionService = nil
            self.errorMessage = "Failed to load ML Model: \(error.localizedDescription)"
        }
    }

    /// The entry point for new frames coming from the visionOS camera system.
    func processFrame(pixelBuffer: CVPixelBuffer) {
        guard let service = detectionService, !isProcessing else { return }
        
        isProcessing = true
        
        // Use a Task to bridge the synchronous UI call to the asynchronous Actor.
        Task {
            do {
                let results = try await service.detectObjects(in: pixelBuffer)
                // Update the UI on the MainActor (ensured by @MainActor on the class).
                self.detectedObjects = results
                self.isProcessing = false
            } catch {
                self.errorMessage = error.localizedDescription
                self.isProcessing = false
            }
        }
    }
}

// MARK: - UI Layer

@available(visionOS 1.0, *)
struct SpatialScannerView: View {
    @State private var viewModel = ScannerViewModel()

    var body: some View {
        VStack(spacing: 20) {
            Text("Spatial Object Scanner")
                .font(.largeTitle)
                .bold()

            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
            }

            List(viewModel.detectedObjects) { object in
                HStack {
                    Text(object.label)
                        .font(.headline)
                    Spacer()
                    Text("\(Int(object.confidence * 100))%")
                        .font(.caption)
                        .monospacedDigit()
                }
            }
            .frame(height: 300)
            .clipShape(RoundedRectangle(cornerRadius: 12))

            if viewModel.isProcessing {
                ProgressView("Analyzing Environment...")
            }
        }
        .padding()
    }
}
