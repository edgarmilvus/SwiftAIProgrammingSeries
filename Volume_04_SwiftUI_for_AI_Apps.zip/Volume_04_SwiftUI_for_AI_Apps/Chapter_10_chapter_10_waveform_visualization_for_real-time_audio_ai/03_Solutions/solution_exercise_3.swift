
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import AVFoundation

// MARK: - Circular Buffer Data Structure

struct CircularBuffer<T> {
    private var buffer: [T?]
    private var head: Int = 0 // Next write position
    private var count: Int = 0 // Number of valid elements
    let capacity: Int

    init(capacity: Int) {
        precondition(capacity > 0, "Capacity must be greater than 0")
        self.capacity = capacity
        self.buffer = Array<T?>(repeating: nil, count: capacity)
    }

    mutating func append(_ element: T) {
        buffer[head] = element
        head = (head + 1) % capacity
        if count < capacity {
            count += 1
        }
    }

    // Returns elements in chronological order (oldest to newest)
    var elements: [T] {
        if count == 0 {
            return []
        }

        var result: [T] = []
        result.reserveCapacity(count)

        if head - count >= 0 { // No wrap-around yet or head is at the end after a full cycle
            for i in (head - count)..<head {
                if let element = buffer[i] {
                    result.append(element)
                }
            }
        } else { // Wrap-around occurred
            let startIndex = (capacity + head - count) % capacity
            for i in startIndex..<capacity {
                if let element = buffer[i] {
                    result.append(element)
                }
            }
            for i in 0..<head {
                if let element = buffer[i] {
                    result.append(element)
                }
            }
        }
        return result
    }

    var isEmpty: Bool {
        return count == 0
    }

    var isFull: Bool {
        return count == capacity
    }

    mutating func removeAll() {
        buffer = Array<T?>(repeating: nil, count: capacity)
        head = 0
        count = 0
    }
}

// MARK: - Audio Input Manager with Circular Buffer

@available(iOS 18.0, *)
class AudioInputManagerWithCircularBuffer: ObservableObject {
    private let audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode!
    private var audioFormat: AVAudioFormat!

    @Published var waveformSamples: [Float] = [] // The current window of samples for display
    private var circularBuffer: CircularBuffer<Float>

    private let displaySampleCount: Int = 500 // Number of aggregated samples to display (longer window)
    private let aggregationFactor: Int = 20  // Aggregate this many raw samples into one display point

    init() {
        self.circularBuffer = CircularBuffer(capacity: displaySampleCount)
        setupAudioSession()
        setupAudioEngine()
    }

    private func setupAudioSession() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .measurement, options: [.mixWithOthers, .allowBluetoothA2DP, .defaultToSpeaker])
            try audioSession.setActive(true)
        } catch {
            print("Failed to set up audio session: \(error.localizedDescription)")
        }
    }

    private func setupAudioEngine() {
        inputNode = audioEngine.inputNode
        audioFormat = inputNode.outputFormat(forBus: 0)

        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            guard granted else {
                print("Microphone permission denied.")
                return
            }
            self?.installAudioTap()
        }
    }

    private func installAudioTap() {
        let bufferSize: AVAudioFrameCount = 1024
        inputNode.installTap(onBus: 0, bufferSize: bufferSize, format: audioFormat) { [weak self] buffer, _ in
            self?.processAudioBuffer(buffer)
        }
    }

    private func processAudioBuffer(_ buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData else { return }
        let samples = channelData[0]
        let frameLength = Int(buffer.frameLength)

        var newAggregatedSamples: [Float] = []
        for i in 0..<frameLength / aggregationFactor {
            var maxAmplitude: Float = 0.0
            for j in 0..<aggregationFactor {
                let sampleIndex = i * aggregationFactor + j
                guard sampleIndex < frameLength else { break }
                let sample = abs(samples[sampleIndex])
                if sample > maxAmplitude {
                    maxAmplitude = sample
                }
            }
            newAggregatedSamples.append(maxAmplitude)
        }

        DispatchQueue.main.async {
            for sample in newAggregatedSamples {
                self.circularBuffer.append(sample)
            }
            self.waveformSamples = self.circularBuffer.elements // Update the published array
        }
    }

    func start() {
        do {
            try audioEngine.start()
            print("Audio engine started.")
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }

    func stop() {
        audioEngine.stop()
        inputNode.removeTap(onBus: 0)
        circularBuffer.removeAll() // Clear buffer on stop
        waveformSamples = []
        print("Audio engine stopped and tap removed.")
    }

    deinit {
        stop()
    }
}

// MARK: - Scrolling Waveform View with Canvas

@available(iOS 18.0, *)
struct ScrollingWaveformView: View {
    @ObservedObject var audioManager: AudioInputManagerWithCircularBuffer
    var lineColor: Color = .blue
    var lineWidth: CGFloat = 2.0
    var isFilled: Bool = false
    var gradientFillStartColor: Color = .blue.opacity(0.8)
    var gradientFillEndColor: Color = .blue.opacity(0.2)
    
    // Smooth scaling factor transition
    @State private var currentVerticalScale: Float = 0.0

    var body: some View {
        Canvas { context, size in
            guard !audioManager.waveformSamples.isEmpty else { return }

            let width = size.width
            let height = size.height
            let midY = height / 2

            // Dynamic Vertical Scaling - calculate target scale
            let maxAmplitude = audioManager.waveformSamples.max() ?? 0.01
            let targetVerticalScale = (maxAmplitude > 0.01) ? (height / 2) / maxAmplitude : 0.0

            // Smoothly interpolate the vertical scale
            // A simple exponential moving average (EMA) can be used for smoothing
            if currentVerticalScale == 0.0 { // Initialize on first draw
                currentVerticalScale = targetVerticalScale
            } else {
                let smoothingFactor: Float = 0.1 // Adjust for faster/slower smoothing
                currentVerticalScale = currentVerticalScale * (1 - smoothingFactor) + targetVerticalScale * smoothingFactor
            }
            
            var path = Path()
            path.move(to: CGPoint(x: 0, y: midY))

            for i in 0..<audioManager.waveformSamples.count {
                let x = CGFloat(i) / CGFloat(audioManager.waveformSamples.count - 1) * width
                let y = midY - CGFloat(audioManager.waveformSamples[i]) * CGFloat(currentVerticalScale)
                path.addLine(to: CGPoint(x: x, y: y))
            }

            // If filled, close the path for filling
            if isFilled {
                path.addLine(to: CGPoint(x: width, y: midY))
                path.addLine(to: CGPoint(x: 0, y: midY))
                path.closeSubpath()
                context.fill(path, with: .linearGradient(
                    Gradient(colors: [gradientFillStartColor, gradientFillEndColor]),
                    startPoint: CGPoint(x: width / 2, y: 0),
                    endPoint: CGPoint(x: width / 2, y: height)
                ))
            } else {
                context.stroke(path, with: .color(lineColor), lineWidth: lineWidth)
            }
        }
        .frame(height: 150)
        .background(Color.black.opacity(0.8))
        .cornerRadius(8)
    }
}

// MARK: - Main Content View for Exercise 3

@available(iOS 18.0, *)
struct ContentView_Exercise3: View {
    @StateObject private var audioManager = AudioInputManagerWithCircularBuffer()
    @State private var isRecording = false

    // Customization states (can be bound to controls if desired, similar to Ex2)
    @State private var lineColor: Color = .green
    @State private var lineWidth: CGFloat = 2.0
    @State private var isFilled: Bool = true
    @State private var gradientStartColor: Color = .green.opacity(0.8)
    @State private var gradientEndColor: Color = .green.opacity(0.2)

    var body: some View {
        VStack {
            Text("Scrolling Waveform")
                .font(.largeTitle)
                .padding()

            ScrollingWaveformView(
                audioManager: audioManager,
                lineColor: lineColor,
                lineWidth: lineWidth,
                isFilled: isFilled,
                gradientFillStartColor: gradientStartColor,
                gradientFillEndColor: gradientEndColor
            )
            .padding()

            Button(action: toggleRecording) {
                Label(isRecording ? "Stop Recording" : "Start Recording", systemImage: isRecording ? "stop.fill" : "mic.fill")
                    .font(.title2)
                    .padding()
                    .background(isRecording ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding()
        }
        .onAppear {
            // audioManager.start() // Optional: start automatically
        }
        .onDisappear {
            audioManager.stop()
        }
    }

    private func toggleRecording() {
        if isRecording {
            audioManager.stop()
        } else {
            audioManager.start()
        }
        isRecording.toggle()
    }
}
