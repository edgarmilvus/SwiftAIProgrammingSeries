
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import NaturalLanguage
    import CoreML

    @available(iOS 18.0, *)
    @Observable
    class SentimentViewModel {
        var inputText: String = ""
        var sentimentResult: String = "Enter text to analyze"
        var isLoading: Bool = false
        private let analyzer: SentimentAnalyzerActor

        init(analyzer: SentimentAnalyzerActor) {
            self.analyzer = analyzer
        }

        @MainActor // Ensure UI updates on main thread
        func analyze() async {
            guard !inputText.isEmpty else {
                sentimentResult = "Please enter some text."
                return
            }
            isLoading = true
            sentimentResult = "Analyzing..."

            do {
                let result = try await analyzer.analyzeSentiment(for: inputText)
                sentimentResult = "Sentiment: \(result)"
            } catch {
                sentimentResult = "Error: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }

    @available(iOS 18.0, *)
    struct SentimentView: View {
        @State var viewModel = SentimentViewModel(analyzer: SentimentAnalyzerActor(modelName: "MyCustomSentimentModel"))

        var body: some View {
            VStack {
                TextField("Enter text here", text: $viewModel.inputText)
                    .textFieldStyle(.roundedBorder)
                    .padding()

                Button("Analyze Sentiment") {
                    Task {
                        await viewModel.analyze()
                    }
                }
                .disabled(viewModel.isLoading)

                if viewModel.isLoading {
                    ProgressView()
                } else {
                    Text(viewModel.sentimentResult)
                        .padding()
                }
            }
            .navigationTitle("Custom Sentiment")
        }
    }
    