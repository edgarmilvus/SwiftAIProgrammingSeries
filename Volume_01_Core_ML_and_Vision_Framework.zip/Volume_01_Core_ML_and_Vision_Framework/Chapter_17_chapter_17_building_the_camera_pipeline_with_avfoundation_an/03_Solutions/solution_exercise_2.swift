
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import AVFoundation
import Vision

class FaceDetectionViewController: UIViewController {

    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var videoDataOutput: AVCaptureVideoDataOutput!
    private let videoDataOutputQueue = DispatchQueue(label: "VideoDataOutput", qos: .userInitiated)

    private var faceDetectionRequest: VNDetectFaceRectanglesRequest!
    private var detectionOverlayLayers: [CAShapeLayer] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupVision()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.stopRunning()
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        // Re-layout overlay layers if bounds change
        DispatchQueue.main.async {
            self.clearDetectionOverlays()
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720

        guard let backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Unable to access back camera.")
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            }

            videoDataOutput = AVCaptureVideoDataOutput()
            videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
            videoDataOutput.alwaysDiscardsLateVideoFrames = true
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

            if captureSession.canAddOutput(videoDataOutput) {
                captureSession.addOutput(videoDataOutput)
            }

            if let connection = videoDataOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait // Set output to portrait for consistent processing
            }

            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = view.bounds
            view.layer.addSublayer(previewLayer)

        } catch {
            print("Error setting up camera input: \(error.localizedDescription)")
        }
    }

    private func setupVision() {
        faceDetectionRequest = VNDetectFaceRectanglesRequest { [weak self] request, error in
            self?.handleFaceDetection(request: request, error: error)
        }
    }

    private func handleFaceDetection(request: VNRequest, error: Error?) {
        // All UI updates must be on the main thread
        DispatchQueue.main.async {
            self.clearDetectionOverlays()

            guard let observations = request.results as? [VNFaceObservation] else {
                print("Face detection failed: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            for observation in observations {
                // Convert Vision's normalized bounding box to the preview layer's coordinate system
                let boundingBox = observation.boundingBox(in: self.previewLayer)
                let faceLayer = self.createBoundingBoxLayer(with: boundingBox)
                self.previewLayer.addSublayer(faceLayer)
                self.detectionOverlayLayers.append(faceLayer)
            }
        }
    }

    private func createBoundingBoxLayer(with rect: CGRect) -> CAShapeLayer {
        let layer = CAShapeLayer()
        layer.path = UIBezierPath(rect: rect).cgPath
        layer.strokeColor = UIColor.green.cgColor
        layer.lineWidth = 2.0
        layer.fillColor = UIColor.clear.cgColor
        return layer
    }

    private func clearDetectionOverlays() {
        for layer in detectionOverlayLayers {
            layer.removeFromSuperlayer()
        }
        detectionOverlayLayers.removeAll()
    }
}

extension FaceDetectionViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Determine the orientation of the image for Vision processing
        // This is crucial for correct analysis, especially if the device orientation changes.
        let imageOrientation = CGImagePropertyOrientation(
            interfaceOrientation: UIApplication.shared.windows.first?.windowScene?.interfaceOrientation ?? .portrait
        )

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: imageOrientation, options: [:])

        do {
            // Perform the Vision request on the background queue
            try handler.perform([faceDetectionRequest])
        } catch {
            print("Failed to perform face detection: \(error.localizedDescription)")
        }
    }
}

// MARK: - Helper Extensions

// Helper for CGImagePropertyOrientation from UIInterfaceOrientation
extension CGImagePropertyOrientation {
    init(interfaceOrientation: UIInterfaceOrientation) {
        switch interfaceOrientation {
        case .portrait: self = .up
        case .portraitUpsideDown: self = .down
        case .landscapeLeft: self = .right
        case .landscapeRight: self = .left
        default: self = .up // Default to .up for unknown or unsupported orientations
        }
    }
}

// Helper to convert Vision's normalized bounding box to CALayer coordinates
extension VNFaceObservation {
    func boundingBox(in previewLayer: AVCaptureVideoPreviewLayer) -> CGRect {
        // Vision's coordinate system is normalized (0-1), with origin at bottom-left.
        // AVCaptureVideoPreviewLayer's layerRectConverted(fromMetadataOutputRect:) expects
        // a normalized rect (0-1), with origin at top-left.
        // So, we need to flip the Y-axis for Vision's bounding box.
        let flippedBoundingBox = CGRect(
            x: boundingBox.origin.x,
            y: 1 - boundingBox.origin.y - boundingBox.height,
            width: boundingBox.width,
            height: boundingBox.height
        )
        // Convert the flipped normalized bounding box to the preview layer's coordinate system
        return previewLayer.layerRectConverted(fromMetadataOutputRect: flippedBoundingBox)
    }
}
