
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CryptoKit
import SwiftData
import Security

// MARK: - Part A: Privacy Vault

enum PrivacyZone {
    case publicZone
    case privateZone
}

actor PrivacyVault {
    private let keyTag = "com.zenith.ai.encryptionKey"
    
    /// Retrieves or generates a symmetric key from the Keychain
    func getEncryptionKey() throws -> SymmetricKey {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: keyTag,
            kSecReturnData as String: true
        ]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        
        if status == errSecSuccess, let data = item as? Data {
            return SymmetricKey(data: data)
        } else {
            let newKey = SymmetricKey(size: .bits256)
            let keyData = newKey.withUnsafeBytes { Data($0) }
            let addQuery: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrAccount as String: keyTag,
                kSecValueData as String: keyData,
                kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
            ]
            SecItemAdd(addQuery as CFDictionary, nil)
            return newKey
        }
    }
    
    func encrypt(_ data: Data) throws -> Data {
        let key = try getEncryptionKey()
        let sealedBox = try AES.GCM.seal(data, using: key)
        return sealedBox.combined!
    }
    
    func decrypt(_ data: Data) throws -> Data {
        let key = try getEncryptionKey()
        let sealedBox = try AES.GCM.SealedBox(combined: data)
        return try AES.GCM.open(sealedBox, using: key)
    }
}

// MARK: - Part B: Global Purge Protocol

actor PurgeCoordinator {
    private let vault = PrivacyVault()
    private let fileManager = FileManager.default
    
    func executeGlobalPurge(modelContext: ModelContext) async throws {
        print("⚠️ INITIATING GLOBAL PURGE PROTOCOL ⚠️")
        
        // 1. Atomic Deletion of SwiftData (PrivateZone)
        try modelContext.delete(model: ChatInteraction.self)
        try modelContext.save()
        
        // 2. Delete Vector Embedding Files
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let files = try fileManager.contentsOfDirectory(at: appSupport, includingPropertiesForKeys: nil)
        
        for file in files where file.pathExtension == "index" || file.pathExtension == "bin" {
            try fileManager.removeItem(at: file)
        }
        
        // 3. Clear Keychain (Destroy the ability to decrypt any remaining backups)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "com.zenith.ai.encryptionKey"
        ]
        SecItemDelete(query as CFDictionary)
        
        // 4. Verification Loop
        try verifyPurge(in: appSupport)
    }
    
    private func verifyPurge(in directory: URL) throws {
        let remaining = try fileManager.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
        let vectorFiles = remaining.filter { $0.pathExtension == "index" }
        if !vectorFiles.isEmpty {
            throw NSError(domain: "PurgeError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Purge verification failed!"])
        }
        print("✅ Purge verified. No vector traces remain.")
    }
}

// MARK: - Part C: Consent Management

@Observable
final class ConsentManager {
    var essential: Bool = true
    var performance: Bool = false
    var improvement: Bool = false
    
    func updateConsent(essential: Bool, performance: Bool, improvement: Bool) {
        self.essential = essential
        self.performance = performance
        self.improvement = improvement
    }
}
