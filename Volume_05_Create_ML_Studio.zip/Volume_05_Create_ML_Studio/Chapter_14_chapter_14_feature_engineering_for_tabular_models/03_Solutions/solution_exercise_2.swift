
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CreateML

@available(macOS 14.0, iOS 18.0, *)
struct ActivitySegment: Codable {
    let activityID: String
    let heartRateBPM: Double
    let accelerometerMagnitudeMean: Double
    let accelerometerMagnitudeStdDev: Double
    let bodyWeightKG: Double
    let ageYears: Int
    let gender: String
    let segmentDurationSeconds: Int
    let caloriesBurnedPerMinute: Double
}

@available(macOS 14.0, iOS 18.0, *)
func prepareActivityData(csvURL: URL) throws -> MLDataTable {
    // Initial MLDataTable: Simulate loading from CSV
    let activityData: [String: MLDataColumn] = [
        "activityID": .init(array: ["A001", "A002", "A003", "A004", "A005"]),
        "heartRateBPM": .init(array: [70.0, 140.0, 95.0, 160.0, 80.0]),
        "accelerometerMagnitudeMean": .init(array: [0.1, 0.8, 0.3, 1.2, 0.2]),
        "accelerometerMagnitudeStdDev": .init(array: [0.05, 0.2, 0.1, 0.3, 0.08]),
        "bodyWeightKG": .init(array: [75.0, 68.0, 82.0, 60.0, 70.0]),
        "ageYears": .init(array: [25, 45, 68, 30, 55]),
        "gender": .init(array: ["Male", "Female", "Male", "Female", "Other"]),
        "segmentDurationSeconds": .init(array: [30, 30, 30, 30, 30]), // Typically constant
        "caloriesBurnedPerMinute": .init(array: [5.0, 12.0, 7.5, 18.0, 6.0])
    ]
    var dataTable = MLDataTable(dictionary: activityData)

    // 1. Binning Numerical Features
    // Discretize ageYears into age groups
    dataTable["ageGroup"] = dataTable["ageYears"].map { (age: Int) -> String in
        if age < 18 { return "Youth" }
        else if age < 65 { return "Adult" }
        else { return "Senior" }
    }
    // Bin heartRateBPM into heart rate zones
    dataTable["heartRateZone"] = dataTable["heartRateBPM"].map { (hr: Double) -> String in
        if hr < 90 { return "Resting" }
        else if hr < 130 { return "Moderate" }
        else { return "Vigorous" }
    }

    // 2. Numerical Feature Normalization
    // Normalize bodyWeightKG, accelerometerMagnitudeMean, and accelerometerMagnitudeStdDev.
    dataTable["bodyWeightKG_normalized"] = dataTable["bodyWeightKG"].normalized()
    dataTable["accelMean_normalized"] = dataTable["accelerometerMagnitudeMean"].normalized()
    dataTable["accelStdDev_normalized"] = dataTable["accelerometerMagnitudeStdDev"].normalized()

    // 3. Interaction Features
    // Combine normalized bodyWeightKG with normalized accelerometerMagnitudeMean.
    dataTable["weightActivityInteraction"] = dataTable["bodyWeightKG_normalized"] * dataTable["accelMean_normalized"]

    // segmentDurationSeconds: Since the target is "per minute", and this feature is typically constant,
    // it offers little predictive value directly for a per-minute target. It can be removed.
    // If it varied significantly and the target was total calories, it would be a crucial feature.

    // 4. Final MLDataTable for Training
    // Select relevant columns, removing original raw features that have been transformed or are not needed.
    let finalColumns = [
        "ageGroup",
        "heartRateZone",
        "gender", // Create ML handles String columns automatically
        "bodyWeightKG_normalized",
        "accelMean_normalized",
        "accelStdDev_normalized",
        "weightActivityInteraction",
        "caloriesBurnedPerMinute" // Target variable
    ]
    dataTable = dataTable[finalColumns]

    return dataTable
}

// Example usage:
if #available(macOS 14.0, iOS 18.0, *) {
    do {
        let dummyURL = URL(fileURLWithDataRepresentation: Data(), relativeTo: nil)
        let preparedTable = try prepareActivityData(csvURL: dummyURL)
        print("Prepared Activity Data Table:\n\(preparedTable.description)")
    } catch {
        print("Error preparing activity data: \(error)")
    }
} else {
    print("CreateML features require macOS 14.0 / iOS 18.0 or later.")
}
