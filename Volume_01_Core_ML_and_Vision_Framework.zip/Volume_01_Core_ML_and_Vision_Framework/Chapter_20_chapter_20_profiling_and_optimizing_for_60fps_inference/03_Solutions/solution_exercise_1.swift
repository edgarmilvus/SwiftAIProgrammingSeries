
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreML
import Vision
import Foundation
import UIKit // For UIImage and loading assets

// Assume MobileNetV2.mlmodel is included in your project
// You can download it from Apple's Core ML Models page:
// https://developer.apple.com/machine-learning/models/
// Drag MobileNetV2.mlmodel into your project, Xcode will auto-generate MobileNetV2 class.

@available(iOS 18.0, *)
class CoreMLComputeUnitComparator {

    private var model: MobileNetV2? // Replace with your chosen model
    private let warmUpInferences = 5
    private let measurementInferences = 50

    init() {
        // Model initialization is done within the performClassification function
        // to allow different MLModelConfiguration for each compute unit.
    }

    /// Creates a sample CVPixelBuffer from a UIImage.
    private func createSamplePixelBuffer(from image: UIImage, targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        var pixelBuffer: CVPixelBuffer?
        let attributes = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ] as CFDictionary

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let unwrappedPixelBuffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0)) }

        let baseAddress = CVPixelBufferGetBaseAddress(unwrappedPixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(unwrappedPixelBuffer)

        guard let context = CGContext(data: baseAddress,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: bytesPerRow,
                                      space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            return nil
        }

        context.clear(CGRect(x: 0, y: 0, width: width, height: height))
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        context.draw(image.cgImage!, in: rect)

        return unwrappedPixelBuffer
    }

    /// Performs image classification with a specified compute unit and measures average inference time.
    func performClassificationAndMeasure(pixelBuffer: CVPixelBuffer, computeUnits: MLComputeUnit) async throws -> TimeInterval {
        let config = MLModelConfiguration()
        config.computeUnits = computeUnits

        guard let model = try? MobileNetV2(configuration: config) else { // Replace with your model
            fatalError("Failed to load Core ML model for \(computeUnits).")
        }

        let vnCoreMLModel = try VNCoreMLModel(for: model.model)
        let request = VNCoreMLRequest(model: vnCoreMLModel)
        request.imageCropAndScaleOption = .centerCrop

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        // Warm-up phase
        for _ in 0..<warmUpInferences {
            try handler.perform([request])
        }

        // Measurement phase
        var totalDuration: Duration = .zero
        for _ in 0..<measurementInferences {
            let startTime = ContinuousClock().now
            try handler.perform([request])
            let endTime = ContinuousClock().now
            totalDuration += (endTime - startTime)
        }

        let averageDuration = totalDuration / Double(measurementInferences)
        print("Inference with \(computeUnits) average over \(measurementInferences) runs: \(averageDuration.formatted(.units(fractionalPart: .show(length: 6))))")

        return averageDuration.timeInterval
    }

    /// Runs the full experiment comparing different compute units.
    @MainActor
    func runExperiment() async {
        guard let sampleImage = UIImage(named: "sample_image") else { // Ensure you have a 'sample_image.jpg' in Assets
            fatalError("Sample image not found. Please add 'sample_image.jpg' to your Assets.xcassets.")
        }
        
        // MobileNetV2 expects 224x224 input
        guard let samplePixelBuffer = createSamplePixelBuffer(from: sampleImage, targetSize: CGSize(width: 224, height: 224)) else {
            fatalError("Failed to create sample CVPixelBuffer.")
        }

        print("--- Testing Core ML Compute Unit Performance ---")

        do {
            print("\n--- Testing CPU_ONLY ---")
            _ = try await performClassificationAndMeasure(pixelBuffer: samplePixelBuffer, computeUnits: .cpuOnly)

            print("\n--- Testing ALL ---")
            _ = try await performClassificationAndMeasure(pixelBuffer: samplePixelBuffer, computeUnits: .all)

            // Check if Neural Engine is available before attempting to use it
            if MLComputeUnit.neuralEngine.isAvailable {
                print("\n--- Testing NEURAL_ENGINE ---")
                _ = try await performClassificationAndMeasure(pixelBuffer: samplePixelBuffer, computeUnits: .neuralEngine)
            } else {
                print("\n--- NEURAL_ENGINE is not available on this device. Skipping test. ---")
            }
        } catch {
            print("An error occurred during the experiment: \(error)")
        }
    }
}

// To run this code, you would typically call:
/*
@available(iOS 18.0, *)
Task {
    let comparator = CoreMLComputeUnitComparator()
    await comparator.runExperiment()
}
*/
