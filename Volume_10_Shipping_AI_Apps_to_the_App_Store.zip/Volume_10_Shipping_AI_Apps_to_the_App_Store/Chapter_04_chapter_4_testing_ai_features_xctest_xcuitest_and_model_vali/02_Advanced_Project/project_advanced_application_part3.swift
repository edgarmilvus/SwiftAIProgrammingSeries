
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import Foundation

/// Represents a single test case in a "Golden Set".
struct GroundTruthEntry: Codable, Sendable {
    let imageName: String
    let expectedType: DocumentType
    let minimumConfidenceThreshold: Float
}

/// A collection of results used to calculate statistical accuracy.
struct ValidationMetrics: Sendable {
    let totalTested: Int
    let correctPredictions: Int
    let precision: Float
    let recall: Float
    let f1Score: Float
    
    var accuracy: Float {
        return totalTested > 0 ? Float(correctPredictions) / Float(totalTested) : 0
    }
}

/// An Actor responsible for aggregating metrics from multiple concurrent test runs.
/// Using an Actor ensures thread-safety when multiple tasks report results.
actor MetricsAggregator {
    private var successes: Int = 0
    private var total: Int = 0
    private var truePositives: Int = 0
    private var falsePositives: Int = 0
    private var falseNegatives: Int = 0
    
    func record(expected: DocumentType, actual: DocumentType, isCorrect: Bool) {
        total += 1
        if isCorrect {
            successes += 1
            if expected == actual { truePositives += 1 }
        } else {
            // If we predicted the wrong thing:
            if actual != .unknown { falsePositives += 1 }
            if expected != actual { falseNegatives += 1 }
        }
    }
    
    func finalize() -> ValidationMetrics {
        let precision = falsePositives + truePositives > 0 
            ? Float(truePositives) / Float(truePositives + falsePositives) 
            : 0
        let recall = falseNegatives + truePositives > 0 
            ? Float(truePositives) / Float(truePositives + falseNegatives) 
            : 0
        let f1 = (precision + recall) > 0 
            ? 2 * (precision * recall) / (precision + recall) 
            : 0
            
        return ValidationMetrics(
            totalTested: total,
            correctPredictions: successes,
            precision: precision,
            recall: recall,
            f1Score: f1
        )
    }
}
