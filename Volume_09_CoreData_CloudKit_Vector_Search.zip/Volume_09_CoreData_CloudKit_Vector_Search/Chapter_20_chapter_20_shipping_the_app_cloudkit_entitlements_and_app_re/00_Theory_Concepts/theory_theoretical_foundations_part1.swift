
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreData
import Accelerate

@available(iOS 18.0, *)
/// An actor that manages the local vector index, ensuring that 
/// semantic searches and CloudKit sync operations do not collide.
actor SemanticMemoryManager {
    private let container: NSPersistentCloudKitContainer
    private let vectorIndex: VectorIndex // Hypothetical local index
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
        self.vectorIndex = VectorIndex()
    }
    
    /// Performs a semantic search. Because this is an actor, 
    /// it provides implicit isolation from background sync writes.
    func performSearch(queryEmbedding: [Float], limit: Int) async throws -> [UUID] {
        // The actor ensures that no 'write' operation from CloudKit 
        // can occur while this 'read' is in progress.
        return try await vectorIndex.search(queryEmbedding, limit: limit)
    }
    
    /// Called when CloudKit notifies the app of a remote change.
    func integrateRemoteChanges() async throws {
        // Perform the heavy lifting of re-indexing embeddings 
        // in a thread-safe manner.
        try await container.viewContext.perform {
            // Logic to reconcile Core Data with the local Vector Index
        }
    }
}

/// A Sendable wrapper for our embeddings to ensure they can 
/// safely cross actor boundaries during the sync process.
struct SemanticRecord: Sendable, Codable {
    let id: UUID
    let text: String
    let embedding: [Float] // Arrays of Floats are Sendable
}
