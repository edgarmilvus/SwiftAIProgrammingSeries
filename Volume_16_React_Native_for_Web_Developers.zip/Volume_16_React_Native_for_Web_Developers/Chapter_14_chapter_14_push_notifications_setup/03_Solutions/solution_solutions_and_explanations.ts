/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// CLIENT-SIDE (Expo - React Native)
// File: lib/expoTokenService.ts
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

export async function registerForPushNotificationsAsync(): Promise<string | null> {
  let token: string | null = null;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      alert('Failed to get push token for push notification!');
      return null;
    }
    
    // Get the token
    token = (await Notifications.getExpoPushTokenAsync()).data;
    console.log(token);
  } else {
    alert('Must use physical device for Push Notifications');
  }

  return token;
}

// CLIENT-SIDE (Next.js Web)
// File: lib/webPushService.ts
export async function getWebPushSubscription(): Promise<PushSubscription | null> {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    console.error('Push messaging is not supported');
    return null;
  }

  const registration = await navigator.serviceWorker.ready;
  
  // Check if subscription exists
  let subscription = await registration.pushManager.getSubscription();

  if (!subscription) {
    // Create a new subscription using VAPID public key (convert to Uint8Array if needed)
    // In a real app, fetch the VAPID public key from your server
    const applicationServerKey = urlB64ToUint8Array(process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!);
    
    try {
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey,
      });
    } catch (error) {
      console.error('Failed to subscribe to push:', error);
      return null;
    }
  }

  return subscription;
}

// Helper for VAPID key conversion
function urlB64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// SERVER-SIDE (Next.js API Route)
// File: pages/api/register-token.ts (or app/api/register-token/route.ts in App Router)
import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next'; // Assuming NextAuth.js
import prisma from '../../../lib/prisma'; // Assuming Prisma ORM

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session || !session.user?.id) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const { token, type } = req.body; // type: 'expo' | 'web'

  try {
    // Upsert logic: Find existing token for this user, or create new.
    // This handles the race condition by relying on unique database constraints
    // or an atomic upsert operation.
    await prisma.pushToken.upsert({
      where: {
        userId_token: {
          userId: session.user.id,
          token: token,
        },
      },
      update: {
        lastUsed: new Date(),
        type: type,
      },
      create: {
        userId: session.user.id,
        token: token,
        type: type,
      },
    });

    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Token registration failed:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
}
