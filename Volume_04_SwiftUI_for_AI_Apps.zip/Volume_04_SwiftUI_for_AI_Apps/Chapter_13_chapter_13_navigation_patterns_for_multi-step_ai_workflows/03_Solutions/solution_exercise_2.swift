
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

// Define destination types for each tab's NavigationPath
enum SummarizerDestination: Codable, Hashable {
    case result(String)
}

enum GeneratorDestination: Codable, Hashable {
    case result(String)
}

struct MultiToolAIHubApp: App {
    var body: some Scene {
        WindowGroup {
            MultiToolAIHubView()
        }
    }
}

struct MultiToolAIHubView: View {
    var body: some View {
        TabView {
            // Tab 1: Summarizer
            SummarizerRootView()
                .tabItem {
                    Label("Summarizer", systemImage: "text.magnifyingglass")
                }

            // Tab 2: Generator
            GeneratorRootView()
                .tabItem {
                    Label("Generator", systemImage: "photo.fill.on.rectangle.fill")
                }

            // Tab 3: Code Assistant
            CodeAssistantView()
                .tabItem {
                    Label("Assistant", systemImage: "terminal.fill")
                }
        }
    }
}

// MARK: - Summarizer Tab

struct SummarizerRootView: View {
    @State private var path = NavigationPath()
    @State private var inputText: String = ""

    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 20) {
                Text("Text Summarizer")
                    .font(.title)
                
                TextEditor(text: $inputText)
                    .frame(height: 150)
                    .border(Color.gray.opacity(0.5))
                    .padding(.horizontal)
                    .overlay(
                        Text(inputText.isEmpty ? "Enter text to summarize..." : "")
                            .foregroundColor(.gray)
                            .padding(.leading, 20)
                            .allowsHitTesting(false),
                        alignment: .topLeading
                    )

                Button("Summarize") {
                    // Simulate summarization
                    let summary = inputText.isEmpty ? "No text provided for summarization." : "Summary of: '\(inputText.prefix(50))...'"
                    path.append(SummarizerDestination.result(summary))
                }
                .buttonStyle(.borderedProminent)
                .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .navigationTitle("Summarizer")
            .navigationDestination(for: SummarizerDestination.self) { destination in
                switch destination {
                case .result(let summary):
                    SummaryResultView(summary: summary)
                }
            }
        }
    }
}

struct SummaryResultView: View {
    let summary: String

    var body: some View {
        VStack {
            Text("Summarization Result")
                .font(.headline)
                .padding()
            Text(summary)
                .padding()
                .background(Color.yellow.opacity(0.1))
                .cornerRadius(8)
            Spacer()
        }
        .navigationTitle("Result")
    }
}

// MARK: - Generator Tab

struct GeneratorRootView: View {
    @State private var path = NavigationPath()
    @State private var promptText: String = ""

    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 20) {
                Text("Image Generator")
                    .font(.title)

                TextField("Enter image prompt...", text: $promptText)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button("Generate Image") {
                    // Simulate image generation
                    let imageUrl = promptText.isEmpty ? "Placeholder for no prompt" : "Image generated for: '\(promptText.prefix(50))...'"
                    path.append(GeneratorDestination.result(imageUrl))
                }
                .buttonStyle(.borderedProminent)
                .disabled(promptText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .navigationTitle("Generator")
            .navigationDestination(for: GeneratorDestination.self) { destination in
                switch destination {
                case .result(let imageUrl):
                    ImageResultView(imageUrl: imageUrl)
                }
            }
        }
    }
}

struct ImageResultView: View {
    let imageUrl: String

    var body: some View {
        VStack {
            Text("Generated Image Result")
                .font(.headline)
                .padding()
            Image(systemName: "photo.fill") // Placeholder image
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .foregroundColor(.purple)
            Text("Prompt: \(imageUrl)")
                .padding()
            Spacer()
        }
        .navigationTitle("Result")
    }
}

// MARK: - Code Assistant Tab

struct CodeAssistantView: View {
    var body: some View {
        NavigationStack { // Even static tabs can benefit from a NavigationStack for consistency
            VStack {
                Text("Welcome to Code Assistant")
                    .font(.largeTitle)
                    .padding()
                Text("Get help with your code, debug, or generate snippets.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .navigationTitle("Code Assistant")
        }
    }
}
