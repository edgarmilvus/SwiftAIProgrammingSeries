
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// MARK: - ConfidenceBar Component

struct ConfidenceBar: View {
    let confidence: Double // Value between 0.0 and 1.0
    let barColor: Color
    let height: CGFloat = 20
    let cornerRadius: CGFloat = 8

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background of the bar (unfilled portion)
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: height)

                // Filled portion of the bar
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(barColor)
                    .frame(width: geometry.size.width * CGFloat(confidence), height: height)
                    // Apply animation to the 'width' property when 'confidence' changes.
                    .animation(.easeInOut(duration: 0.5), value: confidence)
            }
        }
        .frame(height: height) // Fix the height of the GeometryReader container
    }
}

// MARK: - ContentView Integration

struct ContentView: View {
    var body: some View {
        VStack(spacing: 40) {
            Text("AI Model Confidence")
                .font(.title2)
                .fontWeight(.bold)

            // Instance of ConfidenceBar with static values
            ConfidenceBar(confidence: 0.75, barColor: .green)
                .padding(.horizontal) // Add some horizontal padding for better aesthetics
        }
    }
}

// MARK: - Preview Provider

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
