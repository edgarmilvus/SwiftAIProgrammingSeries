
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import XCTest

// 1. Data Models
struct LegalFact: Codable, Sendable {
    let fact: String
}

struct GroundTruth: Codable, Sendable {
    let inputText: String
    let expectedFacts: [LegalFact]
}

struct JudgeResponse: Codable, Sendable {
    let isAccurate: Bool
    let missingFacts: [String]
}

// 2. The Judge Actor (Concurrency Management)
actor JudgeService {
    func evaluate(summary: String, against facts: [LegalFact]) async throws -> JudgeResponse {
        // In a real app, this would perform an API call to a highly-constrained LLM
        // with a prompt like: "Return ONLY JSON: {"isAccurate": bool, "missingFacts": []}"
        
        // Simulating a Judge response
        try await Task.sleep(nanoseconds: 500_000_000)
        
        // Mock logic: If summary contains "Jan 2025", it's accurate
        if summary.contains("Jan 2025") {
            return JudgeResponse(isAccurate: true, missingFacts: [])
        } else {
            return JudgeResponse(isAccurate: false, missingFacts: ["Contract expiry date"])
        }
    }
}

// 3. The Semantic Test Suite
final class LegalEaseSemanticTests: XCTestCase {
    let judge = JudgeService()
    
    func test_summary_isFactuallyAccurate() async throws {
        // Arrange
        let groundTruth = GroundTruth(
            inputText: "The contract is valid until Jan 2025. The penalty is $500.",
            expectedFacts: [
                LegalFact(fact: "Contract expires Jan 2025"),
                LegalFact(fact: "Penalty is $500")
            ]
        )
        
        // Simulate the Worker LLM output
        let workerSummary = "This contract ends in Jan 2025 and carries a $500 penalty."
        
        // Act: Run the Judge
        let result = try await judge.evaluate(summary: workerSummary, against: groundTruth.expectedFacts)
        
        // Assert
        XCTAssertTrue(result.isAccurate, "The summary failed semantic validation. Missing: \(result.missingFacts)")
        XCTAssertEqual(result.missingFacts.count, 0)
    }
    
    // 4. Advanced: Consensus Testing (Mitigating Judge Hallucination)
    func test_summary_consensus_validation() async throws {
        let workerSummary = "The contract ends sometime in 2025."
        let facts = [LegalFact(fact: "Contract expires Jan 2025")]
        
        // We run the judge 3 times in parallel using a TaskGroup
        let consensusResult = try await withThrowingTaskGroup(of: Bool.self) { group in
            for _ in 0..<3 {
                group.addTask {
                    let res = try await self.judge.evaluate(summary: workerSummary, against: facts)
                    return res.isAccurate
                }
            }
            
            var trueVotes = 0
            for try await isAccurate in group {
                if isAccurate { trueVotes += 1 }
            }
            return trueVotes >= 2 // Majority vote (2/3)
        }
        
        XCTAssertTrue(consensusResult, "The summary failed the consensus check (majority of judges disagreed).")
    }
}
