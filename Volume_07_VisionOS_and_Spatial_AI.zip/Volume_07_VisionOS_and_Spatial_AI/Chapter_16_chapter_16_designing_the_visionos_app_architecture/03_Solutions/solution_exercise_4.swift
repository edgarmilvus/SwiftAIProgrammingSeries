
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Observation

// MARK: - 1. Domain Model
@Observable
@MainActor
final class SpatialDocument {
    var lightIntensity: Float = 1.0
    var lightPosition: SIMD3<Float> = [0, 1, 0]
    var imageLayerURL: URL?
    
    // In a real app, this would contain actual pixel/depth data
}

// MARK: - 2. Command Pattern
protocol Command {
    func execute(on document: SpatialDocument)
    func undo(on document: SpatialDocument)
}

struct MoveLightCommand: Command {
    let oldPosition: SIMD3<Float>
    let newPosition: SIMD3<Float>
    
    func execute(on document: SpatialDocument) {
        document.lightPosition = newPosition
    }
    
    func undo(on document: SpatialDocument) {
        document.lightPosition = oldPosition
    }
}

struct ChangeIntensityCommand: Command {
    let oldIntensity: Float
    let newIntensity: Float
    
    func execute(on document: SpatialDocument) {
        document.lightIntensity = newIntensity
    }
    
    func undo(on document: SpatialDocument) {
        document.lightIntensity = oldIntensity
    }
}

// MARK: - 3. Command History Manager
@MainActor
final class CommandHistoryManager: ObservableObject {
    private(set) var undoStack: [Command] = []
    private(set) var redoStack: [Command] = []
    private let document: SpatialDocument
    
    init(document: SpatialDocument) {
        self.document = document
    }
    
    func perform(command: Command) {
        command.execute(on: document)
        undoStack.append(command)
        redoStack.removeAll() // Clear redo history on new action
    }
    
    func undo() {
        guard let command = undoStack.popLast() else { return }
        command.undo(on: document)
        redoStack.append(command)
    }
    
    func redo() {
        guard let command = redoStack.popLast() else { return }
        command.execute(on: document)
        undoStack.append(command)
    }
}

// MARK: - 4. Multi-Window Architecture
@main
struct LuminaPhotoProApp: App {
    // The single instance of the document shared across all windows
    @State private var sharedDocument = SpatialDocument()
    @State private var historyManager: CommandHistoryManager?

    var body: some Scene {
        init() {
            self.historyManager = CommandHistoryManager(document: sharedDocument)
        }

        // Window 1: The 3D View (RealityView)
        WindowGroup("Photo Viewer", id: "viewer") {
            PhotoViewerView(document: sharedDocument)
        }

        // Window 2: The Controls (SwiftUI)
        WindowGroup("Controls", id: "controls") {
            ControlPanelView(document: sharedDocument, history: historyManager!)
        }
    }
}

// MARK: - Views
struct ControlPanelView: View {
    let document: SpatialDocument
    let history: CommandHistoryManager
    
    var body: some View {
        VStack {
            Text("Lighting Controls").font(.headline)
            
            Slider(value: Binding(
                get: { document.lightIntensity },
                set: { newValue in
                    let cmd = ChangeIntensityCommand(oldIntensity: document.lightIntensity, newIntensity: newValue)
                    history.perform(command: cmd)
                }
            ), in: 0...5)
            
            HStack {
                Button("Undo") { history.undo() }
                Button("Redo") { history.redo() }
            }
        }
        .padding()
    }
}

struct PhotoViewerView: View {
    let document: SpatialDocument
    
    var body: some View {
        Text("3D Rendering of \(document.lightIntensity) intensity")
            // In reality, this would be a RealityView observing the document
    }
}
