/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React from 'react';
import { 
  Text, 
  View, 
  StyleSheet, 
  Pressable,
  Platform 
} from 'react-native';

/**
 * @description A universal screen component that acts as a SaaS landing page.
 * This component uses React Native primitives (View, Text) which are 
 * mapped to native iOS/Android views or DOM elements (div, p) via 
 * React Native for Web when running in a browser.
 * 
 * @returns {JSX.Element} A styled welcome screen.
 */
export default function WelcomeScreen(): JSX.Element {
  return (
    <View style={styles.container}>
      {/* Semantic Header */}
      <View style={styles.header}>
        <Text style={styles.title}>SaaS Starter</Text>
        <Text style={styles.subtitle}>
          Built with Expo & Next.js patterns
        </Text>
      </View>

      {/* Action Area */}
      <View style={styles.content}>
        <Text style={styles.welcomeText}>
          Welcome to your universal app.
        </Text>
        
        <Pressable 
          style={styles.button}
          onPress={() => console.log('User clicked Get Started')}
        >
          <Text style={styles.buttonText}>
            {Platform.OS === 'web' ? 'Get Started (Web)' : 'Get Started (Native)'}
          </Text>
        </Pressable>
      </View>

      {/* Platform Indicator Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Running on: {Platform.OS.toUpperCase()}
        </Text>
      </View>
    </View>
  );
}

/**
 * @description StyleSheet creates an abstraction similar to CSS-in-JS.
 * Under the hood, these styles are transformed into native UI thread styles
 * or CSS stylesheets (via React Native for Web) at build time.
 */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A', // Slate 900
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    marginBottom: 40,
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#94A3B8', // Slate 400
  },
  content: {
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 18,
    color: '#E2E8F0',
    textAlign: 'center',
    marginBottom: 24,
  },
  button: {
    backgroundColor: '#3B82F6', // Blue 500
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    minWidth: 160,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  footer: {
    position: 'absolute',
    bottom: 20,
    padding: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
  },
  footerText: {
    color: '#64748B',
    fontSize: 12,
    fontWeight: '500',
  },
});
