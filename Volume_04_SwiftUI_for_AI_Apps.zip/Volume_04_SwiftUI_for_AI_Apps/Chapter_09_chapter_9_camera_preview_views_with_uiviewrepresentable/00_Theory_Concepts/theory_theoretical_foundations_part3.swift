
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    // Example: Camera and AI state exposed via @Observable
    @available(iOS 18.0, *)
    @Observable
    class CameraViewModel { // Or integrate directly into AVCameraManager actor
        var isCameraActive: Bool = false
        var latestAIResult: AIResult?
        var errorMessage: String?

        // Properties of the underlying AVCameraManager actor can be reflected here
        // Or the AVCameraManager actor can itself be @Observable (if class)
        // For an actor, you'd typically have @Published properties and then bridge them.
    }

    // In a SwiftUI View:
    struct CameraView: View {
        @State var viewModel = CameraViewModel() // Or @StateObject if class
        // ...
        var body: some View {
            VStack {
                CameraPreviewRepresentable() // Your UIViewRepresentable
                Text("Camera Active: \(viewModel.isCameraActive ? "Yes" : "No")")
                if let result = viewModel.latestAIResult {
                    Text("AI Prediction: \(result.prediction)")
                }
            }
            .task {
                // Setup camera session here via an actor
                // await cameraManager.setupSession()
                viewModel.isCameraActive = true // Update observable state
            }
        }
    }
    