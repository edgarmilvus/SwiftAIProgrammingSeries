
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// Protocol defining the requirement for any data scrubbing implementation.
protocol DataScrubbing: Sendable {
    func scrub(_ input: String) async -> String
}

/// A high-performance scrubber using Swift's Regex engine.
struct RegexScrubber: DataScrubbing {
    
    // Regex Literals (Swift 5.7+)
    private let emailRegex = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,64}/
    private let phoneRegex = /\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}/
    // Simplified Name Pattern: Looking for "Name: [Word] [Word]" or "Patient [Word]"
    private let nameRegex = /(?:Patient|Name|User):\s?([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)/

    func scrub(_ input: String) async -> String {
        // We perform the work in a detached task if the input is massive, 
        // but for standard strings, we process it directly.
        var sanitized = input
        
        // 1. Redact Emails
        sanitized = sanitized.replacing(emailRegex, with: "[EMAIL_REDACTED]")
        
        // 2. Redact Phone Numbers
        sanitized = sanitized.replacing(phoneRegex, with: "[PHONE_REDACTED]")
        
        // 3. Redact Names (using capture groups)
        // We use a more manual approach for names to preserve the label but hide the value
        sanitized = redactNames(in: sanitized)
        
        return sanitized
    }
    
    private func redactNames(in text: String) -> String {
        var result = text
        // find all matches for the name pattern
        let matches = text.ranges(of: nameRegex)
        
        for range in matches {
            // In a real app, we would use more complex logic to replace 
            // only the captured group, but for this exercise, we replace the whole match.
            result = result.replacing(range, with: "[NAME_REDACTED]")
        }
        return result
    }
}

// MARK: - Implementation Example
@MainActor
func runPrivacyDemo() async {
    let scrubber = RegexScrubber()
    let rawNote = "Patient John Doe, email: john.doe@example.com, phone: 555-0199, reported feeling unwell."
    
    print("Original: \(rawNote)")
    let cleanNote = await scrubber.scrub(rawNote)
    print("Sanitized: \(cleanNote)")
}
