
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "AIDocumentScanner",
    platforms: [
        .iOS(.v17), // Requires iOS 17 for modern SwiftUI features and async/await
        .macOS(.v14)
    ],
    products: [
        .library(
            name: "AIDocumentScanner",
            targets: ["AIDocumentScanner"]),
    ],
    dependencies: [
        // Hypothetical external AI model package for advanced text processing
        // In a real scenario, this might be a custom Core ML model wrapper or a remote API client.
        .package(url: "https://github.com/YourOrg/AIModelPackage.git", from: "1.0.0"),
        // Example for a utility library, if needed
        .package(url: "https://github.com/SomeOrg/UtilityKit.git", from: "2.1.0")
    ],
    targets: [
        .target(
            name: "AIDocumentScanner",
            dependencies: [
                .product(name: "AIModelPackage", package: "AIModelPackage"),
                .product(name: "UtilityKit", package: "UtilityKit")
            ],
            swiftSettings: [
                .enableUpcomingFeature("BareSlashRegexLiterals"),
                .enableUpcomingFeature("ConciseMagicFile"),
                .enableUpcomingFeature("ExistentialAny"),
                .enableUpcomingFeature("ForwardTrailingClosures"),
                .enableUpcomingFeature("ImplicitOpenExistentials"),
                .enableUpcomingFeature("StrictConcurrency")
            ]
        ),
        .testTarget(
            name: "AIDocumentScannerTests",
            dependencies: ["AIDocumentScanner"]),
    ]
)
