
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import MLX
import MLXNN
import Foundation // For print statements and general utility

// Ensure this code is available on the target platforms
@available(iOS 17.0, macOS 14.0, *)
final class EmbeddingExample {

    /// 1. Define a custom MLX Module for our Photo Tag Embeddings
    /// We inherit from `MLXNN.Module` to encapsulate our embedding layer
    /// and benefit from MLX's parameter management and functional transformations.
    class PhotoTagEmbedding: MLXNN.Module {
        let embeddingLayer: MLXNN.Embedding

        /// Initializes the PhotoTagEmbedding module.
        /// - Parameters:
        ///   - numEmbeddings: The total number of unique tags (vocabulary size).
        ///   - embeddingDimension: The desired dimension of each tag's embedding vector.
        init(numEmbeddings: Int, embeddingDimension: Int) {
            // Initialize the embedding layer.
            // MLXNN.Embedding creates a learnable weight matrix of shape
            // (numEmbeddings, embeddingDimension).
            self.embeddingLayer = MLXNN.Embedding(
                numEmbeddings: numEmbeddings,
                embeddingDimension: embeddingDimension
            )
            super.init() // Call the superclass initializer
        }

        /// Performs the forward pass of the embedding module.
        /// - Parameter tagIDs: An `MLXArray` containing the integer IDs of the tags to embed.
        ///                     Shape: `(batch_size,)` or `(batch_size, sequence_length)`.
        /// - Returns: An `MLXArray` containing the embeddings for the input tag IDs.
        ///            Shape: `(batch_size, embeddingDimension)` or
        ///                   `(batch_size, sequence_length, embeddingDimension)`.
        override func callAsFunction(_ tagIDs: MLXArray) -> MLXArray {
            // The call to `embeddingLayer(tagIDs)` performs the lookup.
            // MLX handles the underlying matrix multiplication or indexed lookup efficiently.
            return embeddingLayer(tagIDs)
        }
    }

    /// 2. Define a simple "loss" function for demonstration purposes.
    /// In a real application, this would be a more complex function
    /// measuring similarity, classification error, etc.
    ///
    /// This function takes the `PhotoTagEmbedding` module and an input `MLXArray`
    /// of tag IDs, computes their embeddings, and then calculates a scalar loss
    /// (e.g., the mean of the squared values of the embeddings).
    ///
    /// - Parameters:
    ///   - module: The `PhotoTagEmbedding` instance whose parameters we might want to optimize.
    ///   - tagIDs: The `MLXArray` of tag IDs to process.
    /// - Returns: A scalar `MLXArray` representing the computed loss.
    func computeDummyLoss(module: PhotoTagEmbedding, tagIDs: MLXArray) -> MLXArray {
        // Perform the forward pass to get embeddings
        let embeddings = module(tagIDs) // This is a lazy operation

        // Calculate a simple loss: mean of squared embedding values.
        // This encourages embeddings to be closer to zero, which is arbitrary
        // but demonstrates a scalar loss calculation.
        let loss = embeddings.square().mean() // Also a lazy operation
        return loss
    }

    /// 3. Main execution function to demonstrate MLX embeddings and gradients.
    func runExample() {
        print("--- MLX Swift Local Embeddings Example ---")

        // Define our vocabulary and embedding dimensions
        let numUniqueTags = 1000 // e.g., 1000 distinct photo tags
        let embeddingDim = 128   // Each tag will be represented by a 128-dimensional vector

        // 4. Initialize our PhotoTagEmbedding module
        let photoTagEmbedder = PhotoTagEmbedding(
            numEmbeddings: numUniqueTags,
            embeddingDimension: embeddingDim
        )
        print("\nInitialized PhotoTagEmbedding module with \(numUniqueTags) embeddings, each \(embeddingDim) dimensions.")
        print("Initial parameters (weights) of the embedding layer:")
        // Accessing parameters shows the underlying MLXArray.
        // The weight matrix is typically named 'weight' by convention for MLXNN.Embedding.
        if let weights = photoTagEmbedder.parameters()["embeddingLayer.weight"] {
            print("  Shape: \(weights.shape), DType: \(weights.dtype)")
            // print("  First 5 values of the first embedding vector: \(weights[0].asArray(Float.self).prefix(5))")
        }

        // 5. Prepare input data: example tag IDs
        // Let's say we have photo tags "cat", "dog", "house" corresponding to IDs 5, 12, 88.
        // We represent these as an MLXArray of integers.
        let photoTagIDs = MLXArray([5, 12, 88], dtype: .int32)
        print("\nInput Photo Tag IDs: \(photoTagIDs.asArray(Int32.self))")

        // 6. Perform a forward pass to get embeddings for the given IDs
        print("\nPerforming forward pass to get embeddings...")
        let tagEmbeddings = photoTagEmbedder(photoTagIDs) // This builds the computation graph
        print("  Embeddings computed (lazy evaluation). Shape: \(tagEmbeddings.shape)")

        // 7. Trigger actual computation and print results using `eval()`
        // MLX uses lazy evaluation. Operations like `photoTagEmbedder(photoTagIDs)`
        // only build a computation graph. `eval()` forces the computation to happen.
        MLX.eval(tagEmbeddings)
        print("  Actual embeddings (first 5 values of first embedding):")
        if let firstEmbedding = tagEmbeddings[0].asArray(Float.self).prefix(5) {
            print("    \(Array(firstEmbedding))")
        }
        print("  (Full embedding shape: \(tagEmbeddings.shape))")
        print("  Unified Memory Benefit: These embeddings are now in device memory, accessible by CPU/GPU without copies.")


        // 8. Demonstrate functional transformation: `valueAndGradient`
        // We want to calculate the loss and the gradients of this loss
        // with respect to the parameters of our `photoTagEmbedder` module.
        print("\n--- Demonstrating valueAndGradient ---")
        print("Calculating loss and gradients with respect to embedding layer weights...")

        // `valueAndGradient` is a powerful MLX function.
        // It takes a function (our `computeDummyLoss`), the parameters with respect to which
        // we want gradients (our `photoTagEmbedder.parameters()`), and the inputs to the function.
        let (lossValue, gradients) = valueAndGradient(
            computeDummyLoss,
            photoTagEmbedder.parameters(), // Gradients with respect to the module's learnable parameters
            photoTagIDs // Inputs to the loss function
        )

        // 9. Trigger computation for loss and gradients
        MLX.eval(lossValue, gradients) // Evaluate both the loss and the gradients

        print("  Computed Loss: \(lossValue.item(Float.self))")
        print("  Computed Gradients (lazy evaluation).")

        // 10. Inspect gradients
        // The gradients dictionary will contain gradients for each parameter in `photoTagEmbedder.parameters()`.
        // In our case, it's primarily `embeddingLayer.weight`.
        if let weightGradient = gradients["embeddingLayer.weight"] {
            print("  Gradients for 'embeddingLayer.weight':")
            print("    Shape: \(weightGradient.shape), DType: \(weightGradient.dtype)")
            // print("    First 5 values of the gradient for the first embedding: \(weightGradient[0].asArray(Float.self).prefix(5))")
            print("    (Gradients indicate how much each weight should change to reduce the loss.)")
        } else {
            print("  No gradients found for 'embeddingLayer.weight'. This indicates an issue or a parameter not being tracked.")
        }

        print("\n--- Example Finished ---")
    }
}

// To run the example in a Playground or an application:
@available(iOS 17.0, macOS 14.0, *)
let example = EmbeddingExample()
example.runExample()
