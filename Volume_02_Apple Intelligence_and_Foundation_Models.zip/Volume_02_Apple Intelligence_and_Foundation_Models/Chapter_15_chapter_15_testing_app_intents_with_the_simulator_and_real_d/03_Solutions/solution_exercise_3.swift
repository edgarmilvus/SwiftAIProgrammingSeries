
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import SwiftUI // For ObservableObject and @Published
import Foundation // For UUID, Date, etc.

// MARK: - Mock Data Models

struct BlogCategory: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
}

struct BlogPost: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var content: String
    var tags: [String]
    var categoryID: UUID
    var isDraft: Bool
}

class BlogStore: ObservableObject {
    static let shared = BlogStore() // Singleton for easy access

    @Published var categories: [BlogCategory] {
        didSet { saveCategories() }
    }
    @Published var posts: [BlogPost] {
        didSet { savePosts() }
    }
    @Published var recentTags: Set<String> {
        didSet { saveRecentTags() }
    }

    private init() {
        // Load existing data or initialize with defaults
        self.categories = loadCategories()
        self.posts = loadPosts()
        self.recentTags = loadRecentTags()

        if categories.isEmpty {
            let tech = BlogCategory(id: UUID(), name: "Technology")
            let lifestyle = BlogCategory(id: UUID(), name: "Lifestyle")
            let travel = BlogCategory(id: UUID(), name: "Travel")
            categories = [tech, lifestyle, travel]

            posts.append(BlogPost(id: UUID(), title: "Swift 6 Concurrency", content: "Exploring the new concurrency features...", tags: ["Swift", "iOS", "Concurrency"], categoryID: tech.id, isDraft: false))
            posts.append(BlogPost(id: UUID(), title: "My Morning Routine for Productivity", content: "A typical day in the life...", tags: ["Wellness", "Productivity"], categoryID: lifestyle.id, isDraft: false))
            posts.append(BlogPost(id: UUID(), title: "Exploring the Alps", content: "Hiking through beautiful mountains...", tags: ["Travel", "Europe", "Hiking"], categoryID: travel.id, isDraft: false))
            posts.append(BlogPost(id: UUID(), title: "Draft Idea: AI in Photography", content: "Early thoughts on AI photo editing.", tags: ["AI", "Photography"], categoryID: tech.id, isDraft: true))

            recentTags = ["Swift", "iOS", "Concurrency", "Wellness", "Productivity", "Travel", "Europe", "Hiking", "AI", "Photography", "Development"]
        }
    }

    // MARK: - Persistence Helpers
    private func saveCategories() {
        if let encoded = try? JSONEncoder().encode(categories) {
            UserDefaults.standard.set(encoded, forKey: "blogCategories")
        }
    }
    private func loadCategories() -> [BlogCategory] {
        if let data = UserDefaults.standard.data(forKey: "blogCategories"),
           let decoded = try? JSONDecoder().decode([BlogCategory].self, from: data) {
            return decoded
        }
        return []
    }
    private func savePosts() {
        if let encoded = try? JSONEncoder().encode(posts) {
            UserDefaults.standard.set(encoded, forKey: "blogPosts")
        }
    }
    private func loadPosts() -> [BlogPost] {
        if let data = UserDefaults.standard.data(forKey: "blogPosts"),
           let decoded = try? JSONDecoder().decode([BlogPost].self, from: data) {
            return decoded
        }
        return []
    }
    private func saveRecentTags() {
        UserDefaults.standard.set(Array(recentTags), forKey: "blogRecentTags")
    }
    private func loadRecentTags() -> Set<String> {
        if let tagsArray = UserDefaults.standard.stringArray(forKey: "blogRecentTags") {
            return Set(tagsArray)
        }
        return []
    }

    // MARK: - Data Operations
    func createDraftPost(title: String, tags: [String]) {
        let defaultCategory = categories.first ?? BlogCategory(id: UUID(), name: "Uncategorized")
        let newPost = BlogPost(id: UUID(), title: title, content: "", tags: tags, categoryID: defaultCategory.id, isDraft: true)
        posts.append(newPost)
        recentTags.formUnion(tags) // Update recent tags
    }

    func posts(in categoryID: UUID) -> [BlogPost] {
        posts.filter { $0.categoryID == categoryID && !$0.isDraft }
    }

    func post(for id: UUID) -> BlogPost? {
        posts.first(where: { $0.id == id })
    }

    func category(for id: UUID) -> BlogCategory? {
        categories.first(where: { $0.id == id })
    }
}

// MARK: - App Entities

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct PostEntity: AppEntity {
    let id: UUID
    let title: String
    let categoryName: String // For display
    let isDraft: Bool

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Blog Post"
    static var defaultQuery = PostQuery()

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(
            title: "\(title)",
            subtitle: "Category: \(categoryName) \(isDraft ? "(Draft)" : "")",
            image: isDraft ? DisplayRepresentation.Image("doc.text.fill", in: .system, variableValue: 0) : DisplayRepresentation.Image("doc.text", in: .system, variableValue: 0)
        )
    }

    // Initialize from BlogPost model
    init(blogPost: BlogPost, categoryName: String) {
        self.id = blogPost.id
        self.title = blogPost.title
        self.categoryName = categoryName
        self.isDraft = blogPost.isDraft
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct CategoryEntity: AppEntity {
    let id: UUID
    let name: String

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Blog Category"
    static var defaultQuery = CategoryQuery()

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(name)")
    }

    // Initialize from BlogCategory model
    init(blogCategory: BlogCategory) {
        self.id = blogCategory.id
        self.name = blogCategory.name
    }
}

// MARK: - App Entity Queries

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct PostQuery: EntityQuery {
    func entities(for identifiers: [PostEntity.ID]) async throws -> [PostEntity] {
        let blogStore = BlogStore.shared
        return identifiers.compactMap { id in
            if let blogPost = blogStore.post(for: id),
               let category = blogStore.category(for: blogPost.categoryID) {
                return PostEntity(blogPost: blogPost, categoryName: category.name)
            }
            return nil
        }
    }

    func suggestedEntities() async throws -> [PostEntity] {
        let blogStore = BlogStore.shared
        // Suggest recent non-draft posts
        return blogStore.posts
            .filter { !$0.isDraft }
            .sorted(by: { $0.title < $1.title }) // Simple sorting for consistent suggestions
            .prefix(5) // Limit suggestions
            .compactMap { blogPost in
                if let category = blogStore.category(for: blogPost.categoryID) {
                    return PostEntity(blogPost: blogPost, categoryName: category.name)
                }
                return nil
            }
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct CategoryQuery: EntityQuery {
    func entities(for identifiers: [CategoryEntity.ID]) async throws -> [CategoryEntity] {
        let blogStore = BlogStore.shared
        return identifiers.compactMap { id in
            blogStore.category(for: id).map { CategoryEntity(blogCategory: $0) }
        }
    }

    func suggestedEntities() async throws -> [CategoryEntity] {
        let blogStore = BlogStore.shared
        // Suggest all available categories
        return blogStore.categories
            .sorted(by: { $0.name < $1.name })
            .map { CategoryEntity(blogCategory: $0) }
    }
}

// MARK: - App Intents

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct CreateDraftPostIntent: AppIntent {
    static var title: LocalizedStringResource = "Create Draft Post"
    static var description = IntentDescription("Creates a new draft blog post with a title and optional tags.")

    @Parameter(title: "Post Title", description: "The title of the new draft post.")
    var postTitle: String

    @Parameter(title: "Tags", description: "Optional tags for the post.", default: [])
    var tags: [String]

    // Dynamic suggestions for tags based on recentTags in BlogStore
    static var parameterEditor: some ParameterEditor {
        ParameterEditor(keyPath: \.tags) { editor in
            editor.suggestedValues(BlogStore.shared.recentTags.sorted())
        }
    }

    func perform() async throws -> some IntentResult {
        // Basic validation: ensure title isn't empty
        guard !postTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw IntentError.validationError("Post title cannot be empty.")
        }

        BlogStore.shared.createDraftPost(title: postTitle, tags: tags)
        let dialog = "Draft post '\(postTitle)' created with tags: \(tags.isEmpty ? "None" : tags.joined(separator: ", "))."
        return .result(dialog: dialog)
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct ListPostsByCategoryIntent: AppIntent {
    static var title: LocalizedStringResource = "List Posts by Category"
    static var description = IntentDescription("Lists published blog posts within a specific category.")

    // The category parameter uses CategoryEntity, which automatically uses CategoryQuery for dynamic choices.
    @Parameter(title: "Category", description: "The category to filter posts by.")
    var category: CategoryEntity

    func perform() async throws -> some IntentResult {
        let blogPosts = BlogStore.shared.posts(in: category.id)

        guard !blogPosts.isEmpty else {
            return .result(dialog: "No published posts found in the '\(category.name)' category.")
        }

        // Map BlogPost models to PostEntity for the result
        let postEntities = blogPosts.compactMap { blogPost in
            BlogStore.shared.category(for: blogPost.categoryID)
                .map { PostEntity(blogPost: blogPost, categoryName: $0.name) }
        }

        let dialog = "Found \(postEntities.count) published posts in '\(category.name)': \(postEntities.map { $0.title }.joined(separator: ", "))."
        return .result(dialog: dialog, entities: postEntities)
    }
}

// MARK: - AppIntent Extension (for discoverability)

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct BlogWriterAppIntents: AppIntentExtension {
    static var appName: LocalizedStringResource = "BlogWriter"
    static var category: IntentCategory = .productivity
}
