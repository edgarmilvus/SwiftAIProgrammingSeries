
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Represents a structured response we expect from an LLM for a task like "extract contact info".
struct ContactInfo: Codable, Sendable { // Conforming to Sendable for concurrency safety
    let name: String
    let email: String? // Optional, as LLMs might not always provide it
    let phone: String?
    let company: String?

    // Custom CodingKeys can be used if JSON keys differ from Swift property names
    enum CodingKeys: String, CodingKey {
        case name
        case email = "emailAddress" // Example: JSON might use "emailAddress"
        case phone
        case company
    }
}

// Example usage:
func parseLLMResponse(jsonString: String) throws -> ContactInfo {
    guard let data = jsonString.data(using: .utf8) else {
        throw NSError(domain: "ParsingError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid string encoding"])
    }
    let decoder = JSONDecoder()
    decoder.keyDecodingStrategy = .convertFromSnakeCase // Useful if LLM outputs snake_case
    return try decoder.decode(ContactInfo.self, from: data)
}

// In a real application, the LLM might return:
let llmOutput = """
{
    "name": "Alice Smith",
    "emailAddress": "alice.smith@example.com",
    "phone": "123-456-7890"
}
"""

do {
    let contact = try parseLLMResponse(jsonString: llmOutput)
    print("Parsed contact: \(contact.name), \(contact.email ?? "N/A")")
} catch {
    print("Failed to parse LLM output: \(error.localizedDescription)")
}
