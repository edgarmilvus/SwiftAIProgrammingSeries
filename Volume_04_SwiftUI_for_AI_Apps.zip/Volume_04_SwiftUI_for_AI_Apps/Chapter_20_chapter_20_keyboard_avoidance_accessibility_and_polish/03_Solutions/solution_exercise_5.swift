
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

        // Example AppKit bridging for window access
        extension View {
            func windowAccessor(callback: @escaping (NSWindow?) -> Void) -> some View {
                self.background(
                    WindowAccessor(callback: callback)
                )
            }
        }

        struct WindowAccessor: NSViewRepresentable {
            let callback: (NSWindow?) -> Void

            func makeNSView(context: Context) -> NSView {
                let view = NSView()
                DispatchQueue.main.async { // Ensure callback happens after window is attached
                    self.callback(view.window)
                }
                return view
            }

            func updateNSView(_ nsView: NSView, context: Context) {}
        }

        // Usage in SwiftUI view:
        @State private var assistantWindow: NSWindow?
        // ...
        .windowAccessor { window in
            self.assistantWindow = window
        }
        // Then, in a onChange(of: isInputActive) or similar:
        if isInputActive, let window = assistantWindow {
            // Perform window.setFrame(...) logic here
        }
        