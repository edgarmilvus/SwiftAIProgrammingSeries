
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import SwiftUI

/// A conceptual SwiftUI view demonstrating the integration of UtilityBillPredictor.
/// This view allows users to simulate training and make predictions.
@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 2.0, *)
struct BillPredictionView: View {
    @StateObject private var predictor = UtilityBillPredictor()
    @State private var historicalData: [UtilityBillData] = []
    @State private var futureMonth: Int = 1
    @State private var futureTemperature: Double = 15.0
    @State private var futureOccupants: Int = 2
    @State private var futurePreviousBill: Double = 100.0

    var body: some View {
        NavigationView {
            Form {
                Section("Historical Data (Simulated)") {
                    Text("Generated \(historicalData.count) records.")
                    Button("Generate & Train Model") {
                        Task {
                            historicalData = generateHistoricalUtilityData(count: 100)
                            do {
                                try await predictor.trainModel(historicalData: historicalData)
                            } catch {
                                predictor.errorMessage = error.localizedDescription
                            }
                        }
                    }
                    .disabled(predictor.isLoading)
                }

                Section("Future Prediction Input") {
                    Stepper("Month: \(futureMonth)", value: $futureMonth, in: 1...12)
                    Slider(value: $futureTemperature, in: -10...35, step: 0.1) {
                        Text("Avg. Temp (°C): \(futureTemperature, specifier: "%.1f")")
                    }
                    Stepper("Occupants: \(futureOccupants)", value: $futureOccupants, in: 1...10)
                    TextField("Previous Bill Amount", value: $futurePreviousBill, format: .currency(code: "USD"))
                        .keyboardType(.decimalPad)

                    Button("Predict Next Bill") {
                        Task {
                            let predictionInput = UtilityBillData(
                                month: futureMonth,
                                avgTemperatureC: futureTemperature,
                                householdOccupants: futureOccupants,
                                previousBillAmount: futurePreviousBill,
                                actualBillAmount: 0 // Placeholder, as this is the target
                            )
                            do {
                                _ = try await predictor.predictBill(for: predictionInput)
                            } catch {
                                predictor.errorMessage = error.localizedDescription
                            }
                        }
                    }
                    .disabled(predictor.isLoading)
                }

                Section("Prediction Result") {
                    if predictor.isLoading {
                        ProgressView("Processing...")
                    } else if let result = predictor.predictionResult {
                        Text("Predicted Bill: \(result, format: .currency(code: "USD"))")
                            .font(.headline)
                            .foregroundColor(.green)
                    } else if let error = predictor.errorMessage {
                        Text("Error: \(error)")
                            .foregroundColor(.red)
                    } else {
                        Text("Train model and enter prediction data to see results.")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("BillWise Forecaster")
        }
    }
}
