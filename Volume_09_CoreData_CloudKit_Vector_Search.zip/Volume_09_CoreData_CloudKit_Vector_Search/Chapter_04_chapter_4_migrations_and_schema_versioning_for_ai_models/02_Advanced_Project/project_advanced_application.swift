
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreData
import Accelerate // For vector math operations
import OSLog

// MARK: - Package Dependencies
/*
 [Package.swift]
 dependencies: [
    .package(url: "https://github.com/apple/swift-transformers", from: "1.0.0"),
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ]
*/

/// Represents the version of the AI model used to generate embeddings.
/// This is critical for determining if a semantic migration is required.
enum EmbeddingModelVersion: Int, Codable, Comparable {
    case v1_SmallBERT = 1 // 384 dimensions
    case v2_LargeTransformer = 2 // 1536 dimensions
    
    static func < (lhs: EmbeddingModelVersion, rhs: EmbeddingModelVersion) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
    
    var dimensionCount: Int {
        switch self {
        case .v1_SmallBERT: return 384
        case .v2_LargeTransformer: return 1536
        }
    }
}

/// Errors specific to the Semantic Migration process.
enum MigrationError: Error, LocalizedError {
    case modelIncompatibility
    case batchProcessingFailed(String)
    case insufficientStorage
    case hardwareAccelerationUnavailable
    
    var errorDescription: String? {
        switch self {
        case .modelIncompatibility: return "The current vector data is incompatible with the new model."
        case .batchProcessingFailed(let reason): return "Batch failed: \(reason)"
        case .insufficientStorage: return "Not enough disk space to complete re-embedding."
        case .hardwareAccelerationUnavailable: return "Neural Engine is unavailable for this operation."
        }
    }
}

/// A protocol defining the interface for the AI model provider.
/// Using a protocol allows us to mock the model for unit testing.
protocol EmbeddingProvider: Sendable {
    var currentVersion: EmbeddingModelVersion { get }
    func generateEmbedding(for text: String) async throws -> [Float]
}

/// The core actor responsible for managing the heavy computational task
/// of re-embedding data without blocking the Main Actor or UI.
@available(iOS 18.0, *)
actor SemanticMigrationCoordinator {
    private let logger = Logger(subsystem: "com.ai.app.migration", category: "SemanticMigration")
    private let modelProvider: any EmbeddingProvider
    private let persistentContainer: NSPersistentContainer
    
    /// Tracks the progress of the migration for UI updates.
    @Published private(set) var migrationProgress: Double = 0.0
    @Published private(set) var isMigrating: Bool = false

    init(modelProvider: any EmbeddingProvider, container: NSPersistentContainer) {
        self.modelProvider = modelProvider
        self.persistentContainer = container
    }

    /// Orchestrates the migration from an old model version to the current one.
    /// - Parameter oldVersion: The version currently stored in the database metadata.
    func migrate(from oldVersion: EmbeddingModelVersion) async throws {
        guard oldVersion < modelProvider.currentVersion else {
            logger.info("No migration needed. Versions match.")
            return
        }

        logger.info("Starting Semantic Migration: \(oldVersion.rawValue) -> \(self.modelProvider.currentVersion.rawValue)")
        
        // Reset state
        await MainActor.run { self.isMigrating = true; self.migrationProgress = 0.0 }
        
        defer {
            Task { @MainActor in self.isMigrating = false }
        }

        try await performDualSchemaMigration()
    }

    /// Performs the heavy lifting: Fetching, Re-embedding, and Saving.
    /// Uses a 'Dual-Schema' approach: it populates a new attribute `vector_v2` 
    /// while leaving `vector_v1` intact until completion.
    private func performDualSchemaMigration() async throws {
        let context = persistentContainer.newBackgroundContext()
        // Ensure we use a private queue for this heavy work
        context.performAndWait { /* Setup context if needed */ }

        // 1. Fetch all entities that need re-embedding.
        // In a real app, we'd fetch IDs first to minimize memory footprint.
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "MemoryEntity")
        fetchRequest.predicate = NSPredicate(format: "vector_v2 == nil") // Only fetch what's not yet migrated
        fetchRequest.fetchBatchSize = 50 // Crucial for memory management

        let totalToMigrate = try context.count(for: fetchRequest)
        guard totalToMigrate > 0 else { return }
        
        var processedCount = 0
        let batchSize = 20

        // 2. Process in batches to prevent memory spikes and allow for checkpointing.
        for offset in stride(from: 0, to: totalToMigrate, by: batchSize) {
            try await processBatch(
                fetchRequest: fetchRequest,
                offset: offset,
                limit: batchSize,
                context: context
            )
            
            processedCount += batchSize
            let progress = Double(min(processedCount, totalToMigrate)) / Double(totalToMigrate)
            
            await MainActor.run {
                self.migrationProgress = progress
            }
            
            logger.debug("Processed batch starting at \(offset). Progress: \(progress * 100)%")
        }
        
        // 3. Finalize: In a real implementation, you would trigger a structural 
        // Core Data migration here to drop the old 'vector_v1' column.
        logger.info("Semantic Migration successfully completed.")
    }

    /// Processes a single batch of entities using Swift 6 Concurrency.
    private func processBatch(
        fetchRequest: NSFetchRequest<NSManagedObject>,
        offset: Int,
        limit: Int,
        context: NSManagedObjectContext
    ) async throws {
        // We use a TaskGroup to parallelize the AI model calls for the current batch.
        // While the model itself might be a bottleneck, parallelizing the 
        // pre-processing and post-processing helps throughput.
        
        try await withThrowingTaskGroup(of: (NSManagedObjectID, [Float]).self) { group in
            
            // Configure fetch request for this batch
            let batchRequest = fetchRequest
            batchRequest.fetchOffset = offset
            batchRequest.fetchLimit = limit
            
            let entities = try context.fetch(batchRequest)
            
            for entity in entities {
                let objectID = entity.objectID
                let textContent = entity.value(forKey: "textContent") as? String ?? ""
                
                // Add a task to the group for each entity in the batch
                group.addTask {
                    // The AI model call is the most expensive part.
                    // We do this outside the context's main thread.
                    let embedding = try await self.modelProvider.generateEmbedding(for: textContent)
                    return (objectID, embedding)
                }
            }

            // Collect results as they finish
            for try await (objectID, newEmbedding) in group {
                // We must return to the context's thread to apply changes.
                try await context.perform {
                    let object = context.object(with: objectID)
                    // Set the new versioned attribute
                    object.setValue(newEmbedding, forKey: "vector_v2")
                    // Mark as migrated
                    object.setValue(self.modelProvider.currentVersion.rawValue, forKey: "modelVersion")
                }
            }
            
            // Commit the batch to the persistent store
            try await context.perform {
                if context.hasChanges {
                    try context.save()
                }
            }
        }
    }
}

// MARK: - Mock Implementation for Demonstration

/// A mock implementation of an embedding provider using a simulated delay.
final class MockAIModel: EmbeddingProvider, @unchecked Sendable {
    let currentVersion: EmbeddingModelVersion = .v2_LargeTransformer
    
    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate Neural Engine latency
        try await Task.sleep(for: .milliseconds(150))
        // Return a dummy vector of the correct dimension
        return (0..<currentVersion.dimensionCount).map { _ in Float.random(in: -1...1) }
    }
}

// MARK: - Usage in an App Component

@available(iOS 18.0, *)
@MainActor
class MemoryViewModel: ObservableObject {
    @Published var migrationProgress: Double = 0.0
    @Published var isMigrating: Bool = false
    @Published var statusMessage: String = "System Ready"
    
    private let migrationCoordinator: SemanticMigrationCoordinator
    
    init(container: NSPersistentContainer, model: any EmbeddingProvider) {
        self.migrationCoordinator = SemanticMigrationCoordinator(
            modelProvider: model,
            container: container
        )
    }
    
    func startUpgrade() {
        Task {
            isMigrating = true
            statusMessage = "Upgrading AI Brain..."
            
            do {
                // In a real app, 'oldVersion' would be fetched from UserDefaults or Core Data metadata
                let oldVersion = EmbeddingModelVersion.v1_SmallBERT
                
                // Observe progress via a simulated subscription or direct property access
                // For this example, we trigger the migration.
                try await migrationCoordinator.migrate(from: oldVersion)
                
                statusMessage = "Upgrade Complete. Semantic Search is now optimized."
            } catch {
                statusMessage = "Upgrade Failed: \(error.localizedDescription)"
                print("Migration Error: \(error)")
            }
            isMigrating = false
        }
    }
}
