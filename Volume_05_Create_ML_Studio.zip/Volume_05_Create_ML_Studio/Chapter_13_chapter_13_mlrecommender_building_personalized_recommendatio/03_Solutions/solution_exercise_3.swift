
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Data Generation Helper

// Helper function to create a simulated explicit feedback dataset
func generateArticleFeedbackData() -> [[String: Any]] {
    var data: [[String: Any]] = []
    let users = (1...15).map { "user\($0)" } // 15 users
    let articles = (1...40).map { "article\($0)" } // 40 articles

    // Simulate various users rating articles
    for user in users {
        // Each user rates 5-10 random articles
        let numRatings = Int.random(in: 5...10)
        var ratedArticles: Set<String> = []
        while ratedArticles.count < numRatings {
            let article = articles.randomElement()!
            if !ratedArticles.contains(article) {
                let rating = Double(Int.random(in: 1...5)) // Rating from 1 to 5
                data.append(["userID": user, "articleID": article, "rating": rating])
                ratedArticles.insert(article)
            }
        }
    }

    // Add some strong positive/negative feedback for specific users/articles
    data.append(["userID": "user1", "articleID": "article5", "rating": 5.0])
    data.append(["userID": "user1", "articleID": "article6", "rating": 5.0])
    data.append(["userID": "user1", "articleID": "article7", "rating": 1.0]) // Disliked

    data.append(["userID": "user2", "articleID": "article5", "rating": 4.0])
    data.append(["userID": "user2", "articleID": "article8", "rating": 5.0])

    return data
}

// MARK: - Model Training and Saving

func trainAndSaveUserToItemModel(data: [[String: Any]], modelName: String = "ArticleRecommender") throws -> URL {
    let userIDs = data.map { $0["userID"] as! String }
    let articleIDs = data.map { $0["articleID"] as! String }
    let ratings = data.map { $0["rating"] as! Double }

    let dataTable = try MLDataTable(dictionary: [
        "userID": userIDs,
        "articleID": articleIDs,
        "rating": ratings
    ])

    print("Training MLRecommender model with explicit feedback...")
    let recommender = try MLRecommenderBuilder(trainingData: dataTable,
                                               userIdentifierColumn: "userID",
                                               itemIdentifierColumn: "articleID",
                                               ratingColumn: "rating") // Explicit rating column

    let fileManager = FileManager.default
    let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
    let modelURL = documentsDirectory.appendingPathComponent("\(modelName).mlmodel")

    try recommender.write(to: modelURL)
    print("Model trained and saved to: \(modelURL.lastPathComponent)")
    return modelURL
}

// MARK: - App Integration Logic

/// Loads a pre-trained MLRecommender model and provides user-to-item recommendations.
class NewsFeedRecommendationEngine {
    private var recommender: MLRecommender?
    private let modelURL: URL
    // Store user interaction history to filter out already-seen articles
    private var userInteractionHistory: [String: Set<String>] = [:]

    init(modelURL: URL, initialInteractionData: [[String: Any]]) {
        self.modelURL = modelURL
        loadModel()
        buildInteractionHistory(from: initialInteractionData)
    }

    private func loadModel() {
        do {
            let compiledModelURL = try MLModel.compileModel(at: modelURL)
            self.recommender = try MLRecommender(contentsOf: compiledModelURL)
            print("Article recommender model loaded successfully.")
        } catch {
            print("Error loading article recommender model: \(error)")
            self.recommender = nil
        }
    }

    private func buildInteractionHistory(from data: [[String: Any]]) {
        for record in data {
            if let userID = record["userID"] as? String,
               let articleID = record["articleID"] as? String {
                userInteractionHistory[userID, default: []].insert(articleID)
            }
        }
        print("Built interaction history for \(userInteractionHistory.keys.count) users.")
    }

    /// Returns a list of article IDs recommended for a specific user, excluding articles they've already interacted with.
    /// - Parameters:
    ///   - userID: The ID of the user for whom to generate recommendations.
    ///   - numberOfArticles: The maximum number of articles to recommend.
    /// - Returns: An array of article IDs. Returns an empty array if the model is not loaded,
    ///            if the user is new (cold start), or if no suitable recommendations are found.
    func getPersonalizedNewsFeed(for userID: String, numberOfArticles: Int) -> [String] {
        guard let recommender = recommender else {
            print("Model not loaded. Cannot provide recommendations.")
            return []
        }

        // Get articles the user has already seen/rated
        let interactedArticles = userInteractionHistory[userID] ?? []
        print("User \(userID) has interacted with \(interactedArticles.count) articles.")

        do {
            // MLRecommender will recommend articles the user would like
            // and often includes items the user hasn't seen, but it's good practice
            // to explicitly filter against known interactions.
            let recommendations = try recommender.recommendations(forUsers: [userID], k: numberOfArticles * 2) // Fetch more to allow for filtering
            
            let recommendedArticleIDs = recommendations["articleID"]
                .map { $0.map { $0.stringValue ?? "" } } ?? []
            
            // Filter out articles the user has already interacted with
            let newRecommendations = recommendedArticleIDs.filter { !interactedArticles.contains($0) }
            
            return Array(newRecommendations.prefix(numberOfArticles))

        } catch {
            print("Error getting personalized news feed for \(userID): \(error)")
            // Cold start for users: if MLRecommender can't provide recommendations for a new user
            // (e.g., user is not in training data), it will throw an error or return an empty result.
            return []
        }
    }
}

// MARK: - Example Usage

func runExercise2() {
    print("--- Running Exercise 2: Personalized News Feed ---")

    // 1. Data Generation
    let feedbackData = generateArticleFeedbackData()
    print("Generated \(feedbackData.count) feedback records.")

    do {
        // 2. Model Training and Saving
        let modelPath = try trainAndSaveUserToItemModel(data: feedbackData)

        // 3. Recommendation Logic
        let newsEngine = NewsFeedRecommendationEngine(modelURL: modelPath, initialInteractionData: feedbackData)

        let targetUser1 = "user1"
        let personalizedFeed1 = newsEngine.getPersonalizedNewsFeed(for: targetUser1, numberOfArticles: 5)
        print("\nPersonalized feed for \(targetUser1): \(personalizedFeed1)")
        // Expect articles user1 hasn't seen, but are similar to their 5.0 rated articles.
        // Should NOT include article5, article6, article7.

        let targetUser2 = "user2"
        let personalizedFeed2 = newsEngine.getPersonalizedNewsFeed(for: targetUser2, numberOfArticles: 3)
        print("Personalized feed for \(targetUser2): \(personalizedFeed2)")
        // Should NOT include article5, article8.

        let targetUserColdStart = "user99" // A new user not in training data
        let personalizedFeed3 = newsEngine.getPersonalizedNewsFeed(for: targetUserColdStart, numberOfArticles: 5)
        print("Personalized feed for \(targetUserColdStart) (cold start): \(personalizedFeed3)") // Expect empty

    } catch {
        print("An error occurred during Exercise 2: \(error)")
    }
    print("--- Exercise 2 Finished ---\n")
}

// Call the function to run the exercise
runExercise2()
