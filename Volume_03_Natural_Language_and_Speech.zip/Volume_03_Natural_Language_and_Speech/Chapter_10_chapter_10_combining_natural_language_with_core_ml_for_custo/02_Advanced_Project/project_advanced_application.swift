
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for Swift Package Manager dependencies
// This would be part of your project's Package.swift file.
/*
import PackageDescription

let package = Package(
    name: "SmartDocumentScanner",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 for potential future features and compliance with request
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "SmartDocumentScanner",
            targets: ["SmartDocumentScanner"]),
    ],
    dependencies: [], // Vision, NaturalLanguage, CoreML are system frameworks, no SPM dependency needed.
    targets: [
        .target(
            name: "SmartDocumentScanner",
            dependencies: []),
    ]
)
*/

import Foundation
import Vision
import NaturalLanguage
import CoreML

/// Represents the possible types of documents our classifier can identify.
enum DocumentType: String, CaseIterable, Codable {
    case invoice = "Invoice"
    case receipt = "Receipt"
    case contract = "Contract"
    case report = "Report"
    case unknown = "Unknown"

    /// Provides a user-friendly description for each document type.
    var description: String {
        switch self {
        case .invoice: return "An official request for payment."
        case .receipt: return "Proof of payment for goods or services."
        case .contract: return "A legally binding agreement."
        case .report: return "A detailed account or statement."
        case .unknown: return "Could not determine the document type."
        }
    }
}

/// Represents the structured result of a document analysis.
struct DocumentAnalysisResult: Codable {
    let documentType: DocumentType
    let extractedText: String
    let detectedDates: [Date]
    let detectedAmounts: [Decimal]
    let confidence: Double? // Confidence score from the ML model, if available
}

/// Custom error types for document analysis operations.
enum DocumentAnalysisError: Error, LocalizedError {
    case textRecognitionFailed(Error?)
    case modelPredictionFailed(Error?)
    case noTextFound
    case invalidModelInput
    case modelNotFound
    case dataDetectorError(Error?)

    var errorDescription: String? {
        switch self {
        case .textRecognitionFailed(let error):
            return "Failed to recognize text from the image: \(error?.localizedDescription ?? "unknown error")."
        case .modelPredictionFailed(let error):
            return "Failed to classify document using Core ML model: \(error?.localizedDescription ?? "unknown error")."
        case .noTextFound:
            return "No text was found in the provided image."
        case .invalidModelInput:
            return "The input provided to the Core ML model was invalid."
        case .modelNotFound:
            return "The Core ML document classification model could not be loaded."
        case .dataDetectorError(let error):
            return "An error occurred during data detection: \(error?.localizedDescription ?? "unknown error")."
        }
    }
}

// Assume DocumentClassifier is a generated class from DocumentClassifier.mlmodel
// It typically has an initializer and a prediction method.
// For demonstration, we'll mock its interface if the actual model isn't provided.
// In a real app, you'd drag your .mlmodel file into Xcode, and it generates this class.
@available(iOS 18.0, macOS 15.0, *)
class DocumentClassifier {
    // This is a placeholder for the actual generated class from Core ML.
    // It would typically look like:
    // init(configuration: MLModelConfiguration = MLModelConfiguration()) throws
    // func prediction(text: String) throws -> DocumentClassifierOutput
    // DocumentClassifierOutput would have a 'label' property (String) and 'labelProbs' (Dictionary<String, Double>)

    private let model: MLModel

    /// Initializes the DocumentClassifier with the provided MLModel.
    /// In a real scenario, this would load the model from the app bundle.
    init() throws {
        guard let modelURL = Bundle.main.url(forResource: "DocumentClassifier", withExtension: "mlmodelc") else {
            throw DocumentAnalysisError.modelNotFound
        }
        let configuration = MLModelConfiguration()
        self.model = try MLModel(contentsOf: modelURL, configuration: configuration)
    }

    /// Predicts the document type based on the input text.
    /// - Parameter text: The full text content of the document.
    /// - Returns: A tuple containing the predicted document type (String) and its confidence (Double).
    /// - Throws: `DocumentAnalysisError.modelPredictionFailed` if prediction fails.
    func prediction(text: String) throws -> (label: String, confidence: Double) {
        // Core ML models typically expect an `MLFeatureProvider` as input.
        // For NLModel-based classifiers, a simple string input is common.
        let input = try MLDictionaryFeatureProvider(dictionary: ["text": text])
        
        let output = try model.prediction(from: input)
        
        guard let label = output.featureValue(for: "label")?.stringValue,
              let labelProbs = output.featureValue(for: "labelProbs")?.dictionaryValue as? [String: Double] else {
            throw DocumentAnalysisError.modelPredictionFailed(nil)
        }
        
        let confidence = labelProbs[label] ?? 0.0
        return (label: label, confidence: confidence)
    }
}
