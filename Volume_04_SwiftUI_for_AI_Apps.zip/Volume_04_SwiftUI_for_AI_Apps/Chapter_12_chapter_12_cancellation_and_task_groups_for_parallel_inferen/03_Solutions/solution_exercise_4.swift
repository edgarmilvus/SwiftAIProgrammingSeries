
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - Data Models

/// Represents the sentiment of an article.
enum Sentiment: String, Codable {
    case positive, neutral, negative, mixed
}

/// Represents a raw article fetched from a source.
struct Article: Identifiable, Hashable, CustomStringConvertible {
    let id: String
    let title: String
    let content: String
    let sourceURL: URL
    
    var description: String {
        "Article(id: \(id), title: '\(title.prefix(30))...')"
    }
}

/// Represents an article after AI processing, including its features and ranking score.
struct ProcessedArticle: Identifiable, CustomStringConvertible {
    let id: String
    let title: String
    let content: String
    let sourceURL: URL
    let topics: [String]
    let sentiment: Sentiment
    let entities: [String]
    let readabilityScore: Double // 0.0 (very hard) to 1.0 (very easy)
    let rankingScore: Double // Higher is better
    
    var description: String {
        """
        ProcessedArticle(id: \(id), title: '\(title.prefix(30))...',
                         topics: \(topics), sentiment: \(sentiment.rawValue),
                         rankingScore: \(String(format: "%.2f", rankingScore)))
        """
    }
}

// MARK: - Simulated AI Models

/// Base error for AI operations.
enum AIModelError: Error, LocalizedError {
    case processingFailed(model: String, articleId: String)
    case invalidInput(model: String, articleId: String)
    
    var errorDescription: String? {
        switch self {
        case .processingFailed(let model, let articleId): return "\(model) for \(articleId) failed."
        case .invalidInput(let model, let articleId): return "\(model) received invalid input for \(articleId)."
        }
    }
}

/// Simulates a Topic Classifier AI.
func classifyTopics(article: Article) async throws -> [String] {
    try await Task.sleep(for: .milliseconds(Int.random(in: 400...800)))
    try Task.checkCancellation()
    guard !article.content.isEmpty else { throw AIModelError.invalidInput(model: "Topic Classifier", articleId: article.id) }
    let possibleTopics = ["Tech", "Politics", "Sports", "Science", "Business", "Culture"]
    let numTopics = Int.random(in: 1...3)
    let topics = (0..<numTopics).map { _ in possibleTopics.randomElement()! }
    print("  [AI Topic] '\(article.id)' classified topics: \(topics)")
    return topics
}

/// Simulates a Sentiment Analyzer AI.
func analyzeSentiment(article: Article) async throws -> Sentiment {
    try await Task.sleep(for: .milliseconds(Int.random(in: 300...700)))
    try Task.checkCancellation()
    guard !article.content.isEmpty else { throw AIModelError.invalidInput(model: "Sentiment Analyzer", articleId: article.id) }
    let sentiments: [Sentiment] = [.positive, .neutral, .negative, .mixed]
    let sentiment = sentiments.randomElement()!
    print("  [AI Sentiment] '\(article.id)' sentiment: \(sentiment.rawValue)")
    return sentiment
}

/// Simulates a Named Entity Recognizer AI.
func extractEntities(article: Article) async throws -> [String] {
    try await Task.sleep(for: .milliseconds(Int.random(in: 500...1000)))
    try Task.checkCancellation()
    guard !article.content.isEmpty else { throw AIModelError.invalidInput(model: "Entity Recognizer", articleId: article.id) }
    let possibleEntities = ["Apple", "Elon Musk", "NASA", "Paris", "Joe Biden", "Google", "ChatGPT"]
    let numEntities = Int.random(in: 0...2)
    let entities = (0..<numEntities).map { _ in possibleEntities.randomElement()! }
    print("  [AI Entities] '\(article.id)' extracted entities: \(entities)")
    return entities
}

/// Simulates a Readability Scorer AI.
func scoreReadability(article: Article) async throws -> Double {
    try await Task.sleep(for: .milliseconds(Int.random(in: 200...600)))
    try Task.checkCancellation()
    guard !article.content.isEmpty else { throw AIModelError.invalidInput(model: "Readability Scorer", articleId: article.id) }
    let score = Double.random(in: 0.2...0.9) // Lower score = harder to read
    print("  [AI Readability] '\(article.id)' readability score: \(String(format: "%.2f", score))")
    return score
}

// MARK: - Article Processing Pipeline

/// Calculates a personalized ranking score based on AI features.
/// (Simplified for demonstration)
func calculateRankingScore(topics: [String], sentiment: Sentiment, readability: Double) -> Double {
    var score = 0.0
    
    // Example logic:
    // User prefers "Tech" and "Science"
    if topics.contains("Tech") || topics.contains("Science") {
        score += 0.5
    }
    // Positive sentiment is good
    if sentiment == .positive {
        score += 0.3
    }
    // Readability matters
    score += readability * 0.2 // Max 0.2 contribution
    
    return min(1.0, max(0.0, score)) // Cap score between 0 and 1
}

/// Processes a single article by running all AI models in parallel using TaskGroup.
func processArticle(article: Article) async throws -> ProcessedArticle {
    print("Processing article: \(article.id) - Running AI models in parallel...")
    
    var topics: [String] = []
    var sentiment: Sentiment = .neutral
    var entities: [String] = []
    var readabilityScore: Double = 0.5
    
    try await withTaskGroup(of: Any.self) { group in
        group.addTask { try await classifyTopics(article: article) }
        group.addTask { try await analyzeSentiment(article: article) }
        group.addTask { try await extractEntities(article: article) }
        group.addTask { try await scoreReadability(article: article) }
        
        for await result in group {
            // This is a simple type-based dispatch; in a real app,
            // you might use a more robust enum or struct for results.
            if let t = result as? [String] {
                topics = t
            } else if let s = result as? Sentiment {
                sentiment = s
            } else if let e = result as? [String] {
                entities = e
            } else if let r = result as? Double {
                readabilityScore = r
            }
        }
    }
    
    // Calculate final ranking score
    let rankingScore = calculateRankingScore(topics: topics, sentiment: sentiment, readability: readabilityScore)
    
    return ProcessedArticle(
        id: article.id,
        title: article.title,
        content: article.content,
        sourceURL: article.sourceURL,
        topics: topics,
        sentiment: sentiment,
        entities: entities,
        readabilityScore: readabilityScore,
        rankingScore: rankingScore
    )
}

/// Refreshes the news feed by processing a batch of articles in parallel using TaskGroup.
/// This function is also cooperatively cancellable.
func refreshFeed(articles: [Article]) async -> [ProcessedArticle] {
    print("\n--- Refreshing Feed: Processing \(articles.count) articles ---")
    var processedArticles: [ProcessedArticle] = []
    
    await withTaskGroup(of: ProcessedArticle?.self) { group in
        for article in articles {
            group.addTask {
                do {
                    // Check for cancellation at the outer TaskGroup level before launching child tasks
                    try Task.checkCancellation()
                    let processed = try await processArticle(article: article)
                    print("✅ Article '\(article.id)' fully processed.")
                    return processed
                } catch is CancellationError {
                    print("🛑 Article '\(article.id)' processing cancelled.")
                    return nil
                } catch {
                    print("❌ Article '\(article.id)' processing failed: \(error.localizedDescription)")
                    return nil
                }
            }
        }
        
        // Collect results as they complete
        for await result in group {
            if let article = result {
                processedArticles.append(article)
            }
        }
        
        // The TaskGroup will automatically cancel its children if its parent Task is cancelled.
    }
    
    // Sort articles by ranking score (highest first)
    processedArticles.sort { $0.rankingScore > $1.rankingScore }
    
    print("--- Feed Refresh Complete (or Cancelled). Processed \(processedArticles.count) articles. ---")
    return processedArticles
}

// MARK: - Feed Manager and UI Simulation

/// A class to manage the entire feed refresh process, simulating a macOS app controller.
class FeedManager {
    private var currentRefreshTask: Task<[ProcessedArticle], Never>?
    
    func fetchAndProcessFeed(articles: [Article]) {
        // If a previous refresh is active, cancel it immediately.
        if let activeTask = currentRefreshTask {
            print("UI: Cancelling previous feed refresh for new request.")
            activeTask.cancel()
        }
        
        print("UI: 'Refresh Feed' tapped. Initiating new feed processing.")
        currentRefreshTask = Task {
            let processedArticles = await refreshFeed(articles: articles)
            if Task.isCancelled {
                print("UI: 🛑 Feed refresh was cancelled by user (top-level task check).")
            } else {
                print("UI: ✅ Feed refresh successful! Top ranked articles:")
                processedArticles.forEach { article in
                    print(article)
                }
            }
            self.currentRefreshTask = nil
        }
    }
    
    func cancelFeedRefresh() {
        guard let task = currentRefreshTask else {
            print("UI: No active feed refresh to cancel.")
            return
        }
        print("UI: 'Navigate Away' or 'Cancel' tapped. Cancelling feed refresh.")
        task.cancel()
    }
    
    deinit {
        currentRefreshTask?.cancel()
    }
}

// MARK: - Demonstration

func demonstrateHorizonAppFeed() async {
    let sampleArticles: [Article] = [
        Article(id: "art1", title: "New AI Breakthrough in Medical Imaging", content: "Scientists at XYZ Labs have achieved...", sourceURL: URL(string: "https://example.com/art1")!),
        Article(id: "art2", title: "Global Economic Outlook: A Mixed Picture", content: "Analysts predict a period of both growth and contraction...", sourceURL: URL(string: "https://example.com/art2")!),
        Article(id: "art3", title: "Exploring the Deep Sea: New Species Discovered", content: "An expedition to the Mariana Trench...", sourceURL: URL(string: "https://example.com/art3")!),
        Article(id: "art4", title: "The Future of Renewable Energy Sources", content: "Innovations in solar and wind power...", sourceURL: URL(string: "https://example.com/art4")!),
        Article(id: "art5", title: "Political Tensions Rise in Eastern Europe", content: "Diplomatic efforts continue amidst escalating rhetoric...", sourceURL: URL(string: "https://example.com/art5")!),
        Article(id: "art6", title: "SpaceX Launches New Satellite Constellation", content: "Providing global internet access...", sourceURL: URL(string: "https://example.com/art6")!)
    ]
    
    let feedManager = FeedManager()
    
    print("--- Scenario 1: Full Feed Refresh ---")
    feedManager.fetchAndProcessFeed(articles: sampleArticles)
    await Task.sleep(for: .seconds(6)) // Give enough time for all to process
    print("\n")
    
    print("--- Scenario 2: User Navigates Away Mid-Refresh ---")
    feedManager.fetchAndProcessFeed(articles: sampleArticles)
    await Task.sleep(for: .seconds(1.5)) // Allow some articles to start processing
    feedManager.cancelFeedRefresh()
    await Task.sleep(for: .seconds(1)) // Give time for cancellation to propagate
    print("\n")
    
    print("--- Scenario 3: Another Refresh Request Cancels Ongoing One ---")
    feedManager.fetchAndProcessFeed(articles: sampleArticles)
    await Task.sleep(for: .seconds(1))
    feedManager.fetchAndProcessFeed(articles: [sampleArticles[0], sampleArticles[1]]) // Refresh with fewer articles
    await Task.sleep(for: .seconds(4))
    print("\n")
    
    print("--- Scenario 4: Cancel when no task is active ---")
    feedManager.cancelFeedRefresh()
    print("\n")
}

// Run the demonstration
await demonstrateHorizonAppFeed()
