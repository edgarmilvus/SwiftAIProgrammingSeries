
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AVFoundation
import UIKit

// MARK: - OrientationManager: Monitors device orientation changes

@available(iOS 18.0, *)
class OrientationManager: ObservableObject {
    @Published var currentOrientation: UIDeviceOrientation = .unknown

    init() {
        // Start generating device orientation notifications
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        // Add observer for orientation changes
        NotificationCenter.default.addObserver(self, selector: #selector(deviceDidRotate), name: UIDevice.orientationDidChangeNotification, object: nil)
        // Set initial orientation
        self.currentOrientation = UIDevice.current.orientation
    }

    deinit {
        // Stop generating device orientation notifications
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
        // Remove observer
        NotificationCenter.default.removeObserver(self, name: UIDevice.orientationDidChangeNotification, object: nil)
    }

    @objc private func deviceDidRotate() {
        // Ensure updates to @Published properties happen on the main thread
        DispatchQueue.main.async {
            self.currentOrientation = UIDevice.current.orientation
            print("Device rotated to: \(self.currentOrientation.description)")
        }
    }

    // Helper to map UIDeviceOrientation to AVCaptureVideoOrientation
    func videoOrientation(for deviceOrientation: UIDeviceOrientation) -> AVCaptureVideoOrientation {
        switch deviceOrientation {
        case .portrait: return .portrait
        case .portraitUpsideDown: return .portraitUpsideDown
        // Device rotated clockwise, video needs to be rotated counter-clockwise to appear upright.
        case .landscapeLeft: return .landscapeRight
        // Device rotated counter-clockwise, video needs to be rotated clockwise to appear upright.
        case .landscapeRight: return .landscapeLeft
        default: return .portrait // Fallback to portrait for unknown or flat orientations
        }
    }
}

// MARK: - CameraPreview for Exercise 4: Adapts to aspect ratio and orientation

@available(iOS 18.0, *)
struct AspectRatioCameraPreview: UIViewRepresentable {
    // AVCaptureSession is passed in from an external manager (e.g., CameraManager from Ex3)
    let session: AVCaptureSession
    @Binding var currentDeviceOrientation: UIDeviceOrientation

    private var previewLayer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black

        // Create the preview layer on the main thread
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.bounds // Initial frame
        view.layer.addSublayer(layer)
        self.previewLayer = layer // Store reference

        // Set initial orientation for the preview layer connection
        if let connection = layer.connection {
            if connection.isVideoOrientationSupported {
                connection.videoOrientation = context.coordinator.orientationManager.videoOrientation(for: currentDeviceOrientation)
            }
        }

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        // 1. Update the previewLayer's frame to fill uiView's bounds
        if let layer = previewLayer {
            layer.frame = uiView.bounds
        }

        // 2. Update the previewLayer's connection.videoOrientation based on currentDeviceOrientation
        if let connection = previewLayer?.connection, connection.isVideoOrientationSupported {
            let newOrientation = context.coordinator.orientationManager.videoOrientation(for: currentDeviceOrientation)
            if connection.videoOrientation != newOrientation {
                connection.videoOrientation = newOrientation
                print("Updated video orientation to: \(newOrientation.rawValue)")
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        // The coordinator will hold an instance of OrientationManager
        // This ensures the OrientationManager's lifecycle is tied to the UIViewRepresentable
        Coordinator(orientationManager: OrientationManager())
    }

    class Coordinator: NSObject {
        let orientationManager: OrientationManager

        init(orientationManager: OrientationManager) {
            self.orientationManager = orientationManager
        }
    }
}

// MARK: - SwiftUI Wrapper for Exercise 4

@available(iOS 18.0, *)
struct Exercise4WrapperView: View {
    @StateObject private var orientationManager = OrientationManager()
    @StateObject private var cameraManager = CameraManager() // Reusing CameraManager from Ex3 for session management
    let fixedAspectRatio: CGFloat = 1.0 // Example: 1:1 for a square preview

    var body: some View {
        Group {
            // Simplified permission check for brevity in this specific exercise.
            // In a real app, use the robust permission handling from Exercise 2.
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .authorized:
                GeometryReader { geometry in
                    let availableWidth = geometry.size.width
                    let availableHeight = geometry.size.height

                    // Calculate the size that maintains fixedAspectRatio and fits within available space
                    let targetWidth: CGFloat
                    let targetHeight: CGFloat

                    if availableWidth / availableHeight > fixedAspectRatio {
                        // Container is wider than desired aspect ratio, constrain by height
                        targetHeight = availableHeight
                        targetWidth = availableHeight * fixedAspectRatio
                    } else {
                        // Container is taller than desired aspect ratio, constrain by width
                        targetWidth = availableWidth
                        targetHeight = availableWidth / fixedAspectRatio
                    }

                    AspectRatioCameraPreview(
                        session: cameraManager.session,
                        currentDeviceOrientation: $orientationManager.currentOrientation
                    )
                    .frame(width: targetWidth, height: targetHeight)
                    // Center the preview within the GeometryReader's space
                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    .onAppear {
                        // Ensure CameraManager is set up and running
                        cameraManager.setupSession()
                        cameraManager.startSession()
                    }
                    .onDisappear {
                        cameraManager.stopSession()
                    }
                }
            case .notDetermined:
                Text("Requesting Camera Access...")
                    .onAppear {
                        AVCaptureDevice.requestAccess(for: .video) { _ in } // Simplified request
                    }
            case .denied, .restricted:
                Text("Camera access denied for aspect ratio preview.")
            @unknown default:
                Text("Unknown camera authorization status.")
            }
        }
        .ignoresSafeArea()
    }
}
