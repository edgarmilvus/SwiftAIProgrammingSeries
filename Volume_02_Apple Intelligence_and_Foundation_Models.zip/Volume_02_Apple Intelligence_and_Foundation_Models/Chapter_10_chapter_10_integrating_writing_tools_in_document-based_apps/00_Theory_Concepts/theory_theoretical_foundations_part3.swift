
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

// Assuming iOS 17+ for @Observable, but WritingTools is iOS 18+
// So this would be @available(iOS 18.0, *)
@available(iOS 18.0, *)
@Observable
class EditorViewModel {
    var currentText: String {
        didSet {
            // Potentially trigger AI analysis on text changes
            Task { await analyzeTextForWritingTools() }
        }
    }
    var aiSuggestions: [String] = []
    var isAILoading: Bool = false
    var errorMessage: String?

    // The DocumentManager actor, which encapsulates our document state and AI interaction
    private let documentManager: DocumentManager

    init(initialText: String) {
        self.documentManager = DocumentManager(initialContent: initialText)
        self.currentText = initialText
        Task { await loadInitialContent() }
    }
    
    private func loadInitialContent() async {
        // Actors need to be called with await
        self.currentText = await documentManager.getContent()
    }

    @MainActor // UI updates must be on the main actor
    func analyzeTextForWritingTools() async {
        guard !currentText.isEmpty else {
            aiSuggestions = []
            return
        }
        
        isAILoading = true
        errorMessage = nil
        do {
            // Request rewrite for a portion of the text (e.g., the whole content for simplicity here)
            let suggestions = try await documentManager.requestAIRewrite(for: currentText)
            aiSuggestions = suggestions
        } catch is CancellationError {
            print("AI analysis was cancelled.")
            aiSuggestions = [] // Clear suggestions if cancelled
        } catch {
            errorMessage = "Failed to get AI suggestions: \(error.localizedDescription)"
            aiSuggestions = []
        }
        isAILoading = false
    }
    
    @MainActor
    func applySuggestion(_ suggestion: String) async {
        // In a real app, you'd replace the specific original text that led to this suggestion
        // For simplicity, we'll assume we're replacing the whole currentText
        await documentManager.applySuggestion(suggestion, replacing: currentText)
        currentText = await documentManager.getContent() // Update UI with new content
        aiSuggestions = [] // Clear suggestions after applying one
    }
}
