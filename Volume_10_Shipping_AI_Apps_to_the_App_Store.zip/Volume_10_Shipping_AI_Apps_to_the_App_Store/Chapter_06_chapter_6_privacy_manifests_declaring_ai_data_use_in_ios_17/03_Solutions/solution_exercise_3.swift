
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 17.0, *)
final class AIPerformanceMonitor {
    private let fileManager = FileManager.default
    
    /// Measures the time taken for a closure to execute.
    /// Uses ContinuousClock for high-precision, monotonic timing.
    func measureInferenceTime(operation: () async throws -> Void) async rethrows -> Duration {
        let clock = ContinuousClock()
        let start = clock.now
        try await operation()
        let end = clock.now
        return end - start
    }

    /// Checks if the device has enough space for the next model download.
    /// This triggers a privacy manifest requirement for disk space access.
    func hasEnoughSpaceForModel(requiredBytes: Int64) -> Bool {
        let path = NSHomeDirectory()
        do {
            let url = URL(fileURLWithPath: path)
            let values = try url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            if let capacity = values.volumeAvailableCapacityForImportantUsage {
                return Int64(capacity) > requiredBytes
            }
        } catch {
            print("Error checking disk space: \(error)")
        }
        return false
    }
}

/*
// PrivacyInfo.xcprivacy (Required Entries)
// ---------------------------------------------------------
// 1. For Disk Space:
// <dict>
//    <key>NSPrivacyAccessedAPIType</key>
//    <string>NSPrivacyAccessedAPITypeDiskSpace</string>
//    <key>NSPrivacyAccessedAPITypeReasons</key>
//    <array>
//        <string>E17P.1</string> // Reason: To ensure sufficient storage for model weight swapping
//    </array>
// </dict>
//
// 2. For Timing (System Boot Time/Uptime):
// <dict>
//    <key>NSPrivacyAccessedAPIType</key>
//    <string>NSPrivacyAccessedAPITypeSystemBootTime</string>
//    <key>NSPrivacyAccessedAPITypeReasons</key>
//    <array>
//        <string>35F1.1</string> // Reason: To measure performance/latency of AI inference
//    </array>
// </dict>
*/
