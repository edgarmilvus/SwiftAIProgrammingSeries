
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import GRDB
import OSLog

// MARK: - Domain Models

/// A specialized wrapper for high-dimensional vectors.
/// We use a struct to ensure value semantics, which is critical for thread safety in Swift 6.
struct Embedding: Codable, Equatable, Sendable {
    /// The raw floating-point values representing the semantic meaning.
    /// Using Float (32-bit) is standard for most ML models to balance precision and memory.
    let values: [Float]
    
    /// The dimensionality of the vector (e.g., 384, 768, 1536).
    var dimension: Int { values.count }
    
    /// Converts the array of Floats into a raw Data buffer for efficient BLOB storage.
    /// This is the "Under the Hood" magic that makes vector storage performant.
    func toData() -> Data {
        return values.withUnsafeBytes { Data($0) }
    }
    
    /// Reconstructs the [Float] array from a raw Data buffer.
    /// - Parameter data: The BLOB retrieved from SQLite.
    /// - Returns: An array of Floats.
    static func fromData(_ data: Data) -> Embedding {
        let count = data.count / MemoryLayout<Float>.size
        let values = data.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
        return Embedding(values: values)
    }
}

/// Represents a single entry in the user's semantic journal.
/// This model conforms to GRDB protocols for seamless database interaction.
struct JournalEntry: Identifiable, Codable, FetchableRecord, PersistableRecord, Sendable {
    /// Unique identifier for the entry.
    var id: UUID
    /// The actual text written by the user.
    var content: String
    /// The timestamp of the entry.
    var createdAt: Date
    /// The semantic embedding associated with this text.
    /// We store this as a custom type that GRDB will handle via our conversion logic.
    var embedding: Embedding

    /// Define the database columns for GRDB.
    enum Columns {
        static let id = Column(CodingKeys.id)
        static let content = Column(CodingKeys.content)
        static let createdAt = Column(CodingKeys.createdAt)
        static let embedding = Column(CodingKeys.embedding)
    }
}

// MARK: - Database Layer

/// An actor that manages the SQLite connection.
/// Using an `actor` is mandatory in Swift 6 to ensure that all database 
/// operations are isolated to a single background context, preventing data races.
@available(iOS 18.0, *)
actor JournalDatabaseManager {
    private let dbQueue: DatabaseQueue
    private let logger = Logger(subsystem: "com.app.semanticjournal", category: "Database")

    /// Initializes the database and performs migrations.
    /// - Parameter databaseURL: The file URL where the SQLite file will reside.
    init(databaseURL: URL) throws {
        // Initialize the GRDB DatabaseQueue
        self.dbQueue = try DatabaseQueue(path: databaseURL.path)
        
        // Perform schema setup
        try self.setupSchema()
    }

    /// Sets up the initial database schema using GRDB Migrations.
    /// Migrations are essential for evolving your schema as your AI models change.
    private func setupSchema() throws {
        var migrator = DatabaseMigrator()

        migrator.registerMigration("createJournalEntries") { db in
            // Create the journal_entries table
            try db.create(table: "journalEntry") { t in
                t.column("id", .text).primaryKey()
                t.column("content", .text).notNull()
                t.column("createdAt", .datetime).notNull()
                // We store the embedding as a BLOB (Binary Large Object)
                t.column("embedding", .blob).notNull()
            }
        }

        try migrator.migrate(dbQueue)
    }

    /// Persists a new journal entry into the database.
    /// - Parameter entry: The entry to save.
    func saveEntry(_ entry: JournalEntry) async throws {
        try await dbQueue.write { db in
            try entry.insert(db)
        }
        logger.info("Successfully saved entry: \(entry.id)")
    }

    /// Retrieves all entries, sorted by date.
    /// - Returns: An array of JournalEntry objects.
    func fetchAllEntries() async throws -> [JournalEntry] {
        try await dbQueue.read { db in
            try JournalEntry.order(JournalEntry.Columns.createdAt.desc).fetchAll(db)
        }
    }
}

// MARK: - GRDB Custom Type Mapping

/// To allow GRDB to understand how to convert our `Embedding` struct to and from a SQLite BLOB,
/// we extend the Embedding type to conform to `DatabaseValueConvertible`.
extension Embedding: DatabaseValueConvertible {
    /// Converts the Embedding into a format SQLite understands (Data/BLOB).
    func databaseValue(at column: String, in row: Row) -> DatabaseValue {
        return embeddingToData().databaseValue
    }
    
    /// A helper to facilitate the conversion.
    private func embeddingToData() -> Data {
        return values.withUnsafeBytes { Data($0) }
    }

    /// Tells GRDB how to create an Embedding from a value retrieved from the database.
    static func fromDatabaseValue(_ dbValue: DatabaseValue) -> Embedding? {
        // Attempt to extract Data from the BLOB column
        guard let data = Data.fromDatabaseValue(dbValue) else {
            return nil
        }
        return Embedding.fromData(data)
    }
}

// MARK: - Example Usage (Simulation)

@main
struct SemanticJournalApp {
    static func main() async throws {
        // 1. Setup the file path for our database
        let fileManager = FileManager.default
        let docDir = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dbURL = docDir.appendingPathComponent("journal.sqlite")
        
        print("Database Path: \(dbURL.path)")

        // 2. Initialize the Database Manager (The Actor)
        let manager = try JournalDatabaseManager(databaseURL: dbURL)

        // 3. Simulate creating an embedding (In a real app, this comes from an MLModel)
        // Let's simulate a 3-dimensional vector for simplicity.
        let mockEmbedding = Embedding(values: [0.12, -0.59, 0.88])
        
        let newEntry = JournalEntry(
            id: UUID(),
            content: "Today was a wonderful day! I felt very productive.",
            createdAt: Date(),
            embedding: mockEmbedding
        )

        // 4. Save the entry
        print("Saving entry...")
        try await manager.saveEntry(newEntry)

        // 5. Fetch and verify
        print("Fetching entries...")
        let entries = try await manager.fetchAllEntries()
        
        for entry in entries {
            print("---")
            print("Content: \(entry.content)")
            print("Embedding: \(entry.embedding.values)")
        }
    }
}
