
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
enum TaskPriority: String, Codable, CaseIterable {
    case low, medium, high, urgent
    case unknown // Added to handle unrecognized priority strings gracefully

    // Custom initializer to handle unknown raw values without throwing
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let rawValue = try container.decode(String.self)
        self = TaskPriority(rawValue: rawValue) ?? .unknown
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct TaskItem: Codable {
    let title: String
    let dueDate: Date?
    let priority: TaskPriority
    let tags: [String]
}

@available(iOS 18.0, macOS 15.0, *)
func solveExercise2() {
    print("\n--- Exercise 2: Task Management Item Enrichment ---")

    let decoder = JSONDecoder()
    // Configure date decoding strategy for ISO 8601
    decoder.dateDecodingStrategy = .iso8601

    // Simulate LLM Output 1: Valid TaskItem
    let jsonString1 = """
    {
      "title": "Submit project proposal",
      "dueDate": "2025-04-15T17:00:00Z",
      "priority": "high",
      "tags": ["work", "urgent", "deadline"]
    }
    """

    // Simulate LLM Output 2: Missing dueDate, unknown priority ("critical")
    let jsonString2 = """
    {
      "title": "Call client X",
      "priority": "critical",
      "tags": ["client", "follow-up"]
    }
    """

    // Simulate LLM Output 3: Malformed dueDate format
    let jsonString3 = """
    {
      "title": "Review documentation",
      "dueDate": "2025/01/01", // Incorrect date format, will cause decoding error
      "priority": "medium",
      "tags": ["documentation"]
    }
    """

    // Decoding Logic for jsonString1
    print("\nAttempting to decode TaskItem 1 (valid):")
    if let jsonData = jsonString1.data(using: .utf8) {
        do {
            let task = try decoder.decode(TaskItem.self, from: jsonData)
            print("Successfully decoded TaskItem 1:")
            print("  Title: \(task.title)")
            print("  Due Date: \(task.dueDate?.formatted(date: .abbreviated, time: .shortened) ?? "N/A")")
            print("  Priority: \(task.priority.rawValue)")
            print("  Tags: \(task.tags.joined(separator: ", "))")
        } catch {
            print("Error decoding TaskItem 1: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 1 to Data.")
    }

    // Decoding Logic for jsonString2
    print("\nAttempting to decode TaskItem 2 (missing dueDate, unknown priority):")
    if let jsonData = jsonString2.data(using: .utf8) {
        do {
            let task = try decoder.decode(TaskItem.self, from: jsonData)
            print("Successfully decoded TaskItem 2:")
            print("  Title: \(task.title)")
            print("  Due Date: \(task.dueDate?.formatted(date: .abbreviated, time: .shortened) ?? "N/A")")
            print("  Priority: \(task.priority.rawValue) (Note: 'critical' was mapped to .unknown)")
            print("  Tags: \(task.tags.joined(separator: ", "))")
        } catch {
            print("Error decoding TaskItem 2: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 2 to Data.")
    }

    // Decoding Logic for jsonString3 (malformed dueDate)
    print("\nAttempting to decode TaskItem 3 (malformed dueDate):")
    if let jsonData = jsonString3.data(using: .utf8) {
        do {
            let task = try decoder.decode(TaskItem.self, from: jsonData)
            print("Successfully decoded TaskItem 3 (unexpected!):")
            print("  Title: \(task.title)")
        } catch let decodingError as DecodingError {
            print("Error decoding TaskItem 3 (expected due to date format): \(decodingError.localizedDescription)")
            switch decodingError {
            case .typeMismatch(let type, let context):
                print("  Type Mismatch: Expected \(type) but found different type at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .valueNotFound(let type, let context):
                print("  Value Not Found: Expected \(type) but value was missing at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .keyNotFound(let key, let context):
                print("  Key Not Found: Key '\(key.stringValue)' was missing at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .dataCorrupted(let context):
                print("  Data Corrupted: \(context.debugDescription) at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            @unknown default:
                print("  An unknown decoding error occurred.")
            }
        } catch {
            print("Generic error decoding TaskItem 3: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 3 to Data.")
    }
}

// Uncomment to run Exercise 2
// solveExercise2()
