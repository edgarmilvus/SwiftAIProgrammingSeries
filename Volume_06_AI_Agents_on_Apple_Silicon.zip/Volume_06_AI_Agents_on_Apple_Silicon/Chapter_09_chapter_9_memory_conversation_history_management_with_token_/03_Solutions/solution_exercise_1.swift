
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// 1. ChatMessage Structure
struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let role: String // e.g., "user", "assistant", "system"
    let content: String
    let timestamp: Date
}

// 2. Tokenizer Protocol and MockTokenizer Implementation
protocol Tokenizer {
    func tokenize(_ text: String) -> [Int]
    func countTokens(_ text: String) -> Int
}

struct MockTokenizer: Tokenizer {
    func tokenize(_ text: String) -> [Int] {
        // Simulate tokenization: ~4 characters per token on average
        let tokenCount = max(1, text.count / 4)
        return Array(repeating: 1, count: tokenCount) // Return an array of dummy tokens
    }

    func countTokens(_ text: String) -> Int {
        return tokenize(text).count
    }
}

// 3. calculateTokenCount Function
func calculateTokenCount(for messages: [ChatMessage], using tokenizer: Tokenizer) -> Int {
    return messages.reduce(0) { total, message in
        total + tokenizer.countTokens(message.content)
    }
}

// 4. truncateConversation Function
func truncateConversation(messages: [ChatMessage], tokenBudget: Int, using tokenizer: Tokenizer) -> [ChatMessage] {
    var currentMessages = messages // Work on a mutable copy
    var currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)

    // Repeatedly remove the oldest message until budget is met or no messages left
    while currentTokenCount > tokenBudget && !currentMessages.isEmpty {
        currentMessages.removeFirst() // Remove the oldest message (at index 0)
        currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
    }
    
    return currentMessages
}

// Example Usage (for testing the implementation)
/*
let tokenizer = MockTokenizer()
var conversation: [ChatMessage] = [
    ChatMessage(role: "user", content: "Hello, how are you?", timestamp: Date().addingTimeInterval(-300)), // ~5 tokens
    ChatMessage(role: "assistant", content: "I'm doing great, thanks for asking!", timestamp: Date().addingTimeInterval(-280)), // ~8 tokens
    ChatMessage(role: "user", content: "That's good to hear. What have you been up to?", timestamp: Date().addingTimeInterval(-260)), // ~10 tokens
    ChatMessage(role: "assistant", content: "Just processing some data and learning new things.", timestamp: Date().addingTimeInterval(-240)), // ~10 tokens
    ChatMessage(role: "user", content: "Interesting! Can you tell me more about that?", timestamp: Date().addingTimeInterval(-220)), // ~9 tokens
]

let originalTokenCount = calculateTokenCount(for: conversation, using: tokenizer)
print("Original conversation token count: \(originalTokenCount)") // Expected: ~42 tokens

let budget = 20
let truncated = truncateConversation(messages: conversation, tokenBudget: budget, using: tokenizer)
let truncatedTokenCount = calculateTokenCount(for: truncated, using: tokenizer)
print("Truncated conversation token count (budget \(budget)): \(truncatedTokenCount)")
print("Truncated messages:")
truncated.forEach { print("- \($0.role): \($0.content)") }
// Expected output will show fewer messages from the beginning, total tokens <= 20
*/
