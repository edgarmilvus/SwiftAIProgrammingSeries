
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    actor SpeechRecognizerManager: ObservableObject {
        // @Published is not Sendable, so we use a non-isolated property with a dedicated publisher
        // or a Sendable type for cross-actor updates.
        // For simplicity, we'll demonstrate using a property that can be observed from the MainActor.
        @MainActor @Published var currentTranscription: String = ""
        @MainActor @Published var isRecognizing: Bool = false
        @MainActor @Published var authorizationStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined

        private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
        private var recognitionTask: SFSpeechRecognitionTask?
        private let audioEngine = AVAudioEngine()

        init() {
            Task { @MainActor in
                self.authorizationStatus = await SFSpeechRecognizer.authorizationStatus()
            }
        }

        func requestAuthorization() async {
            await SFSpeechRecognizer.requestAuthorization()
            await MainActor.run {
                self.authorizationStatus = SFSpeechRecognizer.authorizationStatus()
            }
        }

        func startRecognition() async throws {
            guard speechRecognizer?.isAvailable ?? false else {
                throw RecognitionError.recognizerUnavailable
            }
            guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
                throw RecognitionError.notAuthorized
            }

            // Ensure previous task is cancelled
            recognitionTask?.cancel()
            recognitionTask = nil

            await MainActor.run { isRecognizing = true }

            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

            let inputNode = audioEngine.inputNode
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            recognitionRequest?.shouldReportPartialResults = true // Get real-time updates

            guard let recognitionRequest = recognitionRequest else {
                throw RecognitionError.requestCreationFailed
            }

            // Start the recognition task
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { result, error in
                Task { @MainActor in // Update UI on MainActor
                    if let result = result {
                        self.currentTranscription = result.bestTranscription.formattedString
                    } else if let error = error {
                        print("Recognition error: \(error.localizedDescription)")
                        self.stopRecognition()
                    }
                }
            }

            // Configure and start the audio engine
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                recognitionRequest.append(buffer)
            }

            audioEngine.prepare()
            try audioEngine.start()
        }

        func stopRecognition() {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
            recognitionRequest?.endAudio()
            recognitionRequest = nil
            recognitionTask?.cancel()
            recognitionTask = nil

            Task { @MainActor in
                await AVAudioSession.sharedInstance().setActive(false)
                isRecognizing = false
            }
        }

        enum RecognitionError: Error {
            case recognizerUnavailable
            case notAuthorized
            case requestCreationFailed
        }
    }
    