
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import Speech
import AVFoundation // For AVAudioSession category setup
import UserNotifications // For local notifications

// MARK: - BackgroundTranscriptionViewController

@MainActor
class BackgroundTranscriptionViewController: UIViewController, UIDocumentPickerDelegate, SFSpeechRecognitionTaskDelegate {

    // MARK: - UI Elements
    private let importButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Import Audio for Background Transcription", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready to import audio."
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let transcriptionResultTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.isEditable = false
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Transcribed results will appear here."
        return textView
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var currentRecognitionTask: SFSpeechRecognitionTask?
    private var currentAudioFileName: String?

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestPermissions()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(importButton)
        view.addSubview(statusLabel)
        view.addSubview(transcriptionResultTextView)

        NSLayoutConstraint.activate([
            importButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            importButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            importButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            importButton.heightAnchor.constraint(equalToConstant: 50),

            statusLabel.topAnchor.constraint(equalTo: importButton.bottomAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            transcriptionResultTextView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            transcriptionResultTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            transcriptionResultTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            transcriptionResultTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        importButton.addTarget(self, action: #selector(importAudioTapped), for: .touchUpInside)
    }

    // MARK: - Permissions Handling
    private func setupSpeechRecognizer() {
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US")) // Default locale for transcription
        speechRecognizer?.delegate = self // To monitor availability
    }

    private func requestPermissions() {
        Task {
            // Request Speech Recognition Permission
            let speechAuthStatus = await SFSpeechRecognizer.requestAuthorization()
            if speechAuthStatus != .authorized {
                self.showPermissionAlert(message: "Speech recognition access is required for transcription.")
                importButton.isEnabled = false
                statusLabel.text = "Permissions denied. Check settings."
                return
            }

            // Request Notification Permission
            let notificationCenter = UNUserNotificationCenter.current()
            let notificationSettings = await notificationCenter.notificationSettings()
            if notificationSettings.authorizationStatus == .denied {
                self.showPermissionAlert(message: "Notification access is required to inform you about transcription completion.")
            } else if notificationSettings.authorizationStatus == .notDetermined {
                do {
                    let granted = try await notificationCenter.requestAuthorization(options: [.alert, .sound, .badge])
                    if !granted {
                        print("Notification permission denied.")
                        self.statusLabel.text = "Notifications denied. Transcription will not notify."
                    }
                } catch {
                    print("Error requesting notification permission: \(error)")
                }
            }
            
            // Set audio session category to allow background processing if needed (though SFSpeechURLRecognitionRequest handles this mostly)
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default) // Or .soloAmbient
                try AVAudioSession.sharedInstance().setActive(true)
            } catch {
                print("Failed to set audio session category: \(error)")
            }

            // Update UI based on permissions
            importButton.isEnabled = speechAuthStatus == .authorized
            if importButton.isEnabled {
                statusLabel.text = "Ready to import audio."
            }
        }
    }

    private func showPermissionAlert(message: String) {
        let alert = UIAlertController(title: "Permission Required", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    // MARK: - Audio File Import
    @objc private func importAudioTapped() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.audio])
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true, completion: nil)
    }

    // MARK: - UIDocumentPickerDelegate
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let selectedURL = urls.first else { return }
        
        // Copy the file to a persistent location in the app's sandbox (e.g., Documents directory)
        // This ensures the file is available even after the app closes or temp files are cleaned.
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let destinationURL = documentsPath.appendingPathComponent(selectedURL.lastPathComponent)

        do {
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.copyItem(at: selectedURL, to: destinationURL)
            
            currentAudioFileName = selectedURL.lastPathComponent
            statusLabel.text = "Imported '\(currentAudioFileName!)'. Starting background transcription..."
            transcriptionResultTextView.text = "Transcribing '\(currentAudioFileName!)'..."
            
            // Start transcription in a detached Task to allow it to run even if UI is dismissed
            Task.detached { [weak self] in
                await self?.transcribeAudioFileInBackground(url: destinationURL)
            }
            
        } catch {
            print("Error copying audio file: \(error)")
            statusLabel.text = "Error importing audio: \(error.localizedDescription)"
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        statusLabel.text = "Audio import cancelled."
    }

    // MARK: - Background Transcription Logic
    private func transcribeAudioFileInBackground(url: URL) async {
        guard let speechRecognizer = speechRecognizer else {
            await updateUIAndNotify(status: "Error: Speech recognizer not initialized.", transcription: nil, success: false)
            return
        }

        // Simulate background activity. For short tasks, `Task.detached` is enough.
        // For truly long-running tasks (minutes+), `BGTaskScheduler` is required.
        // CONCEPTUAL NOTE for BGTaskScheduler:
        // For a production app, you would register a background task identifier in Info.plist.
        // When transcription starts, you'd request a `BGProcessingTaskRequest` or `BGAppRefreshTaskRequest`.
        // The `SFSpeechURLRecognitionRequest` would then be run within the `perform` handler of this `BGTask`.
        // The task would need to call `task.setTaskCompleted(success: Bool)` when done.
        // This requires careful setup and testing of background modes.
        // For this exercise, `Task.detached` simulates the "background" nature within the app's lifecycle.
        
        let backgroundActivity = ProcessInfo.processInfo.beginActivity(options: .utility, reason: "Transcribing audio file")

        let request = SFSpeechURLRecognitionRequest(url: url)
        request.shouldReportPartialResults = false // We want the final result

        do {
            // SFSpeechRecognizer.recognitionTask(with:delegate:) for progress tracking
            let (task, result) = try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<(SFSpeechRecognitionTask, SFSpeechRecognitionResult?), Error>) in
                self.currentRecognitionTask = speechRecognizer.recognitionTask(with: request) { result, error in
                    if let error = error {
                        continuation.resume(throwing: error)
                    } else {
                        continuation.resume(returning: (self.currentRecognitionTask!, result))
                    }
                }
                self.currentRecognitionTask?.delegate = self // Set delegate for state changes
            }

            if let transcription = result?.bestTranscription {
                await updateUIAndNotify(status: "Transcription complete!", transcription: transcription.formattedString, success: true)
                // In a real app, save the full SFTranscription object persistently
            } else {
                await updateUIAndNotify(status: "Transcription completed, but no text found.", transcription: nil, success: false)
            }
            
            ProcessInfo.processInfo.endActivity(backgroundActivity)

        } catch {
            await updateUIAndNotify(status: "Transcription failed: \(error.localizedDescription)", transcription: nil, success: false)
            ProcessInfo.processInfo.endActivity(backgroundActivity)
        }
    }

    // MARK: - UI Update & Notification
    private func updateUIAndNotify(status: String, transcription: String?, success: Bool) async {
        // Ensure UI updates are on the main actor
        await MainActor.run {
            self.statusLabel.text = status
            if let transcription = transcription {
                self.transcriptionResultTextView.text = transcription
            } else {
                self.transcriptionResultTextView.text = "No transcription available."
            }
            self.importButton.isEnabled = true // Re-enable import button
        }

        // Schedule local notification
        let content = UNMutableNotificationContent()
        content.title = "Transcription Complete!"
        content.body = "Your audio file '\(currentAudioFileName ?? "Unknown")' has been transcribed. " + (success ? "Tap to view." : "Failed to transcribe.")
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false) // Immediate notification
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        do {
            try await UNUserNotificationCenter.current().add(request)
            print("Notification scheduled successfully.")
        } catch {
            print("Error scheduling notification: \(error)")
        }
    }

    // MARK: - SFSpeechRecognitionTaskDelegate (for progress tracking)
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didHypothesizeTranscription transcription: SFTranscription) {
        // This delegate method is typically for live streaming, but for SFSpeechURLRecognitionRequest
        // it might not be called or only called once at the end with a partial result.
        // For this exercise, we focus on overall completion.
        Task { @MainActor in
            self.statusLabel.text = "Transcribing... (Partial: \(transcription.formattedString.prefix(50))...)"
        }
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishRecognition recognitionResult: SFSpeechRecognitionResult) {
        // This method is called when the task has finished processing audio and produced a final result.
        // The final result is handled in the `withCheckedThrowingContinuation` completion block.
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishSuccessfully successfully: Bool) {
        // This method is called when the task has completed, regardless of success.
        // We handle success/failure in the `withCheckedThrowingContinuation` block.
    }

    func speechRecognitionTaskWasCancelled(_ task: SFSpeechRecognitionTask) {
        Task { @MainActor in
            self.statusLabel.text = "Transcription cancelled."
            self.importButton.isEnabled = true
        }
        print("Transcription task was cancelled.")
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didStopRecordingAt audioStartTime: TimeInterval) {
        // This is not relevant for SFSpeechURLRecognitionRequest as it doesn't "record".
    }

    // MARK: - SFSpeechRecognizerDelegate (for availability changes)
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        Task { @MainActor in
            if available {
                self.importButton.isEnabled = true
                self.statusLabel.text = "Ready to import audio."
            } else {
                self.importButton.isEnabled = false
                self.statusLabel.text = "Speech recognition currently unavailable."
            }
        }
    }
}
