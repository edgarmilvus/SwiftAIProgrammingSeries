
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Package.swift Dependency Specification
/*
// In a real project, you might include a dependency for a hashing library 
// or a remote configuration SDK like Firebase Remote Config.
// For this implementation, we use standard Swift libraries.

let package = Package(
    name: "AIEngine",
    platforms: [.iOS(.v18)],
    dependencies: [
        // .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
    ],
    targets: [
        .target(name: "AIEngine", dependencies: [])
    ]
)
*/

import Foundation
import CryptoKit

// MARK: - Domain Models

/// Represents the different AI model architectures available for a specific feature.
/// Using `Sendable` to ensure safe transfer across concurrency boundaries.
enum AIModelVariant: String, Codable, Sendable {
    case remoteGPT4o = "gpt-4o"
    case remoteLlama3 = "llama-3-70b"
    case localCoreML = "coreml-summarizer-v2"
    case fallbackSmallModel = "tiny-llm"
}

/// The configuration for an experiment, defining how traffic is split.
struct ExperimentConfig: Sendable {
    let featureKey: String
    let variants: [AIModelVariant: Double] // Variant and its weight (0.0 - 1.0)
    let isActive: Bool
}

/// Error types specifically for the Experimentation Engine.
enum ExperimentationError: Error, LocalizedError {
    case flagNotFound(String)
    case hashingFailure
    case remoteConfigUnavailable

    var errorDescription: String? {
        switch self {
        case .flagNotFound(let key): return "No configuration found for feature: \(key)"
        case .hashingFailure: return "Failed to generate deterministic hash for user."
        case .remoteConfigUnavailable: return "Remote configuration is currently unreachable."
        }
    }
}

// MARK: - The Experimentation Actor

/// `FeatureFlagManager` is an Actor, which is critical in Swift 6.
/// It prevents data races when multiple concurrent AI tasks attempt to 
/// read or update feature flag configurations.
actor FeatureFlagManager {
    private var configurations: [String: ExperimentConfig] = [:]
    private let userID: String
    
    init(userID: String) {
        self.userID = userID
    }
    
    /// Updates the local configuration cache. In a real app, this would be 
    /// called after fetching from a remote server (e.g., Firebase or LaunchDarkly).
    func updateConfigurations(_ newConfigs: [ExperimentConfig]) {
        for config in newConfigs {
            configurations[config.featureKey] = config
        }
    }
    
    /// Determines which AI variant a user should receive using deterministic hashing.
    /// - Parameter featureKey: The unique identifier for the feature being tested.
    /// - Returns: The assigned `AIModelVariant`.
    /// - Throws: `ExperimentationError` if the flag is missing or hashing fails.
    func getVariant(for featureKey: String) throws -> AIModelVariant {
        guard let config = configurations[featureKey], config.isActive else {
            // If the experiment is off, return a safe default
            return .fallbackSmallModel
        }
        
        let hashValue = try calculateDeterministicHash(for: featureKey)
        return assignVariant(from: config, basedOn: hashValue)
    }
    
    /// Generates a stable hash between 0 and 99 based on the UserID and FeatureKey.
    /// This ensures that even if the app restarts, the user stays in the same bucket.
    private func calculateDeterministicHash(for featureKey: String) throws -> Int {
        let combinedString = "\(userID)-\(featureKey)"
        guard let data = combinedString.data(using: .utf8) else {
            throw ExperimentationError.hashingFailure
        }
        
        let hash = SHA256.hash(data: data)
        // Use the first 4 bytes of the hash to create an integer
        let hashInt = hash.withUnsafeBytes { $0.load(as: UInt32.self) }
        return Int(hashInt % 100)
    }
    
    /// Maps the 0-99 hash value to a specific variant based on weighted distribution.
    private func assignVariant(from config: ExperimentConfig, basedOn hash: Int) -> AIModelVariant {
        var cumulativeWeight: Double = 0.0
        
        // Sort variants to ensure deterministic iteration
        let sortedVariants = config.variants.keys.sorted { $0.rawValue < $1.rawValue }
        
        for variant in sortedVariants {
            let weight = config.variants[variant] ?? 0.0
            cumulativeWeight += weight
            if Double(hash) < (cumulativeWeight * 100.0) {
                return variant
            }
        }
        
        return .fallbackSmallModel
    }
}

// MARK: - AI Service Implementation

/// A protocol defining the requirements for an AI Provider.
/// This allows us to swap between Remote and Local models seamlessly.
protocol AIProvider: Sendable {
    func generateResponse(prompt: String) async throws -> String
}

/// A concrete implementation for a Remote LLM.
struct RemoteAIProvider: AIProvider {
    let modelName: AIModelVariant
    
    func generateResponse(prompt: String) async throws -> String {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1.5))
        return "[Remote \(modelName.rawValue) Response] Summarized: \(prompt.prefix(20))..."
    }
}

/// A concrete implementation for a Local CoreML model.
struct LocalAIProvider: AIProvider {
    let modelName: AIModelVariant
    
    func generateResponse(prompt: String) async throws -> String {
        // Simulate local computation latency
        try await Task.sleep(for: .seconds(0.5))
        return "[Local \(modelName.rawValue) Response] Summarized: \(prompt.prefix(20))..."
    }
}

/// The primary service used by the UI to perform AI operations.
/// It uses the `FeatureFlagManager` to decide which provider to instantiate.
final class SummarizationService: Sendable {
    private let flagManager: FeatureFlagManager
    
    init(flagManager: FeatureFlagManager) {
        self.flagManager = flagManager
    }
    
    /// Performs the summarization task using the variant assigned by the experiment.
    /// - Parameter text: The input text to summarize.
    /// - Returns: The summarized string.
    func summarize(text: String) async throws -> (summary: String, variant: AIModelVariant) {
        // 1. Determine the variant via the Actor
        let variant = try await flagManager.getVariant(for: "summarization_experiment_v1")
        
        // 2. Select the appropriate provider (Strategy Pattern)
        let provider: any AIProvider = switch variant {
        case .remoteGPT4o, .remoteLlama3:
            RemoteAIProvider(modelName: variant)
        case .localCoreML:
            LocalAIProvider(modelName: variant)
        case .fallbackSmallModel:
            LocalAIProvider(modelName: .fallbackSmallModel)
        }
        
        // 3. Execute the AI task
        let result = try await provider.generateResponse(prompt: text)
        
        // 4. Return result along with the variant for telemetry purposes
        return (result, variant)
    }
}

// MARK: - Application Entry Point (Simulation)

@available(iOS 18.0, *)
@main
struct AIApp {
    static func main() async {
        print("🚀 Starting AI Experimentation Engine...\n")
        
        let userID = "user_abc_123"
        let flagManager = FeatureFlagManager(userID: userID)
        
        // --- STEP 1: Simulate Remote Config Fetching ---
        // We define an experiment where 40% get GPT-4o, 40% get Llama-3, and 20% get Local CoreML.
        let experiment = ExperimentConfig(
            featureKey: "summarization_experiment_v1",
            variants: [
                .remoteGPT4o: 0.4,
                .remoteLlama3: 0.4,
                .localCoreML: 0.2
            ],
            isActive: true
        )
        
        await flagManager.updateConfigurations([experiment])
        print("✅ Remote configuration loaded.\n")
        
        // --- STEP 2: Simulate Multiple Concurrent User Requests ---
        let service = SummarizationService(flagManager: flagManager)
        let inputTexts = [
            "The quick brown fox jumps over the lazy dog.",
            "Artificial intelligence is transforming the way we write code.",
            "Swift 6 introduces strict concurrency checking to prevent data races.",
            "The weather in Cupertino is quite sunny today."
        ]
        
        print("📡 Dispatching concurrent AI requests...\n")
        
        // Use a TaskGroup to simulate high-concurrency environments
        await withTaskGroup(of: Void.self) { group in
            for text in inputTexts {
                group.addTask {
                    do {
                        let (summary, variant) = try await service.summarize(text: text)
                        print("📝 [RESULT] Variant: \(variant.rawValue) | Output: \(summary)")
                        // In a real app, you would send 'variant' to your analytics (Mixpanel/Amplitude)
                    } catch {
                        print("❌ [ERROR] Failed to summarize: \(error.localizedDescription)")
                    }
                }
            }
        }
        
        print("\n🏁 All tasks completed.")
    }
}
