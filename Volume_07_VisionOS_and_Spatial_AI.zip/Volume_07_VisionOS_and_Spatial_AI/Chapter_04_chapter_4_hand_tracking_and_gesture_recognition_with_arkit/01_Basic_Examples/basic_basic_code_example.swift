
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import ARKit
import RealityKit
import Observation

/// An error type specific to Hand Tracking operations.
enum HandTrackingError: Error {
    case sessionFailed
    case permissionDenied
}

/// A manager responsible for handling the ARKit hand tracking session.
/// This class uses the Swift 6 `@Observable` macro to provide real-time 
/// updates to the SwiftUI view hierarchy.
@available(visionOS 1.0, *)
@Observable
@MainActor
final class HandTrackingManager {
    
    /// The current state of the tracked hand.
    /// We track whether a hand is present and its current position.
    private(set) var isHandTracked: Bool = false
    
    /// The 3D position of the detected hand's palm.
    /// This is used to position virtual objects relative to the user.
    private(set) var handPosition: SIMD3<Float> = .zero
    
    /// A boolean indicating if a pinch gesture is currently detected.
    /// This is the primary interaction trigger for our Music Controller.
    private(set) var isPinching: Bool = false
    
    /// The underlying ARKit session.
    private var session = ARKitSession()
    
    /// The provider that delivers hand anchor updates.
    private var handProvider: HandTrackingProvider?
    
    /// A reference to the task managing the tracking loop to allow for clean cancellation.
    private var trackingTask: Task<Void, Never>?

    init() {}

    /// Starts the hand tracking session and begins listening to the hand anchor stream.
    /// - Throws: `HandTrackingError` if the session cannot start.
    func startTracking() async throws {
        // Initialize the provider
        let provider = HandTrackingProvider()
        self.handProvider = provider
        
        // Start the ARKit session
        try await session.run([provider])
        
        // Begin the asynchronous loop to process hand updates
        trackingTask = Task { [weak self] in
            // We iterate over the hand anchor updates provided by the HandTrackingProvider.
            // This is an AsyncSequence, which is highly efficient for high-frequency data.
            for await update in provider.anchorUpdates {
                await self?.processHandUpdate(update)
            }
        }
    }

    /// Stops the tracking session and cancels any ongoing tasks.
    func stopTracking() {
        trackingTask?.cancel()
        trackingTask = nil
    }

    /// Processes a single update from the HandTrackingProvider.
    /// - Parameter update: The latest information about a hand anchor.
    /// - Note: This method is marked as @MainActor via the class definition 
    ///   to ensure UI-bound properties are updated on the main thread.
    private func processHandUpdate(_ update: HandAnchor) {
        // 1. Update the tracking status
        self.isHandTracked = true
        
        // 2. Extract the anchor's transform (the position and orientation of the hand)
        // The anchor's transform is relative to the world coordinate system.
        let transform = update.originFromAnchorTransform
        let position = transform.columns.3.xyz // Helper to get translation
        self.handPosition = position
        
        // 3. Perform Gesture Recognition (Pinch Detection)
        // We check the distance between the thumb tip and the index finger tip.
        self.isPinching = detectPinch(in: update)
    }

    /// Analyzes the hand skeleton to determine if a pinch is occurring.
    /// - Parameter anchor: The current hand anchor containing the skeleton.
    /// - Returns: A boolean indicating if the pinch threshold is met.
    private func detectPinch(in anchor: HandAnchor) -> Bool {
        // Access the skeleton of the hand
        let skeleton = anchor.handSkeleton
        
        // Retrieve the joints for the thumb and index finger tips
        // These joint indices are defined by ARKit's hand skeleton hierarchy.
        guard let thumbTip = skeleton.joint(.thumbTip),
              let indexTip = skeleton.joint(.indexFingerTip) else {
            return false
        }
        
        // Calculate the Euclidean distance between the two joint positions in 3D space.
        // We use the joint's transform relative to the anchor.
        let thumbPos = thumbTip.anchorFromJointTransform.columns.3.xyz
        let indexPos = indexTip.anchorFromJointTransform.columns.3.xyz
        
        let distance = simd_distance(thumbPos, indexPos)
        
        // A threshold of ~2cm (0.02 meters) is generally used for a "pinch" in spatial UI.
        return distance < 0.02
    }
}

// MARK: - Helpers

extension SIMD4 where Scalar == Float {
    /// Helper to extract the XYZ components from a SIMD4 vector (the translation column).
    var xyz: SIMD3<Float> {
        SIMD3(x, y, z)
    }
}

// MARK: - UI Layer

/// The main view for the Spatial Music Controller.
@available(visionOS 1.0, *)
struct SpatialMusicControllerView: View {
    @State private var trackingManager = HandTrackingManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Spatial Music Controller")
                .font(.largeTitle)
            
            // Visual feedback for the tracking state
            HStack {
                Circle()
                    .fill(trackingManager.isHandTracked ? Color.green : Color.red)
                    .frame(width: 15, height: 15)
                Text(trackingManager.isHandTracked ? "Hand Detected" : "Searching for Hand...")
            }
            
            // The "Virtual Knob" - In a real app, this would be a RealityKit Entity.
            // Here, we use a SwiftUI representation for simplicity.
            ZStack {
                Circle()
                    .stroke(Color.white.opacity(0.5), lineWidth: 4)
                    .frame(width: 200, height: 200)
                
                Circle()
                    .fill(trackingManager.isPinching ? Color.blue : Color.gray)
                    .frame(width: 180, height: 180)
                    .scaleEffect(trackingManager.isPinching ? 1.1 : 1.0)
                    .animation(.spring(), value: trackingManager.isPinching)
                
                Text(trackingManager.isPinching ? "Volume Up" : "Pinch to Adjust")
                    .foregroundColor(.white)
            }
            .offset(y: trackingManager.isHandTracked ? 0 : 50) // Subtle movement
            
            Button("Start Interaction") {
                Task {
                    do {
                        try await trackingManager.startTracking()
                    } catch {
                        print("Failed to start tracking: \(error)")
                    }
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}
