/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// SecureSettingsPanel.tsx
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Switch, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { BlurView } from 'expo-blur';

export default function SecureSettingsPanel() {
  const [isLocked, setIsLocked] = useState(true);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [lastActivity, setLastActivity] = useState(Date.now());
  
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // 1. Activity Monitor & Timeout Logic
  useEffect(() => {
    // Reset the timer whenever lastActivity changes
    if (!isLocked) {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      
      timeoutRef.current = setTimeout(() => {
        setIsLocked(true);
        Alert.alert("Session Timed Out", "You were inactive for 30 seconds.");
      }, 30000); // 30 seconds
    }

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [lastActivity, isLocked]);

  // Helper to update activity timestamp
  const recordActivity = () => {
    if (!isLocked) {
      setLastActivity(Date.now());
    }
  };

  // 2. Authentication Trigger
  const authenticate = async () => {
    setIsAuthenticating(true);
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Verify to access Secure Settings',
      });

      if (result.success) {
        setIsLocked(false);
        setLastActivity(Date.now()); // Start timer
      } else {
        Alert.alert("Access Denied", "Biometric authentication failed.");
      }
    } catch (error) {
      Alert.alert("Error", "Could not authenticate.");
    } finally {
      setIsAuthenticating(false);
    }
  };

  // 3. Render UI
  return (
    // We wrap the whole container in a touchable to track activity
    <TouchableOpacity 
      style={styles.container} 
      activeOpacity={1} 
      onPress={recordActivity}
      disabled={isLocked}
    >
      <Text style={styles.header}>Secure Settings</Text>

      {/* Blur Overlay */}
      {isLocked && (
        <BlurView intensity={80} style={StyleSheet.absoluteFill} tint="dark">
          <View style={styles.blurContent}>
            {isAuthenticating ? (
              <ActivityIndicator size="large" color="#fff" />
            ) : (
              <>
                <Text style={styles.lockText}>🔒 Locked</Text>
                <TouchableOpacity style={styles.authButton} onPress={authenticate}>
                  <Text style={styles.authButtonText}>Edit Settings</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </BlurView>
      )}

      {/* Sensitive Content */}
      <View style={styles.settingsList}>
        <View style={styles.settingItem} pointerEvents={isLocked ? 'none' : 'auto'}>
          <Text style={isLocked ? styles.disabledText : styles.label}>Dark Mode</Text>
          <Switch value={darkMode} onValueChange={(val) => { setDarkMode(val); recordActivity(); }} />
        </View>

        <TouchableOpacity 
          style={[styles.settingItem, styles.dangerItem]} 
          disabled={isLocked}
          onPress={() => { recordActivity(); Alert.alert("Delete Account", "Confirmed."); }}
        >
          <Text style={[styles.label, isLocked && styles.disabledText, { color: isLocked ? 'gray' : 'red' }]}>Delete Account</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f0f0', padding: 20 },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  blurContent: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center' },
  lockText: { color: 'white', fontSize: 24, marginBottom: 15, fontWeight: 'bold' },
  authButton: { backgroundColor: '#007AFF', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 8 },
  authButtonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  settingsList: { gap: 15 },
  settingItem: { backgroundColor: 'white', padding: 15, borderRadius: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  dangerItem: { backgroundColor: '#ffebee' },
  label: { fontSize: 16, fontWeight: '500' },
  disabledText: { color: '#999', textDecorationLine: 'line-through' },
});
