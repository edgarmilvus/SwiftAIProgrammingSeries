
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import RealityKit
import ARKit
import Vision

struct PantryItem: Sendable {
    let name: String
    let expirationDate: Date
}

/// Manages the lifecycle and spatial persistence of detected pantry items.
actor PantryInventoryManager {
    private let mockDatabase: [String: PantryItem] = [
        "Milk": PantryItem(name: "Milk", expirationDate: Date().addingTimeInterval(86400 * 2)), // 2 days
        "Cereal": PantryItem(name: "Cereal", expirationDate: Date().addingTimeInterval(86400 * 30)), // 30 days
        "Apple": PantryItem(name: "Apple", expirationDate: Date().addingTimeInterval(-86400)) // Expired
    ]
    
    /// Tracks active entities in the 3D scene to prevent flickering.
    /// Key: Label name, Value: (Entity, lastKnownPosition)
    private var trackedItems: [String: (entity: Entity, position: SIMD3<Float>)] = [:]
    
    /// Threshold in meters to consider a detection the "same" object.
    private let proximityThreshold: Float = 0.15 

    func processDetections(
        _ observations: [VNRecognizedObjectObservation],
        currentFrame: ARFrame,
        arView: ARView
    ) async -> [Entity] {
        var newEntities: [Entity] = []
        
        for observation in observations {
            guard let label = observation.labels.first?.identifier,
                  let item = mockDatabase[label] else { continue }
            
            // 1. Convert 2D to 3D (simplified for this logic)
            // In a real app, use the SpatialProjectionEngine from Exercise 3
            let centerPoint = CGPoint(x: observation.boundingBox.midX, y: 1.0 - observation.boundingBox.midY)
            let raycastQuery = arView.raycastQuery(from: centerPoint, allowing: .estimatedPlane, alignment: .any)
            
            guard let query = raycastQuery,
                  let result = arView.session.raycast(query).first else { continue }
            
            let detectedPosition = result.worldTransform.translation // Helper extension
            
            // 2. Spatial Tracking Logic (Identity Persistence)
            if let existing = trackedItems[label], 
               distance(existing.position, detectedPosition) < proximityThreshold {
                // Update existing item position
                existing.entity.position = detectedPosition
                trackedItems[label] = (existing.entity, detectedPosition)
                newEntities.append(existing.entity)
            } else {
                // 3. Create New Spatially Persistent Entity
                let ringEntity = createStatusRing(for: item)
                let anchor = AnchorEntity(world: result.worldTransform)
                anchor.addChild(ringEntity)
                arView.scene.addAnchor(anchor)
                
                trackedItems[label] = (ringEntity, detectedPosition)
                newEntities.append(anchor)
            }
        }
        return newEntities
    }
    
    private func createStatusRing(for item: PantryItem) -> Entity {
        let color: UIColor
        let daysUntilExpiry = Calendar.current.dateComponents([.day], from: Date(), to: item.expirationDate).day ?? 0
        
        if daysUntilExpiry < 0 {
            color = .red
        } else if daysUntilExpiry <= 3 {
            color = .yellow
        } else {
            color = .green
        }
        
        let mesh = MeshResource.generateTorus(ringRadius: 0.05, thickness: 0.005)
        let material = UnlitMaterial(color: color)
        return ModelEntity(mesh: mesh, materials: [material])
    }
}

// Helper for SIMD translation extraction
extension simd_float4x4 {
    var translation: SIMD3<Float> {
        return [columns.3.x, columns.3.y, columns.3.z]
    }
}

func distance(_ a: SIMD3<Float>, _ b: SIMD3<Float>) -> Float {
    return simd_distance(a, b)
}
