
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// MARK: - Create ML Model Generation (Run this in an Xcode Playground)
import CreateML
import Foundation

// 1. Prepare your dataset (example CSV content)
let csvString = """
text,sentiment
"This product is amazing, highly recommend!",positive
"The battery life is terrible, very disappointed.",negative
"It's okay, nothing special.",neutral
"Absolutely love this, best purchase ever!",positive
"Worst experience, completely broken.",negative
"Decent quality for the price.",neutral
"Fast shipping and great customer service.",positive
"Too expensive for what it offers.",negative
"Could be better, but not bad.",neutral
"Fantastic camera, stunning photos!",positive
"Laggy performance, frustrating to use.",negative
"Just average, no strong feelings.",neutral
"A must-have gadget!",positive
"Completely useless, waste of money.",negative
"Works as advertised.",neutral
"So happy with this!",positive
"Regret buying it.",negative
"It does the job.",neutral
"Highly effective and reliable.",positive
"Constantly crashes, very unstable.",negative
"Neither good nor bad.",neutral
"Exceeded my expectations!",positive
"Don't bother, save your money.",negative
"Fairly standard.",neutral
"Brilliant design and functionality.",positive
"Poor quality materials.",negative
"Acceptable for light use.",neutral
"Thrilled with the results.",positive
"Glitches everywhere.",negative
"Satisfied, but not amazed.",neutral
"Perfect for my needs!",positive
"Awful customer support.",negative
"Could use some improvements.",neutral
"Definitely worth the investment.",positive
"Breaks easily.",negative
"It's fine.",neutral
"""

// Save to a temporary file to load into MLDataTable
let tempCSVURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("sentiment_data.csv")
try! csvString.write(to: tempCSVURL, atomically: true, encoding: .utf8)

// Convert to MLDataTable
let dataTable = try! MLDataTable(contentsOf: tempCSVURL)

// Split into training and testing data
let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 42)

// 2. Train the text classifier
let classifier = try! MLTextClassifier(trainingData: trainingData,
                                       textColumn: "text",
                                       labelColumn: "sentiment")

// 3. Evaluate the model (optional)
let evaluationMetrics = classifier.evaluation(on: testingData, textColumn: "text", labelColumn: "sentiment")
print("Validation Accuracy: \(evaluationMetrics.accuracy)")

// 4. Save the model
let modelURL = URL(fileURLWithPath: "/tmp/SentimentClassifier.mlmodel") // Change path as needed
try! classifier.write(to: modelURL)
print("Model saved to: \(modelURL.path)")

// Drag the generated SentimentClassifier.mlmodel from /tmp/ to your Xcode project.
