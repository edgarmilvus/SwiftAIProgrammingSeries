
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// This is a placeholder for a macOS command-line tool or a server-side Swift application.
// It demonstrates how a CI/CD pipeline step written in Swift could programmatically
// retrain and export a Core ML model using Create ML.

import CreateML
import Foundation

// MARK: - Model Configuration
/// Configuration struct for the image classifier model.
/// Encapsulates all necessary metadata and file paths for the training process.
struct ModelConfiguration {
    let modelName: String
    let author: String
    let license: String
    let description: String
    let version: String
    let outputDirectory: URL
    let trainingDataURL: URL
    let testingDataURL: URL
}

// MARK: - Main Retraining Logic
/// Performs the end-to-end model retraining pipeline:
/// 1. Validates data paths.
/// 2. Loads training data.
/// 3. Trains an MLImageClassifier.
/// 4. Evaluates the trained model.
/// 5. Exports the model to a .mlmodel file with metadata.
/// - Parameter config: The configuration details for the model and data.
/// - Throws: An error if any step in the pipeline fails (e.g., data not found, training error).
@available(macOS 14.0, *) // Create ML training is a macOS-only feature.
func retrainImageClassifier(with config: ModelConfiguration) async throws {
    print("🚀 Starting model retraining pipeline for '\(config.modelName)'...")

    // 1. Validate Data Paths and Prepare Output Directory
    // In a real CI/CD pipeline, data would be pulled from a source (e.g., S3, data lake)
    // and placed into these directories by a preceding pipeline step.
    guard FileManager.default.fileExists(atPath: config.trainingDataURL.path) else {
        throw NSError(domain: "RetrainingService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Training data directory not found at \(config.trainingDataURL.path)"])
    }
    guard FileManager.default.fileExists(atPath: config.testingDataURL.path) else {
        throw NSError(domain: "RetrainingService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Testing data directory not found at \(config.testingDataURL.path)"])
    }
    
    // Ensure the output directory for the model exists.
    try FileManager.default.createDirectory(at: config.outputDirectory, withIntermediateDirectories: true, attributes: nil)

    print("✅ Data paths validated and output directory prepared.")

    // 2. Load Training Data
    // Create ML expects image data organized into subdirectories, where each subdirectory
    // name represents a class label. E.g., `trainingDataURL/cat/cat1.jpg`, `trainingDataURL/dog/dog1.jpg`.
    print("📊 Loading training images from \(config.trainingDataURL.lastPathComponent)...")
    let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: config.trainingDataURL)
    print("✅ Loaded \(trainingData.count) training images.")

    // 3. Train the Image Classifier Model
    // This is the core of the Create ML programmatic API.
    // The training process can be computationally intensive and may take time
    // depending on the dataset size and complexity.
    print("⚙️ Training the image classifier...")
    let classifier = try MLImageClassifier(trainingData: trainingData)
    print("✅ Model training complete.")

    // 4. Evaluate the Model (Optional but Highly Recommended)
    // Evaluation helps assess the quality of the newly trained model against unseen data.
    // This step is critical for deciding whether the model is fit for deployment.
    print("🔬 Evaluating the model performance using testing data...")
    let testingData = try MLImageClassifier.DataSource.labeledDirectories(at: config.testingDataURL)
    let evaluation = classifier.evaluation(on: testingData)
    
    print("\n📊 Model Evaluation Results:")
    print("  Validation Accuracy: \(String(format: "%.2f%%", evaluation.accuracy * 100))")
    print("  Validation Precision: \(String(format: "%.2f", evaluation.precision))")
    print("  Validation Recall: \(String(format: "%.2f", evaluation.recall))")
    print("  Validation F1-Score: \(String(format: "%.2f", evaluation.fMeasure))")
    print("  Confusion Matrix: \n\(evaluation.confusionMatrix)")

    // In a real CI/CD pipeline, you would have acceptance criteria here.
    // If the model doesn't meet minimum accuracy/performance, the pipeline should fail.
    if evaluation.accuracy < 0.70 { // Example threshold
        print("⚠️ Warning: Model accuracy is below 70%. Consider retraining with more data or different parameters.")
        // throw NSError(domain: "RetrainingService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Model failed accuracy threshold."])
    }

    // 5. Export the Trained Model
    // The trained model is saved as a .mlmodel file, which is the standard Core ML format.
    // Metadata is crucial for understanding the model's origin and purpose later.
    let modelMetadata = MLModelMetadata(
        author: config.author,
        license: config.license,
        shortDescription: config.description,
        version: config.version,
        additional: nil // Can include custom key-value pairs
    )
    
    let modelURL = config.outputDirectory.appendingPathComponent("\(config.modelName).mlmodel")
    try classifier.write(to: modelURL, metadata: modelMetadata)
    print("📦 Successfully exported new model to: \(modelURL.path)")

    print("🎉 Model retraining pipeline finished successfully!")
}

// MARK: - Example Usage (Simulating a CI/CD Trigger)
// This `main` block would typically be executed by a CI/CD runner.
@main
@available(macOS 14.0, *)
struct RetrainingServiceApp {
    static func main() async {
        // --- IMPORTANT: Setup your data directories here for a real scenario ---
        // For demonstration, we'll generate dummy data. In a real CI/CD,
        // these paths would point to your actual training and testing datasets,
        // which might be fetched from a data lake or a version control system
        // by an earlier step in the CI/CD pipeline.

        let baseDir = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
            .appendingPathComponent("RetrainingServiceData")
        let trainingDataPath = baseDir.appendingPathComponent("training_data")
        let testingDataPath = baseDir.appendingPathComponent("testing_data")
        let outputModelsPath = baseDir.appendingPathComponent("output_models")

        do {
            // Generate dummy data structure with minimal valid images.
            // Replace this with your actual data ingestion for real training.
            try setupDummyData(trainingDir: trainingDataPath, testingDir: testingDataPath)

            let modelConfig = ModelConfiguration(
                modelName: "PetClassifier",
                author: "AI Team",
                license: "MIT",
                description: "A classifier for common pets (cats and dogs).",
                version: "1.0.\(Int(Date().timeIntervalSince1970))", // Dynamic versioning
                outputDirectory: outputModelsPath,
                trainingDataURL: trainingDataPath,
                testingDataURL: testingDataPath
            )

            try await retrainImageClassifier(with: modelConfig)
            
            print("\n--- Next Steps in a Real CI/CD Pipeline ---")
            print("The generated `PetClassifier.mlmodel` at \(outputModelsPath.path) would now be:")
            print("1.  **Model Versioning:** Stored in a model registry, Git LFS, or cloud storage (e.g., S3, Azure Blob Storage).")
            print("2.  **Integration Testing:** Tested with a dummy client application to ensure compatibility and correct behavior.")
            print("3.  **Deployment:** Uploaded to a CDN, bundled into a new app release, or served via a backend API.")
            print("4.  **Monitoring:** Performance of the deployed model is continuously monitored in production.")

        } catch {
            print("❌ Model retraining pipeline failed with error: \(error.localizedDescription)")
            // In a real CI/CD, this would trigger an alert or mark the build as failed.
            exit(1) // Indicate script failure
        }
        exit(0) // Indicate script success
    }
}

// MARK: - Helper for Dummy Data Setup
/// Sets up dummy image data for demonstration purposes.
/// This function creates the expected directory structure and populates it with
/// minimal valid PNG images (1x1 pixels). This allows the Create ML training
/// process to run without crashing due to invalid image files, but the resulting
/// model will not be useful for real classification.
///
/// In a real CI/CD pipeline, this data would be provided by a data ingestion step,
/// typically fetching actual, diverse datasets.
///
/// - Parameters:
///   - trainingDir: The URL for the training data directory.
///   - testingDir: The URL for the testing data directory.
/// - Throws: An error if directory creation or file writing fails.
@available(macOS 14.0, *)
func setupDummyData(trainingDir: URL, testingDir: URL) throws {
    let fileManager = FileManager.default

    // Clear and create base directories
    if fileManager.fileExists(atPath: trainingDir.path) {
        try fileManager.removeItem(at: trainingDir)
    }
    if fileManager.fileExists(atPath: testingDir.path) {
        try fileManager.removeItem(at: testingDir)
    }
    
    try fileManager.createDirectory(at: trainingDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: testingDir, withIntermediateDirectories: true, attributes: nil)

    // Create subdirectories for classes (e.g., "cat", "dog")
    let trainingCatDir = trainingDir.appendingPathComponent("cat")
    let trainingDogDir = trainingDir.appendingPathComponent("dog")
    let testingCatDir = testingDir.appendingPathComponent("cat")
    let testingDogDir = testingDir.appendingPathComponent("dog")

    try fileManager.createDirectory(at: trainingCatDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: trainingDogDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: testingCatDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: testingDogDir, withIntermediateDirectories: true, attributes: nil)

    // Generate simple 1x1 pixel PNG images (base64 encoded)
    // These are valid image files that Create ML can load without error.
    // Red pixel for 'cat' class, Blue pixel for 'dog' class.
    let redPixelPNG: Data? = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEgAGlS6uYAAAAAElFTkSuQmCC")
    let bluePixelPNG: Data? = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAEggJ+wJp0EQAAAABJRU5ErkJggg==")

    guard let redPixelData = redPixelPNG, let bluePixelData = bluePixelPNG else {
        throw NSError(domain: "RetrainingService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Failed to decode base64 image data."])
    }

    let dummyImageCount = 2 // A very small number for quick demo. Real training needs hundreds/thousands.
    for i in 1...dummyImageCount {
        try redPixelData.write(to: trainingCatDir.appendingPathComponent("cat_\(i).png"))
        try bluePixelData.write(to: trainingDogDir.appendingPathComponent("dog_\(i).png"))
        try redPixelData.write(to: testingCatDir.appendingPathComponent("cat_test_\(i).png"))
        try bluePixelData.write(to: testingDogDir.appendingPathComponent("dog_test_\(i).png"))
    }
    print("Generated dummy data structure with minimal valid PNG images for training and testing.")
    print("NOTE: For actual model training, replace these dummy files with diverse, real images relevant to your task.")
}
