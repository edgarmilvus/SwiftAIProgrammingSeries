
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CloudKit
import CoreData

actor DeltaSyncEngine {
    private let database = CKContainer.default().privateCloudDatabase
    private let zoneID = CKRecordZone.ID(zoneName: "NotesZone", ownerName: CKCurrentUserDefaultName)
    private let tokenKey = "com.lumina.notes.serverChangeToken"
    
    /// The core sync loop
    func syncChanges() async throws {
        let lastToken = loadChangeToken()
        
        // 1. Configure the Fetch Operation
        let configurations = CKFetchRecordZoneChangesOperation.ZoneConfiguration(
            previousServerChangeToken: lastToken,
            resultsLimit: nil,
            desiredKeys: nil
        )
        
        // We wrap the callback-based API into a modern async flow
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let operation = CKFetchRecordZoneChangesOperation(
                recordZoneIDs: [zoneID],
                configurationsByRecordZoneID: [zoneID: configurations]
            )
            
            // Handle changes
            operation.recordWasChangedBlock = { record in
                Task {
                    await self.performAtomicTripleUpdate(for: record)
                }
            }
            
            // Handle Token Updates
            operation.recordZoneFetchCompletionBlock = { zoneID, token, _, _, error in
                if let error = error {
                    // Handle Token Invalidation (e.g., zone deleted)
                    if let ckError = error as? CKError, ckError.code == .changeTokenExpired {
                        print("Token expired. Full sync required.")
                        // In production, trigger a full wipe/resync
                    }
                }
                
                if let newToken = token {
                    self.saveChangeToken(newToken)
                }
            }
            
            operation.fetchRecordZoneChangesCompletionBlock = { error in
                if let error = error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            }
            
            database.add(operation)
        }
    }

    /// Requirement: Atomic Triple-Update
    private func performAtomicTripleUpdate(for record: CKRecord) async {
        // Layer 1: Parse CloudKit Record
        guard let text = record["content"] as? String,
              let noteID = record.recordID.recordName as String? else { return }
        
        do {
            // Layer 2: Update Core Data
            try await updateCoreData(id: noteID, content: text)
            
            // Layer 3: Update Vector Store
            try await updateVectorIndex(id: noteID, text: text)
            
            print("Successfully synced \(noteID)")
        } catch {
            print("Atomic update failed for \(noteID): \(error)")
            // Implementation would include a "Pending Indexing" flag here
        }
    }

    // MARK: - Helper Methods (Mocks)
    
    private func updateCoreData(id: String, content: String) async throws { /* Core Data Logic */ }
    private func updateVectorIndex(id: String, text: String) async throws { /* Vector Logic */ }
    
    private func loadChangeToken() -> CKServerChangeToken? {
        guard let data = UserDefaults.standard.data(forKey: tokenKey) else { return nil }
        return try? NSKeyedUnarchiver.unarchivedObject(ofClass: CKServerChangeToken.self, from: data)
    }
    
    private func saveChangeToken(_ token: CKServerChangeToken) {
        let data = try? NSKeyedArchiver.archivedData(withRootObject: token, requiringSecureCoding: true)
        UserDefaults.standard.set(data, forKey: tokenKey)
    }
}
