
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import ARKit
import RealityKit
import SwiftUI

@MainActor
class SpatialNoteManager: ObservableObject {
    let session = ARKitSession()
    let worldTracking = WorldTrackingProvider()

    func placeNote(at point: CGPoint, in content: RealityViewContent) async {
        // 1. Perform a Raycast specifically looking for vertical surfaces (walls)
        let results = await worldTracking.raycast(from: point, allowing: .estimatedPlane, alignment: .vertical)
        
        guard let hit = results.first else {
            print("No vertical surface detected.")
            return
        }

        // 2. Create an AnchorEntity at the hit transform
        // The hit.worldTransform contains the rotation required to face the wall's normal
        let anchor = AnchorEntity(world: hit.worldTransform)
        
        // 3. Create a SwiftUI-based View Attachment
        // This allows us to use standard SwiftUI Text/Layout for the "Post-it"
        let noteView = NoteView(text: "Check electrical outlet")
        
        // In visionOS, we use a ViewAttachment to bridge SwiftUI and RealityKit
        // Note: This requires the RealityView to be set up to handle attachments
        let attachmentEntity = Entity() 
        // (Implementation detail: In a real app, use RealityView's attachment API)
        
        // 4. Orientation Math: 
        // The raycast result's rotation matrix already aligns the Z-axis with the surface normal.
        // We may need to rotate the child entity 180 degrees if it's facing "into" the wall.
        let model = ModelEntity(mesh: .generatePlane(width: 0.2, depth: 0.2), 
                                materials: [SimpleMaterial(color: .yellow, isMetallic: false)])
        
        // Align the plane to be flush with the wall
        anchor.addChild(model)
        content.add(anchor)
    }
}

struct NoteView: View {
    let text: String
    var body: some View {
        Text(text)
            .padding()
            .background(.yellow)
            .cornerRadius(8)
            .shadow(radius: 2)
    }
}
