
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// MARK: - Data Models

/// Represents a document with an ID and text content.
struct Document: Identifiable, Hashable {
    let id: String
    let text: String
}

// MARK: - Simulated AI Summarizer

/// Simulates a long-running AI summarization process for a single document.
/// This function is cooperatively cancellable.
func summarizeDocument(documentId: String, text: String) async throws -> String {
    print("AI Summarizer: Starting summarization for document '\(documentId)'...")
    
    // Simulate varying summarization times
    let delay = Double.random(in: 3...6)
    for i in 1...Int(delay) {
        try await Task.sleep(for: .seconds(1)) // Simulate work
        try Task.checkCancellation() // Check for cancellation
        print("AI Summarizer: '\(documentId)' processing step \(i)/\(Int(delay))...")
    }
    
    try Task.checkCancellation() // Final check before returning
    
    let summary = "Summary of '\(documentId)': This document discusses \(text.prefix(50))..."
    print("AI Summarizer: Finished summarization for document '\(documentId)'.")
    return summary
}

// MARK: - Batch Processing Logic

/// Processes a batch of documents in parallel using TaskGroup.
/// If the parent Task running this function is cancelled, all individual summarization tasks
/// within the TaskGroup will also be cancelled.
func processBatchSummarization(documents: [Document]) async -> [String: String] {
    print("Batch Processor: Starting batch summarization for \(documents.count) documents.")
    var summaries: [String: String] = [:]
    
    await withTaskGroup(of: (String, String)?.self) { group in
        for document in documents {
            group.addTask {
                do {
                    let summary = try await summarizeDocument(documentId: document.id, text: document.text)
                    return (document.id, summary)
                } catch is CancellationError {
                    print("Batch Processor: Summarization for '\(document.id)' was cancelled.")
                    return nil
                } catch {
                    print("Batch Processor: Summarization for '\(document.id)' failed with error: \(error.localizedDescription)")
                    return nil
                }
            }
        }
        
        // Collect results as they complete
        for await result in group {
            if let (id, summary) = result {
                summaries[id] = summary
            }
        }
        
        // TaskGroup automatically cancels all child tasks if the parent Task (running this function) is cancelled.
        // No explicit group.cancelAll() is needed here for parent-driven cancellation.
    }
    
    print("Batch Processor: Batch summarization completed (or cancelled). Processed \(summaries.count) summaries.")
    return summaries
}

// MARK: - Task Management and UI Simulation

/// A class to manage the batch summarization task, simulating a UI controller.
class SummarizationManager {
    private var currentBatchTask: Task<[String: String], Never>?
    
    func startBatchSummarization(documents: [Document]) {
        // If a previous task is running, cancel it before starting a new one
        if let existingTask = currentBatchTask {
            print("UI: Cancelling previous batch summarization task before starting new one.")
            existingTask.cancel()
        }
        
        print("UI: 'Start Batch Summarization' tapped. Initiating new batch task...")
        currentBatchTask = Task {
            let processedSummaries = await processBatchSummarization(documents: documents)
            if Task.isCancelled {
                print("UI: 🛑 Batch summarization was cancelled by user (top-level task check).")
            } else {
                print("UI: ✅ Batch summarization successful! Total summaries: \(processedSummaries.count)")
                processedSummaries.forEach { id, summary in
                    print("  - \(id): \(summary.prefix(70))...")
                }
            }
            self.currentBatchTask = nil
        }
    }
    
    func cancelAllSummarization() {
        guard let task = currentBatchTask else {
            print("UI: No active batch summarization task to cancel.")
            return
        }
        print("UI: 'Cancel All' tapped. Cancelling batch task...")
        task.cancel()
    }
    
    deinit {
        currentBatchTask?.cancel()
    }
}

// MARK: - Demonstration

func demonstrateParallelDocumentSummarization() async {
    let documents = [
        Document(id: "DocA", text: "The latest advancements in quantum computing show promising results for complex problem-solving."),
        Document(id: "DocB", text: "A detailed analysis of historical economic trends reveals patterns in market behavior."),
        Document(id: "DocC", text: "New research in neuroscience explores the mechanisms behind memory formation and recall."),
        Document(id: "DocD", text: "The impact of climate change on global ecosystems requires urgent attention and policy changes.")
    ]
    
    let manager = SummarizationManager()
    
    print("--- Scenario 1: Successful Batch Summarization ---")
    manager.startBatchSummarization(documents: documents)
    await Task.sleep(for: .seconds(8)) // Wait for completion
    print("\n")
    
    print("--- Scenario 2: User Cancels Entire Batch Mid-Process ---")
    manager.startBatchSummarization(documents: documents)
    await Task.sleep(for: .seconds(2.5)) // Allow some work to happen
    manager.cancelAllSummarization()
    await Task.sleep(for: .seconds(1)) // Give time for cancellation to propagate
    print("\n")
    
    print("--- Scenario 3: Cancel when no task is active ---")
    manager.cancelAllSummarization()
    print("\n")
    
    print("--- Scenario 4: Starting a new batch cancels the old one ---")
    manager.startBatchSummarization(documents: documents)
    await Task.sleep(for: .seconds(1.5))
    manager.startBatchSummarization(documents: documents) // This should cancel the first batch and start a new one
    await Task.sleep(for: .seconds(8)) // Wait for the second batch to complete
    print("\n")
}

// Run the demonstration
await demonstrateParallelDocumentSummarization()
