
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AVFoundation
import Vision

class RealtimeClassificationViewController: UIViewController {

    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private let classificationLabel = UILabel()

    private let videoDataOutputQueue = DispatchQueue(label: "videoDataOutputQueue", qos: .userInitiated)
    private var lastClassificationTime: CMTime = .zero
    private let classificationInterval: TimeInterval = 0.5 // Process frame every 0.5 seconds

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupCamera()
        setupClassificationLabel()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if captureSession?.isRunning == false {
            videoDataOutputQueue.async {
                self.captureSession?.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession?.isRunning == true {
            captureSession?.stopRunning()
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720 // Medium resolution for performance

        // Request camera authorization
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard let self = self else { return }
            if granted {
                self.configureCameraSession()
            } else {
                DispatchQueue.main.async {
                    self.showCameraAccessDeniedAlert()
                }
            }
        }
    }

    private func configureCameraSession() {
        guard let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            DispatchQueue.main.async {
                self.showErrorAlert(message: "Failed to get capture device.")
            }
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: captureDevice)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            }

            let output = AVCaptureVideoDataOutput()
            output.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
            // Specify the pixel format for Vision (e.g., BGRA)
            output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

            if captureSession.canAddOutput(output) {
                captureSession.addOutput(output)
            }

            // Set up video orientation for output
            if let connection = output.connection(with: .video), connection.isPortraitSupported {
                connection.videoOrientation = .portrait
            }

            DispatchQueue.main.async {
                self.previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
                self.previewLayer.videoGravity = .resizeAspectFill
                self.previewLayer.frame = self.view.bounds
                self.view.layer.addSublayer(self.previewLayer)
                self.view.bringSubviewToFront(self.classificationLabel) // Ensure label is on top
            }

            videoDataOutputQueue.async {
                self.captureSession.startRunning()
            }

        } catch {
            DispatchQueue.main.async {
                self.showErrorAlert(message: "Error setting up camera input: \(error.localizedDescription)")
            }
        }
    }

    private func setupClassificationLabel() {
        classificationLabel.text = "Initializing Camera..."
        classificationLabel.textColor = .white
        classificationLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        classificationLabel.textAlignment = .center
        classificationLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        classificationLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(classificationLabel)

        NSLayoutConstraint.activate([
            classificationLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            classificationLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            classificationLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            classificationLabel.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func showCameraAccessDeniedAlert() {
        let alert = UIAlertController(title: "Camera Access Denied",
                                      message: "Please enable camera access in Settings to use this feature.",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
extension RealtimeClassificationViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Throttling mechanism
        let currentTime = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        let elapsedTime = CMTimeGetSeconds(currentTime - lastClassificationTime)

        guard elapsedTime > classificationInterval else { return }
        lastClassificationTime = currentTime

        // Convert CMSampleBuffer to CVPixelBuffer
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Create a Vision request handler for the CVPixelBuffer
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        // Create a classification request
        let request = VNClassifyImageRequest { [weak self] request, error in
            guard let self = self else { return }

            DispatchQueue.main.async {
                if let error = error {
                    self.classificationLabel.text = "Vision Error: \(error.localizedDescription)"
                    print("Vision request failed with error: \(error)")
                    return
                }

                guard let observations = request.results as? [VNClassificationObservation],
                      let topObservation = observations.first else {
                    self.classificationLabel.text = "No classification"
                    return
                }

                let confidencePercentage = String(format: "%.1f%%", topObservation.confidence * 100)
                // Only display if confidence is reasonably high
                if topObservation.confidence > 0.5 {
                    self.classificationLabel.text = "\(topObservation.identifier) (\(confidencePercentage))"
                } else {
                    self.classificationLabel.text = "Looking..."
                }
            }
        }

        // Perform the Vision request on the same background queue
        // (or a dedicated Vision queue if processing is very heavy)
        do {
            try handler.perform([request])
        } catch {
            print("Failed to perform Vision request: \(error)")
            DispatchQueue.main.async {
                self.classificationLabel.text = "Vision Error!"
            }
        }
    }
}
