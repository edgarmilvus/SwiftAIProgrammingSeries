
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
class CalendarAgent {
    private let client: ClaudeNetworkingActor
    private let maxTurns = 3

    init(client: ClaudeNetworkingActor) {
        self.client = client
    }

    // The local function the LLM "triggers"
    func createCalendarEvent(title: String, dateTime: String) -> String {
        // In a real app, this would parse the string into a Date and use EventKit
        print("LOG: Executing local tool: Creating event '\(title)' at \(dateTime)")
        return "Successfully created event: \(title) at \(dateTime)"
    }

    // Tool Definition in JSON Schema format
    private var toolDefinitions: [[String: Any]] {
        [
            [
                "name": "create_calendar_event",
                "description": "Schedules a new calendar event.",
                "input_schema": [
                    "type": "object",
                    "properties": [
                        "title": ["type": "string", "description": "The title of the event"],
                        "dateTime": ["type": "string", "description": "The date and time (ISO 8601 format)"]
                    ],
                    "required": ["title", "dateTime"]
                ]
            ]
        ]
    }

    func processNaturalLanguageCommand(_ command: String) async throws -> String {
        var conversationHistory: [Message] = [
            Message(role: "user", content: [ContentBlock(type: "text", text: command)])
        ]
        
        // We need a way to send tools in the request. 
        // (Note: For this exercise, assume ClaudeNetworkingActor is extended to support tool definitions)
        
        for _ in 0..<maxTurns {
            // 1. Send current history to Claude
            // In a real implementation, 'AnthropicRequest' would include 'tools'
            let response = try await client.generateLyrics(prompt: command, mood: "neutral", genre: "none") 
            // ^ NOTE: In a real world scenario, we would use a specialized 'tool-capable' method.
            // For the sake of this exercise logic, let's simulate the Tool Use detection.
            
            // SIMULATION: Let's assume the LLM returned a tool call instead of text
            // In a real API, this is parsed from the 'content' array where type == 'tool_use'
            let simulatedToolCall = try simulateToolDetection(for: command)
            
            if let toolCall = simulatedToolCall {
                // 2. Extract arguments and execute local function
                let title = toolCall.arguments["title"] as? String ?? "Unknown"
                let date = toolCall.arguments["dateTime"] as? String ?? "Unknown"
                
                let result = createCalendarEvent(title: title, dateTime: date)
                
                // 3. Feed the result back to the conversation
                let toolResultMessage = Message(
                    role: "user", 
                    content: [ContentBlock(type: "tool_result", text: result)]
                )
                conversationHistory.append(toolResultMessage)
                
                // 4. Final attempt to get a natural language response
                // (In a real loop, we'd call the API again with the updated history)
                return "Agent: I've processed your request. \(result)"
            } else {
                return response // No tool call, just return the text
            }
        }
        
        throw NSError(domain: "AgentError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Max turns exceeded"])
    }

    // Helper to simulate the complex parsing of a tool_use block
    private func simulateToolDetection(for command: String) throws -> SimulatedToolCall? {
        if command.contains("Schedule") {
            return SimulatedToolCall(name: "create_calendar_event", arguments: ["title": "Meeting", "dateTime": "2025-05-01T15:00:00Z"])
        }
        return nil
    }
}

struct SimulatedToolCall {
    let name: String
    let arguments: [String: String]
}
