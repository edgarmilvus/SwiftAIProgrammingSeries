
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage // Required for NLEmbedding
import SwiftUI // For the example usage in a mock SwiftUI context

@available(iOS 18.0, macOS 15.0, *) // Targeting Swift 6 context with latest OS availability
struct WordSimilarityChecker {

    /// Calculates the semantic similarity between two words using NLEmbedding.
    /// - Parameters:
    ///   - word1: The first word for comparison.
    ///   - word2: The second word for comparison.
    ///   - language: The natural language to use for the embedding model (e.g., .english).
    /// - Returns: A Double representing the similarity score (0.0 to 1.0), or nil if the embedding model is unavailable.
    func calculateSimilarity(word1: String, word2: String, language: NLLanguage) -> Double? {
        // Attempt to get the word embedding model for the specified language.
        // This might return nil if the model is not available on the device or for the language.
        guard let embedding = NLEmbedding.wordEmbedding(for: language) else {
            print("NLEmbedding word model not available for \(language.rawValue)")
            return nil
        }

        // Calculate the similarity score between the two words.
        // The similarity method returns a Double between 0.0 (least similar) and 1.0 (most similar).
        let score = embedding.similarity(for: word1, to: word2)
        return score
    }
}

// MARK: - Example Usage (Illustrative SwiftUI View)
@available(iOS 18.0, macOS 15.0, *)
struct WordSimilarityView: View {
    @State private var word1: String = "cat"
    @State private var word2: String = "kitten"
    @State private var similarityScore: Double?
    @State private var errorMessage: String?

    private let checker = WordSimilarityChecker()

    var body: some View {
        VStack(spacing: 20) {
            Text("Word Similarity Checker")
                .font(.largeTitle)

            HStack {
                TextField("Enter Word 1", text: $word1)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)

                TextField("Enter Word 2", text: $word2)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            }
            .padding(.horizontal)

            Button("Calculate Similarity") {
                errorMessage = nil
                similarityScore = nil
                if word1.isEmpty || word2.isEmpty {
                    errorMessage = "Please enter both words."
                    return
                }
                // Using .english as the language for this example
                if let score = checker.calculateSimilarity(word1: word1, word2: word2, language: .english) {
                    similarityScore = score
                } else {
                    errorMessage = "Could not calculate similarity. Embedding model might be unavailable."
                }
            }
            .buttonStyle(.borderedProminent)

            if let score = similarityScore {
                Text("Similarity: \(score, specifier: "%.4f")")
                    .font(.title2)
                    .foregroundColor(.green)
            }

            if let error = errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }

            Spacer()
        }
        .padding()
        .onAppear {
            // Pre-calculate on appear for initial display
            if let score = checker.calculateSimilarity(word1: word1, word2: word2, language: .english) {
                similarityScore = score
            }
        }
    }
}

// To run this in a preview or an app:
// @available(iOS 18.0, macOS 15.0, *)
// #Preview {
//     WordSimilarityView()
// }
