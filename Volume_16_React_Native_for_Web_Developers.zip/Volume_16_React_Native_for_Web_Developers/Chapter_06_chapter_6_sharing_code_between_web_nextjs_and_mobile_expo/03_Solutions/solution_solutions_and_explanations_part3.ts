/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// packages/ui/Button/Button.types.ts
export interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary';
}

// packages/ui/Button/variantStyles.ts
export const getVariantClasses = (variant: string = 'primary') => {
  if (variant === 'secondary') {
    return 'bg-gray-500 text-white';
  }
  return 'bg-blue-500 text-white';
};

// packages/ui/Button/Button.native.tsx
import React from 'react';
import { Pressable, Text } from 'react-native';
import { ButtonProps } from './Button.types';
import { getVariantClasses } from './variantStyles';

export const Button = ({ title, onPress, variant }: ButtonProps) => {
  // In a real app, NativeWind would process these strings via babel
  // For this example, we map classes to RN styles manually or assume a mapping layer
  const styleClasses = getVariantClasses(variant);
  
  return (
    <Pressable 
      onPress={onPress} 
      style={{ 
        backgroundColor: styleClasses.includes('bg-blue') ? '#2563eb' : '#4b5563', 
        padding: 16, 
        borderRadius: 8 
      }}
    >
      <Text style={{ color: 'white', textAlign: 'center' }}>{title}</Text>
    </Pressable>
  );
};

// packages/ui/Button/Button.web.tsx
import React from 'react';
import { ButtonProps } from './Button.types';
import { getVariantClasses } from './variantStyles';

export const Button = ({ title, onPress, variant }: ButtonProps) => {
  const className = `px-4 py-2 rounded-lg ${getVariantClasses(variant)}`;
  
  return (
    <button className={className} onClick={onPress}>
      {title}
    </button>
  );
};

// packages/ui/Button/index.ts
// This file ensures the bundler picks the correct implementation
export { Button } from './Button';
// Note: Metro (Expo) and Next.js automatically resolve .native.tsx and .web.tsx 
// when importing from './Button' if the index file re-exports from the platform-specific file.
// However, explicit exports are safer:
// export * from './Button.native'; // Metro specific
// export * from './Button.web';    // Web specific
// Usually, the bundler handles the entry point. 
// A common pattern is simply:
// export { Button } from './Button';

// Usage in Next.js (pages/index.tsx)
import { Button } from '@repo/ui';

export default function Home() {
  return <Button title="Click Me" variant="secondary" onPress={() => alert('Web')} />;
}

// Usage in Expo (app/index.tsx)
import { Button } from '@repo/ui';

export default function MobileHome() {
  return <Button title="Tap Me" variant="primary" onPress={() => alert('Mobile')} />;
}
