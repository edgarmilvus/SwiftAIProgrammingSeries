
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Foundation // In a real iOS 18 project, you would import Foundation.AI

// MARK: - Mock for Foundation.AI.TextGenerator (for demonstration without iOS 18)
// In a real iOS 18 project, you would import Foundation.AI and use its types directly.
@available(iOS 18.0, *)
enum AIServiceError: Error, LocalizedError {
    case generationFailed(String)
    case notAvailable
    
    var errorDescription: String? {
        switch self {
        case .generationFailed(let message): return "AI Generation Failed: \(message)"
        case .notAvailable: return "AI Service Not Available"
        }
    }
}

@available(iOS 18.0, *)
class MockAITextGenerator {
    // Simplified options for demonstration
    struct TextGenerationOptions {
        var numberOfCompletions: Int = 1
        var temperature: Double = 0.7
    }

    struct TextGenerationResult {
        let text: String
        let completions: [TextGenerationCompletion]

        init(text: String, completions: [TextGenerationCompletion]) {
            self.text = text
            self.completions = completions
        }
    }

    struct TextGenerationCompletion {
        let text: String
        let finishReason: String

        init(text: String, finishReason: String = "stop") {
            self.text = text
            self.finishReason = finishReason
        }
    }

    static func generate(_ input: String, options: TextGenerationOptions? = nil) async throws -> TextGenerationResult {
        // Simulate network delay or processing time
        try await Task.sleep(for: .seconds(1))

        // Simulate different AI behaviors based on input or options
        let lowercasedInput = input.lowercased()
        var generatedText = "Generated text for: \"\(input)\""
        var completions: [TextGenerationCompletion] = []

        if lowercasedInput.contains("summarize") {
            generatedText = "Summary: This is a concise version of the provided text. It captures the main points efficiently."
        } else if lowercasedInput.contains("rephrase") {
            generatedText = "Rephrased: A different way of articulating the same message, perhaps with improved clarity or style."
        } else if lowercasedInput.contains("formal tone") {
            generatedText = "Formal: It is with great solemnity that we present this formal rendition of the text."
        } else if lowercasedInput.contains("casual and friendly tone") {
            generatedText = "Casual: Hey there! Just wanted to say this in a super chill way."
        } else if lowercasedInput.contains("simplify") {
            generatedText = "Simplified: Here's the easy version: \(input)."
        } else if lowercasedInput.contains("elaborate") {
            generatedText = "Elaborated: Let's delve deeper into this concept. \(input) can be expanded upon significantly by considering various facets and implications."
        } else if lowercasedInput.contains("suggest") && lowercasedInput.contains("reply options") {
            completions = [
                TextGenerationCompletion(text: "Sounds good!"),
                TextGenerationCompletion(text: "Got it, thanks."),
                TextGenerationCompletion(text: "Okay, I'll do that.")
            ]
            generatedText = completions.first?.text ?? ""
        } else {
            generatedText = "AI generated content for: \(input)"
        }

        if let numCompletions = options?.numberOfCompletions, numCompletions > 1 {
            if completions.isEmpty {
                for i in 1...numCompletions {
                    completions.append(TextGenerationCompletion(text: "Suggestion \(i) for: \(input)"))
                }
            }
        } else {
            completions = [TextGenerationCompletion(text: generatedText)]
        }

        // Simulate a potential error
        if input.contains("fail") {
            throw AIServiceError.generationFailed("Simulated AI failure for input: \(input)")
        }

        return TextGenerationResult(text: generatedText, completions: completions)
    }
}

// Alias for convenience in the solutions, matching the real API structure
@available(iOS 18.0, *)
extension Foundation.AI { // Extend Foundation.AI (which would be the real framework)
    class TextGenerator {
        // Expose the mock generate method with the same signature
        static func generate(_ input: String, options: MockAITextGenerator.TextGenerationOptions? = nil) async throws -> MockAITextGenerator.TextGenerationResult {
            return try await MockAITextGenerator.generate(input, options: options)
        }
    }
    // Also provide the mock options struct directly as a typealias
    typealias TextGenerationOptions = MockAITextGenerator.TextGenerationOptions
    typealias TextGenerationResult = MockAITextGenerator.TextGenerationResult
}

// Ensure Foundation.AI is recognized, even if it's a mock.
// In a real iOS 18 app, you'd `import Foundation.AI`
// For this mock, we'll use a global alias if not already defined.
#if !canImport(Foundation.AI)
@available(iOS 18.0, *)
enum AI {} // A placeholder enum to allow `AI.TextGenerator` syntax
#endif


class SummarizeSelectionViewController: UIViewController, UITextViewDelegate {

    private lazy var textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        tv.text = "This is a sample paragraph for summarization. It contains several sentences that convey information about a topic. Users might want to quickly get the gist of such a paragraph without reading through all the details. The 'Summarize Selection' feature aims to provide this capability, making text analysis more efficient. You can select any part of this text to try it out. For example, select the first two sentences."
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Summarize Selection"
        view.backgroundColor = .systemBackground
        setupTextView()
    }

    private func setupTextView() {
        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 300)
        ])
        textView.delegate = self
    }

    // MARK: - UITextViewDelegate

    @available(iOS 16.0, *) // textInput(_:menuElementsFor:at:sender:) is available from iOS 16
    func textInput(_ textInput: UITextInput, menuElementsFor textRange: UITextRange, at point: CGPoint, sender: Any?) -> [UIMenuElement] {
        guard let textView = textInput as? UITextView else { return [] }

        // Get the currently selected text
        guard let selectedText = textView.text(in: textRange), !selectedText.isEmpty else {
            return [] // No text selected, return default menu elements
        }

        // Create the custom "Summarize Selection" action
        let summarizeAction = UIAction(title: "Summarize Selection", image: UIImage(systemName: "highlighter")) { [weak self] _ in
            self?.performSummarization(for: selectedText)
        }
        
        // Return a menu containing our custom action.
        // You could also combine it with default elements if needed.
        return [summarizeAction]
    }

    // MARK: - AI Integration

    private func performSummarization(for text: String) {
        // Feature availability check for iOS 18 (for real Foundation.AI)
        guard #available(iOS 18.0, *) else {
            self.showAlert(title: "Feature Unavailable", message: "This AI feature requires iOS 18 or later.")
            return
        }

        self.showLoadingAlert(message: "Summarizing...")

        Task { // Start an asynchronous task
            do {
                let prompt = "Summarize the following text concisely: '\(text)'"
                let result = try await AI.TextGenerator.generate(prompt) // Await the AI response
                
                DispatchQueue.main.async { // Ensure UI updates on the main thread
                    self.dismissLoadingAlert()
                    self.showAlert(title: "Summary", message: result.text)
                }
            } catch {
                DispatchQueue.main.async { // Handle errors on the main thread
                    self.dismissLoadingAlert()
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }

    // MARK: - UI Utility Functions

    private var loadingAlert: UIAlertController?

    private func showLoadingAlert(message: String) {
        loadingAlert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        loadingAlert?.view.addSubview(indicator)
        
        NSLayoutConstraint.activate([
            indicator.centerXAnchor.constraint(equalTo: loadingAlert!.view.centerXAnchor),
            indicator.centerYAnchor.constraint(equalTo: loadingAlert!.view.centerYAnchor, constant: 20)
        ])
        indicator.startAnimating()
        present(loadingAlert!, animated: true)
    }

    private func dismissLoadingAlert() {
        loadingAlert?.dismiss(animated: true)
        loadingAlert = nil
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
