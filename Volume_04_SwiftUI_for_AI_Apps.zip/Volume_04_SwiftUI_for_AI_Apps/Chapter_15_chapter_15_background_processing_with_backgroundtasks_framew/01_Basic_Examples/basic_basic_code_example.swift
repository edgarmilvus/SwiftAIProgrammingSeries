
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - 1. Necessary Imports

import SwiftUI
import BackgroundTasks
import Foundation

// MARK: - 2. Define Task Identifiers

// It's good practice to define task identifiers as constants.
// These must match the identifiers declared in your Info.plist.
enum BackgroundTaskIdentifier {
    static let appRefresh = "com.ai.smartnewsreader.refresh"
    static let appProcessing = "com.ai.smartnewsreader.process" // Example for a separate processing task
}

// MARK: - 3. App Delegate (or App Lifecycle for SwiftUI)

// In a SwiftUI app, you'd typically use an AppDelegateAdapter or directly
// handle lifecycle events in your App struct if available (iOS 14+).
// For simplicity and clarity in demonstrating BackgroundTasks registration,
// we'll assume an AppDelegate-like structure or an initializer in the App struct.

/// The main application structure.
@main
struct SmartNewsReaderApp: App {
    // This initializer is called when the app launches.
    // It's a suitable place to register background tasks.
    init() {
        // Register all background tasks that your app supports.
        // This must happen early in the app's lifecycle.
        BGTaskScheduler.shared.register(forTaskWithIdentifier: BackgroundTaskIdentifier.appRefresh, using: nil) { task in
            // When the system launches our app for this task, this closure is executed.
            // We cast the generic BGTask to BGAppRefreshTask.
            guard let refreshTask = task as? BGAppRefreshTask else {
                print("Error: Task is not a BGAppRefreshTask.")
                task.setTaskCompleted(success: false)
                return
            }
            print("Background refresh task \(refreshTask.identifier) received!")
            // Perform the actual work.
            handleAppRefreshTask(task: refreshTask)
        }

        // You can register multiple types of tasks.
        BGTaskScheduler.shared.register(forTaskWithIdentifier: BackgroundTaskIdentifier.appProcessing, using: nil) { task in
            guard let processingTask = task as? BGProcessingTask else {
                print("Error: Task is not a BGProcessingTask.")
                task.setTaskCompleted(success: false)
                return
            }
            print("Background processing task \(processingTask.identifier) received!")
            // Perform the actual work.
            handleAppProcessingTask(task: processingTask)
        }

        print("Registered background tasks.")
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }

    // MARK: - 4. Task Handlers

    /// Handles the background app refresh task.
    /// This function simulates fetching new articles and performing a lightweight AI pre-processing.
    /// - Parameter task: The `BGAppRefreshTask` provided by the system.
    private func handleAppRefreshTask(task: BGAppRefreshTask) {
        // Schedule the next refresh task immediately, so the system has a chance to schedule it again.
        // This is crucial for continuous background activity.
        scheduleAppRefresh()

        // Define an expiration handler. This is called if the system decides to terminate
        // the task early (e.g., due to low battery, memory pressure, or time limit).
        task.expirationHandler = {
            // Clean up any ongoing work, stop network requests, save partial results.
            print("Background refresh task \(task.identifier) expired! Cleaning up...")
            // Mark the task as incomplete.
            task.setTaskCompleted(success: false)
        }

        // Simulate asynchronous work: fetching news articles and AI pre-processing.
        Task {
            print("Starting background refresh work for \(task.identifier)...")
            do {
                // Simulate network request for new articles
                try await Task.sleep(for: .seconds(2)) // Simulate network latency
                print("Fetched new articles.")

                // Simulate lightweight AI pre-processing (e.g., generate embeddings, extract keywords)
                try await Task.sleep(for: .seconds(3)) // Simulate AI model inference
                print("Completed AI pre-processing for new articles.")

                // If all work completed successfully, mark the task as complete.
                task.setTaskCompleted(success: true)
                print("Background refresh task \(task.identifier) completed successfully!")

                // MARK: Common Pitfall: UI Updates from Background
                // If this background task completion needs to update the UI,
                // ensure it's done on the main actor.
                // For a background task, this is usually not directly updating the UI,
                // but rather updating a data model that the UI observes.
                // Example (if needed, though not directly in this basic example's scope):
                // await MainActor.run {
                //     // Update a @State or @ObservableObject property that the UI observes
                // }

            } catch {
                print("Background refresh task \(task.identifier) failed with error: \(error.localizedDescription)")
                // If any error occurs, mark the task as incomplete.
                task.setTaskCompleted(success: false)
            }
        }
    }

    /// Handles a background processing task.
    /// This function simulates more intensive AI model inference or data synchronization.
    /// - Parameter task: The `BGProcessingTask` provided by the system.
    private func handleAppProcessingTask(task: BGProcessingTask) {
        // Schedule the next processing task.
        scheduleAppProcessing()

        task.expirationHandler = {
            print("Background processing task \(task.identifier) expired! Cleaning up...")
            task.setTaskCompleted(success: false)
        }

        Task {
            print("Starting background processing work for \(task.identifier)...")
            do {
                // Simulate downloading a new AI model or performing heavy inference.
                try await Task.sleep(for: .seconds(5))
                print("Downloaded updated AI model.")

                // Simulate performing a more intensive AI task, perhaps on a dedicated compute unit.
                // In a real AI app, this might involve MLModel's `prediction` or `predictions` methods
                // with specific `MLComputeUnits`.
                try await Task.sleep(for: .seconds(10))
                print("Performed intensive AI analysis.")

                task.setTaskCompleted(success: true)
                print("Background processing task \(task.identifier) completed successfully!")
            } catch {
                print("Background processing task \(task.identifier) failed with error: \(error.localizedDescription)")
                task.setTaskCompleted(success: false)
            }
        }
    }
}

// MARK: - 5. Scheduling Tasks

/// Schedules a background app refresh task.
/// This should be called whenever you want to request the system to perform a refresh.
/// For example, after the app launches, after a foreground session, or after a previous task completes.
func scheduleAppRefresh() {
    let request = BGAppRefreshTaskRequest(identifier: BackgroundTaskIdentifier.appRefresh)
    // Earliest time the task can run. The system will try to run it after this time.
    // Setting it to `nil` means the system can run it as soon as possible,
    // but it's often better to give it a sensible delay.
    request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60) // Try to run after 15 minutes

    do {
        try BGTaskScheduler.shared.submit(request)
        print("Scheduled background app refresh task: \(request.identifier)")
    } catch {
        print("Could not schedule app refresh task: \(error.localizedDescription)")
    }
}

/// Schedules a background processing task.
/// This type of task allows for more control over network and power requirements.
func scheduleAppProcessing() {
    let request = BGProcessingTaskRequest(identifier: BackgroundTaskIdentifier.appProcessing)
    request.requiresNetworkConnectivity = true // This task needs an internet connection.
    request.requiresExternalPower = false     // This task can run without external power.
    request.earliestBeginDate = Date(timeIntervalSinceNow: 30 * 60) // Try to run after 30 minutes

    do {
        try BGTaskScheduler.shared.submit(request)
        print("Scheduled background processing task: \(request.identifier)")
    } catch {
        print("Could not schedule app processing task: \(error.localizedDescription)")
    }
}

// MARK: - 6. SwiftUI View (for demonstration)

/// A simple SwiftUI view to trigger background tasks manually for testing.
struct ContentView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Smart News Reader")
                .font(.largeTitle)
                .padding()

            Button("Schedule App Refresh Task") {
                scheduleAppRefresh()
            }
            .buttonStyle(.borderedProminent)

            Button("Schedule App Processing Task") {
                scheduleAppProcessing()
            }
            .buttonStyle(.borderedProminent)

            Text("To test background tasks:")
                .font(.headline)
                .padding(.top)
            Text("1. Run the app on a device or simulator.")
            Text("2. Schedule a task using the buttons.")
            Text("3. Send the app to the background (Home button/swipe up).")
            Text("4. In Xcode, go to Debug > Simulate Background Tasks > [Your Task Identifier].")
            Text("5. Observe console output.")
        }
        .padding()
        .onAppear {
            // Optionally schedule a task when the app first appears,
            // or when it comes to the foreground after a period.
            // scheduleAppRefresh()
        }
    }
}

// MARK: - 7. Info.plist Configuration Reminder

/*
    IMPORTANT: You MUST declare your background task identifiers in your app's Info.plist.
    Add a new array key called `Permitted background task scheduler identifiers`
    (or `BGTaskSchedulerPermittedIdentifiers` in raw XML).
    Add each task identifier string as an item in this array.

    Example Info.plist (XML snippet):
    <key>BGTaskSchedulerPermittedIdentifiers</key>
    <array>
        <string>com.ai.smartnewsreader.refresh</string>
        <string>com.ai.smartnewsreader.process</string>
    </array>
*/
