
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import MLX
import MLXNN
import Foundation // For print statements and data generation

// Ensure the code runs on compatible Apple platforms
@available(iOS 17.0, macOS 14.0, *)
@main
struct SmartDocumentScanner {

    /// A simple linear classifier module for our document scanner.
    /// It takes a feature vector and outputs a single logit for binary classification.
    class SimpleDocumentClassifier: MLXNN.Module {
        let linear: MLXNN.Linear

        /// Initializes the classifier with input and output feature dimensions.
        /// - Parameters:
        ///   - inputFeatures: The number of features describing each document.
        ///   - outputFeatures: The number of output classes (1 for binary classification).
        init(inputFeatures: Int, outputFeatures: Int) {
            self.linear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
            super.init() // Call super.init() after all properties are initialized
        }

        /// Performs the forward pass of the model.
        /// - Parameter input: An MLXArray representing the input features (batch_size, inputFeatures).
        /// - Returns: An MLXArray representing the raw logits (batch_size, outputFeatures).
        override func callAsFunction(_ input: MLXArray) -> MLXArray {
            return linear(input)
        }
    }

    /// Calculates the binary cross-entropy loss between predictions and true labels.
    /// - Parameters:
    ///   - predictions: The raw logits from the model (batch_size, 1).
    ///   - targets: The true binary labels (batch_size, 1).
    /// - Returns: A scalar MLXArray representing the mean loss.
    static func binaryCrossEntropyLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        // Apply sigmoid to predictions to get probabilities
        let probabilities = sigmoid(predictions)
        // Clamp probabilities to avoid log(0) or log(1) issues
        let clampedProbabilities = clip(probabilities, min: 1e-7, max: 1 - 1e-7)

        // Calculate binary cross-entropy loss
        let loss = -(targets * log(clampedProbabilities) + (1 - targets) * log(1 - clampedProbabilities))
        return mean(loss)
    }

    static func main() async {
        print("🚀 Starting MLX Swift Document Classifier Example...")

        // MARK: - 1. Define Model Parameters and Hyperparameters

        let inputFeatures = 2      // e.g., "text_density" and "keyword_presence"
        let outputFeatures = 1     // Binary classification: Invoice (1) vs. Receipt (0)
        let learningRate: Float = 0.01
        let numEpochs = 100
        let batchSize = 32
        let numSamples = 1000

        // MARK: - 2. Generate Synthetic Data

        print("\nGenerating synthetic data...")
        // Features (X): Random values for our two features
        let X_data = MLXArray.randomUniform(low: 0, high: 1, shape: [numSamples, inputFeatures], dtype: .float32)

        // Labels (y): A simple linear relationship with some noise for classification
        // For simplicity, let's say if feature1 + feature2 > 1.0, it's an "Invoice" (1), else "Receipt" (0)
        let threshold: Float = 1.0
        let labels_float = X_data[0] + X_data[1] .greaterThan(threshold) .astype(.float32)
        let y_data = labels_float.reshaped([numSamples, 1])

        print("Generated \(numSamples) samples. X_data shape: \(X_data.shape), y_data shape: \(y_data.shape)")
        // print("Sample X_data (first 5):\n", X_data[0..<5]) // Uncomment to see data
        // print("Sample y_data (first 5):\n", y_data[0..<5]) // Uncomment to see data

        // MARK: - 3. Initialize Model and Optimizer

        print("\nInitializing model and optimizer...")
        let model = SimpleDocumentClassifier(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        let optimizer = MLXNN.Optimizers.SGD(learningRate: learningRate)

        // MARK: - 4. Define the Loss and Gradient Function

        /// This function wraps our loss calculation to be compatible with `valueAndGradient`.
        /// It takes the model's parameters and the input data, then computes the loss.
        /// `valueAndGradient` will then automatically compute gradients with respect to these parameters.
        let lossAndGradientFn = valueAndGradient(model.parameters()) { (model: SimpleDocumentClassifier, X: MLXArray, y: MLXArray) -> MLXArray in
            let predictions = model(X)
            let loss = binaryCrossEntropyLoss(predictions: predictions, targets: y)
            return loss
        }

        // MARK: - 5. Training Loop

        print("\nStarting training loop for \(numEpochs) epochs...")
        for epoch in 0..<numEpochs {
            var totalLoss: Float = 0.0
            var correctPredictions = 0
            let numBatches = (numSamples + batchSize - 1) / batchSize

            for i in 0..<numBatches {
                let start = i * batchSize
                let end = min((i + 1) * batchSize, numSamples)
                let currentBatchSize = end - start

                if currentBatchSize <= 0 { continue }

                // Slice data for the current batch
                let X_batch = X_data[start..<end]
                let y_batch = y_data[start..<end]

                // Use `lossAndGradientFn` to get both the loss and its gradients
                // MLX is lazy, so `lossAndGradientFn` builds the graph but doesn't execute yet.
                let (loss, grads) = lossAndGradientFn(model, X_batch, y_batch)

                // The `eval()` call triggers the computation of the loss and gradients.
                // This is where the lazy graph is executed on the GPU/CPU.
                let lossValue = loss.eval().item(Float.self)
                totalLoss += lossValue

                // Update model parameters using the optimizer and computed gradients
                optimizer.update(model: model, gradients: grads)
                optimizer.step(model) // Applies the updates to the model's parameters

                // Calculate accuracy for the current batch (for monitoring)
                let predictions = model(X_batch) // Forward pass again for current predictions
                let predictedClasses = sigmoid(predictions) .greaterThan(0.5) .astype(.float32)
                let batchCorrect = sum(predictedClasses .equal(y_batch)) .item(Float.self)
                correctPredictions += Int(batchCorrect)
            }

            let avgLoss = totalLoss / Float(numBatches)
            let accuracy = Float(correctPredictions) / Float(numSamples) * 100

            if (epoch + 1) % 10 == 0 || epoch == 0 {
                print("Epoch \(epoch + 1)/\(numEpochs), Loss: \(String(format: "%.4f", avgLoss)), Accuracy: \(String(format: "%.2f", accuracy))%")
            }
        }
        print("\nTraining complete!")

        // MARK: - 6. Perform Inference

        print("\nPerforming inference with the trained model...")

        // Create some new data points for testing
        let testX1 = MLXArray([0.2, 0.3], dtype: .float32).reshaped([1, inputFeatures]) // Should be Receipt (0)
        let testX2 = MLXArray([0.8, 0.9], dtype: .float32).reshaped([1, inputFeatures]) // Should be Invoice (1)
        let testX3 = MLXArray([0.5, 0.5], dtype: .float32).reshaped([1, inputFeatures]) // Should be Receipt (0)

        // Make predictions
        let pred1 = sigmoid(model(testX1)).eval().item(Float.self)
        let pred2 = sigmoid(model(testX2)).eval().item(Float.self)
        let pred3 = sigmoid(model(testX3)).eval().item(Float.self)

        print("Test Document 1 ([0.2, 0.3]): Probability of Invoice: \(String(format: "%.4f", pred1)) -> \(pred1 > 0.5 ? "Invoice" : "Receipt")")
        print("Test Document 2 ([0.8, 0.9]): Probability of Invoice: \(String(format: "%.4f", pred2)) -> \(pred2 > 0.5 ? "Invoice" : "Receipt")")
        print("Test Document 3 ([0.5, 0.5]): Probability of Invoice: \(String(format: "%.4f", pred3)) -> \(pred3 > 0.5 ? "Invoice" : "Receipt")")

        // Example: What are the learned weights and biases?
        // Note: Accessing parameters directly will trigger evaluation if they haven't been evaluated yet.
        if let linearLayer = model.linear as? MLXNN.Linear {
            print("\nLearned Weights:\n", linearLayer.weight.eval())
            print("Learned Bias:\n", linearLayer.bias.eval())
        }

        print("\nMLX Swift Document Classifier Example Finished.")
    }
}
