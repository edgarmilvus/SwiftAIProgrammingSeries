
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

/// A specialized actor to manage high-throughput embedding generation.
actor VectorBatcher {
    private let maxConcurrentRequests: Int
    private let batchSize: Int
    
    init(batchSize: Int = 100, maxConcurrentRequests: Int = 5) {
        self.batchSize = batchSize
        self.maxConcurrentRequests = maxConcurrentRequests
    }
    
    /// Processes chunks by grouping them into batches and limiting concurrency.
    func generateEmbeddings(for chunks: [String]) async throws -> [[Float]] {
        guard !chunks.isEmpty else { return [] }
        
        // 1. Prepare Batches
        let batches = chunks.chunked(into: batchSize)
        var allEmbeddings: [[Float]] = []
        // We need to maintain order, so we'll store results with an index
        var indexedResults: [Int: [Float]] = [:]
        
        // 2. Worker Pool via TaskGroup
        try await withThrowingTaskGroup(of: (Int, [Float]).self) { group in
            var batchIndex = 0
            
            // Fill the initial "Worker Pool"
            while batchIndex < min(maxConcurrentRequests, batches.count) {
                let currentBatch = batches[batchIndex]
                let idx = batchIndex
                
                group.addTask {
                    let vectors = try await self.performMockAPIRequest(for: currentBatch)
                    return (idx, vectors.first ?? []) // Simplified for demo
                }
                batchIndex += 1
            }
            
            // As one worker finishes, start the next one
            for try await (originalIndex, vector) in group {
                indexedResults[originalIndex] = vector
                
                if batchIndex < batches.count {
                    let nextBatch = batches[batchIndex]
                    let idx = batchIndex
                    
                    group.addTask {
                        let vectors = try await self.performMockAPIRequest(for: nextBatch)
                        return (idx, vectors.first ?? [])
                    }
                    batchIndex += 1
                }
            }
        }
        
        // 3. Reassemble in original order
        for i in 0..<batches.count {
            if let vec = indexedResults[i] {
                allEmbeddings.append(vec)
            }
        }
        
        return allEmbeddings
    }
    
    /// Mock API call
    private func performMockAPIRequest(for batch: [String]) async throws -> [[Float]] {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(500))
        return batch.map { _ in (0..<1536).map { _ in Float.random(in: -1...1) } }
    }
}

// Helper for batching (reused from Exercise 4)
extension Array {
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
}
