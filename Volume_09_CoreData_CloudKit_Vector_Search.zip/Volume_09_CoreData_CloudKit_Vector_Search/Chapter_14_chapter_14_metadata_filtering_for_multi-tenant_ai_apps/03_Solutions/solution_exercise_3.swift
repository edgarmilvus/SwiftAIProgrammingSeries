
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CloudKit

@available(iOS 18.0, *)
enum SearchError: Error {
    case workspaceNotFound
    case searchEngineError
    case cloudKitSyncError
}

@available(iOS 18.0, *)
struct SearchResult: Sendable {
    let id: UUID
    let text: String
}

@available(iOS 18.0, *)
class Workspace {
    let id: UUID
    let name: String
    init(id: UUID, name: String) { self.id = id; self.name = name }
}

@available(iOS 18.0, *)
actor WorkspaceScopedSearchService {
    private let searchEngine: SemanticSearchEngine
    private let cloudKitManager: MockCloudKitManager
    private let localCache: MockCoreDataCache
    
    init(engine: SemanticSearchEngine, cloudKit: MockCloudKitManager, cache: MockCoreDataCache) {
        self.searchEngine = engine
        self.cloudKitManager = cloudKit
        self.localCache = cache
    }
    
    func performScopedSearch(query: [Float], in workspace: Workspace) async throws -> [SearchResult] {
        // 1. Check for Cancellation
        try Task.checkCancellation()
        
        // 2. Verify Local Metadata Presence (The "Cold Start" Check)
        var isLocalAvailable = await localCache.containsWorkspace(workspace.id)
        
        if !isLocalAvailable {
            print("Cold Start: Fetching workspace metadata from CloudKit...")
            do {
                try await cloudKitManager.syncWorkspace(workspace.id, to: localCache)
                isLocalAvailable = true
            } catch {
                throw SearchError.cloudKitSyncError
            }
        }
        
        // 3. Perform Hybrid Query (Filter + Search)
        // The search engine handles the scoped filtering via the context
        let context = TenantContext(tenantID: UUID(), workspaceID: workspace.id) 
        // Note: In real app, tenantID would be derived from the authenticated user
        
        let chunks = await searchEngine.search(query: query, context: context, limit: 10)
        
        // 4. Map to Results
        return chunks.map { SearchResult(id: $0.id, text: $0.text) }
    }
}

// MARK: - Mocks for Implementation
@available(iOS 18.0, *)
class MockCloudKitManager {
    func syncWorkspace(_ id: UUID, to cache: MockCoreDataCache) async throws {
        try await Task.sleep(for: .seconds(1)) // Simulate network latency
    }
}

@available(iOS 18.0, *)
class MockCoreDataCache {
    func containsWorkspace(_ id: UUID) async -> Bool { return false }
}
