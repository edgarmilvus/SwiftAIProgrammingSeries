
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision
import UIKit

@available(iOS 18.0, *)
actor MLModelActor { // Declare an actor
    private var model: MLModel?
    private let modelName: String

    init(modelName: String) {
        self.modelName = modelName
        // Load model asynchronously within the actor's isolated context
        Task { await loadModel() }
    }

    private func loadModel() async {
        do {
            let config = MLModelConfiguration()
            // Assuming 'modelName' corresponds to a generated class like 'MyModelName'
            // This part requires dynamic loading or a switch, for simplicity, let's assume 'MyModelName'
            self.model = try await MyModelName(configuration: config).model
            print("Model '\(modelName)' loaded successfully within actor.")
        } catch {
            print("Failed to load model '\(modelName)': \(error)")
        }
    }

    // All methods that access 'model' are implicitly isolated by the actor
    func performClassification(pixelBuffer: CVPixelBuffer) async throws -> MLFeatureProvider {
        guard let model = self.model else {
            throw ClassifierError.modelNotLoaded
        }
        
        // Example input creation
        let input = MyModelNameInput(image: pixelBuffer)
        let prediction = try await model.prediction(from: input)
        return prediction
    }
}

// Usage from a ViewModel:
@available(iOS 18.0, *)
class ImageClassifierViewModel {
    // ... other properties ...
    private let mlActor = MLModelActor(modelName: "MyModelName")

    @MainActor
    func classifyImage(image: UIImage) async {
        // ... preprocessing ...
        do {
            guard let pixelBuffer = image.toCVPixelBuffer(width: 224, height: 224) else {
                throw ClassifierError.inputConversionFailed
            }
            // Calling an actor method requires 'await' and jumps into the actor's isolation
            let prediction = try await mlActor.performClassification(pixelBuffer: pixelBuffer)
            // ... post-processing results ...
        } catch {
            // ... error handling ...
        }
        // ... update UI ...
    }
}
