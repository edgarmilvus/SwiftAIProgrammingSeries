
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import GRDB
import Observation

/// A representation of a high-dimensional vector.
/// Conforms to Sendable to allow safe transfer between actors.
@available(iOS 18.0, *)
public struct EmbeddingVector: Sendable, Codable {
    /// The raw dimensions of the vector (e.g., 1536 for OpenAI, 768 for BERT)
    public let dimensions: Int
    /// The actual floating-point data
    public let values: [Float]
    
    public init(values: [Float]) {
        self.dimensions = values.count
        self.values = values
    }
}

/// A model representing a searchable piece of information.
@available(iOS 18.0, *)
public struct SemanticMemory: Identifiable, Codable, FetchableRecord, PersistableRecord {
    public let id: UUID
    public let content: String
    public let embedding: EmbeddingVector
    public let createdAt: Date
    
    // GRDB requirement: Define columns for SQL queries
    enum Columns {
        static let id = Column(CodingKeys.id)
        static let content = Column(CodingKeys.content)
        static let embedding = Column(CodingKeys.embedding)
        static let createdAt = Column(CodingKeys.createdAt)
    }
}

/// The DatabaseActor isolates all SQLite/GRDB operations.
/// This prevents blocking the MainActor during heavy vector math or I/O.
@available(iOS 18.0, *)
public actor VectorDatabaseManager {
    private let dbWriter: any DatabaseWriter
    
    public init(dbWriter: any DatabaseWriter) {
        self.dbWriter = dbWriter
    }
    
    /// Persists a new memory into the vector store.
    /// - Parameter memory: The semantic memory to save.
    public func saveMemory(_ memory: SemanticMemory) async throws {
        try await dbWriter.write { db in
            try memory.insert(db)
        }
    }
    
    /// Performs a semantic search using a query vector.
    /// Note: In a real-world scenario, this would call a custom 
    /// SQLite function for Cosine Similarity.
    /// - Parameters:
    ///   - queryVector: The embedding of the user's search term.
    ///   - limit: How many results to return.
    /// - Returns: An array of the most semantically similar memories.
    public func search(queryVector: EmbeddingVector, limit: Int = 5) async throws -> [SemanticMemory] {
        try await dbWriter.read { db in
            // Theoretical SQL: 
            // SELECT * FROM semanticMemory 
            // ORDER BY cosine_similarity(embedding, :queryVector) DESC 
            // LIMIT :limit
            
            // For this foundation, we represent the retrieval logic:
            let allMemories = try SemanticMemory.fetchAll(db)
            
            // In a production environment, this math happens inside SQLite 
            // via a C-extension to avoid loading everything into Swift memory.
            return allMemories.sorted { mem1, mem2 in
                cosineSimilarity(mem1.embedding.values, queryVector.values) >
                cosineSimilarity(mem2.embedding.values, queryVector.values)
            }
            .prefix(limit)
            .map { $0 }
        }
    }
}

/// Mathematical utility for similarity.
/// In a high-performance system, this is implemented in C or via SQLite extensions.
@available(iOS 18.0, *)
internal func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
    guard a.count == b.count else { return 0 }
    let dotProduct = zip(a, b).map(*).reduce(0, +)
    let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
    let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
    return dotProduct / (magnitudeA * magnitudeB)
}

/// The ViewModel that connects the UI to the Vector Database.
@available(iOS 18.0, *)
@Observable
public final class SemanticSearchViewModel {
    public var results: [SemanticMemory] = []
    public var isSearching: Bool = false
    
    private let dbManager: VectorDatabaseManager
    
    public init(dbManager: VectorDatabaseManager) {
        self.dbManager = dbManager
    }
    
    @MainActor
    public func performSearch(query: String, embeddingModel: (String) -> EmbeddingVector) async {
        isSearching = true
        defer { isSearching = false }
        
        // 1. Generate embedding (CPU/GPU intensive)
        let queryVector = embeddingModel(query)
        
        do {
            // 2. Perform search on the Database Actor (I/O intensive)
            let matches = try await dbManager.search(queryVector: queryVector)
            
            // 3. Update the UI on the Main Actor
            self.results = matches
        } catch {
            print("Search failed: \(error)")
        }
    }
}
