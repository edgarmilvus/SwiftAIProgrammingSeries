
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import OSLog

enum PIIDetectedError: Error, LocalizedError {
    case sensitiveInformationFound
    
    var errorDescription: String? {
        return "Your prompt contains sensitive information (like an email or SSN) that cannot be sent to the cloud for your protection."
    }
}

@available(iOS 18.0, *)
final class PIIGuardProtocol: URLProtocol {
    private static let logger = Logger(subsystem: "com.zenith.ai", category: "PIIGuard")
    
    // Modern Swift 6 Regex Literals
    private static let emailRegex = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,6}/
    private static let ssnRegex = /\b\d{3}-\d{2}-\d{4}\b/
    
    override class func canInit(with request: URLRequest) -> Bool {
        // Only intercept traffic to our specific AI provider
        guard let host = request.url?.host else { return false }
        return host == "api.your-ai-provider.com"
    }
    
    override class func canonicalRequest(for request: URLRequest) -> URLRequest {
        return request
    }
    
    override func startLoading() {
        guard let bodyData = request.httpBody ?? request.httpBodyStream?.readAllData() else {
            // If no body, proceed normally
            self.proceedWithOriginalRequest()
            return
        }
        
        if let bodyString = String(data: bodyData, encoding: .utf8) {
            // Perform Scanning
            if bodyString.contains(Self.emailRegex) || bodyString.contains(Self.ssnRegex) {
                Self.logger.warning("PII Leakage Blocked!")
                self.client?.urlProtocol(self, didFailWithError: PIIDetectedError.sensitiveInformationFound)
                return
            }
        }
        
        proceedWithOriginalRequest()
    }
    
    private func proceedWithOriginalRequest() {
        // In a real implementation, you would use a custom URLSession 
        // to forward the request to avoid infinite loops.
        // For this exercise, we simulate the hand-off.
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: request) { [weak self] data, response, error in
            if let error = error {
                self?.client?.urlProtocol(self!, didFailWithError: error)
            } else if let data = data, let response = response {
                self?.client?.urlProtocol(self!, didReceive: response, cacheStoragePolicy: .notAllowed)
                self?.client?.urlProtocol(self!, didLoad: data)
                self?.client?.urlProtocolDidFinishLoading(self!)
            }
        }
        task.resume()
    }
    
    override func stopLoading() {}
}

// Helper to handle stream-based bodies
extension InputStream {
    func readAllData() -> Data {
        var data = Data()
        let bufferSize = 1024
        let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: bufferSize)
        defer { buffer.deallocate() }
        
        self.open()
        while self.hasBytesAvailable {
            let read = self.read(buffer, maxLength: bufferSize)
            if read > 0 {
                data.append(buffer, count: read)
            } else {
                break
            }
        }
        self.close()
        return data
    }
}
