
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation

/// Represents the various errors that can occur during the ReAct loop.
enum AgentError: Error {
    case parsingError(String)
    case toolExecutionFailed(String)
    case maxIterationsReached
    case llmError(String)
}

/// The protocol defining a 'Tool' that the ReAct agent can utilize.
/// Tools must be `Sendable` to safely cross actor boundaries in Swift 6.
protocol Tool: Sendable {
    /// A unique identifier for the tool used by the LLM.
    var name: String { get }
    
    /// A description of what the tool does, used to instruct the LLM.
    var description: String { get }
    
    /// Executes the tool logic based on the input provided by the LLM.
    func execute(input: String) async throws -> String
}

/// A concrete implementation of a Weather Tool.
/// In a real app, this would call a WeatherKit or OpenWeather API.
struct WeatherTool: Tool {
    let name = "get_weather"
    let description = "Provides the current weather for a given city. Input should be a city name."

    func execute(input: String) async throws -> String {
        // Simulate a network delay
        try await Task.sleep(for: .seconds(1))
        
        // Mock logic for demonstration
        if input.lowercased().contains("london") {
            return "The weather in London is 15°C and cloudy."
        } else if input.lowercased().contains("new york") {
            return "The weather in New York is 22°C and sunny."
        } else {
            return "I'm sorry, I don't have weather data for \(input)."
        }
    }
}

/// The AgentState manages the conversation history and the current loop status.
/// We use `@Observable` for easy integration with SwiftUI.
@Observable
@MainActor
class AgentState {
    var messages: [String] = []
    var isProcessing: Bool = false
    var lastThought: String = ""
    var lastAction: String = ""
}

/// The ReActAgent is the core orchestrator. 
/// It uses the 'Thought-Action-Observation' loop to solve complex queries.
@available(iOS 18.0, macOS 15.0, *)
actor ReActAgent {
    private let tools: [String: any Tool]
    private let systemPrompt: String
    private let maxIterations: Int = 5
    
    /// Initializes the agent with a set of available tools.
    /// - Parameter tools: An array of objects conforming to the Tool protocol.
    init(tools: [any Tool]) {
        var toolMap: [String: any Tool] = [:]
        for tool in tools {
            toolMap[tool.name] = tool
        }
        self.tools = toolMap
        
        // The System Prompt is the most critical part of ReAct.
        // It defines the "Rules of Engagement" for the LLM.
        self.systemPrompt = """
        You are a helpful AI Assistant. You solve problems using a ReAct pattern.
        You have access to the following tools:
        \(tools.values.map { "- \($0.name): \($0.description)" }.joined(separator: "\n"))

        Your workflow must follow this exact format:
        Thought: [Your reasoning about what to do next]
        Action: [tool_name]([input])
        Observation: [The result of the tool]

        Repeat this until you have the final answer.
        When you have the final answer, respond with:
        Final Answer: [Your conclusive response]
        """
    }

    /// The primary entry point for the user to interact with the agent.
    /// - Parameter userQuery: The natural language question from the user.
    /// - Returns: The final string response.
    func run(userQuery: String) async throws -> String {
        var history = [systemPrompt, "User: \(userQuery)"]
        
        for iteration in 1...maxIterations {
            let currentContext = history.joined(separator: "\n")
            
            // 1. CALL THE LLM (Simulated)
            // In a real implementation, this calls OpenAI/Anthropic API.
            let llmResponse = try await simulateLLMCall(prompt: currentContext)
            
            // Append the LLM's thought/action to history
            history.append(llmResponse)
            
            // 2. CHECK FOR FINAL ANSWER
            if let finalAnswer = parseFinalAnswer(from: llmResponse) {
                return finalAnswer
            }
            
            // 3. PARSE ACTION
            guard let (toolName, toolInput) = parseAction(from: llmResponse) else {
                throw AgentError.parsingError("Could not parse Action from: \(llmResponse)")
            }
            
            // 4. EXECUTE TOOL
            guard let tool = tools[toolName] else {
                throw AgentError.toolExecutionFailed("Tool '\(toolName)' not found.")
            }
            
            let observation = try await tool.execute(input: toolInput)
            
            // 5. FEED OBSERVATION BACK
            // The observation is appended so the LLM can "see" the result in the next turn.
            history.append("Observation: \(observation)")
        }
        
        throw AgentError.maxIterationsReached
    }

    /// Simulates an LLM response to avoid requiring a real API key for this example.
    /// In a production app, this would be an actual network request.
    private func simulateLLMCall(prompt: String) async throws -> String {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(500))
        
        if prompt.contains("London") && !prompt.contains("Observation") {
            return "Thought: The user wants to know the weather in London. I should use the weather tool.\nAction: get_weather(London)"
        } else if prompt.contains("Observation: The weather in London is 15°C and cloudy.") {
            return "Final Answer: It is currently 15°C and cloudy in London."
        } else {
            return "Thought: I am not sure what to do.\nFinal Answer: I'm sorry, I couldn't assist with that."
        }
    }

    /// Uses simple string parsing to extract the tool name and input.
    /// In production, use Regular Expressions (Regex) for higher reliability.
    private func parseAction(from text: String) -> (String, String)? {
        // Looking for pattern: Action: tool_name(input)
        let pattern = /Action:\s*(\w+)\((.*)\)/
        if let match = text.firstMatch(of: pattern) {
            return (String(match.1), String(match.2))
        }
        return nil
    }

    /// Extracts the final answer from the LLM output.
    private func parseFinalAnswer(from text: String) -> String? {
        let pattern = /Final Answer:\s*(.*)/
        if let match = text.firstMatch(of: pattern) {
            return String(match.1)
        }
        return nil
    }
}

// MARK: - UI Integration Example

@MainActor
class AssistantViewModel: ObservableObject {
    @Published var agentState = AgentState()
    private let agent = ReActAgent(tools: [WeatherTool()])

    func askQuestion(_ query: String) {
        Task {
            agentState.isProcessing = true
            agentState.messages = ["User: \(query)"]
            
            do {
                let response = try await agent.run(userQuery: query)
                agentState.messages.append("Assistant: \(response)")
            } catch {
                agentState.messages.append("Error: \(error.localizedDescription)")
            }
            
            agentState.isProcessing = false
        }
    }
}
