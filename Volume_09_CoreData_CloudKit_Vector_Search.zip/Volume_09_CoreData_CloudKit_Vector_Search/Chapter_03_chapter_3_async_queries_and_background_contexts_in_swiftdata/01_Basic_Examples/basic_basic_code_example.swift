
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import SwiftData
import Foundation

// MARK: - Model Definition

/// Represents a single voice memo entry in our journal.
/// We use @available to ensure we are targeting the latest SwiftData capabilities.
@available(iOS 18.0, macOS 15.0, *)
@Model
final class VoiceMemo {
    /// The unique identifier for the memo.
    var id: UUID
    /// The transcribed text content of the memo.
    var transcript: String
    /// The timestamp of when the memo was recorded.
    var timestamp: Date
    
    init(transcript: String, timestamp: Date = .now) {
        self.id = UUID()
        self.transcript = transcript
        self.timestamp = timestamp
    }
}

// MARK: - Background Worker (The ModelActor)

/// `MemoBackgroundWorker` is a specialized Actor that handles all heavy database operations.
/// By conforming to `ModelActor`, it gains its own private `ModelContext` and 
/// executes all its work on a background executor, isolated from the `@MainActor`.
@available(iOS 18.0, macOS 15.0, *)
@ModelActor
actor MemoBackgroundWorker {
    
    /// Performs a heavy background task: creating multiple memos at once.
    /// This simulates a process like batch-importing transcripts from an AI engine.
    ///
    /// - Parameter count: The number of memos to generate.
    /// - Returns: An array of `PersistentIdentifier`s. 
    ///   Crucial: We return IDs, NOT the model objects themselves, to ensure thread safety.
    func batchCreateMemos(count: Int) throws -> [PersistentIdentifier] {
        print("Background: Starting batch creation of \(count) memos...")
        
        var createdIDs: [PersistentIdentifier] = []
        
        for i in 1...count {
            let newMemo = VoiceMemo(transcript: "Automated transcript for memo #\(i)")
            modelContext.insert(newMemo)
            
            // We capture the identifier immediately after insertion
            if let id = newMemo.persistentModelID as PersistentIdentifier? {
                createdIDs.append(id)
            }
            
            // Simulate heavy processing time
            Thread.sleep(forTimeInterval: 0.01) 
        }
        
        // Persist the changes to the underlying store
        try modelContext.save()
        print("Background: Batch creation complete.")
        return createdIDs
    }
    
    /// Performs a complex search in the background.
    ///
    /// - Parameter query: The text to search for.
    /// - Returns: An array of `PersistentIdentifier`s matching the query.
    func searchMemos(matching query: String) throws -> [PersistentIdentifier] {
        print("Background: Searching for '\(query)'...")
        
        let predicate = #Predicate<VoiceMemo> { memo in
            memo.transcript.contains(query)
        }
        
        let descriptor = FetchDescriptor<VoiceMemo>(predicate: predicate)
        let results = try modelContext.fetch(descriptor)
        
        // Again, we only return the IDs to respect Swift 6 Concurrency rules.
        return results.map { $0.persistentModelID }
    }
}

// MARK: - ViewModel (The Coordinator)

/// The `MemoViewModel` lives on the `@MainActor`. 
/// It coordinates between the UI and the background worker.
@available(iOS 18.0, macOS 15.0, *)
@MainActor
class MemoViewModel: ObservableObject {
    /// The source of truth for the UI.
    @Published var memos: [VoiceMemo] = []
    /// Tracks if a background operation is currently running.
    @Published var isProcessing: Bool = false
    
    private var modelContainer: ModelContainer
    private var worker: MemoBackgroundWorker?

    init(container: ModelContainer) {
        self.modelContainer = container
        // Initialize the background worker with the shared container
        self.worker = MemoBackgroundWorker(modelContainer: container)
    }

    /// Triggers the background batch creation process.
    func runBatchImport() {
        isProcessing = true
        
        // We use a Task to enter an asynchronous context from the synchronous function
        Task {
            do {
                // 1. Call the background actor
                // This call suspends the MainActor, allowing the UI to remain responsive.
                if let worker = worker {
                    let newIDs = try await worker.batchCreateMemos(count: 50)
                    
                    // 2. Once the background work is done, we must update the UI.
                    // Since we are in a Task on the @MainActor, we can safely update @Published properties.
                    try await refreshMemos()
                    print("MainActor: Successfully imported \(newIDs.count) memos.")
                }
            } catch {
                print("Error during batch import: \(error)")
            }
            isProcessing = false
        }
    }
    
    /// Refreshes the local array of memos by fetching them on the MainActor.
    /// This is necessary because the background worker only returns IDs.
    func refreshMemos() async throws {
        // We use the mainContext for UI-facing fetches.
        let descriptor = FetchDescriptor<VoiceMemo>(sortBy: [SortDescriptor(\.timestamp, order: .reverse)])
        let context = modelContainer.mainContext
        self.memos = try context.fetch(descriptor)
    }
}

// MARK: - View Layer

@available(iOS 18.0, macOS 15.0, *)
struct MemoListView: View {
    @StateObject var viewModel: MemoViewModel
    
    var body: some View {
        NavigationStack {
            List(viewModel.memos) { memo in
                VStack(alignment: .leading) {
                    Text(memo.transcript)
                        .font(.headline)
                    Text(memo.timestamp.formatted())
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Voice Journal")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button(action: { viewModel.runBatchImport() }) {
                        if viewModel.isProcessing {
                            ProgressView()
                        } else {
                            Label("Import Memos", systemImage: "square.and.arrow.down")
                        }
                    }
                    .disabled(viewModel.isProcessing)
                }
            }
            .task {
                // Initial load
                try? await viewModel.refreshMemos()
            }
        }
    }
}
