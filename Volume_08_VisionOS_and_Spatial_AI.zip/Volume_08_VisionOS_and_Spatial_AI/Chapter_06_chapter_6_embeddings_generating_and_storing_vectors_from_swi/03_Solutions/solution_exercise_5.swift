
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import CryptoKit

actor EmbeddingCache {
    private var inMemoryCache: [String: Vector] = [:]
    private var inFlightRequests: [String: Task<Vector, Error>] = [:]
    private let fileManager = FileManager.default
    private let cacheDirectory: URL

    init() throws {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        self.cacheDirectory = appSupport.appendingPathComponent("EmbeddingCache")
        
        if !fileManager.fileExists(atPath: cacheDirectory.path) {
            try fileManager.createDirectory(at: cacheDirectory, withIntermediateDirectories: true)
        }
    }

    /// Generates a SHA-256 hash for a string to use as a cache key.
    private func hash(for text: String) -> String {
        let data = Data(text.utf8)
        let hashed = SHA256.hash(data: data)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }

    func getEmbedding(for text: String, provider: EmbeddingProvider) async throws -> Vector {
        let key = hash(for: text)

        // 1. Check In-Memory Cache
        if let cached = inMemoryCache[key] {
            return cached
        }

        // 2. Check On-Disk Cache
        if let diskVector = try? loadFromDisk(key: key) {
            inMemoryCache[key] = diskVector
            return diskVector
        }

        // 3. Handle "Thundering Herd" (In-flight requests)
        if let inFlight = inFlightRequests[key] {
            return try await inFlight.value
        }

        // 4. Cache-Aside Pattern: Call Provider
        let task = Task {
            do {
                let vector = try await provider.generateEmbedding(for: text)
                await self.saveToCache(key: key, vector: vector)
                return vector
            } catch {
                throw error
            }
        }

        inFlightRequests[key] = task
        
        // Ensure we clean up the in-flight dictionary once the task completes
        defer { inFlightRequests[key] = nil }

        return try await task.value
    }

    private func saveToCache(key: String, vector: Vector) {
        inMemoryCache[key] = vector
        let data = vector.withUnsafeBytes { Data($0) }
        let fileURL = cacheDirectory.appendingPathComponent(key)
        try? data.write(to: fileURL)
    }

    private func loadFromDisk(key: String) throws -> Vector {
        let fileURL = cacheDirectory.appendingPathComponent(key)
        let data = try Data(contentsOf: fileURL)
        return data.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
    }
}
