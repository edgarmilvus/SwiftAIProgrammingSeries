
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, *)
class DocumentScannerViewModel: ObservableObject {
    @Published var classificationResult: String = "No scan performed."
    @Published var inferenceDuration: String = ""
    @Published var selectedStrategy: QuantizationStrategy = .quantized {
        didSet {
            inferenceManager.setQuantizationStrategy(selectedStrategy)
            // Optionally clear cache if switching strategies should force a reload
            // inferenceManager.clearModelCache()
        }
    }
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let inferenceManager: ModelInferenceManager

    /// Initializes the ViewModel.
    init() {
        self.inferenceManager = ModelInferenceManager(defaultStrategy: .quantized)
    }

    /// Simulates scanning a document and performs classification.
    /// - Parameter documentImage: The UIImage representing the scanned document.
    func scanDocument(documentImage: UIImage) {
        isLoading = true
        errorMessage = nil
        classificationResult = "Classifying..."

        Task {
            do {
                let (observations, duration) = try await inferenceManager.classifyDocument(image: documentImage)
                await MainActor.run {
                    if let topClassification = observations.first {
                        classificationResult = "Type: \(topClassification.identifier) (Confidence: \(String(format: "%.2f", topClassification.confidence * 100))%)"
                    } else {
                        classificationResult = "No clear classification found."
                    }
                    inferenceDuration = "Inference took: \(String(format: "%.3f", duration)) seconds"
                    isLoading = false
                }
            } catch {
                await MainActor.run {
                    errorMessage = (error as? ModelInferenceError)?.localizedDescription ?? "An unknown error occurred."
                    classificationResult = "Error during classification."
                    inferenceDuration = ""
                    isLoading = false
                }
            }
        }
    }

    /// Clears the current classification results.
    func clearResults() {
        classificationResult = "No scan performed."
        inferenceDuration = ""
        errorMessage = nil
    }
}
