
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftUI // For demonstration in a View if needed

// MARK: - Pluralization Logic
func localizedUnreadMessageCount(count: Int, localeIdentifier: String) -> String {
    let locale = Locale(identifier: localeIdentifier)
    let formatKey: String
    
    // Select the appropriate key based on the locale
    switch locale.language.languageCode?.identifier {
    case "pl":
        formatKey = "unread_messages_count_pl"
    case "ar":
        formatKey = "unread_messages_count_ar"
    default:
        formatKey = "unread_messages_count" // Default to English rules
    }
    
    // NSLocalizedString uses the device's current locale by default,
    // but for testing specific locales, we simulate it by passing
    // the count to the format string.
    // In a real app, you'd typically just use NSLocalizedString(formatKey, ...)
    // and let the system handle the current device locale.
    
    // This is a common pattern to use with .stringsdict
    // It automatically picks the correct plural form based on 'count'
    // and the rules defined in Localizable.stringsdict for the current locale.
    return String(format: NSLocalizedString(formatKey, comment: "Unread messages count"), count)
}

// MARK: - Relative Time Logic
func localizedRelativeTime(for date: Date, locale: Locale) -> String {
    // Swift 6 and modern iOS/macOS can leverage FormatStyle for type-safe and efficient formatting.
    // However, the prompt's example uses @available(iOS 18.0, macOS 15.0, *),
    // indicating a forward-looking API. For broader compatibility with current Swift 6 targets
    // (e.g., iOS 17/macOS 14), RelativeDateTimeFormatter is the practical choice.
    
    // Using RelativeDateTimeFormatter for current OS versions
    let formatter = RelativeDateTimeFormatter()
    formatter.locale = locale
    formatter.dateTimeStyle = .named // e.g., "yesterday", "tomorrow"
    formatter.unitsStyle = .full    // e.g., "5 minutes ago", "2 hours ago"
    
    return formatter.localizedString(for: date, relativeTo: Date())
}

// MARK: - Demonstration (Example Usage)
struct LocalizationDemoView: View {
    let now = Date()

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Unread Message Counts:")
                .font(.headline)

            Group {
                // English Pluralization
                Text("EN (1): \(localizedUnreadMessageCount(count: 1, localeIdentifier: "en"))")
                Text("EN (5): \(localizedUnreadMessageCount(count: 5, localeIdentifier: "en"))")

                // Polish Pluralization
                Text("PL (1): \(localizedUnreadMessageCount(count: 1, localeIdentifier: "pl"))")
                Text("PL (2): \(localizedUnreadMessageCount(count: 2, localeIdentifier: "pl"))")
                Text("PL (5): \(localizedUnreadMessageCount(count: 5, localeIdentifier: "pl"))")
                Text("PL (22): \(localizedUnreadMessageCount(count: 22, localeIdentifier: "pl"))") // Example of 'few'
                Text("PL (100): \(localizedUnreadMessageCount(count: 100, localeIdentifier: "pl"))") // Example of 'many/other'

                // Arabic Pluralization
                Text("AR (0): \(localizedUnreadMessageCount(count: 0, localeIdentifier: "ar"))")
                Text("AR (1): \(localizedUnreadMessageCount(count: 1, localeIdentifier: "ar"))")
                Text("AR (2): \(localizedUnreadMessageCount(count: 2, localeIdentifier: "ar"))")
                Text("AR (5): \(localizedUnreadMessageCount(count: 5, localeIdentifier: "ar"))")
                Text("AR (15): \(localizedUnreadMessageCount(count: 15, localeIdentifier: "ar"))")
                Text("AR (100): \(localizedUnreadMessageCount(count: 100, localeIdentifier: "ar"))")
            }
            .font(.body)

            Divider()

            Text("Relative Times:")
                .font(.headline)

            Group {
                let fiveMinutesAgo = now.addingTimeInterval(-300)
                let twoHoursAgo = now.addingTimeInterval(-3600 * 2)
                let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: now)!
                let lastWeek = Calendar.current.date(byAdding: .weekOfYear, value: -1, to: now)!

                // English Relative Time
                Text("EN (5 min ago): \(localizedRelativeTime(for: fiveMinutesAgo, locale: Locale(identifier: "en")))")
                Text("EN (2 hrs ago): \(localizedRelativeTime(for: twoHoursAgo, locale: Locale(identifier: "en")))")
                Text("EN (Yesterday): \(localizedRelativeTime(for: yesterday, locale: Locale(identifier: "en")))")
                Text("EN (Last Week): \(localizedRelativeTime(for: lastWeek, locale: Locale(identifier: "en")))")

                // Japanese Relative Time
                Text("JA (5 min ago): \(localizedRelativeTime(for: fiveMinutesAgo, locale: Locale(identifier: "ja")))")
                Text("JA (2 hrs ago): \(localizedRelativeTime(for: twoHoursAgo, locale: Locale(identifier: "ja")))")
                Text("JA (Yesterday): \(localizedRelativeTime(for: yesterday, locale: Locale(identifier: "ja")))")
                Text("JA (Last Week): \(localizedRelativeTime(for: lastWeek, locale: Locale(identifier: "ja")))")
            }
            .font(.body)
        }
        .padding()
    }
}

struct LocalizationDemoView_Previews: PreviewProvider {
    static var previews: some View {
        LocalizationDemoView()
    }
}
