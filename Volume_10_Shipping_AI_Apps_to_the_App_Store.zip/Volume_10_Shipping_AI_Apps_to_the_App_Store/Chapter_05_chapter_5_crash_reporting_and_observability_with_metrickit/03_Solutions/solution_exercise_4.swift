
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

enum InferenceMode: String {
    case ultraHD, lite, safeMode
}

enum InferenceError: Error {
    case loadingFailed
}

/// An orchestrator that manages the AI model lifecycle based on hardware constraints.
actor InferenceOrchestrator {
    private(set) var currentMode: InferenceMode = .ultraHD
    private var currentInferenceTask: Task<Void, Never>?
    
    // Simulated model loading
    private func loadModel(for mode: InferenceMode) async throws {
        print("🔄 Transitioning to \(mode.rawValue) mode...")
        try await Task.sleep(for: .seconds(1.5)) // Simulate heavy I/O
        
        // Simulate a potential failure
        if mode == .ultraHD && Bool.random() && false { // Never fails in this demo
            throw InferenceError.loadingFailed
        }
    }

    /// The core control loop logic.
    func updateSystemState(thermalState: ProcessInfo.ThermalState, memoryPressureHigh: Bool) async {
        let targetMode: InferenceMode
        
        switch thermalState {
        case .serious, .critical:
            targetMode = .safeMode
        case .nominal, .fair:
            targetMode = memoryPressureHigh ? .lite : .ultraHD
        @unknown default:
            targetMode = .lite
        }
        
        if targetMode != currentMode {
            await transition(to: targetMode)
        }
    }

    private func transition(to mode: InferenceMode) async {
        // 1. Cancel any ongoing inference to prevent memory overlap
        currentInferenceTask?.cancel()
        
        // 2. Attempt to load the new model
        do {
            try await loadModel(for: mode)
            self.currentMode = mode
            print("✅ Successfully switched to \(mode.rawValue)")
        } catch {
            print("❌ Failed to transition to \(mode.rawValue). Reverting to safeMode.")
            self.currentMode = .safeMode
        }
    }

    func performInference() {
        // Capture the current task so we can cancel it later
        currentInferenceTask = Task {
            print("🧠 Running inference in \(currentMode.rawValue) mode...")
            // Simulate the inference loop
            for i in 1...10 {
                if Task.isCancelled { 
                    print("🛑 Inference task cancelled during transition.")
                    return 
                }
                try? await Task.sleep(for: .milliseconds(200))
                print("Token \(i) generated...")
            }
        }
    }
}
