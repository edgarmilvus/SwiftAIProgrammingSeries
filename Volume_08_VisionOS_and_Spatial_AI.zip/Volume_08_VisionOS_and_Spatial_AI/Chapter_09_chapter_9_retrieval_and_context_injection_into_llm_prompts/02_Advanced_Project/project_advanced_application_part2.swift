
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import NaturalLanguage
import OpenAI // Hypothetical high-level client
import OSLog

/// Represents a single, semantically coherent unit of text within a larger document.
/// Conforms to `Sendable` to ensure safe transfer across concurrency boundaries in Swift 6.
public struct DocumentChunk: Sendable, Identifiable {
    public let id: UUID
    public let text: String
    public let embedding: [Float]
    public let metadata: [String: String]
    
    public init(id: UUID = UUID(), text: String, embedding: [Float], metadata: [String: String] = [:]) {
        self.id = id
        self.text = text
        self.embedding = embedding
        self.metadata = metadata
    }
}

/// Errors specific to the Retrieval-Augmented Generation pipeline.
public enum RAGError: Error, LocalizedError {
    case chunkingFailed(String)
    case embeddingGenerationFailed(Error)
    case vectorStoreError(String)
    case insufficientContext
    case apiError(String)

    public var errorDescription: String? {
        switch self {
        case .chunkingFailed(let msg): return "Failed to segment document: \(msg)"
        case .embeddingGenerationFailed(let err): return "Embedding engine error: \(err.localizedDescription)"
        case .vectorStoreError(let msg): return "Vector database error: \(msg)"
        case .insufficientContext: return "The retrieved context was too sparse to answer the query."
        case .apiError(let msg): return "LLM API error: \(msg)"
        }
    }
}

/// An actor-based Vector Store that manages high-dimensional embeddings in memory.
/// Using an `actor` ensures that concurrent searches and insertions are synchronized,
/// preventing data races in the underlying storage.
public actor VectorStore {
    private var storage: [DocumentChunk] = []
    private let logger = Logger(subsystem: "com.app.rag", category: "VectorStore")

    /// Inserts a new chunk into the store.
    /// - Parameter chunk: The semantically enriched chunk to store.
    public func insert(_ chunk: DocumentChunk) {
        storage.append(chunk)
        logger.info("Inserted chunk \(chunk.id). Total chunks: \(self.storage.count)")
    }

    /// Performs a K-Nearest Neighbors (KNN) search using Cosine Similarity.
    /// - Parameters:
    ///   - queryEmbedding: The vector representation of the user's question.
    ///   - k: The number of top results to return.
    /// - Returns: An array of the most relevant `DocumentChunk` objects.
    public func search(queryEmbedding: [Float], k: Int) -> [DocumentChunk] {
        // We sort by cosine similarity descending.
        // Similarity = (A · B) / (||A|| * ||B||)
        // Since embeddings are typically normalized to unit length, this simplifies to the dot product.
        let sorted = storage.sorted { (chunkA, chunkB) -> Bool in
            let simA = cosineSimilarity(queryEmbedding, chunkA.embedding)
            let simB = cosineSimilarity(queryEmbedding, chunkB.embedding)
            return simA > simB
        }
        
        return Array(sorted.prefix(k))
    }

    /// Calculates the cosine similarity between two vectors.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0.0 }
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

/// The orchestrator for the RAG process.
/// This class manages the lifecycle from document ingestion to query response.
public final class DocumentIntelligenceEngine: Sendable {
    private let vectorStore = VectorStore()
    private let openaiClient: OpenAIClient // Hypothetical
    private let logger = Logger(subsystem: "com.app.rag", category: "Engine")

    public init(apiKey: String) {
        self.openaiClient = OpenAIClient(apiKey: apiKey)
    }

    // MARK: - Ingestion Pipeline

    /// Processes a raw string by chunking it, embedding it, and storing it.
    /// Uses structured concurrency to parallelize embedding generation.
    /// - Parameter text: The full text of the document.
    /// - Throws: `RAGError` if any stage of the pipeline fails.
    public func ingest(text: String) async throws {
        logger.info("Starting ingestion process...")
        
        // 1. Semantic Chunking
        let chunks = try performSemanticChunking(on: text)
        
        // 2. Parallel Embedding Generation
        // We use a TaskGroup to generate embeddings for all chunks concurrently.
        // This significantly speeds up ingestion on multi-core Apple Silicon.
        try await withThrowingTaskGroup(of: DocumentChunk.self) { group in
            for chunkText in chunks {
                group.addTask {
                    let embedding = try await self.openaiClient.generateEmbedding(for: chunkText)
                    return DocumentChunk(text: chunkText, embedding: embedding)
                }
            }

            for try await completedChunk in group {
                await vectorStore.insert(completedChunk)
            }
        }
        
        logger.info("Ingestion complete.")
    }

    /// Uses Apple's NaturalLanguage framework to split text at sentence boundaries.
    /// This ensures we don't break the semantic meaning of the text.
    private func performSemanticChunking(on text: String) throws -> [String] {
        var chunks: [String] = []
        let tokenizer = NLTokenizer(unit: .sentence)
        tokenizer.string = text

        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { range, _ in
            let sentence = String(text[range])
            // In a production app, we might combine multiple sentences 
            // until a character limit is reached to create larger chunks.
            if !sentence.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                chunks.append(sentence)
            }
            return true
        }

        guard !chunks.isEmpty else {
            throw RAGError.chunkingFailed("No valid sentences found in document.")
        }
        return chunks
    }

    // MARK: - Query Pipeline

    /// The primary entry point for user interaction.
    /// Implements the full RAG cycle: Query -> Embed -> Retrieve -> Augment -> Generate.
    /// - Parameter query: The user's natural language question.
    /// - Returns: The LLM's answer based on the retrieved context.
    public func ask(query: String) async throws -> String {
        logger.info("Processing query: \(query)")

        // 1. Embed the query
        let queryEmbedding = try await openaiClient.generateEmbedding(for: query)

        // 2. Retrieve relevant context
        let relevantChunks = await vectorStore.search(queryEmbedding: queryEmbedding, k: 3)
        
        guard !relevantChunks.isEmpty else {
            throw RAGError.insufficientContext
        }

        // 3. Construct the Augmented Prompt
        // We use a specific template to instruct the LLM to use ONLY the provided context.
        let contextString = relevantChunks
            .map { "- \($0.text)" }
            .joined(separator: "\n")

        let systemPrompt = """
        You are a professional document assistant. 
        Use the provided context fragments to answer the user's question accurately.
        If the answer is not contained within the context, state that you do not know.
        Do not use outside knowledge.

        CONTEXT:
        \(contextString)
        """

        let userPrompt = "Question: \(query)\nAnswer:"

        // 4. Generate Response
        return try await openaiClient.generateChatCompletion(
            systemMessage: systemPrompt,
            userMessage: userPrompt
        )
    }
}

// MARK: - Mock Supporting Types (For Compilation)

/// A mock client to represent the OpenAI integration.
internal final class OpenAIClient: Sendable {
    let apiKey: String
    init(apiKey: String) { self.apiKey = apiKey }

    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(100))
        // Return a dummy 1536-dimension vector (standard for OpenAI)
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }

    func generateChatCompletion(systemMessage: String, userMessage: String) async throws -> String {
        try await Task.sleep(for: .milliseconds(500))
        return "Based on the documents provided, the answer is [Simulated Response]."
    }
}
