
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI

/// A simple view model to manage the chat state and handle LLM interactions.
@MainActor // Ensure all state updates happen on the main actor for UI safety.
class ChatViewModel: ObservableObject {
    @Published var currentResponse: String = ""
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    private var streamingTask: Task<Void, Never>? // To hold and potentially cancel the streaming task

    /// Simulates fetching a streaming response from an LLM endpoint.
    /// In a real app, `llmEndpointURL` would point to your local Ollama server or custom inference pipeline.
    /// - Parameter prompt: The user's input prompt for the LLM.
    @available(iOS 15.0, macOS 12.0, *) // URLSession.AsyncBytes is available from these versions
    func fetchStreamingResponse(prompt: String) {
        // Cancel any existing streaming task to prevent multiple concurrent streams
        streamingTask?.cancel() 
        currentResponse = "" // Clear previous response
        isLoading = true
        errorMessage = nil

        // IMPORTANT: Replace with your actual local LLM streaming endpoint URL.
        // For demonstration, we'll use a placeholder. A real LLM might use POST with a body.
        // Example for Ollama: "http://localhost:11434/api/generate"
        // For this basic GET example, we'll just append the prompt.
        guard let url = URL(string: "https://mock-streaming-llm.example.com/stream?prompt=\(prompt.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")") else {
            errorMessage = "Invalid URL."
            isLoading = false
            return
        }
        
        var request = URLRequest(url: url)
        // For actual LLM APIs like Ollama, you'd typically use POST with a JSON body.
        // Example for Ollama:
        /*
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "model": "llama2", // or your preferred model
            "prompt": prompt,
            "stream": true
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        */

        // Create a new streaming task
        streamingTask = Task {
            do {
                // 1. Initiate the streaming request using URLSession.shared.bytes(for:)
                // This returns an AsyncBytes sequence, allowing us to process data as it arrives.
                let (bytes, response) = try await URLSession.shared.bytes(for: request)
                
                // Optional: Check HTTP response status code
                if let httpResponse = response as? HTTPURLResponse, !(200...299).contains(httpResponse.statusCode) {
                    throw URLError(.badServerResponse)
                }

                // 2. Iterate over the AsyncBytes sequence
                // The 'for await' loop processes each chunk of Data as it becomes available.
                for try await chunk in bytes {
                    // Check if the task was cancelled
                    Task.checkCancellation()
                    
                    // 3. Convert Data chunk to String
                    // Assuming UTF-8 encoding, which is common for LLM responses.
                    // It's crucial to handle potential partial UTF-8 sequences carefully in production.
                    // For a basic example, we'll append directly.
                    if let text = String(data: chunk, encoding: .utf8) {
                        // 4. Update the UI incrementally on the main actor
                        // @MainActor ensures this happens safely on the main thread.
                        self.currentResponse += text
                    } else {
                        print("Warning: Could not decode data chunk to UTF-8 string.")
                    }
                }
                // Stream finished successfully
                self.isLoading = false

            } catch is URLError {
                // Handle network-specific errors
                self.errorMessage = "Network error: Please check your connection or server availability."
                self.isLoading = false
            } catch is CancellationError {
                // Task was explicitly cancelled (e.g., by a new request)
                print("Streaming task cancelled.")
                self.isLoading = false
            } catch {
                // Catch any other errors during the process
                self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                self.isLoading = false
            }
        }
    }
    
    /// Cancels the ongoing streaming task.
    func cancelStreaming() {
        streamingTask?.cancel()
        streamingTask = nil // Clear the task reference
        isLoading = false
    }
}

/// A SwiftUI view to demonstrate the streaming LLM response.
@available(iOS 15.0, macOS 12.0, *)
struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    @State private var prompt: String = "Explain quantum computing in simple terms."

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 15) {
                // User Input
                TextField("Enter your prompt...", text: $prompt)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                // Action Buttons
                HStack {
                    Button("Get Streaming Response") {
                        viewModel.fetchStreamingResponse(prompt: prompt)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(viewModel.isLoading)

                    if viewModel.isLoading {
                        ProgressView()
                    }
                    
                    Spacer()
                    
                    Button("Cancel") {
                        viewModel.cancelStreaming()
                    }
                    .buttonStyle(.bordered)
                    .disabled(!viewModel.isLoading)
                }
                .padding(.horizontal)

                Divider()

                // LLM Response Display
                ScrollView {
                    Text(viewModel.currentResponse.isEmpty && !viewModel.isLoading ? "Response will appear here..." : viewModel.currentResponse)
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                // Error Message Display
                if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .padding(.horizontal)
                }
            }
            .navigationTitle("AI Chat Stream")
        }
    }
}

// MARK: - App Entry Point (for Xcode Previews and App lifecycle)

@available(iOS 15.0, macOS 12.0, *)
struct StreamingLLMApp: App {
    var body: some Scene {
        WindowGroup {
            ChatView()
        }
    }
}

// To run this in a standalone Swift file for quick testing (e.g., in a playground or command line tool):
// You'd need to mock the URLSession.bytes(for:) behavior or point to a real streaming server.
// For a SwiftUI app, the `StreamingLLMApp` struct is the entry point.
