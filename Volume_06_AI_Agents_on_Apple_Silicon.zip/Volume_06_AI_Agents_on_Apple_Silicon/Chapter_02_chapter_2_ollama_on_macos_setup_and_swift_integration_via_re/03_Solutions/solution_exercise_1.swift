
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// MARK: - Codable Structures

/// Represents the request body for the /api/generate endpoint (non-streaming).
struct GenerateRequest: Codable {
    let model: String
    let prompt: String
    let stream: Bool // Set to false for this exercise

    // Optional parameters for fine-tuning generation
    let options: Options?

    struct Options: Codable {
        let temperature: Double?
        let topK: Int?
        let topP: Double?
        let numPredict: Int?
        // Add other options as needed from Ollama API docs
    }
}

/// Represents the full response from the /api/generate endpoint (when stream is false).
struct GenerateResponse: Codable {
    let model: String
    let createdAt: String
    let response: String
    let done: Bool
    let totalDuration: Int?
    let loadDuration: Int?
    let promptEvalCount: Int?
    let promptEvalDuration: Int?
    let evalCount: Int?
    let evalDuration: Int?
}

// MARK: - Ollama Service and Error Handling

/// Custom error type for Ollama API interactions.
enum OllamaError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case invalidHTTPResponse(Int)
    case decodingError(Error)
    case encodingError(Error)
    case apiError(String) // For errors reported by the Ollama API itself

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "The Ollama API URL is invalid."
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .invalidHTTPResponse(let statusCode):
            return "Ollama API returned an unexpected status code: \(statusCode)"
        case .decodingError(let error):
            return "Failed to decode Ollama response: \(error.localizedDescription)"
        case .encodingError(let error):
            return "Failed to encode request body: \(error.localizedDescription)"
        case .apiError(let message):
            return "Ollama API Error: \(message)"
        }
    }
}

/// Service class to interact with the local Ollama instance.
class OllamaService {
    private let baseURLString = "http://localhost:11434"
    private let session: URLSession

    init(session: URLSession = .shared) {
        self.session = session
    }

    /// Generates a response from Ollama for a given prompt and model.
    /// - Parameters:
    ///   - prompt: The text prompt to send to the AI.
    ///   - model: The name of the Ollama model to use (e.g., "llama3").
    ///   - temperature: Optional generation temperature.
    /// - Returns: A `GenerateResponse` object containing the AI's full reply.
    /// - Throws: `OllamaError` if the request fails or decoding is unsuccessful.
    func generateResponse(
        prompt: String,
        model: String,
        temperature: Double? = nil
    ) async throws -> GenerateResponse {
        guard let url = URL(string: "\(baseURLString)/api/generate") else {
            throw OllamaError.invalidURL
        }

        var requestBody = GenerateRequest(
            model: model,
            prompt: prompt,
            stream: false, // Important: Set to false for a single, complete response
            options: temperature != nil ? GenerateRequest.Options(temperature: temperature) : nil
        )

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase // Ollama often uses snake_case
            urlRequest.httpBody = try encoder.encode(requestBody)
        } catch {
            throw OllamaError.encodingError(error)
        }

        let (data, response) = try await session.data(for: urlRequest)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw OllamaError.networkError(URLError(.badServerResponse))
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            // Attempt to decode an error message from the response if available
            if let apiError = try? JSONDecoder().decode(OllamaAPIError.self, from: data) {
                throw OllamaError.apiError(apiError.error)
            }
            throw OllamaError.invalidHTTPResponse(httpResponse.statusCode)
        }

        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase // Ollama often uses snake_case
            return try decoder.decode(GenerateResponse.self, from: data)
        } catch {
            throw OllamaError.decodingError(error)
        }
    }
}

// Helper struct to decode potential API error messages from Ollama
struct OllamaAPIError: Codable {
    let error: String
}

// MARK: - Example Usage (Conceptual UI interaction)

@MainActor
func runBasicGenerationExample() async {
    let ollamaService = OllamaService()
    let prompt = "Write a short, engaging tagline for a new coffee shop called 'The Daily Grind'."
    let model = "llama3" // Ensure this model is pulled locally (e.g., `ollama pull llama3`)

    print("--- Basic AI Text Generation ---")
    print("Prompt: \(prompt)")
    print("Model: \(model)")

    do {
        print("Generating response...")
        let response = try await ollamaService.generateResponse(prompt: prompt, model: model, temperature: 0.7)
        print("\nAI Response:")
        print(response.response)
        print("\nDone: \(response.done)")
        print("Model Used: \(response.model)")
        print("Created At: \(response.createdAt)")
    } catch {
        print("\nError generating response: \(error.localizedDescription)")
        if let ollamaError = error as? OllamaError {
            print("Detailed Error: \(ollamaError.errorDescription ?? "Unknown Ollama Error")")
        }
    }
    print("--------------------------------")
}

// To run this example in a Playground or a Swift application:
// Task {
//     await runBasicGenerationExample()
// }
