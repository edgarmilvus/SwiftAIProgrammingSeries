
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// MARK: - Exercise 2: Local Time Zone Converter Tool

// 1.1. Define TimeZoneConverterTool Arguments
struct TimeZoneConverterArguments: Codable {
    let city: String
}

// 1.2. Create TimeZoneConverterTool
struct TimeZoneConverterTool: Tool {
    let name: String = "time_zone_converter_tool"
    let description: String = "Provides the current local time for a specified city around the world."
    let parametersSchema: String = """
    {
        "type": "object",
        "properties": {
            "city": {
                "type": "string",
                "description": "The name of the city to get the current time for."
            }
        },
        "required": ["city"]
    }
    """

    typealias Arguments = TimeZoneConverterArguments

    func execute(arguments: TimeZoneConverterArguments) async throws -> String {
        // A simple mapping for demonstration. In a real app, this might involve a more robust lookup
        // or a dedicated API for city-to-timezone conversion.
        let timeZoneIdentifier: String
        switch arguments.city.lowercased() {
        case "london":
            timeZoneIdentifier = "Europe/London"
        case "new york", "new_york":
            timeZoneIdentifier = "America/New_York"
        case "tokyo":
            timeZoneIdentifier = "Asia/Tokyo"
        case "sydney":
            timeZoneIdentifier = "Australia/Sydney"
        case "paris":
            timeZoneIdentifier = "Europe/Paris"
        default:
            // Attempt to use the city name directly as an identifier if it matches a known one
            if let tz = TimeZone(identifier: arguments.city) {
                timeZoneIdentifier = arguments.city
            } else {
                throw ToolError.timeZoneNotFound(arguments.city)
            }
        }

        guard let timeZone = TimeZone(identifier: timeZoneIdentifier) else {
            throw ToolError.timeZoneNotFound(arguments.city)
        }

        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = timeZone
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .long

        let currentTime = Date()
        let formattedTime = dateFormatter.string(from: currentTime)

        return "The current time in \(arguments.city) is \(formattedTime)."
    }
}

// 2. Simulate LLM Interaction & Tool Execution
func runExercise2() async {
    print("\n--- Running Exercise 2: Local Time Zone Converter Tool ---")

    let mockToolCallJSONLondon = """
    {
        "toolName": "time_zone_converter_tool",
        "arguments": "{\\"city\\": \\"London\\"}"
    }
    """
    let mockToolCallJSONNewYork = """
    {
        "toolName": "time_zone_converter_tool",
        "arguments": "{\\"city\\": \\"New York\\"}"
    }
    """
    let mockToolCallJSONUnknownCity = """
    {
        "toolName": "time_zone_converter_tool",
        "arguments": "{\\"city\\": \\"Mars\\"}"
    }
    """

    let registry = ToolRegistry()
    registry.registerTool(TimeZoneConverterTool())

    do {
        print("\nScenario 1: Successful Time Conversion (London)")
        let result = try await processLLMResponse(toolCallJSON: mockToolCallJSONLondon, registry: registry)
        print("Final Result: \(result)")
    } catch {
        print("Error in Scenario 1: \(error.localizedDescription)")
    }

    do {
        print("\nScenario 2: Successful Time Conversion (New York)")
        let result = try await processLLMResponse(toolCallJSON: mockToolCallJSONNewYork, registry: registry)
        print("Final Result: \(result)")
    } catch {
        print("Error in Scenario 2: \(error.localizedDescription)")
    }

    do {
        print("\nScenario 3: Unknown City Error")
        _ = try await processLLMResponse(toolCallJSON: mockToolCallJSONUnknownCity, registry: registry)
    } catch {
        print("Error in Scenario 3: \(error.localizedDescription)")
    }
}
