
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct ActionItem: Codable {
    let description: String
    let assignee: String?
    let dueDate: Date?
}

@available(iOS 18.0, macOS 15.0, *)
struct DiscussionPoint: Codable {
    let topic: String
    let details: String
}

@available(iOS 18.0, macOS 15.0, *)
struct MeetingSummary: Codable {
    let overallSummary: String
    let actionItems: [ActionItem]
    let discussionPoints: [DiscussionPoint]

    // Helper struct to consume a malformed object in a custom init(from decoder:)
    // This allows the container to advance past the problematic element.
    private struct CodableErrorSkipper: Codable {}

    // Custom init(from decoder:) to handle partial failures robustly
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.overallSummary = try container.decode(String.self, forKey: .overallSummary)

        // Custom decoding for actionItems to skip malformed ones
        var decodedActionItems: [ActionItem] = []
        // Check if the key exists before attempting to create a nested container
        if container.contains(.actionItems) {
            var actionItemsArrayContainer = try container.nestedUnkeyedContainer(forKey: .actionItems)
            while !actionItemsArrayContainer.isAtEnd {
                let currentPath = actionItemsArrayContainer.codingPath.map { $0.stringValue }.joined(separator: ".")
                do {
                    let item = try actionItemsArrayContainer.decode(ActionItem.self)
                    decodedActionItems.append(item)
                } catch {
                    print("⚠️ Warning: Could not decode an ActionItem at path '\(currentPath)'. Skipping this item. Error: \(error.localizedDescription)")
                    // Attempt to skip the problematic element by decoding into a dummy Codable type.
                    // This is crucial to advance the container's pointer past the malformed element.
                    // For typical object-level malformations (missing required keys, wrong types within an object),
                    // decoding into an empty struct often works to consume the object.
                    _ = try? actionItemsArrayContainer.decode(CodableErrorSkipper.self)
                }
            }
        }
        self.actionItems = decodedActionItems

        // Custom decoding for discussionPoints to skip malformed ones
        var decodedDiscussionPoints: [DiscussionPoint] = []
        if container.contains(.discussionPoints) {
            var discussionPointsArrayContainer = try container.nestedUnkeyedContainer(forKey: .discussionPoints)
            while !discussionPointsArrayContainer.isAtEnd {
                let currentPath = discussionPointsArrayContainer.codingPath.map { $0.stringValue }.joined(separator: ".")
                do {
                    let point = try discussionPointsArrayContainer.decode(DiscussionPoint.self)
                    decodedDiscussionPoints.append(point)
                } catch {
                    print("⚠️ Warning: Could not decode a DiscussionPoint at path '\(currentPath)'. Skipping this item. Error: \(error.localizedDescription)")
                    _ = try? discussionPointsArrayContainer.decode(CodableErrorSkipper.self)
                }
            }
        }
        self.discussionPoints = decodedDiscussionPoints
    }
}

@available(iOS 18.0, macOS 15.0, *)
func solveExercise4() {
    print("\n--- Exercise 4: Feature Request - Smart Meeting Summarizer & Action Item Extractor ---")

    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601 // Configure for ISO 8601 dates

    // Simulate LLM Output 1: Valid MeetingSummary
    let jsonString1 = """
    {
      "overallSummary": "The team discussed Q1 performance and planned for the next sprint. Key takeaways include improving communication channels and defining clear ownership for new features.",
      "actionItems": [
        {
          "description": "Finalize Q1 report",
          "assignee": "Alice",
          "dueDate": "2024-04-05T17:00:00Z"
        },
        {
          "description": "Schedule sprint planning meeting",
          "assignee": "Bob",
          "dueDate": "2024-04-08T10:00:00Z"
        }
      ],
      "discussionPoints": [
        {
          "topic": "Q1 Performance Review",
          "details": "Reviewed sales figures and project completion rates. Identified areas for improvement in onboarding."
        },
        {
          "topic": "Next Sprint Goals",
          "details": "Agreed on core features for the next development cycle."
        }
      ]
    }
    """

    // Simulate LLM Output 2: MeetingSummary with partial failures
    let jsonString2 = """
    {
      "overallSummary": "A complex meeting with some data extraction issues.",
      "actionItems": [
        {
          "description": "Valid action item",
          "assignee": "Charlie",
          "dueDate": "2024-04-10T09:00:00Z"
        },
        {
          "description": "Action item with bad date",
          "assignee": "David",
          "dueDate": "2024/04/12" // Malformed date, will cause decoding error
        },
        {
          "description": "Action item missing assignee and date" // Valid as assignee/dueDate are optional
        },
        {
          // "description": "Action item with missing description" // This would fail if uncommented, as description is not optional
          "assignee": "Eve",
          "dueDate": "2024-04-15T12:00:00Z"
        }
      ],
      "discussionPoints": [
        {
          "topic": "Valid discussion point",
          "details": "Details here."
        },
        {
          "topic": "Discussion point missing details" // Details is not optional, will cause decoding error
        },
        {
          "details": "Discussion point missing topic" // Topic is not optional, will cause decoding error
        }
      ]
    }
    """

    // Decoding Logic for jsonString1 (standard)
    print("\n--- Decoding Valid MeetingSummary (jsonString1) ---")
    if let jsonData = jsonString1.data(using: .utf8) {
        do {
            let summary = try decoder.decode(MeetingSummary.self, from: jsonData)
            print("Successfully decoded MeetingSummary 1:")
            print("  Overall Summary: \(summary.overallSummary)")
            print("  Action Items (\(summary.actionItems.count)):")
            for item in summary.actionItems {
                print("    - \(item.description) (Assignee: \(item.assignee ?? "N/A"), Due: \(item.dueDate?.formatted(date: .abbreviated, time: .shortened) ?? "N/A"))")
            }
            print("  Discussion Points (\(summary.discussionPoints.count)):")
            for point in summary.discussionPoints {
                print("    - Topic: \(point.topic), Details: \(point.details)")
            }
        } catch {
            print("Error decoding MeetingSummary 1: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 1 to Data.")
    }

    // Decoding Logic for jsonString2 (with partial failures, using custom init)
    print("\n--- Decoding MeetingSummary with Partial Failures (jsonString2) ---")
    if let jsonData = jsonString2.data(using: .utf8) {
        do {
            let summary = try decoder.decode(MeetingSummary.self, from: jsonData)
            print("Successfully decoded MeetingSummary 2 with partial resilience:")
            print("  Overall Summary: \(summary.overallSummary)")
            print("  Action Items (\(summary.actionItems.count) successfully parsed):")
            for item in summary.actionItems {
                print("    - \(item.description) (Assignee: \(item.assignee ?? "N/A"), Due: \(item.dueDate?.formatted(date: .abbreviated, time: .shortened) ?? "N/A"))")
            }
            print("  Discussion Points (\(summary.discussionPoints.count) successfully parsed):")
            for point in summary.discussionPoints {
                print("    - Topic: \(point.topic), Details: \(point.details)")
            }
        } catch {
            print("Error decoding MeetingSummary 2 (even with custom init, a top-level error occurred): \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 2 to Data.")
    }
}

// Uncomment to run Exercise 4
// solveExercise4()
