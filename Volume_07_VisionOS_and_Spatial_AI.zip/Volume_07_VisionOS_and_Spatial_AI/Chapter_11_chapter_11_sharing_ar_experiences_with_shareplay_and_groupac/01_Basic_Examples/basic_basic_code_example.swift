
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import GroupActivities
import RealityKit
import Combine

// MARK: - 1. Data Model
/// The data we want to synchronize across the network.
/// It must conform to `Codable` for transmission and `Sendable` for Swift 6 concurrency safety.
struct SpatialObjectState: Codable, Sendable {
    var position: SIMD3<Float>
    var rotation: simd_quatf
    var modelIdentifier: String
}

// MARK: - 2. Group Activity Definition
/// The 'GroupActivity' is the entry point. It defines what the user sees in the SharePlay picker.
@available(iOS 18.0, visionOS 2.0, *)
struct SpatialGalleryActivity: GroupActivity {
    var metadata: GroupActivityMetadata {
        let metadata = GroupActivityMetadata()
        metadata.title = "Spatial Gallery Session"
        metadata.type = .generic
        // In a real app, you would add an icon or cover image here.
        return metadata
    }
}

// MARK: - 3. Session Manager
/// The 'GalleryManager' handles the lifecycle of the GroupSession and the synchronization of data.
/// It is marked with @MainActor because it drives the UI updates.
@available(iOS 18.0, visionOS 2.0, *)
@Observable
@MainActor
class GalleryManager {
    /// The current active session
    var session: GroupSession<SpatialGalleryActivity>?
    
    /// The current state of the shared object
    var sharedState: SpatialObjectState = SpatialObjectState(
        position: [0, 0, -1],
        rotation: simd_quatf(angle: 0, axis: [0, 1, 0]),
        modelIdentifier: "vintage_watch_01"
    )
    
    /// Task to manage the session's async lifecycle
    private var sessionTask: Task<Void, Never>?

    /// Starts a new session as the host.
    func startSession() async {
        do {
            let activity = SpatialGalleryActivity()
            // requestActivity() prompts the system to show the SharePlay invitation UI.
            try await activity.requestActivity()
            
            // End any existing session
            sessionTask?.cancel()
            
            sessionTask = Task {
                // join() or end() are called on the activity to initiate the session.
                // Here we are initiating a session via the activity.
                let newSession = try await activity.join()
                self.session = newSession
                await handleSession(newSession)
            }
        } catch {
            print("Failed to start session: \(error)")
        }
    }

    /// Handles the continuous stream of participant updates and data synchronization.
    private func handleSession(_ session: GroupSession<SpatialGalleryActivity>) async {
        // We use a Task to process the session's async streams without blocking the main thread.
        await withTaskGroup(of: Void.self) { group in
            
            // Task 1: Listen for Participant connections/disconnections
            group.addTask {
                for await participant in session.participants {
                    print("Participant joined/left: \(participant.id)")
                }
            }
            
            // Task 2: Listen for incoming synchronization data
            group.addTask {
                // The synchronization stream provides the real-time data pipe.
                for await incomingState in session.synchronization.updates {
                    // Update the local state with the data received from the network.
                    // Since we are in a Task, we must jump back to the @MainActor to update @Observable properties.
                    await MainActor.run {
                        self.sharedState = incomingState
                    }
                }
            }
        }
    }

    /// Broadcasts the current state to all participants in the session.
    func updateSharedState(newPosition: SIMD3<Float>, newRotation: simd_quatf) {
        guard let session = session else { return }
        
        let newState = SpatialObjectState(
            position: newPosition,
            rotation: newRotation,
            modelIdentifier: sharedState.modelIdentifier
        )
        
        // Update local state immediately for responsiveness (Optimistic UI)
        self.sharedState = newState
        
        // Send the update to the group
        Task {
            do {
                try await session.synchronization.send(newState)
            } catch {
                print("Failed to send update: \(error)")
            }
        }
    }
}

// MARK: - 4. User Interface
@available(iOS 18.0, visionOS 2.0, *)
struct SpatialGalleryView: View {
    @State private var manager = GalleryManager()

    var body: some View {
        VStack(spacing: 20) {
            Text("Spatial Gallery")
                .font(.largeTitle)
            
            if let session = manager.session {
                Text("Connected: \(session.participants.count) participants")
                    .foregroundColor(.green)
                
                // Visual representation of the shared object (Simplified)
                ZStack {
                    Circle()
                        .fill(.blue)
                        .frame(width: 50, height: 50)
                        // In a real RealityKit app, this would be a ModelEntity
                        // positioned using manager.sharedState.position
                        .offset(x: manager.sharedState.position.x * 100, 
                                y: manager.sharedState.position.y * 100)
                }
                .frame(height: 200)

                Button("Move Object Randomly") {
                    let randomPos = SIMD3<Float>(
                        Float.random(in: -1...1),
                        Float.random(in: -1...1),
                        -1
                    )
                    manager.updateSharedState(
                        newPosition: randomPos,
                        newRotation: manager.sharedState.rotation
                    )
                }
            } else {
                Button("Start SharePlay Session") {
                    Task {
                        await manager.startSession()
                    }
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
    }
}
