
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // For @Observable
import CreateML // Assuming CreateML provides MLDataTable and MLModel

// Assume MLProgress and MyModelTrainer from previous examples are available.

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
struct TrainingView: View {
    @State private var trainer: MyModelTrainer?
    @State private var progress: MLProgress?
    @State private var trainedModel: MLModel?
    @State private var isTraining = false
    @State private var errorMessage: String?

    // Example data table (from previous chapters)
    private var dummyDataTable: MLDataTable {
        // In a real app, this would load from a file or network
        // For demonstration, an empty table
        return MLDataTable()
    }

    var body: some View {
        VStack(spacing: 20) {
            Text("Custom Model Training")
                .font(.largeTitle)

            if let progress = progress {
                // Observe the progress object directly using @Observable
                // SwiftUI automatically re-renders when progress properties change.
                ProgressView(value: progress.percentage) {
                    Text("Training Progress: \(Int(progress.percentage * 100))%")
                } currentValueLabel: {
                    VStack {
                        Text("Iteration: \(progress.currentIteration)/\(progress.totalIterations)")
                        if let loss = progress.trainingLoss {
                            Text("Training Loss: \(loss, specifier: "%.4f")")
                        }
                        if let accuracy = progress.accuracy {
                            Text("Accuracy: \(accuracy * 100, specifier: "%.2f")%")
                        }
                        Text("Status: \(statusString(for: progress.status))")
                    }
                }
                .padding()
            } else {
                Text("No training in progress.")
            }

            Button(isTraining ? "Cancel Training" : "Start Training") {
                if isTraining {
                    // In a real scenario, you'd call a cancel method on the trainer or task.
                    // For this example, we'll just reset state.
                    // A proper cancellation would involve the TrainingProgressMonitor actor.
                    Task {
                        // Assuming the actor manages cancellation
                        await monitor.cancelTraining()
                        isTraining = false
                        progress = nil // Clear progress
                        trainedModel = nil // Clear model
                    }
                } else {
                    startTrainingProcess()
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isTraining && progress?.status == .completed) // Disable if already completed

            if let trainedModel = trainedModel {
                Text("Training Completed! Model ready for deployment.")
                    .foregroundStyle(.green)
                // Here, you might show options to export or use the model
            }

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundStyle(.red)
            }
        }
        .padding()
        .task {
            // Initialize the trainer when the view appears
            trainer = MyModelTrainer(dataSource: dummyDataTable)
        }
    }

    // Using an @StateObject for the actor to persist across view updates
    @StateObject private var monitor = TrainingProgressMonitor(initialProgress: MLProgress())

    private func startTrainingProcess() {
        guard let trainer = trainer else {
            errorMessage = "Trainer not initialized."
            return
        }

        isTraining = true
        errorMessage = nil
        trainedModel = nil

        // Assign the actor's progress object to the view's state
        // This is safe because MLProgress is @Observable
        progress = monitor.currentProgress

        Task {
            do {
                // Start training via the actor
                try await monitor.startTraining(trainer: trainer, epochs: 10)
                let finalModel = try await monitor.waitForCompletion()
                trainedModel = finalModel
                isTraining = false
            } catch {
                errorMessage = error.localizedDescription
                isTraining = false
            }
        }
    }

    private func statusString(for status: MLProgress.Status) -> String {
        switch status {
        case .notStarted: return "Not Started"
        case .running: return "Running"
        case .paused: return "Paused"
        case .cancelled: return "Cancelled"
        case .completed: return "Completed"
        case .failed(let error): return "Failed: \(error.localizedDescription)"
        }
    }
}
