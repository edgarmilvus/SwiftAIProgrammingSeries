
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// An actor responsible for all SwiftData persistence operations related to chat conversations.
/// Using an Actor ensures thread-safe access to the ModelContext and prevents race conditions
/// when multiple concurrent tasks (e.g., UI updates, AI streaming) interact with the database.
@available(iOS 18.0, *)
actor ChatPersistenceActor {
    enum PersistenceError: Error, LocalizedError {
        case conversationNotFound(UUID)
        case messageNotFound(UUID)
        case saveFailed(Error)
        case contextInitializationFailed(Error)

        var errorDescription: String? {
            switch self {
            case .conversationNotFound(let id): return "Conversation with ID \(id) not found."
            case .messageNotFound(let id): return "Message with ID \(id) not found."
            case .saveFailed(let error): return "Failed to save changes: \(error.localizedDescription)"
            case .contextInitializationFailed(let error): return "Failed to initialize ModelContext: \(error.localizedDescription)"
            }
        }
    }

    private let modelContainer: ModelContainer
    private let modelContext: ModelContext // Dedicated context for the actor

    /// Initializes the ChatPersistenceActor with a shared ModelContainer.
    /// - Parameter modelContainer: The ModelContainer instance to use for creating the actor's ModelContext.
    init(modelContainer: ModelContainer) throws {
        self.modelContainer = modelContainer
        self.modelContext = ModelContext(modelContainer)
        // Ensure the context is set to automatically save changes, or we can manually call save()
        self.modelContext.autosaveEnabled = true
        print("ChatPersistenceActor initialized with its own ModelContext.")
    }

    /// Creates and persists a new conversation.
    /// - Returns: The newly created Conversation object.
    /// - Throws: `PersistenceError.saveFailed` if the conversation cannot be saved.
    func createConversation() async throws -> Conversation {
        let conversation = Conversation()
        modelContext.insert(conversation)
        do {
            try modelContext.save() // Explicit save for immediate persistence
            print("Created new conversation: \(conversation.id)")
            return conversation
        } catch {
            throw PersistenceError.saveFailed(error)
        }
    }

    /// Adds a new message to an existing conversation.
    /// - Parameters:
    ///   - conversationID: The UUID of the conversation to add the message to.
    ///   - content: The text content of the message.
    ///   - sender: The sender of the message (user, AI, or system).
    ///   - status: The initial status of the message. Defaults to `.completed`.
    /// - Returns: The newly created Message object.
    /// - Throws: `PersistenceError.conversationNotFound` if the conversation ID is invalid,
    ///           or `PersistenceError.saveFailed` if the message cannot be saved.
    func addMessage(to conversationID: UUID, content: String, sender: MessageSender, status: MessageStatus = .completed) async throws -> Message {
        guard let conversation = try modelContext.fetch(FetchDescriptor<Conversation>(predicate: #Predicate { $0.id == conversationID })).first else {
            throw PersistenceError.conversationNotFound(conversationID)
        }

        let message = Message(content: content, sender: sender, status: status)
        conversation.messages?.append(message)
        message.conversation = conversation // Establish inverse relationship
        modelContext.insert(message) // Explicitly insert the new message

        do {
            try modelContext.save() // Explicit save
            print("Added message to conversation \(conversationID): \(message.id) - '\(content)'")
            return message
        } catch {
            throw PersistenceError.saveFailed(error)
        }
    }

    /// Updates the content of an existing message. This is crucial for streaming AI responses.
    /// - Parameters:
    ///   - messageID: The UUID of the message to update.
    ///   - newContent: The new content to append or set.
    ///   - newStatus: An optional new status for the message.
    /// - Throws: `PersistenceError.messageNotFound` if the message ID is invalid,
    ///           or `PersistenceError.saveFailed` if the update cannot be saved.
    func updateMessageContent(messageID: UUID, newContent: String, newStatus: MessageStatus? = nil) async throws {
        guard let message = try modelContext.fetch(FetchDescriptor<Message>(predicate: #Predicate { $0.id == messageID })).first else {
            throw PersistenceError.messageNotFound(messageID)
        }

        message.content = newContent
        if let newStatus {
            message.status = newStatus
        }

        // With autosaveEnabled = true, changes are typically saved automatically
        // when the transaction finishes or after a delay.
        // For critical updates, an explicit save can be performed, but might impact performance
        // if called too frequently during streaming.
        // For streaming, SwiftData's autosave is often sufficient, relying on the actor's
        // serial execution to keep updates consistent.
        do {
            try modelContext.save() // Explicit save to ensure immediate update visibility
            print("Updated message \(messageID): new content length \(newContent.count), status: \(message.status)")
        } catch {
            throw PersistenceError.saveFailed(error)
        }
    }

    /// Updates the status of an existing message.
    /// - Parameters:
    ///   - messageID: The UUID of the message to update.
    ///   - newStatus: The new status for the message.
    /// - Throws: `PersistenceError.messageNotFound` if the message ID is invalid,
    ///           or `PersistenceError.saveFailed` if the update cannot be saved.
    func updateMessageStatus(messageID: UUID, newStatus: MessageStatus) async throws {
        guard let message = try modelContext.fetch(FetchDescriptor<Message>(predicate: #Predicate { $0.id == messageID })).first else {
            throw PersistenceError.messageNotFound(messageID)
        }
        message.status = newStatus
        do {
            try modelContext.save()
            print("Updated message \(messageID) status to \(newStatus)")
        } catch {
            throw PersistenceError.saveFailed(error)
        }
    }

    /// Fetches all conversations.
    /// - Returns: An array of Conversation objects.
    func fetchAllConversations() async throws -> [Conversation] {
        let descriptor = FetchDescriptor<Conversation>(sortBy: [SortDescriptor(\.createdAt, order: .reverse)])
        return try modelContext.fetch(descriptor)
    }

    /// Fetches a specific conversation by its ID.
    /// - Parameter id: The UUID of the conversation to fetch.
    /// - Returns: The Conversation object, or nil if not found.
    func fetchConversation(id: UUID) async throws -> Conversation? {
        let descriptor = FetchDescriptor<Conversation>(predicate: #Predicate { $0.id == id })
        return try modelContext.fetch(descriptor).first
    }

    /// Deletes a specific conversation by its ID.
    /// - Parameter id: The UUID of the conversation to delete.
    /// - Throws: `PersistenceError.conversationNotFound` if the conversation ID is invalid,
    ///           or `PersistenceError.saveFailed` if the deletion fails.
    func deleteConversation(id: UUID) async throws {
        guard let conversation = try modelContext.fetch(FetchDescriptor<Conversation>(predicate: #Predicate { $0.id == id })).first else {
            throw PersistenceError.conversationNotFound(id)
        }
        modelContext.delete(conversation)
        do {
            try modelContext.save()
            print("Deleted conversation: \(id)")
        } catch {
            throw PersistenceError.saveFailed(error)
        }
    }
}
