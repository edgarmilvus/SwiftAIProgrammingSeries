
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CoreVideo

/// Protocol defining the requirements for a style transfer model.
protocol StyleTransferModel: Sendable {
    var name: String { get }
    func applyEffect(to buffer: CVPixelBuffer) async throws -> CVPixelBuffer
}

// MARK: - Mock Implementations
struct LargeModel: StyleTransferModel {
    let name = "StyleTransfer_Large (Float16)"
    func applyEffect(to buffer: CVPixelBuffer) async throws -> CVPixelBuffer {
        try await Task.sleep(nanoseconds: 30_000_000) // 30ms (Heavy)
        return buffer
    }
}

struct MediumModel: StyleTransferModel {
    let name = "StyleTransfer_Medium (Quantized)"
    func applyEffect(to buffer: CVPixelBuffer) async throws -> CVPixelBuffer {
        try await Task.sleep(nanoseconds: 16_000_000) // 16ms (Balanced)
        return buffer
    }
}

struct TinyModel: StyleTransferModel {
    let name = "StyleTransfer_Tiny (Int8)"
    func applyEffect(to buffer: CVPixelBuffer) async throws -> CVPixelBuffer {
        try await Task.sleep(nanoseconds: 8_000_000) // 8ms (Light)
        return buffer
    }
}

// MARK: - Orchestrator
actor ModelOrchestrator {
    
    private var activeModel: any StyleTransferModel
    private var loadingModel: (any StyleTransferModel)?
    
    // Hysteresis logic
    private var lastUpgradeTime: Date = .distantPast
    private let upgradeThreshold: TimeInterval = 10.0 // 10 seconds
    
    init(initialModel: any StyleTransferModel) {
        self.activeModel = initialModel
    }
    
    /// The main entry point for the video render loop.
    func requestNextFrame(input: CVPixelBuffer) async throws -> CVPixelBuffer {
        let targetModel = determineRequiredModel()
        
        // Check if we need to switch models
        if type(of: activeModel) != type(of: targetModel) {
            await handleModelSwitch(to: targetModel)
        }
        
        // Use the current active model (even if a new one is loading in the background)
        return try await activeModel.applyEffect(to: input)
    }
    
    private func determineRequiredModel() -> any StyleTransferModel {
        let state = ProcessInfo.processInfo.thermalState
        
        switch state {
        case .nominal:
            // Hysteresis: Only upgrade if it's been cool for 10 seconds
            if Date().timeIntervalSince(lastUpgradeTime) > upgradeThreshold {
                return LargeModel()
            } else {
                // Stay at current or lower to prevent "flapping"
                return (activeModel is LargeModel) ? activeModel : MediumModel()
            }
        case .fair:
            return MediumModel()
        case .serious, .critical:
            return TinyModel()
        @unknown default:
            return TinyModel()
        }
    }
    
    private func handleModelSwitch(to targetModel: any StyleTransferModel) async {
        // If we are already loading this specific model, do nothing
        if let loading = loadingModel, type(of: loading) == type(of: targetModel) {
            return
        }
        
        print("Thermal change detected. Preparing \(targetModel.name) in background...")
        
        // DOUBLE BUFFERING STRATEGY:
        // We do NOT replace activeModel immediately. 
        // We load the new model into 'loadingModel' while the 'activeModel' 
        // continues to process the current video stream.
        
        let modelToLoad = targetModel
        
        // Simulate asynchronous I/O and model loading
        Task {
            // In a real app, this is where MLModel(contentsOf:) happens
            try? await Task.sleep(nanoseconds: 500_000_000) // 0.5s loading
            await self.finalizeModelSwap(newModel: modelToLoad)
        }
        
        // Update the upgrade time if we are moving towards a higher fidelity
        if targetModel is LargeModel {
            lastUpgradeTime = Date()
        }
    }
    
    private func finalizeModelSwap(newModel: any StyleTransferModel) {
        print("Swapping to \(newModel.name)")
        self.activeModel = newModel
        self.loadingModel = nil
    }
}
