
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor AIManager {
    private var textGenerator: TextGenerator // Hypothetical Apple Intelligence model API

    init() {
        // Initialize the text generator, potentially loading a model
        self.textGenerator = TextGenerator() // This might be an async operation in a real scenario
    }

    func generateText(prompt: String) async throws -> String {
        // This operation could be on-device or routed to PCC
        // The Apple Intelligence framework handles the compute location
        let result = try await textGenerator.generate(prompt: prompt)
        return result.text // Assuming a result object with a text property
    }

    func summarizeDocument(url: URL) async throws -> String {
        // More complex task, likely involving PCC for larger documents
        let documentContent = try String(contentsOf: url) // Potentially async file read
        let summary = try await textGenerator.summarize(document: documentContent)
        return summary.text
    }
}

@available(iOS 18.0, *)
class MyViewModel: ObservableObject {
    private let aiManager = AIManager()
    @Published var generatedText: String = "Enter prompt..."
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    func requestTextGeneration(prompt: String) {
        isLoading = true
        errorMessage = nil
        Task { // A new Task to perform async work
            do {
                let result = try await aiManager.generateText(prompt: prompt)
                await MainActor.run { // Update UI on the main actor
                    self.generatedText = result
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to generate text: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }
}
