
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// MARK: - Model Layer (PetClassifier)

import CoreML
import Vision
import UIKit // For UIImage conversion

// Define a struct for prediction results
struct PredictionResult {
    let identifier: String
    let confidence: Float
}

enum PetClassifierError: Error, LocalizedError {
    case modelLoadingFailed(Error)
    case imageConversionFailed
    case predictionFailed(Error)
    case noResults

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error): return "Failed to load Core ML model: \(error.localizedDescription)"
        case .imageConversionFailed: return "Failed to convert image for prediction."
        case .predictionFailed(let error): return "Core ML prediction failed: \(error.localizedDescription)"
        case .noResults: return "No prediction results found."
        }
    }
}

class PetClassifier {
    private let model: VNCoreMLModel // Use VNCoreMLModel for Vision integration

    init(modelName: String = "AnimalClassifier") throws {
        // First, try to load the compiled .mlmodelc
        guard let url = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            // If .mlmodelc not found, try to find .mlmodel and compile it
            guard let mlmodelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodel") else {
                throw PetClassifierError.modelLoadingFailed(NSError(domain: "PetClassifier", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model file not found: \(modelName).mlmodel or \(modelName).mlmodelc"]))
            }
            do {
                let compiledURL = try MLModel.compileModel(at: mlmodelURL)
                let coreMLModel = try MLModel(contentsOf: compiledURL)
                self.model = try VNCoreMLModel(for: coreMLModel)
            } catch {
                throw PetClassifierError.modelLoadingFailed(error)
            }
            return
        }
        // If .mlmodelc was found, load it directly
        let coreMLModel = try MLModel(contentsOf: url)
        self.model = try VNCoreMLModel(for: coreMLModel)
    }

    // Converts UIImage to CVPixelBuffer and performs prediction
    @available(iOS 18.0, *)
    func classifyImage(_ image: UIImage) async throws -> PredictionResult {
        guard let pixelBuffer = image.toCVPixelBuffer() else {
            throw PetClassifierError.imageConversionFailed
        }

        // Use withCheckedThrowingContinuation to bridge the callback-based Vision API to async/await
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: model) { request, error in
                if let error = error {
                    continuation.resume(throwing: PetClassifierError.predictionFailed(error))
                    return
                }

                guard let observations = request.results as? [VNClassificationObservation],
                      let bestResult = observations.first else {
                    continuation.resume(throwing: PetClassifierError.noResults)
                    return
                }
                continuation.resume(returning: PredictionResult(identifier: bestResult.identifier, confidence: bestResult.confidence))
            }
            request.imageCropAndScaleOption = .centerCrop // Or other appropriate option for the model

            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: PetClassifierError.predictionFailed(error))
            }
        }
    }
}

// Extension to convert UIImage to CVPixelBuffer (re-used from prompt)
extension UIImage {
    func toCVPixelBuffer() -> CVPixelBuffer? {
        let attrs = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA
        ] as CFDictionary
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(self.size.width),
                                         Int(self.size.height),
                                         kCVPixelFormatType_32BGRA,
                                         attrs,
                                         &pixelBuffer)
        guard status == kCVReturnSuccess else {
            return nil
        }

        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pixelData,
                                      width: Int(self.size.width),
                                      height: Int(self.size.height),
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else {
            return nil
        }

        context.translateBy(x: 0, y: self.size.height)
        context.scaleBy(x: 1.0, y: -1.0)

        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

        return pixelBuffer
    }
}


// MARK: - ViewModel Layer

protocol PetIdentifierViewModelDelegate: AnyObject {
    func viewModelDidStartLoading(_ viewModel: PetIdentifierViewModel)
    func viewModelDidFinishLoading(_ viewModel: PetIdentifierViewModel)
    func viewModel(_ viewModel: PetIdentifierViewModel, didUpdatePrediction result: PredictionResult)
    func viewModel(_ viewModel: PetIdentifierViewModel, didEncounterError error: Error)
}

class PetIdentifierViewModel {
    weak var delegate: PetIdentifierViewModelDelegate?
    private let classifier: PetClassifier

    init(classifier: PetClassifier) {
        self.classifier = classifier
    }

    @available(iOS 18.0, *)
    func processImage(_ image: UIImage) {
        // Notify delegate that loading has started
        delegate?.viewModelDidStartLoading(self)

        // Launch an asynchronous task to perform classification
        Task {
            do {
                let result = try await classifier.classifyImage(image)
                // Switch back to MainActor for UI updates via delegate
                await MainActor.run {
                    delegate?.viewModel(self, didUpdatePrediction: result)
                    delegate?.viewModelDidFinishLoading(self)
                }
            } catch {
                // Switch back to MainActor for UI updates via delegate
                await MainActor.run {
                    delegate?.viewModel(self, didEncounterError: error)
                    delegate?.viewModelDidFinishLoading(self)
                }
            }
        }
    }
}

// MARK: - ViewController Layer (Conceptual Implementation)

class PetIdentifierViewController: UIViewController, PetIdentifierViewModelDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var viewModel: PetIdentifierViewModel!
    
    // UI Outlets (simulated)
    let imageView = UIImageView()
    let predictionLabel = UILabel()
    let activityIndicator = UIActivityIndicatorView(style: .large)
    let selectImageButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI() // Setup UI programmatically

        // Initialize PetClassifier and ViewModel
        do {
            let classifier = try PetClassifier() // Assumes AnimalClassifier.mlmodel or .mlmodelc exists
            viewModel = PetIdentifierViewModel(classifier: classifier)
            viewModel.delegate = self
        } catch {
            // Handle model loading error
            print("Failed to initialize classifier: \(error.localizedDescription)")
            predictionLabel.text = "App Error: \(error.localizedDescription)"
            predictionLabel.textColor = .red
            selectImageButton.isEnabled = false // Disable functionality if model fails to load
        }
    }
    
    // MARK: - UI Setup (Programmatic for example)
    private func setupUI() {
        view.backgroundColor = .white
        
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .lightGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        predictionLabel.textAlignment = .center
        predictionLabel.numberOfLines = 0
        predictionLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(predictionLabel)
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        
        selectImageButton.setTitle("Select Image", for: .normal)
        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        selectImageButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImageButton)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),
            
            predictionLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            predictionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            predictionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: predictionLabel.centerYAnchor),
            
            selectImageButton.topAnchor.constraint(equalTo: predictionLabel.bottomAnchor, constant: 20),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.widthAnchor.constraint(equalToConstant: 200),
            selectImageButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    // MARK: - User Actions
    @objc func selectImageTapped(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        if let image = info[.originalImage] as? UIImage {
            imageView.image = image
            if #available(iOS 18.0, *) {
                viewModel.processImage(image)
            } else {
                predictionLabel.text = "iOS 18.0 or later is required for this async operation."
                predictionLabel.textColor = .orange
            }
        }
    }

    // MARK: - PetIdentifierViewModelDelegate
    func viewModelDidStartLoading(_ viewModel: PetIdentifierViewModel) {
        activityIndicator.startAnimating()
        predictionLabel.text = "Classifying..."
        predictionLabel.textColor = .black
    }

    func viewModelDidFinishLoading(_ viewModel: PetIdentifierViewModel) {
        activityIndicator.stopAnimating()
    }

    func viewModel(_ viewModel: PetIdentifierViewModel, didUpdatePrediction result: PredictionResult) {
        predictionLabel.text = "Prediction: \(result.identifier) (\(String(format: "%.2f%%", result.confidence * 100)))"
        predictionLabel.textColor = .systemGreen
    }

    func viewModel(_ viewModel: PetIdentifierViewModel, didEncounterError error: Error) {
        predictionLabel.text = "Error: \(error.localizedDescription)"
        predictionLabel.textColor = .red
    }
}
