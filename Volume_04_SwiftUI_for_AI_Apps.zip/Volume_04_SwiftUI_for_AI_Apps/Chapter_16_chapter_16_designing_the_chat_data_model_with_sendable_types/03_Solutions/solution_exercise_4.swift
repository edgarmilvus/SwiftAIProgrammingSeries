
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// Re-using User and ChatMessage (from Ex1, Ex2, Ex3)
struct User: Identifiable, Hashable, Sendable {
    let id: UUID
    let name: String
    let avatarURL: URL?
}

struct ChatMessage: Identifiable, Sendable {
    let id: UUID
    let sender: User
    let content: String
    let timestamp: Date
    // let attachment: Attachment? // Could be here, but not directly used in AI processing logic
}

// 1. Define AIMessageChunk struct
struct AIMessageChunk: Sendable {
    let text: String
    let isFinal: Bool
    
    // Automatically Sendable as String and Bool are Sendable.
}

// 2. Define AIResponse struct
struct AIResponse: Identifiable, Sendable {
    let id: UUID
    let fullText: String
    let timestamp: Date
    let sender: User // To represent the AI as a sender for consistency
    
    // Automatically Sendable as UUID, String, Date, User are Sendable.
}

// New enum to hold either a user's ChatMessage or an AI's AIResponse in a conversation
enum Message: Identifiable, Sendable {
    case user(ChatMessage)
    case ai(AIResponse)
    
    var id: UUID {
        switch self {
        case .user(let chatMessage): return chatMessage.id
        case .ai(let aiResponse): return aiResponse.id
        }
    }
    
    var timestamp: Date {
        switch self {
        case .user(let chatMessage): return chatMessage.timestamp
        case .ai(let aiResponse): return aiResponse.timestamp
        }
    }
    
    var content: String {
        switch self {
        case .user(let chatMessage): return chatMessage.content
        case .ai(let aiResponse): return aiResponse.fullText
        }
    }
    
    var sender: User {
        switch self {
        case .user(let chatMessage): return chatMessage.sender
        case .ai(let aiResponse): return aiResponse.sender
        }
    }
    
    // Automatically Sendable as ChatMessage and AIResponse are Sendable.
}

// Modified Conversation struct to use the new Message enum
struct Conversation: Identifiable, Sendable {
    let id: UUID
    var participants: [User]
    var messages: [Message] // Now stores Message enum
    var lastUpdated: Date
    var readBy: Set<User.ID>
}


// 3. Create an AIProcessingActor
@available(iOS 18.0, *) // AsyncStream for: .milliseconds requires iOS 16+, but this example uses iOS 18+ for demonstration
actor AIProcessingActor {
    let aiUser = User(id: UUID(uuidString: "00000000-0000-0000-0000-000000000001"), name: "AI Assistant", avatarURL: nil)
    
    func process(message: ChatMessage) async throws -> AsyncStream<AIMessageChunk> {
        return AsyncStream { continuation in
            Task {
                // Simulate AI processing and streaming
                let fullResponse = "Hello \(message.sender.name), I received your message: \"\(message.content)\". I am an AI assistant ready to help you."
                
                for char in fullResponse {
                    let chunk = AIMessageChunk(text: String(char), isFinal: false)
                    continuation.yield(chunk)
                    try? await Task.sleep(for: .milliseconds(50)) // Simulate delay
                }
                
                // Send final chunk
                continuation.yield(AIMessageChunk(text: "", isFinal: true)) // Empty text for final chunk, or could be last char
                continuation.finish()
            }
        }
    }
}

// 4. Extend ConversationManager to handle AI responses
@available(iOS 18.0, *)
actor ConversationManager { // Renamed from ChatViewModelActor for integration with Ex3
    private var conversations: [UUID: Conversation] = [:]
    private let aiProcessor = AIProcessingActor()
    
    // Internal state to track in-progress AI responses
    private var streamingAIResponses: [UUID: String] = [:] // Map conversation ID to current AI text being streamed
    
    // Helper to get or create conversation (similar to Ex3)
    private func getOrCreateConversation(id: UUID, initialSender: User, initialMessage: Message) -> Conversation {
        if var conversation = conversations[id] {
            // Ensure initialSender is in participants
            if !conversation.participants.contains(where: { $0.id == initialSender.id }) {
                conversation.participants.append(initialSender)
            }
            return conversation
        } else {
            let newConversation = Conversation(
                id: id,
                participants: [initialSender],
                messages: [], // Messages will be added by addMessage
                lastUpdated: Date(),
                readBy: []
            )
            conversations[id] = newConversation
            return newConversation
        }
    }
    
    /// Adds a user's message to a conversation and initiates AI processing.
    func sendMessage(_ message: ChatMessage, toConversationId: UUID) async {
        // Add user message to conversation
        var conversation = getOrCreateConversation(id: toConversationId, initialSender: message.sender, initialMessage: .user(message))
        conversation.messages.append(.user(message))
        conversation.lastUpdated = message.timestamp
        conversations[toConversationId] = conversation
        print("ConversationManager: User message '\(message.content)' added to conversation \(toConversationId)")
        
        // Start AI processing for this message
        await processAIResponse(forUserMessage: message, conversationId: toConversationId)
    }
    
    /// Processes the AI response stream and updates the conversation.
    private func processAIResponse(forUserMessage userMessage: ChatMessage, conversationId: UUID) async {
        streamingAIResponses[conversationId] = "" // Initialize streaming text for this conversation
        
        do {
            let stream = try await aiProcessor.process(message: userMessage)
            for await chunk in stream {
                guard var currentText = streamingAIResponses[conversationId] else { return }
                currentText += chunk.text
                streamingAIResponses[conversationId] = currentText // Update in-progress text
                
                // In a real UI, you'd likely publish this streaming text for live updates
                print("ConversationManager: Streaming AI chunk for \(conversationId): \(chunk.text)")
                
                if chunk.isFinal {
                    // Once the stream indicates final, construct the full AIResponse
                    let fullResponseText = currentText
                    let aiResponse = AIResponse(
                        id: UUID(),
                        fullText: fullResponseText,
                        timestamp: Date(),
                        sender: aiProcessor.aiUser // AI's identity
                    )
                    
                    // Add the complete AI response to the conversation
                    if var conversation = conversations[conversationId] {
                        conversation.messages.append(.ai(aiResponse))
                        conversation.lastUpdated = aiResponse.timestamp
                        // Ensure AI is a participant
                        if !conversation.participants.contains(where: { $0.id == aiResponse.sender.id }) {
                            conversation.participants.append(aiResponse.sender)
                        }
                        conversations[conversationId] = conversation
                    }
                    streamingAIResponses.removeValue(forKey: conversationId) // Clear streaming state
                    print("ConversationManager: Final AI response added to conversation \(conversationId): \(fullResponseText)")
                    break // Exit loop as stream is finished
                }
            }
        } catch {
            print("ConversationManager: Error processing AI response for \(conversationId): \(error)")
            streamingAIResponses.removeValue(forKey: conversationId)
        }
    }
    
    // Methods from Ex3, adjusted for Message enum
    func getConversation(id: UUID) -> Conversation? {
        return conversations[id]
    }
    
    func getAllConversations() -> [Conversation] {
        return conversations.values.sorted { $0.lastUpdated > $1.lastUpdated }
    }
    
    func markConversationAsRead(id: UUID, forUser user: User) {
        guard var conversation = conversations[id] else {
            print("ConversationManager: Conversation \(id) not found to mark as read.")
            return
        }
        conversation.readBy.insert(user.id)
        conversations[id] = conversation
        print("ConversationManager: Conversation \(id) marked as read by \(user.name)")
    }
}

// Example Usage
@available(iOS 18.0, *)
func demonstrateAIStreaming() async {
    let manager = ConversationManager()
    let user = User(id: UUID(), name: "Grace", avatarURL: nil)
    let convoId = UUID()
    
    let userMessage = ChatMessage(id: UUID(), sender: user, content: "Tell me about Swift concurrency.", timestamp: Date())
    
    print("--- Sending user message and initiating AI response ---")
    await manager.sendMessage(userMessage, toConversationId: convoId)
    
    // Allow some time for the streaming to complete
    try? await Task.sleep(for: .seconds(2))
    
    if let conversation = await manager.getConversation(id: convoId) {
        print("\n--- Final Conversation State ---")
        for msg in conversation.messages {
            print("[\(msg.sender.name)]: \(msg.content)")
        }
    }
}

// Call to demonstrate
// Task { @MainActor in await demonstrateAIStreaming() } // @MainActor needed for Task.sleep(for:) in older Swift versions, or if calling from UI context
