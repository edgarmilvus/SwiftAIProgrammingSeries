
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import UIKit
import Vision
import CoreGraphics // For CGImage and CGContext
import CoreImage // For CIFilter

// No external Swift Package Manager dependencies are required for this component,
// as it relies solely on Apple's built-in frameworks: UIKit, Vision, CoreGraphics, and CoreImage.

/// An enumeration defining possible errors during the privacy blurring process.
enum PrivacyBlurError: Error, LocalizedError {
    case imageConversionFailed
    case visionRequestFailed(Error)
    case noFacesDetected
    case contextDrawingFailed
    case outputImageCreationFailed
    case ciFilterCreationFailed

    var errorDescription: String? {
        switch self {
        case .imageConversionFailed:
            return "Failed to convert the input UIImage to a format suitable for Vision processing."
        case .visionRequestFailed(let underlyingError):
            return "Vision request failed: \(underlyingError.localizedDescription)"
        case .noFacesDetected:
            return "No faces were detected in the image."
        case .contextDrawingFailed:
            return "Failed to create or draw on the Core Graphics context."
        case .outputImageCreationFailed:
            return "Failed to create the final UIImage from the processed Core Graphics image."
        case .ciFilterCreationFailed:
            return "Failed to create Core Image blur filter."
        }
    }
}

/// A service class responsible for detecting faces in an image and applying a privacy blur
/// to each detected face region.
///
/// This class leverages Apple's Vision framework for robust face detection and Core Graphics
/// and Core Image for efficient image manipulation. It is designed to be used in a real-world
/// photo editing or privacy-enhancement feature within an iOS application.
@available(iOS 17.0, *) // Targeting iOS 17 for modern async/await patterns and Vision APIs.
class PrivacyBlurProcessor {

    /// The intensity of the blur effect. A higher value means a stronger blur.
    let blurRadius: CGFloat

    /// Initializes a new instance of the PrivacyBlurProcessor.
    /// - Parameter blurRadius: The radius for the Gaussian blur effect, in points.
    init(blurRadius: CGFloat = 20.0) {
        self.blurRadius = blurRadius
    }

    /// Processes an input image to automatically detect and blur all faces.
    ///
    /// This is the primary entry point for the privacy blurring feature. It orchestrates
    /// the Vision request and subsequent Core Graphics drawing operations.
    ///
    /// - Parameter image: The `UIImage` to be processed.
    /// - Returns: A new `UIImage` with detected faces blurred.
    /// - Throws: `PrivacyBlurError` if any step in the process fails, providing detailed
    ///           information about the failure.
    func processImageWithPrivacyBlur(image: UIImage) async throws -> UIImage {
        // 1. Prepare the image for Vision processing.
        guard let cgImage = image.cgImage else {
            throw PrivacyBlurError.imageConversionFailed
        }

        // 2. Perform face detection using Vision.
        let observations = try await performFaceDetection(on: cgImage)

        // If no faces are detected, we explicitly throw an error.
        // The calling context can decide to handle this by returning the original image or informing the user.
        guard !observations.isEmpty else {
            throw PrivacyBlurError.noFacesDetected
        }

        // 3. Apply blur to detected face regions using Core Graphics and Core Image.
        let blurredImage = try applyBlurToFaces(in: image, faceObservations: observations)

        return blurredImage
    }

    /// Executes a `VNDetectFaceRectanglesRequest` on the given `CGImage`.
    ///
    /// This function handles the asynchronous execution of the Vision request
    /// and extracts the `VNFaceObservation` results. It uses `withCheckedThrowingContinuation`
    /// to bridge the completion handler-based Vision API to Swift's `async/await`.
    ///
    /// - Parameter cgImage: The `CGImage` on which to perform face detection.
    /// - Returns: An array of `VNFaceObservation` objects, each representing a detected face.
    /// - Throws: `PrivacyBlurError.visionRequestFailed` if the Vision request encounters an error.
    private func performFaceDetection(on cgImage: CGImage) async throws -> [VNFaceObservation] {
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNDetectFaceRectanglesRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: PrivacyBlurError.visionRequestFailed(error))
                    return
                }

                guard let observations = request.results as? [VNFaceObservation] else {
                    // If results are nil or not the expected type, treat as no faces found.
                    continuation.resume(returning: [])
                    return
                }
                continuation.resume(returning: observations)
            }

            // A VNImageRequestHandler is used to perform Vision requests on a specific image.
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            do {
                try handler.perform([request])
            } catch {
                // Catch errors from `handler.perform` itself.
                continuation.resume(throwing: PrivacyBlurError.visionRequestFailed(error))
            }
        }
    }

    /// Applies a Gaussian blur effect to specific regions of an image corresponding to face observations.
    ///
    /// This method creates a new image context, draws the original image, and then for each
    /// face, it extracts the region, applies a blur using `CIGaussianBlur`, and draws the
    /// blurred region back onto the context. This process carefully manages coordinate
    /// system conversions between Vision, Core Image, and Core Graphics/UIKit.
    ///
    /// - Parameters:
    ///   - originalImage: The original `UIImage`.
    ///   - faceObservations: An array of `VNFaceObservation` indicating the face locations.
    /// - Returns: A new `UIImage` with the specified face regions blurred.
    /// - Throws: `PrivacyBlurError.contextDrawingFailed` or `PrivacyBlurError.outputImageCreationFailed`.
    private func applyBlurToFaces(in originalImage: UIImage, faceObservations: [VNFaceObservation]) throws -> UIImage {
        guard let cgImage = originalImage.cgImage else {
            throw PrivacyBlurError.imageConversionFailed
        }

        let imagePixelWidth = cgImage.width
        let imagePixelHeight = cgImage.height
        let imageScale = originalImage.scale

        // UIGraphicsBeginImageContextWithOptions creates a Core Graphics context.
        // The size is in points, and the scale determines the pixel density.
        UIGraphicsBeginImageContextWithOptions(originalImage.size, false, imageScale)
        guard let context = UIGraphicsGetCurrentContext() else {
            throw PrivacyBlurError.contextDrawingFailed
        }

        // Draw the original image onto the context first.
        originalImage.draw(at: .zero)

        for observation in faceObservations {
            // 1. Convert Vision's normalized bounding box to image pixel coordinates.
            // Vision's (0,0) is bottom-left. VNImageRectForNormalizedRect converts to
            // pixel coordinates with a top-left origin, suitable for CGImage.
            let pixelRect = VNImageRectForNormalizedRect(observation.boundingBox, imagePixelWidth, imagePixelHeight)

            // 2. Convert the pixel rectangle to UIKit's point coordinates for drawing in the UIGraphics context.
            let rectInPoints = CGRect(
                x: pixelRect.origin.x / imageScale,
                y: pixelRect.origin.y / imageScale,
                width: pixelRect.width / imageScale,
                height: pixelRect.height / imageScale
            )

            // 3. Prepare for Core Image processing.
            // Create a CIImage from the original CGImage. CIImage uses pixel coordinates with a bottom-left origin.
            let ciImage = CIImage(cgImage: cgImage)

            // Create a CIGaussianBlur filter.
            guard let filter = CIFilter(name: "CIGaussianBlur") else {
                throw PrivacyBlurError.ciFilterCreationFailed
            }
            filter.setValue(ciImage, forKey: kCIInputImageKey)
            filter.setValue(blurRadius, forKey: kCIInputRadiusKey)

            // 4. Crop the blurred CIImage to the face region.
            // Adjust the pixelRect from top-left origin (CGImage) to bottom-left origin (CIImage).
            let ciCropRect = CGRect(
                x: pixelRect.origin.x,
                y: CGFloat(imagePixelHeight) - pixelRect.origin.y - pixelRect.height,
                width: pixelRect.width,
                height: pixelRect.height
            )
            let croppedBlurredImage = filter.outputImage?.cropped(to: ciCropRect)

            guard let finalBlurredCIImage = croppedBlurredImage else {
                continue // Skip this face if blur/crop fails for some reason.
            }

            // 5. Convert the processed CIImage back to CGImage for drawing in the UIGraphics context.
            let ciContext = CIContext() // A CIContext is used to render CIImages into CGImages.
            guard let blurredCGImage = ciContext.createCGImage(finalBlurredCIImage, from: finalBlurredCIImage.extent) else {
                continue // Skip this face if conversion fails.
            }

            // 6. Draw the blurred region on top of the original image in the Core Graphics context.
            // `rectInPoints` ensures the blurred region is drawn at the correct location and size in the context.
            context.draw(blurredCGImage, in: rectInPoints)
        }

        // 7. Get the final UIImage from the context.
        guard let finalImage = UIGraphicsGetImageFromCurrentImageContext() else {
            UIGraphicsEndImageContext()
            throw PrivacyBlurError.outputImageCreationFailed
        }

        UIGraphicsEndImageContext() // Clean up the graphics context.
        return finalImage
    }
}
