
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreData
import CloudKit
import Observation

// MARK: - Data Model Simulation
/// In a real project, 'KnowledgeInsight' would be an entity defined in your .xcdatamodeld file.
/// For this example, we assume the existence of an entity with:
/// - title: String
/// - content: String
/// - timestamp: Date
/// - vectorEmbedding: Data (for semantic search)

@available(iOS 18.0, macOS 15.0, *)
/// The PersistenceController manages the Core Data stack and the CloudKit synchronization engine.
/// It is implemented as an actor-like singleton to ensure thread-safe access to the container.
final class PersistenceController {
    /// The shared instance used throughout the app.
    static let shared = PersistenceController()

    /// The persistent container that handles both local storage and CloudKit syncing.
    let container: NSPersistentCloudKitContainer

    /// Initializes the container and configures the CloudKit synchronization parameters.
    init(inMemory: Bool = false) {
        // 1. Initialize the container with the name of your .xcdatamodeld file
        container = NSPersistentCloudKitContainer(name: "KnowledgeVault")

        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }

        // 2. Configure the CloudKit Store Description
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve persistent store description.")
        }

        // Enable remote change notifications. This is critical! 
        // It tells Core Data to listen for changes pushed from iCloud by other devices.
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        // Enable history tracking. CloudKit sync requires history tracking to 
        // determine what has changed since the last sync event.
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)

        // 3. Set the CloudKit Container Identifier
        // Ensure this matches the 'iCloud.com.yourcompany.KnowledgeVault' ID in your Entitlements.
        description.cloudKitContainerOptions = NSPersistentCloudKitContainerOptions(
            containerIdentifier: "iCloud.com.example.KnowledgeVault"
        )

        // 4. Load the persistent stores
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                /*
                 Typical reasons for error:
                 - The CloudKit container ID is incorrect.
                 - The 'CloudKit' capability hasn't been added in Xcode.
                 - The schema in the CloudKit Dashboard doesn't match the local model.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }

        // 5. Configure the viewContext for UI-driven applications
        // Automatically merges changes from parent contexts (like the sync engine) into the view context.
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        // Set the merge policy to prioritize the in-memory version in case of conflicts.
        // In a production AI app, you might implement a custom merge policy for vector data.
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }
}

// MARK: - ViewModel Layer

@available(iOS 18.0, macOS 15.0, *)
/// `KnowledgeManager` acts as the bridge between the Core Data stack and the SwiftUI view.
/// It uses the `@Observable` macro for modern, efficient state management.
@Observable
final class KnowledgeManager {
    /// The managed object context used for performing data operations on the main thread.
    private let context: NSManagedObjectContext
    
    /// The list of insights retrieved from the persistent store.
    /// In a real app, this would be populated via a @Query or a manual fetch request.
    var insights: [KnowledgeInsight] = []

    /// Initializes the manager with a specific context.
    /// - Parameter context: The context to use (usually the viewContext).
    init(context: NSManagedObjectContext) {
        self.context = context
        fetchInsights()
    }

    /// Fetches all insights from the store, ordered by timestamp.
    func fetchInsights() {
        let request = NSFetchRequest<KnowledgeInsight>(entityName: "KnowledgeInsight")
        request.sortDescriptors = [NSSortDescriptor(keyPath: \KnowledgeInsight.timestamp, ascending: false)]
        
        do {
            insights = try context.fetch(request)
        } catch {
            print("Fetch failed: \(error.localizedDescription)")
        }
    }

    /// Adds a new insight to the local store. 
    /// Because CloudKit sync is enabled, this will automatically trigger an upload to iCloud.
    /// - Parameters:
    ///   - title: The summary of the insight.
    ///   - content: The detailed text.
    func addInsight(title: String, content: String) {
        // Perform the save on the MainActor to ensure UI safety.
        Task { @MainActor in
            let newInsight = KnowledgeInsight(context: context)
            newInsight.title = title
            newInsight.content = content
            newInsight.timestamp = Date()
            
            // In an AI context, you would generate the vector embedding here.
            // newInsight.vectorEmbedding = await AIModel.generateEmbedding(for: content)

            saveContext()
        }
    }

    /// Persists changes to the underlying store.
    private func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
                // Refresh the local list to reflect the newly saved object.
                fetchInsights()
            } catch {
                let nserror = error as NSError
                print("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

// MARK: - UI Layer

@available(iOS 18.0, macOS 15.0, *)
struct KnowledgeListView: View {
    /// The manager instance, passed in from the App struct.
    @State var manager: KnowledgeManager
    @State private var showingAddSheet = false
    @State private var newTitle = ""
    @State private var newContent = ""

    var body: some View {
        NavigationStack {
            List(manager.insights, id: \.self) { insight in
                VStack(alignment: .leading) {
                    Text(insight.title ?? "Untitled")
                        .font(.headline)
                    Text(insight.content ?? "")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
            }
            .navigationTitle("AI Memory")
            .toolbar {
                Button(action: { showingAddSheet.toggle() }) {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showingAddSheet) {
                NavigationStack {
                    Form {
                        TextField("Title", text: $newTitle)
                        TextEditor(text: $newContent)
                            .frame(minHeight: 100)
                    }
                    .navigationTitle("New Insight")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") { showingAddSheet = false }
                        }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Save") {
                                manager.addInsight(title: newTitle, content: newContent)
                                newTitle = ""
                                newContent = ""
                                showingAddSheet = false
                            }
                        }
                    }
                }
            }
        }
    }
}

// MARK: - App Entry Point

@main
struct KnowledgeVaultApp: App {
    /// The persistence controller is initialized once at app launch.
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            // We pass the manager initialized with the viewContext.
            KnowledgeListView(manager: KnowledgeManager(context: persistenceController.container.viewContext))
        }
    }
}
