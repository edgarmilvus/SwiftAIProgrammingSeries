
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation // For TextGenerator and related types
import UIKit      // For UI elements

// Define hypothetical API for iOS 18.1+ model configuration
// In a real scenario, these would be provided by the framework.
@available(iOS 18.1, *)
enum SummarizationStyle {
    case concise
    case detailed
}

@available(iOS 18.1, *)
extension TextGenerationRequest.Options {
    // Hypothetical initializer or property to set summarization style
    // This is a placeholder for how Apple might extend TextGenerationRequest.Options
    // to allow more granular control over summarization in iOS 18.1+.
    init(summarizationStyle: SummarizationStyle? = nil,
         maximumTokenCount: Int? = nil,
         temperature: Double? = nil) {
        self.init(maximumTokenCount: maximumTokenCount, temperature: temperature)
        // In a real API, the summarizationStyle would be passed to the underlying model
        // configuration object, e.g., self.modelConfiguration = .init(style: summarizationStyle)
        // For this exercise, we'll just conceptually use it to illustrate the idea.
    }
}


// The class itself can be available from iOS 18.0, but its internal logic adapts.
class ArticleSummarizerViewController: UIViewController {

    // MARK: - UI Elements

    private lazy var articleTextView: UITextView = {
        let textView = UITextView()
        textView.font = .preferredFont(forTextStyle: .body)
        textView.text = "Paste a long article here to summarize. This is a placeholder text to demonstrate the functionality. In a real app, users would input their own content. The summarization will adapt based on the iOS version, offering more control on iOS 18.1 and later."
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 0.5
        textView.layer.cornerRadius = 5
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    private lazy var summarizeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Summarize Article", for: .normal)
        button.addTarget(self, action: #selector(summarizeArticle), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private lazy var summaryLabel: UILabel = {
        let label = UILabel()
        label.text = "Summary will appear here."
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // This UI element is conditionally visible based on OS version
    private lazy var styleSegmentedControl: UISegmentedControl = {
        let segmentedControl = UISegmentedControl(items: ["Concise", "Detailed"])
        segmentedControl.selectedSegmentIndex = 0 // Default to concise
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        return segmentedControl
    }()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        configureUIForAvailability()
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Research Assistant"

        view.addSubview(articleTextView)
        view.addSubview(styleSegmentedControl) // Add but hide conditionally
        view.addSubview(summarizeButton)
        view.addSubview(summaryLabel)

        NSLayoutConstraint.activate([
            articleTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            articleTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            articleTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            articleTextView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3),

            styleSegmentedControl.topAnchor.constraint(equalTo: articleTextView.bottomAnchor, constant: 20),
            styleSegmentedControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            styleSegmentedControl.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            styleSegmentedControl.heightAnchor.constraint(equalToConstant: 40),

            summarizeButton.topAnchor.constraint(equalTo: styleSegmentedControl.bottomAnchor, constant: 20),
            summarizeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            summarizeButton.widthAnchor.constraint(equalToConstant: 200),
            summarizeButton.heightAnchor.constraint(equalToConstant: 50),

            summaryLabel.topAnchor.constraint(equalTo: summarizeButton.bottomAnchor, constant: 40),
            summaryLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            summaryLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            summaryLabel.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    private func configureUIForAvailability() {
        // Conditionally show/hide the segmented control based on OS version
        if #available(iOS 18.1, *) {
            styleSegmentedControl.isHidden = false
        } else {
            styleSegmentedControl.isHidden = true
            // Adjust constraints if needed, or simply rely on it being hidden
            // For this example, we'll keep the constraints active but hidden.
        }
    }

    // MARK: - Adaptive Summarization Logic

    @objc private func summarizeArticle() {
        view.endEditing(true) // Dismiss keyboard

        guard let articleText = articleTextView.text, !articleText.isEmpty else {
            presentAlert(title: "Input Required", message: "Please paste an article to summarize.")
            return
        }

        summaryLabel.text = "Summarizing article..."
        summarizeButton.isEnabled = false

        Task {
            do {
                var request: TextGenerationRequest

                // Use conditional compilation to adapt API usage
                if #available(iOS 18.1, *) {
                    // This block is only compiled and executed on iOS 18.1 and later.
                    let selectedStyle: SummarizationStyle = styleSegmentedControl.selectedSegmentIndex == 0 ? .concise : .detailed

                    // Hypothetical API usage: TextGenerationRequest.Options might be extended
                    // to accept a model configuration or a specific summarization style.
                    let options = TextGenerationRequest.Options(
                        summarizationStyle: selectedStyle, // Using the hypothetical extension
                        maximumTokenCount: selectedStyle == .concise ? 100 : 250, // Adjust length based on style
                        temperature: 0.5
                    )
                    request = TextGenerationRequest(
                        prompt: "Summarize the following article \(selectedStyle == .detailed ? "in detail" : "concisely"): \(articleText)",
                        options: options
                    )
                    print("Using iOS 18.1+ advanced summarization.")
                } else {
                    // Fallback for iOS 18.0
                    // This block is compiled for iOS 18.0 and earlier.
                    request = TextGenerationRequest(
                        prompt: "Summarize the following article: \(articleText)",
                        options: .init(maximumTokenCount: 150, temperature: 0.5) // Standard length
                    )
                    print("Using iOS 18.0 standard summarization.")
                }

                let response = try await TextGenerator.shared.generate(request)

                await MainActor.run {
                    self.summaryLabel.text = response.text
                }
            } catch {
                await MainActor.run {
                    self.presentAlert(title: "Summarization Failed", message: "Error: \(error.localizedDescription)")
                    self.summaryLabel.text = "Failed to summarize article."
                }
            }
            await MainActor.run {
                self.summarizeButton.isEnabled = true
            }
        }
    }

    // MARK: - Helper

    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
