
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import Accelerate

@available(iOS 18.0, *)
struct TenantContext: Sendable {
    let tenantID: UUID
    let workspaceID: UUID?
}

@available(iOS 18.0, *)
struct MockSemanticChunk: Sendable {
    let id: UUID
    let tenantID: UUID
    let workspaceID: UUID
    let embedding: [Float]
    let text: String
}

@available(iOS 18.0, *)
actor SemanticSearchEngine {
    private var storage: [MockSemanticChunk] = []
    
    func insert(chunk: MockSemanticChunk) {
        storage.append(chunk)
    }
    
    func search(
        query: [Float],
        context: TenantContext,
        limit: Int
    ) async -> [MockSemanticChunk] {
        // 1. Pre-filtering (The Guardrail)
        // We narrow the search space BEFORE doing heavy math.
        let filteredSubset = storage.filter { chunk in
            let matchesTenant = chunk.tenantID == context.tenantID
            if let workspaceID = context.workspaceID {
                return matchesTenant && chunk.workspaceID == workspaceID
            }
            return matchesTenant
        }
        
        guard !filteredSubset.isEmpty else { return [] }
        
        // 2. Similarity Calculation (The Heavy Lifting)
        // We map the filtered subset to their similarity scores.
        let scoredResults = filteredSubset.map { chunk -> (chunk: MockSemanticChunk, score: Float) in
            let similarity = cosineSimilarity(query, chunk.embedding)
            return (chunk, similarity)
        }
        
        // 3. Sort and Limit
        return scoredResults
            .sorted { $0.score > $1.score }
            .prefix(limit)
            .map { $0.chunk }
    }
    
    /// High-performance Cosine Similarity using Accelerate
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count, !a.isEmpty else { return 0.0 }
        
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        var normA: Float = 0
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        
        var normB: Float = 0
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        
        let magnitude = sqrt(normA) * sqrt(normB)
        return magnitude > 0 ? dotProduct / magnitude : 0.0
    }
}
