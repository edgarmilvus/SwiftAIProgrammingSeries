/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// components/BenchmarkTool.tsx
import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { storage } from '../lib/storage';

export const BenchmarkTool = () => {
  const [results, setResults] = useState({
    mmkvWrite: 0,
    asyncWrite: 0,
    mmkvRead: 0,
    asyncRead: 0,
  });
  const [loading, setLoading] = useState(false);

  const runBenchmarks = async () => {
    setLoading(true);
    const count = 1000;
    const keys = Array.from({ length: count }, (_, i) => `key_${i}`);
    const value = 'test_value_for_benchmarking'; 

    // --- MMKV Benchmark ---
    const mmkvWriteStart = performance.now();
    keys.forEach(key => {
      storage.set(key, value);
    });
    const mmkvWriteEnd = performance.now();

    const mmkvReadStart = performance.now();
    keys.forEach(key => {
      storage.getString(key);
    });
    const mmkvReadEnd = performance.now();

    // --- AsyncStorage Benchmark ---
    // Note: AsyncStorage is async, so we use a loop for sequential writes
    const asyncWriteStart = performance.now();
    for (const key of keys) {
      await AsyncStorage.setItem(key, value);
    }
    const asyncWriteEnd = performance.now();

    const asyncReadStart = performance.now();
    for (const key of keys) {
      await AsyncStorage.getItem(key);
    }
    const asyncReadEnd = performance.now();

    setResults({
      mmkvWrite: mmkvWriteEnd - mmkvWriteStart,
      asyncWrite: asyncWriteEnd - asyncWriteStart,
      mmkvRead: mmkvReadEnd - mmkvReadStart,
      asyncRead: asyncReadEnd - asyncReadStart,
    });
    setLoading(false);
  };

  return (
    <View style={styles.container}>
      <Button title="Run Benchmarks (1000 ops)" onPress={runBenchmarks} disabled={loading} />
      
      {loading ? (
        <ActivityIndicator size="large" style={{ marginTop: 20 }} />
      ) : (
        <View style={styles.results}>
          <Text style={styles.header}>Performance Results (ms)</Text>
          <Text>MMKV Write: {results.mmkvWrite.toFixed(2)} ms</Text>
          <Text>AsyncStorage Write: {results.asyncWrite.toFixed(2)} ms</Text>
          <Text>MMKV Read: {results.mmkvRead.toFixed(2)} ms</Text>
          <Text>AsyncStorage Read: {results.asyncRead.toFixed(2)} ms</Text>
          
          <View style={styles.analysis}>
            <Text style={styles.analysisHeader}>Analysis:</Text>
            <Text>
              MMKV is significantly faster because it uses memory-mapping (mmap) to access data directly from memory, 
              avoiding the overhead of serialization/deserialization and disk I/O serialization required by AsyncStorage 
              (which uses SQLite under the hood). Reads and writes in MMKV are essentially pointer operations in memory.
            </Text>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, flex: 1 },
  results: { marginTop: 20 },
  header: { fontWeight: 'bold', fontSize: 18, marginBottom: 10 },
  analysis: { marginTop: 15, padding: 10, backgroundColor: '#f0f0f0', borderRadius: 5 },
  analysisHeader: { fontWeight: 'bold', marginBottom: 5 },
});
