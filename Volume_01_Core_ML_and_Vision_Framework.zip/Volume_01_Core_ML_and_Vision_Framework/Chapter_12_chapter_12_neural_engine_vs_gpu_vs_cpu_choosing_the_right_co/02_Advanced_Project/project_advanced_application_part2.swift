
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AVFoundation
import Vision
import CoreML
import os.log // For structured logging

// MARK: - 1. Define Compute Unit Strategy

/// Represents the available compute units for Core ML inference.
/// This enum makes it easy to switch between different strategies.
enum ComputeUnitStrategy: String, CaseIterable, Identifiable {
    case neuralEngine = "Neural Engine (ANE)"
    case gpu = "GPU"
    case cpu = "CPU"

    var id: String { self.rawValue }

    /// Converts the strategy to the corresponding MLComputeUnit.
    var coreMLComputeUnit: MLComputeUnit {
        switch self {
        case .neuralEngine: return .neuralEngine
        case .gpu: return .cpuAndGPU // Core ML often combines CPU and GPU for GPU tasks
        case .cpu: return .cpuOnly
        }
    }
}

// MARK: - 2. ML Inference Manager (Actor for thread safety)

/// An actor responsible for loading and managing Core ML models configured for different compute units.
/// It ensures thread-safe access to model instances and provides methods for dynamic switching.
@available(iOS 17.0, *) // Requires modern async/await features
actor DynamicMLInferenceManager {
    private let modelName: String
    private var coreMLModels: [ComputeUnitStrategy: VNCoreMLModel] = [:]
    private var currentStrategy: ComputeUnitStrategy = .neuralEngine {
        didSet {
            os_log("Compute unit strategy changed to: %{PUBLIC}s", log: .default, type: .info, currentStrategy.rawValue)
        }
    }

    /// Initializes the manager with the name of the Core ML model.
    /// - Parameter modelName: The base name of the .mlmodelc file (e.g., "ObjectDetector").
    init(modelName: String) {
        self.modelName = modelName
    }

    /// Asynchronously loads the Core ML model for all supported compute unit strategies.
    /// This pre-loads models to avoid latency during runtime switching.
    func loadModels() async throws {
        for strategy in ComputeUnitStrategy.allCases {
            os_log("Attempting to load model for %{PUBLIC}s...", log: .default, type: .debug, strategy.rawValue)
            let config = MLModelConfiguration()
            config.computeUnit = strategy.coreMLComputeUnit

            guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
                os_log("Failed to find model '%{PUBLIC}s.mlmodelc' in bundle.", log: .default, type: .error, modelName)
                throw InferenceError.modelNotFound(modelName)
            }

            do {
                let coreMLModel = try await MLModel.load(contentsOf: modelURL, configuration: config)
                let visionModel = try VNCoreMLModel(for: coreMLModel)
                self.coreMLModels[strategy] = visionModel
                os_log("Successfully loaded model for %{PUBLIC}s.", log: .default, type: info, strategy.rawValue)
            } catch {
                os_log("Failed to load model for %{PUBLIC}s: %{PUBLIC}s", log: .default, type: .error, strategy.rawValue, error.localizedDescription)
                // Depending on criticality, we might throw or just log and continue.
                // For a robust app, we should ensure at least one strategy works.
                throw InferenceError.modelLoadingFailed(strategy, error)
            }
        }
    }

    /// Sets the active compute unit strategy.
    /// - Parameter newStrategy: The desired compute unit strategy.
    func setStrategy(_ newStrategy: ComputeUnitStrategy) {
        self.currentStrategy = newStrategy
    }

    /// Returns the VNCoreMLRequest configured for the current strategy.
    /// - Returns: A VNCoreMLRequest instance.
    /// - Throws: `InferenceError.modelNotLoaded` if the model for the current strategy hasn't been loaded.
    func getCurrentVisionRequest() throws -> VNCoreMLRequest {
        guard let visionModel = coreMLModels[currentStrategy] else {
            os_log("Vision model for current strategy %{PUBLIC}s not loaded.", log: .default, type: .error, currentStrategy.rawValue)
            throw InferenceError.modelNotLoaded(currentStrategy)
        }
        let request = VNCoreMLRequest(model: visionModel) { request, error in
            // Handle Vision request results (detections) in the delegate or completion handler
            // For this example, the completion handler is passed to the caller.
        }
        // Configure common request properties (e.g., imageCropAndScaleOption)
        request.imageCropAndScaleOption = .centerCrop
        return request
    }

    /// Returns the currently active compute unit strategy.
    func getActiveStrategy() -> ComputeUnitStrategy {
        return currentStrategy
    }

    /// Custom error types for the inference manager.
    enum InferenceError: Error, LocalizedError {
        case modelNotFound(String)
        case modelLoadingFailed(ComputeUnitStrategy, Error)
        case modelNotLoaded(ComputeUnitStrategy)
        case visionRequestFailed(Error)

        var errorDescription: String? {
            switch self {
            case .modelNotFound(let name):
                return "Core ML model '\(name).mlmodelc' not found in app bundle."
            case .modelLoadingFailed(let strategy, let underlyingError):
                return "Failed to load Core ML model for \(strategy.rawValue): \(underlyingError.localizedDescription)"
            case .modelNotLoaded(let strategy):
                return "Vision model for \(strategy.rawValue) has not been loaded."
            case .visionRequestFailed(let error):
                return "Vision request failed: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - 3. & 4. & 5. Camera Feed Processor

/// A class that manages the AVCaptureSession, processes video frames,
/// and performs ML inference using the DynamicMLInferenceManager.
/// It also reports inference performance.
@available(iOS 17.0, *)
class CameraFeedProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoOutputQueue = DispatchQueue(label: "com.example.camera.videoOutputQueue", qos: .userInitiated)
    private var previewLayer: AVCaptureVideoPreviewLayer?

    private let inferenceManager: DynamicMLInferenceManager
    private var lastInferenceTime: CFAbsoluteTime = 0

    /// A closure to report detected objects and performance metrics.
    var onDetectedObjects: (([VNRecognizedObjectObservation], ComputeUnitStrategy, TimeInterval) -> Void)?
    /// A closure to report errors.
    var onError: ((Error) -> Void)?

    /// Initializes the camera feed processor.
    /// - Parameter inferenceManager: The manager responsible for ML models.
    init(inferenceManager: DynamicMLInferenceManager) {
        self.inferenceManager = inferenceManager
        super.init()
    }

    /// Sets up the AVCaptureSession for video input.
    /// - Parameter previewView: The UIView to display the camera preview.
    /// - Throws: `AVCaptureSetupError` if camera setup fails.
    func setupCamera(in previewView: UIView) async throws {
        session.beginConfiguration()
        defer { session.commitConfiguration() }

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            throw AVCaptureSetupError.noCameraAvailable
        }

        let videoInput = try AVCaptureDeviceInput(device: videoDevice)
        guard session.canAddInput(videoInput) else {
            throw AVCaptureSetupError.cannotAddInput
        }
        session.addInput(videoInput)

        // Configure video output
        videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        guard session.canAddOutput(videoOutput) else {
            throw AVCaptureSetupError.cannotAddOutput
        }
        session.addOutput(videoOutput)

        // Set up preview layer
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.frame = previewView.bounds
        previewView.layer.addSublayer(previewLayer)
        self.previewLayer = previewLayer

        // Ensure video orientation matches device orientation
        if let connection = videoOutput.connection, connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait // Or determine dynamically
        }

        os_log("AVCaptureSession setup complete.", log: .default, type: .info)
    }

    /// Starts the camera session.
    func startSession() {
        videoOutputQueue.async { [weak self] in
            self?.session.startRunning()
            os_log("AVCaptureSession started.", log: .default, type: .info)
        }
    }

    /// Stops the camera session.
    func stopSession() {
        videoOutputQueue.async { [weak self] in
            self?.session.stopRunning()
            os_log("AVCaptureSession stopped.", log: .default, type: .info)
        }
    }

    /// Delegate method called when a new video frame is available.
    /// - Parameters:
    ///   - output: The AVCaptureVideoDataOutput that produced the sample buffer.
    ///   - sampleBuffer: The CMSampleBuffer containing the video frame.
    ///   - connection: The AVCaptureConnection that generated the sample buffer.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            os_log("Failed to get CVPixelBuffer from sample buffer.", log: .default, type: .error)
            return
        }

        // Use a Task for asynchronous Vision processing to avoid blocking the camera queue
        Task {
            do {
                let currentStrategy = await inferenceManager.getActiveStrategy()
                let request = try await inferenceManager.getCurrentVisionRequest()

                let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
                
                let startTime = CFAbsoluteTimeGetCurrent()
                try handler.perform([request])
                let inferenceDuration = CFAbsoluteTimeGetCurrent() - startTime

                guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                    os_log("Vision request did not return VNRecognizedObjectObservation results.", log: .default, type: .warning)
                    return
                }

                // Report results back to the main thread or a dedicated UI queue
                await MainActor.run {
                    self.onDetectedObjects?(observations, currentStrategy, inferenceDuration)
                }
                os_log("Inference completed on %{PUBLIC}s in %f ms.", log: .default, type: .debug, currentStrategy.rawValue, inferenceDuration * 1000)

            } catch let error as DynamicMLInferenceManager.InferenceError {
                os_log("Inference Manager Error: %{PUBLIC}s", log: .default, type: .error, error.localizedDescription)
                await MainActor.run { self.onError?(error) }
            } catch {
                os_log("Vision processing error: %{PUBLIC}s", log: .default, type: .error, error.localizedDescription)
                await MainActor.run { self.onError?(error) }
            }
        }
    }

    /// Errors specific to AVCaptureSession setup.
    enum AVCaptureSetupError: Error, LocalizedError {
        case noCameraAvailable
        case cannotAddInput
        case cannotAddOutput

        var errorDescription: String? {
            switch self {
            case .noCameraAvailable: return "No suitable camera device found."
            case .cannotAddInput: return "Could not add camera input to session."
            case .cannotAddOutput: return "Could not add video output to session."
            }
        }
    }
}

// MARK: - Example Usage (Conceptual UI Integration)

/// This class would typically be a UIViewController managing the camera and ML inference.
@available(iOS 17.0, *)
class CameraViewController: UIViewController {
    private let cameraPreviewView = UIView()
    private let inferenceManager = DynamicMLInferenceManager(modelName: "ObjectDetector") // Replace with your model name
    private var cameraProcessor: CameraFeedProcessor!

    private let strategyPicker = UISegmentedControl(items: ComputeUnitStrategy.allCases.map { $0.rawValue })
    private let statusLabel = UILabel()
    private let performanceLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        cameraProcessor = CameraFeedProcessor(inferenceManager: inferenceManager)
        cameraProcessor.onDetectedObjects = { [weak self] observations, strategy, duration in
            self?.updateDetectionOverlay(observations)
            self?.performanceLabel.text = String(format: "Unit: %@, Latency: %.2f ms", strategy.rawValue, duration * 1000)
        }
        cameraProcessor.onError = { [weak self] error in
            self?.statusLabel.text = "Error: \(error.localizedDescription)"
            os_log("CameraVC received error: %{PUBLIC}s", log: .default, type: .error, error.localizedDescription)
        }

        Task {
            do {
                // Load models for all compute units upfront
                try await inferenceManager.loadModels()
                os_log("All ML models loaded successfully.", log: .default, type: .info)
                
                // Set initial strategy, e.g., Neural Engine if available
                await inferenceManager.setStrategy(.neuralEngine)
                strategyPicker.selectedSegmentIndex = ComputeUnitStrategy.allCases.firstIndex(of: .neuralEngine) ?? 0

                // Setup and start camera
                try await cameraProcessor.setupCamera(in: cameraPreviewView)
                cameraProcessor.startSession()
                statusLabel.text = "Camera Ready (Neural Engine)"
            } catch {
                statusLabel.text = "Initialization Error: \(error.localizedDescription)"
                os_log("CameraVC initialization error: %{PUBLIC}s", log: .default, type: .error, error.localizedDescription)
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Ensure preview layer resizes with view
        if let previewLayer = cameraPreviewView.layer.sublayers?.first(where: { $0 is AVCaptureVideoPreviewLayer }) as? AVCaptureVideoPreviewLayer {
            previewLayer.frame = cameraPreviewView.bounds
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        cameraProcessor.stopSession()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        cameraPreviewView.backgroundColor = .black
        cameraPreviewView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cameraPreviewView)

        strategyPicker.translatesAutoresizingMaskIntoConstraints = false
        strategyPicker.selectedSegmentIndex = 0 // Default to first option
        strategyPicker.addTarget(self, action: #selector(computeUnitChanged), for: .valueChanged)
        view.addSubview(strategyPicker)

        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.textColor = .white
        statusLabel.textAlignment = .center
        statusLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        statusLabel.numberOfLines = 0
        view.addSubview(statusLabel)
        
        performanceLabel.translatesAutoresizingMaskIntoConstraints = false
        performanceLabel.textColor = .yellow
        performanceLabel.textAlignment = .center
        performanceLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(performanceLabel)

        NSLayoutConstraint.activate([
            cameraPreviewView.topAnchor.constraint(equalTo: view.topAnchor),
            cameraPreviewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            cameraPreviewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            cameraPreviewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            strategyPicker.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            strategyPicker.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            strategyPicker.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            strategyPicker.heightAnchor.constraint(equalToConstant: 40),

            statusLabel.bottomAnchor.constraint(equalTo: performanceLabel.topAnchor, constant: -5),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 30),
            
            performanceLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            performanceLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            performanceLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            performanceLabel.heightAnchor.constraint(equalToConstant: 30)
        ])
    }

    @objc private func computeUnitChanged(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        let newStrategy = ComputeUnitStrategy.allCases[selectedIndex]
        Task {
            await inferenceManager.setStrategy(newStrategy)
            await MainActor.run {
                self.statusLabel.text = "Switching to \(newStrategy.rawValue)..."
            }
        }
    }

    /// Placeholder for drawing bounding boxes. In a real app, this would draw on a CALayer or UIView.
    private func updateDetectionOverlay(_ observations: [VNRecognizedObjectObservation]) {
        // Clear previous detections (example: remove all sublayers from a dedicated overlay view)
        cameraPreviewView.layer.sublayers?.filter { $0.name == "DetectionBox" }.forEach { $0.removeFromSuperlayer() }

        let previewLayer = self.previewLayer! // Assuming previewLayer is set
        let viewRect = previewLayer.bounds

        for observation in observations {
            // Transform Vision coordinates (normalized) to view coordinates
            let boundingBox = VNImageRectForNormalizedRect(observation.boundingBox, Int(viewRect.width), Int(viewRect.height))

            let shapeLayer = CAShapeLayer()
            shapeLayer.name = "DetectionBox"
            shapeLayer.frame = boundingBox
            shapeLayer.borderColor = UIColor.red.cgColor
            shapeLayer.borderWidth = 2.0
            shapeLayer.cornerRadius = 4.0

            let textLayer = CATextLayer()
            textLayer.string = "\(observation.labels.first?.identifier ?? "Unknown") (\(String(format: "%.2f", observation.confidence)))"
            textLayer.font = UIFont.systemFont(ofSize: 12)
            textLayer.fontSize = 12
            textLayer.foregroundColor = UIColor.white.cgColor
            textLayer.backgroundColor = UIColor.red.withAlphaComponent(0.7).cgColor
            textLayer.frame = CGRect(x: boundingBox.origin.x, y: boundingBox.origin.y - 20, width: boundingBox.width, height: 20)
            textLayer.contentsScale = UIScreen.main.scale // Important for high-res text

            DispatchQueue.main.async { // Ensure UI updates on main thread
                self.cameraPreviewView.layer.addSublayer(shapeLayer)
                self.cameraPreviewView.layer.addSublayer(textLayer)
            }
        }
    }
}
