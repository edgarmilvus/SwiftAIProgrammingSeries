
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreML // Included for context, though not strictly used for FE itself here.

// MARK: - Data Structures

/// Represents the raw, untransformed activity data logged by a user.
struct RawActivityData {
    let activityType: String // e.g., "Walking", "Running", "Sleeping"
    let durationMinutes: Double // e.g., 30.0, 60.0
    let timeOfDay: String // e.g., "Morning", "Afternoon", "Evening"
}

/// Represents the engineered features, ready to be fed into a machine learning model.
/// For simplicity, we'll use a dictionary here, but often this would be an MLMultiArray
/// or a specific `MLFeatureProvider` implementation.
struct EngineeredFeatures {
    let features: [String: Double]
}

// MARK: - Feature Engineering Logic

/// A utility class for performing feature engineering on RawActivityData.
class FeatureEngineer {

    // MARK: - Configuration for Feature Engineering

    // Define all possible categories for One-Hot Encoding.
    // In a real application, these would typically be derived from the training dataset.
    private let possibleActivityTypes: Set<String> = ["Walking", "Running", "Sleeping", "Eating", "Working"]
    private let possibleTimesOfDay: Set<String> = ["Morning", "Afternoon", "Evening", "Night"]

    // Define min/max for Min-Max Scaling.
    // These values MUST be derived from the training data to prevent data leakage.
    // For this basic example, we're hardcoding them for demonstration purposes.
    private let minDurationMinutes: Double = 0.0
    private let maxDurationMinutes: Double = 120.0 // Assuming max logged duration is 2 hours

    // MARK: - Public API

    /// Engineers features from raw activity data into a format suitable for a ML model.
    /// - Parameter rawData: The raw `RawActivityData` logged by the user.
    /// - Returns: An `EngineeredFeatures` struct containing a dictionary of transformed features.
    ///            Returns nil if essential configuration (like maxDuration) is invalid.
    func engineerFeatures(from rawData: RawActivityData) -> EngineeredFeatures? {
        var engineered: [String: Double] = [:]

        // 1. One-Hot Encoding for 'activityType'
        // Creates a binary feature for each possible activity type.
        for type in possibleActivityTypes {
            engineered["activityType_\(type)"] = (rawData.activityType == type) ? 1.0 : 0.0
        }

        // 2. One-Hot Encoding for 'timeOfDay'
        // Creates a binary feature for each possible time of day.
        for time in possibleTimesOfDay {
            engineered["timeOfDay_\(time)"] = (rawData.timeOfDay == time) ? 1.0 : 0.0
        }

        // 3. Min-Max Scaling for 'durationMinutes'
        // Scales a numerical feature to a fixed range, typically [0, 1].
        // Formula: (value - min) / (max - min)
        // This helps prevent features with larger numerical ranges from dominating the model.
        if maxDurationMinutes <= minDurationMinutes {
            print("Error: maxDurationMinutes must be greater than minDurationMinutes for scaling.")
            return nil // Indicate failure due to invalid configuration
        }
        let scaledDuration = (rawData.durationMinutes - minDurationMinutes) / (maxDurationMinutes - minDurationMinutes)
        engineered["duration_scaled"] = max(0.0, min(1.0, scaledDuration)) // Clamp to [0, 1] range

        return EngineeredFeatures(features: engineered)
    }
}

// MARK: - Application Entry Point (Simulated Usage)

/// Main entry point for demonstrating the feature engineering process.
@main
@available(iOS 18.0, macOS 15.0, *) // Using @main for a standalone executable example
struct HealthTrackerApp {
    static func main() {
        print("--- Health Tracker App: Feature Engineering Demo ---")

        let featureEngineer = FeatureEngineer()

        // Example 1: User logs a morning walk
        let rawActivity1 = RawActivityData(activityType: "Walking", durationMinutes: 45.0, timeOfDay: "Morning")
        print("\nRaw Data 1: \(rawActivity1)")
        if let engineeredFeatures1 = featureEngineer.engineerFeatures(from: rawActivity1) {
            print("Engineered Features 1:")
            engineeredFeatures1.features.sorted(by: { $0.key < $1.key }).forEach { key, value in
                print("  \(key): \(value)")
            }
        } else {
            print("Failed to engineer features for Raw Data 1.")
        }

        // Example 2: User logs an afternoon run (duration near max)
        let rawActivity2 = RawActivityData(activityType: "Running", durationMinutes: 110.0, timeOfDay: "Afternoon")
        print("\nRaw Data 2: \(rawActivity2)")
        if let engineeredFeatures2 = featureEngineer.engineerFeatures(from: rawActivity2) {
            print("Engineered Features 2:")
            engineeredFeatures2.features.sorted(by: { $0.key < $1.key }).forEach { key, value in
                print("  \(key): \(value)")
            }
        } else {
            print("Failed to engineer features for Raw Data 2.")
        }

        // Example 3: User logs an activity not in our predefined list (unseen category)
        let rawActivity3 = RawActivityData(activityType: "Gardening", durationMinutes: 60.0, timeOfDay: "Evening")
        print("\nRaw Data 3: \(rawActivity3)")
        if let engineeredFeatures3 = featureEngineer.engineerFeatures(from: rawActivity3) {
            print("Engineered Features 3:")
            engineeredFeatures3.features.sorted(by: { $0.key < $1.key }).forEach { key, value in
                print("  \(key): \(value)")
            }
            // Notice how 'activityType_Gardening' is NOT present, and all 'activityType_' features are 0.0
            // This is a common pitfall: handling unseen categories.
        } else {
            print("Failed to engineer features for Raw Data 3.")
        }

        // Example 4: Duration outside expected range (will be clamped)
        let rawActivity4 = RawActivityData(activityType: "Sleeping", durationMinutes: 150.0, timeOfDay: "Night")
        print("\nRaw Data 4: \(rawActivity4)")
        if let engineeredFeatures4 = featureEngineer.engineerFeatures(from: rawActivity4) {
            print("Engineered Features 4:")
            engineeredFeatures4.features.sorted(by: { $0.key < $1.key }).forEach { key, value in
                print("  \(key): \(value)")
            }
        } else {
            print("Failed to engineer features for Raw Data 4.")
        }
    }
}
