
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// Swift 6
@available(iOS 18.0, macOS 15.0, *)
actor ConversationAgentActor {
    private let llmClient: LLMClientActor
    private var conversationHistory: [String] = []
    private let maxHistoryTurns: Int // Max number of user+AI turns to remember

    init(llmClient: LLMClientActor, maxHistoryTurns: Int = 3) { // Default to 3 turns
        self.llmClient = llmClient
        self.maxHistoryTurns = maxHistoryTurns
    }

    /// Processes a user message, updates history, and gets an LLM response.
    func processMessage(userMessage: String) async throws -> String {
        // Add user message to history
        conversationHistory.append("User: \(userMessage)")
        trimHistory()

        // Construct context for the LLM from the current history
        let fullContext = conversationHistory.joined(separator: "\n") + "\nAI:"
        print("ConversationAgentActor: Sending context to LLM:\n\(fullContext)")

        // Get response from LLM
        let llmResponse = try await llmClient.sendPrompt(text: fullContext)

        // Add LLM response to history
        conversationHistory.append("AI: \(llmResponse)")
        trimHistory()
        
        return llmResponse
    }

    /// Clears the conversation history.
    func clearHistory() {
        conversationHistory = []
        print("ConversationAgentActor: History cleared.")
    }

    /// Trims the conversation history to `maxHistoryTurns`.
    private func trimHistory() {
        // Each "turn" consists of a user message and an AI response.
        // So, if maxHistoryTurns is 3, we want to keep up to 6 entries.
        let desiredHistorySize = maxHistoryTurns * 2
        if conversationHistory.count > desiredHistorySize {
            let startIndex = conversationHistory.count - desiredHistorySize
            conversationHistory = Array(conversationHistory[startIndex...])
        }
    }
}

// Example Usage (e.g., from an updated ViewModel)
@available(iOS 18.0, macOS 15.0, *)
class AdvancedChatViewModel: ObservableObject {
    @Published var currentPrompt: String = ""
    @Published var chatLog: String = "Start your conversation...\n"
    
    private let conversationAgent: ConversationAgentActor

    init() {
        let llmService = LLMService() // Re-using LLMService from Exercise 1
        let llmClient = LLMClientActor(llmService: llmService) // Re-using LLMClientActor
        self.conversationAgent = ConversationAgentActor(llmClient: llmClient, maxHistoryTurns: 3)
    }

    func submitPrompt() {
        let promptToSend = currentPrompt
        currentPrompt = ""
        
        Task {
            await MainActor.run {
                self.chatLog += "User: \(promptToSend)\n"
            }
            do {
                let response = try await conversationAgent.processMessage(userMessage: promptToSend)
                await MainActor.run {
                    self.chatLog += "AI: \(response)\n"
                }
            } catch {
                await MainActor.run {
                    self.chatLog += "Error: \(error.localizedDescription)\n"
                }
            }
        }
    }
    
    func clearConversation() {
        Task {
            await conversationAgent.clearHistory() // Actor method call
            await MainActor.run {
                self.chatLog = "Start your conversation...\n"
            }
        }
    }
}
