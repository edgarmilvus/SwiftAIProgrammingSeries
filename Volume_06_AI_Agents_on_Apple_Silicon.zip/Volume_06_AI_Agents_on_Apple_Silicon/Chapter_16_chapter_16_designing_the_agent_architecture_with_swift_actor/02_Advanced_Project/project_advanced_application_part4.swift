
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

/// `DocumentProcessingActor` is responsible for handling document-related operations,
/// such as simulating OCR and extracting textual content.
/// It isolates the state and logic for document processing, preventing race conditions.
actor DocumentProcessingActor {
    private var processedDocuments: [UUID: DocumentContent] = [:]

    /// Simulates scanning and OCR for a given raw document input.
    /// - Parameter rawDocumentData: A string representing the raw content of the document.
    /// - Returns: A `DocumentContent` object containing the extracted text.
    /// - Throws: `AgentError.documentProcessingFailed` if the simulation fails.
    func processDocument(rawDocumentData: String) async throws -> DocumentContent {
        print("[\(Date().formatted(date: .omitted, time: .standard))] DocumentProcessingActor: Starting document processing...")
        // Simulate a computationally intensive OCR process
        try await Task.sleep(for: .seconds(Double.random(in: 0.5...1.5)))

        guard !rawDocumentData.isEmpty else {
            throw AgentError.documentProcessingFailed(reason: "Input document data is empty.")
        }

        // In a real app, this would involve OCR frameworks like VisionKit or third-party libraries.
        let extractedText = "Extracted text content from document: \"\(rawDocumentData.prefix(100))...\""
        let newDocument = DocumentContent(
            id: UUID(),
            rawText: extractedText,
            pageCount: Int.random(in: 1...10),
            processedTimestamp: Date()
        )

        self.processedDocuments[newDocument.id] = newDocument
        print("[\(Date().formatted(date: .omitted, time: .standard))] DocumentProcessingActor: Finished processing document \(newDocument.id.uuidString.prefix(8))...")
        return newDocument
    }
}
