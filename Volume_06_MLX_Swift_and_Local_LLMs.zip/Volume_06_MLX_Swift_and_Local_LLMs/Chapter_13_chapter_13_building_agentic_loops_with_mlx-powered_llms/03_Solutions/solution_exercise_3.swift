
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import Foundation

// MARK: - Agent State

@available(iOS 18.0, macOS 15.0, *)
enum SummarizerAgentState {
    case initializing, summarizing, critiquing, finished, failed
}

// MARK: - Self-Correcting Summarizer Agent

@available(iOS 18.0, macOS 15.0, *)
class SelfCorrectingSummarizerAgent {
    let chatModel: MLXChatModel // Reusing the model from Exercise 1
    
    init(chatModel: MLXChatModel) {
        self.chatModel = chatModel
    }
    
    /// Runs the self-correcting summarization agent.
    /// - Parameters:
    ///   - documentText: The full text of the document to summarize.
    ///   - maxIterations: Maximum number of summary/critique cycles.
    /// - Returns: The final, refined summary.
    /// - Throws: An error if the process fails.
    func runSelfCorrectingAgent(documentText: String, maxIterations: Int = 3) async throws -> String {
        var currentSummary = ""
        var critiqueFeedback = "No critique yet."
        var iteration = 0
        var state: SummarizerAgentState = .initializing
        
        print("Agent: Starting self-correcting summarization for document (length: \(documentText.count))...")
        
        while iteration < maxIterations && state != .finished && state != .failed {
            print("\n--- Iteration \(iteration + 1) --- Current State: \(state) ---")
            
            switch state {
            case .initializing:
                // Initial state, transition to summarizing
                state = .summarizing
                
            case .summarizing:
                let summarizePrompt = """
                You are a research assistant tasked with summarizing a document.
                Your goal is to create a concise and accurate summary of the key findings and conclusions.
                
                Document to summarize:
                ---
                \(documentText)
                ---
                
                Previous Summary (if any, refine this based on critique):
                ---
                \(currentSummary.isEmpty ? "No previous summary." : currentSummary)
                ---
                
                Critique from last iteration:
                ---
                \(critiqueFeedback)
                ---
                
                Generate a refined summary.
                Your refined summary:
                """
                
                print("Agent: Generating/Refining summary...")
                let llmResponse = try await chatModel.performInference(prompt: summarizePrompt)
                currentSummary = llmResponse.trimmingCharacters(in: .whitespacesAndNewlines)
                print("Agent: Generated Summary:\n\(currentSummary)")
                
                state = .critiquing
                
            case .critiquing:
                let critiquePrompt = """
                You are a critical reviewer. Evaluate the following summary against the original document.
                Identify any missing key points, factual inaccuracies, or areas where conciseness or clarity can be improved.
                If the summary is excellent and meets all criteria, respond with "CRITIQUE: ACCEPT".
                Otherwise, provide specific, constructive feedback that the summarizer can use to improve.
                
                Original Document:
                ---
                \(documentText)
                ---
                
                Summary to critique:
                ---
                \(currentSummary)
                ---
                
                Your Critique:
                """
                
                print("Agent: Critiquing generated summary...")
                let llmCritique = try await chatModel.performInference(prompt: critiquePrompt)
                critiqueFeedback = llmCritique.trimmingCharacters(in: .whitespacesAndNewlines)
                print("Agent: Critique:\n\(critiqueFeedback)")
                
                if critiqueFeedback.contains("CRITIQUE: ACCEPT") {
                    state = .finished
                    print("Agent: Summary accepted. Process finished.")
                } else {
                    print("Agent: Critique received. Will attempt to refine summary.")
                    state = .summarizing // Loop back to refine
                }
                
            case .finished:
                break // Exit loop
            case .failed:
                throw AgentError.summarizationFailed("Agent failed to produce an acceptable summary after \(maxIterations) iterations.")
            }
            
            iteration += 1
            if iteration >= maxIterations && state != .finished {
                state = .failed // If max iterations reached and not finished, mark as failed
            }
        }
        
        if state == .failed {
            throw AgentError.summarizationFailed("Agent could not finalize summary within \(maxIterations) iterations. Last summary: \(currentSummary)")
        }
        
        return currentSummary
    }
}

enum AgentError: Error, LocalizedError {
    case summarizationFailed(String)
    
    var errorDescription: String? {
        switch self {
        case .summarizationFailed(let message):
            return message
        }
    }
}

// MARK: - Main Agent Loop

@available(iOS 18.0, macOS 15.0, *)
func runSelfCorrectingSummarizerFeature() async {
    print("Welcome to the Self-Correcting Document Summarizer!")
    print("This agent will iteratively refine a summary using an MLX-powered LLM.")
    
    let sampleDocument = """
    Artificial intelligence (AI) is rapidly transforming various industries, from healthcare to finance.
    One of the most significant advancements in recent years has been the development of large language models (LLMs).
    These models, trained on vast amounts of text data, can understand, generate, and process human language with remarkable fluency.
    Apple's MLX framework provides a powerful and efficient way to run these LLMs directly on Apple Silicon, leveraging its Unified Memory architecture.
    This allows for high-performance inference and fine-tuning on consumer devices, opening up new possibilities for on-device AI applications.
    The zero-copy approach of Unified Memory means that data does not need to be transferred between discrete CPU and GPU memory,
    leading to lower latency and higher throughput. Furthermore, MLX's lazy evaluation mechanism optimizes computation graphs,
    executing operations only when their results are required, which can lead to significant performance gains, especially in complex,
    multi-step AI workflows like agentic loops. This local execution capability enhances user privacy and reduces reliance on cloud services.
    """
    
    let chatModel = MLXChatModel() // Reuse or create a new MLXChatModel
    let summarizerAgent = SelfCorrectingSummarizerAgent(chatModel: chatModel)
    
    do {
        let finalSummary = try await summarizerAgent.runSelfCorrectingAgent(documentText: sampleDocument, maxIterations: 3)
        print("\n--- Final Accepted Summary ---")
        print(finalSummary)
    } catch {
        print("Agent failed: \(error.localizedDescription)")
    }
}

// To run this:
/*
@main
struct MyApp {
    static func main() async {
        await runSelfCorrectingSummarizerFeature()
    }
}
*/
