
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
@Observable
class RAGViewModel {
    private let pipeline: RAGPipeline
    var currentQuery: String = ""
    var response: String = "Ask me anything!"
    var isLoading: Bool = false
    var error: String?

    init(pipeline: RAGPipeline) {
        self.pipeline = pipeline
    }

    @MainActor
    func sendQuery() async {
        guard !currentQuery.isEmpty else { return }
        isLoading = true
        error = nil
        response = "Thinking..."

        do {
            let result = try await pipeline.query(userQuery: currentQuery)
            response = result
        } catch {
            self.error = "Error: \(error.localizedDescription)"
            response = "Failed to get an answer."
        }
        isLoading = false
    }
}

// Example SwiftUI View (not part of the core RAG theory, but shows usage)
/*
@available(iOS 18.0, *)
struct RAGChatView: View {
    @State private var viewModel: RAGViewModel

    init(pipeline: RAGPipeline) {
        _viewModel = State(initialValue: RAGViewModel(pipeline: pipeline))
    }

    var body: some View {
        VStack {
            TextEditor(text: $viewModel.currentQuery)
                .frame(height: 100)
                .border(Color.gray, width: 1)
                .padding()

            Button("Ask") {
                Task { await viewModel.sendQuery() }
            }
            .disabled(viewModel.isLoading)

            if viewModel.isLoading {
                ProgressView()
            }

            Text(viewModel.response)
                .padding()

            if let error = viewModel.error {
                Text(error)
                    .foregroundColor(.red)
            }
        }
    }
}
*/
