
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftData
import CoreData
import Foundation

// --- SHARED MODEL ---
@available(iOS 17.0, *)
@Model
final class SensorReading {
    var timestamp: Date
    var value: Double
    var sensorType: String
    
    init(timestamp: Date, value: Double, sensorType: String) {
        self.timestamp = timestamp
        self.value = value
        self.sensorType = sensorType
    }
}

// --- PATTERN B: SWIFTDATA MODELACTOR ---
@available(iOS 17.0, *)
actor SensorIngestionActor: ModelActor {
    let modelContainer: ModelContainer
    let modelExecutor: any ModelExecutor
    
    init(container: ModelContainer) {
        self.modelContainer = container
        let context = ModelContext(container)
        // The executor manages the context on this actor's isolation
        self.modelExecutor = DefaultModelExecutor(context: context)
    }
    
    func ingest(readings: [SensorReading]) throws {
        for reading in readings {
            modelContext.insert(reading)
        }
        try modelContext.save()
    }
}

// --- STRESS TEST HARNESS ---
@available(iOS 17.0, *)
struct IngestionStressTester {
    let container: ModelContainer
    
    func runTest() async throws {
        let count = 5000
        let mockReadings = (0..<count).map { i in
            SensorReading(timestamp: Date(), value: Double(i), sensorType: "Temp")
        }
        
        print("Starting Stress Test for \(count) records...")
        
        // Test SwiftData ModelActor
        let clock = ContinuousClock()
        let swiftDataTime = try await clock.measure {
            let ingestionActor = SensorIngestionActor(container: container)
            try await ingestionActor.ingest(readings: mockReadings)
        }
        
        print("SwiftData ModelActor Time: \(swiftDataTime)")
        
        /*
         NOTE ON PATTERN A (CORE DATA):
         In a real implementation, Pattern A would use:
         persistentContainer.performBackgroundTask { context in
            for data in mockData {
                let obj = LogEntry(context: context)
                // ... populate ...
            }
            try? context.save()
         }
         
         TECHNICAL BREAKDOWN:
         
         1. Thread Confinement vs. Actor Isolation:
            Core Data relies on 'Thread Confinement'. You must manually ensure that 
            you are on the correct private queue associated with the context. 
            If you accidentally pass an NSManagedObject to the Main Thread, 
            the app crashes.
            
            SwiftData's ModelActor uses 'Actor Isolation'. The ModelContext is 
            bound to the Actor. The Swift 6 compiler enforces that you can only 
            interact with the context through the actor's isolated methods, 
            making data races mathematically impossible in safe code.
            
         2. Complexity and Boilerplate:
            Core Data requires managing `NSManagedObjectContext` hierarchies 
            and manual `perform` blocks. ModelActor encapsulates this entire 
            lifecycle into a single, cohesive unit that follows standard 
            Swift concurrency patterns.
            
         3. Throughput:
            While both eventually write to SQLite, ModelActor provides a more 
            predictable execution environment. Because it integrates with the 
            Swift Concurrency cooperative thread pool, it avoids the 'thread 
            explosion' often seen when heavily nesting Core Data background tasks.
         */
    }
}
