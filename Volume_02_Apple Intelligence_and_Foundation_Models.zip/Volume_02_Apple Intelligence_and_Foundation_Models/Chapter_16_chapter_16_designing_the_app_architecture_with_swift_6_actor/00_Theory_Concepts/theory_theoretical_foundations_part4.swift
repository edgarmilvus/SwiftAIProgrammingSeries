
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import SwiftUI // For @Observable

@available(iOS 18.0, *)
struct ConversationTurn: Identifiable, Sendable { // Make turns Sendable for potential sharing
    let id = UUID()
    let speaker: Speaker
    let text: String
    let timestamp: Date

    enum Speaker: Sendable {
        case user, llm, system
    }
}

@available(iOS 18.0, *)
@Observable // This class will automatically publish changes to its properties
class ConversationState {
    var turns: [ConversationTurn] = []
    var isThinking: Bool = false
    var currentInput: String = ""
    var error: String?

    func addTurn(_ turn: ConversationTurn) {
        turns.append(turn)
    }

    func clear() {
        turns.removeAll()
        isThinking = false
        currentInput = ""
        error = nil
    }
}

@available(iOS 18.0, *)
@MainActor // UI code always runs on the main actor
class LLMViewModel {
    private let llmActor = LLMInferenceActor()
    let conversation = ConversationState() // An instance of our observable state

    init() {
        // Load model on app launch or when view appears
        Task {
            do {
                await conversation.addTurn(ConversationTurn(speaker: .system, text: "Loading AI model...", timestamp: Date()))
                try await llmActor.loadModel()
                await conversation.addTurn(ConversationTurn(speaker: .system, text: "AI model ready!", timestamp: Date()))
            } catch {
                await conversation.addTurn(ConversationTurn(speaker: .system, text: "Error loading model: \(error.localizedDescription)", timestamp: Date()))
                conversation.error = error.localizedDescription
            }
        }
    }

    func sendPrompt() {
        guard !conversation.currentInput.isEmpty else { return }

        let userPrompt = conversation.currentInput
        conversation.currentInput = "" // Clear input field immediately
        conversation.addTurn(ConversationTurn(speaker: .user, text: userPrompt, timestamp: Date()))
        conversation.isThinking = true
        conversation.error = nil // Clear previous errors

        Task {
            do {
                let llmResponse = try await llmActor.generateResponse(for: userPrompt)
                conversation.addTurn(ConversationTurn(speaker: .llm, text: llmResponse, timestamp: Date()))
            } catch {
                conversation.error = "Error: \(error.localizedDescription)"
                conversation.addTurn(ConversationTurn(speaker: .system, text: "Error generating response.", timestamp: Date()))
            }
            conversation.isThinking = false
        }
    }

    func clearConversation() {
        Task {
            await llmActor.clearHistory()
            conversation.clear()
            conversation.addTurn(ConversationTurn(speaker: .system, text: "Conversation cleared. Ready for new input.", timestamp: Date()))
        }
    }
}

// Example SwiftUI View (not part of the theoretical explanation, but for context)
/*
@available(iOS 18.0, *)
struct ConversationView: View {
    @State private var viewModel = LLMViewModel()

    var body: some View {
        VStack {
            ScrollView {
                ForEach(viewModel.conversation.turns) { turn in
                    Text("\(turn.speaker): \(turn.text)")
                        .padding(5)
                        .background(turn.speaker == .user ? Color.blue.opacity(0.2) : Color.gray.opacity(0.1))
                        .cornerRadius(5)
                }
            }
            if viewModel.conversation.isThinking {
                ProgressView()
            }
            if let error = viewModel.conversation.error {
                Text(error).foregroundColor(.red)
            }
            HStack {
                TextField("Type your message...", text: $viewModel.conversation.currentInput)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    viewModel.sendPrompt()
                }
                .disabled(viewModel.conversation.isThinking || viewModel.conversation.currentInput.isEmpty)
            }
            Button("Clear") {
                viewModel.clearConversation()
            }
        }
        .padding()
    }
}
*/
