
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
struct PhotoTag {
    let name: String
    let embedding: NLEmbedding.Vector
}

@available(iOS 18.0, macOS 15.0, *)
class TagSuggestionEngine {
    private var availableTags: [PhotoTag] = []

    init() {
        let masterTagList = ["travel", "nature", "friends", "food", "cityscape", "mountains", "ocean", "animals", "adventure", "relax", "family", "beach", "sunset", "hiking", "party", "urban", "wildlife", "portrait", "landscape", "pets"]
        
        for tagName in masterTagList {
            if let embedding = NLEmbedding.embedding(for: tagName, language: .english) {
                availableTags.append(PhotoTag(name: tagName, embedding: embedding))
            } else {
                print("Could not generate embedding for tag: \(tagName)")
            }
        }
    }

    /// Suggests tags based on a list of existing tags.
    /// - Parameters:
    ///   - existingTags: Tags already applied to an item.
    ///   - maxSuggestions: The maximum number of tag suggestions to return.
    /// - Returns: An array of suggested tag names, sorted by semantic similarity.
    func suggestTags(basedOn existingTags: [String], maxSuggestions: Int = 5) async -> [String] {
        guard !existingTags.isEmpty else { return [] }

        var inputEmbeddings: [NLEmbedding.Vector] = []
        for tag in existingTags {
            if let embedding = NLEmbedding.embedding(for: tag, language: .english) {
                inputEmbeddings.append(embedding)
            }
        }

        guard !inputEmbeddings.isEmpty else { return [] }

        // Compute the average embedding to represent the combined semantic meaning
        // NLEmbedding.Vector supports arithmetic operations for this
        let queryEmbedding = inputEmbeddings.reduce(NLEmbedding.Vector.zero) { $0 + $1 } / Double(inputEmbeddings.count)

        var suggestions: [(tag: String, distance: Double)] = []
        let usedTagNames = Set(existingTags.map { $0.lowercased() })

        for tagEntry in availableTags {
            // Only suggest tags that are not already used
            if !usedTagNames.contains(tagEntry.name.lowercased()) {
                let distance = NLEmbedding.distance(between: queryEmbedding, and: tagEntry.embedding)
                suggestions.append((tag: tagEntry.name, distance: distance))
            }
        }

        return suggestions.sorted { $0.distance < $1.distance }.prefix(maxSuggestions).map { $0.tag }
    }
}

// Example Usage (in an async context)
/*
@available(iOS 18.0, macOS 15.0, *)
func demonstrateTagSuggestions() async {
    let engine = TagSuggestionEngine()
    
    print("--- Tag Suggestion Demo ---")

    let photoTags1 = ["beach", "sunset"]
    let suggestions1 = await engine.suggestTags(basedOn: photoTags1, maxSuggestions: 3)
    print("\nSuggestions for photo with tags \(photoTags1):")
    for suggestion in suggestions1 {
        print("- \(suggestion)")
    }
    // Expected output might include "ocean", "travel", "relax"

    let photoTags2 = ["mountains", "hiking"]
    let suggestions2 = await engine.suggestTags(basedOn: photoTags2, maxSuggestions: 3)
    print("\nSuggestions for photo with tags \(photoTags2):")
    for suggestion in suggestions2 {
        print("- \(suggestion)")
    }
    // Expected output might include "adventure", "nature", "landscape"
    
    let photoTags3 = ["food"]
    let suggestions3 = await engine.suggestTags(basedOn: photoTags3, maxSuggestions: 3)
    print("\nSuggestions for photo with tags \(photoTags3):")
    for suggestion in suggestions3 {
        print("- \(suggestion)")
    }
    // Expected output might be less specific, maybe "travel" if food is associated with travel experiences
}

// To run this example, embed it in a Task:
// Task { await demonstrateTagSuggestions() }
*/
