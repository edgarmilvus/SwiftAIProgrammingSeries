
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

// MARK: - Dependencies

/// Note: In a real SPM project, you would include:
/// .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
/// However, for this implementation, we rely on native Swift 6 Concurrency and URLSession.

// MARK: - Models

/// Represents the different types of content an agentic LLM can stream.
enum StreamContent: Sendable, Equatable {
    case reasoning(String)    // The "Thought" process
    case text(String)         // The actual response
    case toolCall(String)     // A structured tool call (e.g., JSON)
    case error(String)        // Error messages
    case complete             // The end of the stream
}

/// A structured error type for the Streaming Engine.
enum StreamingError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case parsingError(String)
    case connectionLost
    
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The provided URL was invalid."
        case .networkError(let err): return "Network error: \(err.localizedDescription)"
        case .parsingError(let msg): return "Failed to parse stream: \(msg)"
        case .connectionLost: return "The connection to the AI server was lost."
        }
    }
}

// MARK: - Core Engine

/// `SSEStreamManager` is an Actor responsible for managing the lifecycle of an SSE connection.
/// Using an `actor` ensures that the internal state of the stream (like partial buffers)
/// is protected from data races in a multi-threaded environment.
@available(iOS 18.0, macOS 15.0, *)
actor SSEStreamManager {
    
    private var streamTask: Task<Void, Never>?
    
    /// Parses an incoming stream of bytes into a sequence of `StreamContent`.
    /// - Parameters:
    ///   - url: The endpoint for the streaming chat completion.
    ///   - apiKey: The bearer token for authentication.
    ///   - prompt: The user's input.
    /// - Returns: An `AsyncStream` that yields parsed content updates.
    func streamChat(
        from url: URL,
        apiKey: String,
        prompt: String
    ) -> AsyncStream<StreamContent> {
        
        return AsyncStream { continuation in
            // Create a task to manage the long-running network request
            streamTask = Task {
                do {
                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"
                    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
                    request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    
                    // Construct the payload (Simplified for demonstration)
                    let payload: [String: Any] = [
                        "model": "gpt-4-turbo",
                        "messages": [["role": "user", "content": prompt]],
                        "stream": true
                    ]
                    request.httpBody = try JSONSerialization.data(withJSONObject: payload)

                    let (bytes, response) = try await URLSession.shared.bytes(for: request)
                    
                    guard let httpResponse = response as? HTTPURLResponse,
                          httpResponse.statusCode == 200 else {
                        continuation.yield(.error("Server returned non-200 status"))
                        continuation.finish()
                        return
                    }

                    // Buffer to handle fragmented SSE lines
                    var buffer = ""
                    
                    // Iterate over the lines of the stream
                    // URLSession.bytes(for:) provides an AsyncLineSequence
                    for try await line in bytes.lines {
                        // SSE protocol dictates that data follows the "data: " prefix
                        if line.hasPrefix("data: ") {
                            let dataContent = line.dropFirst(6).trimmingCharacters(in: .whitespacesAndNewlines)
                            
                            // Handle the [DONE] signal used by many providers (OpenAI, etc.)
                            if dataContent == "[DONE]" {
                                continuation.yield(.complete)
                                break
                            }
                            
                            // Process the data chunk
                            await processChunk(dataContent, continuation: continuation)
                        }
                    }
                    
                    continuation.finish()
                    
                } catch {
                    continuation.yield(.error(error.localizedDescription))
                    continuation.finish()
                }
            }
            
            // Handle task cancellation (e.g., if the user navigates away)
            continuation.onTermination = { @Sendable _ in
                self.streamTask?.cancel()
            }
        }
    }
    
    /// Internal logic to parse the raw SSE data string into typed content.
    /// In a production environment, this would involve complex JSON parsing.
    private func processChunk(
        _ chunk: String,
        continuation: AsyncStream<StreamContent>.Continuation
    ) async {
        // In a real-world scenario, we would use JSONDecoder here.
        // For this demonstration, we simulate parsing 'reasoning' vs 'text'
        // based on a hypothetical JSON structure: {"type": "reasoning", "delta": "..."}
        
        guard let data = chunk.data(using: .utf8) else { return }
        
        do {
            if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                let type = json["type"] as? String ?? "text"
                let delta = json["delta"] as? String ?? ""
                
                switch type {
                case "reasoning":
                    continuation.yield(.reasoning(delta))
                case "text":
                    continuation.yield(.text(delta))
                case "tool":
                    continuation.yield(.toolCall(delta))
                default:
                    continuation.yield(.text(delta))
                }
            }
        } catch {
            // If parsing fails, it might be a partial JSON fragment.
            // In an advanced implementation, we would buffer this and wait for the next chunk.
            // Here, we simply log it to prevent the stream from crashing.
            print("Transient parsing error: \(error)")
        }
    }
    
    /// Cancels the current active stream.
    func cancelStream() {
        streamTask?.cancel()
        streamTask = nil
    }
}

// MARK: - ViewModel

/// `ChatViewModel` manages the UI state and bridges the `SSEStreamManager` to the View.
/// It uses the `@Observable` macro (introduced in iOS 17) for efficient UI updates.
@available(iOS 18.0, macOS 15.0, *)
@Observable
class ChatViewModel {
    
    // MARK: UI State
    var messages: [String] = []
    var currentReasoning: String = ""
    var currentResponse: String = ""
    var isStreaming: Bool = false
    var errorMessage: String?
    
    private let streamManager = SSEStreamManager()
    private let apiKey = "sk-your-api-key-here" // Should be stored securely in Keychain
    
    /// Initiates the streaming process.
    /// - Parameter prompt: The user's message.
    func sendMessage(_ prompt: String) {
        // Reset state for a new message
        messages.append("User: \(prompt)")
        currentReasoning = ""
        currentResponse = ""
        errorMessage = nil
        isStreaming = true
        
        // Use a Task to enter the asynchronous context
        Task {
            let endpoint = URL(string: "https://api.openai.com/v1/chat/completions")!
            
            // Consume the AsyncStream returned by the actor
            let stream = await streamManager.streamChat(
                from: endpoint,
                apiKey: apiKey,
                prompt: prompt
            )
            
            for await content in stream {
                // Ensure UI updates happen on the Main Actor
                await MainActor.run {
                    updateUI(with: content)
                }
            }
            
            await MainActor.run {
                self.isStreaming = false
            }
        }
    }
    
    /// Updates the view model state based on the received content.
    /// This method is strictly called on the @MainActor.
    @MainActor
    private func updateUI(with content: StreamContent) {
        switch content {
        case .reasoning(let delta):
            currentReasoning += delta
        case .text(let delta):
            currentResponse += delta
        case .toolCall(let tool):
            currentResponse += "\n[System: Executing \(tool)]\n"
        case .error(let message):
            self.errorMessage = message
        case .complete:
            messages.append("AI: \(currentResponse)")
            currentResponse = ""
            currentReasoning = ""
        }
    }
    
    func stopStreaming() {
        Task {
            await streamManager.cancelStream()
            isStreaming = false
        }
    }
}
