
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.swift
// Description: Solution for Exercise 7
// ==========================================

// AppDelegate.swift (Updated for Exercise 5)
import Cocoa
import SwiftUI

class AppDelegate: NSObject, NSApplicationDelegate, NSPopoverDelegate {

    var statusItem: NSStatusItem!
    var popover: NSPopover!
    var clipboardMonitorTimer: Timer?
    var lastChangeCount: Int = 0
    
    // Binding to communicate clipboard state to SwiftUI view
    @Published var isCodeDetectedInClipboard: Bool = false {
        didSet {
            updateStatusItemIcon()
        }
    }
    @Published var clipboardContent: String = ""

    private var isPopoverShownBinding: Binding<Bool> {
        Binding(
            get: { self.popover.isShown },
            set: { newValue in
                if !newValue {
                    self.popover.performClose(nil)
                }
            }
        )
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let button = statusItem.button {
            button.action = #selector(togglePopover(_:))
            button.target = self
        }
        updateStatusItemIcon() // Set initial icon

        popover = NSPopover()
        popover.contentSize = NSSize(width: 320, height: 500) // Adjust size
        popover.behavior = .transient
        popover.delegate = self
        
        // Pass Published properties to PopoverRootView using an EnvironmentObject or custom initializer
        // For simplicity, we'll pass them directly as bindings/values here.
        popover.contentViewController = NSHostingController(rootView: ClipboardCodeExplainerView(
            isPopoverShown: isPopoverShownBinding,
            isCodeDetectedInClipboard: $isCodeDetectedInClipboard, // Pass binding
            clipboardContent: $clipboardContent // Pass binding
        ))
        
        // Start clipboard monitoring
        startClipboardMonitoring()
    }

    @objc func togglePopover(_ sender: AnyObject?) {
        if popover.isShown {
            popover.performClose(sender)
        } else {
            // Before showing popover, check clipboard one last time
            checkClipboard()
            if let button = statusItem.button {
                popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
                NSApp.activate(ignoringOtherApps: true)
            }
        }
    }
    
    // MARK: - Clipboard Monitoring
    private func startClipboardMonitoring() {
        clipboardMonitorTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.checkClipboard()
        }
    }

    private func checkClipboard() {
        let pasteboard = NSPasteboard.general
        if pasteboard.changeCount != lastChangeCount {
            lastChangeCount = pasteboard.changeCount
            
            if let copiedString = pasteboard.string(forType: .string) {
                let codeKeywords = ["func", "class", "struct", "import", "var", "let", "if", "for", "while", "{", "}", "[", "]", "(", ")", ";", "#include", "public", "private", "static", "return", "const", "int", "string", "void", "console.log", "print", "System.out.println"]
                
                // Simple heuristic: check for multiple code keywords or common code patterns
                let isCode = codeKeywords.contains(where: copiedString.contains) ||
                             copiedString.contains("->") ||
                             copiedString.contains("=>") ||
                             copiedString.contains("==") ||
                             copiedString.contains("===") ||
                             copiedString.contains("//") ||
                             copiedString.contains("/*") ||
                             copiedString.contains("*/") ||
                             copiedString.contains("def ") || // Python
                             copiedString.contains("function ") // JS
                
                DispatchQueue.main.async { // Ensure UI updates on main thread
                    self.isCodeDetectedInClipboard = isCode
                    self.clipboardContent = copiedString
                }
            } else {
                DispatchQueue.main.async {
                    self.isCodeDetectedInClipboard = false
                    self.clipboardContent = ""
                }
            }
        }
    }
    
    // MARK: - Status Item Icon Update
    private func updateStatusItemIcon() {
        if let button = statusItem.button {
            let config = NSImage.SymbolConfiguration(pointSize: 16, weight: .regular)
            let symbolName = isCodeDetectedInClipboard ? "curlybraces.square.fill" : "brain.head.profile.fill"
            button.image = NSImage(systemSymbolName: symbolName, accessibilityDescription: "Code Explainer")?
                .withSymbolConfiguration(config)
        }
    }

    // MARK: - NSPopoverDelegate
    func popoverDidClose(_ notification: Notification) {
        print("Popover closed.")
        // Optionally clear clipboard content or explanation when popover closes
        // This is handled by the SwiftUI view's state if needed.
    }
}
