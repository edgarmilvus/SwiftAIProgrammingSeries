
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import Foundation

// MARK: - Note Data Structures and Errors

struct NoteOutput: Codable, Hashable {
    let noteID: UUID
    let savedContent: String
    let savedTag: String?
}

enum NoteError: Error, CustomLocalizedStringResourceConvertible {
    case emptyContent
    case saveFailed // Added for completeness, though not strictly required by exercise.

    var localizedStringResource: LocalizedStringResource {
        switch self {
        case .emptyContent:
            return "Note content cannot be empty."
        case .saveFailed:
            return "Failed to save the note. Please try again."
        }
    }
}

// MARK: - Quick Note Intent

@available(iOS 18.0, *)
struct AddQuickNoteIntent: AppIntent {
    static var intentDisplayName: LocalizedStringResource = "Add Quick Note"
    static var description: LocalizedStringResource = "Quickly adds a new note to your notes app, with optional tagging."

    @Parameter(title: "Content", description: "The main text of the note.")
    var content: String

    @Parameter(title: "Tag", description: "An optional tag to categorize the note (e.g., 'Work', 'Personal').")
    var tag: String?

    static var parameterSummary: some ParameterSummary {
        Summary("Add note \((\.$content))") {
            \.$tag
        }
    }

    func perform() async throws -> some IntentResult & ReturnsValue<NoteOutput> {
        // Validate content
        if content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            throw NoteError.emptyContent
        }

        // Simulate saving the note
        let newNote = NoteOutput(noteID: UUID(), savedContent: content, savedTag: tag)
        print("Note saved: '\(newNote.savedContent)' (Tag: \(newNote.savedTag ?? "None")) with ID: \(newNote.noteID)")

        // In a real app, this would involve persistent storage and potentially more complex error handling.
        // For this exercise, we assume success after the print statement.
        return .result(
            value: newNote,
            dialog: "Note '\(newNote.savedContent)' saved with tag '\(newNote.savedTag ?? "None")'."
        )
    }
}

// MARK: - App Shortcuts Provider

@available(iOS 18.0, *)
struct MyNotesAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: AddQuickNoteIntent(),
            phrases: [
                "Add quick note \(\.$content)",
                "New note about \(\.$content) with tag \(\.$tag)",
                "Jot down a note"
            ],
            shortTitle: "Quick Note",
            systemImageName: "note.text.badge.plus"
        )
    }
}
