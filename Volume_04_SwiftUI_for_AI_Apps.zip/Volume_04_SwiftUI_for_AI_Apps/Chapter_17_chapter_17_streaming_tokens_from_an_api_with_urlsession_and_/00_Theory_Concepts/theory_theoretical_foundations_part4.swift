
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 15.0, *)
actor ChatStreamManager {
    // @Published var currentMessage: String = "" // Cannot use @Published directly in actor
    // Instead, use an Observable object for UI updates

    private var _currentMessage: String = ""
    private(set) var isStreaming: Bool = false

    // A separate Observable object to hold UI-relevant state
    @MainActor
    class ObservableChatState: ObservableObject {
        @Published var message: String = ""
        @Published var streamingActive: Bool = false
    }

    @MainActor
    let observableState = ObservableChatState()

    func startStream(from url: URL) async throws {
        guard !isStreaming else { return }
        isStreaming = true
        await observableState.setStreamingActive(true) // Update UI state on MainActor

        do {
            let (asyncBytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: url))
            // ... handle response ...

            for try await byteChunk in asyncBytes {
                try Task.checkCancellation()
                if let token = String(data: byteChunk, encoding: .utf8) {
                    _currentMessage.append(token)
                    await observableState.setMessage(_currentMessage) // Update UI state on MainActor
                }
            }
            isStreaming = false
            await observableState.setStreamingActive(false)
        } catch {
            print("Stream error: \(error)")
            isStreaming = false
            await observableState.setStreamingActive(false)
            // Handle error, potentially update observableState with error message
            throw error // Re-throw for caller to handle
        }
    }

    func getCurrentMessage() -> String {
        return _currentMessage
    }

    // Example of a MainActor isolated method in the ObservableObject
    @MainActor
    private func setMessage(_ newMessage: String) {
        self.message = newMessage
    }
    
    @MainActor
    private func setStreamingActive(_ active: Bool) {
        self.streamingActive = active
    }
}
