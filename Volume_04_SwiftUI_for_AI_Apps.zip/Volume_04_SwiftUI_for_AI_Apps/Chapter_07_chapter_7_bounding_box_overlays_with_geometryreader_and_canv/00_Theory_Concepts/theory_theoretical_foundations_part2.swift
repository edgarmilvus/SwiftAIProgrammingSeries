
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
struct BoundingBoxOverlayView: View {
    let imageSize: CGSize // The actual size of the image view, from GeometryReader
    let detections: [BoundingBoxDetection] // AI model output

    var body: some View {
        Canvas { context, size in
            // `size` here is the size of the Canvas itself, which should match `imageSize`
            // if Canvas is placed directly inside GeometryReader's content.

            for detection in detections {
                // Scale normalized AI bounding box (0.0 to 1.0) to screen coordinates
                let displayRect = CGRect(
                    x: detection.rect.origin.x * imageSize.width,
                    y: detection.rect.origin.y * imageSize.height,
                    width: detection.rect.size.width * imageSize.width,
                    height: detection.rect.size.height * imageSize.height
                )

                // Draw the bounding box rectangle
                let path = Path(roundedRect: displayRect, cornerRadius: 5)
                context.stroke(path, with: .color(.red), lineWidth: 2)

                // Draw the label and confidence
                let text = Text("\(detection.label) (\(Int(detection.confidence * 100))%)")
                    .font(.caption)
                    .foregroundColor(.white)
                
                // Position text above the box, or inside if space allows
                let textMeasurement = context.resolve(text).measure(in: size)
                let textOrigin = CGPoint(
                    x: displayRect.minX,
                    y: displayRect.minY - textMeasurement.height - 2
                )
                
                context.fill(Path(roundedRect: CGRect(origin: textOrigin, size: textMeasurement), cornerRadius: 3), with: .color(.red))
                context.draw(text, at: CGPoint(x: textOrigin.x + textMeasurement.width / 2, y: textOrigin.y + textMeasurement.height / 2), anchor: .center)
            }
        }
    }
}
