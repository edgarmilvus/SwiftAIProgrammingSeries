
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
struct ContentView: View {
    // Assume `aiModelOutput` is an @Observable object holding detection results
    @State private var detections: [BoundingBoxDetection] = []

    var body: some View {
        VStack {
            Image("input_image") // Or a VideoPlayer
                .resizable()
                .aspectRatio(contentMode: .fit)
                .overlay {
                    // GeometryReader here provides the size of the Image view
                    GeometryReader { geometry in
                        // The content of GeometryReader gets `geometry` (GeometryProxy)
                        // This is where we'll place our Canvas for drawing
                        BoundingBoxOverlayView(
                            imageSize: geometry.size, // Pass the actual image size
                            detections: detections
                        )
                    }
                }
            
            Button("Perform AI Inference") {
                Task {
                    // Simulate AI inference
                    await simulateAIInference()
                }
            }
        }
    }

    private func simulateAIInference() async {
        // In a real app, this would involve calling an actor-isolated AI model
        // and transforming its raw output into BoundingBoxDetection
        try? await Task.sleep(for: .seconds(0.5))
        self.detections = [
            BoundingBoxDetection(label: "Cat", confidence: 0.95, rect: CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)),
            BoundingBoxDetection(label: "Dog", confidence: 0.88, rect: CGRect(x: 0.5, y: 0.6, width: 0.25, height: 0.3))
        ]
    }
}

// Example data structure for AI output
struct BoundingBoxDetection: Identifiable, Sendable { // BoundingBoxDetection must be Sendable
    let id = UUID()
    let label: String
    let confidence: Double
    var rect: CGRect // Normalized CGRect (0.0 to 1.0)
}
