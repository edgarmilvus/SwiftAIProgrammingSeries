/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface UserData {
  id: string;
  name: string;
  role: 'admin' | 'user';
}

// hooks/usePlatformData.ts
import { useState, useEffect } from 'react';

// Define the return type for the hook
interface UsePlatformDataReturn<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

export function usePlatformData<T>(url: string): UsePlatformDataReturn<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // In a real app, this would be a fetch call to your API
        // For this exercise, we simulate a network request
        const response = await fetch(url);
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = (await response.json()) as T;
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url]);

  return { data, loading, error };
}

// components/DashboardHeader.tsx
import React from 'react';
import { View, Text, ActivityIndicator, Platform } from 'react-native';
import { usePlatformData } from '../hooks/usePlatformData';
import { UserData } from '../types';

// Props interface for type safety
interface DashboardHeaderProps {
  userId: string;
}

export default function DashboardHeader({ userId }: DashboardHeaderProps) {
  // Using the custom hook to fetch data
  const { data: user, loading, error } = usePlatformData<UserData>(`/api/users/${userId}`);

  if (loading) {
    return (
      <View style={{ padding: 20 }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={{ padding: 20 }}>
        <Text style={{ color: 'red' }}>Error: {error}</Text>
      </View>
    );
  }

  // Platform-specific rendering logic
  if (Platform.OS === 'web') {
    return (
      <nav style={{ padding: '1rem', backgroundColor: '#f3f4f6' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <h1>Welcome, {user?.name}</h1>
          <div>
            <span style={{ marginRight: '1rem' }}>Role: {user?.role}</span>
            <a href="/dashboard">Dashboard</a>
          </div>
        </div>
      </nav>
    );
  }

  // Native rendering (iOS/Android)
  return (
    <View style={{ padding: 16, backgroundColor: '#f3f4f6' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Welcome, {user?.name}</Text>
        <View>
          <Text style={{ marginRight: 10 }}>Role: {user?.role}</Text>
          <Text style={{ color: 'blue' }}>Dashboard</Text>
        </View>
      </View>
    </View>
  );
}
