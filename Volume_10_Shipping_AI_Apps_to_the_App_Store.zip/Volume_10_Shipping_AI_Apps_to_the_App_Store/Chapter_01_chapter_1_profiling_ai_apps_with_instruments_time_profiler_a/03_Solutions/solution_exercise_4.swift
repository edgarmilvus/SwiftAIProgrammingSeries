
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AVFoundation
import CoreML

@available(iOS 18.0, *)
class VideoStyleTransferEngine: ObservableObject {
    @Published var currentFPS: Double = 0
    
    func processFrame(_ pixelBuffer: CVPixelBuffer) async {
        let startTime = CFAbsoluteTimeGetCurrent()
        
        // 1. Thermal Awareness: Check the current SoC state.
        let thermalState = ProcessInfo.processInfo.thermalState
        
        // 2. Dynamic Complexity Scaling:
        // We adjust the "intensity" of our computation based on how hot the device is.
        switch thermalState {
        case .nominal, .fair:
            // Full quality mode
            await performHeavyMath(iterations: 1_000_000)
            
        case .serious:
            // "Lite" mode: Reduce workload to allow the device to cool down.
            // This prevents the OS from entering the 'Critical' state and hard-throttling.
            await performHeavyMath(iterations: 200_000)
            
        case .critical:
            // Emergency mode: Minimal processing to maintain basic functionality.
            await performHeavyMath(iterations: 10_000)
            
        @unknown default:
            await performHeavyMath(iterations: 1_000_000)
        }
        
        let duration = CFAbsoluteTimeGetCurrent() - startTime
        
        // Ensure UI updates happen on the Main Actor
        await MainActor.run {
            self.currentFPS = 1.0 / duration
        }
    }
    
    private func performHeavyMath(iterations: Int) async {
        // Simulate the heavy load of a generative model
        var value: Float = 0.0
        for i in 0..<iterations {
            value += sin(Float(i)) * cos(Float(i))
        }
        // Prevent compiler from optimizing away the loop
        _ = value 
    }
}
