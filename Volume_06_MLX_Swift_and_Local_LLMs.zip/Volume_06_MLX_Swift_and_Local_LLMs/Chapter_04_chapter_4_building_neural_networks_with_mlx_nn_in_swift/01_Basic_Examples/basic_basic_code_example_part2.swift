
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import MLX
import MLXNN // For neural network modules like Linear, Module, Optimizers

// Ensure this code is only compiled and run on platforms that support MLX.
// MLX Swift currently targets iOS 18+ and macOS 15+.
@available(iOS 18.0, macOS 15.0, *)
class SketchClassifierService {

    /// 1. Define the Neural Network Architecture
    ///
    /// Our simple classifier is a subclass of `MLXNN.Module`.
    /// This base class provides the necessary infrastructure for parameter management
    /// and integration with MLX's functional transformations.
    ///
    /// The network consists of a single linear layer, suitable for simple binary classification
    /// problems, especially when the data is linearly separable.
    struct SimpleBinaryClassifier: MLXNN.Module {
        let linear: MLXNN.Linear

        /// Initializes the classifier with an input and output feature dimension.
        ///
        /// - Parameters:
        ///   - inputFeatures: The number of input features (e.g., 2 for our 2D data).
        ///   - outputFeatures: The number of output features (e.g., 2 for two classes).
        init(inputFeatures: Int, outputFeatures: Int) {
            self.linear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        }

        /// The forward pass of the neural network.
        ///
        /// This method defines how input data `x` flows through the network to produce an output.
        /// For our simple model, it's just a linear transformation.
        ///
        /// - Parameter x: An `MLXArray` representing the input features.
        /// - Returns: An `MLXArray` representing the raw logits for each class.
        func callAsFunction(_ x: MLXArray) -> MLXArray {
            return linear(x)
        }
    }

    /// 2. Define the Loss Function
    ///
    /// This function calculates the categorical cross-entropy loss, a common choice
    /// for multi-class classification problems. It takes the model's parameters,
    /// the input data, and the true target labels.
    ///
    /// - Parameters:
    ///   - parameters: The current parameters of the model (weights and biases).
    ///   - inputs: The input data `MLXArray`.
    ///   - targets: The true target labels `MLXArray`.
    /// - Returns: An `MLXArray` containing the scalar loss value.
    func lossFunction(parameters: ModuleParameters, inputs: MLXArray, targets: MLXArray) -> MLXArray {
        // Apply the model's forward pass using the given parameters.
        // `parameters` here is a dictionary mapping parameter names to their MLXArray values.
        let logits = SimpleBinaryClassifier(parameters: parameters)(inputs)

        // Calculate the cross-entropy loss.
        // `crossEntropy` expects logits and integer targets.
        // `mean()` aggregates the loss over the batch.
        return MLX.mean(MLX.crossEntropy(logits: logits, targets: targets, reduction: .none))
    }

    /// 3. Training Function: Orchestrates the learning process.
    ///
    /// This function generates synthetic data, initializes the model and optimizer,
    /// and then performs a series of training steps to update the model's parameters.
    ///
    /// - Parameters:
    ///   - numEpochs: The number of training iterations.
    ///   - learningRate: The step size for parameter updates.
    /// - Returns: The trained `SimpleBinaryClassifier` instance.
    func trainSimpleClassifier(numEpochs: Int = 100, learningRate: Float = 0.01) -> SimpleBinaryClassifier {
        print("Starting training for SimpleBinaryClassifier...")

        // Generate synthetic data for two classes (e.g., "line" vs. "dot cluster")
        // Class 0: Points around (1, 1)
        let class0Data = MLX.random.normal(shape: [50, 2]) + 1.0
        let class0Labels = MLX.zeros([50], type: .int32) // Labels for class 0

        // Class 1: Points around (-1, -1)
        let class1Data = MLX.random.normal(shape: [50, 2]) - 1.0
        let class1Labels = MLX.ones([50], type: .int32) // Labels for class 1

        // Combine data and labels
        let inputs = MLX.concatenate([class0Data, class1Data])
        let targets = MLX.concatenate([class0Labels, class1Labels])

        // Shuffle the data
        let indices = MLX.random.permutation(MLX.arange(inputs.dim(0)))
        let shuffledInputs = inputs[indices]
        let shuffledTargets = targets[indices]

        // Initialize the model
        let model = SimpleBinaryClassifier(inputFeatures: 2, outputFeatures: 2) // 2 input features, 2 output classes

        // Initialize the optimizer (Stochastic Gradient Descent)
        let optimizer = MLXNN.Optimizers.SGD(learningRate: learningRate)

        // Training loop
        for epoch in 0..<numEpochs {
            // MLX's `valueAndGradient` is a functional transformation.
            // It computes both the loss value and the gradients of the loss
            // with respect to the model's parameters in a single pass.
            // This is where MLX's lazy evaluation comes into play: the computation graph
            // for the loss and gradients is built but not executed until `eval()` is called.
            let (loss, gradients) = MLX.valueAndGradient(lossFunction)(model.parameters, shuffledInputs, shuffledTargets)

            // Force evaluation of the loss and gradients.
            // This triggers the actual computation on the accelerator (CPU/GPU).
            // MLXArray's `eval()` method ensures the values are computed and available.
            loss.eval()
            gradients.eval()

            // Update model parameters using the optimizer and the computed gradients.
            // The optimizer applies the gradients to adjust the parameters.
            model.update(optimizer.call(parameters: model.parameters, gradients: gradients))

            if epoch % 10 == 0 {
                print("Epoch \(epoch): Loss = \(loss.item(Float.self))")
            }
        }
        print("Training complete.")
        return model
    }

    /// 4. Inference Function: Uses the trained model to make predictions.
    ///
    /// - Parameters:
    ///   - model: The trained `SimpleBinaryClassifier` instance.
    ///   - input: An `MLXArray` representing a single input feature vector (e.g., a new sketch).
    /// - Returns: The predicted class label (0 or 1).
    func predict(model: SimpleBinaryClassifier, input: MLXArray) -> Int {
        // Ensure input has the correct shape (e.g., [1, 2] for a single 2D input)
        precondition(input.shape.count == 2 && input.shape[1] == model.linear.inputFeatures,
                     "Input shape must be [batch_size, input_features]")

        // Perform a forward pass to get the raw logits.
        let logits = model(input)

        // Apply softmax to convert logits into probabilities.
        // Softmax ensures the outputs sum to 1 and represent a probability distribution.
        let probabilities = MLX.softmax(logits, axis: -1)

        // Get the index of the highest probability, which is our predicted class.
        let predictedClass = MLX.argmax(probabilities, axis: -1).item(Int.self)

        return predictedClass
    }

    /// Main entry point for demonstrating the classifier.
    func runClassifierDemo() {
        let trainedModel = trainSimpleClassifier()

        // Test with new data points
        let testInput1 = MLXArray([1.2, 0.8]) // Should be class 0 ("line")
        let prediction1 = predict(model: trainedModel, input: testInput1.expandedDimensions(axis: 0))
        print("Test input \(testInput1.description) -> Predicted class: \(prediction1)") // Expected: 0

        let testInput2 = MLXArray([-0.9, -1.1]) // Should be class 1 ("dot cluster")
        let prediction2 = predict(model: trainedModel, input: testInput2.expandedDimensions(axis: 0))
        print("Test input \(testInput2.description) -> Predicted class: \(prediction2)") // Expected: 1

        let testInput3 = MLXArray([0.1, 0.2]) // Ambiguous, but closer to class 0
        let prediction3 = predict(model: trainedModel, input: testInput3.expandedDimensions(axis: 0))
        print("Test input \(testInput3.description) -> Predicted class: \(prediction3)") // Expected: 0 or 1 depending on training
    }
}

// Example usage in an application's entry point (e.g., an AppDelegate or a SwiftUI View's `onAppear`)
@main
struct SketchClassifierApp {
    static func main() async {
        if #available(iOS 18.0, macOS 15.0, *) {
            let service = SketchClassifierService()
            service.runClassifierDemo()
        } else {
            print("MLX Swift requires iOS 18.0 / macOS 15.0 or later.")
        }
    }
}

