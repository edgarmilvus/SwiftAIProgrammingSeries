
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct MockMetadata: Sendable {
    let id: UUID
    let tenantID: UUID
}

@available(iOS 18.0, *)
actor SyncIntegrityManager {
    // Simulated storage
    private var vectorStoreIDs: Set<UUID> = []
    private var metadataStore: [MockMetadata] = []
    
    func setMockData(vectors: Set<UUID>, metadata: [MockMetadata]) {
        self.vectorStoreIDs = vectors
        self.metadataStore = metadata
    }
    
    @available(iOS 18.0, *)
    func runReconciliationLoop() async {
        print("Starting Integrity Reconciliation...")
        
        // 1. Extract IDs for Set operations
        let metadataIDs = Set(metadataStore.map { $0.id })
        
        // 2. Detect Discrepancies using Set Subtraction
        // Ghost Vectors: In Vector Store, but NOT in Metadata
        let ghostIDs = vectorStoreIDs.subtracting(metadataIDs)
        
        // Orphaned Vectors: In Metadata, but NOT in Vector Store
        let orphanedIDs = metadataIDs.subtracting(vectorStoreIDs)
        
        // 3. Repair Logic
        await withTaskGroup(of: Void.self) { group in
            // Handle Ghosts: Delete from Vector Store
            for id in ghostIDs {
                group.addTask {
                    await self.cleanupGhostVector(id)
                }
            }
            
            // Handle Orphans: Re-hydrate from CloudKit or Delete
            for id in orphanedIDs {
                group.addTask {
                    await self.repairOrphanedMetadata(id)
                }
            }
        }
        
        print("Reconciliation Complete.")
    }
    
    private func cleanupGhostVector(_ id: UUID) async {
        // In real app: Call Vector DB API to delete
        print("⚠️ Cleaning up Ghost Vector: \(id)")
        vectorStoreIDs.remove(id)
    }
    
    private func repairOrphanedMetadata(_ id: UUID) async {
        print("🔍 Attempting to re-hydrate Orphaned Metadata: \(id)")
        // Simulate CloudKit Latency
        try? await Task.sleep(for: .milliseconds(500))
        
        let success = Bool.random() // Simulate network success/failure
        if !success {
            print("❌ Re-hydration failed. Deleting orphaned metadata: \(id)")
            metadataStore.removeAll { $0.id == id }
        } else {
            print("✅ Re-hydration successful for: \(id)")
        }
    }
}
