
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import SwiftData

@main
@available(iOS 18.0, *)
struct AIConversationApp: App {
    var sharedModelContainer: ModelContainer

    init() {
        do {
            sharedModelContainer = try ModelContainer(for: Conversation.self, Message.self)
        } catch {
            fatalError("Failed to create ModelContainer: \(error.localizedDescription)")
        }
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(ChatEngine(persistenceActor: try! ChatPersistenceActor(modelContainer: sharedModelContainer)))
        }
        .modelContainer(sharedModelContainer) // Provides the container to the SwiftUI environment
    }
}

// Example ContentView (simplified)
@available(iOS 18.0, *)
struct ContentView: View {
    @Environment(ChatEngine.self) private var chatEngine
    @State private var newMessageText: String = ""

    // Use @Query for live updates from SwiftData
    @Query(sort: \Conversation.createdAt, order: .reverse) private var conversations: [Conversation]

    var body: some View {
        NavigationStack {
            VStack {
                if let currentConversation = chatEngine.currentConversation {
                    // Display messages for the current conversation
                    List {
                        ForEach(currentConversation.messages?.sorted(using: KeyPathComparator(\.timestamp)) ?? []) { message in
                            HStack {
                                if message.sender == .user { Spacer() }
                                MessageBubble(message: message)
                                if message.sender == .ai { Spacer() }
                            }
                        }
                    }
                    .listStyle(.plain)
                    .onChange(of: currentConversation.messages?.count) {
                        // Scroll to bottom logic for chat
                    }

                    // Input field
                    HStack {
                        TextField("Type a message...", text: $newMessageText)
                            .textFieldStyle(.roundedBorder)
                        Button("Send") {
                            Task {
                                await chatEngine.sendUserMessage(text: newMessageText, to: currentConversation.id)
                                newMessageText = ""
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding()
                } else {
                    ContentUnavailableView("Select or Start a Conversation", systemImage: "message.fill")
                }
            }
            .navigationTitle(chatEngine.currentConversation?.createdAt.formatted(date: .abbreviated, time: .shortened) ?? "AI Chat")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu("Conversations") {
                        Button("New Conversation") {
                            Task { await chatEngine.startNewConversation() }
                        }
                        Divider()
                        ForEach(conversations) { convo in
                            Button(convo.createdAt.formatted(date: .abbreviated, time: .shortened)) {
                                Task { await chatEngine.selectConversation(id: convo.id) }
                            }
                            .swipeActions {
                                Button("Delete", role: .destructive) {
                                    Task { await chatEngine.deleteConversation(conversationID: convo.id) }
                                }
                            }
                        }
                    }
                }
            }
            .task {
                await chatEngine.loadAllConversations()
                if chatEngine.allConversations.isEmpty {
                    await chatEngine.startNewConversation()
                } else {
                    await chatEngine.selectConversation(id: chatEngine.allConversations.first!.id)
                }
            }
        }
    }
}

@available(iOS 18.0, *)
struct MessageBubble: View {
    let message: Message

    var body: some View {
        Text(message.content)
            .padding(10)
            .background(message.sender == .user ? Color.blue : Color.gray.opacity(0.2))
            .foregroundColor(message.sender == .user ? .white : .primary)
            .cornerRadius(10)
            .overlay(alignment: message.sender == .user ? .bottomTrailing : .bottomLeading) {
                if message.status == .streaming {
                    Image(systemName: "ellipsis.message.fill")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .padding([.horizontal, .bottom], 4)
                } else if message.status == .error {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.caption2)
                        .foregroundColor(.red)
                        .padding([.horizontal, .bottom], 4)
                }
            }
    }
}
