
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

// MARK: - Package Dependencies
/*
 To use this in a real project, add the following to your Package.swift:
 
 dependencies: [
     .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
 ]
*/

/// Represents the different types of errors that can occur during the evaluation process.
enum RAGEvaluationError: Error, LocalizedError {
    case providerError(String)
    case invalidResponseFormat
    case insufficientContext
    
    var errorDescription: String? {
        switch self {
        case .providerError(let msg): return "LLM Provider Error: \(msg)"
        case .invalidResponseFormat: return "The judge returned a malformed response."
        case .insufficientContext: return "Evaluation failed due to empty context."
        }
    }
}

/// A structured report containing the quantitative metrics of a RAG execution.
struct RAGEvaluationReport: Sendable, Codable {
    let faithfulnessScore: Double // 0.0 to 1.0
    let relevanceScore: Double    // 0.0 to 1.0
    let precisionScore: Double    // 0.0 to 1.0
    let reasoning: String         // The "Why" behind the scores
    let timestamp: Date
}

/// The input data required to perform a comprehensive RAG evaluation.
struct RAGEvaluationInput: Sendable {
    let query: String
    let retrievedContext: [String]
    let generatedAnswer: String
}

/// A protocol defining the requirements for an LLM-based evaluator.
protocol RAGEvaluator: Sendable {
    func evaluate(input: RAGEvaluationInput) async throws -> RAGEvaluationReport
}

/// The `RAGEvaluationEngine` is an actor responsible for orchestrating 
/// the "LLM-as-a-Judge" pattern. Using an actor ensures that the 
/// internal state and concurrent evaluation requests are thread-safe.
@available(iOS 18.0, macOS 15.0, *)
actor RAGEvaluationEngine: RAGEvaluator {
    
    private let apiKey: String
    private let modelName: String
    
    /// Initializes the engine with necessary credentials.
    /// - Parameters:
    ///   - apiKey: The OpenAI or compatible API key.
    ///   - modelName: The model to use as the "Judge" (e.g., "gpt-4o").
    init(apiKey: String, modelName: String = "gpt-4o") {
        self.apiKey = apiKey
        self.modelName = modelName
    }
    
    /// Performs a multi-dimensional evaluation of a RAG cycle.
    /// This function uses Swift 6 Structured Concurrency to run 
    /// different metric checks in parallel.
    func evaluate(input: RAGEvaluationInput) async throws -> RAGEvaluationReport {
        guard !input.retrievedContext.isEmpty else {
            throw RAGEvaluationError.insufficientContext
        }
        
        // We use a TaskGroup to perform the different evaluation dimensions 
        // simultaneously, optimizing for latency.
        return try await withThrowingTaskGroup(of: EvaluationDimension.self) { group in
            
            // 1. Check Faithfulness (Hallucination)
            group.addTask {
                let score = try await self.calculateFaithfulness(input)
                return .faithfulness(score)
            }
            
            // 2. Check Answer Relevance
            group.addTask {
                let score = try await self.calculateRelevance(input)
                return .relevance(score)
            }
            
            // 3. Check Context Precision
            group.addTask {
                let score = try await self.calculatePrecision(input)
                return .precision(score)
            }
            
            var faithfulness: Double = 0
            var relevance: Double = 0
            var precision: Double = 0
            var combinedReasoning = ""
            
            // Collect results as they finish
            for try await result in group {
                switch result {
                case .faithfulness(let score):
                    faithfulness = score
                case .relevance(let score):
                    relevance = score
                case .precision(let score):
                    precision = score
                }
            }
            
            // In a production app, we would also request a single "Reasoning" 
            // block from the LLM to explain the scores.
            combinedReasoning = "Evaluation completed successfully."
            
            return RAGEvaluationReport(
                faithfulnessScore: faithfulness,
                relevanceScore: relevance,
                precisionScore: precision,
                reasoning: combinedReasoning,
                timestamp: Date()
            )
        }
    }
    
    // MARK: - Private Evaluator Logic
    
    /// Evaluates if the answer is grounded in the context.
    /// This is the primary defense against hallucinations.
    private func calculateFaithfulness(_ input: RAGEvaluationInput) async throws -> Double {
        let prompt = """
        You are a strict fact-checker. 
        Compare the 'Answer' against the 'Context' provided below.
        
        Context: \(input.retrievedContext.joined(separator: "\n"))
        Answer: \(input.generatedAnswer)
        
        Does the Answer contain any information NOT present in the Context?
        Return ONLY a JSON object with a single key "score" (0.0 to 1.0), 
        where 1.0 is perfectly faithful and 0.0 is a complete hallucination.
        """
        return try await performJudgeQuery(prompt: prompt)
    }
    
    /// Evaluates if the answer actually addresses the user's query.
    private func calculateRelevance(_ input: RAGEvaluationInput) async throws -> Double {
        let prompt = """
        You are an intent evaluator.
        Query: \(input.query)
        Answer: \(input.generatedAnswer)
        
        On a scale of 0.0 to 1.0, how well does the Answer address the Query?
        Return ONLY a JSON object with a single key "score".
        """
        return try await performJudgeQuery(prompt: prompt)
    }
    
    /// Evaluates if the retrieved context is relevant to the query.
    private func calculatePrecision(_ input: RAGEvaluationInput) async throws -> Double {
        let prompt = """
        You are a retrieval quality auditor.
        Query: \(input.query)
        Context Chunks: \(input.retrievedContext.joined(separator: "\n"))
        
        On a scale of 0.0 to 1.0, how much of the provided context is actually 
        relevant to answering the query? Return ONLY a JSON object with key "score".
        """
        return try await performJudgeQuery(prompt: prompt)
    }
    
    /// The low-level communication layer with the LLM Judge.
    /// In a real implementation, this would use a formal OpenAI SDK.
    private func performJudgeQuery(prompt: String) async throws -> Double {
        // Simulated network call to an LLM provider
        // In production, use URLSession to call OpenAI/Anthropic API
        try await Task.sleep(for: .milliseconds(500)) 
        
        // Mocking a JSON response for demonstration
        // In real code: Parse the JSON response from the LLM
        let mockScore = Double.random(in: 0.7...1.0)
        return mockScore
    }
    
    /// Internal helper to categorize task results within the TaskGroup.
    private enum EvaluationDimension {
        case faithfulness(Double)
        case relevance(Double)
        case precision(Double)
    }
}

// MARK: - UI Integration Example (SwiftUI)

@available(iOS 18.0, macOS 15.0, *)
@Observable
class ResearchViewModel {
    var report: RAGEvaluationReport?
    var isEvaluating = false
    var errorMessage: String?
    
    private let engine = RAGEvaluationEngine(apiKey: "sk-...")
    
    func runQualityAudit(query: String, context: [String], answer: String) async {
        isEvaluating = true
        errorMessage = nil
        
        let input = RAGEvaluationInput(
            query: query,
            retrievedContext: context,
            generatedAnswer: answer
        )
        
        do {
            // The actor handles the concurrency safely
            let result = try await engine.evaluate(input: input)
            self.report = result
        } catch {
            self.errorMessage = error.localizedDescription
        }
        
        isEvaluating = false
    }
}
