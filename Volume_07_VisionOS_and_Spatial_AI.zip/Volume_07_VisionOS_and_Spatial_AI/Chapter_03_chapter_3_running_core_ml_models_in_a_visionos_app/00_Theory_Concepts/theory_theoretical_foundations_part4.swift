
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation
import RealityKit // For a spatial context

@available(visionOS 1.0, *)
class SpatialAIProcessor {
    private var model: MLModel?
    
    init() {
        Task {
            do {
                self.model = try await loadModel()
                print("Core ML model loaded successfully.")
            } catch {
                print("Failed to load Core ML model: \(error)")
            }
        }
    }

    func processImage(pixelBuffer: CVPixelBuffer) async throws -> String {
        guard let model = self.model else {
            throw SpatialAIError.modelNotLoaded
        }

        // Assume MyImageClassifierInput is generated from your .mlmodel
        let input = MyImageClassifierInput(image: pixelBuffer)
        
        // Perform prediction asynchronously
        let output = try await model.prediction(from: input)
        
        // Access specific output features (e.g., a classification label)
        guard let label = output.featureValue(for: "label")?.stringValue else {
            throw SpatialAIError.outputMissing
        }
        return label
    }
}

enum SpatialAIError: Error {
    case modelNotLoaded
    case outputMissing
}
