
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Foundation
// import MLX

// Reusing LLMService protocol and LLMServiceError from Exercise 1
// protocol LLMService { ... }
// enum LLMServiceError: Error, LocalizedError { ... }

/// A simulated MLX LLM service that streams a predefined response.
/// Modified to respect Task cancellation.
final class MLXLLMService: LLMService {
    private let simulatedResponse = "Hello there! I am a simulated AI assistant powered by MLX Swift. I can help you with various tasks, from answering questions to generating creative content. How can I assist you today?"
    private let simulatedTokens: [String]

    init() {
        simulatedTokens = simulatedResponse.components(separatedBy: " ")
    }

    func streamResponse(prompt: String) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                print("MLXLLMService: Starting stream for prompt: '\(prompt)'")
                for (index, token) in simulatedTokens.enumerated() {
                    // CRITICAL: Check for cancellation within the loop
                    if Task.isCancelled {
                        print("MLXLLMService: Stream cancelled internally.")
                        continuation.finish(throwing: LLMServiceError.cancellationRequested)
                        return // Exit the Task
                    }

                    // Simulate processing time for each token
                    try await Task.sleep(for: .milliseconds(70))

                    let tokenWithSpace = token + (index == simulatedTokens.count - 1 ? "" : " ")
                    continuation.yield(tokenWithSpace)
                }
                print("MLXLLMService: Stream finished normally.")
                continuation.finish()
            }
        }
    }
}

/// Manages the chat interface state, interaction with the LLM service, and cancellation logic.
@MainActor
final class ChatViewModel: ObservableObject {
    @Published var currentResponse: String = ""
    @Published var promptInput: String = ""
    @Published var isStreaming: Bool = false // Renamed from isLoading for clarity

    private let llmService: LLMService
    private var currentGenerationTask: Task<Void, Never>? // Stores the task for cancellation

    init(llmService: LLMService = MLXLLMService()) {
        self.llmService = llmService
    }

    /// Sends the current prompt to the LLM service and streams the response.
    func sendMessage() {
        guard !promptInput.isEmpty, !isStreaming else { return } // Prevent multiple concurrent streams

        // Clear any previous task if, for some reason, it wasn't cleaned up
        cancelStreaming()

        let currentPrompt = promptInput
        promptInput = ""
        currentResponse = ""
        isStreaming = true // Set streaming state to true

        currentGenerationTask = Task {
            do {
                for try await token in llmService.streamResponse(prompt: currentPrompt) {
                    // Check for cancellation within the consumption loop as well
                    // Although the stream itself handles it, this adds another layer of robustness
                    if Task.isCancelled {
                        print("ChatViewModel: Consumption task cancelled during iteration.")
                        break // Exit the loop
                    }
                    currentResponse += token
                }
            } catch let error as LLMServiceError where error == .cancellationRequested {
                print("ChatViewModel: Stream cancelled by user.")
                currentResponse += "\n\n(Generation cancelled.)" // Optional: Add a message
            } catch {
                print("ChatViewModel: Error streaming response: \(error.localizedDescription)")
                currentResponse = "Error: \(error.localizedDescription)"
            }
            isStreaming = false // Set streaming state to false when finished or cancelled
            currentGenerationTask = nil // Clear task reference
        }
    }

    /// Cancels the currently active LLM response streaming task.
    func cancelStreaming() {
        print("ChatViewModel: Attempting to cancel streaming task.")
        currentGenerationTask?.cancel() // Request cancellation
        // The Task will eventually observe Task.isCancelled and clean up
        // We don't immediately set isStreaming = false here,
        // as the Task's cleanup (including setting isStreaming = false) should ideally complete.
        // If the Task is already finished, this call has no effect.
    }
    
    /// Clears the current response and prompt.
    func clearChat() {
        cancelStreaming() // Ensure any ongoing stream is stopped
        currentResponse = ""
        promptInput = ""
    }
}

/// The main SwiftUI view for the chat application, now with cancellation and status UI.
struct ContentView: View {
    @StateObject private var chatViewModel = ChatViewModel()

    var body: some View {
        VStack {
            // Chat history display
            ScrollViewReader { scrollViewProxy in
                ScrollView {
                    Text(chatViewModel.currentResponse)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                        .onChange(of: chatViewModel.currentResponse) { _ in
                            scrollViewProxy.scrollTo("bottom", anchor: .bottom)
                        }
                    Rectangle()
                        .fill(Color.clear)
                        .frame(height: 1)
                        .id("bottom")
                }
                .frame(maxHeight: .infinity)
                .padding(.horizontal)
            }

            // Status Indicator
            if chatViewModel.isStreaming {
                HStack {
                    ProgressView()
                    Text("Generating...")
                }
                .padding(.vertical, 5)
            }

            // Input and control area
            HStack {
                TextField("Ask me anything...", text: $chatViewModel.promptInput, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .padding(.vertical, 8)
                    .disabled(chatViewModel.isStreaming) // Disable input while streaming

                if chatViewModel.isStreaming {
                    Button("Stop") {
                        chatViewModel.cancelStreaming()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                } else {
                    Button {
                        chatViewModel.sendMessage()
                    } label: {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title)
                    }
                    .buttonStyle(.plain)
                    .disabled(chatViewModel.promptInput.isEmpty)
                }
            }
            .padding()
            .background(.ultraThinMaterial)
        }
        .navigationTitle("AI Assistant (MLX Swift)")
    }
}
