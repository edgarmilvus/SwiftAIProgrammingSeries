
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation

// MARK: - Models

/// Represents a single piece of user-generated content.
/// In a production app, this might be stored in CoreData or SwiftData.
struct Note: Sendable, Identifiable {
    let id: UUID
    let content: String
    let timestamp: Date
}

/// Errors specific to the Retrieval and LLM interaction process.
enum AssistantError: Error, LocalizedError {
    case retrievalFailed
    case noRelevantContextFound
    case apiError(String)

    var errorDescription: String? {
        switch self {
        case .retrievalFailed: return "Failed to search through your notes."
        case .noRelevantContextFound: return "I couldn't find any notes related to your question."
        case .apiError(let msg): return "AI Error: \(msg)"
        }
    }
}

// MARK: - Retrieval Service

/// An actor responsible for searching through the user's notes.
/// We use an `actor` to ensure that searching through a potentially large 
/// collection of notes is thread-safe and doesn't block the Main Actor.
actor NoteRetriever {
    private let notes: [Note]

    init(notes: [Note]) {
        self.notes = notes
    }

    /// Simulates a semantic search or keyword search.
    /// - Parameter query: The user's natural language question.
    /// - Returns: The most relevant note found.
    /// - Throws: `AssistantError.noRelevantContextFound` if no match is found.
    func findMostRelevantNote(for query: String) async throws -> Note {
        // In a real-world RAG application, this is where you would:
        // 1. Convert the query into a vector embedding.
        // 2. Perform a cosine similarity search against a Vector Database.
        
        // For this beginner example, we perform a simple keyword match.
        let queryWords = query.lowercased().components(separatedBy: .whitespacesAndNewlines)
        
        let match = notes.first { note in
            queryWords.contains { word in
                note.content.lowercased().contains(word) && word.count > 3
            }
        }

        // Simulate network/processing latency
        try await Task.sleep(for: .seconds(0.5))

        guard let foundNote = match else {
            throw AssistantError.noRelevantContextFound
        }
        
        return foundNote
    }
}

// MARK: - LLM Service

/// A service that handles communication with the OpenAI API.
struct LLMService {
    /// Simulates a call to an LLM like GPT-4o.
    /// - Parameters:
    ///   - augmentedPrompt: The prompt containing both context and the user query.
    /// - Returns: The string response from the AI.
    func generateResponse(from augmentedPrompt: String) async throws -> String {
        // In a real app, this would use URLSession to call:
        // https://api.openai.com/v1/chat/completions
        
        print("--- SENDING TO LLM ---\n\(augmentedPrompt)\n--- END PROMPT ---")
        
        // Simulating network delay
        try await Task.sleep(for: .seconds(1.5))
        
        // Mocking a successful response
        return "Based on your notes, you are planning to visit the Shibuya Crossing and eat ramen in Tokyo next Tuesday!"
    }
}

// MARK: - ViewModel (The Orchestrator)

/// The ViewModel manages the UI state and orchestrates the RAG workflow.
/// It uses the `@Observable` macro (introduced in iOS 17) for modern SwiftUI integration.
@Observable
@MainActor
class NoteAssistantViewModel {
    /// The user's current input.
    var userQuery: String = ""
    
    /// The final response displayed to the user.
    var assistantResponse: String = ""
    
    /// Indicates if the assistant is currently "thinking."
    var isProcessing: Bool = false
    
    /// Error message to display in the UI.
    var errorMessage: String?

    private let retriever: NoteRetriever
    private let llmService: LLMService

    init(notes: [Note]) {
        self.retriever = NoteRetriever(notes: notes)
        self.llmService = LLMService()
    }

    /// The core RAG workflow: Retrieve -> Inject -> Generate.
    func askQuestion() async {
        // Reset state for a new request
        isProcessing = true
        errorMessage = nil
        assistantResponse = ""

        do {
            // 1. RETRIEVAL STEP
            // We call the actor to find relevant information.
            let relevantNote = try await retriever.findMostRelevantNote(for: userQuery)

            // 2. CONTEXT INJECTION STEP
            // We construct a "Sandwich Prompt." 
            // We define the persona, provide the context, and then the question.
            let augmentedPrompt = """
            You are a helpful personal assistant. Use the provided context below to answer the user's question.
            If the answer is not in the context, say you don't know.

            ### CONTEXT ###
            \(relevantNote.content)

            ### USER QUESTION ###
            \(userQuery)

            ### ANSWER ###
            """

            // 3. GENERATION STEP
            // Send the augmented prompt to the LLM.
            let response = try await llmService.generateResponse(from: augmentedPrompt)
            
            // Update UI on the MainActor (guaranteed by @MainActor on the class)
            self.assistantResponse = response

        } catch let error as AssistantError {
            self.errorMessage = error.localizedDescription
        } catch {
            self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
        }

        isProcessing = false
    }
}

// MARK: - Execution Entry Point

@available(iOS 18.0, macOS 15.0, *)
@main
struct SmartNoteApp {
    static func main() async {
        // Mock Data: Our "Database" of notes
        let myNotes = [
            Note(id: UUID(), content: "Grocery list: Milk, Eggs, Bread, Coffee.", timestamp: Date()),
            Note(id: UUID(), content: "Tokyo Trip: Visit Shibuya Crossing, eat ramen in Shinjuku, and see the temples in Asakusa.", timestamp: Date()),
            Note(id: UUID(), content: "Work: Finish the Swift 6 concurrency module by Friday.", timestamp: Date())
        ]

        let viewModel = NoteAssistantViewModel(notes: myNotes)

        print("--- SMART NOTE ASSISTANT START ---")
        print("User asks: 'What is my plan for Tokyo?'")
        
        // Simulate user input
        viewModel.userQuery = "What is my plan for Tokyo?"
        
        // Start the async process
        await viewModel.askQuestion()

        if let response = viewModel.assistantResponse, !response.isEmpty {
            print("\nASSISTANT RESPONSE:\n\(response)")
        }

        if let error = viewModel.errorMessage {
            print("\nERROR: \(error)")
        }
        
        print("\n--- SESSION END ---")
    }
}
