
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import Foundation
import Observation // Required for @Observable

@available(iOS 18.0, *)
@Observable
class MLXViewModel {
    var inputTensor: MLXArray
    var outputTensor: MLXArray?
    var statusMessage: String = "Ready"

    // Assume a simple linear model for demonstration
    private var model: LinearLayer

    init() {
        self.inputTensor = MLXArray.zeros([1, 5], .float32) // Default input
        self.model = LinearLayer(inputFeatures: 5, outputFeatures: 2)
    }

    func performInference() async {
        statusMessage = "Inferring..."
        do {
            // Simulate async inference
            try await Task.sleep(for: .milliseconds(500))
            let result = model(inputTensor)
            await MainActor.run {
                self.outputTensor = result
                self.statusMessage = "Inference complete!"
            }
        } catch {
            await MainActor.run {
                self.statusMessage = "Error: \(error.localizedDescription)"
            }
        }
    }

    // Example of updating input reactively
    func updateInput(newValue: [Float]) {
        guard newValue.count == inputTensor.shape[1] else { return }
        self.inputTensor = MLXArray(newValue, [1, inputTensor.shape[1]], .float32)
        self.statusMessage = "Input updated."
    }
}

// In a SwiftUI View:
/*
@available(iOS 18.0, *)
struct InferenceView: View {
    @State private var viewModel = MLXViewModel()

    var body: some View {
        VStack {
            Text("Status: \(viewModel.statusMessage)")
            if let output = viewModel.outputTensor {
                Text("Output: \(output.description)")
            }
            Button("Perform Inference") {
                Task {
                    await viewModel.performInference()
                }
            }
            Button("Update Input") {
                viewModel.updateInput(newValue: [0.1, 0.2, 0.3, 0.4, 0.5])
            }
        }
    }
}
*/
