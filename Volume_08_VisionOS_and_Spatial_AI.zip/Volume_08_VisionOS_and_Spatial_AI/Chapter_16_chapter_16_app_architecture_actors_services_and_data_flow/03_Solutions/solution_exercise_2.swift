
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
struct ChatMessage: Identifiable, Sendable {
    let id: UUID
    let role: MessageRole
    var content: String
}

enum MessageRole: Sendable {
    case user, assistant
}

@available(iOS 18.0, *)
@Observable
@MainActor // Ensures all UI updates happen on the main thread
class ChatViewModel {
    var messages: [ChatMessage] = []
    
    /// Adds a completely new message to the history
    func appendMessage(_ message: ChatMessage) {
        messages.append(message)
    }
    
    /// Updates the content of the very last message. 
    /// Used for streaming tokens from an LLM.
    func updateLastMessage(with token: String) {
        guard !messages.isEmpty else { return }
        // Since this is @MainActor, we can safely mutate the array
        if messages.count > 0 {
            messages[messages.count - 1].content += token
        }
    }
}

// --- Implementation Challenge ---
@available(iOS 18.0, *)
struct ChatViewSimulation {
    func simulateStreaming() async {
        let viewModel = ChatViewModel()
        
        // 1. User sends a message
        let userMsg = ChatMessage(id: UUID(), role: .user, content: "Hello AI!")
        await viewModel.appendMessage(userMsg)
        
        // 2. Create an AsyncStream to simulate LLM token streaming
        let tokenStream = AsyncStream<String> { continuation in
            Task {
                let tokens = [" Hi", ", ", " how", " can", " I", " help", " you", " today", "?"]
                for token in tokens {
                    try? await Task.sleep(for: .milliseconds(100))
                    continuation.yield(token)
                }
                continuation.finish()
            }
        }
        
        // 3. Append the assistant's empty message placeholder
        await viewModel.appendMessage(ChatMessage(id: UUID(), role: .assistant, content: ""))
        
        // 4. Consume the stream
        // Even if this loop runs on a background task, 
        // the @MainActor on ChatViewModel forces the update to the main thread.
        for await token in tokenStream {
            await viewModel.updateLastMessage(with: token)
            print("Current UI Content: \(viewModel.messages.last?.content ?? "")")
        }
    }
}
