
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import AppIntents
import SwiftUI

// MARK: - Models

/// A representation of a Journal Entry that the system can understand.
/// By conforming to `AppEntity`, we allow Apple Intelligence to "see" and 
/// "index" our data semantically.
@available(iOS 18.0, *)
struct JournalEntry: AppEntity, Codable {
    /// The unique identifier for the entry, required by AppEntity.
    let id: UUID
    
    /// The actual text content of the journal entry.
    let content: String
    
    /// The timestamp of when the entry was created.
    let timestamp: Date
    
    /// The display name used by the system when referring to this entity.
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Journal Entry"
    
    /// Provides the system with a way to identify and display a specific instance.
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(
            title: "\(timestamp.formatted(date: .abbreviated, time: .shortened))",
            subtitle: "Journal Entry"
        )
    }
    
    /// Required for AppEntity to allow the system to fetch the entity from a data store.
    static var defaultQuery: JournalEntryQuery = JournalEntryQuery()
}

// MARK: - Data Management

/// An Actor responsible for managing journal data.
/// We use an `actor` to ensure thread-safety in a Swift 6 environment, 
/// preventing data races when multiple intents or UI components access the data.
@available(iOS 18.0, *)
actor JournalManager {
    static let shared = JournalManager()
    
    private var entries: [JournalEntry] = [
        JournalEntry(id: UUID(), content: "Had a great coffee this morning while coding Swift 6.", timestamp: Date()),
        JournalEntry(id: UUID(), content: "Feeling a bit overwhelmed by the new concurrency rules.", timestamp: Date().addingTimeInterval(-86400))
    ]
    
    /// Returns the most recent entry.
    func fetchLatestEntry() async -> JournalEntry? {
        return entries.sorted(by: { $0.timestamp > $1.timestamp }).first
    }
    
    /// Returns all entries for semantic indexing.
    func fetchAllEntries() async -> [JournalEntry] {
        return entries
    }
}

// MARK: - Intent Implementation

/// The core capability we are exposing to Apple Intelligence.
/// This intent allows the system to summarize a specific journal entry.
@available(iOS 18.0, *)
struct SummarizeEntryIntent: AppIntent {
    /// The title of the intent as seen by the system/Siri.
    static var title: LocalizedStringResource = "Summarize Journal Entry"
    
    /// A description that helps the LLM understand when to use this intent.
    static var description = IntentDescription("Summarizes the content of a specific journal entry to provide a brief overview.")

    /// The parameter that tells the system which entry to summarize.
    /// Using `AppEntity` here is crucial; it allows the LLM to map 
    /// "that entry from this morning" to a specific `JournalEntry` object.
    @Parameter(title: "Journal Entry")
    var entry: JournalEntry

    /// The primary execution logic of the intent.
    /// This is called by the system when the intent is triggered.
    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        // 1. Perform the 'AI' work. 
        // In a real-world scenario, this would call a local CoreML model 
        // or a Private Cloud Compute (PCC) endpoint.
        let summary = try await AIService.shared.generateSummary(for: entry.content)
        
        // 2. Return the result.
        // The returned string can be spoken by Siri or displayed in the UI.
        return .result(value: summary)
    }
}

// MARK: - Querying

/// The Query allows the system to find `JournalEntry` entities.
/// This is how the LLM "finds" the correct data to pass to the Intent.
@available(iOS 18.0, *)
struct JournalEntryQuery: EntityQuery {
    /// Searches for an entry by its ID.
    func entities(for identifiers: [UUID]) async throws -> [JournalEntry] {
        let all = await JournalManager.shared.fetchAllEntries()
        return all.filter { identifiers.contains($0.id) }
    }
    
    /// Provides the system with the ability to search entries.
    /// This is vital for Apple Intelligence to perform semantic searches.
    func entities(matching query: String) async throws -> [JournalEntry] {
        let all = await JournalManager.shared.fetchAllEntries()
        // In a real app, you would use a vector database or fuzzy search here.
        return all.filter { $0.content.localizedCaseInsensitiveContains(query) }
    }
}

// MARK: - Mock AI Service

/// A service simulating the interaction with an On-Device LLM.
@available(iOS 18.0, *)
actor AIService {
    static let shared = AIService()
    
    /// Simulates an asynchronous call to a generative model.
    func generateSummary(for text: String) async throws -> String {
        // Simulate network or compute latency
        try await Task.sleep(for: .seconds(1.5))
        
        // Mocked logic: In reality, this would be an Apple Intelligence API call.
        if text.contains("Swift 6") {
            return "You had a productive morning working with Swift 6."
        } else {
            return "A brief reflection on your recent activities."
        }
    }
}
