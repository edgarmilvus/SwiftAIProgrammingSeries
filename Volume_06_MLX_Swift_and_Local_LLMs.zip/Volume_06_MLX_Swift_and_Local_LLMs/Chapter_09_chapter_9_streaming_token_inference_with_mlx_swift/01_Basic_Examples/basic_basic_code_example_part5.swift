
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import MLX
import MLXNN // Ensure these are imported in your main app target as well

// Define a simple text for our tokenizer's vocabulary
let sampleText = "Hello, world! This is a simple MLX Swift streaming example. " +
                 "It demonstrates character-level token generation."

// 1. Initialize the tokenizer
let tokenizer = CharacterTokenizer(text: sampleText)

// 2. Initialize the model
// We'll use a small embedding dimension for this simple example.
let vocabSize = tokenizer.vocabSize
let embedDim = 16 // Small embedding dimension for a character model
let model = SimpleTokenPredictor(vocabSize: vocabSize, embedDim: embedDim)

// For a real model, you would load pre-trained weights here.
// For this example, we'll just initialize with random weights.
// MLX models are initialized with random weights by default.
// You can also explicitly set a random seed for reproducibility:
MLX.seed(0) // Set a global random seed for MLX operations

// --- Simulate a SwiftUI View for a chat interface ---
@available(iOS 17.0, macOS 14.0, *)
struct ChatView: View {
    @State private var chatOutput: String = ""
    @State private var currentPrompt: String = "Hello"
    @State private var isGenerating: Bool = false

    var body: some View {
        VStack {
            ScrollView {
                Text(chatOutput)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(maxHeight: .infinity)

            HStack {
                TextField("Enter prompt", text: $currentPrompt)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .disabled(isGenerating)

                Button("Generate") {
                    generateResponse()
                }
                .disabled(isGenerating)
            }
            .padding()
        }
        .padding()
        .navigationTitle("MLX Chat Demo")
    }

    /// Initiates the token generation process.
    private func generateResponse() {
        isGenerating = true
        chatOutput = "" // Clear previous output for a new generation

        Task {
            // It's crucial to update UI on the MainActor.
            // The `generateStream` function runs in a background Task.
            // Each `yield` from the stream will trigger this loop.
            for await token in model.generateStream(prompt: currentPrompt, tokenizer: tokenizer) {
                // @MainActor ensures UI updates happen on the main thread.
                await MainActor.run {
                    chatOutput += token
                }
            }
            await MainActor.run {
                isGenerating = false
            }
        }
    }
}

// --- How you might use it in your App's entry point ---
@main
@available(iOS 17.0, macOS 14.0, *)
struct MLXStreamingApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ChatView()
            }
        }
    }
}
