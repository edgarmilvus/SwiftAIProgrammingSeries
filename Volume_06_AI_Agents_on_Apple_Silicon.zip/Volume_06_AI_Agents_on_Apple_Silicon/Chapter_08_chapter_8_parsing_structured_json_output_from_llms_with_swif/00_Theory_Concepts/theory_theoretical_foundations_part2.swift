
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    // Hypothetical utility for robust partial JSON decoding
    struct PartialJSONDecoder {
        private var buffer = Data()
        private let decoder = JSONDecoder()

        mutating func append(chunk: String) {
            if let data = chunk.data(using: .utf8) {
                buffer.append(data)
            }
        }

        mutating func decode<T: Decodable>(type: T.Type) throws -> T? {
            do {
                // Attempt to decode the current buffer.
                // If it's a complete, valid JSON, it will succeed.
                let result = try decoder.decode(type, from: buffer)
                // If successful, clear the buffer as the object is parsed
                buffer.removeAll()
                return result
            } catch let DecodingError.dataCorrupted(context) {
                // This is expected for partial JSON. We just return nil and wait for more data.
                // You might log context.debugDescription for debugging.
                return nil
            } catch let DecodingError.keyNotFound(key, context) {
                 // May also happen for partial JSON where a key is expected but not yet received
                 return nil
            } catch {
                // Other errors (e.g., type mismatch, value not found for non-optional keys)
                // indicate a true parsing failure or malformed JSON.
                print("Decoding failed with unexpected error: \(error.localizedDescription)")
                throw error // Re-throw fatal errors
            }
        }
    }
    