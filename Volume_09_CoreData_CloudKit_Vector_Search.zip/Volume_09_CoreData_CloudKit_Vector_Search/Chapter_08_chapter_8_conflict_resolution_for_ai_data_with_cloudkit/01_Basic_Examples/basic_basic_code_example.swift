
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CloudKit
import Observation

/// Represents a single unit of AI-generated memory.
/// In a real app, this would be backed by CoreData, but here we model it 
/// directly as a CKRecord wrapper for clarity.
@Observable
@available(iOS 18.0, *)
final class AIVoiceMemory {
    let recordID: CKRecord.ID
    var summary: String
    var userPreference: String
    var lastUpdated: Date
    
    /// Initializer for a new local memory
    init(recordID: CKRecord.ID, summary: String, userPreference: String) {
        self.recordID = recordID
        self.summary = summary
        self.userPreference = userPreference
        self.lastUpdated = Date()
    }
    
    /// Converts the local properties into a CKRecord for CloudKit transport.
    func asCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "MemoryLog", recordID: recordID)
        record["summary"] = summary as CKRecordValue
        record["userPreference"] = userPreference as CKRecordValue
        record["lastUpdated"] = lastUpdated as CKRecordValue
        return record
    }
    
    /// Updates the local object using data from a CKRecord (used during sync).
    func update(from record: CKRecord) {
        self.summary = record["summary"] as? String ?? ""
        self.userPreference = record["userPreference"] as? String ?? ""
        self.lastUpdated = record["lastUpdated"] as? Date ?? Date()
    }
}

/// A service responsible for synchronizing AI memories with CloudKit,
/// featuring advanced conflict resolution logic.
@available(iOS 18.0, *)
final class CloudKitSyncService {
    private let container = CKContainer.default()
    private let privateDatabase = CKContainer.default().privateCloudDatabase
    
    enum SyncError: Error {
        case recordNotFound
        case unresolvableConflict
        case unknown(Error)
    }

    /// Attempts to save an AI memory to CloudKit.
    /// If a conflict is detected, it automatically attempts to resolve it.
    /// - Parameter memory: The local memory object to save.
    func saveMemory(_ memory: AIVoiceMemory) async throws {
        let recordToSave = memory.asCKRecord()
        
        do {
            // We use the modern async API for simplicity, but for granular 
            // error handling in complex scenarios, CKModifyRecordsOperation 
            // is often wrapped in a CheckedContinuation.
            try await performSave(recordToSave)
            print("Successfully saved memory: \(memory.summary)")
        } catch let error as CKError {
            // Check if the error is specifically a conflict
            if error.code == .serverRecordChanged {
                print("Conflict detected. Initiating Three-Way Merge...")
                try await resolveConflict(error: error, localMemory: memory)
            } else {
                throw SyncError.unknown(error)
            }
        } catch {
            throw SyncError.unknown(error)
        }
    }

    /// The low-level save operation.
    private func performSave(_ record: CKRecord) async throws {
        // In a real-world production app, you would use CKModifyRecordsOperation
        // to set the savePolicy to .ifServerRecordUnchanged.
        // For this example, we use the convenience API which behaves similarly.
        try await privateDatabase.save(record)
    }

    /// Extracts the conflicting records from the CKError and applies a merge policy.
    /// - Parameters:
    ///   - error: The caught CKError containing the three versions of the record.
    ///   - localMemory: The local object that needs to be updated/re-saved.
    private func resolveConflict(error: CKError, localMemory: AIVoiceMemory) async throws {
        // 1. Extract the three pillars of the Three-Way Merge
        // These are provided by CloudKit inside the error's userInfo dictionary.
        guard let ancestorRecord = error.ancestorRecord,
              let serverRecord = error.serverRecord,
              let clientRecord = error.clientRecord else {
            print("Critical Error: Missing record versions in CKError.")
            throw SyncError.unresolvableConflict
        }

        print("--- Conflict Resolution Details ---")
        print("Ancestor Summary: \(ancestorRecord["summary"] as? String ?? "None")")
        print("Server Summary:   \(serverRecord["summary"] as? String ?? "None")")
        print("Client Summary:   \(clientRecord["summary"] as? String ?? "None")")

        // 2. Create a 'Merged Record' based on the Server Record.
        // We MUST start with the server record to ensure we have the latest ETag/ChangeTag.
        let mergedRecord = serverRecord

        // 3. Apply Semantic Merge Logic
        // Strategy: For text 'summary', we append changes. For 'userPreference', we use Last Write Wins.
        
        // A. Semantic Merge for 'summary' (Concatenation approach)
        let ancestorSummary = ancestorRecord["summary"] as? String ?? ""
        let clientSummary = clientRecord["summary"] as? String ?? ""
        let serverSummary = serverRecord["summary"] as? String ?? ""

        if clientSummary != ancestorSummary && serverSummary != ancestorSummary {
            // Both client and server changed the summary!
            // We merge them by combining unique information.
            mergedRecord["summary"] = "\(serverSummary) | \(clientSummary)" as CKRecordValue
        } else if clientSummary != ancestorSummary {
            // Only the client changed it.
            mergedRecord["summary"] = clientSummary as CKRecordValue
        } else {
            // Only the server changed it (or neither), so keep server's version.
            mergedRecord["summary"] = serverSummary as CKRecordValue
        }

        // B. Last-Write-Wins Merge for 'userPreference'
        let clientDate = clientRecord["lastUpdated"] as? Date ?? Date.distantPast
        let serverDate = serverRecord["lastUpdated"] as? Date ?? Date.distantPast

        if clientDate > serverDate {
            mergedRecord["userPreference"] = clientRecord["userPreference"] as? CKRecordValue
            mergedRecord["lastUpdated"] = clientDate as CKRecordValue
        } else {
            // Keep the server's preference and date
            mergedRecord["userPreference"] = serverRecord["userPreference"] as? CKRecordValue
            mergedRecord["lastUpdated"] = serverDate as CKRecordValue
        }

        // 4. Attempt to save the merged record
        do {
            try await performSave(mergedRecord)
            
            // 5. Update the local UI-facing model with the final merged state
            // This ensures the app reflects exactly what is now on the server.
            await MainActor.run {
                localMemory.update(from: mergedRecord)
                print("Conflict resolved successfully via Semantic Merge.")
            }
        } catch {
            // If it fails again, there might be another concurrent change.
            // In a production app, you would implement a retry limit or recursive call.
            print("Failed to save merged record: \(error)")
            throw SyncError.unresolvableConflict
        }
    }
}

// MARK: - Execution Simulation

@available(iOS 18.0, *)
@MainActor
func runConflictDemo() async {
    let syncService = CloudKitSyncService()
    let memoryID = CKRecord.ID(recordName: "user_memory_001")
    
    // 1. Initial State
    let localMemory = AIVoiceMemory(
        recordID: memoryID,
        summary: "User likes coffee.",
        userPreference: "Dark Mode"
    )
    
    print("Initial Local State: \(localMemory.summary), \(localMemory.userPreference)")
    
    // 2. Simulate a successful first save
    // (In a real app, this would actually hit the network)
    print("\n--- Step 1: Initial Sync ---")
    // try? await syncService.saveMemory(localMemory) 

    // 3. Simulate a conflict scenario
    // We manually trigger the logic to demonstrate how the resolver handles the data.
    print("\n--- Step 2: Simulating Conflict ---")
    
    // Let's mock the error components
    let ancestor = CKRecord(recordType: "MemoryLog", recordID: memoryID)
    ancestor["summary"] = "User likes coffee."
    ancestor["userPreference"] = "Dark Mode"
    
    let server = CKRecord(recordType: "MemoryLog", recordID: memoryID)
    server["summary"] = "User likes coffee and tea." // Server changed
    server["userPreference"] = "Dark Mode"
    
    let client = CKRecord(recordType: "MemoryLog", recordID: memoryID)
    client["summary"] = "User likes coffee and decaf." // Client changed
    client["userPreference"] = "Light Mode" // Client changed preference too
    
    // Construct a mock error (In reality, CloudKit provides this)
    // Note: In a real unit test, you'd subclass or mock the error, 
    // but here we describe the logic flow.
    
    // For demonstration purposes, we'll simulate the resolution logic directly
    // as if the 'resolveConflict' method was called by the catch block.
    
    print("Simulating resolution logic...")
    // (Implementation details inside resolveConflict would run here)
}
