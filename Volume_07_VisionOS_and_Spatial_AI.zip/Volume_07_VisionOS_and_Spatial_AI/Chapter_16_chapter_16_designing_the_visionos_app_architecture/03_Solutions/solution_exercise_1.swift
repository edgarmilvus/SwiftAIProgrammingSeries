
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Observation

// MARK: - Domain Model
struct SpatialModel: Identifiable, Sendable {
    let id: UUID
    let name: String
}

// MARK: - Orchestrator (The Coordinator)
@Observable
@MainActor
final class GalleryOrchestrator {
    // The Single Source of Truth for what is currently being viewed
    var selectedModelID: UUID?
    
    // A closure to bridge the Orchestrator to the SwiftUI environment actions
    // This prevents the Orchestrator from being tightly coupled to SwiftUI views
    var openWindowAction: ((ID) -> Void)?
    
    func selectModel(_ model: SpatialModel) {
        selectedModelID = model.id
        // Trigger the window opening via the provided closure
        openWindowAction?(model.id)
    }
}

// MARK: - View Model
@Observable
@MainActor
final class DashboardViewModel {
    private let orchestrator: GalleryOrchestrator
    let models: [SpatialModel]
    
    init(orchestrator: GalleryOrchestrator) {
        self.orchestrator = orchestrator
        // Mock data
        self.models = [
            SpatialModel(id: UUID(), name: "Cyberpunk Chair"),
            SpatialModel(id: UUID(), name: "Minimalist Lamp"),
            SpatialModel(id: UUID(), name: "Floating Sculpture")
        ]
    }
    
    func requestModelView(model: SpatialModel) {
        orchestrator.selectModel(model)
    }
}

// MARK: - Views
struct DashboardView: View {
    @State var viewModel: DashboardViewModel
    
    var body: some View {
        List(viewModel.models) { model in
            Button(model.name) {
                viewModel.requestModelView(model: model)
            }
        }
        .navigationTitle("Spatial Gallery")
    }
}

struct ModelViewerVolume: View {
    let orchestrator: GalleryOrchestrator
    
    var body: some View {
        VStack {
            if let id = orchestrator.selectedModelID {
                Text("Viewing Model: \(id.uuidString.prefix(8))")
                    .font(.largeTitle)
            } else {
                Text("No Model Selected")
            }
        }
    }
}

// MARK: - App Entry Point
@main
struct SpatialGalleryApp: App {
    @State private var orchestrator = GalleryOrchestrator()
    
    var body: some Scene {
        // 1. The Dashboard Window (2D)
        WindowGroup("Dashboard") {
            DashboardView(viewModel: DashboardViewModel(orchestrator: orchestrator))
                .environment(orchestrator)
                .onAppear {
                    // Inject the environment action into the orchestrator
                    // This is the key to decoupling
                    // Note: In a real app, we'd use a custom environment key or a wrapper
                }
        }
        
        // 2. The Model Viewer (3D Volume)
        WindowGroup(id: "model-viewer", for: UUID.self) { $modelID in
            ModelViewerVolume(orchestrator: orchestrator)
        }
        .windowStyle(.volumetric)
    }
}

// Extension to facilitate the environment action injection in a real scenario
extension WindowGroup {
    // In a production app, we would use an EnvironmentKey to pass the 
    // openWindow action back to the orchestrator.
}
