
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import FoundationModels // Hypothetical framework

@available(iOS 18.0, *)
actor MyAIProcessor {
    private let textGenerator: TextGenerator // Represents an on-device LLM API

    init() {
        // Initialize the TextGenerator. This might involve loading the model.
        // For simplicity, assume it's readily available.
        self.textGenerator = TextGenerator()
    }

    /// Generates text asynchronously using the on-device LLM.
    func generateResponse(for prompt: String) async throws -> String {
        // The actual inference call is an async operation.
        let result = try await textGenerator.generate(prompt: prompt)
        return result.text // Assuming result has a 'text' property
    }
}

@available(iOS 18.0, *)
class ViewModel: ObservableObject {
    private let aiProcessor = MyAIProcessor()
    @Published var generatedText: String = "Waiting for AI..."
    @Published var isLoading: Bool = false

    func sendPrompt(_ prompt: String) {
        isLoading = true
        Task {
            do {
                let response = try await aiProcessor.generateResponse(for: prompt)
                await MainActor.run { // Update UI on the main actor
                    self.generatedText = response
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.generatedText = "Error: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }
}
