
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import MLX
import MLXNN // For MLXNN.Module
import Foundation // For Task.sleep

// All code in this example requires Swift 6 and iOS 18.0 / macOS 15.0+
// due to the use of @Observable and newer concurrency features.
@available(iOS 18.0, macOS 15.0, *)

// MARK: - 1. The MLX-Simulated Token Generator

/// In a real-world scenario, this would be an actual LLM (e.g., Llama-2, Mistral) loaded
/// and running inference via MLX Swift. For this basic example, we simulate the token
/// generation process while adhering to MLX Swift guidelines by using `MLXArray`
/// and inheriting from `MLXNN.Module`. This allows us to explain core MLX concepts
/// even with a simplified "model."
///
/// **MLX Swift Concepts Demonstrated:**
/// - Inheriting from `MLXNN.Module` for model definition.
/// - Using `MLXArray` for tensor operations.
/// - Explanation of 'lazy evaluation' and 'Unified Memory'.
class SimpleMLXGenerator: MLXNN.Module {

    /// A dummy MLXArray to demonstrate basic MLX operations and lazy evaluation.
    /// In a real LLM, this might represent model weights or intermediate activations.
    /// We initialize it here to have a persistent `MLXArray` instance.
    let dummyWeights: MLXArray

    /// Initializes the generator.
    /// - Parameter name: An optional name for the module.
    init(name: String? = nil) {
        // Call the superclass initializer for MLXNN.Module
        super.init(name: name)

        // Create a dummy MLXArray. This operation is lazily evaluated.
        // It's a placeholder to show MLXArray usage.
        self.dummyWeights = MLXArray.randomUniform(
            shape: [1, 1024], // A common size for embeddings or hidden states
            min: 0,
            max: 1
        )
        // At this point, `dummyWeights` is just a description of a computation graph.
        // No actual random numbers have been generated in memory yet.
        print("MLX: Initialized dummyWeights (lazy MLXArray). Shape: \(dummyWeights.shape)")
    }

    /// A placeholder `callAsFunction` for `MLXNN.Module`.
    /// In a real model, this would define the forward pass computation.
    /// For this simulation, it just returns a dummy `MLXArray` to satisfy the `MLXNN.Module` structure.
    /// - Parameter input: A dummy input `MLXArray`.
    /// - Returns: A dummy output `MLXArray`.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // This is where actual model logic would reside.
        // For demonstration, let's perform a simple, lazily evaluated operation.
        // Example: add a slice of dummyWeights to the input.
        let processedInput = input + dummyWeights[0, 0..<input.shape[1]]
        print("MLX: Performed a dummy operation in callAsFunction (lazy evaluation).")
        return MLXArray.softmax(processedInput) // Another lazy operation
    }

    /// Simulates streaming token generation from an LLM.
    /// This method returns an `AsyncThrowingStream` that emits tokens one by one.
    ///
    /// **Under the Hood (MLX Integration):**
    /// While the *content* of the tokens is hardcoded for simplicity, we integrate MLX
    /// by performing a dummy computation with `MLXArray` *before* generating tokens.
    /// This demonstrates:
    /// 1. **Lazy Evaluation:** The `MLXArray` operations (like `dummyWeights.eval()`)
    ///    are only computed when `eval()` is called. Until then, they merely define
    ///    a computation graph.
    /// 2. **Unified Memory:** `MLXArray` instances directly utilize Apple Silicon's Unified Memory.
    ///    When `eval()` or `toArray()` is called, the computation happens efficiently
    ///    on the available hardware (CPU/GPU) without explicit memory copies between them.
    ///    This is a "zero-copy" benefit, crucial for performance.
    ///
    /// - Parameter prompt: The user's input prompt (unused in this simulation, but typical for LLMs).
    /// - Returns: An `AsyncThrowingStream` of `String` tokens.
    func generateStream(prompt: String) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                do {
                    // --- MLX Integration Point ---
                    // Perform a dummy MLX computation to demonstrate lazy evaluation.
                    // In a real LLM, this would be the actual inference loop,
                    // where logits are computed, sampled, and then converted to tokens.

                    // Forcing evaluation of `dummyWeights` to demonstrate eager computation.
                    // This would typically happen implicitly as part of a forward pass
                    // or when results are needed (e.g., `toArray()`).
                    print("MLX: Forcing evaluation of dummyWeights to demonstrate eager computation.")
                    _ = dummyWeights.eval() // Explicitly trigger computation
                    print("MLX: dummyWeights evaluated. Value is now concrete in memory (Unified Memory).")

                    // Another dummy MLX operation to show chaining.
                    let result = self.callAsFunction(MLXArray.ones(shape: [1, 1024])) // This operation is still lazy
                    print("MLX: Chained another MLX operation (still lazy).")

                    // If we needed the concrete values from `result` for some reason (e.g.,
                    // to decide what tokens to generate based on actual logits),
                    // we would call `toArray()` or `eval()` here.
                    // For this example, we'll just simulate token generation.
                    // _ = result.toArray(Float.self) // This would force computation and materialization.
                    // --- End MLX Integration Point ---

                    let fullResponse = "Hello there! I am a simple MLX-powered chatbot. " +
                                       "I can stream responses to you in real-time. " +
                                       "How may I assist you today? " +
                                       "This demonstrates token-by-token generation."
                    let words = fullResponse.split(separator: " ").map { String($0) + " " }

                    for (index, word) in words.enumerated() {
                        // Simulate network/computation delay to mimic real LLM inference time
                        try await Task.sleep(for: .milliseconds(index == 0 ? 500 : 100))
                        continuation.yield(word) // Emit the next token
                    }
                    continuation.finish() // Signal the end of the stream
                } catch {
                    continuation.finish(throwing: error) // Propagate any errors
                }
            }
        }
    }
}

// MARK: - 2. The ViewModel for UI Logic and Data Flow

/// This `ChatViewModel` acts as the bridge between our `SimpleMLXGenerator`
/// and the SwiftUI `ContentView`. It manages the chat state, initiates token streaming,
/// and updates the UI-bound properties.
///
/// **SwiftUI/Concurrency Concepts Demonstrated:**
/// - `@Observable` (iOS 17+ / Swift 6) for reactive UI updates.
/// - `Task` for structured concurrency.
/// - `@MainActor` for ensuring UI updates happen on the main thread.
/// - `AsyncThrowingStream` consumption using `for await`.
@available(iOS 18.0, macOS 15.0, *)
@Observable
class ChatViewModel {
    /// The current response being streamed, displayed in the UI.
    var currentResponse: String = ""
    /// The user's input prompt.
    var promptInput: String = ""
    /// Indicates if a response is currently being generated.
    var isGenerating: Bool = false
    /// An optional error message to display to the user.
    var errorMessage: String?

    // Our MLX-simulated model instance.
    // This is typically a long-lived object as model loading can be expensive.
    private let generator = SimpleMLXGenerator()

    /// Sends the user's message and initiates the token streaming process.
    /// - Parameter prompt: The user's input string.
    func sendMessage(prompt: String) {
        guard !isGenerating else { return } // Prevent multiple simultaneous generations

        currentResponse = "" // Clear previous response
        isGenerating = true
        errorMessage = nil

        Task {
            // @MainActor is implicitly applied here because `currentResponse` is an @Observable
            // property and its mutation will trigger UI updates. For clarity and
            // to explicitly state UI-related work, it's good practice to be aware of it.
            // For older SwiftUI versions or non-Observable objects, `@MainActor` is crucial
            // when updating UI properties from a background `Task`.

            do {
                // The `generator.generateStream` method returns an `AsyncThrowingStream`.
                // We iterate over this stream using `for await` to process each token
                // as it becomes available.
                for await token in generator.generateStream(prompt: prompt) {
                    currentResponse += token // Append token to the UI-bound string
                }
            } catch {
                // Handle any errors that occurred during streaming
                errorMessage = "Error generating response: \(error.localizedDescription)"
                print("Error during token streaming: \(error)")
            }

            // Ensure UI state is reset on completion (success or error)
            isGenerating = false
        }
    }
}

// MARK: - 3. The SwiftUI View for Display

/// This `ContentView` provides the user interface for our chat application.
/// It uses SwiftUI's declarative syntax to display the input field, send button,
/// and the streamed bot response.
///
/// **SwiftUI Concepts Demonstrated:**
/// - `@Observable` usage for automatic UI updates.
/// - `TextField` for user input.
/// - `Button` for actions.
/// - `ScrollView` and `Text` for displaying the chat history.
@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    /// The ViewModel instance, observed for changes to automatically update the UI.
    @State private var viewModel = ChatViewModel() // Using @State for simplicity; @StateObject for older iOS

    var body: some View {
        VStack {
            Text("MLX Swift Streaming Chat")
                .font(.largeTitle)
                .padding()

            // Display streamed response
            ScrollView {
                Text(viewModel.currentResponse)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                    // Smooth token append animation for a better user experience
                    .animation(.linear(duration: 0.1), value: viewModel.currentResponse)
            }
            .padding(.horizontal)
            .frame(maxHeight: .infinity)

            // Error message display
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }

            // User input area
            HStack {
                TextField("Enter your message...", text: $viewModel.promptInput)
                    .textFieldStyle(.roundedBorder)
                    .padding(.vertical, 8)
                    .disabled(viewModel.isGenerating) // Disable input while generating

                Button("Send") {
                    viewModel.sendMessage(prompt: viewModel.promptInput)
                    viewModel.promptInput = "" // Clear input after sending
                }
                .buttonStyle(.borderedProminent)
                // Disable if input is empty or a response is already generating
                .disabled(viewModel.promptInput.isEmpty || viewModel.isGenerating)
            }
            .padding()
        }
    }
}

// MARK: - Preview Provider (for Xcode Canvas)
@available(iOS 18.0, macOS 15.0, *)
#Preview {
    ContentView()
}
