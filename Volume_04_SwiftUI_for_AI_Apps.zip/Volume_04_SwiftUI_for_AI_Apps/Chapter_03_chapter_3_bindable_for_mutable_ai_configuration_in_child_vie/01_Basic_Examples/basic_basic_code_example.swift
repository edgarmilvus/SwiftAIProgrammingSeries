
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation // Required for @Observable

// MARK: - 1. Define the AI Configuration Model

/// @Observable: Makes the class observable, allowing SwiftUI views to react to changes in its properties.
/// This is the modern replacement for ObservableObject and is more efficient.
/// @MainActor: Ensures that all property changes and view updates related to this model happen on the main thread.
/// While not strictly necessary for simple property changes, it's a good practice for models that might interact
/// with UI or receive updates from background AI processing.
@Observable @MainActor
final class AIConfiguration {
    /// The strength of the AI analysis, from 0.0 (minimal) to 1.0 (maximal).
    /// Used by a Slider in the UI.
    var analysisStrength: Double = 0.5 {
        didSet {
            // Optional: Add validation or side effects here.
            // print("Analysis strength changed to: \(analysisStrength)")
        }
    }

    /// Toggles whether object detection is enabled for image analysis.
    /// Used by a Toggle in the UI.
    var objectDetectionEnabled: Bool = true {
        didSet {
            // print("Object detection enabled: \(objectDetectionEnabled)")
        }
    }

    /// The minimum confidence score for AI predictions to be considered valid.
    /// Used by a Slider in the UI.
    var confidenceThreshold: Double = 0.7 {
        didSet {
            // Ensure threshold stays within valid range.
            confidenceThreshold = max(0.0, min(1.0, confidenceThreshold))
            // print("Confidence threshold changed to: \(confidenceThreshold)")
        }
    }

    /// Represents the currently selected AI model variant (e.g., "Fast", "Balanced", "Accurate").
    /// Used by a Picker in the UI.
    var selectedModelVariant: String = "Balanced" {
        didSet {
            // print("Selected model variant: \(selectedModelVariant)")
        }
    }

    /// All available model variants.
    let modelVariants: [String] = ["Fast", "Balanced", "Accurate"]
}

// MARK: - 2. Parent View: Manages the AI Configuration

/// The main view of our Smart Photo Analyzer app.
/// It owns the AIConfiguration instance and displays its current state.
@available(iOS 17.0, *) // @Bindable requires iOS 17.0 or later
struct PhotoAnalyzerView: View {
    /// @State: Owns the AIConfiguration instance. When properties of this instance change
    /// (even if modified by a child view), PhotoAnalyzerView will re-render.
    @State private var config = AIConfiguration()

    /// @State for showing/hiding the configuration sheet.
    @State private var showingConfigSheet = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Smart Photo Analyzer")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Spacer()

                // Display current configuration values
                Group {
                    Text("Current AI Settings:")
                        .font(.headline)
                    Text("Analysis Strength: \(config.analysisStrength, format: .percent)")
                    Text("Object Detection: \(config.objectDetectionEnabled ? "Enabled" : "Disabled")")
                    Text("Confidence Threshold: \(config.confidenceThreshold, format: .percent)")
                    Text("Model Variant: \(config.selectedModelVariant)")
                }
                .padding(.horizontal)
                .frame(maxWidth: .infinity, alignment: .leading)

                Spacer()

                Button("Configure AI Settings") {
                    showingConfigSheet = true
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .sheet(isPresented: $showingConfigSheet) {
                // Present the AI configuration view as a sheet.
                // @Bindable here creates a binding to the 'config' instance,
                // allowing the child view to directly modify its properties.
                AIConfigurationView(config: config)
            }
            .navigationTitle("Analyzer")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - 3. Child View: Modifies the AI Configuration

/// A child view responsible for allowing the user to modify AI settings.
/// It receives the AIConfiguration instance via @Bindable.
@available(iOS 17.0, *) // @Bindable requires iOS 17.0 or later
struct AIConfigurationView: View {
    /// @Bindable: This property wrapper is crucial. It allows this child view to create
    /// bindings to the properties of the `config` instance. Any changes made through
    /// these bindings will directly update the original `AIConfiguration` instance
    /// owned by the `PhotoAnalyzerView`.
    @Bindable var config: AIConfiguration

    /// Environment value to dismiss the sheet.
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Analysis Parameters") {
                    // Slider for analysis strength
                    VStack(alignment: .leading) {
                        Text("Analysis Strength")
                        Slider(value: $config.analysisStrength, in: 0...1) {
                            Text("Strength")
                        } minimumValueLabel: {
                            Text("Low")
                        } maximumValueLabel: {
                            Text("High")
                        }
                        .tint(.accentColor)
                        Text("Current: \(config.analysisStrength, format: .percent)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }

                    // Toggle for object detection
                    Toggle("Enable Object Detection", isOn: $config.objectDetectionEnabled)
                        .tint(.green)

                    // Slider for confidence threshold
                    VStack(alignment: .leading) {
                        Text("Confidence Threshold")
                        Slider(value: $config.confidenceThreshold, in: 0...1, step: 0.05) {
                            Text("Threshold")
                        } minimumValueLabel: {
                            Text("0%")
                        } maximumValueLabel: {
                            Text("100%")
                        }
                        .tint(.orange)
                        Text("Current: \(config.confidenceThreshold, format: .percent)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }

                Section("Model Selection") {
                    // Picker for selecting AI model variant
                    Picker("Model Variant", selection: $config.selectedModelVariant) {
                        ForEach(config.modelVariants, id: \.self) { variant in
                            Text(variant).tag(variant)
                        }
                    }
                    .pickerStyle(.segmented)
                }
            }
            .navigationTitle("AI Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss() // Dismiss the sheet when done
                    }
                }
            }
        }
    }
}

// MARK: - Preview Provider

@available(iOS 17.0, *)
#Preview {
    PhotoAnalyzerView()
}
