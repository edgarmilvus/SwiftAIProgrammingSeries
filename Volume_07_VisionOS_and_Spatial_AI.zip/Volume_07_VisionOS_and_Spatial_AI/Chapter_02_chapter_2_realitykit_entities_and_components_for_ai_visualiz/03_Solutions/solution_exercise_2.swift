
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import RealityKit
import Foundation

/// Stores the physical dimensions of the detected object.
struct ObjectBoundsComponent: Component, Codable, Sendable {
    var size: SIMD3<Float>
}

@available(visionOS 1.0, *)
class BoundingBoxSystem: System {
    
    /// Define a query to find entities that have both AI data and bounds.
    private static let query = EntityQuery(where: .has(AIInferenceComponent.self) && .has(ObjectBoundsComponent.self))
    
    /// A unique name to identify the visualizer child entity.
    private let visualizerName = "AI_BoundingBox_Visualizer"

    required init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        context.scene.performQuery(Self.query).forEach { entity in
            let bounds = entity.components[ObjectBoundsComponent.self]!.size
            
            // 1. Find or create the visualizer child entity
            let visualizer = entity.findEntity(named: visualizerName) ?? createVisualizer(for: entity)
            
            // 2. Synchronize Transform (Scale and Position)
            // We scale the box to match the bounds provided by the component.
            visualizer.scale = bounds
            
            // The visualizer is a child, so its position is relative to the parent.
            // We center it at the parent's origin.
            visualizer.position = .zero
        }
    }
    
    private func createVisualizer(for parent: Entity) -> Entity {
        // Create a box mesh with a size of 1,1,1 so scaling works intuitively.
        let mesh = MeshResource.generateBox(size: 1.0)
        
        // Use a semi-transparent material.
        var material = UnlitMaterial(color: .cyan.withAlphaComponent(0.3))
        material.blending = .transparent
        
        let modelEntity = ModelEntity(mesh: mesh, materials: [material])
        modelEntity.name = visualizerName
        
        parent.addChild(modelEntity)
        return modelEntity
    }
}

// Helper to find entity by name (extension for clarity)
extension Entity {
    func findEntity(named name: String) -> Entity? {
        if self.name == name { return self }
        for child in children {
            if let found = child.findEntity(named: name) { return found }
        }
        return nil
    }
}
