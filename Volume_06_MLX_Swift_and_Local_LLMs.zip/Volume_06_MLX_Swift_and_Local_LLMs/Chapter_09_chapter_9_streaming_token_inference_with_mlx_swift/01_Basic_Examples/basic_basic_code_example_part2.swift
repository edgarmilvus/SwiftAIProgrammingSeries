
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN // For neural network modules like Embedding and Linear

/// A simple character-level tokenizer for demonstration purposes.
/// Maps characters to unique integer IDs and vice-versa.
struct CharacterTokenizer {
    let vocabulary: [Character]
    let charToInt: [Character: Int]
    let intToChar: [Int: Character]
    let unknownTokenID: Int = 0 // A default ID for characters not in vocab

    init(text: String) {
        // Create a unique sorted set of characters from the input text
        let uniqueChars = Set(text).sorted()
        self.vocabulary = uniqueChars

        var charToIntMap: [Character: Int] = [:]
        var intToCharMap: [Int: Character] = [:]

        // Assign IDs starting from 1, reserving 0 for unknown
        for (index, char) in uniqueChars.enumerated() {
            let id = index + 1 // Start IDs from 1
            charToIntMap[char] = id
            intToCharMap[id] = char
        }
        self.charToInt = charToIntMap
        self.intToChar = intToCharMap
    }

    /// Encodes a string into an array of integer token IDs.
    func encode(_ text: String) -> [Int] {
        return text.map { char in
            charToInt[char] ?? unknownTokenID
        }
    }

    /// Decodes an array of integer token IDs back into a string.
    func decode(_ tokens: [Int]) -> String {
        return String(tokens.compactMap { id in
            intToChar[id]
        })
    }
    
    /// The size of the vocabulary, including the unknown token.
    var vocabSize: Int {
        return vocabulary.count + 1 // +1 for the unknown token ID 0
    }
}
