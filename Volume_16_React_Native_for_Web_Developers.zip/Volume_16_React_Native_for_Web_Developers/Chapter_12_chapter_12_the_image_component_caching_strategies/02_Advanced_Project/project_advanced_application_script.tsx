/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/SmartImage.tsx
"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { Blurhash } from "react-blurhash";

// -----------------------------------------------------------------------------
// TYPES & INTERFACES
// -----------------------------------------------------------------------------

/**
 * Extended Image Props for our Universal SmartImage component.
 * We extend Next.js ImageProps to maintain compatibility with the web layer.
 */
interface SmartImageProps {
  src: string;
  alt: string;
  width: number;
  height: number;
  /**
   * Determines the caching strategy.
   * - 'memory-disk': Aggressive caching (Best for galleries).
   * - 'memory-only': Ephemeral caching (Best for sensitive/temporary data).
   * - 'force-cache': Forces usage of cache even if stale.
   */
  cachePolicy?: "memory-disk" | "memory-only" | "force-cache";
  /**
   * A BlurHash string to display while the image loads.
   * Essential for preventing Layout Shift (CLS) and improving perceived performance.
   */
  blurHash?: string;
  /**
   * Priority loading for LCP (Largest Contentful Paint) images.
   */
  priority?: boolean;
}

// -----------------------------------------------------------------------------
// SERVER ACTION (Simulated)
// -----------------------------------------------------------------------------

/**
 * Server Action to fetch image metadata.
 * In a real app, this would interact with AWS S3, Cloudinary, or a database.
 * This ensures type safety and secure fetching without exposing API keys to the client.
 */
async function fetchOptimizedImageSrc(originalSrc: string): Promise<string> {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 300));
  
  // In a real scenario, we might append CDN parameters for resizing/caching
  // e.g., return `https://cdn.example.com/${originalSrc}?w=800&q=80`;
  return originalSrc;
}

// -----------------------------------------------------------------------------
// COMPONENT LOGIC
// -----------------------------------------------------------------------------

/**
 * SmartImage Component
 * 
 * A hybrid component designed for SaaS dashboards handling high-volume media.
 * It abstracts away the complexity of native caching strategies and web optimization.
 */
export default function SmartImage({
  src,
  alt,
  width,
  height,
  cachePolicy = "memory-disk",
  blurHash,
  priority = false,
}: SmartImageProps) {
  // State to manage the resolved source (handling Server Action promises)
  const [resolvedSrc, setResolvedSrc] = useState<string | null>(null);
  
  // State to track loading status for custom blur transitions
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  // ---------------------------------------------------------------------------
  // EFFECT: Fetch Optimized Source
  // ---------------------------------------------------------------------------
  useEffect(() => {
    let isMounted = true;

    const loadImageSource = async () => {
      try {
        // Fetch the optimized URL from the server
        const optimizedUrl = await fetchOptimizedImageSrc(src);
        if (isMounted) {
          setResolvedSrc(optimizedUrl);
        }
      } catch (error) {
        console.error("Failed to fetch optimized image source:", error);
      }
    };

    loadImageSource();

    return () => {
      isMounted = false;
    };
  }, [src]);

  // ---------------------------------------------------------------------------
  // RENDER: Conditional Logic
  // ---------------------------------------------------------------------------

  if (!resolvedSrc) {
    // Render BlurHash placeholder if available, otherwise a skeleton
    return (
      <div 
        className="relative overflow-hidden rounded-md bg-gray-200 animate-pulse"
        style={{ width, height }}
        aria-label={`Loading ${alt}`}
      >
        {blurHash && (
          <div className="absolute inset-0">
            <Blurhash
              hash={blurHash}
              width={width}
              height={height}
              resolutionX={32}
              resolutionY={32}
              punch={1}
            />
          </div>
        )}
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // RENDER: Web Implementation (Next.js)
  // ---------------------------------------------------------------------------
  
  /**
   * Why Next.js Image Component?
   * 1. Automatic Optimization: Serves modern formats (WebP/AVIF) based on browser support.
   * 2. Lazy Loading: Built-in (unless priority is true).
   * 3. Layout Shift Prevention: Width/Height are mandatory.
   * 
   * Caching Strategy Mapping:
   * Next.js relies on the upstream headers (CDN). However, we simulate native
   * cache policies via the 'priority' prop and fetch strategy.
   */
  return (
    <div className="relative w-full h-full">
      <Image
        src={resolvedSrc}
        alt={alt}
        width={width}
        height={height}
        priority={priority}
        placeholder={blurHash ? "blur" : "empty"}
        // Note: Next.js doesn't support blurHash strings directly in 'blur'.
        // We would typically convert blurHash to a base64 data URI here,
        // but for this demo, we rely on the custom wrapper logic above.
        className={`
          transition-opacity duration-500 ease-in-out
          ${isLoaded ? 'opacity-100' : 'opacity-0'}
        `}
        onLoad={() => setIsLoaded(true)}
        // Quality setting based on cache policy
        quality={cachePolicy === "memory-disk" ? 85 : 75}
      />
      
      {/* 
        NATIVE EQUIVALENT NOTES (Expo-Image):
        In a React Native (Expo) environment, the implementation would look like this:
        
        import { Image as ExpoImage } from 'expo-image';
        
        <ExpoImage
          source={{ uri: resolvedSrc }}
          style={{ width, height, borderRadius: 8 }}
          cachePolicy={cachePolicy} // 'disk' | 'memory' | 'memory-disk' | 'none'
          placeholder={blurHash ? { blurHash } : undefined}
          contentFit="cover"
          transition={200}
        />
        
        The 'cachePolicy' prop is the key differentiator here, allowing native-level
        control over memory usage which is not directly exposed in Next.js Image.
      */}
    </div>
  );
}
