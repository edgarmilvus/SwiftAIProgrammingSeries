
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Swift Package Manager - Not strictly necessary for this example
// as Core ML and Vision are system frameworks, but included for context.)
//
// This file would typically be in the root of a package. For an app target,
// you simply link CoreML and Vision frameworks in your Xcode project.
//
// import PackageDescription
//
// let package = Package(
//     name: "DocumentClassifier",
//     platforms: [.iOS(.v18)], // Target iOS 18 for advanced concurrency features
//     products: [
//         .library(
//             name: "DocumentClassifier",
//             targets: ["DocumentClassifier"]),
//     ],
//     targets: [
//         .target(
//             name: "DocumentClassifier",
//             dependencies: []), // No external dependencies needed for Core ML/Vision
//     ]
// )

import CoreML
import Vision
import UIKit // For UIImage

// MARK: - 1. Error Handling Definition

/// Custom error types for the document classification process, providing specific context
/// for different failure scenarios. This enhances debugging and user feedback.
enum DocumentClassificationError: Error, LocalizedError {
    case modelLoadingFailed(Error)
    case imageProcessingFailed(String)
    case predictionFailed(Error)
    case noClassificationResult
    case invalidResultType
    case featureExtractionFailed(String)

    /// Provides a user-friendly description for each error case.
    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error): return "Failed to load Core ML model: \(error.localizedDescription)"
        case .imageProcessingFailed(let message): return "Image pre-processing failed: \(message)"
        case .predictionFailed(let error): return "Core ML prediction failed: \(error.localizedDescription)"
        case .noClassificationResult: return "No classification result found from the model."
        case .invalidResultType: return "The Vision request returned an unexpected result type."
        case .featureExtractionFailed(let message): return "Failed to extract required features from model output: \(message)"
        }
    }
}

// MARK: - 2. Model Output Structure

/// A structured representation of the classification result, making it easy to access
/// the predicted label, its confidence, and all other confidence scores.
struct DocumentClassificationResult {
    let label: String
    let confidence: Double
    let allConfidences: [String: Double]
}

// MARK: - 3. DocumentClassifierService Class

/// `DocumentClassifierService` encapsulates the logic for loading a Core ML model
/// and performing document classification using the Vision framework.
/// It demonstrates robust error handling and Swift concurrency best practices.
@available(iOS 18.0, *) // Requires iOS 18+ for certain async Vision APIs and modern concurrency patterns.
final class DocumentClassifierService {
    /// The `VNCoreMLModel` wraps the `MLModel` for use with the Vision framework.
    private let coreMLModel: VNCoreMLModel
    /// The `VNCoreMLRequest` is the Vision request that performs the Core ML inference.
    private let classificationRequest: VNCoreMLRequest

    /// Initializes the document classifier service. This involves loading the Core ML model
    /// and setting up the Vision request.
    ///
    /// - Parameter modelURL: The file URL to the compiled Core ML model (`.mlpackage` or `.mlmodelc`).
    ///                       In an Xcode project, dragging a `.mlpackage` file automatically compiles
    ///                       it and makes it accessible via `Bundle.main.url(forResource:withExtension:)`.
    /// - Throws: `DocumentClassificationError.modelLoadingFailed` if the model cannot be loaded or wrapped.
    init(modelURL: URL) async throws {
        do {
            // Load the raw Core ML model from the provided URL.
            let model = try MLModel(contentsOf: modelURL)
            // Wrap the MLModel in a VNCoreMLModel. This adapter allows Vision to interact
            // with the Core ML model, handling input/output format conversions (e.g., CVPixelBuffer).
            self.coreMLModel = try VNCoreMLModel(for: model)
        } catch {
            // Catch any errors during model loading and re-throw them as a specific custom error.
            throw DocumentClassificationError.modelLoadingFailed(error)
        }

        // Create the VNCoreMLRequest. This request will be executed by Vision to perform
        // inference using our wrapped Core ML model.
        self.classificationRequest = VNCoreMLRequest(model: self.coreMLModel) { request, error in
            // This completion handler is primarily for older, synchronous Vision request patterns.
            // With async/await, we typically handle errors directly from the `await` call.
            if let error = error {
                print("VNCoreMLRequest completed with an error in its handler: \(error.localizedDescription)")
            }
        }

        // Configure the Vision request for optimal image processing.
        // `uses` set to `true` allows Vision to handle image pre-processing (scaling, cropping, color space).
        self.classificationRequest.uses = true
        // `.imageCropAndScaleOption` specifies how Vision should transform the input image
        // to match the Core ML model's expected input dimensions. `.centerCrop` is a common
        // and robust choice, maintaining aspect ratio and focusing on the central content.
        self.classificationRequest.imageCropAndScaleOption = .centerCrop
    }

    /// Classifies a given `UIImage` to determine its document type asynchronously.
    ///
    /// - Parameter image: The `UIImage` to be classified. This image will be processed
    ///                    by Vision before being fed to the Core ML model.
    /// - Returns: A `DocumentClassificationResult` containing the predicted label, its confidence,
    ///            and a dictionary of all potential labels with their respective confidences.
    /// - Throws: `DocumentClassificationError` if any part of the classification process fails,
    ///           from image processing to model inference or result interpretation.
    func classifyDocument(image: UIImage) async throws -> DocumentClassificationResult {
        // Ensure the UIImage can be converted to a CGImage, which Vision requires.
        guard let cgImage = image.cgImage else {
            throw DocumentClassificationError.imageProcessingFailed("Could not get CGImage from UIImage.")
        }

        // Create a `VNImageRequestHandler`. This handler takes the raw image data
        // and is responsible for executing one or more Vision requests on it.
        // It's crucial to pass the correct `orientation` to ensure Vision correctly
        // interprets the image's pixel data, especially for photos taken with a camera.
        let handler = VNImageRequestHandler(
            cgImage: cgImage,
            orientation: image.imageOrientation.toCGImagePropertyOrientation()
        )

        do {
            // Perform the classification request asynchronously using Swift's `async/await`.
            // Vision handles the conversion of the `CGImage` to the `CVPixelBuffer` format
            // expected by the underlying Core ML model.
            try await handler.perform([classificationRequest])

            // After the request is performed, retrieve the results.
            // VNCoreMLRequest results are typically `VNCoreMLFeatureValueObservation`s.
            guard let observations = classificationRequest.results as? [VNCoreMLFeatureValueObservation] else {
                throw DocumentClassificationError.invalidResultType
            }

            // For classification, we usually expect one primary observation.
            guard let bestObservation = observations.first else {
                throw DocumentClassificationError.noClassificationResult
            }

            // The output of a VNCoreMLRequest, when configured for classification,
            // is an `MLFeatureProvider`. We need to extract specific features from it.
            // The feature names ("classLabel", "confidence") depend on how the Core ML
            // model was trained and converted.
            guard let featureProvider = bestObservation.featureValue.featureValue else {
                throw DocumentClassificationError.featureExtractionFailed("Could not get MLFeatureProvider from observation.")
            }

            // Extract the predicted class label (String) and confidence scores ([String: Double]).
            // These are standard outputs for classification models.
            guard let classLabel = featureProvider.featureValue(for: "classLabel")?.stringValue,
                  let confidenceScores = featureProvider.featureValue(for: "confidence")?.dictionaryValue as? [String: Double] else {
                throw DocumentClassificationError.featureExtractionFailed("Missing 'classLabel' or 'confidence' output from model. Check model outputs.")
            }

            // Get the confidence specifically for the predicted label.
            let predictedConfidence = confidenceScores[classLabel] ?? 0.0

            // Return the structured classification result.
            return DocumentClassificationResult(
                label: classLabel,
                confidence: predictedConfidence,
                allConfidences: confidenceScores
            )
        } catch let vnError as VNError {
            // Catch specific Vision errors and wrap them.
            throw DocumentClassificationError.predictionFailed(vnError)
        } catch {
            // Catch any other unexpected errors during the prediction phase.
            throw DocumentClassificationError.predictionFailed(error)
        }
    }
}

// MARK: - 4. Helper Extension for UIImage Orientation

/// Extension to `UIImage.Orientation` to convert it to `CGImagePropertyOrientation`.
/// This is crucial for `VNImageRequestHandler` to correctly interpret the image's
/// orientation, preventing incorrect rotations or flips during processing.
extension UIImage.Orientation {
    func toCGImagePropertyOrientation() -> CGImagePropertyOrientation {
        switch self {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default:
            // Handle future unknown cases gracefully by defaulting to .up
            // This is important for forward compatibility.
            return .up
        }
    }
}

// MARK: - 5. Example Usage

/// This function demonstrates how the `DocumentClassifierService` would be integrated
/// into an application, showing initialization, image preparation, and classification.
///
/// In a real application:
/// - The `modelURL` would point to a `.mlpackage` file dragged into your Xcode project.
/// - `imageToClassify` would come from `UIImagePickerController` (camera/photo library)
///   or a document scanning framework.
/// - The classification result would update UI or trigger further app logic.
@available(iOS 18.0, *)
func demonstrateDocumentClassification() async {
    print("Starting document classification demonstration...")

    // 1. Locate the Core ML model in the app bundle.
    //    Replace "DocumentClassifier" with the actual name of your .mlpackage file.
    guard let modelURL = Bundle.main.url(forResource: "DocumentClassifier", withExtension: "mlpackage") else {
        print("Error: 'DocumentClassifier.mlpackage' not found in the app bundle. Please ensure it's added to your Xcode project.")
        return
    }

    // 2. Initialize the `DocumentClassifierService`.
    //    This should ideally be done once, e.g., when your app launches or when the
    //    relevant view controller loads, to avoid repeated model loading overhead.
    var classifierService: DocumentClassifierService?
    do {
        classifierService = try await DocumentClassifierService(modelURL: modelURL)
        print("DocumentClassifierService initialized successfully.")
    } catch {
        print("Failed to initialize DocumentClassifierService: \(error.localizedDescription)")
        return
    }

    // 3. Prepare a sample image for classification.
    //    For a real app, this would be a photo from the camera or chosen from the photo library.
    //    Here, we use a placeholder SF Symbol image and resize it to simulate a document scan.
    let originalImage = UIImage(systemName: "doc.text.image")?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
    let imageToClassify = originalImage?.sd_resized(to: CGSize(width: 600, height: 800)) // Simulate a document size

    guard let finalImage = imageToClassify else {
        print("Error: Sample image could not be created or resized.")
        return
    }
    print("Sample image prepared for classification.")

    // 4. Perform the document classification.
    print("Attempting to classify the sample image...")
    do {
        let result = try await classifierService!.classifyDocument(image: finalImage)
        print("\n--- Document Classification Result ---")
        print("Predicted Label: \(result.label)")
        print("Confidence: \(String(format: "%.2f%%", result.confidence * 100))")
        print("All Confidences:")
        // Sort and print all confidences for a comprehensive view.
        result.allConfidences.sorted { $0.1 > $1.1 }.forEach { (label, confidence) in
            print("  \(label): \(String(format: "%.2f%%", confidence * 100))")
        }
    } catch {
        print("Document classification failed: \(error.localizedDescription)")
    }
}

// MARK: - Dummy UIImage Extension for Demonstration

/// A simple `UIImage` extension for resizing, used only for demonstration purposes.
/// In a production app, you might use a more robust image processing library or
/// ensure images are already at an appropriate size/resolution.
extension UIImage {
    /// Resizes the image to a new specified size.
    /// - Parameter newSize: The target size for the image.
    /// - Returns: A new `UIImage` instance resized to `newSize`, or `nil` if resizing fails.
    func sd_resized(to newSize: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        self.draw(in: CGRect(origin: .zero, size: newSize))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
}
