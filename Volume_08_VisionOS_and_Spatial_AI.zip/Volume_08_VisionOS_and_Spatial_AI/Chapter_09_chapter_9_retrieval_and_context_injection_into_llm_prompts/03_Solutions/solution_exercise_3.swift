
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct TextChunk {
    let text: String
    let metadata: [String: String]
    let embedding: [Float]
}

// Hypothetical LLM Client
@available(iOS 18.0, *)
protocol LLMClient {
    func generateResponse(prompt: String) async throws -> String
}

@available(iOS 18.0, *)
protocol DocumentChunker {
    func chunk(text: String, chunkSize: Int, overlap: Int) -> [String]
}

@available(iOS 18.0, *)
protocol VectorStore {
    func save(chunks: [TextChunk]) async throws
    func search(queryEmbedding: [Float], limit: Int) async throws -> [TextChunk]
}

@available(iOS 18.0, *)
class SlidingWindowChunker: DocumentChunker {
    func chunk(text: String, chunkSize: Int, overlap: Int) -> [String] {
        let characters = Array(text)
        var chunks: [String] = []
        var start = 0
        
        while start < characters.count {
            let end = min(start + chunkSize, characters.count)
            let chunkRange = start..<end
            chunks.append(String(characters[chunkRange]))
            
            // Move start pointer forward, but subtract overlap to ensure continuity
            if end == characters.count { break }
            start += (chunkSize - overlap)
        }
        return chunks
    }
}

@available(iOS 18.0, *)
class RAGPipeline {
    private let chunker: DocumentChunker
    private let vectorStore: VectorStore
    private let embeddingProvider: EmbeddingProvider
    private let llmClient: LLMClient
    
    init(chunker: DocumentChunker, vectorStore: VectorStore, embeddingProvider: EmbeddingProvider, llmClient: LLMClient) {
        self.chunker = chunker
        self.vectorStore = vectorStore
        self.embeddingProvider = embeddingProvider
        self.llmClient = llmClient
    }
    
    func processDocument(text: String, metadata: [String: String]) async throws {
        // 1. Chunking
        let rawChunks = chunker.chunk(text: text, chunkSize: 500, overlap: 50)
        
        // 2. Embedding and Storage
        var textChunks: [TextChunk] = []
        for rawText in rawChunks {
            let embedding = try await embeddingProvider.generateEmbedding(for: rawText)
            textChunks.append(TextChunk(text: rawText, metadata: metadata, embedding: embedding))
        }
        
        try await vectorStore.save(chunks: textChunks)
    }
    
    func answerQuestion(query: String) async throws -> String {
        // 1. Embed the query
        let queryEmbedding = try await embeddingProvider.generateEmbedding(for: query)
        
        // 2. Retrieve relevant chunks
        let relevantChunks = try await vectorStore.search(queryEmbedding: queryEmbedding, limit: 3)
        
        // 3. Construct Contextual Prompt
        let context = relevantChunks.map { $0.text }.joined(separator: "\n---\n")
        let prompt = """
        Use the following pieces of retrieved context to answer the question. 
        If you don't know the answer, just say that you don't know.
        
        CONTEXT:
        \(context)
        
        QUESTION:
        \(query)
        
        ANSWER:
        """
        
        // 4. Call LLM
        return try await llmClient.generateResponse(prompt: prompt)
    }
}
