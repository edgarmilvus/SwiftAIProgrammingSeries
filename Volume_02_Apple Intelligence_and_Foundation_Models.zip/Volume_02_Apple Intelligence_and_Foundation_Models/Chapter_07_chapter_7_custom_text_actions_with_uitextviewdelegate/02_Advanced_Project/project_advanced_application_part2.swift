
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import UIKit
import Foundation // For String operations and basic utilities
// import AIKit // Hypothetical framework for Apple Intelligence, part of iOS 18+

// MARK: - 1. Custom Error Handling for Apple Intelligence Operations

/// Custom error type specifically for Apple Intelligence text processing operations.
/// This provides granular control over error messages and allows for specific handling
/// based on the nature of the failure (e.g., text length constraints, service availability).
enum AppleIntelligenceError: Error, LocalizedError {
    case textTooShort(minimumLength: Int)
    case textTooLong(maximumLength: Int)
    case serviceUnavailable
    case unknown(Error)

    /// Provides a user-friendly description for each error case.
    var errorDescription: String? {
        switch self {
        case .textTooShort(let min):
            return "The selected text is too short. Please select at least \(min) characters."
        case .textTooLong(let max):
            return "The selected text is too long. Please select at most \(max) characters."
        case .serviceUnavailable:
            return "Apple Intelligence service is currently unavailable. Please try again later."
        case .unknown(let error):
            return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}

// MARK: - 2. Simulated Apple Intelligence Text Service

/// An `actor` that simulates interactions with Apple Intelligence's on-device text capabilities.
/// Using an `actor` ensures thread-safe access to its internal state (like min/max lengths)
/// and prevents data races if multiple AI operations were to be triggered concurrently
/// from different parts of the app, though for this specific `UITextViewDelegate` context,
/// it primarily serves as a good practice for asynchronous service objects.
///
/// In a real application, this actor would wrap the actual `AI.Text` APIs provided by Apple.
@available(iOS 18.0, *) // Apple Intelligence features are available from iOS 18.0
actor AppleIntelligenceTextService {
    // Define reasonable length constraints for different AI operations.
    // These would typically be determined by the actual AI model's capabilities.
    private let minSummarizeLength = 50
    private let maxSummarizeLength = 1000
    private let minRephraseLength = 20
    private let maxRephraseLength = 500
    private let minProofreadLength = 10
    private let maxProofreadLength = 2000

    /// Simulates summarizing a given text.
    /// - Parameter text: The input text to summarize.
    /// - Returns: A summarized version of the text.
    /// - Throws: `AppleIntelligenceError` if input constraints are not met or service fails.
    func summarize(text: String) async throws -> String {
        guard text.count >= minSummarizeLength else {
            throw AppleIntelligenceError.textTooShort(minimumLength: minSummarizeLength)
        }
        guard text.count <= maxSummarizeLength else {
            throw AppleIntelligenceError.textTooLong(maximumLength: maxSummarizeLength)
        }

        // Simulate network/processing delay for AI operation.
        try await Task.sleep(for: .seconds(1.5))

        // Simulate an occasional service unavailability or specific error condition.
        if Bool.random() && text.contains("service_error") {
            throw AppleIntelligenceError.serviceUnavailable
        }

        // Basic placeholder summarization logic.
        let words = text.split(separator: " ")
        let summaryWords = words.prefix(words.count / 3) // Take roughly one-third of the words
        return summaryWords.joined(separator: " ") + "..." + " (AI Summary)"
    }

    /// Simulates rephrasing a given text.
    /// - Parameter text: The input text to rephrase.
    /// - Returns: A rephrased version of the text.
    /// - Throws: `AppleIntelligenceError` if input constraints are not met or service fails.
    func rephrase(text: String) async throws -> String {
        guard text.count >= minRephraseLength else {
            throw AppleIntelligenceError.textTooShort(minimumLength: minRephraseLength)
        }
        guard text.count <= maxRephraseLength else {
            throw AppleIntelligenceError.textTooLong(maximumLength: maxRephraseLength)
        }

        try await Task.sleep(for: .seconds(1.0))

        if Bool.random() && text.contains("rephrase_fail") {
            throw AppleIntelligenceError.serviceUnavailable
        }

        // Simple placeholder rephrasing: capitalize and add a prefix.
        return "Rephrased for clarity: \"\(text.capitalized)\" (AI Rephrase)"
    }

    /// Simulates proofreading a given text.
    /// - Parameter text: The input text to proofread.
    /// - Returns: A proofread version of the text.
    /// - Throws: `AppleIntelligenceError` if input constraints are not met or service fails.
    func proofread(text: String) async throws -> String {
        guard text.count >= minProofreadLength else {
            throw AppleIntelligenceError.textTooShort(minimumLength: minProofreadLength)
        }
        guard text.count <= maxProofreadLength else {
            throw AppleIntelligenceError.textTooLong(maximumLength: maxProofreadLength)
        }

        try await Task.sleep(for: .seconds(0.8))

        if Bool.random() && text.contains("proof_bug") {
            throw AppleIntelligenceError.serviceUnavailable
        }

        // Basic placeholder proofreading: ensure first letter is capitalized and ends with a period.
        var proofreadText = text.prefix(1).uppercased() + text.dropFirst()
        if !proofreadText.hasSuffix(".") && !proofreadText.hasSuffix("!") && !proofreadText.hasSuffix("?") {
            proofreadText += "."
        }
        return proofreadText + " (AI Proofread)"
    }
}

// MARK: - 3. Document Editor View Controller with Custom AI Actions

/// A `UIViewController` that serves as a simple document editor.
/// It demonstrates how to integrate custom AI-powered text actions into the
/// `UITextView`'s edit menu using `UITextViewDelegate` and Swift concurrency.
@available(iOS 18.0, *)
class DocumentEditorViewController: UIViewController, UITextViewDelegate {

    // MARK: - Properties

    private let textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 0.5
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        textView.isScrollEnabled = true
        textView.text = """
        This is a sample document text for the AI Document Editor.
        You can select any part of this text to see custom Apple Intelligence actions in the edit menu.
        For example, select a sentence and try to rephrase it.
        Select a longer paragraph and summarize it.
        Or simply select a word or phrase and proofread it.

        Remember, these are simulated AI responses for demonstration purposes.
        The actual Apple Intelligence APIs would provide more sophisticated and contextually aware results.
        This text is sufficiently long to test summarization capabilities.
        It includes multiple sentences and paragraphs to showcase the versatility of the custom actions.
        Feel free to experiment with different selections to observe the behavior of each AI function.
        """
        return textView
    }()

    /// Instantiate our simulated Apple Intelligence service.
    private let aiService = AppleIntelligenceTextService()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "AI Document Editor"
        view.backgroundColor = .systemBackground

        setupTextView()
    }

    // MARK: - Setup

    /// Configures and adds the `UITextView` to the view hierarchy.
    private func setupTextView() {
        view.addSubview(textView)
        textView.delegate = self // Assign self as the delegate to receive text view events.

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    // MARK: - UITextViewDelegate Implementation

    /// This is the pivotal delegate method for customizing the text selection menu.
    /// It's called when the system is preparing to display the edit menu for selected text.
    ///
    /// - Parameters:
    ///   - textView: The text view requesting the edit menu.
    ///   - textRange: The `UITextRange` representing the currently selected text.
    ///   - suggestedActions: An array of `UIAction` objects that the system suggests (e.g., Copy, Paste).
    /// - Returns: An `UIMenu` containing the desired actions for the edit menu.
    func textView(_ textView: UITextView, editMenuForTextIn textRange: UITextRange, suggestedActions: [UIAction]) -> UIMenu? {
        // 1. Validate selected text: Ensure there is actual text selected.
        guard let selectedText = textView.text(in: textRange), !selectedText.isEmpty else {
            // If no text is selected or it's empty, we might return nil to show no menu,
            // or just the suggested actions if they are still relevant.
            return UIMenu(title: "", children: suggestedActions)
        }

        // 2. Define custom AI-powered `UIAction` instances.
        //    Each `UIAction` has a title, an optional system icon, and a handler closure.
        //    The handler closure captures `self`, `selectedText`, and `textRange`
        //    to perform the AI operation and update the text view.
        let summarizeAction = UIAction(title: "Summarize (AI)", image: UIImage(systemName: "text.alignleft")) { [weak self] _ in
            self?.performAIAction(actionType: .summarize, selectedText: selectedText, textRange: textRange)
        }

        let rephraseAction = UIAction(title: "Rephrase (AI)", image: UIImage(systemName: "text.quote")) { [weak self] _ in
            self?.performAIAction(actionType: .rephrase, selectedText: selectedText, textRange: textRange)
        }

        let proofreadAction = UIAction(title: "Proofread (AI)", image: UIImage(systemName: "text.badge.checkmark")) { [weak self] _ in
            self?.performAIAction(actionType: .proofread, selectedText: selectedText, textRange: textRange)
        }

        // 3. Construct the `UIMenu` by combining custom actions with system-suggested ones.
        //    We place our custom AI actions first for prominence.
        //    `UIMenu` allows for hierarchical menus, but for simplicity, we'll use a flat list here.
        let customActions = [summarizeAction, rephraseAction, proofreadAction]
        return UIMenu(title: "", children: customActions + suggestedActions)
    }

    // MARK: - AI Action Dispatch and Handling

    /// Enum to clearly distinguish between different types of AI text actions.
    enum AIActionType {
        case summarize
        case rephrase
        case proofread
    }

    /// Dispatches and handles the execution of an AI text action.
    /// This method leverages Swift's structured concurrency (`async/await`, `Task`)
    /// and robust error handling (`do-catch`).
    ///
    /// - Parameters:
    ///   - actionType: The specific AI action to perform.
    ///   - selectedText: The text that was selected when the action was triggered.
    ///   - textRange: The `UITextRange` corresponding to the `selectedText`.
    private func performAIAction(actionType: AIActionType, selectedText: String, textRange: UITextRange) {
        // 1. Initiate an asynchronous task.
        //    `Task` creates a new concurrent context. The AI operation will run off the main thread.
        Task {
            do {
                var processedText: String

                // 2. Call the appropriate `async` AI service method.
                //    `await` suspends this task until the `aiService` returns a result or throws an error.
                switch actionType {
                case .summarize:
                    processedText = try await aiService.summarize(text: selectedText)
                case .rephrase:
                    processedText = try await aiService.rephrase(text: selectedText)
                case .proofread:
                    processedText = try await aiService.proofread(text: selectedText)
                }

                // 3. Update the UI on the main actor after the AI processing is complete.
                //    `await MainActor.run { ... }` ensures that all UI modifications occur
                //    on the main thread, which is a fundamental UIKit requirement.
                await MainActor.run {
                    // Critical check: Verify if the original text range is still valid and selected.
                    // The user might have changed their selection or edited the text while the AI was processing.
                    // If the range is no longer valid, we should not attempt to replace text at that location.
                    guard let currentSelectedRange = textView.selectedTextRange,
                          currentSelectedRange == textRange else {
                        print("User changed selection during AI processing. Not updating text.")
                        // Optionally, show a toast or alert indicating the change.
                        return
                    }

                    // Replace the original selected text with the AI-processed text.
                    textView.replace(textRange, withText: processedText)

                    // Optionally, re-select the newly inserted text for better user experience.
                    // This keeps the context of the AI operation visible.
                    if let newEndPosition = textView.position(from: textRange.start, offset: processedText.count) {
                        textView.selectedTextRange = textView.textRange(from: textRange.start, to: newEndPosition)
                    }
                }
            } catch let aiError as AppleIntelligenceError {
                // 4. Handle specific `AppleIntelligenceError` types.
                //    Present a user-friendly alert with the localized error description.
                await MainActor.run {
                    self.showAlert(title: "AI Action Failed", message: aiError.localizedDescription)
                }
            } catch {
                // 5. Catch any other unexpected errors.
                //    Provide a generic error message for unhandled exceptions.
                await MainActor.run {
                    self.showAlert(title: "Error", message: "An unexpected error occurred: \(error.localizedDescription)")
                }
            }
        }
    }

    /// Presents a standard `UIAlertController` to display messages to the user.
    /// - Parameters:
    ///   - title: The title of the alert.
    ///   - message: The message content of the alert.
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

// MARK: - Example Usage in an App Delegate or Scene Delegate

/*
// To run this example in a minimal Xcode project or Playground, you would typically
// set up your AppDelegate or SceneDelegate as follows:

@available(iOS 18.0, *)
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        let viewController = DocumentEditorViewController()
        let navigationController = UINavigationController(rootViewController: viewController)
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
        return true
    }
}

// For a Swift Playground, you could use:
// import PlaygroundSupport
// PlaygroundPage.current.liveView = AppDelegate().window?.rootViewController
*/
