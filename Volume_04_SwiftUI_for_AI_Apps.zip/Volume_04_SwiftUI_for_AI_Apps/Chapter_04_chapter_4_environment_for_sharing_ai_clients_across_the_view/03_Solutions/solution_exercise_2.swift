
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Foundation

// MARK: - 1. AI Summarizer Protocol

/// A protocol defining the interface for an AI text summarizer.
@available(iOS 18.0, macOS 15.0, *)
protocol AISummarizerProtocol {
    /// Generates a summary of the provided text.
    /// - Parameter text: The input text to summarize.
    /// - Returns: The generated summary.
    func summarize(_ text: String) async throws -> String
    /// A descriptive name for this summarizer's configuration.
    var configurationName: String { get }
}

// MARK: - 2. Configurable AI Summarizer

/// A mock implementation of AISummarizerProtocol that can be configured.
@available(iOS 18.0, macOS 15.0, *)
struct ConfigurableAISummarizer: AISummarizerProtocol {
    let configurationName: String

    init(configurationName: String) {
        self.configurationName = configurationName
    }

    func summarize(_ text: String) async throws -> String {
        try await Task.sleep(for: .seconds(0.7)) // Simulate work
        switch configurationName {
        case "Fast Summary":
            return "Quick summary by \(configurationName): The essence of your text in a few words. (Input length: \(text.count))"
        case "Detailed Analysis":
            return "In-depth analysis by \(configurationName): A comprehensive overview with key points and insights. (Input length: \(text.count))"
        default:
            return "Generic summary by \(configurationName): \(text.prefix(50))..."
        }
    }
}

// MARK: - 3. Two Custom Environment Keys

@available(iOS 18.0, macOS 15.0, *)
private struct FastSummarizerKey: EnvironmentKey {
    static let defaultValue: any AISummarizerProtocol = ConfigurableAISummarizer(configurationName: "Default Fast Summary")
}

@available(iOS 18.0, macOS 15.0, *)
private struct DetailedSummarizerKey: EnvironmentKey {
    static let defaultValue: any AISummarizerProtocol = ConfigurableAISummarizer(configurationName: "Default Detailed Analysis")
}

// MARK: - 4. Extend EnvironmentValues for Both Keys

@available(iOS 18.0, macOS 15.0, *)
extension EnvironmentValues {
    var fastSummarizer: any AISummarizerProtocol {
        get { self[FastSummarizerKey.self] }
        set { self[FastSummarizerKey.self] = newValue }
    }

    var detailedSummarizer: any AISummarizerProtocol {
        get { self[DetailedSummarizerKey.self] }
        set { self[DetailedSummarizerKey.self] = newValue }
    }
}

// MARK: - 5. Two Dashboard Widgets

@available(iOS 18.0, macOS 15.0, *)
struct FastSummaryWidget: View {
    @Environment(\.fastSummarizer) private var summarizer: any AISummarizerProtocol
    @State private var inputText: String = "Apple released SwiftUI in 2019, revolutionizing UI development across its platforms. It offers a declarative approach, making it easier to build complex UIs with less code. Developers appreciate its seamless integration with Xcode previews and its ability to adapt to various device orientations and sizes."
    @State private var summaryResult: String = "No summary yet."
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(alignment: .leading) {
            Text(summarizer.configurationName)
                .font(.headline)
                .foregroundColor(.green)
            
            TextEditor(text: $inputText)
                .frame(height: 80)
                .border(Color.gray.opacity(0.5), width: 1)
                .accessibilityIdentifier("fastSummaryInputTextEditor")

            Button {
                summarizeText()
            } label: {
                HStack {
                    if isLoading {
                        ProgressView()
                    }
                    Text("Get Fast Summary")
                }
            }
            .disabled(isLoading || inputText.isEmpty)
            .padding(.vertical, 5)
            .accessibilityIdentifier("getFastSummaryButton")

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
            } else {
                Text("Summary: \(summaryResult)")
                    .font(.caption)
                    .lineLimit(3)
            }
        }
        .padding()
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }

    private func summarizeText() {
        isLoading = true
        errorMessage = nil
        Task {
            do {
                let result = try await summarizer.summarize(inputText)
                await MainActor.run {
                    summaryResult = result
                }
            } catch {
                await MainActor.run {
                    errorMessage = error.localizedDescription
                }
            }
            await MainActor.run {
                isLoading = false
            }
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct DetailedAnalysisWidget: View {
    @Environment(\.detailedSummarizer) private var summarizer: any AISummarizerProtocol
    @State private var inputText: String = "Apple released SwiftUI in 2019, revolutionizing UI development across its platforms. It offers a declarative approach, making it easier to build complex UIs with less code. Developers appreciate its seamless integration with Xcode previews and its ability to adapt to various device orientations and sizes."
    @State private var analysisResult: String = "No detailed analysis yet."
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(alignment: .leading) {
            Text(summarizer.configurationName)
                .font(.headline)
                .foregroundColor(.purple)
            
            TextEditor(text: $inputText)
                .frame(height: 80)
                .border(Color.gray.opacity(0.5), width: 1)
                .accessibilityIdentifier("detailedAnalysisInputTextEditor")

            Button {
                summarizeText()
            } label: {
                HStack {
                    if isLoading {
                        ProgressView()
                    }
                    Text("Get Detailed Analysis")
                }
            }
            .disabled(isLoading || inputText.isEmpty)
            .padding(.vertical, 5)
            .accessibilityIdentifier("getDetailedAnalysisButton")

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
            } else {
                Text("Analysis: \(analysisResult)")
                    .font(.caption)
                    .lineLimit(5)
            }
        }
        .padding()
        .background(Color.purple.opacity(0.1))
        .cornerRadius(10)
    }

    private func summarizeText() {
        isLoading = true
        errorMessage = nil
        Task {
            do {
                let result = try await summarizer.summarize(inputText)
                await MainActor.run {
                    analysisResult = result
                }
            } catch {
                await MainActor.run {
                    errorMessage = error.localizedDescription
                }
            }
            await MainActor.run {
                isLoading = false
            }
        }
    }
}

// MARK: - 6. App Struct

@available(iOS 18.0, macOS 15.0, *)
struct DashboardView: View {
    var body: some View {
        VStack(spacing: 20) {
            FastSummaryWidget()
            DetailedAnalysisWidget()
        }
        .padding()
        .navigationTitle("AI Dashboard")
    }
}

@main
@available(iOS 18.0, macOS 15.0, *)
struct AIDashboardApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                DashboardView()
                    // Provide distinct, configured instances for each key
                    .environment(\.fastSummarizer, ConfigurableAISummarizer(configurationName: "Fast Summary"))
                    .environment(\.detailedSummarizer, ConfigurableAISummarizer(configurationName: "Detailed Analysis"))
            }
        }
    }
}
