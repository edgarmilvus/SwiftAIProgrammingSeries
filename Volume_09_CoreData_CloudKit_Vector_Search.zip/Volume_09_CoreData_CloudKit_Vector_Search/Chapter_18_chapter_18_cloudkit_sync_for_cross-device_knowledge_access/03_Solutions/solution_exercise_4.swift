
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreData
import CloudKit
import UIKit

@available(iOS 18.0, macOS 15.0, *)
class SharingService: NSObject {
    let container: NSPersistentCloudKitContainer
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
        super.init()
    }
    
    /// Initiates the CloudKit sharing flow for a specific Vault.
    func shareVault(_ vault: VaultEntity, from viewController: UIViewController) {
        // 1. Ensure the Vault is in a custom zone capable of sharing
        // In NSPersistentCloudKitContainer, sharing requires the entity to be 
        // part of a shared record zone.
        
        let sharingController = UICloudSharingController { [weak self] (_, completion: @escaping (CKShare?, CKContainer?, Error?) -> Void) in
            guard let self = self else { return }
            
            // 2. Create the CKShare object
            // In Core Data, we fetch the managed object and use its representation
            let share = CKShare(rootRecord: vault.asCKRecord()) 
            share.publicPermission = .readWrite
            
            // 3. The container handles the heavy lifting of associating 
            // the managed object with the CKShare.
            completion(share, self.container.cloudKitContainerOptions?.cloudKitContainerIdentifier != nil ? nil : nil, nil)
        }
        
        sharingController.delegate = self
        viewController.present(sharingController, animated: true)
    }
}

extension SharingService: UICloudSharingControllerDelegate {
    func cloudSharingController(_ csc: UICloudSharingController, failedToSaveShareWithError error: Error) {
        print("Failed to save share: \(error.localizedDescription)")
    }
    
    func itemTitle(for csc: UICloudSharingController) -> String? {
        return "Research Vault"
    }
}

// MARK: - Handling the Acceptance of a Share
@available(iOS 18.0, macOS 15.0, *)
class AppDelegate: NSObject, UIApplicationDelegate {
    let container: NSPersistentCloudKitContainer

    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }

    func application(_ application: UIApplication, userDidAcceptCloudKitShareWith metadata: CKMetadata) {
        // 1. The user accepted an invitation.
        // 2. We must notify the container to refresh its view of the SHARED database.
        
        Task {
            // This ensures the local SQLite store integrates the new shared zone
            // from the user's Shared CloudKit Database.
            try? await container.initializeCloudKitSchema() 
            
            // Trigger a merge of remote changes to show the shared data immediately
            container.viewContext.perform {
                self.container.viewContext.automaticallyMergesChangesFromParent = true
            }
        }
    }
}
