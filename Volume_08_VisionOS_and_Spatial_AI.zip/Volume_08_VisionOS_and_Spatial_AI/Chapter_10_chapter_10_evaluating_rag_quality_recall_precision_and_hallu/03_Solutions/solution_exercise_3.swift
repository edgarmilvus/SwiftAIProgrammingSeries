
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct Hyperparameter: Hashable, Sendable {
    let chunkSize: Int
    let overlap: Int
}

@available(iOS 18.0, macOS 15.0, *)
protocol RAGPipeline: Sendable {
    func execute(query: String) async throws -> (context: String, answer: String)
}

@available(iOS 18.0, macOS 15.0, *)
struct TestQuery: Sendable {
    let query: String
    let expectedContextSnippet: String
}

@available(iOS 18.0, macOS 15.0, *)
actor RAGProfiler {
    let pipelineFactory: @Sendable (Hyperparameter) -> any RAGPipeline
    let testDataset: [TestQuery]
    private let maxConcurrentTasks = 5

    init(pipelineFactory: @escaping @Sendable (Hyperparameter) -> any RAGPipeline, testDataset: [TestQuery]) {
        self.pipelineFactory = pipelineFactory
        self.testDataset = testDataset
    }

    func runProfile(configurations: [Hyperparameter]) async throws -> [Hyperparameter: Double] {
        var results: [Hyperparameter: Double] = [:]
        
        for config in configurations {
            let pipeline = pipelineFactory(config)
            
            // Use a TaskGroup to run all queries for THIS configuration in parallel
            let avgScore = try await withThrowingTaskGroup(of: Double.self) { group in
                // To implement a simple "Rate Limiter", we process queries in batches
                // or use a semaphore-like approach. Here we use a simple chunking strategy.
                let chunks = testDataset.chunked(into: maxConcurrentTasks)
                var totalScore: Double = 0
                
                for chunk in chunks {
                    for query in chunk {
                        group.addTask {
                            let (context, _) = try await pipeline.execute(query: query.query)
                            // Simple metric: Does the context contain the expected snippet?
                            return context.contains(query.expectedContextSnippet) ? 1.0 : 0.0
                        }
                    }
                    
                    // Wait for the current batch to finish before starting the next
                    // to respect the 'maxConcurrentTasks' limit.
                    for try await score in group {
                        totalScore += score
                    }
                }
                return totalScore / Double(testDataset.count)
            }
            
            results[config] = avgScore
        }
        
        return results
    }
}

// Helper for chunking arrays
extension Array {
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
}
