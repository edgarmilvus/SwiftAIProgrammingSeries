
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CreateML
import Foundation

// MARK: - Exercise 3: Dynamic Ride-Sharing Fare Prediction

// Function to generate substantial synthetic data for ride-sharing fare prediction
func generateRideSharingData(numSamples: Int) -> [[String: MLDataValue]] {
    var data: [[String: MLDataValue]] = []

    for _ in 0..<numSamples {
        let distanceMiles = Double.random(in: 1.0...30.0)
        let timeOfDayHour = Int.random(in: 0...23)
        let dayOfWeek = Int.random(in: 1...7) // 1=Monday, 7=Sunday
        let currentDemandIndex = Int.random(in: 1...10)
        let availableDrivers = Int.random(in: 5...100)
        let weatherConditionIndex = Int.random(in: 0...3) // 0=Clear, 1=Rain, 2=Snow, 3=Extreme
        let historicalSurgeFactor = Double.random(in: 1.0...2.5)

        // Simulate optimalFareMultiplier:
        // Base multiplier starts at 1.0
        var multiplier = 1.0

        // Increase with distance, demand, historical surge
        multiplier += distanceMiles * 0.01
        multiplier += Double(currentDemandIndex) * 0.05
        multiplier += historicalSurgeFactor * 0.2

        // Adjust based on time of day (peak hours)
        if (timeOfDayHour >= 7 && timeOfDayHour <= 9) || (timeOfDayHour >= 17 && timeOfDayHour <= 19) {
            multiplier += 0.3 // Morning/Evening rush
        } else if timeOfDayHour >= 22 || timeOfDayHour <= 4 {
            multiplier += 0.1 // Late night/early morning
        }

        // Adjust based on day of week (weekends)
        if dayOfWeek == 6 || dayOfWeek == 7 { // Saturday or Sunday
            multiplier += 0.15
        }

        // Decrease with more available drivers
        multiplier -= Double(availableDrivers) * 0.005

        // Adjust for weather
        switch weatherConditionIndex {
        case 1: multiplier += 0.1 // Rain
        case 2: multiplier += 0.2 // Snow
        case 3: multiplier += 0.4 // Extreme
        default: break // Clear
        }

        // Add some random noise and ensure a reasonable range
        multiplier += Double.random(in: -0.1...0.1)
        multiplier = max(0.8, min(3.0, multiplier)) // Keep multiplier between 0.8 and 3.0

        data.append([
            "distanceMiles": .double(distanceMiles),
            "timeOfDayHour": .int(timeOfDayHour),
            "dayOfWeek": .int(dayOfWeek),
            "currentDemandIndex": .int(currentDemandIndex),
            "availableDrivers": .int(availableDrivers),
            "weatherConditionIndex": .int(weatherConditionIndex),
            "historicalSurgeFactor": .double(historicalSurgeFactor),
            "optimalFareMultiplier": .double(multiplier)
        ])
    }
    return data
}

// Main function to run Exercise 3
func runExercise3() {
    print("--- Exercise 3: Dynamic Ride-Sharing Fare Prediction ---")

    // 1. Problem Definition:
    print("Problem: Predict an optimal fare multiplier for ride-sharing requests.")
    print("Business Value: Dynamic pricing balances driver incentives, passenger demand, and competitive rates.")
    print("Role of MLLinearRegressor: To learn a linear relationship between various ride factors and the optimal fare multiplier.")

    // 2. Data Simulation/Loading: Create a substantial synthetic dataset
    let numSamples = 2000 // Increased samples for a more robust model
    let rawData = generateRideSharingData(numSamples: numSamples)
    guard let dataTable = try? MLDataTable(array: rawData) else {
        print("Error: Could not create MLDataTable from raw data.")
        return
    }
    print("Generated \(dataTable.rows.count) samples.")

    // 3. Feature Engineering:
    // For this exercise, we assume numerical input is sufficient.
    // In a real scenario, 'dayOfWeek' and 'weatherConditionIndex' might benefit from one-hot encoding.
    // However, MLLinearRegressor can handle numerical categories directly, assuming a linear relationship.
    let featureColumns = [
        "distanceMiles", "timeOfDayHour", "dayOfWeek", "currentDemandIndex",
        "availableDrivers", "weatherConditionIndex", "historicalSurgeFactor"
    ]
    let targetColumn = "optimalFareMultiplier"

    let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 2)
    print("Training data size: \(trainingData.rows.count)")
    print("Testing data size: \(testingData.rows.count)")

    // 4. Model Training:
    do {
        let regressor = try MLLinearRegressor(trainingData: trainingData,
                                              targetColumn: targetColumn,
                                              featureColumns: featureColumns)
        print("Model training complete.")

        // 5. Advanced Evaluation:
        let evaluationMetrics = regressor.evaluation(on: testingData, targetColumn: targetColumn)
        let rmse = evaluationMetrics.rootMeanSquaredError
        let mae = evaluationMetrics.meanAbsoluteError

        print("\nModel Evaluation:")
        print("  Root Mean Squared Error (RMSE): \(String(format: "%.3f", rmse))")
        print("  Mean Absolute Error (MAE): \(String(format: "%.3f", mae))")

        // Business Impact Discussion:
        print("\nDiscussion on Business Impact Evaluation:")
        print("  Beyond RMSE/MAE, business impact would involve:")
        print("  - Revenue Simulation: Compare predicted vs. actual revenue with dynamic pricing.")
        print("  - Driver Satisfaction: Monitor driver earnings and acceptance rates.")
        print("  - Passenger Satisfaction: Track ride completion rates, cancellation rates, and feedback on pricing.")
        print("  - Fairness Metrics: Analyze pricing differences across demographics or geographic areas to ensure equity.")
        print("  - A/B Testing: Deploy the model to a subset of users and compare key performance indicators (KPIs) against a control group.")

        // 6. Model Persistence & Integration:
        print("\nModel Persistence & Integration:")
        let modelURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("FareMultiplierRegressor.mlmodel")
        try regressor.write(to: modelURL)
        print("  Trained model saved to: \(modelURL.path)")
        print("  Integration into SwiftRides:")
        print("  - Backend: The .mlmodel can be converted to Core ML and used by a server-side Swift/Vapor application or other backend services.")
        print("  - On-Device (Core ML): For real-time, low-latency predictions, the Core ML model can be bundled with the iOS/macOS app.")
        print("    This allows predictions without network latency, improving user experience. The app would collect features (GPS, time, local demand estimate) and feed them to the Core ML model.")
        print("    Model updates would require app updates or Over-the-Air (OTA) Core ML model deployment (if using Core ML Model Deployment).")

    } catch {
        print("Error during model training or evaluation: \(error.localizedDescription)")
    }
    print("--------------------------------------------------\n")
}

// Call the function to run the exercise
runExercise3()
