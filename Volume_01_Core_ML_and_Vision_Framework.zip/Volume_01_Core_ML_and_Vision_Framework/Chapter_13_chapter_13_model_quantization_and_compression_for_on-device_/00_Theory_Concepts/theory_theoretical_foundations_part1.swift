
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import CoreML
    import Foundation

    /// A dedicated actor for managing Core ML model loading and inference.
    @available(iOS 18.0, *)
    actor MLModelManager {
        private var models: [String: MLModel] = [:]

        /// Loads an MLModel from the specified URL.
        /// - Parameters:
        ///   - modelURL: The URL to the compiled .mlmodelc directory.
        ///   - modelName: A unique name to identify and cache the model.
        /// - Returns: The loaded MLModel instance.
        /// - Throws: An error if the model cannot be loaded.
        func loadModel(from modelURL: URL, named modelName: String) async throws -> MLModel {
            if let cachedModel = models[modelName] {
                return cachedModel
            }

            // MLModel.load(contentsOf:) is a throwing, synchronous operation.
            // We wrap it in Task.detached to ensure it runs off the current actor's executor
            // if the current actor is not the main actor, and to provide isolation.
            let config = MLModelConfiguration()
            config.computeUnits = .all // Use all available compute units, including Neural Engine

            let model = try await Task.detached {
                try MLModel.load(contentsOf: modelURL, configuration: config)
            }.value
            
            models[modelName] = model
            return model
        }

        /// Performs a prediction using a cached model.
        /// - Parameters:
        ///   - modelName: The name of the cached model.
        ///   - input: The MLFeatureProvider input for the model.
        /// - Returns: The MLFeatureProvider output from the model.
        /// - Throws: An error if the model is not found or prediction fails.
        func predict(using modelName: String, input: MLFeatureProvider) async throws -> MLFeatureProvider {
            guard let model = models[modelName] else {
                throw MLModelError.notFound(modelName: modelName)
            }

            // Prediction is also a synchronous operation.
            // Although MLModel instances are thread-safe for concurrent inference calls,
            // wrapping in Task.detached ensures the *entire* prediction process
            // (including potential pre/post-processing if done here) is off the caller's thread.
            let prediction = try await Task.detached {
                try model.prediction(from: input)
            }.value
            return prediction
        }
    }

    // Example usage in a SwiftUI view model or similar:
    @available(iOS 18.0, *)
    class ImageClassifierViewModel: ObservableObject { // Using ObservableObject for simplicity here
        private let modelManager = MLModelManager()
        @Published var classificationResult: String?
        @Published var isLoading: Bool = false

        func classifyImage(imageFeatureProvider: MLFeatureProvider) async {
            isLoading = true
            do {
                // Assume "MyQuantizedModel" is the name given during loading
                let model = try await modelManager.loadModel(from: Bundle.main.url(forResource: "MyQuantizedModel", withExtension: "mlmodelc")!, named: "MyQuantizedModel")
                let output = try await modelManager.predict(using: "MyQuantizedModel", input: imageFeatureProvider)
                
                // Process output (e.g., get top label)
                if let label = output.featureValue(forName: "classLabel")?.stringValue {
                    await MainActor.run {
                        self.classificationResult = "Detected: \(label)"
                    }
                }
            } catch {
                await MainActor.run {
                    self.classificationResult = "Error: \(error.localizedDescription)"
                }
            }
            isLoading = false
        }
    }

    // Custom error for MLModelManager
    enum MLModelError: Error, LocalizedError {
        case notFound(modelName: String)
        case predictionFailed(underlyingError: Error)

        var errorDescription: String? {
            switch self {
            case .notFound(let name): return "MLModel '\(name)' not found in cache."
            case .predictionFailed(let error): return "MLModel prediction failed: \(error.localizedDescription)"
            }
        }
    }
    