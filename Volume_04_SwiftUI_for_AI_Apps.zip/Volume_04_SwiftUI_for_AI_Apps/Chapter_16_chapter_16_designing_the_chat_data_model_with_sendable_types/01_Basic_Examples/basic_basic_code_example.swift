
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI // Required for @MainActor and basic UI concepts.

// MARK: - 1. Define Sendable Data Models

/// Represents a user participating in the chat.
/// Since 'id' (UUID) and 'name' (String) are both Sendable,
/// and 'ChatUser' is a struct (value type), it is implicitly Sendable.
struct ChatUser: Identifiable, Hashable, Sendable {
    let id: UUID
    let name: String

    init(id: UUID = UUID(), name: String) {
        self.id = id
        self.name = name
    }
}

/// Represents a single message in the chat.
/// Since 'id' (UUID), 'sender' (ChatUser, which is Sendable),
/// 'content' (String), 'timestamp' (Date), and 'isAIResponse' (Bool) are all Sendable,
/// and 'ChatMessage' is a struct (value type), it is implicitly Sendable.
struct ChatMessage: Identifiable, Hashable, Sendable {
    let id: UUID
    let sender: ChatUser
    let content: String
    let timestamp: Date
    let isAIResponse: Bool // Indicates if this message originated from an AI.

    init(id: UUID = UUID(), sender: ChatUser, content: String, timestamp: Date = Date(), isAIResponse: Bool = false) {
        self.id = id
        self.sender = sender
        self.content = content
        self.timestamp = timestamp
        self.isAIResponse = isAIResponse
    }
}

// MARK: - 2. Define an Actor for Safe Concurrent Message Management

/// An actor responsible for managing chat messages.
/// Actors provide isolated mutable state, ensuring that access to their properties
/// and methods is serialized, preventing data races.
actor ChatService {
    private var messages: [ChatMessage] = [] // Internal state, protected by the actor.

    /// Adds a new message to the chat service.
    /// Since ChatMessage is Sendable, it can be safely passed into the actor's isolated context.
    ///
    /// - Parameter message: The ChatMessage to add.
    func addMessage(_ message: ChatMessage) {
        messages.append(message)
        print("[\(Thread.current.description)] Added message from \(message.sender.name): \(message.content)")
    }

    /// Simulates an AI response based on a user message.
    /// This function performs asynchronous work and returns a Sendable ChatMessage.
    ///
    /// - Parameter userMessage: The user's message to respond to.
    /// - Returns: A simulated AI response message.
    func simulateAIResponse(for userMessage: ChatMessage) async -> ChatMessage {
        // Simulate some asynchronous processing, e.g., calling an ML model
        try? await Task.sleep(for: .milliseconds(500))

        let aiUser = ChatUser(name: "AI Assistant")
        let responseContent: String
        if userMessage.content.lowercased().contains("hello") {
            responseContent = "Hello there! How can I assist you today?"
        } else if userMessage.content.lowercased().contains("swiftui") {
            responseContent = "SwiftUI is great for building declarative UIs. What would you like to know?"
        } else {
            responseContent = "That's an interesting thought! Could you tell me more?"
        }

        let aiResponse = ChatMessage(sender: aiUser, content: responseContent, isAIResponse: true)
        print("[\(Thread.current.description)] Generated AI response: \(aiResponse.content)")
        return aiResponse // ChatMessage is Sendable, so it can be safely returned.
    }

    /// Retrieves all current messages.
    /// The array of ChatMessage is returned. Since ChatMessage is Sendable,
    /// and Array is Sendable if its elements are Sendable, this operation is safe.
    ///
    /// - Returns: An array of ChatMessage objects.
    func getAllMessages() -> [ChatMessage] {
        return messages
    }
}

// MARK: - 3. SwiftUI View for Display (Illustrating @MainActor)

/// A simple SwiftUI view to display chat messages.
/// UI updates must happen on the main actor.
@MainActor // Ensures all properties and methods of this View are on the main actor.
struct ChatView: View {
    @State private var chatMessages: [ChatMessage] = []
    @State private var newMessageContent: String = ""
    @State private var isLoadingAIResponse: Bool = false

    // Initialize the ChatService as a StateObject or EnvironmentObject in a real app.
    // For this basic example, we'll instantiate it directly.
    private let chatService = ChatService()

    private let currentUser = ChatUser(name: "You")

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(chatMessages) { message in
                        HStack {
                            if message.isAIResponse {
                                Spacer()
                                ChatBubble(message: message, isUser: false)
                            } else {
                                ChatBubble(message: message, isUser: true)
                                Spacer()
                            }
                        }
                    }
                }
                .padding()
            }
            .background(Color.gray.opacity(0.1))

            HStack {
                TextField("Type your message...", text: $newMessageContent)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Button("Send") {
                    sendMessage()
                }
                .padding(.trailing)
                .disabled(newMessageContent.isEmpty || isLoadingAIResponse)
            }
            .padding(.bottom)

            if isLoadingAIResponse {
                ProgressView()
                    .padding(.bottom)
            }
        }
        .navigationTitle("AI Chat")
        .onAppear {
            // Load initial messages if any (not implemented in this basic example)
        }
    }

    /// Sends a user message and triggers an AI response.
    private func sendMessage() {
        guard !newMessageContent.isEmpty else { return }

        let userMessage = ChatMessage(sender: currentUser, content: newMessageContent)
        newMessageContent = "" // Clear input field

        Task {
            // Add user message to service (actor call)
            await chatService.addMessage(userMessage)

            // Update UI on main actor (safe because chatMessages is @State)
            chatMessages.append(userMessage)

            isLoadingAIResponse = true

            // Simulate AI response (actor call, potentially on a different thread)
            let aiResponse = await chatService.simulateAIResponse(for: userMessage)

            // Add AI response to service (actor call)
            await chatService.addMessage(aiResponse)

            // Update UI on main actor (safe because chatMessages is @State)
            chatMessages.append(aiResponse)

            isLoadingAIResponse = false
        }
    }
}

/// A helper view for displaying chat bubbles.
@MainActor
struct ChatBubble: View {
    let message: ChatMessage
    let isUser: Bool

    var body: some View {
        Text(message.content)
            .padding(10)
            .background(isUser ? Color.blue : Color.green.opacity(0.8))
            .foregroundColor(.white)
            .cornerRadius(10)
            .shadow(radius: 2)
    }
}

// MARK: - 4. Application Entry Point (for demonstration)

// This structure would typically be in an App file (e.g., MyApp.swift)
@main
@available(iOS 15.0, *) // Sendable and async/await require iOS 15+
struct SendableChatApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView { // Use NavigationView for navigationTitle to work
                ChatView()
            }
        }
    }
}
