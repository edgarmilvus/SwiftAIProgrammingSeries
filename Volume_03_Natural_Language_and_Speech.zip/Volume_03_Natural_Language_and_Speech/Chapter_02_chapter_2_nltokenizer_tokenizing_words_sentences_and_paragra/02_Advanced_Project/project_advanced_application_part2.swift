
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import NaturalLanguage // Core framework for NLTokenizer

// MARK: - 1. Error Handling

/// Custom errors that can occur during document analysis.
enum DocumentAnalyzerError: Error, LocalizedError {
    /// Thrown when the input text is empty or consists only of whitespace.
    case emptyInput
    /// Thrown when tokenization fails for an unexpected reason.
    case tokenizationFailed(unit: NLTokenizer.Unit, underlyingError: Error?)
    /// Thrown for any other unexpected internal error during processing.
    case internalError(message: String)

    var errorDescription: String? {
        switch self {
        case .emptyInput:
            return NSLocalizedString("The input document is empty or contains no meaningful text.", comment: "Empty input error description")
        case .tokenizationFailed(let unit, let underlyingError):
            let unitDescription = String(describing: unit)
            if let underlyingError = underlyingError {
                return NSLocalizedString("Failed to tokenize \(unitDescription)s. Underlying error: \(underlyingError.localizedDescription)", comment: "Tokenization failed error description with underlying error")
            } else {
                return NSLocalizedString("Failed to tokenize \(unitDescription)s due to an unknown issue.", comment: "Tokenization failed error description")
            }
        case .internalError(let message):
            return NSLocalizedString("An internal error occurred: \(message)", comment: "Internal error description")
        }
    }
}

// MARK: - 2. Data Models

/// Represents a tokenized segment of text, such as a word, sentence, or paragraph.
struct TokenizedSegment: Identifiable, Hashable {
    let id = UUID() // Unique identifier for SwiftUI list display
    let text: String
    let range: NSRange // The range of the segment within the original text

    /// Initializes a new tokenized segment.
    /// - Parameters:
    ///   - text: The actual string content of the segment.
    ///   - range: The NSRange of this segment within the original full text.
    init(text: String, range: NSRange) {
        self.text = text
        self.range = range
    }
}

/// The comprehensive result of a document analysis, containing tokenized units and counts.
struct DocumentAnalysisResult {
    let originalText: String
    let language: NLLanguage? // The detected language of the document
    let paragraphs: [TokenizedSegment]
    let sentences: [TokenizedSegment]
    let words: [TokenizedSegment]

    /// The total number of paragraphs in the document.
    var paragraphCount: Int { paragraphs.count }
    /// The total number of sentences in the document.
    var sentenceCount: Int { sentences.count }
    /// The total number of words in the document.
    var wordCount: Int { words.count }

    /// Initializes a new document analysis result.
    /// - Parameters:
    ///   - originalText: The full text that was analyzed.
    ///   - language: The detected language of the text, if available.
    ///   - paragraphs: An array of tokenized paragraphs.
    ///   - sentences: An array of tokenized sentences.
    ///   - words: An array of tokenized words.
    init(originalText: String, language: NLLanguage?, paragraphs: [TokenizedSegment], sentences: [TokenizedSegment], words: [TokenizedSegment]) {
        self.originalText = originalText
        self.language = language
        self.paragraphs = paragraphs
        self.sentences = sentences
        self.words = words
    }
}

// MARK: - 3. The Analyzer Service

/// A service for analyzing document text using `NLTokenizer` to break it down into linguistic units.
/// This class is designed to be thread-safe and efficient, leveraging Swift concurrency.
@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *) // NLTokenizer availability
final class DocumentAnalyzer {

    /// The locale to use for tokenization. If nil, the system's current locale is used.
    /// Specifying a locale can improve accuracy for specific languages.
    private let locale: Locale?

    /// Initializes a new `DocumentAnalyzer` instance.
    /// - Parameter locale: An optional `Locale` to guide the tokenizer. If `nil`, the system's default locale is used.
    init(locale: Locale? = nil) {
        self.locale = locale
    }

    /// Analyzes the provided document text, breaking it down into paragraphs, sentences, and words.
    ///
    /// This method uses `NLTokenizer` for linguistic segmentation and leverages Swift's
    /// `async/await` for non-blocking execution, making it suitable for processing large texts
    /// in a responsive application.
    ///
    /// - Parameter text: The document text to analyze.
    /// - Returns: A `DocumentAnalysisResult` containing the tokenized units and counts.
    /// - Throws: `DocumentAnalyzerError` if the input is invalid or tokenization fails.
    func analyzeDocument(text: String) async throws -> DocumentAnalysisResult {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw DocumentAnalyzerError.emptyInput
        }

        // Detect the language of the text. This is useful for more accurate tokenization
        // and can be passed to the NLTokenizer initializer.
        let language = NLLanguageRecognizer.dominantLanguage(for: text)

        // Use a TaskGroup to potentially parallelize expensive tokenization tasks if needed,
        // though for NLTokenizer's internal implementation, sequential calls are often
        // efficient enough and simplify error handling. Here, we'll demonstrate sequential
        // async calls for clarity, but a TaskGroup could be used for processing
        // sub-sections of a very large document if the tokenizer supported partial ranges.

        // Tokenize paragraphs
        let paragraphs = try await tokenize(text: text, unit: .paragraph, language: language)

        // Tokenize sentences
        let sentences = try await tokenize(text: text, unit: .sentence, language: language)

        // Tokenize words
        let words = try await tokenize(text: text, unit: .word, language: language)

        return DocumentAnalysisResult(
            originalText: text,
            language: language,
            paragraphs: paragraphs,
            sentences: sentences,
            words: words
        )
    }

    /// Helper function to tokenize a given text for a specific unit type.
    ///
    /// - Parameters:
    ///   - text: The input string to tokenize.
    ///   - unit: The `NLTokenizer.Unit` to use for tokenization (e.g., `.word`, `.sentence`, `.paragraph`).
    ///   - language: The detected language of the text. Used to initialize the tokenizer for better accuracy.
    /// - Returns: An array of `TokenizedSegment` representing the tokens.
    /// - Throws: `DocumentAnalyzerError.tokenizationFailed` if the process encounters an error.
    private func tokenize(text: String, unit: NLTokenizer.Unit, language: NLLanguage?) async throws -> [TokenizedSegment] {
        return try await withCheckedThrowingContinuation { continuation in
            let tokenizer: NLTokenizer
            if let lang = language {
                tokenizer = NLTokenizer(unit: unit, language: lang)
            } else {
                tokenizer = NLTokenizer(unit: unit) // Fallback to system locale if language not detected
            }
            tokenizer.string = text

            var segments: [TokenizedSegment] = []
            let fullRange = NSRange(location: 0, length: text.utf16.count)

            // NLTokenizer's enumerateTokens is synchronous but callback-based.
            // We wrap it in a continuation to make it `async`.
            tokenizer.enumerateTokens(in: fullRange) { tokenRange, _ in
                if let range = Range(tokenRange, in: text) {
                    let segmentText = String(text[range])
                    segments.append(TokenizedSegment(text: segmentText, range: tokenRange))
                    return true // Continue enumeration
                } else {
                    // This case should ideally not happen if `tokenRange` is valid.
                    // If it does, it indicates an internal inconsistency.
                    continuation.resume(throwing: DocumentAnalyzerError.internalError(
                        message: "Invalid range returned by NLTokenizer for unit \(unit)."
                    ))
                    return false // Stop enumeration
                }
            }
            continuation.resume(returning: segments)
        }
    }
}

// MARK: - Example Usage in a Real-World Apple App Context (e.g., a Document Scanner App)

@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
class DocumentScannerViewModel: ObservableObject {
    @Published var documentText: String = ""
    @Published var analysisResult: DocumentAnalysisResult?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let analyzer = DocumentAnalyzer()

    /// Simulates scanning a document and processing its text.
    /// In a real app, `scannedText` would come from an OCR engine or user input.
    func processScannedDocument(scannedText: String) {
        isLoading = true
        errorMessage = nil
        Task {
            do {
                let result = try await analyzer.analyzeDocument(text: scannedText)
                await MainActor.run {
                    self.analysisResult = result
                    self.documentText = scannedText // Store for display
                }
            } catch let error as DocumentAnalyzerError {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    print("Document analysis error: \(error.localizedDescription)")
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                    print("Unexpected error: \(error.localizedDescription)")
                }
            }
            await MainActor.run {
                self.isLoading = false
            }
        }
    }

    /// Provides a sample document for testing.
    func loadSampleDocument() {
        let sample = """
        The quick brown fox jumps over the lazy dog. This is the first sentence. The second sentence is a bit longer, containing some technical terms like "NLTokenizer" and "NaturalLanguage.framework".

        Paragraph two. This paragraph discusses the importance of Swift 6 concurrency. Async/await makes writing asynchronous code much easier and more readable. For example, processing large documents can now be done without blocking the UI.

        A final short paragraph. Dr. Smith reviewed the findings.
        """
        processScannedDocument(scannedText: sample)
    }

    /// Clears the current analysis and document text.
    func clearDocument() {
        documentText = ""
        analysisResult = nil
        errorMessage = nil
        isLoading = false
    }
}

// MARK: - Example of how to use the ViewModel (e.g., in a SwiftUI View)
/*
 import SwiftUI

 @available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
 struct DocumentAnalyzerView: View {
     @StateObject private var viewModel = DocumentScannerViewModel()

     var body: some View {
         NavigationView {
             VStack(alignment: .leading, spacing: 10) {
                 if viewModel.isLoading {
                     ProgressView("Analyzing Document...")
                 } else if let errorMessage = viewModel.errorMessage {
                     Text("Error: \(errorMessage)")
                         .foregroundColor(.red)
                 } else if let result = viewModel.analysisResult {
                     ScrollView {
                         VStack(alignment: .leading, spacing: 5) {
                             Text("Original Text:")
                                 .font(.headline)
                             Text(result.originalText)
                                 .font(.body)
                                 .padding(.bottom)

                             Divider()

                             Text("Analysis Summary:")
                                 .font(.headline)
                             Text("Detected Language: \(result.language?.rawValue ?? "N/A")")
                             Text("Paragraphs: \(result.paragraphCount)")
                             Text("Sentences: \(result.sentenceCount)")
                             Text("Words: \(result.wordCount)")
                                 .padding(.bottom)

                             Divider()

                             Text("Tokenized Paragraphs:")
                                 .font(.headline)
                             ForEach(result.paragraphs) { paragraph in
                                 Text("• \(paragraph.text)")
                                     .font(.subheadline)
                             }
                             .padding(.bottom)

                             Divider()

                             Text("Tokenized Sentences:")
                                 .font(.headline)
                             ForEach(result.sentences) { sentence in
                                 Text("• \(sentence.text)")
                                     .font(.subheadline)
                             }
                             .padding(.bottom)

                             Divider()

                             Text("Tokenized Words:")
                                 .font(.headline)
                             // Displaying too many words can be overwhelming,
                             // so we might limit it or provide a search.
                             // For demonstration, let's show a few.
                             Text(result.words.prefix(20).map { $0.text }.joined(separator: ", ") + (result.words.count > 20 ? "..." : ""))
                                 .font(.subheadline)
                         }
                         .padding()
                     }
                 } else {
                     Text("Load a document to start analysis.")
                         .foregroundColor(.secondary)
                 }

                 Spacer()

                 HStack {
                     Button("Load Sample Document") {
                         viewModel.loadSampleDocument()
                     }
                     .buttonStyle(.borderedProminent)

                     Button("Clear") {
                         viewModel.clearDocument()
                     }
                     .buttonStyle(.bordered)
                 }
                 .padding()
             }
             .navigationTitle("Document Insight")
         }
     }
 }
 */

// MARK: - Demonstration of usage
@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
func demonstrateDocumentAnalyzer() async {
    let analyzer = DocumentAnalyzer()
    let text1 = "The quick brown fox jumps over the lazy dog. This is a test. Dr. Smith arrived."
    let text2 = "  " // Empty input

    print("--- Analyzing Valid Text ---")
    do {
        let result = try await analyzer.analyzeDocument(text: text1)
        print("Original Text: \"\(result.originalText)\"")
        print("Detected Language: \(result.language?.rawValue ?? "Unknown")")
        print("Paragraph Count: \(result.paragraphCount)")
        print("Sentence Count: \(result.sentenceCount)")
        print("Word Count: \(result.wordCount)")
        print("First 3 Words: \(result.words.prefix(3).map { $0.text })")
        print("First Sentence: \"\(result.sentences.first?.text ?? "N/A")\"")
        print("All Paragraphs:")
        result.paragraphs.forEach { print("  - \($0.text)") }
    } catch {
        print("Error analyzing text 1: \(error.localizedDescription)")
    }

    print("\n--- Analyzing Empty Text ---")
    do {
        _ = try await analyzer.analyzeDocument(text: text2)
    } catch {
        print("Error analyzing text 2: \(error.localizedDescription)")
    }

    print("\n--- Analyzing a more complex text ---")
    let complexText = """
    "Hello, world!" said the programmer. "How are you doing today?" The system responded, "I'm functioning optimally. Version 1.2.3."

    This is a second paragraph. It contains some numbers like 123, and special characters! Also, abbreviations like U.S.A. and e.g. are handled.

    Finally, a third paragraph.
    """
    do {
        let result = try await analyzer.analyzeDocument(text: complexText)
        print("Original Text: \"\(result.originalText)\"")
        print("Detected Language: \(result.language?.rawValue ?? "Unknown")")
        print("Paragraph Count: \(result.paragraphCount)")
        print("Sentence Count: \(result.sentenceCount)")
        print("Word Count: \(result.wordCount)")
        print("All Sentences:")
        result.sentences.forEach { print("  - \($0.text)") }
        print("All Words (first 10):")
        print(result.words.prefix(10).map { $0.text })
    } catch {
        print("Error analyzing complex text: \(error.localizedDescription)")
    }
}

// To run this demonstration:
// In an async context (e.g., an XCTest or a top-level async function in a script):
// await demonstrateDocumentAnalyzer()
