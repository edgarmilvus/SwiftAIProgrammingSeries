
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit
import RoomPlan
import RealityKit
import Combine

/// An error type specifically for our Spatial Architect scanning operations.
enum ScanningError: Error {
    case sessionFailed(String)
    case exportFailed
    case hardwareIncompatible
}

/// The `RoomScannerViewController` manages the lifecycle of a RoomPlan session.
/// It uses `@MainActor` to ensure all UI updates occur on the main thread,
/// adhering to Swift 6 strict concurrency requirements.
@available(iOS 16.0, *)
@MainActor
class RoomScannerViewController: UIViewController {

    // MARK: - UI Components
    
    /// The specialized view provided by RoomPlan that handles the AR overlay and UI instructions.
    private let captureView = RoomCaptureView()
    
    /// A button to finalize the scan and trigger the export process.
    private let finalizeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Finish Scan", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    // MARK: - RoomPlan Properties
    
    /// The engine that drives the scanning process.
    private var captureSession = RoomCaptureSession()
    
    /// The configuration defining how the scan behaves (e.g., scanning speed, detail).
    private var captureConfig = RoomCaptureConfig()
    
    /// Holds the final reconstructed room data once the scan is complete.
    private var capturedRoom: CapturedRoom?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupCaptureView()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        startScanning()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopScanning()
    }

    // MARK: - Setup

    /// Configures the layout of the UI elements.
    private func setupUI() {
        view.backgroundColor = .black
        
        view.addSubview(finalizeButton)
        
        NSLayoutConstraint.activate([
            finalizeButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            finalizeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            finalizeButton.widthAnchor.constraint(equalToConstant: 150),
            finalizeButton.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        finalizeButton.addTarget(self, action: #selector(handleFinalizeTap), for: .touchUpInside)
    }

    /// Initializes the RoomCaptureView and sets its delegate.
    private func setupCaptureView() {
        captureView.frame = view.bounds
        captureView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(captureView)
        
        // The view's delegate is responsible for responding to scanning events.
        captureView.delegate = self
    }

    // MARK: - Session Management

    /// Starts the RoomPlan session. 
    /// This initiates the LiDAR sensor and the ML segmentation pipeline.
    private func startScanning() {
        // In a real app, check for LiDAR availability here.
        captureSession.run(configuration: captureConfig)
        captureView.session = captureSession
    }

    /// Stops the session safely.
    private func stopScanning() {
        captureSession.stop()
    }

    // MARK: - Actions

    /// Triggered when the user taps 'Finish Scan'.
    /// Uses Swift 6 Task to handle the potentially heavy export process off the main thread.
    @objc private func handleFinalizeTap() {
        // We capture the current state of the room from the session.
        // Note: In a real app, you'd handle the completion via the delegate.
        Task {
            do {
                try await finalizeScan()
            } catch {
                print("Error finalizing scan: \(error)")
                // In production, present a UIAlertController here.
            }
        }
    }

    /// Performs the finalization of the scan and exports the data.
    /// - Throws: `ScanningError` if the process fails.
    private func finalizeScan() async throws {
        // 1. Stop the session to prevent further data mutation.
        captureSession.stop()
        
        // 2. Retrieve the captured room data. 
        // Note: For this example, we assume the delegate has populated 'capturedRoom'.
        guard let room = capturedRoom else {
            throw ScanningError.exportFailed
        }
        
        // 3. Export to USDZ. This is a heavy I/O operation.
        // We use the RoomCaptureSession's ability to export.
        let exportURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("ScannedRoom_\(UUID().uuidString).usdz")
        
        // This is a simplified representation of the export logic.
        // In a real implementation, you would use the RoomCaptureSession's completion handlers.
        print("Exporting room to: \(exportURL.path)")
        
        // Success!
        await showSuccessAlert(url: exportURL)
    }
    
    @MainActor
    private func showSuccessAlert(url: URL) {
        let alert = UIAlertController(title: "Scan Complete", message: "Room saved as USDZ", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - RoomCaptureSessionDelegate

extension RoomScannerViewController: RoomCaptureSessionDelegate {
    
    /// Called when the session has successfully captured the room geometry.
    /// This is the most critical callback in the RoomPlan lifecycle.
    func captureSession(_ session: RoomCaptureSession, didUpdate room: CapturedRoom) {
        // The 'room' object contains the semantic model (walls, windows, etc.)
        // We update our local reference so we can export it later.
        // Since this delegate method might be called on a background thread, 
        // we must ensure we update our state safely.
        Task { @MainActor in
            self.capturedRoom = room
        }
    }
    
    /// Called if the session encounters an error (e.g., insufficient light, lost tracking).
    func captureSession(_ session: RoomCaptureSession, didFailWithError error: Error) {
        print("Session failed: \(error.localizedDescription)")
    }
}
