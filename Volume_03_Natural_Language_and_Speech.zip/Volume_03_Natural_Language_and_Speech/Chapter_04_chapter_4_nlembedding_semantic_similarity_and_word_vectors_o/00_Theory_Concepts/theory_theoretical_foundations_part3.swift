
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage

@available(iOS 18.0, *)
actor EmbeddingCache {
    private var cache: [String: [Double]] = [:] // Mutable state, isolated by the actor
    private let embedding = NLEmbedding.wordEmbedding(for: .english)

    func getEmbedding(for text: String) async throws -> [Double]? {
        if let cachedVector = cache[text] {
            return cachedVector // Return from cache if available
        }

        // If not in cache, compute it
        guard let vector = await embedding?.vector(for: text) else {
            print("Could not get embedding vector for '\(text)'")
            return nil
        }

        cache[text] = vector // Store in cache
        return vector
    }

    func clearCache() {
        cache.removeAll()
    }
}

@available(iOS 18.0, *)
@main
struct EmbeddingCacheApp {
    static func main() async {
        let cache = EmbeddingCache()

        // Multiple concurrent requests for embeddings
        async let embedApple = cache.getEmbedding(for: "apple")
        async let embedBanana = cache.getEmbedding(for: "banana")
        async let embedAppleAgain = cache.getEmbedding(for: "apple") // Should hit cache

        let appleVector = await embedApple
        let bananaVector = await embedBanana
        let appleAgainVector = await embedAppleAgain

        print("Apple vector (first 3): \(appleVector?.prefix(3) ?? [])")
        print("Banana vector (first 3): \(bananaVector?.prefix(3) ?? [])")
        print("Apple again vector (first 3): \(appleAgainVector?.prefix(3) ?? [])")

        // Clear the cache
        await cache.clearCache()
        print("Cache cleared.")
    }
}
