
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import UniformTypeIdentifiers

enum IngestionStatus: Sendable {
    case idle
    case processing(fileName: String)
    case completed(Document)
    case failed(Error)
}

@available(iOS 18.0, macOS 15.0, *)
actor IngestionMonitor {
    private let folderURL: URL
    private let loader: LocalFileLoader
    private let splitter: RecursiveTextSplitter
    
    // Using a continuation to bridge the callback-based DispatchSource to AsyncStream
    private var statusContinuation: AsyncStream<IngestionStatus>.Continuation?
    
    lazy var statusStream: AsyncStream<IngestionStatus> = {
        AsyncStream { continuation in
            self.statusContinuation = continuation
        }
    }()

    init(folderURL: URL, loader: LocalFileLoader, splitter: RecursiveTextSplitter) {
        self.folderURL = folderURL
        self.loader = loader
        self.splitter = splitter
    }

    func startMonitoring() async {
        let fileDescriptor = open(folderURL.path, O_EVTONLY)
        guard fileDescriptor >= 0 else { return }
        
        let source = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: fileDescriptor,
            eventMask: .write,
            queue: DispatchQueue.global()
        )
        
        source.setEventHandler {
            // When a write occurs in the folder, trigger processing
            Task { [weak self] in
                await self?.checkForNewFiles()
            }
        }
        
        source.setCancelHandler {
            close(fileDescriptor)
        }
        
        source.resume()
        print("Monitoring started at: \(folderURL.path)")
    }

    private func checkForNewFiles() async {
        do {
            let fileURLs = try FileManager.default.contentsOfDirectory(
                at: folderURL,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: .skipsHiddenFiles
            )
            
            // Use TaskGroup to process files in parallel
            await withTaskGroup(of: Void.self) { group in
                for url in fileURLs where url.pathExtension == "txt" {
                    group.addTask {
                        await self.processFile(at: url)
                    }
                }
            }
        } catch {
            statusContinuation?.yield(.failed(error))
        }
    }

    private func processFile(at url: URL) async {
        let fileName = url.lastPathComponent
        statusContinuation?.yield(.processing(fileName: fileName))
        
        do {
            // 1. Load
            let doc = try await loader.load(from: url)
            
            // 2. Split
            let chunks = await splitter.split(text: doc.content)
            
            // 3. Simulate Embedding Generation
            try await Task.sleep(for: .seconds(1)) 
            
            print("Successfully processed \(chunks.count) chunks for \(fileName)")
            statusContinuation?.yield(.completed(doc))
            
        } catch {
            statusContinuation?.yield(.failed(error))
        }
    }
}
