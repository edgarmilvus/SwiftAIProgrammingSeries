
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation // For NSSummarizeService, Error handling

// MARK: - ViewModel

/// A ViewModel to manage the state and logic for text summarization.
/// It conforms to `ObservableObject` to allow SwiftUI views to react to changes.
@MainActor // Ensures all state updates happen on the main actor, safe for UI
@available(iOS 18.0, *) // NSSummarizeService is available from iOS 18.0+
class SummarizationViewModel: ObservableObject {
    /// The text input by the user that needs to be summarized.
    @Published var inputText: String = ""

    /// The summarized text returned by `NSSummarizeService`.
    @Published var summarizedText: String = "Your summary will appear here."

    /// A boolean flag indicating if a summarization operation is currently in progress.
    @Published var isLoading: Bool = false

    /// An optional error message to display to the user if summarization fails.
    @Published var errorMessage: String?

    /// Performs the summarization of the `inputText` using `NSSummarizeService`.
    /// This is an asynchronous function as summarization can take some time.
    func performSummarization() async {
        // 1. Input Validation: Ensure there's text to summarize.
        guard !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            self.errorMessage = "Please enter some text to summarize."
            return
        }

        // 2. Update UI State: Indicate that summarization is starting.
        self.isLoading = true
        self.errorMessage = nil // Clear previous errors

        do {
            // 3. Create a Summarization Request:
            //    NSSummarizeService.Request encapsulates the text to be summarized.
            let request = NSSummarizeService.Request(text: inputText)

            // 4. Instantiate the Summarization Service:
            //    NSSummarizeService is the entry point for on-device summarization.
            let service = NSSummarizeService()

            // 5. Execute the Summarization:
            //    The `summarize` method is asynchronous and can throw errors.
            let result = try await service.summarize(request)

            // 6. Update UI with Result:
            //    Assign the generated summary to the published property.
            self.summarizedText = result.summary

        } catch {
            // 7. Handle Errors:
            //    If an error occurs during summarization, capture and display it.
            self.errorMessage = "Summarization failed: \(error.localizedDescription)"
            self.summarizedText = "Could not generate summary."
        }

        // 8. Final UI State Update:
        //    Indicate that summarization has completed (whether successful or not).
        self.isLoading = false
    }
}

// MARK: - SwiftUI View

/// The main SwiftUI View for our note summarizer application.
@available(iOS 18.0, *) // This View uses the ViewModel, which requires iOS 18.0+
struct ContentView: View {
    /// An observed object for our ViewModel, allowing the View to react to its published properties.
    @StateObject private var viewModel = SummarizationViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Note Summarizer")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.bottom, 10)

                // Input Text Area
                TextEditor(text: $viewModel.inputText)
                    .frame(height: 150)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    .padding(.horizontal)
                    .autocapitalization(.sentences)
                    .disableAutocorrection(false)
                    .font(.body)
                    .onChange(of: viewModel.inputText) { _ in
                        // Clear summary and error when input changes
                        if !viewModel.isLoading {
                            viewModel.summarizedText = "Your summary will appear here."
                            viewModel.errorMessage = nil
                        }
                    }


                // Summarize Button
                Button {
                    // Trigger the summarization process asynchronously.
                    Task {
                        await viewModel.performSummarization()
                    }
                } label: {
                    if viewModel.isLoading {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .tint(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue.opacity(0.6))
                            .cornerRadius(10)
                    } else {
                        Text("Summarize Note")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                }
                .disabled(viewModel.isLoading || viewModel.inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .padding(.horizontal)

                // Separator
                Divider().padding(.horizontal)

                // Output Summary Area
                VStack(alignment: .leading, spacing: 10) {
                    Text("Summary:")
                        .font(.title2)
                        .fontWeight(.semibold)

                    if let errorMessage = viewModel.errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.subheadline)
                    } else {
                        ScrollView {
                            Text(viewModel.summarizedText)
                                .font(.body)
                                .padding(5)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .frame(minHeight: 100, maxHeight: 200)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                    }
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding(.top, 20)
            .navigationTitle("") // Hide default navigation title
            .navigationBarHidden(true) // Hide navigation bar for cleaner look
        }
    }
}

// MARK: - App Entry Point

/// The main App structure for our SwiftUI application.
@available(iOS 18.0, *) // The App uses ContentView, which requires iOS 18.0+
@main
struct SummarizationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
