
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Custom errors specific to the Claude API interaction.
enum ClaudeError: Error, LocalizedError {
    case invalidAPIKey
    case rateLimitExceeded
    case serverError(String)
    case decodingError
    case emptyInput
    case networkError(Error)

    var errorDescription: String? {
        switch self {
        case .invalidAPIKey: return "The provided API key is invalid."
        case .rateLimitExceeded: return "Too many requests. Please slow down."
        case .serverError(let msg): return "Anthropic server error: \(msg)"
        case .decodingError: return "Failed to parse the response from Claude."
        case .emptyInput: return "The prompt/mood/genre cannot be empty."
        case .networkError(let err): return "Network error: \(err.localizedDescription)"
        }
    }
}

// MARK: - Models

struct ContentBlock: Codable, Sendable {
    let type: String
    let text: String?
    
    enum CodingKeys: String, CodingKey {
        case type
        case text
    }
}

struct Message: Codable, Sendable {
    let role: String
    let content: [ContentBlock]
}

struct AnthropicRequest: Codable, Sendable {
    let model: String
    let system: String
    let messages: [Message]
    let max_tokens: Int
}

struct AnthropicResponse: Codable, Sendable {
    struct Content: Codable, Sendable {
        let type: String
        let text: String
    }
    struct Usage: Codable, Sendable {
        let input_tokens: Int
        let output_tokens: Int
    }
    
    let id: String
    let content: [Content]
    let role: String
    let usage: Usage
}

// MARK: - Actor Implementation

@available(iOS 18.0, macOS 15.0, *)
actor ClaudeNetworkingActor {
    private let apiKey: String
    private let endpoint = URL(string: "https://api.anthropic.com/v1/messages")!
    private let session: URLSession

    init(apiKey: String, session: URLSession = .shared) {
        self.apiKey = apiKey
        self.session = session
    }

    func generateLyrics(prompt: String, mood: String, genre: String) async throws -> String {
        // 1. Validation
        let trimmedPrompt = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedPrompt.isEmpty, !mood.isEmpty, !genre.isEmpty else {
            throw ClaudeError.emptyInput
        }

        // 2. Construct the payload
        let systemPrompt = "You are a professional songwriter. Create poetic fragments based on the user's input."
        let userMessageText = "Write a \(genre) song fragment with a \(mood) mood. Context: \(trimmedPrompt)"
        
        let userMessage = Message(
            role: "user",
            content: [ContentBlock(type: "text", text: userMessageText)]
        )
        
        let requestBody = AnthropicRequest(
            model: "claude-3-5-sonnet-20240620",
            system: systemPrompt,
            messages: [userMessage],
            max_tokens: 1024
        )

        // 3. Prepare the URLRequest
        var urlRequest = URLRequest(url: endpoint)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue("bearer \(apiKey)", forHTTPHeaderField: "x-api-key") // Note: Anthropic uses x-api-key
        urlRequest.setValue("anthropic-version-2023-06-01", forHTTPHeaderField: "anthropic-version")
        urlRequest.httpBody = try JSONEncoder().encode(requestBody)

        // 4. Perform Network Call
        let (data, response) = try await session.data(for: urlRequest)

        // 5. Handle HTTP Status Codes
        guard let httpResponse = response as? HTTPURLResponse else {
            throw ClaudeError.serverError("Invalid response type")
        }

        switch httpResponse.statusCode {
        case 200:
            break // Success
        case 401:
            throw ClaudeError.invalidAPIKey
        case 429:
            throw ClaudeError.rateLimitExceeded
        default:
            let errorMsg = String(data: data, encoding: .utf8) ?? "Unknown Error"
            throw ClaudeError.serverError(errorMsg)
        }

        // 6. Decode Response
        do {
            let decodedResponse = try JSONDecoder().decode(AnthropicResponse.self, from: data)
            return decodedResponse.content.first?.text ?? ""
        } catch {
            throw ClaudeError.decodingError
        }
    }
}
