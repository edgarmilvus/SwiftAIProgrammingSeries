/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// components/Skeleton.tsx
interface SkeletonProps {
  count: number;
  className?: string;
}

export function Skeleton({ count, className }: SkeletonProps) {
  // Render 'count' number of placeholder elements with pulsing animation
  return (
    <div>
      {/* Array.from({ length: count }).map(...) */}
    </div>
  );
}

// components/UserAnalytics.tsx
'use client';

import { useState, useEffect } from 'react';
import { Skeleton } from './Skeleton';

// 1. Define strict interface for data
interface AnalyticsData {
  userId: string;
  activity: number;
}

export function UserAnalytics() {
  const [data, setData] = useState<AnalyticsData[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simulate API fetch
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // const response = await fetch('/api/analytics');
        // const json = await response.json();
        // setData(json);
      } catch (err) {
        setError("Failed to load data");
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  // 2. Handle states (Loading, Error, Success)
  if (isLoading) {
    return <Skeleton count={5} />;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      {/* 3. Render actual data table/charts */}
      {data?.map((item) => (
        <div key={item.userId}>{item.activity}</div>
      ))}
    </div>
  );
}
