
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AVFoundation
import Speech
import NaturalLanguage

/// Custom error types specific to the Voice Journal processing.
enum VoiceJournalError: Error, LocalizedError {
    case speechRecognitionUnavailable
    case audioFileLoadFailed(URL)
    case transcriptionFailed(Error?)
    case sentimentAnalysisFailed(String)
    case permissionDenied(String)
    case invalidAudioFormat
    case unknown

    var errorDescription: String? {
        switch self {
        case .speechRecognitionUnavailable:
            return "Speech recognition is not available on this device or for the current locale."
        case .audioFileLoadFailed(let url):
            return "Failed to load audio file from URL: \(url.lastPathComponent)."
        case .transcriptionFailed(let error):
            return "Transcription failed: \(error?.localizedDescription ?? "Unknown error")."
        case .sentimentAnalysisFailed(let text):
            return "Sentiment analysis failed for text: \(text.prefix(50))..."
        case .permissionDenied(let type):
            return "\(type) permission denied. Please enable it in Settings."
        case .invalidAudioFormat:
            return "The audio file format is not supported for transcription."
        case .unknown:
            return "An unknown error occurred during processing."
        }
    }
}
