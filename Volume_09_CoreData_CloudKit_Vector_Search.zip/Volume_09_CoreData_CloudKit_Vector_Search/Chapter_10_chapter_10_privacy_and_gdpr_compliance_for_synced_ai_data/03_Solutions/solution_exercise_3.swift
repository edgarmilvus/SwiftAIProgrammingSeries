
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CoreData

enum ErasureError: Error {
    case databaseDeletionFailed
    case indexPurgeFailed
    case memoryInvalidationFailed
}

/// A mock high-performance vector index.
class LocalVectorIndex {
    private var index: [UUID: [Float]] = [:]
    private let lock = NSLock()

    func removeVector(forID id: UUID) throws {
        lock.lock()
        defer { lock.unlock() }
        
        guard index.removeValue(forKey: id) != nil else {
            // In a real scenario, we might not throw if it's already gone, 
            // but for this exercise, we follow the "all or nothing" requirement.
            throw ErasureError.indexPurgeFailed
        }
        print("Vector index re-optimized after removal of \(id).")
    }
}

/// An actor to orchestrate the complex, multi-step erasure process.
actor PrivacyPurgeService {
    private let container: NSPersistentContainer
    private let vectorIndex: LocalVectorIndex
    private let cache = NSCache<NSString, NSArray>()

    init(container: NSPersistentContainer, vectorIndex: LocalVectorIndex) {
        self.container = container
        self.vectorIndex = vectorIndex
    }

    /// Performs a total erasure of all data associated with a specific note.
    func performTotalErasure(forNoteID noteID: UUID) async throws {
        print("🚀 Starting Nuclear Option for Note: \(noteID)")

        // Step 1: Local & Cloud Deletion
        // Deleting from an NSPersistentCloudKitContainer context automatically 
        // marks the record for deletion in CloudKit during the next sync cycle.
        try await deleteFromCoreData(noteID: noteID)

        // Step 2: Index Purge
        // We must ensure the mathematical representation is gone.
        do {
            try vectorIndex.removeVector(forID: noteID)
        } catch {
            print("❌ Critical Failure: Vector Index failed to purge.")
            throw ErasureError.indexPurgeFailed
        }

        // Step 3: Memory Invalidation
        invalidateMemory(for: noteID)
        
        print("✅ Total Erasure Complete for \(noteID).")
    }

    private func deleteFromCoreData(noteID: UUID) async throws {
        let context = container.newBackgroundContext()
        try await context.perform {
            let request: NSFetchRequest<SensitiveContent> = NSFetchRequest(entityName: "SensitiveContent")
            request.predicate = NSPredicate(format: "id == %@", noteID as CVarArg)
            
            let results = try context.fetch(request)
            for object in results {
                context.delete(object)
            }
            
            if context.hasChanges {
                try context.save()
            } else {
                print("ℹ️ No local records found to delete.")
            }
        }
    }

    private func invalidateMemory(for noteID: UUID) {
        let key = noteID.uuidString as NSString
        cache.removeObject(forKey: key)
        print("🗑️ In-memory cache invalidated.")
    }
}
