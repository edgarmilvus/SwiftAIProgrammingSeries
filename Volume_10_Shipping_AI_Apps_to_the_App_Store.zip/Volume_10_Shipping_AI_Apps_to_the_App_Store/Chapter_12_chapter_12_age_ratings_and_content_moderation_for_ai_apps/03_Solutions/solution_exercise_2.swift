
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Observation

// MARK: - Models
enum AgeCategory {
    case child
    case hobbyist
    case professional
}

@Observable
class SafetySettings {
    var profile: SafetyProfile
    
    init(profile: SafetyProfile) {
        self.profile = profile
    }
}

struct SafetyProfile {
    let ageCategory: AgeCategory
    let isStrictModerationEnabled: Bool
    
    var isStrict: Bool {
        ageCategory == .child || isStrictModerationEnabled
    }
}

// MARK: - View Modifiers
struct FeatureLockModifier: ViewModifier {
    @Environment(SafetySettings.self) private var settings
    
    func body(content: Content) -> some View {
        if settings.profile.isStrict {
            HStack {
                Image(systemName: "lock.fill")
                Text("Locked in Safe Mode")
            }
            .foregroundStyle(.secondary)
            .padding()
            .background(Capsule().fill(.ultraThinMaterial))
        } else {
            content
        }
    }
}

extension View {
    func restrictedInSafeMode() -> some View {
        self.modifier(FeatureLockModifier())
    }
}

// MARK: - Components
struct SafetyDisclaimerView: View {
    @Environment(SafetySettings.self) private var settings
    
    var body: some View {
        Text(settings.profile.isStrict ? 
             "This AI is filtered. Some topics are restricted." : 
             "Warning: This AI may generate unpredictable or mature content.")
            .font(.caption)
            .foregroundStyle(.orange)
            .padding()
            .multilineTextAlignment(.center)
    }
}

// MARK: - Main View
struct AISuiteView: View {
    @State private var settings = SafetySettings(
        profile: SafetyProfile(ageCategory: .hobbyist, isStrictModerationEnabled: false)
    )
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                SafetyDisclaimerView()
                
                // A feature available to everyone
                Button("Basic Chat") { }
                    .buttonStyle(.borderedProminent)
                
                // A feature restricted in Safe Mode
                Button("Generate Mature Concept") { }
                    .buttonStyle(.borderedProminent)
                    .restrictedInSafeMode()
                
                Spacer()
                
                // Settings Toggle
                Toggle("Strict Moderation", isOn: Binding(
                    get: { settings.profile.isStrictModerationEnabled },
                    set: { newValue in
                        withAnimation(.spring()) {
                            settings.profile = SafetyProfile(
                                ageCategory: settings.profile.ageCategory,
                                isStrictModerationEnabled: newValue
                            )
                        }
                    }
                ))
                .padding()
            }
            .navigationTitle("AI Creative Suite")
            .environment(settings) // Propagating the source of truth
        }
    }
}
