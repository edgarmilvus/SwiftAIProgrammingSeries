
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import AppTrackingTransparency

// 1. Protocol Definition
protocol PersonalizationStrategy: Sendable {
    var name: String { get }
    func generateResponse(prompt: String) async throws -> String
}

// 2. Implementation A: Local Layer (Privacy-First)
struct OnDeviceStrategy: PersonalizationStrategy {
    let name = "Local Neural Engine"
    
    func generateResponse(prompt: String) async throws -> String {
        // Simulate low-latency ANE processing
        try await Task.sleep(for: .milliseconds(200))
        return "[Local AI] Responding to '\(prompt)' using on-device privacy-safe data."
    }
}

// 3. Implementation B: Cloud Layer (High Capability)
struct CloudContextStrategy: PersonalizationStrategy {
    let name = "Global Cloud LLM"
    let idfa: String
    
    func generateResponse(prompt: String) async throws -> String {
        // Simulate high-latency cloud processing with IDFA context
        try await Task.sleep(for: .seconds(1))
        return "[Cloud AI] Responding to '\(prompt)' using global contextual awareness (IDFA: \(idfa))."
    }
}

// 4. The Coordinator
actor PersonalizationCoordinator {
    private var currentStrategy: PersonalizationStrategy?
    
    func resolveStrategy() async -> PersonalizationStrategy {
        let status = ATTrackingManager.trackingAuthorizationStatus
        
        if status == .authorized {
            // In a real app, fetch the actual IDFA via ASIdentifierManager
            let mockIDFA = "0000-0000-0000-0000" 
            return CloudContextStrategy(idfa: mockIDFA)
        } else {
            return OnDeviceStrategy()
        }
    }
    
    func executeInference(prompt: String) async throws -> String {
        // Ensure we have a strategy
        let strategy = currentStrategy ?? await resolveStrategy()
        self.currentStrategy = strategy
        
        do {
            return try await strategy.generateResponse(prompt: prompt)
        } catch {
            // Fallback Chain: If Cloud fails, attempt to switch to Local
            if strategy is CloudContextStrategy {
                print("Cloud failed, falling back to Local.")
                let fallback = OnDeviceStrategy()
                self.currentStrategy = fallback
                return try await fallback.generateResponse(prompt: prompt)
            }
            throw error
        }
    }
}
