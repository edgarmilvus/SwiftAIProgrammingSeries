
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import Vision
import UIKit
import CoreGraphics
import Accelerate // For vImage
@preconcurrency import Accelerate // For Swift 6 concurrency safety

// Assume MobileNetV2.mlmodel is included in your project (same as Exercise 1)

@available(iOS 18.0, *)
extension UIImage {

    /// Converts a UIImage to a CVPixelBuffer using CoreGraphics for scaling and format conversion.
    /// This method is generally efficient and widely compatible.
    func toCVPixelBufferCoreGraphics(targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        var pixelBuffer: CVPixelBuffer?
        let attributes = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ] as CFDictionary

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let unwrappedPixelBuffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0)) }

        let baseAddress = CVPixelBufferGetBaseAddress(unwrappedPixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(unwrappedPixelBuffer)

        guard let context = CGContext(data: baseAddress,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: bytesPerRow,
                                      space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            return nil
        }

        context.clear(CGRect(x: 0, y: 0, width: width, height: height))
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        context.draw(self.cgImage!, in: rect)

        return unwrappedPixelBuffer
    }

    /// Converts a UIImage to a CVPixelBuffer using vImage for highly optimized scaling and format conversion.
    /// This method can offer superior performance for repetitive, high-throughput tasks.
    func toCVPixelBufferVImage(targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        guard let cgImage = self.cgImage else { return nil }
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        // 1. Create a CVPixelBuffer for the output
        var outputPixelBuffer: CVPixelBuffer?
        let attributes = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ] as CFDictionary

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes,
                                         &outputPixelBuffer)

        guard status == kCVReturnSuccess, let unwrappedOutputPixelBuffer = outputPixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(unwrappedOutputPixelBuffer, .init(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(unwrappedOutputPixelBuffer, .init(rawValue: 0)) }

        // 2. Convert CGImage to vImage_Buffer
        var format = vImage_CGImageFormat(
            bitsPerComponent: UInt32(cgImage.bitsPerComponent),
            bitsPerPixel: UInt32(cgImage.bitsPerPixel),
            colorSpace: Unmanaged.passRetained(cgImage.colorSpace!),
            bitmapInfo: cgImage.bitmapInfo,
            version: 0,
            decode: nil,
            renderingIntent: .defaultIntent
        )

        var sourceBuffer = vImage_Buffer()
        var error = vImageBuffer_InitWithCGImage(&sourceBuffer, &format, nil, cgImage, kvImageNoFlags)
        guard error == kvImageNoError else {
            print("vImageBuffer_InitWithCGImage failed: \(error)")
            return nil
        }
        defer { free(sourceBuffer.data) } // Ensure source buffer data is freed

        // 3. Prepare destination vImage_Buffer pointing to CVPixelBuffer's base address
        let destinationBaseAddress = CVPixelBufferGetBaseAddress(unwrappedOutputPixelBuffer)
        let destinationBytesPerRow = CVPixelBufferGetBytesPerRow(unwrappedOutputPixelBuffer)

        var destinationBuffer = vImage_Buffer(data: destinationBaseAddress,
                                              height: vImagePixelCount(height),
                                              width: vImagePixelCount(width),
                                              rowBytes: destinationBytesPerRow)

        // 4. Perform scaling and format conversion using vImage
        // Assuming input CGImage is ARGB and output is BGRA (kCVPixelFormatType_32BGRA)
        // If the source is not ARGB, an intermediate conversion might be needed.
        // Here, we assume the CGImage is compatible or vImage can handle the conversion.
        // For BGRA output from ARGB input, a simple channel reordering might be needed or
        // using vImageConvert_ARGB8888ToBGRA8888 if the input is guaranteed ARGB.
        // For simplicity, let's assume direct scaling to ARGB, then convert to BGRA if necessary.

        // If the pixelFormat is kCVPixelFormatType_32BGRA, we need to convert from ARGB (common for CGImage)
        let map: [UInt8] = [2, 1, 0, 3] // ARGB to BGRA: R(2), G(1), B(0), A(3)
        var backgroundColor: [UInt8] = [0, 0, 0, 0] // Black, fully transparent

        error = vImagePermuteChannels_ARGB8888(&sourceBuffer, &sourceBuffer, map, kvImageNoFlags)
        guard error == kvImageNoError else {
            print("vImagePermuteChannels_ARGB8888 failed: \(error)")
            return nil
        }

        error = vImageScale_ARGB8888(&sourceBuffer, &destinationBuffer, nil, kvImageNoFlags)
        guard error == kvImageNoError else {
            print("vImageScale_ARGB8888 failed: \(error)")
            return nil
        }
        
        return unwrappedOutputPixelBuffer
    }
}

@available(iOS 18.0, *)
class ImagePreprocessingOptimizer {
    private let targetSize = CGSize(width: 224, height: 224) // MobileNetV2 input size
    private let testImageCount = 50 // Number of times to run preprocessing for average
    
    // Core ML model instance (for integration test)
    private var model: MobileNetV2?
    
    init() {
        // Initialize model for integration test
        let config = MLModelConfiguration()
        config.computeUnits = .all // Use .all for general performance
        self.model = try? MobileNetV2(configuration: config)
    }

    @MainActor
    func runOptimizationExperiment() async {
        guard let highResImage = UIImage(named: "high_res_image") else { // Add a high-res image to Assets
            fatalError("High resolution image not found. Please add 'high_res_image.jpg' to your Assets.xcassets.")
        }
        print("--- Preprocessing Optimization Experiment ---")

        // 1. CoreGraphics Measurement
        print("\nMeasuring CoreGraphics preprocessing...")
        var totalCoreGraphicsDuration: Duration = .zero
        for _ in 0..<testImageCount {
            let startTime = ContinuousClock().now
            _ = highResImage.toCVPixelBufferCoreGraphics(targetSize: targetSize)
            totalCoreGraphicsDuration += (ContinuousClock().now - startTime)
        }
        let avgCoreGraphicsDuration = totalCoreGraphicsDuration / Double(testImageCount)
        print("Average CoreGraphics preprocessing time over \(testImageCount) runs: \(avgCoreGraphicsDuration.formatted(.units(fractionalPart: .show(length: 6))))")

        // 2. vImage Measurement
        print("\nMeasuring vImage preprocessing...")
        var totalVImageDuration: Duration = .zero
        for _ in 0..<testImageCount {
            let startTime = ContinuousClock().now
            _ = highResImage.toCVPixelBufferVImage(targetSize: targetSize)
            totalVImageDuration += (ContinuousClock().now - startTime)
        }
        let avgVImageDuration = totalVImageDuration / Double(testImageCount)
        print("Average vImage preprocessing time over \(testImageCount) runs: \(avgVImageDuration.formatted(.units(fractionalPart: .show(length: 6))))")

        // 3. Integration Test (Conceptual with Core ML)
        print("\n--- Integration with Core ML (Conceptual) ---")
        guard let pixelBufferCG = highResImage.toCVPixelBufferCoreGraphics(targetSize: targetSize),
              let pixelBufferVImage = highResImage.toCVPixelBufferVImage(targetSize: targetSize),
              let model = self.model else {
            print("Failed to prepare pixel buffers or load model for integration test.")
            return
        }

        let vnCoreMLModel = try! VNCoreMLModel(for: model.model)
        let request = VNCoreMLRequest(model: vnCoreMLModel)
        request.imageCropAndScaleOption = .centerCrop

        // CoreGraphics + Inference
        let startTimeCGInference = ContinuousClock().now
        _ = try? VNImageRequestHandler(cvPixelBuffer: pixelBufferCG, options: [:]).perform([request])
        let endTimeCGInference = ContinuousClock().now
        print("CoreGraphics Preprocessing + Inference: \((endTimeCGInference - startTimeCGInference).formatted(.units(fractionalPart: .show(length: 6))))")

        // vImage + Inference
        let startTimeVImageInference = ContinuousClock().now
        _ = try? VNImageRequestHandler(cvPixelBuffer: pixelBufferVImage, options: [:]).perform([request])
        let endTimeVImageInference = ContinuousClock().now
        print("vImage Preprocessing + Inference: \((endTimeVImageInference - startTimeVImageInference).formatted(.units(fractionalPart: .show(length: 6))))")

        print("\nObservation: The total latency should improve significantly with vImage for preprocessing.")
    }
}

// To run this code, you would typically call:
/*
@available(iOS 18.0, *)
Task {
    let optimizer = ImagePreprocessingOptimizer()
    await optimizer.runOptimizationExperiment()
}
*/
