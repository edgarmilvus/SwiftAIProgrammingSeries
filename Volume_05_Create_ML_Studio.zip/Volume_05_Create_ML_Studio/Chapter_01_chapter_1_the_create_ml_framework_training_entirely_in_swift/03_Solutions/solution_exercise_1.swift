
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CreateML

// MARK: - 1. Data Simulation
struct Ticket: Codable {
    let ticketID: Int
    let description: String
    let priority: String // Low, Medium, High
    let category: String // Technical Support, Billing, Feature Request, General Inquiry
}

func simulateTicketData(count: Int) -> [Ticket] {
    let descriptions = ["Cannot log in", "Billing error", "New feature request", "Password reset failed", "App crashed", "Question about subscription", "Suggest new UI design", "Payment not going through", "Account locked", "General inquiry about services"]
    let priorities = ["Low", "Medium", "High"]
    let categories = ["Technical Support", "Billing", "Feature Request", "General Inquiry"]

    var tickets: [Ticket] = []
    for i in 0..<count {
        let ticketID = i + 1
        let description = descriptions.randomElement()!
        let priority = priorities.randomElement()!
        
        var category: String
        switch description {
        case "Cannot log in", "Password reset failed", "App crashed", "Account locked":
            category = "Technical Support"
        case "Billing error", "Question about subscription", "Payment not going through":
            category = "Billing"
        case "New feature request", "Suggest new UI design":
            category = "Feature Request"
        default:
            category = categories.randomElement()! // Random for general inquiries
        }
        
        tickets.append(Ticket(ticketID: ticketID, description: description, priority: priority, category: category))
    }
    return tickets
}

// MARK: - Main Training Logic
func runExercise1() async {
    print("--- Exercise 1: Categorizing Customer Support Tickets ---")
    
    do {
        // 1. Data Simulation
        let simulatedTickets = simulateTicketData(count: 1000)
        
        // 2. MLDataTable Creation
        // Convert struct array to MLDataTable rows
        var dataTable = MLDataTable()
        var rows: [[String: MLDataValue]] = []
        for ticket in simulatedTickets {
            // Combine description and priority into a single feature for MLTextClassifier
            let combinedText = "\(ticket.description) [Priority: \(ticket.priority)]"
            rows.append([
                "ticketID": .int(ticket.ticketID),
                "combined_description": .string(combinedText), // New combined feature
                "category": .string(ticket.category)
            ])
        }
        dataTable = try MLDataTable(rows: rows, columns: ["ticketID", "combined_description", "category"])
        
        print("Created MLDataTable with \(dataTable.rows.count) rows.")
        print("Columns: \(dataTable.columnNames)")
        
        // 3. Model Training
        let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 0)
        
        print("Training data rows: \(trainingData.rows.count)")
        print("Testing data rows: \(testingData.rows.count)")
        
        // Train an MLTextClassifier
        // The 'combined_description' column will be used as the text feature, and 'category' as the label.
        let textClassifier = try await MLTextClassifier(trainingData: trainingData,
                                                        textColumn: "combined_description",
                                                        labelColumn: "category")
        
        print("MLTextClassifier trained successfully.")
        
        // 4. Model Evaluation
        let evaluation = textClassifier.evaluation(on: testingData)
        let accuracy = (1.0 - evaluation.classificationError) * 100
        print("Model evaluation accuracy on test data: \(String(format: "%.2f", accuracy))%")
        
        // 5. Model Saving
        let tempDirectory = FileManager.default.temporaryDirectory
        let modelURL = tempDirectory.appendingPathComponent("CustomerTicketClassifier.mlmodel")
        
        try textClassifier.write(to: modelURL)
        print("Model saved to: \(modelURL.path)")
        
        // Optional: Clean up (remove the saved model)
        // try FileManager.default.removeItem(at: modelURL)
        // print("Cleaned up: removed \(modelURL.lastPathComponent)")
        
    } catch {
        print("Error during Exercise 1: \(error.localizedDescription)")
    }
}

// Run the exercise
// Task { await runExercise1() } // Uncomment to run directly if not part of a larger app
