
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import ARKit
import Vision
import RealityKit
import Observation

/// A Sendable structure representing a single point in 3D space.
/// Using Sendable ensures this can safely cross actor boundaries.
struct SpatialKeypoint: Sendable, Equatable {
    let position: simd_float3
    let confidence: Float
}

/// The representation of a full pose.
struct BodyPose: Sendable {
    let joints: [String: SpatialKeypoint]
    let timestamp: TimeInterval
}

/// The PoseEstimationActor isolates the heavy Core ML and Vision processing.
/// By using an actor, we guarantee that the high-frequency inference 
/// does not contend with the MainActor (UI/Rendering).
@available(iOS 18.0, *)
actor PoseEstimationActor {
    private var isProcessing = false
    
    // In a real implementation, this would hold your VNCoreMLRequest
    // and the loaded Core ML model.
    
    /// Processes a single frame to extract pose data.
    /// - Parameter frame: The current ARFrame from ARKit.
    /// - Returns: A BodyPose containing the 3D joint locations.
    func estimatePose(from frame: ARFrame) async throws -> BodyPose {
        // Prevent overlapping inference calls (Backpressure management)
        guard !isProcessing else {
            throw PoseError.inferenceInProgress
        }
        
        isProcessing = true
        defer { isProcessing = false }
        
        // 1. Perform Vision/CoreML Inference (Simulated)
        // Under the hood, this utilizes the Apple Neural Engine (ANE).
        let detectedPose = try await performInference(on: frame)
        
        return detectedPose
    }
    
    private func performInference(on frame: ARFrame) async throws -> BodyPose {
        // Simulate heavy computation on the Neural Engine
        try await Task.sleep(for: .milliseconds(16)) 
        
        // In practice, you would use:
        // let request = VNCoreMLRequest(model: model)
        // let handler = VNImageRequestHandler(cvPixelBuffer: frame.capturedImage)
        // handler.perform([request])
        
        return BodyPose(
            joints: ["right_hand": SpatialKeypoint(position: [0.1, 0.2, -0.5], confidence: 0.98)],
            timestamp: frame.timestamp
        )
    }
}

enum PoseError: Error {
    case inferenceInProgress
}

/// The ViewModel acts as the bridge between the background Actor and the MainActor UI.
/// We use @Observable (introduced in Swift 5.9/iOS 17) to allow RealityKit 
/// or SwiftUI to react to pose changes.
@available(iOS 18.0, *)
@Observable
final class PoseTrackingViewModel {
    // This property is observed by the UI/Scene.
    // Changes to this will trigger updates on the MainActor.
    var currentPose: BodyPose?
    
    private let poseActor = PoseEstimationActor()
    
    /// The entry point for the ARKit session delegate.
    /// This must be called from the main thread (e.g., from ARSessionDelegate).
    @MainActor
    func update(with frame: ARFrame) {
        // We spawn a detached task to move the work off the MainActor immediately.
        Task {
            do {
                // The heavy lifting happens inside the actor.
                let newPose = try await poseActor.estimatePose(from: frame)
                
                // Once the actor returns, we are back on the MainActor context 
                // because the Task was created within a @MainActor method.
                self.currentPose = newPose
            } catch {
                // Handle errors (e.g., frame dropped)
                print("Pose estimation failed: \(error)")
            }
        }
    }
}
