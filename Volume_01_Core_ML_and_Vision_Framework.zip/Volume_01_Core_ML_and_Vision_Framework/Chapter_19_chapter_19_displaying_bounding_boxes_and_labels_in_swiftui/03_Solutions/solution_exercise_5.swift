
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import AVFoundation // For camera integration
import CoreGraphics // For CGRect
import Foundation   // For UUID
import Vision       // For VNRecognizedObjectObservation (mocking)

// MARK: - Reusing Mock Data Structures & Helper from Exercise 1

// DetectionResult is reused. BoundingBoxOverlay is reused.
// CGRect.visionToSwiftUIRect is NOT used directly here;
// AVCaptureVideoPreviewLayer.metadataOutputRectConverted handles the conversion.

// MARK: - Camera View (UIViewRepresentable)

/// A UIViewRepresentable to embed AVCaptureVideoPreviewLayer in SwiftUI.
struct CameraView: UIViewRepresentable {
    @ObservedObject var viewModel: CameraViewModel

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black // Default background
        viewModel.setupCaptureSession(in: view)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        // Update view properties if needed, e.g., orientation
        viewModel.updateVideoOrientation()
    }

    static func dismantleUIView(_ uiView: UIView, coordinator: ()) {
        // Stop the session when the view is removed
        (uiView.layer.sublayers?.first as? AVCaptureVideoPreviewLayer)?.session?.stopRunning()
    }
}

// MARK: - Camera View Model (ObservableObject)

/// Manages the AVCaptureSession, processes frames, and provides detection results.
class CameraViewModel: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    @Published var detections: [DetectionResult] = []
    
    // Store the raw detection results from the latest frame
    private var latestDetectionResults: [DetectionResult] = []
    
    private var captureSession: AVCaptureSession?
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    private let videoDataOutputQueue = DispatchQueue(label: "videoDataOutputQueue", qos: .userInitiated)
    
    // Throttling mechanism
    private var lastUpdateTime = Date()
    private let updateInterval: TimeInterval = 1.0 / 30.0 // Target 30 FPS for UI updates

    /// Sets up the AVCaptureSession and adds the preview layer to the provided UIView.
    func setupCaptureSession(in uiView: UIView) {
        captureSession = AVCaptureSession()
        guard let captureSession = captureSession else { return }

        // Configure camera input
        guard let videoCaptureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("No video device found")
            return
        }
        guard let videoInput = try? AVCaptureDeviceInput(device: videoCaptureDevice) else {
            print("Could not create video input")
            return
        }
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            print("Could not add video input to session")
            return
        }

        // Configure video data output (for processing frames)
        let videoDataOutput = AVCaptureVideoDataOutput()
        videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
        videoDataOutput.alwaysDiscardsLateVideoFrames = true // Crucial for performance
        if captureSession.canAddOutput(videoDataOutput) {
            captureSession.addOutput(videoDataOutput)
            // Ensure video orientation matches device orientation for correct bounding box conversion
            if let connection = videoDataOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait // Or determine dynamically
            }
        } else {
            print("Could not add video data output to session")
            return
        }

        // Configure preview layer
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer?.videoGravity = .resizeAspectFill
        videoPreviewLayer?.frame = uiView.bounds // Fill the entire UIView
        uiView.layer.addSublayer(videoPreviewLayer!)

        // Start the session on a background thread
        DispatchQueue.global(qos: .userInitiated).async {
            captureSession.startRunning()
        }
    }
    
    /// Updates the video preview layer's orientation.
    func updateVideoOrientation() {
        if let connection = videoPreviewLayer?.connection, connection.isVideoOrientationSupported {
            // This is simplified. In a real app, you'd observe device orientation changes.
            connection.videoOrientation = .portrait
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Simulate object detection: Generate random bounding boxes and labels
        // In a real app, you would pass `sampleBuffer` to a Vision request.
        let newDetections = generateMockDetections(for: sampleBuffer)
        
        // Convert Vision-style bounding boxes to preview layer coordinates
        let convertedDetections = newDetections.map { detection -> DetectionResult in
            guard let previewLayer = self.videoPreviewLayer else { return detection }
            
            // This is the CRITICAL step for coordinate conversion
            // metadataOutputRectConverted takes a normalized rect (Vision style)
            // and converts it to a rect in the preview layer's coordinate system.
            let swiftUIRect = previewLayer.metadataOutputRectConverted(fromOutputRect: detection.boundingBox)
            
            // Return a new DetectionResult where boundingBox is now SwiftUI-ready
            return DetectionResult(boundingBox: swiftUIRect, label: detection.label, confidence: detection.confidence)
        }
        
        // Store latest results and throttle UI updates
        latestDetectionResults = convertedDetections
        
        if Date().timeIntervalSince(lastUpdateTime) >= updateInterval {
            DispatchQueue.main.async {
                self.detections = self.latestDetectionResults
                self.lastUpdateTime = Date()
            }
        }
    }
    
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // print("Dropped frame") // Can be uncommented for debugging performance
    }

    // MARK: - Mock Detection Generation

    private func generateMockDetections(for sampleBuffer: CMSampleBuffer) -> [DetectionResult] {
        // In a real app, Vision would process the sampleBuffer here.
        // For simulation, generate random detections.
        var mockDetections: [DetectionResult] = []
        let numberOfDetections = Int.random(in: 1...3)
        let labels = ["Person", "Object", "Face", "Hand"]

        for _ in 0..<numberOfDetections {
            let x = CGFloat.random(in: 0.1...0.7)
            let y = CGFloat.random(in: 0.1...0.7)
            let width = CGFloat.random(in: 0.1...0.3)
            let height = CGFloat.random(in: 0.1...0.3)
            let confidence = Double.random(in: 0.5...0.99)
            let label = labels.randomElement() ?? "Unknown"

            let boundingBox = CGRect(x: x, y: y, width: width, height: height)
            mockDetections.append(DetectionResult(boundingBox: boundingBox, label: label, confidence: confidence))
        }
        return mockDetections
    }
}

// MARK: - Exercise 5 Solution View

struct Exercise5View: View {
    @StateObject private var cameraViewModel = CameraViewModel()

    var body: some View {
        VStack {
            Text("Exercise 5: Real-time Camera Feed Overlay with Throttling")
                .font(.headline)
                .padding()

            GeometryReader { geometry in
                CameraView(viewModel: cameraViewModel)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .overlay(
                        ZStack {
                            ForEach(cameraViewModel.detections) { detection in
                                // The boundingBox in detection is ALREADY converted to SwiftUI/UIKit coordinates
                                // by the CameraViewModel's metadataOutputRectConverted.
                                BoundingBoxOverlay(
                                    id: detection.id,
                                    swiftUIRect: detection.boundingBox, // Use the pre-converted rect
                                    label: detection.label,
                                    confidence: detection.confidence,
                                    containerSize: geometry.size, // The size of the CameraView container
                                    strokeColor: .yellow, // Distinct color for live feed
                                    displayConfidence: true,
                                    labelPlacementPreference: .auto
                                )
                            }
                        }
                    )
            }
        }
        .onAppear {
            // Request camera permissions when the view appears
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if !granted {
                    print("Camera access denied.")
                    // Handle denial, e.g., show an alert
                }
            }
        }
    }
}

// Preview Provider (Note: Camera previews won't work in Xcode Previews)
struct Exercise5View_Previews: PreviewProvider {
    static var previews: some View {
        Exercise5View()
    }
}
