
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Placeholder Data Source and Evaluation (from Exercise 1)
// In a real app, you would load data from directories.
@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
private func evaluateModel(_ model: MLImageClassifier, on dataSource: MLImageClassifier.DataSource) async throws -> (accuracy: Double, loss: Double) {
    print("  (Simulating model evaluation for validation accuracy and loss for Tool Classifier...)")
    let accuracy = Double.random(in: 0.80...0.98) // Higher for targeted
    let loss = Double.random(in: 0.05...0.3)
    return (accuracy, loss)
}

// MARK: - Augmentation Configuration and Training Functions

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func configureToolAugmentations() -> MLImageClassifier.DataSource.AugmentationOptions {
    var options = MLImageClassifier.DataSource.AugmentationOptions()
    
    // Configure rotation, scale, translation, and/or perspectiveWarp here
    options.rotation = .degrees(range: -30.0...30.0) // Tools can be highly rotated
    options.scale = .fraction(min: 0.7, max: 1.3)     // Tools can appear closer or further
    options.translation = .fraction(range: -0.15...0.15) // Tools can be off-center
    options.perspectiveWarp = .fraction(range: 0.0...0.07) // Slight camera angle distortions
    
    // Explicitly omit colorJitter, blur, etc., for this exercise
    options.colorJitter = nil
    options.blur = nil
    options.flip = nil // Tools often have a distinct "up" or "right" side (e.g., hammer head vs handle)
                       // so horizontal flip might be less desirable unless the tool is symmetrical.
                       // For this exercise, we'll omit it to focus purely on spatial distortions.
    options.randomCrop = nil // Focus on full object visibility for tools
    
    return options
}

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func trainToolClassifier(
    trainingData: MLImageClassifier.DataSource,
    validationData: MLImageClassifier.DataSource,
    augmentations: MLImageClassifier.DataSource.AugmentationOptions?,
    epochs: Int = 25, // Slightly more epochs for potentially more complex variations
    label: String
) async throws -> MLImageClassifier {
    print("--- Training \(label) Model ---")
    let parameters = MLImageClassifier.ModelParameters(
        validationData: validationData,
        augmentationOptions: augmentations,
        epochs: epochs,
        shuffle: true,
        learningRate: 0.001,
        progressHandler: { context in
            if let metrics = context.metrics {
                print("  Epoch \(metrics.epoch): Train Loss = \(String(format: "%.4f", metrics.trainingLoss)), Validation Loss = \(String(format: "%.4f", metrics.validationLoss))")
                print("  Epoch \(metrics.epoch): Train Acc = \(String(format: "%.2f", metrics.trainingAccuracy * 100))%, Validation Acc = \(String(format: "%.2f", metrics.validationAccuracy * 100))%")
            }
        }
    )
    let model = try await MLImageClassifier.train(
        trainingData: trainingData,
        parameters: parameters
    )
    print("--- \(label) Model Training Complete ---")
    return model
}

// MARK: - Main Execution Logic (Example)

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func runToolClassifierExperiment() async throws {
    // --- IMPORTANT: Replace with your actual data sources ---
    let dummyTrainingData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_tool_training"))
    let dummyValidationData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_tool_validation"))
    
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_tool_training/classA"), withIntermediateDirectories: true, attributes: nil)
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_tool_validation/classA"), withIntermediateDirectories: true, attributes: nil)

    // Train with targeted augmentations
    let toolAugmentations = configureToolAugmentations()
    let toolModel = try await trainToolClassifier(
        trainingData: dummyTrainingData,
        validationData: dummyValidationData,
        augmentations: toolAugmentations,
        label: "Tool Classifier (Targeted Augmentation)"
    )
    let toolMetrics = try await evaluateModel(toolModel, on: dummyValidationData)

    print("\n--- Tool Classifier Model Results (Targeted Augmentation) ---")
    print("Validation Accuracy: \(String(format: "%.2f", toolMetrics.accuracy * 100))%")
    print("Validation Loss: \(String(format: "%.4f", toolMetrics.loss))")

    print("\n--- Justification for Targeted Augmentations ---")
    print("The chosen augmentations (rotation, scale, translation, perspectiveWarp) directly address the challenges of identifying tools in varied photographic conditions:")
    print("- **Rotation (-30° to +30°):** Tools are frequently held or placed at arbitrary angles, making rotational invariance crucial. A wider range than for plants is often appropriate here.")
    print("- **Scale (0.7x to 1.3x):** Users might photograph tools from different distances, causing them to appear larger or smaller in the frame. Scale augmentation helps the model generalize across these size variations.")
    print("- **Translation (-15% to +15%):** Tools are rarely perfectly centered in a user's photo. Translation augmentation teaches the model to recognize tools regardless of their exact position within the image.")
    print("- **Perspective Warp (0% to 7%):** This simulates slight camera angle distortions, common when a photo isn't taken perfectly head-on, adding robustness to real-world perspective variations.")
    print("\nAugmentations like `colorJitter` and `blur` were explicitly omitted because the scenario states that 'Color and lighting, however, tend to be relatively consistent.' Applying unnecessary augmentations can sometimes hinder training or increase training time without significant benefit, especially if the real-world variations they simulate are not present.")
    print("`flip` was also omitted as many tools have a distinct orientation that might be lost with arbitrary flips (e.g., a hammer's head vs. handle). `randomCrop` was omitted to ensure the full tool is generally visible, which is often important for identification.")
    
    // Clean up dummy directories
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_tool_training"))
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_tool_validation"))
}

// To run this code:
// Task {
//     try await runToolClassifierExperiment()
// }
