
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Swift 6
// Requires iOS 18.0 or macOS 15.0 for MLImageClassifier.ModelParameters.ImageAugmentationOptions
// and MLImageClassifier.TrainingSession.
@available(iOS 18.0, macOS 15.0, *)
import Foundation
import CoreML
import CreateML
import UIKit // Required for UIImage, UIGraphicsImageRenderer in dummy image generation

// MARK: - 1. Real-world Apple App Context & Problem Definition
///
/// **Context:** This component simulates the core logic for a "Smart Photo Album Categorizer" app.
///
/// **Problem:** Users often have vast photo libraries and struggle to organize them. This app aims to
/// learn from user-tagged photos (e.g., "Pets", "Nature", "Food") and automatically suggest categories
/// for new, untagged photos. Crucially, the model needs to improve over time as the user provides
/// more feedback (tags more photos). This involves:
/// 1. Initial training of an `MLImageClassifier`.
/// 2. **Incremental retraining** of the model on-device when new user-tagged photos become available.
///    This is where image augmentation becomes vital to prevent overfitting on potentially small
///    new datasets and to enhance the model's generalization capabilities.
/// 3. Efficient management and deployment of updated models within the app.
///
/// **Advanced Application Aspects Demonstrated:**
/// - On-device training and retraining of `MLImageClassifier`.
/// - Dynamic data source creation from user-provided content.
/// - Strategic use of `MLImageClassifier.ModelParameters.ImageAugmentationOptions` for robustness,
///   especially during incremental updates.
/// - Asynchronous operations with Swift 6 concurrency (`async/await`).
/// - Robust error handling and file system management.
/// - Model persistence and loading for continuous improvement.

// MARK: - 2. Data Structures and Utility Functions

/// Represents a single user-tagged photo entry.
struct UserPhotoEntry: Identifiable, Hashable {
    let id = UUID()
    let imageURL: URL // Local URL to the image file
    let category: String // User-defined category (label)

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }

    static func == (lhs: UserPhotoEntry, rhs: UserPhotoEntry) -> Bool {
        lhs.id == rhs.id
    }
}

/// Manages file paths for storing and retrieving Core ML models.
enum ModelPathManager {
    /// The directory where application-specific documents are stored.
    static var appDocumentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    /// Generates a file URL for a Core ML model with a given version.
    /// - Parameter version: A string identifier for the model version (e.g., "v1", "v1_retrained").
    /// - Returns: A URL pointing to where the model should be saved or loaded.
    static func modelURL(forVersion version: String) -> URL {
        appDocumentsDirectory.appendingPathComponent("PhotoCategorizerModel_\(version)").appendingPathExtension("mlmodel")
    }

    /// Cleans up any existing models in the document directory.
    static func cleanupModels() {
        do {
            let files = try FileManager.default.contentsOfDirectory(at: appDocumentsDirectory, includingPropertiesForKeys: nil)
            for file in files where file.lastPathComponent.hasPrefix("PhotoCategorizerModel_") && file.pathExtension == "mlmodel" {
                try FileManager.default.removeItem(at: file)
                print("Cleaned up old model: \(file.lastPathComponent)")
            }
        } catch {
            print("Error cleaning up models: \(error.localizedDescription)")
        }
    }
}

// MARK: - 3. SmartPhotoCategorizer Class: Core Logic

/// `SmartPhotoCategorizer` orchestrates the training, retraining, and inference
/// of an `MLImageClassifier` for photo categorization.
/// It demonstrates on-device learning with data augmentation and incremental updates.
@available(iOS 18.0, macOS 15.0, *)
class SmartPhotoCategorizer {
    private var currentModel: MLModel?
    private var currentModelVersion: String = "initial"
    private var allTrainingData: [UserPhotoEntry] = [] // Stores all data used for training so far

    /// Initializes the categorizer. Attempts to load the latest model if available.
    init() {
        Task {
            await loadLatestModel()
        }
    }

    /// Loads the latest trained model from disk.
    /// This method is asynchronous as file I/O can be blocking.
    private func loadLatestModel() async {
        let modelURL = ModelPathManager.modelURL(forVersion: currentModelVersion)
        guard FileManager.default.fileExists(atPath: modelURL.path) else {
            print("No existing model found at \(modelURL.lastPathComponent). Will train a new one.")
            return
        }

        do {
            print("Loading existing model from \(modelURL.lastPathComponent)...")
            currentModel = try await MLModel.load(contentsOf: modelURL)
            print("Model loaded successfully.")
        } catch {
            print("Failed to load model from \(modelURL.lastPathComponent): \(error.localizedDescription)")
            currentModel = nil
        }
    }

    /// Prepares an `MLImageClassifier.DataSource` from an array of `UserPhotoEntry`.
    /// This function simulates reading images from disk and associating them with labels.
    /// - Parameter entries: An array of `UserPhotoEntry` containing image URLs and categories.
    /// - Returns: An `MLImageClassifier.DataSource` ready for training.
    /// - Throws: `SmartPhotoCategorizerError` if image data cannot be loaded or processed.
    private func prepareDataSource(from entries: [UserPhotoEntry]) async throws -> MLImageClassifier.DataSource {
        guard !entries.isEmpty else {
            throw SmartPhotoCategorizerError.noTrainingData
        }

        // Create a temporary directory for Create ML to work with, mimicking a folder structure.
        let tempDirectory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: tempDirectory, withIntermediateDirectories: true, attributes: nil)

        // Organize images into subdirectories by category for Create ML's folder-based data source.
        // In a real app, you might already have these organized or use a custom data source.
        for entry in entries {
            let categoryDirectory = tempDirectory.appendingPathComponent(entry.category)
            try FileManager.default.createDirectory(at: categoryDirectory, withIntermediateDirectories: true, attributes: nil)
            let destinationURL = categoryDirectory.appendingPathComponent(entry.imageURL.lastPathComponent)

            // Simulate copying the image. In a real app, you might just point to existing files.
            // For this example, we assume `entry.imageURL` points to actual image files.
            // We'll create dummy files for demonstration purposes if they don't exist.
            if !FileManager.default.fileExists(atPath: entry.imageURL.path) {
                // Create a dummy image file for demonstration
                // (Using UIImage for UIKit environments, will create empty file otherwise)
                let dummyImageData = UIImage(systemName: "photo")?.pngData() ?? Data()
                try dummyImageData.write(to: entry.imageURL)
            }
            try FileManager.default.copyItem(at: entry.imageURL, to: destinationURL)
        }

        // Create the data source from the temporary directory.
        let dataSource = try MLImageClassifier.DataSource.labeledImages(at: tempDirectory)

        // Clean up the temporary directory after data source creation (optional, but good practice).
        // The data source holds references, not the actual files.
        // try FileManager.default.removeItem(at: tempDirectory) // Uncomment if temporary files are not needed after datasource creation.
        print("Data source prepared with \(entries.count) entries from temporary directory: \(tempDirectory.lastPathComponent)")
        return dataSource
    }

    /// Trains an initial `MLImageClassifier` model.
    /// This is typically done once when the app is first used or after a significant data reset.
    /// - Parameter initialPhotos: The initial set of user-tagged photos.
    /// - Returns: The trained `MLModel`.
    /// - Throws: `SmartPhotoCategorizerError` or `Error` from `CreateML`.
    func trainInitialModel(with initialPhotos: [UserPhotoEntry]) async throws -> MLModel {
        print("\n--- Starting Initial Model Training ---")
        ModelPathManager.cleanupModels() // Ensure a clean slate for initial training

        guard !initialPhotos.isEmpty else {
            throw SmartPhotoCategorizerError.noTrainingData
        }

        allTrainingData = initialPhotos // Store the initial data

        let dataSource = try await prepareDataSource(from: allTrainingData)

        // Define model parameters, including crucial image augmentation options.
        // Augmentation helps the model generalize better from limited data,
        // preventing overfitting and improving robustness to variations in new images.
        let modelParameters = MLImageClassifier.ModelParameters(
            featureExtractor: .init(kind: .scenePrint), // Use a pre-trained feature extractor
            augmentation: .init(
                // Common augmentations:
                .randomCrop(minScale: 0.8, maxScale: 1.0), // Randomly crop part of the image
                .randomFlip(horizontal: true, vertical: false), // Randomly flip horizontally
                .randomRotation(maxDegrees: 20), // Randomly rotate up to 20 degrees
                .randomColorAdjustments(brightness: 0.2, contrast: 0.2, saturation: 0.2, hue: 0.1) // Randomly adjust colors
            ),
            validationData: nil, // For simplicity, skipping explicit validation set; Create ML uses a default split.
            epochs: 10, // Number of training iterations
            batchSize: 32 // Number of samples per gradient update
        )

        print("Training with \(allTrainingData.count) images and augmentation enabled.")
        let trainingSession = try MLImageClassifier.TrainingSession(
            data: dataSource,
            parameters: modelParameters
        )

        // Monitor training progress (optional, but good for UI updates)
        for await event in trainingSession.events {
            switch event {
            case .trainingProgress(let progress):
                print("Training Progress: \(Int(progress.fractionCompleted * 100))% completed, Loss: \(progress.metrics.loss ?? -1.0)")
            case .finished(let model):
                print("Initial model training finished successfully!")
                self.currentModel = model
                self.currentModelVersion = "v1"
                let modelURL = ModelPathManager.modelURL(forVersion: self.currentModelVersion)
                try model.write(to: modelURL)
                print("Initial model saved to: \(modelURL.lastPathComponent)")
                return model
            case .failed(let error):
                throw SmartPhotoCategorizerError.trainingFailed(error.localizedDescription)
            default:
                break
            }
        }
        throw SmartPhotoCategorizerError.trainingFailed("Unknown error during initial training session.")
    }

    /// Retrains the existing `MLImageClassifier` model with new user-provided data.
    /// This is the "advanced" part, demonstrating incremental on-device learning.
    /// Augmentation is especially critical here to prevent overfitting on potentially small new datasets.
    /// - Parameter newPhotos: The new set of user-tagged photos to incorporate into training.
    /// - Returns: The updated `MLModel`.
    /// - Throws: `SmartPhotoCategorizerError` or `Error` from `CreateML`.
    func retrainModelIncrementally(with newPhotos: [UserPhotoEntry]) async throws -> MLModel {
        print("\n--- Starting Incremental Model Retraining ---")

        guard !newPhotos.isEmpty else {
            print("No new photos provided for retraining. Skipping.")
            return currentModel! // Return existing model if no new data
        }

        // Combine all historical data with the new data.
        // It's generally better to retrain on the complete dataset rather than just the new increment
        // to prevent "catastrophic forgetting" of previously learned categories.
        let uniqueNewPhotos = newPhotos.filter { newPhoto in
            !allTrainingData.contains(where: { $0.imageURL == newPhoto.imageURL && $0.category == newPhoto.category })
        }
        guard !uniqueNewPhotos.isEmpty else {
            print("No *unique* new photos for retraining. Skipping.")
            return currentModel!
        }

        allTrainingData.append(contentsOf: uniqueNewPhotos)
        print("Combined new photos. Total training data: \(allTrainingData.count) images.")

        guard let existingModel = currentModel else {
            throw SmartPhotoCategorizerError.noExistingModelForRetraining
        }

        let dataSource = try await prepareDataSource(from: allTrainingData)

        // For incremental retraining, we might use slightly different augmentation parameters
        // or keep them consistent. The key is that augmentation is active.
        // We can increase epochs if the new data is very small, but too many can still overfit.
        let modelParameters = MLImageClassifier.ModelParameters(
            featureExtractor: .init(kind: .scenePrint),
            augmentation: .init(
                .randomCrop(minScale: 0.7, maxScale: 1.0), // Slightly more aggressive cropping
                .randomFlip(horizontal: true, vertical: true), // Allow vertical flips too
                .randomRotation(maxDegrees: 30), // More rotation
                .randomColorAdjustments(brightness: 0.3, contrast: 0.3, saturation: 0.3, hue: 0.15), // More color variation
                .randomZoom(minScale: 0.9, maxScale: 1.1) // Introduce zooming
            ),
            validationData: nil,
            epochs: 15, // Potentially more epochs for fine-tuning
            batchSize: 16 // Smaller batch size can sometimes help with smaller datasets
        )

        print("Retraining existing model with \(allTrainingData.count) images and enhanced augmentation.")
        let trainingSession = try MLImageClassifier.TrainingSession(
            data: dataSource,
            parameters: modelParameters,
            model: existingModel // Crucially, pass the existing model for retraining
        )

        // Monitor training progress
        for await event in trainingSession.events {
            switch event {
            case .trainingProgress(let progress):
                print("Retraining Progress: \(Int(progress.fractionCompleted * 100))% completed, Loss: \(progress.metrics.loss ?? -1.0)")
            case .finished(let model):
                print("Incremental model retraining finished successfully!")
                self.currentModel = model
                // Increment model version or use a timestamp
                let newVersion = "v\(Int(self.currentModelVersion.dropFirst())! + 1)"
                self.currentModelVersion = newVersion
                let modelURL = ModelPathManager.modelURL(forVersion: self.currentModelVersion)
                try model.write(to: modelURL)
                print("Updated model saved to: \(modelURL.lastPathComponent)")
                return model
            case .failed(let error):
                throw SmartPhotoCategorizerError.trainingFailed(error.localizedDescription)
            default:
                break
            }
        }
        throw SmartPhotoCategorizerError.trainingFailed("Unknown error during incremental training session.")
    }

    /// Classifies a single image using the currently loaded model.
    /// - Parameter imageURL: The URL of the image to classify.
    /// - Returns: An array of `MLImageClassifier.Prediction` representing the classification results.
    /// - Throws: `SmartPhotoCategorizerError` if no model is available or prediction fails.
    func classifyImage(at imageURL: URL) async throws -> [MLImageClassifier.Prediction] {
        guard let model = currentModel else {
            throw SmartPhotoCategorizerError.noModelAvailableForPrediction
        }

        print("\n--- Classifying Image: \(imageURL.lastPathComponent) ---")

        // MLImageClassifier expects an MLFeatureProvider or an image URL.
        // We'll use the URL directly for simplicity.
        let classifier = try MLImageClassifier(mlModel: model)
        let prediction = try await classifier.prediction(from: imageURL)
        print("Classification result for \(imageURL.lastPathComponent):")
        for (label, confidence) in prediction.labelProbabilities.sorted(by: { $0.1 > $1.1 }) {
            print("  - \(label): \(String(format: "%.2f", confidence * 100))%")
        }
        return [prediction] // MLImageClassifier.prediction(from:) returns a single prediction
    }
}

// MARK: - 4. Error Handling
/// Custom errors for the `SmartPhotoCategorizer`.
enum SmartPhotoCategorizerError: Error, LocalizedError {
    case noTrainingData
    case trainingFailed(String)
    case noExistingModelForRetraining
    case noModelAvailableForPrediction
    case invalidImageData(URL)
    case customError(String)

    var errorDescription: String? {
        switch self {
        case .noTrainingData:
            return "No training data provided. Cannot train or retrain the model."
        case .trainingFailed(let message):
            return "Model training failed: \(message)"
        case .noExistingModelForRetraining:
            return "No existing model found to retrain. An initial model must be trained first."
        case .noModelAvailableForPrediction:
            return "No model is currently loaded for prediction. Train or load a model first."
        case .invalidImageData(let url):
            return "Could not load or process image data from URL: \(url.lastPathComponent)"
        case .customError(let message):
            return message
        }
    }
}

// MARK: - 5. Main Execution Block (Demonstration)

/// This section simulates the lifecycle of the Smart Photo Album Categorizer app.
@available(iOS 18.0, macOS 15.0, *)
func runSmartPhotoCategorizerDemo() async {
    let categorizer = SmartPhotoCategorizer()

    // --- Simulate initial user data ---
    // Create dummy image files for demonstration purposes.
    // In a real app, these would be actual photos from the user's library.
    func createDummyImage(named name: String, text: String, color: UIColor) -> URL? {
        let url = ModelPathManager.appDocumentsDirectory.appendingPathComponent(name)
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 200))
        let image = renderer.image { ctx in
            color.setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: 200, height: 200))
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 40),
                .foregroundColor: UIColor.white,
                .paragraphStyle: paragraphStyle
            ]
            let attributedString = NSAttributedString(string: text, attributes: attributes)
            let rect = CGRect(x: 0, y: 80, width: 200, height: 40)
            attributedString.draw(in: rect)
        }
        do {
            try image.pngData()?.write(to: url)
            return url
        } catch {
            print("Error creating dummy image \(name): \(error)")
            return nil
        }
    }

    let initialPhotos: [UserPhotoEntry] = [
        .init(imageURL: createDummyImage(named: "cat_photo_1.png", text: "Cat", color: .systemBlue)!, category: "Pets"),
        .init(imageURL: createDummyImage(named: "cat_photo_2.png", text: "Cat", color: .systemBlue)!, category: "Pets"),
        .init(imageURL: createDummyImage(named: "dog_photo_1.png", text: "Dog", color: .systemOrange)!, category: "Pets"),
        .init(imageURL: createDummyImage(named: "food_photo_1.png", text: "Food", color: .systemGreen)!, category: "Food"),
        .init(imageURL: createDummyImage(named: "nature_photo_1.png", text: "Nature", color: .systemPurple)!, category: "Nature")
    ]

    do {
        // 1. Initial Training
        // The model is trained with an initial set of user-tagged photos.
        // Augmentation parameters are applied to make the model robust from the start.
        _ = try await categorizer.trainInitialModel(with: initialPhotos)

        // 2. Simulate new user data and incremental retraining
        print("\n--- Simulating new user feedback and incremental retraining ---")
        // User tags more photos, some existing categories, some potentially new.
        let newPhotos: [UserPhotoEntry] = [
            .init(imageURL: createDummyImage(named: "cat_photo_3.png", text: "Cat", color: .systemBlue)!, category: "Pets"),
            .init(imageURL: createDummyImage(named: "dog_photo_2.png", text: "Dog", color: .systemOrange)!, category: "Pets"),
            .init(imageURL: createDummyImage(named: "food_photo_2.png", text: "Food", color: .systemGreen)!, category: "Food"),
            .init(imageURL: createDummyImage(named: "new_bird_photo_1.png", text: "Bird", color: .systemRed)!, category: "Birds") // A new category!
        ]

        // The model is retrained, incorporating the new data.
        // Crucially, the retraining uses the *existing model* and applies *enhanced augmentation*
        // to prevent catastrophic forgetting and improve generalization on the new, potentially small, dataset.
        _ = try await categorizer.retrainModelIncrementally(with: newPhotos)

        // 3. Classify a new, unseen image
        print("\n--- Classifying a brand new image ---")
        let unseenPhotoURL = createDummyImage(named: "unseen_bird_photo.png", text: "Bird", color: .systemRed)!

        // The latest, incrementally trained model is used for prediction.
        _ = try await categorizer.classifyImage(at: unseenPhotoURL)

    } catch {
        print("An error occurred during the demo: \(error.localizedDescription)")
    }
}

// To run this demo in an Xcode project (e.g., in a Playground or an AppDelegate/SceneDelegate):
// Ensure your target is iOS 18.0+ or macOS 15.0+
// Then call:
// Task {
//     await runSmartPhotoCategorizerDemo()
// }
//
// For a simple command-line Swift Package, you might need to adjust the dummy image creation
// or ensure you have actual image files at the specified URLs. The `createDummyImage` function
// uses UIKit (UIImage, UIGraphicsImageRenderer), which is not available in a pure command-line
// environment. For a robust command-line demo, replace `createDummyImage` with actual image
// file paths or use a platform-agnostic image generation library.

// Example of how to call the demo (e.g., in an iOS app's AppDelegate or SwiftUI App struct):
/*
import SwiftUI
import UIKit // Required for UIImage, UIGraphicsImageRenderer in dummy image generation

@main
struct SmartPhotoApp: App {
    init() {
        // Ensure the demo runs when the app starts.
        // This is for demonstration purposes; in a real app, training would be user-triggered.
        Task {
            await runSmartPhotoCategorizerDemo()
        }
    }

    var body: some Scene {
        WindowGroup {
            ContentView() // Your main app UI
        }
    }
}

struct ContentView: View {
    var body: some View {
        Text("Smart Photo Categorizer Demo Running in Console...")
            .padding()
    }
}
*/
