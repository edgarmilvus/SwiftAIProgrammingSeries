
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation // For basic data structures and String operations
import Combine    // Although not strictly necessary for this basic example, useful for real-world async flows

// Ensure compatibility with the latest SDKs, especially for async/await in certain contexts.
// For basic Swift concurrency, these are generally available on recent OS versions.
@available(iOS 15.0, macOS 12.0, watchOS 8.0, tvOS 15.0, *)
enum DocQueryError: Error, LocalizedError {
    case documentNotFound(String)
    case retrievalError(String)
    case promptCompositionError(String)

    var errorDescription: String? {
        switch self {
        case .documentNotFound(let id):
            return "Document with ID '\(id)' could not be found."
        case .retrievalError(let msg):
            return "Retrieval failed: \(msg)"
        case .promptCompositionError(let msg):
            return "Prompt composition failed: \(msg)"
        }
    }
}

// MARK: - 1. Defining Our Local Document Store

/// Represents a simplified local document. In a real app, this would involve
/// file paths, metadata, and potentially more complex content parsing.
struct Document: Identifiable, Hashable, Sendable {
    let id: String         // Unique identifier for the document (e.g., filename)
    let title: String      // Human-readable title
    let content: String    // The actual text content of the document

    /// Initializes a new Document instance.
    /// - Parameters:
    ///   - id: A unique identifier for the document.
    ///   - title: The title of the document.
    ///   - content: The full text content of the document.
    init(id: String, title: String, content: String) {
        self.id = id
        self.title = title
        self.content = content
    }
}

/// A simple in-memory store for our documents.
/// In a real application, this would interact with the file system, a database,
/// or a dedicated document management service.
actor DocumentStore: Sendable {
    private var documents: [String: Document]

    /// Initializes the document store with an initial set of documents.
    /// - Parameter initialDocuments: A dictionary mapping document IDs to Document instances.
    init(initialDocuments: [String: Document]) {
        self.documents = initialDocuments
    }

    /// Adds a new document to the store.
    /// - Parameter document: The Document instance to add.
    func addDocument(_ document: Document) {
        self.documents[document.id] = document
    }

    /// Retrieves a document by its ID.
    /// - Parameter id: The unique identifier of the document.
    /// - Returns: The Document instance if found, otherwise nil.
    func getDocument(id: String) -> Document? {
        return documents[id]
    }

    /// Retrieves all documents currently in the store.
    /// - Returns: An array of all Document instances.
    func getAllDocuments() -> [Document] {
        return Array(documents.values)
    }
}

// MARK: - 2. The `DocumentRetriever`

/// `DocumentRetriever` is responsible for finding relevant snippets from the document store
/// based on a given query. This example uses a very basic keyword-matching approach.
/// In a real RAG system, this would involve embeddings, vector databases, and semantic search.
final class DocumentRetriever {
    private let documentStore: DocumentStore

    /// Initializes the retriever with access to a document store.
    /// - Parameter documentStore: The DocumentStore instance to retrieve documents from.
    init(documentStore: DocumentStore) {
        self.documentStore = documentStore
    }

    /// Retrieves relevant text snippets from the documents based on a query.
    /// This is a simplified keyword-based retrieval.
    /// - Parameters:
    ///   - query: The user's search query.
    ///   - maxSnippets: The maximum number of relevant snippets to return.
    ///   - snippetLength: The approximate character length of each snippet.
    /// - Returns: An array of relevant text snippets.
    func retrieveRelevantSnippets(query: String, maxSnippets: Int = 3, snippetLength: Int = 200) async throws -> [String] {
        let allDocuments = await documentStore.getAllDocuments()
        let keywords = query.lowercased().split(separator: " ").map(String.init)
        var relevantSnippets: [String] = []

        // A very basic scoring mechanism: count how many keywords appear in a document.
        // In a real system, this would be much more sophisticated (TF-IDF, BM25, vector similarity).
        let scoredDocuments = allDocuments.map { doc -> (Document, Int) in
            let score = keywords.reduce(0) { currentScore, keyword in
                // Simple check for keyword presence
                if doc.content.lowercased().contains(keyword) {
                    return currentScore + 1
                }
                return currentScore
            }
            return (doc, score)
        }
        .filter { $0.1 > 0 } // Only consider documents with at least one matching keyword
        .sorted { $0.1 > $1.1 } // Sort by score (highest first)

        // Extract snippets from the top-scoring documents
        for (doc, _) in scoredDocuments {
            if relevantSnippets.count >= maxSnippets { break }

            // Find the first occurrence of any keyword in the document content
            if let firstKeyword = keywords.first(where: { doc.content.lowercased().contains($0) }),
               let range = doc.content.lowercased().range(of: firstKeyword) {

                let index = doc.content.distance(from: doc.content.startIndex, to: range.lowerBound)
                let start = max(0, index - snippetLength / 2)
                let end = min(doc.content.count, index + snippetLength / 2)

                let startIndex = doc.content.index(doc.content.startIndex, offsetBy: start)
                let endIndex = doc.content.index(doc.content.startIndex, offsetBy: end)

                let snippet = String(doc.content[startIndex..<endIndex])
                relevantSnippets.append("Document: \(doc.title)\nSnippet: \"\(snippet.trimmingCharacters(in: .whitespacesAndNewlines))...\"")
            } else {
                // Fallback: if no specific keyword found or snippet extraction fails, take a chunk
                let fallbackSnippet = String(doc.content.prefix(snippetLength))
                relevantSnippets.append("Document: \(doc.title)\nSnippet: \"\(fallbackSnippet.trimmingCharacters(in: .whitespacesAndNewlines))...\"")
            }
        }

        return relevantSnippets
    }
}

// MARK: - 3. The `PromptComposer`

/// `PromptComposer` takes the original user query and the retrieved context
/// and combines them into a single, well-structured prompt for an LLM.
final class PromptComposer {

    /// Composes a final prompt string for an LLM.
    /// - Parameters:
    ///   - userQuery: The original query from the user.
    ///   - retrievedContext: An array of relevant text snippets retrieved from local documents.
    /// - Returns: A formatted string ready to be sent to an LLM.
    func composePrompt(userQuery: String, retrievedContext: [String]) throws -> String {
        guard !userQuery.isEmpty else {
            throw DocQueryError.promptCompositionError("User query cannot be empty.")
        }

        var prompt = "You are an AI assistant tasked with answering questions based on provided context.\n"
        prompt += "If the answer is not available in the context, state that you don't have enough information.\n\n"

        if !retrievedContext.isEmpty {
            prompt += "Here is some relevant information from my local documents:\n"
            for (index, snippet) in retrievedContext.enumerated() {
                prompt += "Context \(index + 1):\n\(snippet)\n\n"
            }
            prompt += "Based on the above context, please answer the following question:\n"
        } else {
            prompt += "No specific local context was found for your query. Please answer the following question to the best of your general knowledge:\n"
        }

        prompt += "User Question: \(userQuery)\n"
        prompt += "Answer:"

        return prompt
    }
}

// MARK: - 4. Integrating into an App Flow (Simulated `ViewModel` or `Service`)

/// `DocumentAssistantService` orchestrates the RAG process: retrieval followed by prompt composition.
/// This acts as the main entry point for a user's query in our simulated app.
final class DocumentAssistantService {
    private let retriever: DocumentRetriever
    private let promptComposer: PromptComposer

    /// Initializes the service with a document retriever and a prompt composer.
    /// - Parameters:
    ///   - retriever: The DocumentRetriever instance.
    ///   - promptComposer: The PromptComposer instance.
    init(retriever: DocumentRetriever, promptComposer: PromptComposer) {
        self.retriever = retriever
        self.promptComposer = promptComposer
    }

    /// Processes a user's query by first retrieving relevant local document context
    /// and then composing a final prompt for an LLM.
    /// - Parameter query: The user's input query.
    /// - Returns: The composed prompt string.
    /// - Throws: `DocQueryError` if any step in the process fails.
    func processQuery(query: String) async throws -> String {
        print("Processing query: '\(query)'")

        // Step 1: Retrieve relevant information
        let retrievedContext = try await retriever.retrieveRelevantSnippets(query: query)
        print("Retrieved \(retrievedContext.count) snippets.")

        // Step 2: Compose the final prompt
        let finalPrompt = try promptComposer.composePrompt(userQuery: query, retrievedContext: retrievedContext)
        print("--- Composed Prompt ---")
        print(finalPrompt)
        print("-----------------------")

        return finalPrompt
    }
}

// MARK: - 5. Running the Example

/// Main entry point for demonstrating the RAG pipeline.
@main
struct DocQueryApp {
    static func main() async {
        // Sample local documents
        let sampleDocuments: [String: Document] = [
            "doc1": Document(
                id: "doc1",
                title: "Introduction to Swift Concurrency",
                content: "Swift Concurrency, introduced in Swift 5.5 (and later refined in Swift 6), provides a structured way to write asynchronous and parallel code using async/await. Key concepts include Tasks, Actors, and Sendable types. This greatly simplifies managing concurrent operations and helps prevent common issues like data races. The @MainActor attribute is vital for ensuring UI updates happen on the main thread, preventing crashes and ensuring smooth user experiences."
            ),
            "doc2": Document(
                id: "doc2",
                title: "Understanding RAG for LLMs",
                content: "Retrieval Augmented Generation (RAG) is a technique used to improve the factual accuracy and reduce hallucinations in Large Language Models (LLMs). It involves retrieving relevant documents or data from an external knowledge base and then feeding that information into the LLM's prompt. This allows LLMs to leverage up-to-date, specific, or proprietary information that wasn't part of their initial training data. Vector databases and embeddings are often used for efficient semantic retrieval."
            ),
            "doc3": Document(
                id: "doc3",
                title: "Apple Silicon Performance for AI",
                content: "Apple Silicon chips, like the M1, M2, and M3 series, offer exceptional performance for AI and machine learning workloads due to their unified memory architecture and powerful Neural Engine. Running local LLMs with frameworks like Ollama or llama.cpp takes full advantage of these capabilities, allowing for fast inference directly on device. Optimizing model quantization and leveraging Core ML tools can further enhance performance on Apple hardware."
            ),
            "doc4": Document(
                id: "doc4",
                title: "SwiftUI and Data Flow",
                content: "SwiftUI is Apple's declarative UI framework. Managing data flow is crucial for building robust apps. Property wrappers like @State, @Binding, @ObservedObject, @StateObject, and @EnvironmentObject help manage the source of truth and propagate changes throughout the UI. Understanding the lifecycle of views and data is key to avoiding common pitfalls."
            )
        ]

        // Initialize our components
        let documentStore = DocumentStore(initialDocuments: sampleDocuments)
        let retriever = DocumentRetriever(documentStore: documentStore)
        let promptComposer = PromptComposer()
        let assistantService = DocumentAssistantService(retriever: retriever, promptComposer: promptComposer)

        // Simulate user queries
        let queries = [
            "What is Swift Concurrency?",
            "How does RAG work with LLMs?",
            "Tell me about Apple Silicon and AI performance.",
            "What are SwiftUI data flow patterns?",
            "Who invented the internet?" // Query with no specific local context
        ]

        for query in queries {
            do {
                _ = try await assistantService.processQuery(query: query)
                print("\n=====================================\n")
            } catch {
                print("Error processing query '\(query)': \(error.localizedDescription)")
            }
        }
    }
}
