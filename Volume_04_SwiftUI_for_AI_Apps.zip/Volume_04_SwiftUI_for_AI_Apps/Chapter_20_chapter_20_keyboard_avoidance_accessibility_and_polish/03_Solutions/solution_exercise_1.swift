
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// A simple model for chat messages
struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let content: String
    let isUser: Bool
}

struct AIChatView: View {
    @State private var messages: [ChatMessage] = [
        ChatMessage(content: "Hello! How can I assist you today?", isUser: false),
        ChatMessage(content: "Tell me about SwiftUI keyboard avoidance.", isUser: true),
        ChatMessage(content: "SwiftUI offers robust ways to handle keyboard appearance, primarily using safe area insets and ignoring safe areas.", isUser: false)
    ]
    @State private var newMessageText: String = ""
    @FocusState private var isInputActive: Bool

    // A proxy to scroll to the bottom of the ScrollView
    @State private var scrollViewProxy: ScrollViewProxy?

    var body: some View {
        VStack {
            // Chat message display area
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(messages) { message in
                            HStack {
                                if message.isUser {
                                    Spacer()
                                }
                                Text(message.content)
                                    .padding(10)
                                    .background(message.isUser ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                    .foregroundColor(message.isUser ? .white : .primary)
                                    .font(.body) // Support Dynamic Type
                                if !message.isUser {
                                    Spacer()
                                }
                            }
                            .id(message.id) // Assign ID for ScrollViewReader
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 8)
                }
                .onAppear {
                    // Store the proxy to use it later for scrolling
                    self.scrollViewProxy = proxy
                    scrollToBottom(proxy: proxy)
                }
                .onChange(of: messages) { _ in
                    // Scroll to bottom whenever new messages are added
                    scrollToBottom(proxy: proxy)
                }
            }

            // Input field at the bottom
            HStack {
                TextField("Type your message...", text: $newMessageText)
                    .textFieldStyle(.roundedBorder)
                    .focused($isInputActive)
                    .padding(.vertical, 8)
                    .submitLabel(.send) // iOS 15+
                    .onSubmit(sendMessage)

                Button("Send") {
                    sendMessage()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding([.horizontal, .bottom])
            // The safeAreaInset pushes the content up when the keyboard appears.
            // This is the primary mechanism for keyboard avoidance in modern SwiftUI.
            // The .keyboard safe area is ignored on the parent view,
            // but the inset ensures content doesn't go *under* the keyboard.
        }
        // This modifier makes the entire view extend under the keyboard,
        // allowing the safeAreaInset below to correctly calculate its height.
        .ignoresSafeArea(.keyboard, edges: .bottom)
        // This safeAreaInset pushes the ScrollView's content up by the height of the keyboard,
        // ensuring the TextField remains visible. The .keyboard safe area is dynamic.
        .safeAreaInset(edge: .bottom) {
            // An empty view as a placeholder for the keyboard height
            Color.clear.frame(height: 0)
        }
    }

    private func sendMessage() {
        guard !newMessageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        messages.append(ChatMessage(content: newMessageText, isUser: true))
        // Simulate an AI response after a short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            messages.append(ChatMessage(content: "Understood. I'm processing your request.", isUser: false))
        }
        newMessageText = ""
        isInputActive = true // Keep focus on the TextField
    }

    private func scrollToBottom(proxy: ScrollViewProxy) {
        if let lastMessage = messages.last {
            proxy.scrollTo(lastMessage.id, anchor: .bottom)
        }
    }
}

// Preview Provider
struct AIChatView_Previews: PreviewProvider {
    static var previews: some View {
        AIChatView()
    }
}
