
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN // For MLXNN.Module inheritance

// Mark availability for modern Swift features and SDKs
@available(iOS 17.0, macOS 14.0, *)
class ChatEngine {

    // MARK: - 1. Define Tools (Swift Functions)

    /// Represents a tool that can be called by the LLM.
    /// In a real app, these would perform actual actions (e.g., network requests, device API calls).
    enum Tool {
        case getCurrentWeather(location: String)
        case sendEmail(recipient: String, subject: String, body: String)
        // Add more tools as your application grows
    }

    /// A simple struct to represent the JSON output format our mock LLM will produce for a tool call.
    struct ToolCall: Codable {
        let tool_name: String
        let arguments: [String: String] // Simple string-to-string for this example
    }

    /// Performs a mock weather lookup.
    /// - Parameter location: The city to get weather for.
    /// - Returns: A descriptive string of the weather.
    func getCurrentWeather(location: String) async -> String {
        print("🌍 Tool: Fetching weather for \(location)...")
        // Simulate a network delay
        try? await Task.sleep(for: .seconds(1))
        switch location.lowercased() {
        case "cupertino":
            return "The weather in Cupertino is sunny with a high of 25°C."
        case "london":
            return "The weather in London is cloudy with a chance of rain, 15°C."
        default:
            return "Could not retrieve weather for \(location)."
        }
    }

    /// Performs a mock email sending.
    /// - Parameters:
    ///   - recipient: The email address of the recipient.
    ///   - subject: The subject of the email.
    ///   - body: The body content of the email.
    /// - Returns: A confirmation message.
    func sendEmail(recipient: String, subject: String, body: String) async -> String {
        print("📧 Tool: Sending email to \(recipient) with subject '\(subject)'...")
        try? await Task.sleep(for: .seconds(0.5))
        return "Email sent successfully to \(recipient)."
    }

    // MARK: - 2. Mock LLM (MLXNN.Module) for Tool Call Generation

    /// A highly simplified, mock MLX model that simulates an LLM's output.
    /// In a real scenario, this would be a full-fledged pre-trained LLM (e.g., Llama-2, Phi-3)
    /// loaded via MLX, and its output would be text that *you then parse* for JSON.
    ///
    /// For demonstration, this model directly outputs a tensor that decodes to a JSON string
    /// representing a tool call based on a simple "prompt ID".
    class MockToolCallingLLM: MLXNN.Module {
        let toolCallOutputTensor: MLXArray
        let regularResponseOutputTensor: MLXArray

        /// Initializes the mock LLM with predefined outputs.
        /// - Parameters:
        ///   - toolCallJSON: The JSON string representing a tool call.
        ///   - regularResponseText: A regular text response string.
        init(toolCallJSON: String, regularResponseText: String) {
            // Convert the JSON string to an MLXArray.
            // In a real LLM, the model would output token IDs, which are then decoded to a string.
            // Here, we directly encode the string for simplicity.
            self.toolCallOutputTensor = MLXArray(
                toolCallJSON.utf8.map { Float($0) },
                shape: [toolCallJSON.count],
                dtype: .float32
            )
            self.regularResponseOutputTensor = MLXArray(
                regularResponseText.utf8.map { Float($0) },
                shape: [regularResponseText.count],
                dtype: .float32
            )
            super.init()
        }

        /// Simulates the LLM's forward pass.
        /// - Parameter input: A dummy input (e.g., a prompt ID).
        /// - Returns: An `MLXArray` representing the LLM's raw output.
        ///
        /// **MLX Lazy Evaluation:** Notice that the actual computation (selecting `toolCallOutputTensor`
        /// or `regularResponseOutputTensor`) only happens when `eval()` is called later.
        /// The `MLXArray`s are symbolic graphs until then.
        func callAsFunction(_ input: MLXArray) -> MLXArray {
            // For simplicity, if input[0] is 1, it's a tool call prompt. Otherwise, a regular response.
            // In a real LLM, this would be based on complex token analysis.
            if input[0].item() as! Int == 1 {
                return toolCallOutputTensor
            } else {
                return regularResponseOutputTensor
            }
        }
    }

    // MARK: - 3. Chat Engine Logic

    private var llm: MockToolCallingLLM

    init() {
        // Define our mock tool call JSON
        let toolCallJSON = """
        {
          "tool_name": "getCurrentWeather",
          "arguments": {
            "location": "Cupertino"
          }
        }
        """
        let regularResponseText = "I'm sorry, I can only provide information about weather or send emails for now."
        self.llm = MockToolCallingLLM(
            toolCallJSON: toolCallJSON,
            regularResponseText: regularResponseText
        )
        // MLX models are lazily evaluated. This `eval()` call explicitly compiles the graph
        // for the mock LLM's forward pass, making subsequent inferences faster.
        // It's good practice to call `eval()` on your models after loading/initializing them.
        self.llm.eval()
        print("✅ MLX MockToolCallingLLM initialized and evaluated.")
    }

    /// Processes a user's message, leveraging the MLX model for tool calling.
    /// - Parameter message: The user's input message.
    /// - Returns: A `String` response from the chat engine.
    ///
    /// **Unified Memory & Zero-Copy:** When `MLXArray`s are created or passed around,
    /// they often point directly to data in Unified Memory on Apple Silicon.
    /// This avoids costly data copies between CPU and GPU, which is a major performance benefit.
    func processMessage(_ message: String) async -> String {
        print("\nUser: \(message)")

        // Simulate prompt encoding:
        // If message contains "weather", trigger tool call (input ID 1).
        // Otherwise, trigger regular response (input ID 0).
        let promptID: Int
        if message.lowercased().contains("weather") {
            promptID = 1 // Simulate a prompt that triggers a tool call
        } else {
            promptID = 0 // Simulate a prompt that triggers a regular response
        }

        let llmInput = MLXArray(promptID, dtype: .int32)

        // Perform inference with the MLX model.
        // This is where MLX's computation graph is executed.
        let llmOutputArray = llm(llmInput)

        // Convert the MLXArray output back to a Swift String.
        // In a real LLM, this would involve decoding token IDs to text.
        // Here, we convert the float array back to UTF8 bytes and then to String.
        let outputFloats = llmOutputArray.item(Float.self) // Get raw floats
        let outputBytes = outputFloats.map { UInt8($0) } // Convert to UInt8 bytes
        guard let llmRawOutput = String(bytes: outputBytes, encoding: .utf8) else {
            return "Error decoding LLM output."
        }

        print("LLM Raw Output: \(llmRawOutput)")

        // Attempt to parse the LLM's raw output as a ToolCall JSON.
        if let toolCallData = llmRawOutput.data(using: .utf8),
           let toolCall = try? JSONDecoder().decode(ToolCall.self, from: toolCallData) {

            print("Detected Tool Call: \(toolCall.tool_name) with args \(toolCall.arguments)")

            // Execute the detected tool
            return await executeTool(toolCall: toolCall)

        } else {
            // If it's not a valid tool call JSON, treat it as a regular text response.
            return llmRawOutput
        }
    }

    /// Dynamically dispatches and executes the appropriate Swift function based on the tool call.
    /// - Parameter toolCall: The parsed `ToolCall` object.
    /// - Returns: The result of the tool execution.
    private func executeTool(toolCall: ToolCall) async -> String {
        switch toolCall.tool_name {
        case "getCurrentWeather":
            guard let location = toolCall.arguments["location"] else {
                return "Error: 'location' argument missing for getCurrentWeather."
            }
            return await getCurrentWeather(location: location)
        case "sendEmail":
            guard let recipient = toolCall.arguments["recipient"],
                  let subject = toolCall.arguments["subject"],
                  let body = toolCall.arguments["body"] else {
                return "Error: Missing arguments for sendEmail."
            }
            return await sendEmail(recipient: recipient, subject: subject, body: body)
        default:
            return "Error: Unknown tool '\(toolCall.tool_name)'."
        }
    }
}

// MARK: - Main Application Entry Point

@main
@available(iOS 17.0, macOS 14.0, *)
struct MyApp {
    static func main() async {
        let chatEngine = ChatEngine()

        // Test cases
        let response1 = await chatEngine.processMessage("What's the weather like in Cupertino?")
        print("🤖 Chatbot: \(response1)")

        let response2 = await chatEngine.processMessage("Tell me a joke.")
        print("🤖 Chatbot: \(response2)")

        let response3 = await chatEngine.processMessage("What about the weather in London?")
        print("🤖 Chatbot: \(response3)")

        // Example of a tool call that would fail due to missing arguments (if implemented)
        // let response4 = await chatEngine.processMessage("Send an email.")
        // print("🤖 Chatbot: \(response4)")
    }
}
