
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import Foundation
    import AVFoundation // For AVAudioPCMBuffer

    @available(iOS 18.0, *)
    actor AudioBufferActor {
        private var audioBuffer: [AVAudioPCMBuffer] = []
        private var currentBufferSize: Int = 0
        private let maxBufferSize: Int // e.g., to limit memory usage

        init(maxBufferSize: Int = 10 * 44100 * 2) { // 10 seconds of stereo 44.1kHz audio
            self.maxBufferSize = maxBufferSize
        }

        func append(_ buffer: AVAudioPCMBuffer) {
            // This method is implicitly isolated by the actor
            audioBuffer.append(buffer)
            currentBufferSize += Int(buffer.frameLength * buffer.format.channelCount)

            // Simple buffer management to prevent excessive memory use
            while currentBufferSize > maxBufferSize && !audioBuffer.isEmpty {
                let oldestBuffer = audioBuffer.removeFirst()
                currentBufferSize -= Int(oldestBuffer.frameLength * oldestBuffer.format.channelCount)
            }
        }

        func retrieveAndClearBuffer() -> [AVAudioPCMBuffer] {
            // This method is also implicitly isolated
            let currentBuffers = audioBuffer
            audioBuffer.removeAll()
            currentBufferSize = 0
            return currentBuffers
        }

        func isEmpty() -> Bool {
            audioBuffer.isEmpty
        }
    }
    