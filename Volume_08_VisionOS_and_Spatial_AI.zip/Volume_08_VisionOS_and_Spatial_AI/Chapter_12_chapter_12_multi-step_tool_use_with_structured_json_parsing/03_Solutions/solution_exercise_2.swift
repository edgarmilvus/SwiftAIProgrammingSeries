
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// The blueprint for any system-level tool.
protocol SystemTool: Sendable {
    var name: String { get }
    func execute() async throws -> String
}

// --- Concrete Implementations ---

struct CPUUsageTool: SystemTool {
    let name = "get_cpu_usage"
    
    func execute() async throws -> String {
        // In a real app, this would call Darwin/sysctl
        try await Task.sleep(for: .milliseconds(100)) // Simulate work
        let usage = Double.random(in: 5...45)
        return "Current CPU usage is \(String(format: "%.1f", usage))%."
    }
}

struct MemoryUsageTool: SystemTool {
    let name = "get_memory_usage"
    
    func execute() async throws -> String {
        try await Task.sleep(for: .milliseconds(100))
        let usageGB = Double.random(in: 4...16)
        return "Current memory usage is \(String(format: "%.1f", usageGB)) GB."
    }
}

/// Manages the mapping between LLM tool names and Swift implementations.
final class ToolRegistry: Sendable {
    private let tools: [String: any SystemTool]

    init(tools: [any SystemTool]) {
        var registry: [String: any SystemTool] = [:]
        for tool in tools {
            registry[tool.name] = tool
        }
        self.tools = registry
    }

    func getTool(named name: String) -> (any SystemTool)? {
        return tools[name]
    }

    func availableToolNames() -> [String] {
        return Array(tools.keys).sorted()
    }
}

/// The engine that processes tool calls and returns results.
struct ExecutionEngine {
    let registry: ToolRegistry

    func process(toolCallName: String) async -> String {
        guard let tool = registry.getTool(named: toolCallName) else {
            let available = registry.availableToolNames().joined(separator: ", ")
            return "Error: Tool '\(toolCallName)' not found. Available tools are: [\(available)]."
        }

        do {
            return try await tool.execute()
        } catch {
            return "Error executing tool '\(toolCallName)': \(error.localizedDescription)"
        }
    }
}

// --- Testing the Implementation ---
@main
struct ToolRegistryApp {
    static func main() async {
        let registry = ToolRegistry(tools: [CPUUsageTool(), MemoryUsageTool()])
        let engine = ExecutionEngine(registry: registry)

        print("--- Scenario 1: Valid Tool ---")
        let result1 = await engine.process(toolCallName: "get_cpu_usage")
        print("Result: \(result1)")

        print("\n--- Scenario 2: Invalid Tool ---")
        let result2 = await engine.process(toolCallName: "get_gpu_usage")
        print("Result: \(result2)")
    }
}
