
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage

func extractNamedEntities(from noteText: String) -> [NLTag: [String]] {
    var extractedEntities: [NLTag: [String]] = [
        .personName: [],
        .placeName: [],
        .organizationName: []
    ]

    // Initialize NLTagger with the .nameType scheme
    let tagger = NLTagger(tagSchemes: [.nameType], options: 0)
    tagger.string = noteText

    // Define the desired entity types
    let desiredEntityTags: [NLTag] = [.personName, .placeName, .organizationName]

    // Enumerate tags over the entire string
    tagger.enumerateTags(in: noteText.startIndex..<noteText.endIndex, unit: .word, scheme: .nameType, options: [.joinNames]) { tag, tokenRange in
        if let tag = tag, desiredEntityTags.contains(tag) {
            let entity = String(noteText[tokenRange])
            extractedEntities[tag]?.append(entity)
        }
        return true // Continue enumeration
    }

    return extractedEntities
}

// Example Usage (for testing your implementation)
/*
let sampleNote = "Dr. Sarah Connor met with John Doe from Cyberdyne Systems in San Francisco to discuss Project Skynet."
let entities = extractNamedEntities(from: sampleNote)
print("People: \(entities[.personName] ?? [])")
print("Places: \(entities[.placeName] ?? [])")
print("Organizations: \(entities[.organizationName] ?? [])")

// Expected Output:
// People: ["Dr. Sarah Connor", "John Doe"]
// Places: ["San Francisco"]
// Organizations: ["Cyberdyne Systems"]
*/
