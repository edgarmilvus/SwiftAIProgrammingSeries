
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML // Assuming Core ML models are used
import Foundation // For UUID

@available(visionOS 1.0, *)
actor EyeGazeAIProcessor {
    // In a real application, this would be a loaded Core ML model instance
    private var gazeIntentModel: MLModel? // Placeholder for an actual MLModel
    private var recentGazeHistory: [GazeRay] = [] // State managed by the actor
    private let historyCapacity: Int = 30

    init() {
        // Load your Core ML model here
        // self.gazeIntentModel = try? MyGazeIntentModel(configuration: MLModelConfiguration())
        print("EyeGazeAIProcessor actor initialized.")
    }

    // Method to process new gaze data and update internal state
    func processNewGazeData(_ gazeRay: GazeRay) async throws {
        recentGazeHistory.append(gazeRay)
        if recentGazeHistory.count > historyCapacity {
            recentGazeHistory.removeFirst()
        }
        print("Actor received new gaze data. History count: \(recentGazeHistory.count)")

        // Potentially trigger immediate inference or update internal model state
        // For demonstration, we'll just store and then infer when requested.
    }

    // Method to infer intent based on current internal state
    func inferCurrentIntent() async throws -> GazeIntent {
        guard let model = gazeIntentModel else {
            // Simulate inference if no model is loaded
            try await Task.sleep(for: .milliseconds(20))
            let focusedID = recentGazeHistory.last?.direction.x ?? 0 > 0 ? "right_panel" : "left_panel"
            return GazeIntent(focusedObjectID: focusedID, type: .focus)
        }

        // In a real scenario, you'd feed recentGazeHistory into your Core ML model
        // let input = MyGazeIntentModelInput(features: recentGazeHistory.map { $0.toMLFeature() })
        // let prediction = try await model.prediction(input: input)
        // return GazeIntent(from: prediction)
        
        // Simulate actual inference
        try await Task.sleep(for: .milliseconds(50))
        let focusedID = UUID().uuidString // Placeholder
        return GazeIntent(focusedObjectID: focusedID, type: .select)
    }
}
