
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import Observation
import SwiftUI

// MARK: - Data Model

@available(iOS 18.0, *)
struct CodeLine: Identifiable, Hashable {
    let id = UUID()
    let content: String
}

// MARK: - ViewModel

@available(iOS 18.0, *)
@Observable
class CodeGeneratorViewModel {
    var generatedCodeLines: [CodeLine] = []
    private var generationTask: Task<Void, Never>?

    func startGeneratingCode() {
        reset() // Clear previous lines
        generationTask = Task {
            let sampleCode = [
                "import SwiftUI",
                "",
                "@available(iOS 18.0, *)",
                "struct MyAwesomeView: View {",
                "    var body: some View {",
                "        VStack {",
                "            Text(\"Hello, AI Code!\")",
                "                .font(.largeTitle)",
                "            // More code will be generated here...",
                "            Button(\"Tap Me\") {",
                "                print(\"Button tapped!\")",
                "            }",
                "        }",
                "    }",
                "}"
            ]

            for (index, line) in sampleCode.enumerated() {
                await Task.sleep(nanoseconds: UInt64(0.5 * 1_000_000_000)) // Simulate generation delay
                await MainActor.run {
                    self.generatedCodeLines.append(CodeLine(content: line))
                }
                if index < sampleCode.count - 1 {
                    await Task.sleep(nanoseconds: UInt64(0.05 * 1_000_000_000)) // Small delay for newline
                    await MainActor.run {
                        self.generatedCodeLines.append(CodeLine(content: "\n")) // Add newline as a separate token
                    }
                }
            }
        }
    }

    func reset() {
        generationTask?.cancel()
        generatedCodeLines = []
    }
}

// MARK: - PreferenceKeys for Scroll Position Detection

// PreferenceKey to get content height
struct CodeContentHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

// PreferenceKey to get scroll view height
struct CodeScrollViewHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

// MARK: - View

@available(iOS 18.0, *)
struct CodeGeneratorView: View {
    @State private var viewModel = CodeGeneratorViewModel()
    
    @State private var isAutoScrollingEnabled: Bool = true
    @State private var showScrollToBottomButton: Bool = false
    
    // State to track scroll position for "at bottom" detection
    @State private var scrollViewContentHeight: CGFloat = 0
    @State private var scrollViewHeight: CGFloat = 0
    @State private var currentScrollOffset: CGFloat = 0 // Track scroll offset
    
    // Threshold for considering "at bottom" due to floating point inaccuracies
    private let atBottomThreshold: CGFloat = 10

    // Computed property to check if the scroll view is currently at the bottom
    private var isAtBottom: Bool {
        // If content is smaller than scroll view, it's always at bottom
        if scrollViewContentHeight <= scrollViewHeight { return true }
        
        // Otherwise, check if current offset is close to max scrollable offset
        let maxScrollOffset = scrollViewContentHeight - scrollViewHeight
        return currentScrollOffset >= maxScrollOffset - atBottomThreshold
    }
    
    private var lastLineId: UUID? {
        viewModel.generatedCodeLines.last?.id
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(viewModel.generatedCodeLines) { line in
                            Text(line.content)
                                .font(.monospaced(.body)()) // Monospaced font for code
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.horizontal, 8)
                                .id(line.id) // Crucial for ScrollViewReader
                        }
                        // Invisible view at the very bottom to detect content height
                        Color.clear
                            .frame(height: 1) // Minimal height for content height calculation
                            .id("bottom_anchor")
                            .background(GeometryReader { geo in
                                Color.clear.preference(key: CodeContentHeightPreferenceKey.self, value: geo.frame(in: .named("scroll")).maxY)
                            })
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    // Apply background for code block
                    .background(Color.black.opacity(0.8))
                    .cornerRadius(8)
                    .padding()
                }
                .coordinateSpace(name: "scroll") // Define coordinate space for GeometryReader
                .onPreferenceChange(CodeContentHeightPreferenceKey.self) {
                    scrollViewContentHeight = $0
                }
                .background(GeometryReader { geo in // Get ScrollView's own height
                    Color.clear.preference(key: CodeScrollViewHeightPreferenceKey.self, value: geo.size.height)
                })
                .onPreferenceChange(CodeScrollViewHeightPreferenceKey.self) {
                    scrollViewHeight = $0
                }
                .onChange(of: viewModel.generatedCodeLines.count) {
                    // Only auto-scroll if enabled AND we are currently at the bottom (or content is smaller than view)
                    if isAutoScrollingEnabled && isAtBottom {
                        withAnimation(.easeOut(duration: 0.3)) {
                            proxy.scrollTo(lastLineId ?? "bottom_anchor", anchor: .bottom)
                        }
                    } else if !isAtBottom {
                        // If new content arrives and we're not at the bottom, show the button
                        showScrollToBottomButton = true
                    }
                }
                .onScroll { phase in
                    currentScrollOffset = phase.contentOffset.y
                    
                    // If user is actively scrolling, disable auto-scroll
                    if phase.isDecelerating || phase.isDragging {
                        isAutoScrollingEnabled = false
                    }
                    
                    // Determine if "Scroll to Bottom" button should be shown
                    // It should be shown if auto-scroll is off AND we are NOT at the bottom
                    showScrollToBottomButton = !isAutoScrollingEnabled && !isAtBottom
                    
                    // If user scrolls all the way to the bottom manually, re-enable auto-scroll
                    if isAtBottom {
                        isAutoScrollingEnabled = true
                        showScrollToBottomButton = false
                    }
                }
                
                // Floating "Scroll to Bottom" button
                .overlay(alignment: .bottomTrailing) {
                    if showScrollToBottomButton {
                        Button {
                            withAnimation(.easeOut(duration: 0.5)) {
                                proxy.scrollTo(lastLineId ?? "bottom_anchor", anchor: .bottom)
                            }
                            isAutoScrollingEnabled = true
                            showScrollToBottomButton = false
                        } label: {
                            Label("Scroll to Bottom", systemImage: "arrow.down.circle.fill")
                                .font(.headline)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(Color.accentColor)
                                .foregroundColor(.white)
                                .cornerRadius(20)
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                        .transition(.opacity.animation(.easeInOut))
                    }
                }
            }

            HStack {
                Button("Generate Code") {
                    viewModel.startGeneratingCode()
                }
                .buttonStyle(.borderedProminent)

                Button("Reset") {
                    viewModel.reset()
                    isAutoScrollingEnabled = true // Reset auto-scroll state
                    showScrollToBottomButton = false
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
        .navigationTitle("AI Code Generator")
        .onDisappear {
            viewModel.reset()
        }
    }
}

// MARK: - Preview (for Xcode Canvas)

@available(iOS 18.0, *)
#Preview {
    CodeGeneratorView()
}
