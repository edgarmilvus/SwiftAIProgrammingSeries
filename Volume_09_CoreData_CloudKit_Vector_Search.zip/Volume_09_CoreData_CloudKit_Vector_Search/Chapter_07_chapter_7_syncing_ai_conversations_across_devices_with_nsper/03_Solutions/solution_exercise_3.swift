
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreData

@objc(AIPersona)
public class AIPersona: NSManagedObject {
    @NSManaged public var name: String?
    @NSManaged public var systemPrompt: String?
    @NSManaged public var temperature: Double
    @NSManaged public var lastModified: Date?
    @NSManaged public var isGlobalIdentifier: Bool // Used to identify the singleton
}

class PersonaService {
    let container: NSPersistentCloudKitContainer
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }
    
    /// Updates the global persona or creates it if it doesn't exist.
    func updateGlobalPersona(name: String, prompt: String, temp: Double) async throws {
        let context = container.newBackgroundContext()
        // Crucial: Use a merge policy that resolves conflicts at the property level
        context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        try await context.perform {
            let request: NSFetchRequest<AIPersona> = AIPersona.fetchRequest()
            // We look for the unique "Global" persona
            request.predicate = NSPredicate(format: "isGlobalIdentifier == YES")
            request.fetchLimit = 1
            
            let persona = try context.fetch(request).first ?? AIPersona(context: context)
            
            // Check for "Latest Wins" logic manually if needed, 
            // though mergePolicy handles the collision.
            let newTimestamp = Date()
            if let existingTimestamp = persona.lastModified, existingTimestamp > newTimestamp {
                // If the local change is actually older than what's in the store, skip.
                return 
            }
            
            persona.name = name
            persona.systemPrompt = prompt
            persona.temperature = temp
            persona.lastModified = newTimestamp
            persona.isGlobalIdentifier = true
            
            if context.hasChanges {
                try context.save()
            }
        }
    }
}
