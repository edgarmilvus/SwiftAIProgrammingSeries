
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import NaturalLanguage // For NLContextualEmbedding, TextGenerationService

@available(iOS 18.0, macOS 15.0, *)
struct Document: Identifiable {
    let id = UUID()
    let title: String
    let content: String
}

@available(iOS 18.0, macOS 15.0, *)
func summarizeThematicContent(documents: [Document], similarityThreshold: Float = 0.7) async throws -> String {
    guard !documents.isEmpty else { return "No documents to summarize." }

    let embeddingService = NLContextualEmbedding.current
    var documentEmbeddings: [Document: [Float]] = [:]

    // 1. Generate embeddings for each document's content.
    // We'll use the entire document content for a holistic embedding.
    for document in documents {
        // NLContextualEmbedding.embedding(for:) can be expensive for very long texts.
        // For production, consider splitting documents into paragraphs and averaging embeddings,
        // or using a more sophisticated approach. For this exercise, we'll use the full content.
        let embedding = try await embeddingService.embedding(for: document.content)
        documentEmbeddings[document] = embedding
    }

    guard !documentEmbeddings.isEmpty else {
        return "Could not generate embeddings for any document."
    }

    // 2. Identify semantic similarities to group relevant content.
    // For simplicity, we'll find documents that are "similar enough" to a central theme.
    // A more advanced approach would involve proper clustering (e.g., K-means, hierarchical).
    
    // Let's pick a "representative" document or combine all content for the LLM to find themes.
    // For this exercise, we'll combine content from documents that are sufficiently similar
    // to each other to ensure we're feeding a coherent set of ideas.
    
    var relevantDocuments: [Document] = []
    
    // Simple approach: Consider all documents. The LLM will be tasked to find themes.
    // If we wanted to filter, we'd need a more complex clustering or similarity matrix.
    // For a thematic summary across *all* documents, we pass all their content.
    
    // Alternative (more complex, but closer to the "identify themes" hint):
    // Calculate pairwise similarities and form groups.
    // For now, let's assume the LLM is smart enough to find themes from concatenated text,
    // and the embeddings step helps *understand* the content for the analysis.
    
    // Let's refine: Use embeddings to select *most relevant* documents if there's a huge disparity.
    // For the "thematic summary" across *all* provided documents, we'll include all content.
    // The prompt is crucial here.

    let combinedRelevantText = documents.map { "## \($0.title)\n\($0.content)" }.joined(separator: "\n\n---\n\n")

    // 3. Use TextGenerationService to synthesize a summary of the common themes.
    let generationService = TextGenerationService()
    
    let prompt = """
    Analyze the following collection of documents. Identify and summarize the overarching common themes, key findings, and shared insights that emerge across all of them. Do not summarize each document individually, but rather synthesize a cohesive summary of their collective message.

    Documents:
    \(combinedRelevantText)

    Thematic Summary:
    """
    
    let thematicSummary = try await generationService.generate(prompt)
    return thematicSummary
}

// Example usage:
@available(iOS 18.0, macOS 15.0, *)
struct MultiDocumentSummarizerExample: View {
    let researchPapers = [
        Document(title: "AI in Healthcare", content: "This paper explores the application of AI algorithms for disease diagnosis and personalized treatment plans in healthcare, focusing on machine learning models and data privacy challenges in medical data processing."),
        Document(title: "Machine Learning for Medical Imaging", content: "We present novel machine learning techniques for analyzing medical images, improving diagnostic accuracy and reducing clinician workload. Specific focus on CNNs for tumor detection and ethical considerations of algorithmic bias."),
        Document(title: "Ethics of AI in Medicine", content: "A discussion on the ethical implications of deploying artificial intelligence in clinical settings, including bias, accountability, patient privacy, and the need for transparent AI systems."),
        Document(title: "Drug Discovery with AI", content: "Utilizing AI and computational methods to accelerate the drug discovery process, from target identification to lead optimization. Highlights the role of generative models and large-scale data analysis.")
    ]
    @State private var thematicSummary: String = "Tap 'Summarize' to get a thematic summary."
    @State private var isLoading: Bool = false
    @State private var showingErrorAlert: Bool = false
    @State private var errorMessage: String = ""

    var body: some View {
        VStack(alignment: .leading) {
            Text("Research Papers:")
                .font(.headline)
            ScrollView {
                ForEach(researchPapers) { paper in
                    VStack(alignment: .leading) {
                        Text("**\(paper.title)**")
                            .font(.subheadline)
                        Text(paper.content)
                            .font(.caption)
                            .lineLimit(2) // Truncate for display
                    }
                    .padding(.bottom, 5)
                }
            }
            .frame(height: 150)
            .border(Color.gray, width: 0.5)
            .padding(.horizontal)

            Button {
                Task {
                    isLoading = true
                    errorMessage = ""
                    showingErrorAlert = false
                    do {
                        thematicSummary = try await summarizeThematicContent(documents: researchPapers)
                    } catch {
                        errorMessage = "Error summarizing themes: \(error.localizedDescription)"
                        showingErrorAlert = true
                        thematicSummary = "Failed to generate thematic summary."
                        print("Error summarizing themes: \(error)")
                    }
                    isLoading = false
                }
            } label: {
                if isLoading {
                    ProgressView()
                } else {
                    Text("Summarize Common Themes")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isLoading)
            .padding()

            Text("Thematic Summary:")
                .font(.headline)
            ScrollView {
                Text(thematicSummary)
                    .padding(.top, 5)
            }
            .frame(minHeight: 100)
            .border(Color.gray, width: 0.5)
            .padding(.horizontal)
        }
        .navigationTitle("Multi-Document Thematic Summarizer")
        .padding()
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }
}

// To run this example in a SwiftUI App:
/*
@main
@available(iOS 18.0, macOS 15.0, *)
struct ResearchApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                MultiDocumentSummarizerExample()
            }
        }
    }
}
*/
