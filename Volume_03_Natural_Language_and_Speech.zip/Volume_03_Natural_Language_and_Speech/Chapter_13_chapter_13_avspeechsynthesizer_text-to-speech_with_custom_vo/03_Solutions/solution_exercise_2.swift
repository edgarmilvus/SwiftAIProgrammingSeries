
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AVFoundation

// MARK: - SpeechManager (Extended from Exercise 1)

class SpeechManager: NSObject {
    private let synthesizer = AVSpeechSynthesizer()

    // Curated voice identifiers (from Exercise 1)
    private var curatedVoiceIdentifiers: [String: String] = [:]

    // Adjustable speech properties
    var speechRate: Float = AVSpeechUtteranceDefaultSpeechRate {
        didSet {
            // Clamp rate to valid range
            speechRate = max(AVSpeechUtteranceMinimumSpeechRate, min(AVSpeechUtteranceMaximumSpeechRate, speechRate))
            print("Speech rate set to: \(speechRate)")
        }
    }
    var speechPitchMultiplier: Float = 1.0 { // Default pitch
        didSet {
            // Clamp pitch to reasonable range (0.5 to 2.0 as suggested)
            speechPitchMultiplier = max(0.5, min(2.0, speechPitchMultiplier))
            print("Speech pitch multiplier set to: \(speechPitchMultiplier)")
        }
    }

    private var currentUtteranceText: String? // To store text of the current utterance for logging

    override init() {
        super.init()
        synthesizer.delegate = self
        setupCuratedVoices()
    }

    // (setupCuratedVoices method is identical to Exercise 1, omitted for brevity here but present in full solution)
    private func setupCuratedVoices() {
        let allVoices = AVSpeechSynthesisVoice.speechVoices()

        if let usFemale = allVoices.first(where: { $0.language == "en-US" && $0.gender == .female }) {
            curatedVoiceIdentifiers["US Female"] = usFemale.identifier
            print("Curated Voice: US Female found: \(usFemale.name) (\(usFemale.identifier))")
        } else if let anyUSVoice = allVoices.first(where: { $0.language == "en-US" }) {
             curatedVoiceIdentifiers["US Female"] = anyUSVoice.identifier
        }

        if let usMale = allVoices.first(where: { $0.language == "en-US" && $0.gender == .male }) {
            curatedVoiceIdentifiers["US Male"] = usMale.identifier
            print("Curated Voice: US Male found: \(usMale.name) (\(usMale.identifier))")
        } else if let anyUSVoice = allVoices.first(where: { $0.language == "en-US" }) {
             curatedVoiceIdentifiers["US Male"] = anyUSVoice.identifier
        }

        if let frenchVoice = allVoices.first(where: { $0.language == "fr-FR" }) {
            curatedVoiceIdentifiers["French"] = frenchVoice.identifier
            print("Curated Voice: French found: \(frenchVoice.name) (\(frenchVoice.identifier))")
        } else {
            print("Curated Voice: French (fr-FR) not found. This option will fall back to system default.")
        }
    }

    /// Speaks the given text using the specified voice identifier, applying current rate and pitch settings.
    /// New requests interrupt any ongoing speech.
    ///
    /// - Parameters:
    ///   - text: The text string to be spoken.
    ///   - voiceIdentifier: An optional identifier for the desired voice.
    func speak(_ text: String, voiceIdentifier: String? = nil) {
        // Stop any current speech to implement interruption logic
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
            print("Interrupted previous speech to start new utterance.")
        }

        let utterance = AVSpeechUtterance(string: text)
        var selectedVoice: AVSpeechSynthesisVoice?
        var usedVoiceName: String = "System Default"
        var fallbackOccurred = false

        if let identifier = voiceIdentifier {
            if let curatedID = curatedVoiceIdentifiers[identifier] {
                selectedVoice = AVSpeechSynthesisVoice(identifier: curatedID)
            } else {
                selectedVoice = AVSpeechSynthesisVoice(identifier: identifier)
            }

            if selectedVoice == nil {
                fallbackOccurred = true
                print("Voice '\(identifier)' not found. Falling back to system default voice.")
            }
        }

        utterance.voice = selectedVoice ?? AVSpeechSynthesisVoice(language: nil)
        utterance.rate = speechRate
        utterance.pitchMultiplier = speechPitchMultiplier

        if let finalVoice = utterance.voice {
            usedVoiceName = "\(finalVoice.name) (\(finalVoice.language))"
        }

        if fallbackOccurred {
            print("Fallback: Using voice: \(usedVoiceName)")
        } else {
            print("Speaking with voice: \(usedVoiceName) at rate \(String(format: "%.2f", speechRate)) and pitch \(String(format: "%.2f", speechPitchMultiplier))")
        }

        self.currentUtteranceText = text // Store for delegate method logging
        synthesizer.speak(utterance)
    }

    /// Pauses the current speech.
    func pause() {
        if synthesizer.isSpeaking {
            synthesizer.pauseSpeaking(at: .word) // Pause at the nearest word boundary for smoothness
            print("Speech paused.")
        } else {
            print("No speech active to pause.")
        }
    }

    /// Continues speech that was previously paused.
    func `continue`() {
        if synthesizer.isPaused {
            synthesizer.continueSpeaking()
            print("Speech continued.")
        } else {
            print("No paused speech to continue.")
        }
    }

    /// Stops the current speech and clears the synthesizer's queue.
    func stop() {
        if synthesizer.isSpeaking || synthesizer.isPaused {
            synthesizer.stopSpeaking(at: .immediate)
            print("Speech stopped.")
            self.currentUtteranceText = nil
        } else {
            print("No speech active or paused to stop.")
        }
    }

    // Public method to get curated voice keys (from Exercise 1)
    func getCuratedVoiceKeys() -> [String] {
        return Array(curatedVoiceIdentifiers.keys).sorted()
    }
}

// MARK: - AVSpeechSynthesizerDelegate (Implementation for Exercise 2)

extension SpeechManager: AVSpeechSynthesizerDelegate {
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        if let spokenText = currentUtteranceText {
            print("Speech finished for utterance: \"\(spokenText.prefix(50))...\"")
        } else {
            print("Speech finished for an utterance.")
        }
        self.currentUtteranceText = nil // Clear after completion
    }

    // Other delegate methods for completeness, though not strictly required by this exercise:
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        print("Speech started for utterance.")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didPause utterance: AVSpeechUtterance) {
        print("Speech did pause.")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didContinue utterance: AVSpeechUtterance) {
        print("Speech did continue.")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        print("Speech did cancel.")
        self.currentUtteranceText = nil
    }

    // `willSpeakRangeOfSpeechString` will be used in Exercise 4
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        // print("Will speak range: \(characterRange) of \"\(utterance.speechString)\"")
    }
}

// MARK: - Example Usage

func demonstrateExercise2() {
    print("\n--- Exercise 2 Demonstration ---")
    let speechManager = SpeechManager()

    // Set custom rate and pitch
    speechManager.speechRate = 0.2 // Slower than default
    speechManager.speechPitchMultiplier = 1.5 // Higher pitch

    print("\nSpeaking first sentence with custom rate and pitch:")
    speechManager.speak("This is the first sentence. It should be spoken slowly with a higher pitch.", voiceIdentifier: "US Female")

    // Pause after a short delay
    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
        speechManager.pause()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            // Continue after another delay
            speechManager.continue()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                // Speak a new sentence, which should interrupt the first if it's still going
                print("\nSpeaking second sentence (should interrupt first):")
                speechManager.speechRate = 0.6 // Faster rate
                speechManager.speechPitchMultiplier = 0.8 // Lower pitch
                speechManager.speak("Now, this is the second sentence. It should interrupt the first and speak faster with a lower pitch.", voiceIdentifier: "US Male")

                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    // Stop the second sentence
                    speechManager.stop()
                    print("\n--- Exercise 2 Demonstration Complete ---")
                }
            }
        }
    }
}

// Call the demonstration function to run the example
// demonstrateExercise2()
