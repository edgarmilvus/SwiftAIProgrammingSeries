
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import StoreKit
import Combine

// MARK: - Package Dependencies

/*
 To use this in a real project, your Package.swift would include:
 
 dependencies: [
     .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ],
 targets: [
     .target(name: "LuminaAI", dependencies: [.product(name: "Algorithms", package: "swift-algorithms")])
 ]
*/

// MARK: - Models & Errors

/// Represents the specific capabilities granted to a user based on their subscription.
/// Using an enum with associated values allows for complex, tiered AI access.
enum AIEntitlementLevel: Equatable, Sendable {
    case free(tokenLimit: Int)
    case pro(modelAccess: [AIModel], monthlyTokens: Int)
    case enterprise(modelAccess: [AIModel], unlimitedHighRes: Bool)
    case none
    
    enum AIModel: String, Sendable {
        case stableDiffusionXL = "SDXL"
        case midjourneyV6 = "MJ-V6"
        case dallE3 = "DALL-E 3"
    }
}

/// Errors specific to the subscription and entitlement lifecycle.
enum SubscriptionError: LocalizedError {
    case transactionFailed(String)
    case unauthorizedAccess(AIEntitlementLevel)
    case storeKitUnavailable
    case verificationFailed
    
    var errorDescription: String? {
        switch self {
        case .transactionFailed(let msg): return "Purchase failed: \(msg)"
        case .unauthorizedAccess(let level): return "Access denied. Current tier: \(level)"
        case .storeKitUnavailable: return "StoreKit is currently unavailable."
        case .verificationFailed: return "Could not verify purchase authenticity."
        }
    }
}

// MARK: - Subscription Actor

/// The `SubscriptionActor` is the single source of truth for the user's entitlement state.
/// Being an `actor` ensures that updates from background `Transaction.updates` 
/// and queries from the `AIEngine` are synchronized, preventing data races in Swift 6.
@available(iOS 18.0, *)
actor SubscriptionActor {
    
    /// The current entitlement state, observable by the UI.
    private(set) var currentEntitlement: AIEntitlementLevel = .free(tokenLimit: 5)
    
    /// Tracks if the listener is currently active to prevent redundant task creation.
    private var isListenerRunning = false
    
    /// Validated product IDs for the AI tiers.
    private let proProductID = "com.lumina.ai.pro"
    private let enterpriseProductID = "com.lumina.ai.enterprise"
    
    init() {}

    /// Updates the internal entitlement state based on a verified transaction.
    /// - Parameter transaction: The StoreKit 2 transaction to process.
    func updateEntitlement(with transaction: Transaction) async {
        // In a real-world app, you would verify the JWS signature here.
        // StoreKit 2 handles much of this, but for high-value AI tokens,
        // server-side validation is still recommended.
        
        switch transaction.productID {
        case proProductID:
            currentEntitlement = .pro(modelAccess: [.dallE3], monthlyTokens: 1000)
        case enterpriseProductID:
            currentEntitlement = .enterprise(modelAccess: [.stableDiffusionXL, .midjourneyV6], unlimitedHighRes: true)
        default:
            break
        }
        
        // Always finish the transaction to notify Apple the app has processed it.
        await transaction.finish()
    }

    /// Resets the user to a free tier (e.g., after subscription expiry).
    func resetToFreeTier() {
        currentEntitlement = .free(tokenLimit: 5)
    }

    /// Checks if a specific AI capability is permitted under the current tier.
    /// - Parameter feature: The capability being requested.
    /// - Returns: A boolean indicating if the feature is allowed.
    func canAccess(feature: AIFeature) -> Bool {
        switch (currentEntitlement, feature) {
        case (.enterprise, _):
            return true
        case (.pro(let models, let tokens), .generate(let model, let cost)):
            return models.contains(model) && tokens >= cost
        case (.free(let limit), .generate(_, let cost)):
            return limit >= cost
        case (_, .highResGeneration):
            return false
        case (.none, _):
            return false
        }
    }
}

/// Defines the granular features of the AI engine.
enum AIFeature {
    case generate(AIEntitlementLevel.AIModel, cost: Int)
    case highResGeneration
    case customFineTuning
}

// MARK: - StoreKit Listener Service

/// A service responsible for observing the `Transaction.updates` stream.
/// This service must be kept alive for the duration of the app's lifecycle.
@available(iOS 18.0, *)
final class StoreKitListener: Sendable {
    
    private let subscriptionActor: SubscriptionActor
    
    init(subscriptionActor: SubscriptionActor) {
        self.subscriptionActor = subscriptionActor
    }
    
    /// Starts the background listener for transaction updates.
    /// This should be called once in the App's `init` or `onAppear`.
    func startListening() {
        Task(priority: .background) {
            // The Transaction.updates stream is a continuous AsyncSequence 
            // that emits whenever a transaction occurs (renewal, refund, etc.)
            for await update in Transaction.updates {
                print("Received transaction update: \(update.id)")
                await handleUpdate(update)
            }
        }
    }
    
    private func handleUpdate(_ update: Transaction) async {
        // Ensure the transaction is valid and not expired
        guard update.revocationDate == nil else {
            await subscriptionActor.resetToFreeTier()
            return
        }
        
        await subscriptionActor.updateEntitlement(with: update)
    }
}

// MARK: - AI Engine (The Consumer)

/// The `AIEngine` simulates the heavy-lifting component of the app.
/// It is strictly governed by the `SubscriptionActor`.
@available(iOS 18.0, *)
final class AIEngine: ObservableObject {
    
    private let subscriptionActor: SubscriptionActor
    
    @Published var isProcessing: Bool = false
    @Published var lastError: String?
    
    init(subscriptionActor: SubscriptionActor) {
        self.subscriptionActor = subscriptionActor
    }
    
    /// Attempts to generate an image using a specific model.
    /// - Parameter model: The requested AI model.
    func requestImageGeneration(model: AIEntitlementLevel.AIModel) async {
        await MainActor.run { isProcessing = true }
        
        // 1. Check entitlements via the Actor
        let isAllowed = await subscriptionActor.canAccess(feature: .generate(model, cost: 1))
        
        guard isAllowed else {
            await MainActor.run {
                self.lastError = "Upgrade to Pro to use \(model.rawValue)"
                self.isProcessing = false
            }
            return
        }
        
        // 2. Simulate heavy AI Inference
        // In a real app, this would be a URLSession call to an inference endpoint.
        try? await Task.sleep(for: .seconds(2))
        
        await MainActor.run {
            self.isProcessing = false
            self.lastError = nil
            print("Successfully generated image using \(model.rawValue)")
        }
    }
}

// MARK: - UI Integration

@available(iOS 18.0, *)
import SwiftUI

struct AIControlView: View {
    @StateObject private var aiEngine: AIEngine
    private let subscriptionActor: SubscriptionActor
    
    init(subscriptionActor: SubscriptionActor) {
        self.subscriptionActor = subscriptionActor
        // Note: In a real app, use a Dependency Injection container
        _aiEngine = StateObject(wrappedValue: AIEngine(subscriptionActor: subscriptionActor))
    }
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Lumina AI Studio")
                .font(.largeTitle.bold())
            
            if aiEngine.isProcessing {
                ProgressView("Running Diffusion Models...")
                    .padding()
            } else {
                HStack {
                    Button("Generate (SDXL)") {
                        Task { await aiEngine.requestImageGeneration(model: .stableDiffusionXL) }
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button("Generate (DALL-E)") {
                        Task { await aiEngine.requestImageGeneration(model: .dallE3) }
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            
            if let error = aiEngine.lastError {
                Text(error)
                    .foregroundColor(.red)
                    .font(.caption)
            }
        }
        .padding()
    }
}
