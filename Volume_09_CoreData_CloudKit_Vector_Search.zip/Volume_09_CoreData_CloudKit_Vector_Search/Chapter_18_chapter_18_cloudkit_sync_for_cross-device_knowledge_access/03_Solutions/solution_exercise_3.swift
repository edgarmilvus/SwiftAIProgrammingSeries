
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreData
import Foundation

@available(iOS 18.0, macOS 15.0, *)
class ConflictResolver {
    
    /// Simulates a complex merge where we prioritize the most recent embedding 
    /// based on a timestamp, even if the text is newer on another device.
    static func resolveKnowledgeConflict(context: NSManagedObjectContext, objectID: NSManagedObjectID) {
        context.perform {
            guard let snippet = try? context.existingManagedObject(with: objectID) as? KnowledgeSnippet else { return }
            
            // In a real conflict, Core Data's NSMergePolicy handles the property-level merge.
            // However, for AI-specific logic, we manually validate the "Semantic Integrity".
            
            // Let's assume the 'embedding' has a 'lastEmbeddingUpdate' timestamp attribute.
            // This is a 'Versioning' pattern.
            
            let currentEmbeddingTimestamp = snippet.lastEmbeddingUpdate ?? Date.distantPast
            let incomingEmbeddingTimestamp = snippet.incomingEmbeddingTimestamp ?? Date.distantPast
            
            // If the incoming data has an older embedding than what we already have,
            // we revert the embedding to our local version to preserve semantic quality,
            // even if the 'text' was updated by the other device.
            if incomingEmbeddingTimestamp < currentEmbeddingTimestamp {
                print("Conflict Detected: Protecting high-quality embedding from being overwritten by stale data.")
                // Logic to restore the 'best' embedding would go here.
            }
        }
    }
}

// MARK: - Simulated Implementation of the Data Model logic
extension KnowledgeSnippet {
    // These attributes would be defined in the .xcdatamodeld
    // text: String
    // embedding: Data
    // lastEmbeddingUpdate: Date
    // incomingEmbeddingTimestamp: Date (used during the merge process)
    
    func updateContent(text: String, embedding: Data, context: NSManagedObjectContext) {
        context.perform {
            self.text = text
            self.embedding = embedding
            self.lastEmbeddingUpdate = Date()
        }
    }
}

// MARK: - Multi-threaded Conflict Simulation
@available(iOS 18.0, macOS 15.0, *)
func simulateConflict(container: NSPersistentCloudKitContainer) async {
    let mainContext = container.viewContext
    
    // 1. Create initial record on "Device A" (Main Context)
    let snippet = KnowledgeSnippet(context: mainContext)
    snippet.text = "Initial thought."
    snippet.embedding = Data([0x01, 0x02])
    snippet.lastEmbeddingUpdate = Date()
    try? mainContext.save()
    
    let snippetID = snippet.objectID
    
    // 2. Simulate "Device B" (Background Context) updating the EMBEDDING only
    let backgroundContext = container.newBackgroundContext()
    backgroundContext.perform {
        guard let bgSnippet = try? backgroundContext.existingManagedObject(with: snippetID) as? KnowledgeSnippet else { return }
        
        // Device B has a newer, better embedding
        bgSnippet.embedding = Data([0xFF, 0xFF]) 
        bgSnippet.lastEmbeddingUpdate = Date().addingTimeInterval(100) // Future date
        try? backgroundContext.save()
    }
    
    // 3. Simulate "Device A" updating the TEXT only (but with an OLDER embedding timestamp)
    mainContext.perform {
        snippet.text = "Updated text on Device A."
        // Device A's embedding is actually old/stale
        snippet.lastEmbeddingUpdate = Date().addingTimeInterval(-100) 
        try? mainContext.save()
    }
    
    // After sync, the 'lastEmbeddingUpdate' logic ensures the [0xFF, 0xFF] embedding wins.
}
