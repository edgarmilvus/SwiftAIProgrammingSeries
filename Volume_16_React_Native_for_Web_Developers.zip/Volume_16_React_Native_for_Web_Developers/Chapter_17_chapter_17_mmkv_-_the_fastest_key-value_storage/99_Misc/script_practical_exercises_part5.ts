/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// checkpointer/mmkvCheckpointer.ts
import { storage } from '../lib/storage';

// 1. Define the interface (simplified for the exercise)
interface Checkpointer {
  put(threadId: string, checkpointId: string, state: any): Promise<void>;
  get(threadId: string, checkpointId: string): Promise<any>;
}

// 2. Implement the class
export class MMKVCheckpointer implements Checkpointer {
  // TODO: Implement methods.
}

// 3. Graphviz Diagram


::: {style="text-align: center"}
![This diagram illustrates the class structure of `MMKVCheckpointer` implementing the `Checkpointer` interface, with its methods and properties visually mapped out to represent the checkpointing logic for an AI model.](images/b16_c17_s4_diag1.png){width=80% caption="This diagram illustrates the class structure of `MMKVCheckpointer` implementing the `Checkpointer` interface, with its methods and properties visually mapped out to represent the checkpointing logic for an AI model."}
:::


