
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import Accelerate

/// A mock representation of a CoreML model's weights.
struct ModelWeights: Sendable {
    var values: [Float]
}

/// A mock central server that aggregates updates from many clients.
final class CentralAggregator {
    private(set) var globalWeights: [Float]
    private var updateCount: Int = 0
    
    init(initialWeights: [Float]) {
        self.globalWeights = initialWeights
    }
    
    /// Aggregates a new update using a simple moving average.
    func aggregate(update: [Float]) {
        updateCount += 1
        for i in 0..<globalWeights.count {
            // Simple average: NewAvg = OldAvg + (NewVal - OldAvg) / N
            globalWeights[i] += (update[i] - globalWeights[i]) / Float(updateCount)
        }
        print("🏛️ [Aggregator] Global model updated. Total clients: \(updateCount)")
    }
}

/// An actor representing a single user's device performing local training.
actor FederatedClient {
    private let clientId: String
    private var localWeights: ModelWeights
    private let clippingThreshold: Float = 1.0
    
    init(id: String, initialWeights: [Float]) {
        self.clientId = id
        self.localWeights = ModelWeights(values: initialWeights)
    }
    
    /// Simulates the local training process.
    func performLocalTraining(on data: [Float]) async -> [Float] {
        print("📱 [Client \(clientId)] Training on local data...")
        
        // Simulate weight adjustment based on data mean
        let dataMean = data.reduce(0, +) / Float(data.count)
        for i in 0..<localWeights.values.count {
            localWeights.values[i] += dataMean * 0.01 
        }
        
        // 1. Gradient Clipping (Crucial for DP)
        let clippedWeights = clip(weights: localWeights.values, threshold: clippingThreshold)
        
        // 2. Add Gaussian Noise (The Gaussian Mechanism)
        let noisyWeights = applyGaussianNoise(to: clippedWeights, sigma: 0.05)
        
        return noisyWeights
    }
    
    /// Ensures no single update is too large, bounding the sensitivity.
    private func clip(weights: [Float], threshold: Float) -> [Float] {
        let norm = sqrt(weights.reduce(0) { $0 + $1 * $1 })
        if norm > threshold {
            let scale = threshold / norm
            return weights.map { $0 * scale }
        }
        return weights
    }
    
    /// Applies Gaussian noise using the Box-Muller transform.
    private func applyGaussianNoise(to weights: [Float], sigma: Float) -> [Float] {
        return weights.map { w in
            let u1 = Float.random(in: 0...1)
            let u2 = Float.random(in: 0...1)
            let standardNormal = sqrt(-2.0 * log(u1)) * cos(2.0 * .pi * u2)
            return w + (Float(sigma) * standardNormal)
        }
    }
}

// MARK: - Simulation Execution
@main
struct FederatedLearningApp {
    static func main() async {
        let initialWeights: [Float] = [0.1, -0.2, 0.5, 0.8]
        let aggregator = CentralAggregator(initialWeights: initialWeights)
        
        print("🚀 Starting Federated Learning Simulation...")
        
        // Use a TaskGroup to simulate multiple clients training in parallel
        await withTaskGroup(of: Void.self) { group in
            for i in 1...5 {
                group.addTask {
                    let client = FederatedClient(id: "\(i)", initialWeights: initialWeights)
                    // Simulate unique local data for each client
                    let localData = (0..<10).map { _ in Float.random(in: -1...1) }
                    
                    let update = await client.performLocalTraining(on: localData)
                    
                    // In a real app, this would be a network call.
                    // Here we call the aggregator directly.
                    aggregator.aggregate(update: update)
                }
            }
        }
        
        print("✅ Simulation Complete.")
        print("Final Global Weights: \(aggregator.globalWeights)")
    }
}
