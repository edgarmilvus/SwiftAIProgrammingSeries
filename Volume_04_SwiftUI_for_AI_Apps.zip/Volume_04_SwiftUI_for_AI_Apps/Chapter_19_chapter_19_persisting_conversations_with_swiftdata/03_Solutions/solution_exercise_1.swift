
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import SwiftData
import Foundation

// MARK: - SwiftData Models

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Conversation {
    var id: UUID
    var title: String
    var creationDate: Date
    @Relationship(deleteRule: .cascade, inverse: \Message.conversation)
    var messages: [Message]

    init(id: UUID = UUID(), title: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.creationDate = creationDate
        self.messages = []
    }
}

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Message {
    var id: UUID
    var content: String
    var timestamp: Date
    var isFromUser: Bool
    var conversation: Conversation? // Inverse relationship

    init(id: UUID = UUID(), content: String, timestamp: Date = Date(), isFromUser: Bool) {
        self.id = id
        self.content = content
        self.timestamp = timestamp
        self.isFromUser = isFromUser
    }
}

// MARK: - SwiftUI Views

@available(iOS 18.0, macOS 15.0, *)
struct NewConversationView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @State private var newConversationTitle: String = ""

    var body: some View {
        NavigationView {
            Form {
                TextField("Conversation Title", text: $newConversationTitle)
                Button("Create Conversation") {
                    guard !newConversationTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                    let newConversation = Conversation(title: newConversationTitle)
                    modelContext.insert(newConversation)
                    dismiss()
                }
                .disabled(newConversationTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .navigationTitle("New Conversation")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ChatView: View { // This will become ConversationDetailView in Ex2
    @Environment(\.modelContext) private var modelContext
    let conversation: Conversation
    @State private var newMessageContent: String = ""

    var body: some View {
        VStack {
            // Placeholder for messages, will be implemented fully in Ex2
            Text("Messages for: \(conversation.title)")
                .font(.headline)
            Spacer()

            HStack {
                TextField("Type a message...", text: $newMessageContent)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    guard !newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                    let message = Message(content: newMessageContent, isFromUser: true)
                    conversation.messages.append(message) // SwiftData automatically manages relationship
                    modelContext.insert(message) // Explicitly insert message
                    newMessageContent = ""
                }
                .disabled(newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding()
        }
        .navigationTitle(conversation.title)
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \.creationDate, order: .reverse) private var conversations: [Conversation]
    @State private var showingNewConversationSheet = false

    var body: some View {
        NavigationStack {
            List {
                ForEach(conversations) { conversation in
                    NavigationLink(destination: ChatView(conversation: conversation)) {
                        Text(conversation.title)
                    }
                }
                if conversations.isEmpty {
                    ContentUnavailableView("No Conversations", systemImage: "bubble.left.and.bubble.right.fill", description: Text("Start a new chat to see it appear here."))
                }
            }
            .navigationTitle("AI Chats")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingNewConversationSheet = true
                    } label: {
                        Label("New Conversation", systemImage: "plus.circle.fill")
                    }
                }
            }
            .sheet(isPresented: $showingNewConversationSheet) {
                NewConversationView()
            }
        }
    }
}

// MARK: - App Entry Point

@available(iOS 18.0, macOS 15.0, *)
@main
struct AIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [Conversation.self, Message.self])
    }
}
