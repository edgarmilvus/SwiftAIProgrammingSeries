/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// profileStore.ts
import { create } from 'zustand';

// 1. Define Discriminated Unions for Type Safety
type ProfileStatus = 'idle' | 'loading' | 'success' | 'error';

interface ProfileData {
  name: string;
  email: string;
  avatar: string;
}

interface ProfileState {
  data: ProfileData | null;
  status: ProfileStatus;
  error: string | null;
  fetchProfile: () => Promise<void>;
}

// 2. Create the Async Store
export const useProfileStore = create<ProfileState>((set) => ({
  data: null,
  status: 'idle',
  error: null,

  fetchProfile: async () => {
    set({ status: 'loading', error: null });

    // Simulate 2-second network delay
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Random outcome simulation (80% success, 20% error)
    const isSuccess = Math.random() > 0.2;

    if (isSuccess) {
      set({
        status: 'success',
        data: {
          name: 'Jane Doe',
          email: 'jane@example.com',
          avatar: 'https://i.pravatar.cc/150?img=32',
        },
      });
    } else {
      set({
        status: 'error',
        error: 'Failed to fetch profile data. Please try again.',
      });
    }
  },
}));

// 3. UI State Selector (Derived State)
export const useProfileUIState = () => {
  const { status } = useProfileStore();
  
  // Map status to component names
  switch (status) {
    case 'loading':
      return { component: 'LoadingSpinner' as const };
    case 'success':
      return { component: 'ProfileCard' as const };
    case 'error':
      return { component: 'ErrorDisplay' as const };
    case 'idle':
    default:
      return { component: 'InitialPrompt' as const };
  }
};

// ProfileScreen.tsx
import React, { useEffect } from 'react';
import { View, Text, Button, Image, ActivityIndicator } from 'react-native';
import { useProfileStore, useProfileUIState } from './profileStore';

// Placeholder Components
const LoadingSpinner = () => <ActivityIndicator size="large" color="#0000ff" />;
const InitialPrompt = () => <Text>Press button to load profile</Text>;
const ErrorDisplay = () => {
  const error = useProfileStore((state) => state.error);
  return <Text style={{ color: 'red' }}>Error: {error}</Text>;
};
const ProfileCard = () => {
  const data = useProfileStore((state) => state.data);
  if (!data) return null;
  return (
    <View>
      <Image source={{ uri: data.avatar }} style={{ width: 100, height: 100, borderRadius: 50 }} />
      <Text>Name: {data.name}</Text>
      <Text>Email: {data.email}</Text>
    </View>
  );
};

// Main Component
export const ProfileScreen = () => {
  const { fetchProfile } = useProfileStore();
  const { component } = useProfileUIState();

  // Render based on UI State Selector
  const renderContent = () => {
    switch (component) {
      case 'LoadingSpinner': return <LoadingSpinner />;
      case 'ProfileCard': return <ProfileCard />;
      case 'ErrorDisplay': return <ErrorDisplay />;
      case 'InitialPrompt': return <InitialPrompt />;
      default: return null;
    }
  };

  return (
    <View style={{ padding: 20, alignItems: 'center' }}>
      {renderContent()}
      <View style={{ marginTop: 20 }}>
        <Button title="Fetch Profile" onPress={fetchProfile} disabled={component === 'LoadingSpinner'} />
      </View>
    </View>
  );
};
