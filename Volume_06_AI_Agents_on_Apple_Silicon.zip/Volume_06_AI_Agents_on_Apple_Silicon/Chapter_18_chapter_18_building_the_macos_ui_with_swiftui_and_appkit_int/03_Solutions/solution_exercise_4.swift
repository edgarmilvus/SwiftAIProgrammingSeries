
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AppKit

// MARK: - 1. Custom AppKit NSView for Visualization

// Protocol for ActivationPatternView delegate to communicate selection events
protocol ActivationPatternViewDelegate: AnyObject {
    func activationPatternView(_ view: ActivationPatternView, didSelectIndex index: Int?)
}

class ActivationPatternView: NSView {
    var activationData: [Double] = [] {
        didSet {
            // Trigger redraw when data changes
            needsDisplay = true
        }
    }

    var selectedIndex: Int? {
        didSet {
            // Trigger redraw when selection changes to highlight
            needsDisplay = true
        }
    }

    weak var delegate: ActivationPatternViewDelegate?

    init() {
        super.init(frame: .zero)
        self.wantsLayer = true // Enable layer-backed view for smoother drawing
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)

        guard !activationData.isEmpty else { return }

        // Clear background
        NSColor.windowBackgroundColor.setFill()
        dirtyRect.fill()

        let barWidth = bounds.width / CGFloat(activationData.count)
        let maxActivation = activationData.max() ?? 1.0 // Prevent division by zero

        for (index, activation) in activationData.enumerated() {
            let barHeight = (activation / maxActivation) * bounds.height
            let x = CGFloat(index) * barWidth
            let y = bounds.height - barHeight // Draw from bottom up

            let barRect = NSRect(x: x, y: y, width: barWidth, height: barHeight)

            // Choose color based on activation value
            let color = NSColor(red: CGFloat(activation), green: 1.0 - CGFloat(activation), blue: 0.2, alpha: 1.0)
            color.setFill()
            
            // Highlight if selected
            if index == selectedIndex {
                NSColor.systemBlue.withAlphaComponent(0.6).setFill()
            }
            
            barRect.fill()

            // Draw a thin border for each bar
            NSColor.darkGray.setStroke()
            barRect.frame()
        }
    }

    // MARK: - User Interaction
    override func mouseDown(with event: NSEvent) {
        let locationInView = convert(event.locationInWindow, from: nil)
        
        guard !activationData.isEmpty else { return }

        let barWidth = bounds.width / CGFloat(activationData.count)
        let clickedIndex = Int(locationInView.x / barWidth)
        
        // Ensure clickedIndex is within bounds
        if clickedIndex >= 0 && clickedIndex < activationData.count {
            selectedIndex = clickedIndex
            delegate?.activationPatternView(self, didSelectIndex: selectedIndex)
        } else {
            selectedIndex = nil
            delegate?.activationPatternView(self, didSelectIndex: nil)
        }
    }
}

// MARK: - 2. NSViewRepresentable with Coordinator

struct ActivationPatternRepresentable: NSViewRepresentable {
    @Binding var data: [Double]
    @Binding var selectedIndex: Int?

    func makeNSView(context: Context) -> ActivationPatternView {
        let view = ActivationPatternView()
        view.delegate = context.coordinator // Set the coordinator as the delegate
        view.activationData = data // Set initial data
        view.selectedIndex = selectedIndex // Set initial selection
        return view
    }

    func updateNSView(_ nsView: ActivationPatternView, context: Context) {
        // Update data if it changes from SwiftUI
        if nsView.activationData != data {
            nsView.activationData = data
        }
        // Update selection if it changes from SwiftUI
        if nsView.selectedIndex != selectedIndex {
            nsView.selectedIndex = selectedIndex
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    class Coordinator: NSObject, ActivationPatternViewDelegate {
        var parent: ActivationPatternRepresentable

        init(parent: ActivationPatternRepresentable) {
            self.parent = parent
        }

        // Delegate method to update SwiftUI binding when selection changes in AppKit view
        func activationPatternView(_ view: ActivationPatternView, didSelectIndex index: Int?) {
            parent.selectedIndex = index
        }
    }
}

// MARK: - 3. SwiftUI Integration

struct Exercise4View: View {
    @State private var activationValues: [Double] = [0.1, 0.5, 0.8, 0.3, 0.9, 0.6, 0.2, 0.7]
    @State private var selectedVizIndex: Int? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("AI Activation Pattern Visualization")
                .font(.headline)
                .padding(.bottom, 5)

            ActivationPatternRepresentable(data: $activationValues, selectedIndex: $selectedVizIndex)
                .frame(minWidth: 400, idealWidth: 600, minHeight: 150, idealHeight: 200)
                .border(Color.gray.opacity(0.5), width: 1) // Visual border for the AppKit view

            Text("Selected Activation Index: \(selectedVizIndex.map { String($0) } ?? "None")")
                .font(.subheadline)
                .padding(.top, 10)

            HStack {
                Button("Randomize Data") {
                    activationValues = (0..<Int.random(in: 5...15)).map { _ in Double.random(in: 0.1...1.0) }
                    selectedVizIndex = nil // Reset selection when data changes
                }
                .buttonStyle(.borderedProminent)

                Button("Clear Selection") {
                    selectedVizIndex = nil
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .navigationTitle("Exercise 4")
    }
}

// To run this in a preview or an actual app:
// @main
// struct AppKitSwiftUIApp: App {
//     var body: some Scene {
//         WindowGroup {
//             Exercise4View()
//         }
//     }
// }
