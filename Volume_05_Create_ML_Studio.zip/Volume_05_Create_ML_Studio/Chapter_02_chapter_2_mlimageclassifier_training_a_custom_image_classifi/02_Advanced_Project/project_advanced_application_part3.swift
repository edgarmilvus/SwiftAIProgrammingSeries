
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import CoreML
import Vision
import Photos
import UIKit // For UIImage and CVPixelBuffer conversion

/// Manages the loading of a custom image classification model and the
/// asynchronous classification of a batch of photos.
@available(iOS 15.0, *) // async/await requires iOS 15.0 or later
class SmartPhotoOrganizer: ObservableObject {
    /// The Core ML model instance, loaded dynamically.
    private var imageClassifier: VNCoreMLModel?

    /// Published property to inform SwiftUI views about classification progress.
    @Published var classificationResults: [PhotoClassificationResult] = []

    /// Published property for loading state.
    @Published var isLoading: Bool = false

    /// Published property for error messages.
    @Published var errorMessage: String?

    /// The name of the Core ML model asset bundle.
    private let modelBundleName: String

    /// Initializes the organizer with the name of the Core ML model.
    /// - Parameter modelBundleName: The filename of the .mlmodelc bundle (without extension).
    init(modelBundleName: String = "MyPhotoClassifier") {
        self.modelBundleName = modelBundleName
        // Model loading is asynchronous and can fail, so it's done in a separate method.
    }

    /// Asynchronously loads the Core ML model from the app's bundle.
    /// This method ensures the model is ready before classification begins.
    /// - Throws: `SmartPhotoOrganizerError` if the model cannot be found or loaded.
    func loadModel() async throws {
        // Reset any previous errors
        await MainActor.run { errorMessage = nil }

        guard let modelURL = Bundle.main.url(forResource: modelBundleName, withExtension: "mlmodelc") else {
            let error = SmartPhotoOrganizerError.modelNotFound(name: modelBundleName)
            await MainActor.run { errorMessage = error.localizedDescription }
            throw error
        }

        do {
            // MLModel is the low-level Core ML representation.
            let compiledModel = try MLModel(contentsOf: modelURL)
            // VNCoreMLModel wraps MLModel for Vision framework integration,
            // handling image preprocessing (scaling, cropping, pixel buffer conversion).
            self.imageClassifier = try VNCoreMLModel(for: compiledModel)
            print("Successfully loaded Core ML model: \(modelBundleName)")
        } catch {
            let wrappedError = SmartPhotoOrganizerError.modelLoadingFailed(underlyingError: error)
            await MainActor.run { errorMessage = wrappedError.localizedDescription }
            throw wrappedError
        }
    }

    /// Asynchronously classifies a batch of images using the loaded Core ML model.
    /// This method uses `TaskGroup` to process images concurrently for better performance
    /// and provides progress updates.
    /// - Parameter photos: An array of `ImageInput` objects (e.g., `PHAsset` or `UIImage`).
    func processPhotos(photos: [ImageInput]) async {
        await MainActor.run {
            self.isLoading = true
            self.classificationResults = []
            self.errorMessage = nil
        }

        // Ensure model is loaded before proceeding
        guard let classifier = imageClassifier else {
            await MainActor.run {
                self.errorMessage = SmartPhotoOrganizerError.modelNotLoaded.localizedDescription
                self.isLoading = false
            }
            print("Error: Model not loaded. Call loadModel() first.")
            return
        }

        var results: [PhotoClassificationResult] = []
        let totalPhotos = photos.count

        // Use a TaskGroup to process multiple photos concurrently.
        // This is crucial for performance when dealing with many images.
        await withTaskGroup(of: PhotoClassificationResult?.self) { group in
            for (index, photoInput) in photos.enumerated() {
                group.addTask {
                    do {
                        // Load image data from the input (e.g., PHAsset)
                        guard let imageData = await photoInput.loadImageData(),
                              let image = UIImage(data: imageData) else {
                            print("Warning: Could not load image data for photo \(photoInput.id)")
                            return nil
                        }

                        // Perform classification
                        let result = try await self.classifyImage(image: image, photoID: photoInput.id, classifier: classifier)

                        // Update UI on the main actor for progress feedback
                        await MainActor.run {
                            self.classificationResults.append(result)
                            // Optional: Sort results or update UI in other ways
                            // self.classificationResults.sort { $0.id < $1.id }
                        }
                        return result
                    } catch {
                        print("Error classifying photo \(photoInput.id): \(error.localizedDescription)")
                        // Optionally, report individual photo errors to the UI
                        return nil
                    }
                }
            }

            // Collect all results (even if some failed)
            for await result in group {
                if let result = result {
                    results.append(result)
                }
            }
        }

        await MainActor.run {
            self.isLoading = false
            // Final sorting or processing if needed
            self.classificationResults.sort { $0.id < $1.id }
            print("Classification completed for \(self.classificationResults.count) out of \(totalPhotos) photos.")
        }
    }

    /// Performs the actual image classification using Vision and Core ML.
    /// - Parameters:
    ///   - image: The `UIImage` to classify.
    ///   - photoID: A unique identifier for the photo.
    ///   - classifier: The `VNCoreMLModel` instance to use for prediction.
    /// - Returns: A `PhotoClassificationResult` containing the prediction.
    /// - Throws: `SmartPhotoOrganizerError` if classification fails.
    private func classifyImage(image: UIImage, photoID: String, classifier: VNCoreMLModel) async throws -> PhotoClassificationResult {
        guard let pixelBuffer = image.toCVPixelBuffer() else {
            throw SmartPhotoOrganizerError.imageProcessingFailed(id: photoID, reason: "Could not convert UIImage to CVPixelBuffer.")
        }

        // Create a Vision request for the Core ML model.
        // VNCoreMLRequest handles scaling and cropping of the input image
        // to match the model's expected input size and format.
        let request = VNCoreMLRequest(model: classifier) { request, error in
            // This completion handler is typically for non-async Vision workflows.
            // For async, we await the result of the `perform` call.
        }

        // Set up request options for better performance or specific behavior
        request.imageCropAndScaleOption = .centerCrop // Common for image classification

        // Create a Vision image request handler
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        do {
            try handler.perform([request])

            guard let observations = request.results as? [VNClassificationObservation],
                  let bestObservation = observations.first else {
                throw SmartPhotoOrganizerError.classificationFailed(id: photoID, reason: "No classification observations found.")
            }

            let predictedCategory = bestObservation.identifier
            let confidence = Double(bestObservation.confidence)

            // Generate a thumbnail for UI display (optional)
            let thumbnailData: Data?
            if let thumbnailImage = image.resized(to: CGSize(width: 100, height: 100)),
               let data = thumbnailImage.jpegData(compressionQuality: 0.8) {
                thumbnailData = data
            } else {
                thumbnailData = nil
            }

            return PhotoClassificationResult(
                id: photoID,
                predictedCategory: predictedCategory,
                confidence: confidence,
                thumbnailData: thumbnailData
            )
        } catch {
            throw SmartPhotoOrganizerError.classificationFailed(id: photoID, reason: "Vision request failed: \(error.localizedDescription)")
        }
    }
}
