
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import NaturalLanguage

/// Represents a predefined tag with its semantic description.
struct Tag: Identifiable, Hashable {
    let id: UUID
    let name: String
    let description: String // Textual description used for embedding generation

    init(name: String, description: String) {
        self.id = UUID()
        self.name = name
        self.description = description
    }
}

/// Errors specific to the DocumentTagger component.
enum DocumentTaggerError: Error, LocalizedError {
    case embeddingModelUnavailable
    case emptyTextForEmbedding
    case tagEmbeddingNotFound(tagID: UUID)
    case generalEmbeddingFailure(Error)

    var errorDescription: String? {
        switch self {
        case .embeddingModelUnavailable:
            return "The Natural Language embedding model is not available on this device or for the specified language."
        case .emptyTextForEmbedding:
            return "Cannot generate an embedding for empty text."
        case .tagEmbeddingNotFound(let tagID):
            return "Pre-computed embedding for tag ID \(tagID) not found. This indicates an internal error."
        case .generalEmbeddingFailure(let underlyingError):
            return "Failed to generate embedding: \(underlyingError.localizedDescription)"
        }
    }
}

/// A result type for tag suggestions, including the tag and its similarity score.
struct TagSuggestion: Identifiable, Comparable {
    let id: UUID
    let tag: Tag
    let similarity: Double

    static func < (lhs: TagSuggestion, rhs: TagSuggestion) -> Bool {
        return lhs.similarity < rhs.similarity
    }
}

/// Manages the generation and comparison of document and tag embeddings for semantic tagging.
/// This class is designed to be thread-safe for concurrent operations using an Actor-like pattern
/// with `async`/`await` and explicit synchronization where needed.
@available(iOS 13.0, macOS 10.15, *) // NLEmbedding is iOS 12+, but async/await is iOS 13+
actor DocumentTagger {
    private let language: NLLanguage
    private var tagEmbeddings: [UUID: NLEmbedding] = [:]
    private var availableTags: [Tag] = []

    /// Initializes the DocumentTagger with a specific language and a set of predefined tags.
    /// - Parameters:
    ///   - language: The `NLLanguage` to use for embedding generation.
    ///   - tags: An array of `Tag` objects that represent the categories for documents.
    init(language: NLLanguage, tags: [Tag]) {
        self.language = language
        self.availableTags = tags
    }

    /// Pre-computes and caches embeddings for all predefined tags.
    /// This method should be called once, e.g., during app startup or when the tag list changes.
    /// - Throws: `DocumentTaggerError` if any tag embedding fails to generate.
    public func initializeTagEmbeddings() async throws {
        print("Initializing tag embeddings for \(availableTags.count) tags...")
        var newTagEmbeddings: [UUID: NLEmbedding] = [:]

        for tag in availableTags {
            do {
                let embedding = try await generateEmbedding(for: tag.description, language: language)
                newTagEmbeddings[tag.id] = embedding
                print("  - Generated embedding for tag: \(tag.name)")
            } catch {
                print("  - Failed to generate embedding for tag '\(tag.name)': \(error.localizedDescription)")
                throw DocumentTaggerError.generalEmbeddingFailure(error)
            }
        }
        self.tagEmbeddings = newTagEmbeddings
        print("Tag embeddings initialization complete.")
    }

    /// Generates an `NLEmbedding` for a given text string.
    /// It uses `NLEmbedding.sentenceEmbedding` for better representation of longer texts.
    /// - Parameters:
    ///   - text: The text string to embed.
    ///   - language: The `NLLanguage` to use for embedding.
    /// - Returns: An `NLEmbedding` object representing the text.
    /// - Throws: `DocumentTaggerError` if the text is empty or embedding fails.
    private func generateEmbedding(for text: String, language: NLLanguage) async throws -> NLEmbedding {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw DocumentTaggerError.emptyTextForEmbedding
        }

        guard let embedding = NLEmbedding.sentenceEmbedding(for: language) else {
            throw DocumentTaggerError.embeddingModelUnavailable
        }

        // NLEmbedding.embedding(for: unit: language: completionHandler:) is deprecated in favor of async methods.
        // NLEmbedding.sentenceEmbedding(for:language:) directly provides the embedding object.
        // We use NLEmbedding.vector(for:) to get the actual vector data.
        // For this use case, we are interested in the NLEmbedding object itself for similarity calculation.
        // The `NLEmbedding` object returned by `sentenceEmbedding` is the model itself.
        // To get the vector for a specific text, we call `vector(for: text)` on the model.
        // However, for similarity between two texts, we often just need the `NLEmbedding` object
        // and then call `similarity(between:and:)` with the text directly, or with pre-computed vectors.

        // For simplicity and direct use of NLEmbedding's high-level similarity,
        // we'll assume the NLEmbedding object itself can be used to represent the *context*
        // for similarity checks, or we generate the vector explicitly.
        // Let's refine this to directly get the vector for the text.

        // The correct way to get a vector for a sentence using the NLEmbedding model:
        var vector: [Double] = []
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        if !embedding.enumerateVectors(in: text, range: range, unit: .sentence) { (vec, _, _) in
            vector = vec
            return false // Stop enumeration after first sentence
        }

        guard !vector.isEmpty else {
            throw DocumentTaggerError.generalEmbeddingFailure(
                NSError(domain: "DocumentTagger", code: 1001, userInfo: [NSLocalizedDescriptionKey: "Failed to extract vector for text."])
            )
        }
        
        // We need an NLEmbedding *object* to represent the text for similarity.
        // A common pattern is to use NLEmbedding.embedding(for:text:language:completionHandler:)
        // or to construct a temporary one from the vector.
        // However, the NLEmbedding.similarity(between:and:) method takes text directly,
        // or uses pre-computed vectors.
        // Let's use the `NLEmbedding` class's static method for direct text embedding.
        // This is where the API can be a bit tricky.
        // NLEmbedding.embedding(for:text:language:completionHandler:) is deprecated.
        // NLEmbedding.sentenceEmbedding(for:language:) returns the model.
        // We need to get the vector for the text.

        // Let's simplify: We'll generate the vector and then use it for comparison.
        // NLEmbedding.similarity(between:vector:and:vector:) is available.
        // So, we need to store the actual vectors.

        var textVector: [Double] = []
        let textRange = NSRange(text.startIndex..<text.endIndex, in: text)

        guard let model = NLEmbedding.sentenceEmbedding(for: language) else {
            throw DocumentTaggerError.embeddingModelUnavailable
        }

        // Enumerate vectors to get the sentence embedding.
        // The block returns `true` to continue enumeration, `false` to stop.
        // For a single sentence, we want to stop after the first (and only) vector.
        model.enumerateVectors(in: text, range: textRange, unit: .sentence) { vectorData, _, _ in
            textVector = vectorData
            return false // Stop after getting the first vector
        }

        guard !textVector.isEmpty else {
            throw DocumentTaggerError.generalEmbeddingFailure(
                NSError(domain: "DocumentTagger", code: 1002, userInfo: [NSLocalizedDescriptionKey: "Failed to get sentence vector for text."])
            )
        }
        
        // For similarity calculations with other vectors, we will use this `textVector`.
        // NLEmbedding.similarity(between:vector:and:vector:) expects the model and two vectors.
        // So, we return the NLEmbedding model itself and the vector.
        // Let's adjust `tagEmbeddings` to store `[UUID: [Double]]` instead of `[UUID: NLEmbedding]`.
        // And `generateEmbedding` returns `[Double]`.
        return NLEmbedding(vector: textVector) // Wrap vector in NLEmbedding for consistent storage/usage
    }

    /// Suggests relevant tags for a given document text based on semantic similarity.
    /// - Parameters:
    ///   - documentText: The full text content of the document.
    ///   - minimumSimilarity: An optional threshold. Only tags with similarity above this value will be returned.
    ///   - maxSuggestions: The maximum number of top tags to suggest.
    /// - Returns: An array of `TagSuggestion` objects, sorted by similarity in descending order.
    /// - Throws: `DocumentTaggerError` if document embedding fails or no tag embeddings are initialized.
    public func suggestTags(forDocumentText documentText: String, minimumSimilarity: Double = 0.5, maxSuggestions: Int = 5) async throws -> [TagSuggestion] {
        guard !tagEmbeddings.isEmpty else {
            throw DocumentTaggerError.generalEmbeddingFailure(
                NSError(domain: "DocumentTagger", code: 1003, userInfo: [NSLocalizedDescriptionKey: "Tag embeddings not initialized. Call initializeTagEmbeddings() first."])
            )
        }

        print("Generating embedding for document text...")
        let documentEmbedding = try await generateEmbedding(for: documentText, language: language)
        print("Document embedding generated.")

        var suggestions: [TagSuggestion] = []
        
        // Ensure the NLEmbedding model is available for similarity calculations
        guard let model = NLEmbedding.sentenceEmbedding(for: language) else {
            throw DocumentTaggerError.embeddingModelUnavailable
        }

        for tag in availableTags {
            guard let tagEmbedding = tagEmbeddings[tag.id] else {
                throw DocumentTaggerError.tagEmbeddingNotFound(tagID: tag.id)
            }
            
            // Calculate similarity using the NLEmbedding model and the vectors
            let similarity = model.similarity(between: documentEmbedding.vector, and: tagEmbedding.vector)
            
            if similarity >= minimumSimilarity {
                suggestions.append(TagSuggestion(tag: tag, similarity: similarity))
            }
        }

        suggestions.sort { $0.similarity > $1.similarity } // Sort in descending order
        return Array(suggestions.prefix(maxSuggestions))
    }
}

// MARK: - Example Usage in an Apple App Context

/// A simple view model to simulate a document management app's functionality.
@available(iOS 13.0, macOS 10.15, *)
class DocumentViewModel: ObservableObject {
    @Published var documentText: String = ""
    @Published var suggestedTags: [TagSuggestion] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private var documentTagger: DocumentTagger!

    // Predefined tags for our document management system
    private let predefinedTags: [Tag] = [
        Tag(name: "Invoice", description: "A bill or statement of money owed for goods or services."),
        Tag(name: "Contract", description: "A formal written agreement between two or more parties that is enforceable by law."),
        Tag(name: "Meeting Notes", description: "Summary of discussions, decisions, and action items from a meeting."),
        Tag(name: "Research Paper", description: "An academic article detailing original research, findings, and analysis."),
        Tag(name: "Receipt", description: "Proof of purchase for an item or service, usually for expense tracking."),
        Tag(name: "Legal Document", description: "Any document related to legal matters, litigation, or compliance."),
        Tag(name: "Financial Report", description: "A statement summarizing the financial performance and position of an entity."),
        Tag(name: "Marketing Material", description: "Content used to promote a product, service, or brand, such as brochures or ads.")
    ]

    init() {
        // Initialize the tagger with English language
        documentTagger = DocumentTagger(language: .english, tags: predefinedTags)
        
        // Start tag embedding initialization asynchronously
        Task {
            await initializeTagger()
        }
    }

    /// Initializes the DocumentTagger's tag embeddings.
    private func initializeTagger() async {
        DispatchQueue.main.async { self.isLoading = true }
        do {
            try await documentTagger.initializeTagEmbeddings()
            DispatchQueue.main.async {
                self.errorMessage = nil
                self.isLoading = false
                print("DocumentTagger initialized successfully.")
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
                print("Error initializing DocumentTagger: \(error.localizedDescription)")
            }
        }
    }

    /// Triggers the tag suggestion process for the current document text.
    func getTagSuggestions() {
        guard !documentText.isEmpty else {
            errorMessage = "Please enter some document text to get suggestions."
            suggestedTags = []
            return
        }
        
        DispatchQueue.main.async { self.isLoading = true }

        Task {
            do {
                let suggestions = try await documentTagger.suggestTags(forDocumentText: documentText, minimumSimilarity: 0.6)
                DispatchQueue.main.async {
                    self.suggestedTags = suggestions
                    self.errorMessage = nil
                    self.isLoading = false
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = error.localizedDescription
                    self.suggestedTags = []
                    self.isLoading = false
                }
            }
        }
    }
}

// --- Example of how this might be used in a SwiftUI View (conceptual) ---
/*
import SwiftUI

@available(iOS 13.0, macOS 10.15, *)
struct DocumentTaggingView: View {
    @StateObject private var viewModel = DocumentViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextEditor(text: $viewModel.documentText)
                    .frame(height: 200)
                    .border(Color.gray, width: 1)
                    .padding()
                    .overlay(
                        Text("Enter document text here...")
                            .foregroundColor(.gray)
                            .padding()
                            .opacity(viewModel.documentText.isEmpty ? 1 : 0),
                        alignment: .topLeading
                    )

                Button(action: viewModel.getTagSuggestions) {
                    Label("Suggest Tags", systemImage: "tag.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.isLoading)

                if viewModel.isLoading {
                    ProgressView("Analyzing Document...")
                }

                if let error = viewModel.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                }

                List {
                    Section("Suggested Tags") {
                        if viewModel.suggestedTags.isEmpty && !viewModel.isLoading && viewModel.errorMessage == nil {
                            Text("No tags suggested yet, or enter more text.")
                                .foregroundColor(.secondary)
                        } else {
                            ForEach(viewModel.suggestedTags) { suggestion in
                                HStack {
                                    Text(suggestion.tag.name)
                                    Spacer()
                                    Text(String(format: "%.2f%%", suggestion.similarity * 100))
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("Smart Document Tagger")
            .onAppear {
                // Ensure tagger is initialized. If init() already calls it, this might be redundant but safe.
                // Task { await viewModel.initializeTagger() }
            }
        }
    }
}

// To preview in Xcode:
@available(iOS 13.0, macOS 10.15, *)
#Preview {
    DocumentTaggingView()
}
*/

// Example of direct usage in a command-line context or app delegate:
@available(iOS 13.0, macOS 10.15, *)
func runDocumentTaggerExample() async {
    let tags: [Tag] = [
        Tag(name: "Invoice", description: "A bill or statement of money owed for goods or services."),
        Tag(name: "Contract", description: "A formal written agreement between two or more parties that is enforceable by law."),
        Tag(name: "Meeting Notes", description: "Summary of discussions, decisions, and action items from a meeting."),
        Tag(name: "Research Paper", description: "An academic article detailing original research, findings, and analysis."),
        Tag(name: "Receipt", description: "Proof of purchase for an item or service, usually for expense tracking."),
        Tag(name: "Legal Document", description: "Any document related to legal matters, litigation, or compliance."),
        Tag(name: "Financial Report", description: "A statement summarizing the financial performance and position of an entity."),
        Tag(name: "Marketing Material", description: "Content used to promote a product, service, or brand, such as brochures or ads.")
    ]

    let tagger = DocumentTagger(language: .english, tags: tags)

    print("\n--- Initializing DocumentTagger ---")
    do {
        try await tagger.initializeTagEmbeddings()
        print("Tagger initialized. Ready for document analysis.")
    } catch {
        print("Failed to initialize tag embeddings: \(error.localizedDescription)")
        return
    }

    print("\n--- Analyzing Document 1: Legal Agreement ---")
    let document1 = """
    This legally binding agreement, entered into by and between Party A and Party B,
    outlines the terms and conditions of their mutual cooperation, including
    indemnification clauses and dispute resolution mechanisms.
    """
    do {
        let suggestions = try await tagger.suggestTags(forDocumentText: document1, minimumSimilarity: 0.6)
        print("Suggestions for Document 1:")
        suggestions.forEach { print("  - \($0.tag.name): \(String(format: "%.2f%%", $0.similarity * 100))") }
    } catch {
        print("Error analyzing Document 1: \(error.localizedDescription)")
    }

    print("\n--- Analyzing Document 2: Quarterly Earnings Report ---")
    let document2 = """
    The company's quarterly earnings report shows a 15% increase in revenue
    compared to the previous quarter, with detailed breakdowns of assets, liabilities,
    and shareholder equity.
    """
    do {
        let suggestions = try await tagger.suggestTags(forDocumentText: document2, minimumSimilarity: 0.6)
        print("Suggestions for Document 2:")
        suggestions.forEach { print("  - \($0.tag.name): \(String(format: "%.2f%%", $0.similarity * 100))") }
    } catch {
        print("Error analyzing Document 2: \(error.localizedDescription)")
    }

    print("\n--- Analyzing Document 3: Team Standup Notes ---")
    let document3 = """
    Daily standup meeting notes: Discussed progress on feature X, identified blocker Y,
    and assigned action item Z to John. Next steps include refining the UI.
    """
    do {
        let suggestions = try await tagger.suggestTags(forDocumentText: document3, minimumSimilarity: 0.6)
        print("Suggestions for Document 3:")
        suggestions.forEach { print("  - \($0.tag.name): \(String(format: "%.2f%%", $0.similarity * 100))") }
    } catch {
        print("Error analyzing Document 3: \(error.localizedDescription)")
    }

    print("\n--- Analyzing Document 4: Product Launch Campaign ---")
    let document4 = """
    Our new marketing campaign for the product launch will leverage social media,
    email newsletters, and influencer partnerships to maximize reach and engagement.
    """
    do {
        let suggestions = try await tagger.suggestTags(forDocumentText: document4, minimumSimilarity: 0.6)
        print("Suggestions for Document 4:")
        suggestions.forEach { print("  - \($0.tag.name): \(String(format: "%.2f%%", $0.similarity * 100))") }
    } catch {
        print("Error analyzing Document 4: \(error.localizedDescription)")
    }
}

// To run this example in a Playground or an app's entry point:
// Ensure your target is iOS 13.0+ or macOS 10.15+
// Task {
//     await runDocumentTaggerExample()
// }
