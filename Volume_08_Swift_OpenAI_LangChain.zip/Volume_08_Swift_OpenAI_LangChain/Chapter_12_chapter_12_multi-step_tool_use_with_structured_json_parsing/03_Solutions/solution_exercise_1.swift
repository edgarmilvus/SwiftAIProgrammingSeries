
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Represents the possible actions the LLM can request.
enum CalendarTool: Decodable, Sendable {
    case createEvent(title: String, startDate: Date, durationMinutes: Int)
    case deleteEvent(eventID: UUID)

    enum CodingKeys: String, CodingKey {
        case name, arguments
    }

    // Internal struct to decode the nested 'arguments' string
    private struct ArgumentsWrapper: Decodable {
        let title: String?
        let startDate: Date?
        let durationMinutes: Int?
        let eventID: UUID?
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let name = try container.decode(String.self, forKey: .name)
        let argumentsString = try container.decode(String.self, forKey: .arguments)
        
        // Convert the stringified JSON arguments into Data
        guard let argumentsData = argumentsString.data(using: .utf8) else {
            throw DecodingError.dataCorruptedError(forKey: .arguments, in: container, debugDescription: "Invalid string encoding")
        }

        // Configure decoder for the nested arguments
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601 // Critical for LLM interoperability
        
        let args = try decoder.decode(ArgumentsWrapper.self, from: argumentsData)

        switch name {
        case "createEvent":
            guard let title = args.title, let start = args.startDate, let duration = args.durationMinutes else {
                throw DecodingError.dataMismatch(String.self, .init(codingPath: [], debugDescription: "Missing createEvent fields"))
            }
            self = .createEvent(title: title, startDate: start, durationMinutes: duration)
        case "deleteEvent":
            guard let id = args.eventID else {
                throw DecodingError.dataMismatch(UUID.self, .init(codingPath: [], debugDescription: "Missing eventID"))
            }
            self = .deleteEvent(eventID: id)
        default:
            throw DecodingError.dataCorruptedError(forKey: .name, in: container, debugDescription: "Unknown tool name: \(name)")
        }
    }
}

/// An actor to ensure thread-safe parsing of tool calls.
actor ToolParser {
    private let decoder: JSONDecoder

    init() {
        self.decoder = JSONDecoder()
        // Handle various ISO8601 formats common in LLM outputs
        self.decoder.dateDecodingStrategy = .iso8601
    }

    /// Parses a raw JSON payload into a CalendarTool.
    func parse(jsonString: String) throws -> CalendarTool {
        guard let data = jsonString.data(using: .utf8) else {
            throw NSError(domain: "ToolParser", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid string encoding"])
        }
        return try decoder.decode(CalendarTool.self, from: data)
    }
}

// --- Testing the Implementation ---
@main
struct ToolDispatcherApp {
    static func main() async {
        let parser = ToolParser()
        
        // Case 1: Valid JSON
        let validJSON = """
        {
            "name": "createEvent",
            "arguments": "{\\"title\\": \\"Sync Meeting\\", \\"startDate\\": \\"2025-10-01T10:00:00Z\\", \\"durationMinutes\\": 30}"
        }
        """
        
        // Case 2: Malformed JSON (Missing field)
        let malformedJSON = """
        {
            "name": "createEvent",
            "arguments": "{\\"title\\": \\"Broken Event\\"}"
        }
        """

        do {
            let tool = try await parser.parse(jsonString: validJSON)
            print("✅ Success: \(tool)")
        } catch {
            print("❌ Error: \(error)")
        }

        do {
            _ = try await parser.parse(jsonString: malformedJSON)
        } catch {
            print("✅ Caught Expected Error: \(error)")
        }
    }
}
