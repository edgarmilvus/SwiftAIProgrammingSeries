
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import PDFKit
import NaturalLanguage

// MARK: - Models

/// Represents a single piece of text extracted from a document, 
/// paired with its mathematical representation.
/// Conforming to `Sendable` allows this to be passed safely between concurrency domains.
struct DocumentChunk: Sendable, Identifiable {
    let id: UUID
    let text: String
    let embedding: [Float]
    let metadata: [String: String]
    
    init(id: UUID = UUID(), text: String, embedding: [Float], metadata: [String: String] = [:]) {
        self.id = id
        self.text = text
        self.embedding = embedding
        self.metadata = metadata
    }
}

/// Errors specific to the PDF Ingestion process.
enum IngestionError: Error, LocalizedError {
    case fileNotFound
    case pdfProcessingFailed
    case embeddingGenerationFailed
    case emptyDocument
    
    var errorDescription: String? {
        switch self {
        case .fileNotFound: return "The specified PDF file could not be located."
        case .pdfProcessingFailed: return "Failed to extract text from the PDF."
        case .embeddingGenerationFailed: return "The embedding model failed to process the text."
        case .emptyDocument: return "The document contains no extractable text."
        }
    }
}

// MARK: - Protocols

/// Defines the requirement for an embedding provider. 
/// This allows us to swap between OpenAI (Remote) and Apple's NaturalLanguage (Local).
protocol EmbeddingProvider: Sendable {
    /// Generates a vector representation for a given string.
    func generateEmbedding(for text: String) async throws -> [Float]
}

// MARK: - Services

/// A mock implementation of an embedding provider for demonstration purposes.
/// In a real app, this would call the OpenAI API.
final class MockOpenAIEmbeddingProvider: EmbeddingProvider, @unchecked Sendable {
    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(100))
        
        // In a real scenario, this would be a 1536-dimension vector from OpenAI.
        // We return a dummy vector of 1536 floats.
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}

/// The core engine responsible for the ingestion pipeline.
/// Using an `actor` ensures that if multiple files are being processed, 
/// the internal state remains thread-safe.
actor PDFIngestionEngine {
    
    private let embeddingProvider: any EmbeddingProvider
    private let chunkSize: Int
    private let chunkOverlap: Int
    
    /// Initializes the engine.
    /// - Parameters:
    ///   - embeddingProvider: The service used to turn text into vectors.
    ///   - chunkSize: The maximum number of characters per chunk.
    ///   - chunkOverlap: The number of characters to overlap between adjacent chunks.
    init(
        embeddingProvider: any EmbeddingProvider,
        chunkSize: Int = 1000,
        chunkOverlap: Int = 200
    ) {
        self.embeddingProvider = embeddingProvider
        self.chunkSize = chunkSize
        self.chunkOverlap = chunkOverlap
    }
    
    /// The primary entry point for processing a PDF.
    /// - Parameter url: The local file URL of the PDF.
    /// - Returns: An array of processed `DocumentChunk` objects.
    @available(iOS 18.0, macOS 15.0, *)
    func processPDF(at url: URL) async throws -> [DocumentChunk] {
        // 1. Ingestion: Load the PDF
        guard let document = PDFDocument(url: url) else {
            throw IngestionError.fileNotFound
        }
        
        let totalPages = document.pageCount
        guard totalPages > 0 else { throw IngestionError.emptyDocument }
        
        print("Starting ingestion for \(totalPages) pages...")
        
        // 2. Extraction: Convert PDF pages to raw text
        var fullText = ""
        for i in 0..<totalPages {
            if let page = document.page(at: i) {
                fullText += page.string ?? "" + "\n"
            }
        }
        
        guard !fullText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw IngestionError.emptyDocument
        }
        
        // 3. Chunking: Split text into overlapping segments
        let chunks = performChunking(on: fullText)
        print("Created \(chunks.count) text chunks. Starting embedding generation...")
        
        // 4. Embedding: Convert chunks to vectors using structured concurrency
        return try await generateEmbeddings(for: chunks)
    }
    
    /// Implements a sliding window chunking algorithm.
    /// This is crucial for maintaining context between chunks.
    private func performChunking(on text: String) -> [String] {
        var chunks: [String] = []
        let textLength = text.count
        var currentIndex = 0
        
        while currentIndex < textLength {
            let remainingLength = textLength - currentIndex
            let currentChunkSize = min(chunkSize, remainingLength)
            
            let start = text.index(text.startIndex, offsetBy: currentIndex)
            let end = text.index(start, offsetBy: currentChunkSize)
            let chunk = String(text[start..<end])
            
            chunks.append(chunk)
            
            // Move the index forward, but subtract the overlap to create the sliding window
            currentIndex += (chunkSize - chunkOverlap)
            
            // Safety break to prevent infinite loops if overlap >= chunkSize
            if chunkOverlap >= chunkSize { break }
        }
        
        return chunks
    }
    
    /// Uses a TaskGroup to parallelize the embedding generation process.
    /// This significantly speeds up ingestion on multi-core Apple Silicon.
    private func generateEmbeddings(for textChunks: [String]) async throws -> [DocumentChunk] {
        try await withThrowingTaskGroup(of: DocumentChunk.self) { group in
            for text in textChunks {
                group.addTask {
                    // Each task generates an embedding for one chunk
                    let vector = try await self.embeddingProvider.generateEmbedding(for: text)
                    return DocumentChunk(text: text, embedding: vector)
                }
            }
            
            var results: [DocumentChunk] = []
            for try await chunk in group {
                results.append(chunk)
            }
            
            // Note: TaskGroup does not guarantee order. 
            // In a real RAG app, you might want to sort them by a sequence ID.
            return results
        }
    }
}

// MARK: - Usage Example (App Context)

@MainActor
class DocumentScannerViewModel: ObservableObject {
    @Published var isProcessing = false
    @Published var statusMessage = "Ready"
    @Published var processedChunks: [DocumentChunk] = []
    
    private let engine: PDFIngestionEngine
    
    init() {
        // In a real app, this would be your OpenAI service
        let provider = MockOpenAIEmbeddingProvider()
        self.engine = PDFIngestionEngine(embeddingProvider: provider)
    }
    
    func scanDocument(at url: URL) {
        isProcessing = true
        statusMessage = "Ingesting PDF..."
        
        Task {
            do {
                let chunks = try await engine.processPDF(at: url)
                self.processedChunks = chunks
                self.statusMessage = "Successfully processed \(chunks.count) chunks."
            } catch {
                self.statusMessage = "Error: \(error.localizedDescription)"
            }
            isProcessing = false
        }
    }
}
