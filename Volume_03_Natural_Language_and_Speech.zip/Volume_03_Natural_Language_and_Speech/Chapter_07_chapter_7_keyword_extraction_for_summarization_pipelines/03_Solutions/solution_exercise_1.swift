
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import NaturalLanguage
import Foundation // For String.lowercased()

@available(iOS 18.0, macOS 15.0, *)
struct KeywordExtractor {
    // A basic set of stop words. In a real application, this would be much more comprehensive.
    private let stopWords: Set<String> = [
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "and", "or", "but", "for", "nor", "so", "yet",
        "in", "on", "at", "by", "with", "from", "of", "to", "into", "onto",
        "this", "that", "these", "those", "it", "its", "he", "him", "his", "she", "her", "hers",
        "we", "us", "our", "ours", "you", "your", "yours", "they", "them", "their", "theirs",
        "i", "me", "my", "mine", "what", "which", "who", "whom", "whose", "where", "when", "why", "how",
        "am", "can", "will", "would", "should", "could", "may", "might", "must",
        "do", "does", "did", "don't", "doesn't", "didn't",
        "have", "has", "had", "not", "no", "yes", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such",
        "only", "own", "same", "so", "than", "too", "very", "s", "t", "can't", "will", "just", "don't", "shouldn't", "now", "d", "ll", "m", "o", "re", "ve", "y", "ain", "aren", "couldn", "didn", "doesn", "hadn", "hasn", "haven", "isn", "ma", "mightn", "mustn", "needn", "shan", "shouldn", "wasn", "weren", "won", "wouldn"
    ]

    func extractTopKeywords(from text: String, count: Int = 5) -> [String] {
        let tagger = NLTagger(tagSchemes: [.lexicalClass])
        tagger.string = text
        
        var wordFrequencies: [String: Int] = [:]
        
        // Iterate through tokens (words) in the text
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation, .omitOther]) { tag, tokenRange in
            guard let tag = tag else { return true } // Ensure tag exists
            
            let word = String(text[tokenRange])
            let lowercasedWord = word.lowercased()
            
            // 1. Filter out stop words
            if stopWords.contains(lowercasedWord) {
                return true // Continue to next token
            }
            
            // 2. Filter for specific lexical classes: nouns and proper nouns
            if tag == .noun || tag == .properNoun {
                wordFrequencies[lowercasedWord, default: 0] += 1
            }
            
            return true // Continue enumeration
        }
        
        // Sort keywords by frequency (descending) then alphabetically (ascending) for ties
        let sortedKeywords = wordFrequencies.sorted { (entry1, entry2) -> Bool in
            if entry1.value != entry2.value {
                return entry1.value > entry2.value // Higher frequency first
            } else {
                return entry1.key < entry2.key // Alphabetical for ties
            }
        }
        
        // Select the top 'count' keywords
        let topKeywords = sortedKeywords.prefix(count).map { $0.key }
        
        return topKeywords
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func runExercise1() {
    let extractor = KeywordExtractor()
    let text = "Apple's new iPhone 16 features a powerful A18 chip. The iPhone has improved camera capabilities and a longer battery life. Many users are excited about the new iPhone."
    let keywords = extractor.extractTopKeywords(from: text)
    print("Exercise 1 Keywords: \(keywords)")
    // Expected Output (order might vary slightly based on tie-breaking, but content should be similar):
    // ["iphone", "apple", "chip", "camera", "users"]
}

// Uncomment to run the example in a playground or app
// runExercise1()
