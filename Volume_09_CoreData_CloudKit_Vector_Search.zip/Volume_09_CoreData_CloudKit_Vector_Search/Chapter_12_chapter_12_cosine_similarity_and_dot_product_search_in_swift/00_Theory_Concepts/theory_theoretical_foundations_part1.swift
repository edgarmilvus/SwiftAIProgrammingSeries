
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Accelerate

@available(iOS 18.0, *)
/// A thread-safe container for managing high-dimensional embeddings.
actor SemanticVectorStore {
    
    /// Represents a single semantic entry in our database.
    struct EmbeddingEntry: Sendable, Identifiable {
        let id: UUID
        let vector: [Float]
        let metadata: String
    }
    
    private var entries: [EmbeddingEntry] = []
    
    /// Adds a new embedding to the store.
    func insert(_ entry: EmbeddingEntry) {
        entries.append(entry)
    }
    
    /// Performs a Cosine Similarity search.
    /// - Parameter query: The embedding vector to search for.
    /// - Returns: The most similar entry found.
    func findNearest(to query: [Float]) async -> EmbeddingEntry? {
        // We perform the heavy math in a detached task or 
        // via the actor's execution context to avoid blocking.
        return entries.map { entry in
            let similarity = cosineSimilarity(query, entry.vector)
            return (entry, similarity)
        }
        .max(by: { $0.1 < $1.1 })?
        .0
    }
    
    /// Mathematical implementation using Apple's Accelerate framework.
    /// This is the 'Under the Hood' optimization.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        
        // 1. Calculate Dot Product: A · B
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        // 2. Calculate Magnitudes: ||A|| and ||B||
        var magnitudeA: Float = 0
        var magnitudeB: Float = 0
        vDSP_svesq(a, 1, &magnitudeA, vDSP_Length(a.count))
        vDSP_svesq(b, 1, &magnitudeB, vDSP_Length(b.count))
        
        magnitudeA = sqrt(magnitudeA)
        magnitudeB = sqrt(magnitudeB)
        
        // 3. Final Cosine Calculation
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0 }
        return dotProduct / (magnitudeA * magnitudeB)
    }
}
