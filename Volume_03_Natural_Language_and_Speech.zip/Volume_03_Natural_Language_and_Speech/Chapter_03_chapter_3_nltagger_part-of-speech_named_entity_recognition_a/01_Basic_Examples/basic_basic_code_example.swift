
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage

// Ensure the code is available on a suitable iOS/macOS version.
// NLTagger is available from iOS 12.0, macOS 10.14.
// This example uses fundamental NLTagger features.

/// A utility class for performing basic natural language processing
/// tasks like Part-of-Speech tagging, Named Entity Recognition, and Lemmatization
/// using Apple's NLTagger framework.
class JournalEntryAnalyzer {

    /// Analyzes a given text to extract tokens, their part-of-speech,
    /// named entity type, and lemma.
    /// - Parameter text: The input string to be analyzed.
    func analyze(text: String) {
        print("--- Analyzing Journal Entry ---")
        print("Original Text: \"\(text)\"\n")

        // 1. Initialize NLTagger with the desired tag schemes.
        // We want to get lexical class (POS), name type (NER), and lemma.
        // NLTagger will automatically detect the dominant language, but we can also set it explicitly.
        let tagger = NLTagger(tagSchemes: [.lexicalClass, .nameType, .lemma])

        // 2. Set the string to be analyzed.
        tagger.string = text

        // 3. Define the unit of tokenization (e.g., .word, .sentence, .paragraph).
        // For POS, NER, and Lemmatization, we typically process word by word.
        let unit: NLTokenUnit = .word

        // 4. Define the options for tagging.
        // We want to omit whitespace and punctuation from the results to focus on actual words.
        let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation]

        // 5. Enumerate tags over the entire range of the string.
        // The block is called for each token found.
        text.enumerateSubstrings(in: text.startIndex..<text.endIndex, unit: unit) { substring, substringRange, enclosingRange, stop in
            guard let substring = substring else { return }

            // Retrieve all tags for the current substring (token) based on the initialized schemes.
            let tags = tagger.tags(in: substringRange, unit: unit, scheme: .tokenType, options: options)
            
            // For each token, we want to query specific tag schemes.
            let lexicalClassTag = tagger.tag(at: substringRange.lowerBound, unit: unit, scheme: .lexicalClass, options: options)?.0
            let nameTypeTag = tagger.tag(at: substringRange.lowerBound, unit: unit, scheme: .nameType, options: options)?.0
            let lemmaTag = tagger.tag(at: substringRange.lowerBound, unit: unit, scheme: .lemma, options: options)?.0

            // Print the results for each token.
            print("Token: '\(substring)'")
            print("  - POS (Lexical Class): \(lexicalClassTag?.rawValue ?? "N/A")")
            print("  - NER (Name Type):     \(nameTypeTag?.rawValue ?? "N/A")")
            print("  - Lemma:               \(lemmaTag?.rawValue ?? "N/A")")
            print("---------------------------------")
        }
        print("\n--- Analysis Complete ---")
    }

    /// Demonstrates Named Entity Recognition specifically for "person" entities.
    /// - Parameter text: The input string to find person names in.
    func findPersonNames(in text: String) {
        print("\n--- Finding Person Names ---")
        print("Original Text: \"\(text)\"\n")

        let tagger = NLTagger(tagSchemes: [.nameType])
        tagger.string = text

        let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation, .joinNames] // .joinNames is important for multi-word names

        // Enumerate tags specifically for name types.
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameType, options: options) { tag, tokenRange in
            if let tag = tag, tag == .personalName {
                let name = String(text[tokenRange])
                print("Found Person Name: '\(name)'")
            }
            return true // Continue enumeration
        }
        print("\n--- Person Name Search Complete ---")
    }
}

// --- Usage Example ---
let analyzer = JournalEntryAnalyzer()
let journalEntry = """
Today, I met with Dr. Sarah Connor at the Apple Store on Fifth Avenue.
We discussed the new project for next Tuesday. John Smith also joined us later.
It was a productive meeting, and I'm excited about the future.
"""

analyzer.analyze(text: journalEntry)
analyzer.findPersonNames(in: journalEntry)
