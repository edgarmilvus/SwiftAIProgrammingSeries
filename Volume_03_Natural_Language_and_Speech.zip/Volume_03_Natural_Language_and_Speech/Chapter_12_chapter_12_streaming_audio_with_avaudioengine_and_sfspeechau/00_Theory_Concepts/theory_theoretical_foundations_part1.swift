
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import AVFoundation
import Speech

@available(iOS 18.0, *)
actor AudioRecognitionManager: ObservableObject { // @ObservableObject for UIKit/Combine, or @Observable for SwiftUI
    // @Published var currentTranscription: String = "" // For @ObservableObject
    @ObservationIgnored private var audioEngine: AVAudioEngine?
    @ObservationIgnored private var speechRecognizer: SFSpeechRecognizer?
    @ObservationIgnored private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    @ObservationIgnored private var recognitionTask: SFSpeechRecognitionTask?

    // @Observable property for SwiftUI
    @Published var currentTranscription: String = "" // This property is @Published (Sendable) and updated safely.
    @Published var isRecognizing: Bool = false
    @Published var authorizationStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined
    @Published var lastError: Error?

    init() {
        // Initialize speech recognizer
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        speechRecognizer?.delegate = self // Actor conforms to delegate
    }

    // MARK: - Public Actor Methods

    /// Asynchronously requests speech recognition authorization.
    func requestAuthorization() async {
        let status = await SFSpeechRecognizer.requestAuthorization()
        await MainActor.run {
            self.authorizationStatus = status
        }
    }

    /// Starts the audio engine and speech recognition.
    func startRecognition() async throws {
        guard authorizationStatus == .authorized else {
            throw RecognitionError.notAuthorized
        }
        guard !isRecognizing else { return }

        // Ensure previous task is cancelled
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        audioEngine?.stop()
        audioEngine = nil

        await MainActor.run { // Update UI state on main actor
            self.currentTranscription = ""
            self.isRecognizing = true
            self.lastError = nil
        }

        // Setup AVAudioEngine
        let engine = AVAudioEngine()
        self.audioEngine = engine // Store engine instance in actor's isolated state
        let inputNode = engine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)

        // Create speech recognition request
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        self.recognitionRequest = request // Store request instance in actor's isolated state

        // Start recognition task
        self.recognitionTask = speechRecognizer?.recognitionTask(with: request)

        // Install tap on input node to feed audio to the request
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
            // This block is called on a high-priority audio thread.
            // We must carefully send the buffer to the actor's isolated context.
            // Since appendAudioPCMBuffer consumes the buffer, and the actor serializes access,
            // this is safe.
            Task { @MainActor in // Use @MainActor for updating @Published properties safely
                guard let self = self else { return }
                guard self.isRecognizing else { return }
                self.recognitionRequest?.appendAudioPCMBuffer(buffer)
            }
        }

        engine.prepare()
        try engine.start()
    }

    /// Stops the audio engine and finalizes speech recognition.
    func stopRecognition() async {
        guard isRecognizing else { return }

        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio() // Signal end of audio
        recognitionTask?.finish() // Explicitly finish the task

        await MainActor.run {
            self.isRecognizing = false
        }
    }

    // MARK: - Error Handling
    enum RecognitionError: Error, LocalizedError {
        case notAuthorized
        case recognitionFailed(Error)
        case audioEngineFailed(Error)

        var errorDescription: String? {
            switch self {
            case .notAuthorized: return "Speech recognition not authorized."
            case .recognitionFailed(let error): return "Recognition failed: \(error.localizedDescription)"
            case .audioEngineFailed(let error): return "Audio engine failed: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - SFSpeechRecognizerDelegate Conformance (within the actor)
@available(iOS 18.0, *)
extension AudioRecognitionManager: SFSpeechRecognizerDelegate, SFSpeechRecognitionTaskDelegate {
    // Delegate methods are called on a background thread.
    // We must hop to the MainActor to update @Published properties.

    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        // Handle availability changes if needed
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didHypothesizeTranscription transcription: SFTranscription) {
        Task { @MainActor in
            // Update current transcription with partial results
            self.currentTranscription = transcription.formattedString
        }
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishRecognition recognitionResult: SFSpeechRecognitionResult) {
        Task { @MainActor in
            // Final transcription result
            self.currentTranscription = recognitionResult.bestTranscription.formattedString
        }
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishSuccessfully successfully: Bool) {
        Task { @MainActor in
            self.isRecognizing = false
            self.recognitionRequest = nil
            self.recognitionTask = nil
            self.audioEngine?.stop()
            self.audioEngine = nil
        }
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didProcessAudioBuffer buffer: AVAudioPCMBuffer) {
        // This method is called after the speech recognizer has processed an audio buffer.
        // It's useful for debugging or advanced scenarios.
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didStopSpeechAt timestamp: TimeInterval) {
        // Called when the recognizer detects a pause in speech
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didStartSpeechAt timestamp: TimeInterval) {
        // Called when the recognizer detects the beginning of speech
    }

    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFailWithError error: Error) {
        Task { @MainActor in
            self.lastError = RecognitionError.recognitionFailed(error)
            self.isRecognizing = false
            self.recognitionRequest = nil
            self.recognitionTask = nil
            self.audioEngine?.stop()
            self.audioEngine = nil
        }
    }
}
