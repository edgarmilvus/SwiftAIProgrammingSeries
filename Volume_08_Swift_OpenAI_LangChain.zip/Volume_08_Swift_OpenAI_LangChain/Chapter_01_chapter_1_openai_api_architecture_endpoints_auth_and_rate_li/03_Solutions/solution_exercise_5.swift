
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

/// Represents the available AI models and their profiles.
enum AIModel: String, Sendable {
    case gpt4o = "gpt-4o"
    case gpt4oMini = "gpt-4o-mini"
    
    var costPerToken: Double {
        switch self {
        case .gpt4o: return 0.03 // Example cost
        case .gpt4oMini: return 0.00015
        }
    }
    
    var latencyScore: Int { // Lower is faster
        switch self {
        case .gpt4o: return 10
        case .gpt4oMini: return 2
        }
    }
}

/// Protocol defining how a routing decision is made.
protocol RoutingStrategy: Sendable {
    func selectModel(for prompt: String) -> AIModel
}

/// Strategy 1: Simple keyword matching.
struct KeywordRoutingStrategy: RoutingStrategy {
    let complexKeywords = ["analyze", "legal", "critique", "architectural", "complex"]
    
    func selectModel(for prompt: String) -> AIModel {
        let lowerPrompt = prompt.lowercased()
        for keyword in complexKeywords {
            if lowerPrompt.contains(keyword) {
                return .gpt4o
            }
        }
        return .gpt4oMini
    }
}

/// Strategy 2: Heuristic complexity scoring.
struct ComplexityScoringStrategy: RoutingStrategy {
    func selectModel(for prompt: String) -> AIModel {
        // If prompt is long or contains complex punctuation, assume complexity
        if prompt.count > 500 || prompt.contains(";") || prompt.contains(":") {
            return .gpt4o
        }
        return .gpt4oMini
    }
}

/// The Orchestrator that decides which model to use.
final class ModelRouter: Sendable {
    private let strategy: any RoutingStrategy
    
    init(strategy: any RoutingStrategy) {
        self.strategy = strategy
    }
    
    func route(prompt: String) -> AIModel {
        return strategy.selectModel(for: prompt)
    }
}

// --- Integration Example ---
actor EnterpriseAIService {
    private let openAIService: OpenAIService
    private let router: ModelRouter
    
    init(openAIService: OpenAIService, router: ModelRouter) {
        self.openAIService = openAIService
        self.router = router
    }
    
    func processUserRequest(prompt: String, history: [ChatMessage]) async throws -> String {
        // 1. Determine optimal model via the router
        let optimalModel = router.route(prompt: prompt)
        print("Routing request to: \(optimalModel.rawValue)")
        
        // 2. Execute request using the chosen model
        let response = try await openAIService.generateCompletion(for: history, model: optimalModel.rawValue)
        
        return response.choices.first?.message.content ?? ""
    }
}
