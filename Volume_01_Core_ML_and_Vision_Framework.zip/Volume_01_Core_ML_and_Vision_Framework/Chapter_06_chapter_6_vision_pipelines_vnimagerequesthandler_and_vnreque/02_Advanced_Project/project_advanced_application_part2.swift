
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Vision
import CoreML
import UIKit // For UIImage and CGImage

// Assume a Core ML model named "DocumentClassifier" exists in the app bundle.
// This model takes an image and outputs a document type label and confidence.
// For pedagogical purposes, we'll assume it's an Image Classifier.
// It would typically be generated from a .mlmodel file.
// In a real app, you would drag and drop the .mlmodel into your Xcode project,
// and Xcode automatically generates a Swift class for it (e.g., DocumentClassifier).
// We'll simulate this generated class structure.

/// Represents the classification result for a document.
struct DocumentClassificationResult {
    let type: String
    let confidence: Float
    let boundingBox: CGRect? // Bounding box of the classified document
}

/// Represents a detected text block with its content and bounding box.
struct DetectedTextBlock {
    let text: String
    let boundingBox: CGRect
}

/// A comprehensive result structure combining all analysis outputs for a document.
struct DocumentAnalysisResult {
    let classification: DocumentClassificationResult?
    let detectedText: [DetectedTextBlock]
    let documentOutline: CGRect? // The main detected document rectangle
    let error: Error?

    static var empty: DocumentAnalysisResult {
        DocumentAnalysisResult(classification: nil, detectedText: [], documentOutline: nil, error: nil)
    }
}

/// Manages the advanced Vision pipeline for document analysis,
/// including text recognition, document boundary detection, and custom Core ML classification.
@available(iOS 18.0, *) // Vision and Core ML features evolve; targeting a recent version for advanced usage.
class DocumentAnalyzer {

    // MARK: - Properties

    /// The Core ML model used for document classification.
    private let coreMLModel: VNCoreMLModel

    /// Initializes the DocumentAnalyzer with a Core ML model.
    /// - Throws: `DocumentAnalyzerError.modelLoadingFailed` if the Core ML model cannot be loaded.
    init() throws {
        // 1. Load the Core ML model dynamically.
        // This assumes a compiled .mlmodelc exists in the app's main bundle.
        // In a real project, Xcode generates a Swift class for your model (e.g., DocumentClassifier)
        // and you'd typically use `DocumentClassifier().model` to get the MLModel.
        // For demonstration, we'll load it via its name.
        guard let modelURL = Bundle.main.url(forResource: "DocumentClassifier", withExtension: "mlmodelc") else {
            throw DocumentAnalyzerError.modelLoadingFailed(
                "Could not find DocumentClassifier.mlmodelc in the app bundle. " +
                "Ensure your Core ML model is added to the target and compiled."
            )
        }
        let mlModel = try MLModel(contentsOf: modelURL)
        self.coreMLModel = try VNCoreMLModel(for: mlModel)
    }

    // MARK: - Public API

    /// Processes a document image using a Vision pipeline to perform text recognition,
    /// document boundary detection, and custom Core ML classification.
    ///
    /// - Parameters:
    ///   - image: The `CGImage` of the document to be analyzed.
    ///   - orientation: The `CGImagePropertyOrientation` of the image. Defaults to `.up`.
    /// - Returns: A `DocumentAnalysisResult` containing all detected information.
    /// - Throws: `DocumentAnalyzerError` if any part of the Vision pipeline fails.
    func analyzeDocument(image: CGImage, orientation: CGImagePropertyOrientation = .up) async throws -> DocumentAnalysisResult {
        // Initialize requests
        let textRecognitionRequest = VNRecognizeTextRequest()
        textRecognitionRequest.recognitionLevel = .accurate // Prioritize accuracy over speed
        textRecognitionRequest.usesLanguageCorrection = true // Improve text recognition with language context
        textRecognitionRequest.revision = VNRecognizeTextRequestRevision3 // Use the latest revision for best results

        let rectangleDetectionRequest = VNDetectRectanglesRequest()
        rectangleDetectionRequest.minimumAspectRatio = 0.5 // Allow for various document shapes
        rectangleDetectionRequest.maximumAspectRatio = 2.0
        rectangleDetectionRequest.quadratureTolerance = 15.0 // Tolerance for non-perfect rectangles
        rectangleDetectionRequest.minimumSize = 0.3 // Minimum size of a detected rectangle as a fraction of the image.

        let coreMLRequest = VNCoreMLRequest(model: coreMLModel) { request, error in
            // This completion handler is called *after* the request completes.
            // For `async/await`, we'll typically process results directly from `request.results`
            // after the `perform` call finishes, but this handler is useful for debugging or
            // specific post-processing if not using structured concurrency directly on results.
            if let error = error {
                print("Core ML Vision request failed with error: \(error.localizedDescription)")
            }
        }
        // Core ML requests often need specific image scaling/cropping.
        // VNCoreMLRequest will handle this automatically based on the MLModel's input description.
        // However, you can override it with `imageCropAndScaleOption`.
        coreMLRequest.imageCropAndScaleOption = .centerCrop

        // Create a request handler for the image.
        // VNImageRequestHandler is thread-safe and can be used on a background queue.
        let handler = VNImageRequestHandler(cgImage: image, orientation: orientation)

        var detectedTextBlocks: [DetectedTextBlock] = []
        var documentOutline: CGRect?
        var classificationResult: DocumentClassificationResult?
        var pipelineError: Error?

        do {
            // 2. Perform all requests concurrently (within the handler's internal queue).
            // `perform` is a synchronous call that executes all requests.
            // For truly parallel execution of *different* handlers or *different* images,
            // you'd use multiple `Task`s. Here, the requests within *one* handler
            // are processed efficiently by Vision.
            try handler.perform([textRecognitionRequest, rectangleDetectionRequest, coreMLRequest])

            // 3. Process Text Recognition Results
            if let observations = textRecognitionRequest.results as? [VNRecognizedTextObservation] {
                for observation in observations {
                    guard let topCandidate = observation.topCandidates(1).first else { continue }
                    // Convert normalized bounding box to image coordinates
                    let boundingBox = VNImageRectForNormalizedRect(observation.boundingBox,
                                                                   Int(image.width),
                                                                   Int(image.height))
                    detectedTextBlocks.append(DetectedTextBlock(text: topCandidate.string, boundingBox: boundingBox))
                }
            } else if let error = textRecognitionRequest.error {
                print("Text Recognition Request failed: \(error.localizedDescription)")
                pipelineError = pipelineError ?? DocumentAnalyzerError.visionRequestFailed("Text Recognition", error)
            }


            // 4. Process Rectangle Detection Results
            if let observations = rectangleDetectionRequest.results as? [VNRectangleObservation],
               let firstRectangle = observations.first { // Assuming the largest/most prominent is the document
                // Convert normalized bounding box to image coordinates
                documentOutline = VNImageRectForNormalizedRect(firstRectangle.boundingBox,
                                                               Int(image.width),
                                                               Int(image.height))
            } else if let error = rectangleDetectionRequest.error {
                print("Rectangle Detection Request failed: \(error.localizedDescription)")
                pipelineError = pipelineError ?? DocumentAnalyzerError.visionRequestFailed("Rectangle Detection", error)
            }

            // 5. Process Core ML Classification Results
            if let observations = coreMLRequest.results as? [VNCoreMLFeatureValueObservation],
               let firstObservation = observations.first {
                // Assuming the Core ML model outputs a string label and a confidence score.
                // The exact structure depends on how your MLModel was created.
                // For a typical image classifier, the output might be a dictionary of string-to-double.
                if let featureValue = firstObservation.featureValue,
                   let multiArray = featureValue.multiArrayValue {

                    // Example: Assuming the model outputs a softmax probability distribution
                    // and we need to find the highest confidence label.
                    // This part is highly dependent on your Core ML model's output format.
                    // For a simple classifier, it might directly output a string and a float.
                    // We'll simulate a common scenario where the output is a multiArray
                    // representing probabilities for different classes.
                    let (label, confidence) = try await getTopPrediction(from: multiArray, model: coreMLModel.model)
                    
                    // If the Core ML model also provides a bounding box for the classified object,
                    // it would be available in `firstObservation.boundingBox`.
                    // For a whole-image classifier, boundingBox might not be relevant or available.
                    let classificationBoundingBox = firstObservation.boundingBox.isEmpty ? nil : VNImageRectForNormalizedRect(firstObservation.boundingBox, Int(image.width), Int(image.height))
                    
                    classificationResult = DocumentClassificationResult(type: label, confidence: confidence, boundingBox: classificationBoundingBox)

                } else {
                    print("Core ML request did not return expected feature value.")
                    pipelineError = pipelineError ?? DocumentAnalyzerError.visionRequestFailed("Core ML Classification", nil)
                }
            } else if let error = coreMLRequest.error {
                print("Core ML Classification Request failed: \(error.localizedDescription)")
                pipelineError = pipelineError ?? DocumentAnalyzerError.visionRequestFailed("Core ML Classification", error)
            }

        } catch {
            // Catch any errors from `handler.perform`
            print("Vision handler performance failed: \(error.localizedDescription)")
            pipelineError = pipelineError ?? DocumentAnalyzerError.visionPipelineFailed(error)
        }
        
        // If an error occurred during processing, throw it.
        if let pipelineError = pipelineError {
            throw pipelineError
        }

        return DocumentAnalysisResult(
            classification: classificationResult,
            detectedText: detectedTextBlocks,
            documentOutline: documentOutline,
            error: nil // Error is thrown, not stored in result for successful path
        )
    }

    /// Helper to extract the top prediction from a Core ML model's multiArray output.
    /// This is a common pattern for image classification models.
    /// - Parameters:
    ///   - multiArray: The `MLMultiArray` containing the model's output probabilities.
    ///   - model: The `MLModel` instance to get class labels.
    /// - Returns: A tuple containing the top label string and its confidence.
    /// - Throws: `DocumentAnalyzerError.modelOutputProcessingFailed` if output cannot be processed.
    private func getTopPrediction(from multiArray: MLMultiArray, model: MLModel) async throws -> (String, Float) {
        guard multiArray.dataType == .float32 || multiArray.dataType == .double else {
            throw DocumentAnalyzerError.modelOutputProcessingFailed("Unsupported MLMultiArray data type: \(multiArray.dataType)")
        }

        let pointer = multiArray.dataPointer.assumingMemoryBound(to: Float.self)
        let count = multiArray.count

        var maxConfidence: Float = 0.0
        var maxIndex: Int = -1

        for i in 0..<count {
            let confidence = pointer[i]
            if confidence > maxConfidence {
                maxConfidence = confidence
                maxIndex = i
            }
        }

        guard maxIndex != -1,
              let classLabels = model.modelDescription.outputDescriptionsByName["label"]?.multiArrayConstraint?.shape.last?.intValue == count ? model.modelDescription.classLabels : nil,
              maxIndex < classLabels.count else {
            throw DocumentAnalyzerError.modelOutputProcessingFailed("Could not determine top class label from model output.")
        }

        let label = classLabels[maxIndex]
        return (label, maxConfidence)
    }
}

// MARK: - Error Handling

/// Custom error types for the DocumentAnalyzer.
enum DocumentAnalyzerError: Error, LocalizedError {
    case modelLoadingFailed(String)
    case visionPipelineFailed(Error)
    case visionRequestFailed(String, Error?)
    case modelOutputProcessingFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let message):
            return "Failed to load Core ML model: \(message)"
        case .visionPipelineFailed(let underlyingError):
            return "Vision pipeline failed: \(underlyingError.localizedDescription)"
        case .visionRequestFailed(let requestType, let underlyingError):
            let base = "Vision request for \(requestType) failed."
            return underlyingError != nil ? "\(base) Underlying error: \(underlyingError!.localizedDescription)" : base
        case .modelOutputProcessingFailed(let message):
            return "Failed to process Core ML model output: \(message)"
        }
    }
}

// MARK: - Example Usage (within a SwiftUI View or ViewController)

/// A simple example demonstrating how to use the DocumentAnalyzer.
/// In a real app, this would be part of your UI logic (e.g., in a `UIViewController` or `View`).
@available(iOS 18.0, *)
class DocumentScannerViewController: UIViewController {

    private var documentAnalyzer: DocumentAnalyzer?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupAnalyzer()
        // Simulate processing an image after a short delay
        Task {
            await simulateImageProcessing()
        }
    }

    /// Sets up the DocumentAnalyzer, handling potential model loading errors.
    private func setupAnalyzer() {
        do {
            documentAnalyzer = try DocumentAnalyzer()
            print("DocumentAnalyzer initialized successfully.")
        } catch {
            print("Failed to initialize DocumentAnalyzer: \(error.localizedDescription)")
            // Display an alert to the user or disable functionality
        }
    }

    /// Simulates processing a sample image.
    @MainActor
    private func simulateImageProcessing() async {
        guard let analyzer = documentAnalyzer else {
            print("DocumentAnalyzer is not initialized.")
            return
        }

        // Load a sample image. In a real app, this would come from the camera or photo library.
        guard let sampleImage = UIImage(named: "sample_document")?.cgImage else {
            print("Error: 'sample_document.png' not found in assets.")
            // For testing, create a dummy image if no asset is available
            let dummySize = CGSize(width: 800, height: 1200)
            UIGraphicsBeginImageContextWithOptions(dummySize, false, 0.0)
            UIColor.white.setFill()
            UIRectFill(CGRect(origin: .zero, size: dummySize))
            let textRect = CGRect(x: 50, y: 50, width: dummySize.width - 100, height: dummySize.height - 100)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 48),
                .foregroundColor: UIColor.black,
                .paragraphStyle: paragraphStyle
            ]
            ("Invoice #12345\nDate: 2024-07-20\nTotal: $99.99").draw(in: textRect, withAttributes: attributes)
            let dummyImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            guard let cgDummyImage = dummyImage?.cgImage else {
                print("Failed to create dummy image.")
                return
            }
            print("Using dummy image for analysis.")
            await processImage(cgDummyImage, analyzer: analyzer)
            return
        }

        print("Processing sample_document.png...")
        await processImage(sampleImage, analyzer: analyzer)
    }

    @MainActor
    private func processImage(_ cgImage: CGImage, analyzer: DocumentAnalyzer) async {
        do {
            // Perform the analysis on a background thread using Task
            let analysisResult = try await Task.detached {
                try await analyzer.analyzeDocument(image: cgImage)
            }.value

            // Update UI on the main thread
            print("\n--- Document Analysis Results ---")
            if let classification = analysisResult.classification {
                print("Classification: \(classification.type) (Confidence: \(String(format: "%.2f", classification.confidence * 100))%)")
                if let bbox = classification.boundingBox {
                    print("  Classification BBox: \(bbox)")
                }
            } else {
                print("Classification: Not determined")
            }

            if let outline = analysisResult.documentOutline {
                print("Document Outline: \(outline)")
            } else {
                print("Document Outline: Not detected")
            }

            print("Detected Text Blocks (\(analysisResult.detectedText.count)):")
            for (index, textBlock) in analysisResult.detectedText.enumerated() {
                print("  \(index + 1). \"\(textBlock.text)\" (BBox: \(textBlock.boundingBox))")
            }

            // In a real app, you would update your UI here
            // e.g., display the classification, highlight text, draw document outline.

        } catch {
            print("Document analysis failed: \(error.localizedDescription)")
            // Show an error alert to the user
            let alert = UIAlertController(title: "Analysis Error", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
}
