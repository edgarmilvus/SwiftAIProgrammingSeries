
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct ChatToken: Sendable {
    let text: String
}

@available(iOS 18.0, *)
actor TokenStreamProcessor {
    private var buffer: String = ""
    private var isStreaming = false
    
    /// Adds a token to the internal buffer.
    /// This can be called at extremely high frequencies (e.g., 500Hz).
    func processIncomingToken(_ token: ChatToken) {
        buffer += token.text
    }
    
    /// Returns an AsyncStream that emits the current buffer contents at a controlled rate.
    func streamThrottledContent() -> AsyncStream<String> {
        AsyncStream { continuation in
            let task = Task {
                // Use ContinuousClock for modern, precise timing
                let clock = ContinuousClock()
                
                while !Task.isCancelled {
                    // 1. Wait for the throttle interval (0.1s = 10 updates per second)
                    try? await Task.sleep(for: .seconds(0.1))
                    
                    // 2. Extract the current buffer
                    let contentToYield = self.getAndClearBuffer()
                    
                    // 3. Yield to the UI
                    if !contentToYield.isEmpty {
                        continuation.yield(contentToYield)
                    }
                    
                    // In a real app, we'd check if the LLM has finished streaming 
                    // to break this loop. For this exercise, we'll assume it runs.
                }
                continuation.finish()
            }
            
            // Handle task cancellation
            continuation.onTermination = { _ in
                task.cancel()
            }
        }
    }
    
    // Helper to extract data from the actor's private state
    private func getAndClearBuffer() -> String {
        let current = buffer
        buffer = ""
        return current
    }
}

// --- Implementation Challenge ---
@available(iOS 18.0, *)
struct HighFrequencySimulation {
    func run() async {
        let processor = TokenStreamProcessor()
        
        // 1. Simulate a "Firehose" of tokens (100 tokens in 1 second)
        Task {
            for i in 1...100 {
                await processor.processIncomingToken(ChatToken(text: "t\(i) "))
                // Extremely fast arrival: 10ms between tokens
                try? await Task.sleep(for: .milliseconds(10))
            }
            print("--- Firehose Finished ---")
        }
        
        // 2. Consume the throttled stream
        print("Starting throttled consumer...")
        let startTime = Date()
        
        for await chunk in await processor.streamThrottledContent() {
            let elapsed = Date().timeIntervalSince(startTime)
            print("[\(String(format: "%.2f", elapsed))s] UI Received Chunk: \(chunk)")
            
            // Stop simulation after 1.5 seconds for demo purposes
            if elapsed > 1.5 { break }
        }
    }
}

// --- Execution ---
@available(iOS 18.0, *)
func runThrottlingTest() async {
    await HighFrequencySimulation().run()
}
