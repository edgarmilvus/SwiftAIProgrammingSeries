
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import Vision
import AVFoundation
import CoreGraphics
import CoreImage
import UIKit // For UIViewController and UIImage/CALayer for demonstration

// MARK: - 1. Custom Error Definitions

/// Custom errors specific to the segmentation process.
enum SegmentationError: Error, LocalizedError {
    case modelNotFound
    case modelCompilationFailed(Error)
    case modelNotReady
    case invalidObservationType
    case noSegmentationMap
    case cameraSetupFailed(Error)
    case throttled
    case unknown(Error)
    case cgImageConversionFailed

    var errorDescription: String? {
        switch self {
        case .modelNotFound: return "Semantic segmentation model not found in the app bundle."
        case .modelCompilationFailed(let error): return "Failed to compile Core ML model: \(error.localizedDescription)"
        case .modelNotReady: return "Core ML model is not yet loaded or failed to load."
        case .invalidObservationType: return "Vision observation was not of type VNSegmentationObservation."
        case .noSegmentationMap: return "No segmentation pixel buffer found in the observation."
        case .cameraSetupFailed(let error): return "Failed to set up camera: \(error.localizedDescription)"
        case .throttled: return "Frame processing throttled due to high load."
        case .unknown(let error): return "An unknown error occurred: \(error.localizedDescription)"
        case .cgImageConversionFailed: return "Failed to convert CVPixelBuffer to CGImage."
        }
    }
}

// MARK: - 2. Camera Feed Management

/// Manages the AVCaptureSession to provide real-time video frames.
/// Uses an AsyncStream to deliver CVPixelBuffer frames asynchronously.
@available(iOS 18.0, *)
class CameraFeedManager: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    /// The underlying AVCaptureSession for camera input.
    let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "com.example.cameraSessionQueue", qos: .userInitiated)

    private var continuation: AsyncStream<CVPixelBuffer>.Continuation?

    /// An AsyncStream that yields CVPixelBuffer frames from the camera.
    lazy var videoFrames: AsyncStream<CVPixelBuffer> = {
        AsyncStream { continuation in
            self.continuation = continuation
            continuation.onTermination = { [weak self] _ in
                self?.stopSession()
            }
        }
    }()

    override init() {
        super.init()
        setupSession()
    }

    /// Configures the AVCaptureSession with video input and output.
    private func setupSession() {
        captureSession.beginConfiguration()
        defer { captureSession.commitConfiguration() }

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get camera device.")
            continuation?.finish(throwing: SegmentationError.cameraSetupFailed(NSError(domain: "Camera", code: -1, userInfo: [NSLocalizedDescriptionKey: "No camera device available"])))
            return
        }

        guard let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            print("Failed to create video input.")
            continuation?.finish(throwing: SegmentationError.cameraSetupFailed(NSError(domain: "Camera", code: -2, userInfo: [NSLocalizedDescriptionKey: "Could not create video input"])))
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            print("Could not add video input to session.")
            continuation?.finish(throwing: SegmentationError.cameraSetupFailed(NSError(domain: "Camera", code: -3, userInfo: [NSLocalizedDescriptionKey: "Could not add video input"])))
            return
        }

        if captureSession.canAddOutput(videoOutput) {
            videoOutput.setSampleBufferDelegate(self, queue: sessionQueue)
            videoOutput.alwaysDiscardsLateVideoFrames = true
            // Use 32BGRA for compatibility with CIImage and Core ML
            videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output to session.")
            continuation?.finish(throwing: SegmentationError.cameraSetupFailed(NSError(domain: "Camera", code: -4, userInfo: [NSLocalizedDescriptionKey: "Could not add video output"])))
            return
        }

        // Configure video orientation for output
        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }
    }

    /// Starts the camera session on a background queue.
    func startSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if !self.captureSession.isRunning {
                self.captureSession.startRunning()
                print("Camera session started.")
            }
        }
    }

    /// Stops the camera session and finishes the AsyncStream.
    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if self.captureSession.isRunning {
                self.captureSession.stopRunning()
                print("Camera session stopped.")
            }
            self.continuation?.finish()
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    /// Called when a new video frame is available.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        continuation?.yield(pixelBuffer)
    }

    /// Called when a video frame is dropped due to being late.
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // In a real-time app, logging dropped frames can help diagnose performance issues.
        // print("Dropped frame.")
    }
}

// MARK: - 3. Core ML Segmentation Processor (Actor)

/// An actor responsible for loading the Core ML model and processing CVPixelBuffer frames
/// for semantic segmentation using Vision.
@available(iOS 18.0, *)
actor SegmentationProcessor {
    private var model: VNCoreMLModel?
    private var isProcessing = false // Simple throttling mechanism

    init() {
        // Asynchronously load the model when the actor is initialized.
        Task {
            await loadModel()
        }
    }

    /// Loads the custom Core ML model into a VNCoreMLModel.
    private func loadModel() async {
        do {
            // Ensure the model is compiled (.mlmodelc) and available in the app bundle.
            guard let modelURL = Bundle.main.url(forResource: "SemanticSegmentationModel", withExtension: "mlmodelc") else {
                throw SegmentationError.modelNotFound
            }
            // If the model is not already compiled, Vision will attempt to compile it.
            // For production, it's best to pre-compile the model at build time.
            // let compiledModel = try MLModel.compileModel(at: modelURL) // Optional: explicit compilation
            self.model = try VNCoreMLModel(for: MLModel(contentsOf: modelURL))
            print("Core ML model 'SemanticSegmentationModel.mlmodelc' loaded successfully.")
        } catch let error as SegmentationError {
            print("Failed to load Core ML model: \(error.localizedDescription)")
            self.model = nil // Ensure model is nil if loading fails
        } catch {
            print("Failed to load Core ML model with unknown error: \(error.localizedDescription)")
            self.model = nil
        }
    }

    /// Processes a single CVPixelBuffer frame using the loaded Core ML model.
    /// - Parameter pixelBuffer: The CVPixelBuffer representing the video frame.
    /// - Returns: A Result containing the processed CVPixelBuffer (segmentation mask) or an Error.
    /// The returned mask typically has pixel values representing different segments.
    func processFrame(_ pixelBuffer: CVPixelBuffer) async -> Result<CVPixelBuffer, Error> {
        guard let model = self.model else {
            return .failure(SegmentationError.modelNotReady)
        }

        if isProcessing {
            // Simple throttling: skip frame if previous one is still being processed.
            // This prevents backpressure and keeps the UI responsive.
            return .failure(SegmentationError.throttled)
        }
        isProcessing = true

        return await withCheckedContinuation { continuation in
            // Create a new VNCoreMLRequest for each frame. This allows us to
            // capture the continuation within its completion handler.
            let frameRequest = VNCoreMLRequest(model: model) { [weak self] request, error in
                self?.isProcessing = false // Reset throttling state

                if let error = error {
                    continuation.resume(returning: .failure(error))
                    return
                }

                // Vision segmentation models typically return VNSegmentationObservation.
                guard let observations = request.results as? [VNSegmentationObservation] else {
                    continuation.resume(returning: .failure(SegmentationError.invalidObservationType))
                    return
                }

                // Get the first segmentation map (assuming a single-class segmentation or primary class).
                guard let segmentationMap = observations.first?.pixelBuffer else {
                    continuation.resume(returning: .failure(SegmentationError.noSegmentationMap))
                    return
                }
                continuation.resume(returning: .success(segmentationMap))
            }

            // Configure request options. .scaleFill is common for segmentation.
            frameRequest.imageCropAndScaleOption = .scaleFill

            // Perform the Vision request on the pixel buffer.
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            do {
                try handler.perform([frameRequest])
            } catch {
                self.isProcessing = false // Ensure throttling is reset even on handler error
                continuation.resume(returning: .failure(error))
            }
        }
    }
}

// MARK: - 4. Integration into a UIViewController

/// A simplified view controller to demonstrate the integration of camera feed,
/// Core ML segmentation, and basic visualization.
/// In a real app, this would manage UI, display camera feed, and overlay sophisticated
/// segmentation results (e.g., using Metal for blurring/compositing).
@available(iOS 18.0, *)
class SegmentationViewController: UIViewController {
    private let cameraManager = CameraFeedManager()
    private let segmentationProcessor = SegmentationProcessor()
    private var processingTask: Task<Void, Never>?

    /// Layer to display the live camera feed.
    private let cameraPreviewLayer = AVCaptureVideoPreviewLayer()
    /// Layer to overlay the segmentation mask.
    private let segmentationOverlayLayer = CALayer()

    private let ciContext = CIContext() // For efficient CIImage to CGImage conversion

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupCameraPreview()
        setupSegmentationOverlay()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Request camera authorization if not already granted
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard granted else {
                print("Camera access denied. Cannot start session.")
                // Present an alert to the user
                return
            }
            DispatchQueue.main.async {
                self?.cameraManager.startSession()
                self?.startProcessingFrames()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        cameraManager.stopSession()
        processingTask?.cancel() // Cancel the ongoing frame processing task
    }

    /// Sets up the AVCaptureVideoPreviewLayer to display the camera feed.
    private func setupCameraPreview() {
        cameraPreviewLayer.session = cameraManager.captureSession
        cameraPreviewLayer.videoGravity = .resizeAspectFill
        cameraPreviewLayer.frame = view.bounds
        view.layer.addSublayer(cameraPreviewLayer)
    }

    /// Sets up a CALayer to display the segmentation mask as an overlay.
    private func setupSegmentationOverlay() {
        segmentationOverlayLayer.frame = view.bounds
        segmentationOverlayLayer.opacity = 0.6 // Make it semi-transparent
        segmentationOverlayLayer.backgroundColor = UIColor.clear.cgColor // Default to clear
        view.layer.addSublayer(segmentationOverlayLayer)
    }

    /// Starts an asynchronous task to continuously process camera frames.
    private func startProcessingFrames() {
        processingTask = Task {
            do {
                for await pixelBuffer in cameraManager.videoFrames {
                    // Send the frame to the actor for processing.
                    // The actor will handle its internal state and concurrency.
                    let result = await segmentationProcessor.processFrame(pixelBuffer)

                    // Update UI on the main thread after processing.
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self else { return }
                        switch result {
                        case .success(let segmentationMask):
                            // Convert the segmentation mask CVPixelBuffer to CGImage for display.
                            // In a high-performance scenario, this conversion and display
                            // would be handled by Metal or AVSampleBufferDisplayLayer directly.
                            if let cgImage = self.createCGImage(from: segmentationMask) {
                                self.segmentationOverlayLayer.contents = cgImage
                                self.segmentationOverlayLayer.backgroundColor = UIColor.clear.cgColor
                            } else {
                                self.segmentationOverlayLayer.contents = nil
                                self.segmentationOverlayLayer.backgroundColor = UIColor.red.withAlphaComponent(0.3).cgColor // Indicate failure
                                print("Failed to create CGImage from segmentation mask.")
                            }
                        case .failure(let error):
                            if case SegmentationError.throttled = error {
                                // print("Frame throttled, skipping.") // Suppress frequent logs for throttling
                            } else {
                                print("Error processing frame: \(error.localizedDescription)")
                                self.segmentationOverlayLayer.contents = nil
                                self.segmentationOverlayLayer.backgroundColor = UIColor.orange.withAlphaComponent(0.3).cgColor // Indicate error
                            }
                        }
                    }
                }
                print("Camera frame stream terminated.")
            } catch {
                print("Error consuming camera frames: \(error.localizedDescription)")
            }
        }
    }

    /// Helper function to convert a CVPixelBuffer into a CGImage.
    /// This uses Core Image (CIImage) as an intermediate step.
    /// - Parameter pixelBuffer: The CVPixelBuffer to convert.
    /// - Returns: An optional CGImage.
    private func createCGImage(from pixelBuffer: CVPixelBuffer) -> CGImage? {
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        // Use the shared CIContext for potentially better performance.
        guard let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else {
            return nil
        }
        return cgImage
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Ensure layers resize with the view.
        cameraPreviewLayer.frame = view.bounds
        segmentationOverlayLayer.frame = view.bounds
    }
}
