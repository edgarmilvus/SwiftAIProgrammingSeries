
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// --- Shared Manifest Structure (e.g., Manifest.swift) ---
import Foundation

/// Represents the current state of model deployments, including stable, A/B test, and available versions.
struct ModelManifest: Codable {
    var stableModelVersion: String // The model version active for the majority of users
    var abTestModelVersion: String? // Optional model version for A/B testing
    var abTestPercentage: Int // Percentage of users to receive the A/B test model (0-100)
    var availableVersions: [String] // List of all model versions found in the repository
    var lastDeploymentTimestamp: Date // Timestamp of the last manifest update
    
    // Custom initializer to handle initial state or defaults
    init(stableModelVersion: String, abTestModelVersion: String? = nil, abTestPercentage: Int = 0, availableVersions: [String], lastDeploymentTimestamp: Date) {
        self.stableModelVersion = stableModelVersion
        self.abTestModelVersion = abTestModelVersion
        self.abTestPercentage = abTestPercentage
        self.availableVersions = availableVersions
        self.lastDeploymentTimestamp = lastDeploymentTimestamp
    }
}

// Helper to load/save the manifest
enum ManifestManager {
    static let manifestFileName = "manifest.json"
    
    static func getManifestURL(in directory: URL) -> URL {
        return directory.appendingPathComponent(manifestFileName)
    }
    
    static func loadManifest(from directory: URL) throws -> ModelManifest {
        let manifestURL = getManifestURL(in: directory)
        guard FileManager.default.fileExists(atPath: manifestURL.path) else {
            throw NSError(domain: "ModelManagement", code: 404, userInfo: [NSLocalizedDescriptionKey: "Manifest file not found at \(manifestURL.path)"])
        }
        let data = try Data(contentsOf: manifestURL)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601 // Use ISO8601 for consistent date encoding/decoding
        return try decoder.decode(ModelManifest.self, from: data)
    }
    
    static func saveManifest(_ manifest: ModelManifest, to directory: URL) throws {
        let manifestURL = getManifestURL(in: directory)
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        encoder.dateEncodingStrategy = .iso8601 // Use ISO8601 for consistent date encoding/decoding
        let updatedData = try encoder.encode(manifest)
        try updatedData.write(to: manifestURL, options: .atomicWrite)
    }
    
    /// Discovers all available model versions in the ModelRepository.
    static func discoverAvailableVersions(in repositoryPath: URL) throws -> [String] {
        let fileManager = FileManager.default
        guard fileManager.fileExists(atPath: repositoryPath.path) else {
            return []
        }
        let contents = try fileManager.contentsOfDirectory(at: repositoryPath, includingPropertiesForKeys: nil)
            .filter { $0.hasDirectoryPath && $0.lastPathComponent.hasPrefix("v") } // Filter for version directories
            .map { $0.lastPathComponent }
            .sorted { $0.compare($1, options: .numeric) == .orderedAscending } // Numeric sort for versions
        return contents
    }
}
