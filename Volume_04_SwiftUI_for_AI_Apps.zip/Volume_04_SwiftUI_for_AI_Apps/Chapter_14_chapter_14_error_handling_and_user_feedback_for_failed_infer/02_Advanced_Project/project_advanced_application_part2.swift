
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Logging // For Logger

/// A custom error type specifically for AI inference operations.
/// This allows for fine-grained control over error handling,
/// such as distinguishing between retryable and non-retryable failures.
enum AIInferenceError: LocalizedError, Equatable {
    /// Indicates a transient network issue (e.g., no internet, timeout).
    case networkError(String)
    /// The input provided to the AI model was invalid (e.g., wrong format, out of bounds).
    case invalidInput(String)
    /// The AI model or service is temporarily unavailable on the server side.
    case modelUnavailable(String)
    /// The inference process failed for an internal reason on the server.
    case inferenceFailed(String)
    /// The server or device ran out of resources (e.g., memory, GPU).
    case resourceExhausted(String)
    /// The inference task was explicitly cancelled by the user or system.
    case cancelled
    /// An unknown or unhandled error occurred.
    case unknown(String)

    /// A human-readable description of the error.
    var errorDescription: String? {
        switch self {
        case .networkError(let detail): return "Network Error: \(detail). Please check your connection."
        case .invalidInput(let detail): return "Invalid Input: \(detail). Please try a different image."
        case .modelUnavailable(let detail): return "AI Model Unavailable: \(detail). Please try again later."
        case .inferenceFailed(let detail): return "Inference Failed: \(detail). An unexpected error occurred."
        case .resourceExhausted(let detail): return "Resource Exhausted: \(detail). The server is busy, or image is too large."
        case .cancelled: return "Operation Cancelled."
        case .unknown(let detail): return "An unknown error occurred: \(detail)."
        }
    }

    /// Determines if the error is transient and thus potentially retryable.
    var isRetryable: Bool {
        switch self {
        case .networkError, .modelUnavailable, .resourceExhausted:
            // Network issues, temporary model unavailability, or transient resource exhaustion
            // are often retryable.
            return true
        case .invalidInput, .inferenceFailed, .cancelled, .unknown:
            // Invalid input requires user intervention.
            // A general inference failure might indicate a persistent model bug.
            // Cancellation is not an error to retry.
            // Unknown errors are generally treated as non-retryable to prevent infinite loops.
            return false
        }
    }
}
