
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import MLX
import MLXNN

/// A simplified document classifier model.
/// This model takes document embeddings and classifies them into categories.
/// It uses `LoRA_Augmented_Linear` layers to allow for efficient fine-tuning
/// on domain-specific tasks without modifying the base model's core weights.
final class SimpleDocumentClassifier: MLXNN.Module {
    let embeddingDimension: Int
    let hiddenDimension: Int
    let numClasses: Int

    let layer1: LoRA_Augmented_Linear
    let activation: MLXNN.ReLU
    let outputLayer: LoRA_Augmented_Linear // Another LoRA-augmented layer

    /// Initializes the document classifier.
    /// - Parameters:
    ///   - embeddingDimension: The dimension of the input document embeddings.
    ///   - hiddenDimension: The dimension of the hidden layer.
    ///   - numClasses: The number of output classification categories.
    ///   - loraRank: The low rank `r` for the LoRA matrices.
    ///   - loraAlpha: Scaling factor for the LoRA output.
    ///   - key: The `MLXRandom.Key` for parameter initialization.
    init(embeddingDimension: Int, hiddenDimension: Int, numClasses: Int, loraRank: Int, loraAlpha: Double, key: MLXRandom.Key) {
        self.embeddingDimension = embeddingDimension
        self.hiddenDimension = hiddenDimension
        self.numClasses = numClasses

        // The first layer, augmented with LoRA.
        self.layer1 = LoRA_Augmented_Linear(
            inputDimensions: embeddingDimension,
            outputDimensions: hiddenDimension,
            rank: loraRank,
            alpha: loraAlpha,
            key: key.split()
        )
        self.activation = MLXNN.ReLU()
        // The output layer, also augmented with LoRA.
        self.outputLayer = LoRA_Augmented_Linear(
            inputDimensions: hiddenDimension,
            outputDimensions: numClasses,
            rank: loraRank,
            alpha: loraAlpha,
            key: key.split()
        )
        super.init()
    }

    /// Performs the forward pass of the classifier.
    /// - Parameter input: A batch of document embeddings (`MLXArray`).
    /// - Returns: Logits for each class (`MLXArray`).
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        let x = layer1(input)
        let x_activated = activation(x)
        return outputLayer(x_activated)
    }

    /// Retrieves only the trainable LoRA parameters from the model.
    /// This is crucial for efficient fine-tuning, as only these parameters
    /// will be passed to the optimizer.
    func loraParameters() -> [MLXArray] {
        var params: [MLXArray] = []
        // Recursively find all parameters within LoRALinearAdapter instances
        for (_, module) in self.namedModules() {
            if let loraAdapter = module as? LoRALinearAdapter {
                params.append(loraAdapter.loraA)
                params.append(loraAdapter.loraB)
            }
        }
        return params
    }
}
