
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Placeholder Data Source and Evaluation (from previous exercises)
@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
private func evaluateModel(_ model: MLImageClassifier, on dataSource: MLImageClassifier.DataSource) async throws -> Double {
    print("  (Simulating model evaluation for validation accuracy for Document Scanner...)")
    // In a real app, this would involve actual predictions and metric calculation.
    // For demonstration, we'll return a value that might trigger the adaptive re-training.
    return Double.random(in: 0.80...0.92) // Simulate a range that could be below 0.88
}

// MARK: - Document Classifier Trainer Struct

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
struct DocumentClassifierTrainer {
    let trainingData: MLImageClassifier.DataSource
    let validationData: MLImageClassifier.DataSource
    let accuracyThreshold: Double = 0.88 // Target validation accuracy
    let initialEpochs: Int = 15
    let aggressiveEpochs: Int = 25 // More epochs for aggressive augmentations

    func trainAdaptiveModel() async throws -> MLImageClassifier {
        print("Starting initial training with moderate augmentations...")
        var currentAugmentations = configureModerateAugmentations()
        
        // Initial training phase
        var model = try await trainModel(augmentations: currentAugmentations, epochs: initialEpochs, label: "Initial (Moderate Augmentation)")

        // Performance Evaluation
        let initialValidationAccuracy: Double = try await evaluateModel(model, on: validationData)
        print("Initial validation accuracy: \(String(format: "%.2f", initialValidationAccuracy * 100))%")

        // Adaptive Augmentation Logic
        if initialValidationAccuracy < accuracyThreshold {
            print("Initial validation accuracy (\(String(format: "%.2f", initialValidationAccuracy * 100))%) is below threshold (\(String(format: "%.2f", accuracyThreshold * 100))%). Retraining with aggressive augmentations...")
            currentAugmentations = configureAggressiveAugmentations()
            // Re-training phase
            model = try await trainModel(augmentations: currentAugmentations, epochs: aggressiveEpochs, label: "Retrained (Aggressive Augmentation)")
            let finalValidationAccuracy = try await evaluateModel(model, on: validationData)
            print("Final validation accuracy after aggressive retraining: \(String(format: "%.2f", finalValidationAccuracy * 100))%")
        } else {
            print("Initial validation accuracy (\(String(format: "%.2f", initialValidationAccuracy * 100))%) is sufficient.")
        }
        return model
    }

    private func configureModerateAugmentations() -> MLImageClassifier.DataSource.AugmentationOptions {
        var options = MLImageClassifier.DataSource.AugmentationOptions()
        options.rotation = .degrees(range: -10.0...10.0)
        options.flip = .horizontal // Documents can be scanned upside down or mirrored
        options.randomCrop = .fraction(min: 0.9, max: 1.0) // Slight crop for framing variations
        options.colorJitter = .fraction(brightness: 0.05, contrast: 0.05, saturation: 0.0, hue: 0.0) // Minor lighting/color shifts
        return options
    }

    private func configureAggressiveAugmentations() -> MLImageClassifier.DataSource.AugmentationOptions {
        var options = MLImageClassifier.DataSource.AugmentationOptions()
        options.rotation = .degrees(range: -25.0...25.0) // Wider rotation for skewed scans
        options.flip = .horizontalAndVertical           // Both flips for maximum orientation invariance
        options.randomCrop = .fraction(min: 0.8, max: 1.0) // More aggressive crop to handle poor framing
        options.colorJitter = .fraction(brightness: 0.1, contrast: 0.1, saturation: 0.05, hue: 0.02) // More intense color changes for varied lighting/paper
        options.blur = .pixels(range: 0.0...1.5)        // Add blur for camera shake/low-res scans
        options.perspectiveWarp = .fraction(range: 0.0...0.05) // Add perspective warp for angled scans
        options.translation = .fraction(range: -0.1...0.1) // Add translation for off-center documents
        return options
    }

    private func trainModel(augmentations: MLImageClassifier.DataSource.AugmentationOptions?, epochs: Int, label: String) async throws -> MLImageClassifier {
        print("  Training \(label) model for \(epochs) epochs...")
        let parameters = MLImageClassifier.ModelParameters(
            validationData: validationData,
            augmentationOptions: augmentations,
            epochs: epochs,
            shuffle: true,
            learningRate: 0.001,
            progressHandler: { context in
                if let metrics = context.metrics {
                    // print("  \(label) Epoch \(metrics.epoch): Train Acc = \(String(format: "%.2f", metrics.trainingAccuracy * 100))%, Val Acc = \(String(format: "%.2f", metrics.validationAccuracy * 100))%")
                }
            }
        )
        let model = try await MLImageClassifier.train(
            trainingData: trainingData,
            parameters: parameters
        )
        print("  \(label) training complete.")
        return model
    }
}

// MARK: - Main Execution Logic (Example)

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func runDocumentScannerAdaptiveExperiment() async throws {
    // --- IMPORTANT: Replace with your actual data sources ---
    let dummyTrainingData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_doc_training"))
    let dummyValidationData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_doc_validation"))
    
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_doc_training/classA"), withIntermediateDirectories: true, attributes: nil)
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_doc_validation/classA"), withIntermediateDirectories: true, attributes: nil)

    let trainer = DocumentClassifierTrainer(trainingData: dummyTrainingData, validationData: dummyValidationData)
    let finalModel = try await trainer.trainAdaptiveModel()

    print("\n--- Adaptive Training Complete ---")
    print("The final model was trained with an adaptive strategy.")
    
    // Clean up dummy directories
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_doc_training"))
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_doc_validation"))
}

// To run this code:
// Task {
//     try await runDocumentScannerAdaptiveExperiment()
// }
