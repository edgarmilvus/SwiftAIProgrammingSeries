
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Accelerate

struct HighPerformanceVectorMath {
    /// Optimized cosine similarity using the Accelerate framework.
    static func cosineSimilarity(between vectorA: [Float], and vectorB: [Float]) throws -> Float {
        guard vectorA.count == vectorB.count else {
            throw VectorError.dimensionMismatch
        }
        
        let n = vDSP_Length(vectorA.count)
        guard n > 0 else { return 0.0 }
        
        // 1. Calculate Dot Product using vDSP_dotpr
        var dotProduct: Float = 0.0
        vDSP_dotpr(vectorA, 1, vectorB, 1, &dotProduct, n)
        
        // 2. Calculate Magnitude A using vDSP_svesq (Sum of Squares)
        var sumSquaresA: Float = 0.0
        vDSP_svesq(vectorA, 1, &sumSquaresA, n)
        
        // 3. Calculate Magnitude B using vDSP_svesq
        var sumSquaresB: Float = 0.0
        vDSP_svesq(vectorB, 1, &sumSquaresB, n)
        
        let magA = sqrt(sumSquaresA)
        let magB = sqrt(sumSquaresB)
        
        guard magA > 0, magB > 0 else { return 0.0 }
        
        return dotProduct / (magA * magB)
    }
}

// MARK: - Benchmarking Utility
struct VectorBenchmark {
    static func runBenchmark(dimensions: Int, iterations: Int) {
        let v1 = (0..<dimensions).map { _ in Float.random(in: -1...1) }
        let v2 = (0..<dimensions).map { _ in Float.random(in: -1...1) }
        
        print("Benchmarking \(iterations) iterations with \(dimensions) dimensions...")
        
        // Benchmark Loop-based
        let startLoop = CFAbsoluteTimeGetCurrent()
        for _ in 0..<iterations {
            _ = try? VectorMath.cosineSimilarity(between: v1, and: v2)
        }
        let endLoop = CFAbsoluteTimeGetCurrent()
        print("Standard Loop: \(endLoop - startLoop) seconds")
        
        // Benchmark Accelerate-based
        let startAcc = CFAbsoluteTimeGetCurrent()
        for _ in 0..<iterations {
            _ = try? HighPerformanceVectorMath.cosineSimilarity(between: v1, and: v2)
        }
        let endAcc = CFAbsoluteTimeGetCurrent()
        print("Accelerate (SIMD): \(endAcc - startAcc) seconds")
        
        let speedup = (endLoop - startLoop) / (endAcc - startAcc)
        print("🚀 Speedup factor: \(String(format: "%.2f", speedup))x")
    }
}

// Run Benchmark
VectorBenchmark.runBenchmark(dimensions: 1536, iterations: 1000)
