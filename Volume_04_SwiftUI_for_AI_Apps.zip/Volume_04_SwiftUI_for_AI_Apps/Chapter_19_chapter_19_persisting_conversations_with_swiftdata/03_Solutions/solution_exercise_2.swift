
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import SwiftData
import Foundation

// MARK: - SwiftData Models (from Exercise 1, repeated for completeness)

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Conversation {
    var id: UUID
    var title: String
    var creationDate: Date
    @Relationship(deleteRule: .cascade, inverse: \Message.conversation)
    var messages: [Message]

    init(id: UUID = UUID(), title: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.creationDate = creationDate
        self.messages = []
    }
}

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Message {
    var id: UUID
    var content: String
    var timestamp: Date
    var isFromUser: Bool
    var conversation: Conversation? // Inverse relationship

    init(id: UUID = UUID(), content: String, timestamp: Date = Date(), isFromUser: Bool) {
        self.id = id
        self.content = content
        self.timestamp = timestamp
        self.isFromUser = isFromUser
    }
}

// MARK: - SwiftUI Views

@available(iOS 18.0, macOS 15.0, *)
struct ConversationDetailView: View { // Renamed from ChatView for clarity
    @Environment(\.modelContext) private var modelContext
    let conversation: Conversation

    // Query messages specifically for this conversation, ordered by timestamp
    // The filter predicate ensures only messages belonging to 'conversation' are shown
    @Query private var messages: [Message]
    @State private var newMessageContent: String = ""

    init(conversation: Conversation) {
        self.conversation = conversation
        _messages = Query(
            filter: #Predicate<Message> { $0.conversation?.id == conversation.id },
            sort: \.timestamp
        )
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                List {
                    ForEach(messages) { message in
                        HStack {
                            if message.isFromUser {
                                Spacer()
                                Text(message.content)
                                    .padding()
                                    .background(Color.blue.opacity(0.8))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            } else {
                                Text(message.content)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                Spacer()
                            }
                        }
                        .listRowSeparator(.hidden)
                        .id(message.id) // Needed for ScrollViewReader
                    }
                    .onDelete(perform: deleteMessages) // Optional: Delete individual messages
                }
                .listStyle(.plain)
                .onChange(of: messages.count) { oldVal, newVal in
                    // Scroll to the latest message when a new one is added
                    if newVal > oldVal, let lastMessage = messages.last {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }

            HStack {
                TextField("Type a message...", text: $newMessageContent)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    guard !newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
                    let message = Message(content: newMessageContent, isFromUser: true)
                    conversation.messages.append(message)
                    modelContext.insert(message)
                    newMessageContent = ""
                }
                .disabled(newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding()
        }
        .navigationTitle(conversation.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func deleteMessages(at offsets: IndexSet) {
        for index in offsets {
            let messageToDelete = messages[index]
            modelContext.delete(messageToDelete)
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \.creationDate, order: .reverse) private var conversations: [Conversation]
    @State private var showingNewConversationSheet = false

    var body: some View {
        NavigationStack {
            List {
                ForEach(conversations) { conversation in
                    NavigationLink(destination: ConversationDetailView(conversation: conversation)) {
                        Text(conversation.title)
                    }
                }
                .onDelete(perform: deleteConversations) // Delete conversations
                if conversations.isEmpty {
                    ContentUnavailableView("No Conversations", systemImage: "bubble.left.and.bubble.right.fill", description: Text("Start a new chat to see it appear here."))
                }
            }
            .navigationTitle("AI Chats")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingNewConversationSheet = true
                    } label: {
                        Label("New Conversation", systemImage: "plus.circle.fill")
                    }
                }
            }
            .sheet(isPresented: $showingNewConversationSheet) {
                NewConversationView()
            }
        }
    }

    private func deleteConversations(at offsets: IndexSet) {
        for index in offsets {
            let conversationToDelete = conversations[index]
            modelContext.delete(conversationToDelete)
        }
    }
}

// NewConversationView and AIApp (from Exercise 1) remain unchanged.
// For brevity, not repeated here but would be part of the full app.
// @available(iOS 18.0, macOS 15.0, *) @main struct AIApp: App { ... }
