
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

// Continuation of the example in the same file or a new one.

/// A simple linear classifier for voice intent recognition.
/// Inherits from `MLXNN.Module` to manage parameters and define the forward pass.
@available(iOS 17.0, macOS 14.0, *)
class VoiceIntentClassifier: MLXNN.Module {
    let linear: MLXNN.Linear

    /// Initializes the classifier with input and output feature dimensions.
    /// - Parameters:
    ///   - inputFeatures: The number of features in the input audio vector.
    ///   - outputIntents: The number of possible intents to classify.
    init(inputFeatures: Int, outputIntents: Int) {
        // MLXNN.Linear is a standard fully connected layer.
        // It automatically initializes its weights and biases.
        self.linear = MLXNN.Linear(inputSize: inputFeatures, outputSize: outputIntents)
        super.init() // Call the superclass initializer
    }

    /// Defines the forward pass of the model.
    /// - Parameter input: An `MLXArray` representing the input feature vector.
    /// - Returns: An `MLXArray` representing the raw logits (scores) for each intent.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // The linear layer performs: input * weights + bias
        return linear(input)
    }
}

// Example usage of the VoiceIntentClassifier:
@available(iOS 17.0, macOS 14.0, *)
extension BasicMLXExample {
    func runModelExample() {
        print("\n--- MLX Model Example: VoiceIntentClassifier ---")

        let inputFeatures = 5
        let outputIntents = 3

        // 5. Initializing and Using the Model
        // Create an instance of our custom module.
        let model = VoiceIntentClassifier(inputFeatures: inputFeatures, outputIntents: outputIntents)
        print("\n5. Model Initialized:")
        print("   Model parameters: \(model.parameters())") // Shows randomly initialized weights/biases

        // Generate dummy input (same as before)
        let audioFeaturesSwift: [Float] = [0.1, 0.5, 0.2, 0.8, 0.3]
        let inputTensor = MLXArray(audioFeaturesSwift, [1, inputFeatures])

        // Perform a forward pass through the model
        let logits = model(inputTensor)
        logits.eval() // Evaluate to get the actual logits
        print("\n   Model Output (Logits): \(logits)")

        // Apply softmax to get probabilities
        let probabilities = softMax(logits, axis: -1)
        probabilities.eval()
        print("   Model Output (Probabilities): \(probabilities)")

        let resultSwiftArray = probabilities.asArray(Float.self)
        if let maxIndex = resultSwiftArray.first?.maxIndex() {
            let intents = ["Play Music", "Set Timer", "Call Contact"]
            print("   Predicted Intent: \(intents[maxIndex])")
        }
    }
}

// To run this model example:
/*
if #available(iOS 17.0, macOS 14.0, *) {
    let example = BasicMLXExample()
    example.runBasicExample()
    example.runModelExample() // Call the new model example
} else {
    print("MLX requires iOS 17.0+ or macOS 14.0+.")
}
*/
