
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Vision
import UIKit

@available(iOS 18.0, *)
actor VisionProcessor {
    private var currentImageBuffer: CGImage? // Example of shared state
    private let classificationRequest = VNClassifyImageRequest()

    func updateImage(_ image: UIImage) throws {
        guard let cgImage = image.cgImage else {
            throw ImageClassifier.ImageClassifierError.invalidImage
        }
        self.currentImageBuffer = cgImage
    }

    func performClassification() async throws -> [VNClassificationObservation] {
        guard let image = currentImageBuffer else {
            throw ImageClassifier.ImageClassifierError.invalidImage
        }
        let handler = VNImageRequestHandler(cgImage: image, options: [:])

        try await withCheckedThrowingContinuation { continuation in
            do {
                try handler.perform([classificationRequest])
                if let observations = classificationRequest.results as? [VNClassificationObservation] {
                    continuation.resume(returning: observations)
                } else {
                    continuation.resume(throwing: ImageClassifier.ImageClassifierError.noResults)
                }
            } catch {
                continuation.resume(throwing: ImageClassifier.ImageClassifierError.classificationFailed(error))
            }
        }
    }
}

// Usage example:
@available(iOS 18.0, *)
func manageConcurrentClassifications(image1: UIImage, image2: UIImage) async {
    let processor = VisionProcessor()

    // Task 1: Classify image1
    async let result1: [VNClassificationObservation]? = Task {
        try await processor.updateImage(image1)
        return try await processor.performClassification()
    }.value

    // Task 2: Classify image2
    async let result2: [VNClassificationObservation]? = Task {
        try await processor.updateImage(image2) // This will wait for processor to be free from Task 1's updateImage
        return try await processor.performClassification()
    }.value

    do {
        if let classifications1 = await result1 {
            print("Classifications for Image 1: \(classifications1.map(\.identifier))")
        }
        if let classifications2 = await result2 {
            print("Classifications for Image 2: \(classifications2.map(\.identifier))")
        }
    } catch {
        print("Error in concurrent classification: \(error)")
    }
}
