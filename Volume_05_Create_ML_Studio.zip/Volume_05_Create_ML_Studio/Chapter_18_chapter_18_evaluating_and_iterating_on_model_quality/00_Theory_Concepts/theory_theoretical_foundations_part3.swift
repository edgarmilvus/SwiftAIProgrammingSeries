
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
@Observable
class ModelEvaluationViewModel {
    var trainingProgress: Double = 0.0
    var currentMetrics: EvaluationReport?
    var evaluationHistory: [EvaluationReport] = []
    var isTraining: Bool = false
    var currentIterationID: String?

    func startTrainingAndEvaluation(trainingData: MLDataSet, evaluationData: MLDataSet) async {
        isTraining = true
        currentIterationID = UUID().uuidString
        trainingProgress = 0.0
        currentMetrics = nil

        do {
            let evaluator = MLModelEvaluator(model: MLModel(), evaluationDataSet: evaluationData)
            
            // Simulate training progress updates
            for i in 1...10 {
                try await Task.sleep(for: .milliseconds(500))
                trainingProgress = Double(i) / 10.0
                print("Training progress: \(String(format: "%.0f", trainingProgress * 100))%")
            }
            
            let trainedModel = try await evaluator.trainModel(with: trainingData)
            
            let updatedEvaluator = MLModelEvaluator(model: trainedModel, evaluationDataSet: evaluationData)
            let report = try await updatedEvaluator.evaluateModel()
            
            self.currentMetrics = report
            self.evaluationHistory.append(report)
            print("Iteration \(currentIterationID!): \(report)")
            
        } catch {
            print("Error during training/evaluation: \(error)")
        }
        isTraining = false
    }
}

@available(iOS 18.0, *)
struct ModelEvaluationView: View {
    @State private var viewModel = ModelEvaluationViewModel()

    var body: some View {
        VStack(spacing: 20) {
            Text("Model Evaluation Dashboard")
                .font(.largeTitle)
                .bold()

            if viewModel.isTraining {
                ProgressView(value: viewModel.trainingProgress) {
                    Text("Training Model...")
                } currentValueLabel: {
                    Text("\(String(format: "%.0f", viewModel.trainingProgress * 100))%")
                }
                .progressViewStyle(.linear)
                .padding()
            } else {
                Button("Start New Iteration") {
                    Task {
                        await viewModel.startTrainingAndEvaluation(trainingData: MLDataSet(), evaluationData: MLDataSet())
                    }
                }
                .buttonStyle(.borderedProminent)
            }

            if let metrics = viewModel.currentMetrics {
                VStack(alignment: .leading) {
                    Text("Current Iteration Metrics:")
                        .font(.headline)
                    Text("Accuracy: \(String(format: "%.2f", metrics.accuracy))")
                    Text("Precision: \(String(format: "%.2f", metrics.precision))")
                    Text("Recall: \(String(format: "%.2f", metrics.recall))")
                }
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(10)
            }

            if !viewModel.evaluationHistory.isEmpty {
                VStack(alignment: .leading) {
                    Text("Evaluation History:")
                        .font(.headline)
                    ForEach(viewModel.evaluationHistory.indices, id: \.self) { index in
                        let report = viewModel.evaluationHistory[index]
                        Text("Run \(index + 1): Acc \(String(format: "%.2f", report.accuracy))")
                    }
                }
                .padding()
            }
        }
        .padding()
    }
}

// To run this in a SwiftUI preview or app:
/*
@available(iOS 18.0, *)
#Preview {
    ModelEvaluationView()
}
*/
