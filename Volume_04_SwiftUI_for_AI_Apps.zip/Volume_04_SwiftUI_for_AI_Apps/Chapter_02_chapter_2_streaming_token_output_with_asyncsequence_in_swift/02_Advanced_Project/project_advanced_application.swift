
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Assume iOS 18.0 for latest concurrency features and potential SwiftUI integration
@available(iOS 18.0, *)
import Foundation

// MARK: - 1. Swift Package Manager Dependencies (Conceptual)
// In a real project, these would be defined in your Package.swift file.
// For this example, we're simulating an AI model client internally for self-containment.
/*
import PackageDescription

let package = Package(
    name: "MeetingSummarizerApp",
    platforms: [.iOS(.v18), .macOS(.v15)], // Specify target platforms
    products: [
        .library(
            name: "AISummarizationModule",
            targets: ["AISummarizationModule"]),
    ],
    dependencies: [
        // A hypothetical package for interacting with an AI model API.
        // In a real scenario, this could be a wrapper around a specific LLM provider's SDK
        // (e.g., OpenAI-Swift, GoogleGenerativeAI-Swift, or a custom HTTP client).
        // For this advanced application, we implement a mock client directly
        // to focus on the AsyncSequence implementation details without external setup.
        // .package(url: "https://github.com/some-org/AIModelClient.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "AISummarizationModule",
            dependencies: [
                // .product(name: "AIModelClient", package: "AIModelClient"),
            ]
        ),
    ]
)
*/

// MARK: - 2. Custom Error Types for Token Streaming
/// Defines specific errors that can occur during the AI token streaming process.
/// This provides clear, actionable error information to the consuming application.
enum TokenStreamError: Error, LocalizedError {
    /// Encapsulates underlying network issues (e.g., no internet, timeout).
    case networkError(Error)
    /// Errors reported by the AI model itself (e.g., input too long, invalid API key).
    case modelError(String)
    /// The token stream was explicitly cancelled by the user or system.
    case cancelled
    /// Any other unexpected error during streaming.
    case unknown

    /// Provides a user-friendly description for each error type.
    var errorDescription: String? {
        switch self {
        case .networkError(let error):
            return "Network error during token streaming: \(error.localizedDescription)"
        case .modelError(let message):
            return "AI model error: \(message)"
        case .cancelled:
            return "Token stream cancelled by user or system."
        case .unknown:
            return "An unknown error occurred during token streaming."
        }
    }
}

// MARK: - 3. The Core AsyncSequence for Streaming Summary Tokens
/// `SummaryTokenAsyncSequence` is a custom `AsyncSequence` that simulates streaming
/// tokens from an AI model. This advanced implementation allows for precise control
/// over token generation, delays, and error injection, making it suitable for
/// robust production environments.
struct SummaryTokenAsyncSequence: AsyncSequence {
    typealias Element = String // Each element yielded by the sequence is a String token.

    private let textToSummarize: String // The original text provided for summarization.
    private let simulateErrorAfterTokens: Int? // Optional: if set, an error is thrown after this many tokens.
    private let simulateNetworkDelay: TimeInterval // The delay between yielding each token.
    private let simulatedSummary: String // The full summary string to be tokenized and streamed.

    /// Initializes the `SummaryTokenAsyncSequence` with simulation parameters.
    /// - Parameters:
    ///   - textToSummarize: The input text that would be sent to the AI model.
    ///   - simulatedSummary: The full summary string to be tokenized and streamed.
    ///   - simulateErrorAfterTokens: If non-nil, an error will be thrown after this many tokens.
    ///   - simulateNetworkDelay: The delay (in seconds) between each token emission to simulate network latency.
    init(textToSummarize: String, simulatedSummary: String, simulateErrorAfterTokens: Int? = nil, simulateNetworkDelay: TimeInterval = 0.05) {
        self.textToSummarize = textToSummarize
        self.simulatedSummary = simulatedSummary
        self.simulateErrorAfterTokens = simulateErrorAfterTokens
        self.simulateNetworkDelay = simulateNetworkDelay
    }

    /// Creates and returns an `AsyncIterator` for this sequence.
    /// This method is called once when the `for await` loop begins.
    func makeAsyncIterator() -> SummaryTokenAsyncIterator {
        SummaryTokenAsyncIterator(
            fullSummary: simulatedSummary,
            simulateErrorAfterTokens: simulateErrorAfterTokens,
            simulateNetworkDelay: simulateNetworkDelay
        )
    }
}

// MARK: - 4. The AsyncIterator for Generating Tokens
/// `SummaryTokenAsyncIterator` is the actual worker that generates and yields tokens
/// one by one. It implements `AsyncIteratorProtocol`, handling asynchronous operations,
/// simulating network delays, injecting errors, and crucially, respecting `Task` cancellation.
struct SummaryTokenAsyncIterator: AsyncIteratorProtocol {
    typealias Element = String // The type of element this iterator produces.

    private let tokens: [String] // Pre-tokenized summary for simulation.
    private var currentIndex: Int = 0 // Tracks the current token to yield.
    private let simulateErrorAfterTokens: Int? // Configuration for error injection.
    private let simulateNetworkDelay: TimeInterval // Configuration for network delay simulation.

    /// Initializes the iterator with the full summary and simulation parameters.
    /// - Parameters:
    ///   - fullSummary: The complete summary text to be broken into tokens.
    ///   - simulateErrorAfterTokens: After how many tokens should an error be simulated.
    ///   - simulateNetworkDelay: The delay between yielding each token.
    init(fullSummary: String, simulateErrorAfterTokens: Int?, simulateNetworkDelay: TimeInterval) {
        // Simple tokenization: split by space and append a space for readability.
        // In a real LLM, tokens are often sub-word units (e.g., "the", " quick", " brown").
        self.tokens = fullSummary.split(separator: " ").map { String($0) + " " }
        self.simulateErrorAfterTokens = simulateErrorAfterTokens
        self.simulateNetworkDelay = simulateNetworkDelay
    }

    /// Advances to the next element in the sequence and returns it.
    /// This method is `async` because it performs asynchronous operations (e.g., `Task.sleep`).
    /// It can throw `TokenStreamError` to propagate issues from the simulated model/network.
    mutating func next() async throws -> String? {
        // CRITICAL: Check for task cancellation early and often.
        // If the task has been cancelled, throw a CancellationError or a custom error.
        // This ensures the stream is responsive to external cancellation requests.
        if Task.isCancelled {
            throw TokenStreamError.cancelled
        }

        // Simulate a network delay for each token.
        // This demonstrates how real-time streaming delays or backpressure would be handled.
        try await Task.sleep(for: .milliseconds(Int(simulateNetworkDelay * 1000)))

        // Simulate an error condition if specified.
        // This shows how an underlying API error would be propagated.
        if let errorTokenCount = simulateErrorAfterTokens, currentIndex >= errorTokenCount {
            // Only throw the error once, then end the stream.
            if currentIndex == errorTokenCount {
                print("--- Simulating network error after \(errorTokenCount) tokens ---")
                throw TokenStreamError.networkError(URLError(.notConnectedToInternet))
            }
            return nil // After error, the stream should effectively end.
        }

        // Check if there are more tokens to yield.
        guard currentIndex < tokens.count else {
            return nil // The stream is exhausted; no more tokens.
        }

        // Get the next token and advance the index for the next call.
        let token = tokens[currentIndex]
        currentIndex += 1
        return token
    }
}

// MARK: - 5. AI Summarization Service
/// `AISummarizationService` acts as the interface to the AI model for the application.
/// It encapsulates the logic for initiating a summary request and returning
/// an `AsyncSequence` for real-time token streaming, abstracting away the
/// underlying streaming mechanism.
class AISummarizationService {
    /// A mock AI model response. In a real application, this would be the full
    /// summary text received from a network call to an actual AI model API.
    private let mockLongSummary = """
    The recent quarterly earnings report from TechCorp shows a mixed but generally positive outlook.
    Revenue increased by 15% year-over-year, primarily driven by strong performance in their cloud computing division.
    However, net profit saw a slight decline due to increased R&D investments in their new AI initiatives.
    The CEO expressed optimism about future growth, particularly in the AI sector, and announced plans
    for aggressive expansion into new markets. Investors reacted cautiously, with stock prices remaining stable.
    """

    /// Initiates a summary generation request for the given text.
    /// This method returns an `AsyncSequence` that allows the caller to consume
    /// summary tokens as they become available.
    /// - Parameters:
    ///   - text: The input text (e.g., a meeting transcript) to be summarized by the AI.
    ///   - simulateError: If `true`, the token stream will simulate an error after a few tokens.
    ///   - simulateNetworkDelay: The delay (in seconds) between each token to simulate network latency.
    /// - Returns: An `AsyncSequence` of `String` tokens representing the streamed summary.
    ///            The sequence can throw `TokenStreamError` if issues occur during streaming.
    func summarize(text: String, simulateError: Bool = false, simulateNetworkDelay: TimeInterval = 0.05) -> SummaryTokenAsyncSequence {
        // In a real application, 'text' would be sent to a backend AI model via a network request.
        // The response would typically be an `AsyncSequence` or a similar streamable format
        // provided by the AI model's SDK (e.g., gRPC stream, Server-Sent Events).

        // For this example, we're simulating the AI model's response and tokenization
        // by returning our custom `SummaryTokenAsyncSequence`.
        let errorAfterTokens: Int? = simulateError ? 10 : nil // Simulate error after 10 tokens if requested.

        return SummaryTokenAsyncSequence(
            textToSummarize: text,
            simulatedSummary: mockLongSummary,
            simulateErrorAfterTokens: errorAfterTokens,
            simulateNetworkDelay: simulateNetworkDelay
        )
    }
}

// MARK: - 6. Real-World Apple App Context: Smart Meeting Summarizer (Demonstration)
/// This `main` struct demonstrates how `AISummarizationService` would be used
/// within an actual Apple application, such as a "Smart Meeting Summarizer".
/// It shows how to consume the `AsyncSequence` for streaming AI output,
/// handling success, error, and cancellation scenarios.
@main
struct MeetingSummarizerApp {
    static func main() async {
        let service = AISummarizationService()
        let meetingTranscript = """
        Participants discussed the Q3 financial results, noting a 15% revenue increase driven by cloud services.
        However, R&D expenses for new AI initiatives led to a slight profit dip. The CEO confirmed continued
        investment in AI and market expansion. Stock performance was stable. The board also approved a new
        marketing campaign targeting emerging markets in Asia and South America, expected to launch in Q4.
        """

        print("--- Starting AI Summary Stream (Success Scenario) ---")
        await processSummaryStream(service: service, transcript: meetingTranscript, simulateError: false)

        print("\n--- Starting AI Summary Stream (Error Scenario) ---")
        await processSummaryStream(service: service, transcript: meetingTranscript, simulateError: true)

        print("\n--- Starting AI Summary Stream (Cancellation Scenario) ---")
        await processSummaryStreamWithCancellation(service: service, transcript: meetingTranscript)
    }

    /// Processes and prints tokens from the summary stream, demonstrating basic consumption and error handling.
    /// In a SwiftUI app, the `receivedSummary` would typically be bound to a `@State` property
    /// to update the UI in real-time.
    /// - Parameters:
    ///   - service: The `AISummarizationService` instance to use.
    ///   - transcript: The meeting transcript text to send for summarization.
    ///   - simulateError: A flag to instruct the service to simulate an error in the stream.
    static func processSummaryStream(service: AISummarizationService, transcript: String, simulateError: Bool) async {
        let summaryStream = service.summarize(text: transcript, simulateError: simulateError)
        var receivedSummary = ""
        do {
            // The `for try await` loop is the idiomatic way to consume an AsyncSequence.
            for try await token in summaryStream {
                print("Received token: '\(token.trimmingCharacters(in: .whitespacesAndNewlines))'")
                receivedSummary += token
                // In a SwiftUI View, you would update a @State property here:
                // e.g., `DispatchQueue.main.async { self.displayedSummary += token }`
                // (though often `Task` on the main actor handles this implicitly)
            }
            print("--- Full Summary Received (Success): ---")
            print(receivedSummary.trimmingCharacters(in: .whitespacesAndNewlines))
        } catch {
            // Catch and handle specific `TokenStreamError` types for granular feedback.
            if let streamError = error as? TokenStreamError {
                print("--- Stream Error: \(streamError.localizedDescription) ---")
            } else {
                print("--- Unexpected Error: \(error.localizedDescription) ---")
            }
        }
        print("--------------------------------------------------\n")
    }

    /// Demonstrates how to cancel an ongoing summary stream using `Task.cancel()`.
    /// This is crucial for resource management and user responsiveness in interactive applications.
    /// - Parameters:
    ///   - service: The `AISummarizationService` instance.
    ///   - transcript: The meeting transcript to summarize.
    static func processSummaryStreamWithCancellation(service: AISummarizationService, transcript: String) async {
        // Use a slightly longer delay to make cancellation more noticeable.
        let summaryStream = service.summarize(text: transcript, simulateError: false, simulateNetworkDelay: 0.1)
        var receivedSummary = ""

        // Create a parent Task that can be cancelled.
        let processingTask = Task {
            do {
                for try await token in summaryStream {
                    print("Received token: '\(token.trimmingCharacters(in: .whitespacesAndNewlines))'")
                    receivedSummary += token
                    // Simulate a condition where the user might cancel after a few tokens
                    // (e.g., if the user closes the summary view).
                    if receivedSummary.count > 50 && !Task.isCancelled {
                        print("--- Internal logic decided to request cancellation ---")
                        // Request cancellation. The `AsyncIterator`'s `next()` method
                        // will detect this via `Task.isCancelled` or `try Task.checkCancellation()`.
                        Task.cancel()
                        break // Break the loop immediately after requesting cancellation.
                    }
                }
                // This line should ideally not be reached if cancellation was effective.
                print("--- Full Summary Received (Cancellation should have prevented this): ---")
                print(receivedSummary.trimmingCharacters(in: .whitespacesAndNewlines))
            } catch {
                // `Task.isCancelled` can be checked to distinguish explicit cancellation
                // from other errors.
                if Task.isCancelled {
                    print("--- Stream was explicitly cancelled. ---")
                } else if let streamError = error as? TokenStreamError {
                    print("--- Stream Error during cancellation test: \(streamError.localizedDescription) ---")
                } else {
                    print("--- Unexpected Error during cancellation test: \(error.localizedDescription) ---")
                }
            }
        }

        // In a real UI, a button tap or view disappearance would trigger `processingTask.cancel()`.
        // Here, we simulate it after a short delay to allow some tokens to stream.
        try? await Task.sleep(for: .seconds(0.8))
        if !processingTask.isCancelled { // Ensure we don't try to cancel an already cancelled task.
            print("--- Explicitly cancelling the processing task from an external scope ---")
            processingTask.cancel()
        }

        // Wait for the processing task to finish (either by completing or by throwing CancellationError).
        await processingTask.value
        print("--------------------------------------------------\n")
    }
}
