
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation
import Combine

// MARK: - 1. Authenticated AI Client Protocol

/// A protocol for an AI client that requires authentication and manages a session.
@available(iOS 18.0, macOS 15.0, *)
protocol AuthenticatedAIClientProtocol: AnyObject { // Must be a class protocol for reference semantics
    var isAuthenticated: Bool { get }
    var sessionExpirationDate: Date? { get }

    /// Attempts to authenticate the client.
    /// - Returns: True if authentication was successful, false otherwise.
    func authenticate() async throws -> Bool

    /// Performs a secure AI operation.
    /// - Parameter input: The input for the operation.
    /// - Returns: The result of the operation.
    func performSecureOperation(input: String) async throws -> String
}

// MARK: - 2. Mock Authenticated AI Client

@available(iOS 18.0, macOS 15.0, *)
class MockAuthenticatedAIClient: AuthenticatedAIClientProtocol {
    private var _isAuthenticated: Bool = false
    private var _sessionExpirationDate: Date?

    // Public properties to reflect internal state, computed based on expiration
    var isAuthenticated: Bool {
        // If there's an expiration date and it's in the future, and we were authenticated
        if let expiration = _sessionExpirationDate, expiration > Date() {
            return _isAuthenticated
        } else {
            // Otherwise, session is invalid/expired
            if _isAuthenticated { // If it was authenticated before, print expiration
                print("Session expired at \(_sessionExpirationDate?.formatted() ?? "N/A").")
            }
            _isAuthenticated = false // Mark as unauthenticated
            _sessionExpirationDate = nil
            return false
        }
    }

    var sessionExpirationDate: Date? { _sessionExpirationDate }

    func authenticate() async throws -> Bool {
        print("Attempting authentication...")
        try await Task.sleep(for: .seconds(2)) // Simulate network request
        let success = Bool.random() // Simulate random success/failure
        if success {
            _isAuthenticated = true
            _sessionExpirationDate = Date().addingTimeInterval(30) // Session valid for 30 seconds
            print("Authentication successful. Session expires at \(_sessionExpirationDate!)")
        } else {
            _isAuthenticated = false
            _sessionExpirationDate = nil
            print("Authentication failed.")
            throw AuthenticationError.invalidCredentials
        }
        return success
    }

    func performSecureOperation(input: String) async throws -> String {
        guard isAuthenticated else {
            throw AuthenticationError.sessionExpired
        }
        print("Performing secure operation with input: \(input)")
        try await Task.sleep(for: .seconds(1.5)) // Simulate AI processing
        if input.lowercased().contains("fail") {
            throw AIError.processingFailed(reason: "Input triggered a simulated failure.")
        }
        return "Secure AI result for '\(input)': Processed by authenticated client. (Expires: \(_sessionExpirationDate?.formatted() ?? "N/A"))"
    }

    enum AuthenticationError: Error, LocalizedError {
        case invalidCredentials
        case sessionExpired
        var errorDescription: String? {
            switch self {
            case .invalidCredentials: return "Invalid username or password."
            case .sessionExpired: return "Session expired. Please re-authenticate."
            }
        }
    }

    enum AIError: Error, LocalizedError {
        case processingFailed(reason: String)
        var errorDescription: String? {
            switch self {
            case .processingFailed(let reason): return "AI processing failed: \(reason)"
            }
        }
    }
}

// MARK: - 3. Environment Key for the Optional Authenticated Client

@available(iOS 18.0, macOS 15.0, *)
private struct AuthenticatedAIClientEnvironmentKey: EnvironmentKey {
    // Default is nil, indicating no client is authenticated by default
    static let defaultValue: (any AuthenticatedAIClientProtocol)? = nil
}

@available(iOS 18.0, macOS 15.0, *)
extension EnvironmentValues {
    var authenticatedAIClient: (any AuthenticatedAIClientProtocol)? {
        get { self[AuthenticatedAIClientEnvironmentKey.self] }
        set { self[AuthenticatedAIClientEnvironmentKey.self] = newValue }
    }
}

// MARK: - 4. AIClientAuthenticator (ObservableObject)

@available(iOS 18.0, macOS 15.0, *)
final class AIClientAuthenticator: ObservableObject {
    // The actual client instance, which is a class
    let client: MockAuthenticatedAIClient = MockAuthenticatedAIClient()
    
    // Published properties to reflect the client's state for UI
    @Published private(set) var isAuthenticated: Bool = false
    @Published private(set) var authenticationError: Error?
    
    // This is the property that will be provided to the environment.
    // It's optional because the client might not always be authenticated.
    @Published private(set) var currentAuthenticatedClient: (any AuthenticatedAIClientProtocol)?

    private var cancellables = Set<AnyCancellable>()

    init() {
        // Monitor client's authentication status changes periodically
        Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                guard let self = self else { return }
                let wasAuthenticated = self.isAuthenticated
                self.isAuthenticated = self.client.isAuthenticated // Check client's internal state
                
                // If authentication status changed, update currentAuthenticatedClient
                if self.isAuthenticated && self.currentAuthenticatedClient == nil {
                    // Became authenticated or re-authenticated
                    self.currentAuthenticatedClient = self.client
                    print("Client became authenticated and provided to environment.")
                } else if !self.isAuthenticated && self.currentAuthenticatedClient != nil {
                    // Session expired or became unauthenticated
                    self.currentAuthenticatedClient = nil // Remove client from environment
                    print("Session expired or client became unauthenticated, removed from environment.")
                }
            }
            .store(in: &cancellables)

        // Initial authentication attempt on app launch
        Task { await performAuthentication() }
    }

    @MainActor
    func performAuthentication() async {
        authenticationError = nil
        do {
            if try await client.authenticate() {
                isAuthenticated = true
                currentAuthenticatedClient = client // Make client available to environment
            } else {
                isAuthenticated = false
                currentAuthenticatedClient = nil
            }
        } catch {
            isAuthenticated = false
            currentAuthenticatedClient = nil
            authenticationError = error
            print("Authentication failed with error: \(error.localizedDescription)")
        }
    }
}

// MARK: - 5. AIProtectedFeatureView

@available(iOS 18.0, macOS 15.0, *)
struct AIProtectedFeatureView: View {
    @Environment(\.authenticatedAIClient) private var authenticatedAIClient: (any AuthenticatedAIClientProtocol)?
    @EnvironmentObject private var authenticator: AIClientAuthenticator // To trigger re-authentication

    @State private var inputText: String = "Please summarize this document."
    @State private var operationResult: String = "No operation performed yet."
    @State private var isLoading: Bool = false
    @State private var operationError: Error?

    var body: some View {
        VStack {
            Group {
                if let client = authenticatedAIClient {
                    Text("AI Client Status: Authenticated")
                        .foregroundColor(.green)
                    if let expiration = client.sessionExpirationDate {
                        Text("Session expires: \(expiration.formatted(date: .omitted, time: .standard))")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                } else {
                    Text("AI Client Status: Not Authenticated")
                        .foregroundColor(.red)
                    if let authError = authenticator.authenticationError {
                        Text("Authentication Error: \(authError.localizedDescription)")
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                    Button("Re-authenticate") {
                        Task { await authenticator.performAuthentication() }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isLoading)
                    .padding(.top, 5)
                }
            }
            .padding(.bottom)

            TextEditor(text: $inputText)
                .frame(height: 100)
                .border(Color.gray.opacity(0.5), width: 1)
                .padding(.horizontal)
                .disabled(authenticatedAIClient == nil || isLoading)
                .accessibilityIdentifier("secureOperationInputTextEditor")

            Button("Perform Secure AI Operation") {
                performOperation()
            }
            .buttonStyle(.borderedProminent)
            .disabled(authenticatedAIClient == nil || isLoading || inputText.isEmpty)
            .padding(.vertical)
            .accessibilityIdentifier("performSecureOperationButton")

            if isLoading {
                ProgressView("Performing operation...")
                    .padding()
            }
            
            if let opError = operationError {
                Text("Operation Error: \(opError.localizedDescription)")
                    .foregroundColor(.red)
                    .padding()
            } else if !operationResult.isEmpty {
                ScrollView {
                    Text(operationResult)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)
                }
                .accessibilityIdentifier("operationResultScrollView")
            }
            Spacer()
        }
        .navigationTitle("Protected AI Feature")
        .padding()
    }

    private func performOperation() {
        guard let client = authenticatedAIClient else {
            operationError = MockAuthenticatedAIClient.AuthenticationError.sessionExpired
            return
        }
        isLoading = true
        operationError = nil
        operationResult = ""
        Task {
            do {
                let result = try await client.performSecureOperation(input: inputText)
                await MainActor.run {
                    operationResult = result
                }
            } catch {
                await MainActor.run {
                    operationError = error
                }
            }
            await MainActor.run {
                isLoading = false
            }
        }
    }
}

// MARK: - 6. Integrate into Your App

@main
@available(iOS 18.0, macOS 15.0, *)
struct EnterpriseAIApp: App {
    @StateObject private var authenticator = AIClientAuthenticator()

    var body: some Scene {
        WindowGroup {
            NavigationView {
                // Provide the *optional* authenticated client to the environment.
                // This value will dynamically update as the authenticator updates currentAuthenticatedClient.
                AIProtectedFeatureView()
                    .environment(\.authenticatedAIClient, authenticator.currentAuthenticatedClient)
                    // Provide the authenticator itself as an EnvironmentObject
                    // so child views can trigger authentication actions (e.g., re-authenticate button).
                    .environmentObject(authenticator)
            }
        }
    }
}
