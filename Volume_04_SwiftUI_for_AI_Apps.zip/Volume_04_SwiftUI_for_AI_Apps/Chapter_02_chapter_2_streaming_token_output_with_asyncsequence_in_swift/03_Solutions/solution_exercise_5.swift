
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import Foundation

// MARK: - Mock AsyncSequences for Concurrent Streams

struct SummaryStream: AsyncSequence {
    typealias Element = String
    private let summary: String
    private let delay: TimeInterval

    init(summary: String, delay: TimeInterval = 0.1) {
        self.summary = summary
        self.delay = delay
    }

    func makeAsyncIterator() -> Iterator {
        Iterator(words: summary.split(separator: " ").map(String.init), delay: delay)
    }

    struct Iterator: AsyncIteratorProtocol {
        private var words: [String]
        private let delay: TimeInterval

        init(words: [String], delay: TimeInterval) {
            self.words = words
            self.delay = delay
        }

        mutating func next() async throws -> String? {
            guard !words.isEmpty else { return nil }
            try await Task.sleep(for: .seconds(delay))
            try Task.checkCancellation()
            return words.removeFirst()
        }
    }
}

struct InsightsStream: AsyncSequence {
    typealias Element = String
    private let insights: [String] // Emits phrases/bullet points
    private let delay: TimeInterval

    init(insights: [String], delay: TimeInterval = 0.2) {
        self.insights = insights
        self.delay = delay
    }

    func makeAsyncIterator() -> Iterator {
        Iterator(phrases: insights, delay: delay)
    }

    struct Iterator: AsyncIteratorProtocol {
        private var phrases: [String]
        private let delay: TimeInterval

        init(phrases: [String], delay: TimeInterval) {
            self.phrases = phrases
            self.delay = delay
        }

        mutating func next() async throws -> String? {
            guard !phrases.isEmpty else { return nil }
            try await Task.sleep(for: .seconds(delay))
            try Task.checkCancellation()
            return phrases.removeFirst()
        }
    }
}

// MARK: - SwiftUI View

struct ResearchDashboardView: View {
    @State private var summaryText: String = "Summary will appear here..."
    @State private var insightsText: String = "Key Insights will appear here..."
    @State private var isStreaming: Bool = false
    @State private var parentTask: Task<Void, Never>? // Parent task to manage child tasks/TaskGroup

    private let mockSummary = """
    The latest quarterly report indicates a strong performance across key metrics. Revenue growth exceeded expectations by 15%, driven primarily by increased market penetration in emerging economies. Operational efficiency improvements also contributed significantly to the improved profit margins. Several new product lines are in development, promising continued expansion into new customer segments.
    """
    private let mockInsights = [
        "High revenue growth.",
        "Strong market penetration.",
        "Improved profit margins.",
        "New product lines coming.",
        "Positive outlook."
    ]

    var body: some View {
        VStack(spacing: 20) {
            Text("AI Research Assistant")
                .font(.largeTitle)
                .fontWeight(.bold)

            HStack {
                Button("Start Research") {
                    startAllStreams()
                }
                .buttonStyle(.borderedProminent)
                .disabled(isStreaming)

                Button("Stop All Streams") {
                    stopAllStreams()
                }
                .buttonStyle(.bordered)
                .tint(.red)
                .disabled(!isStreaming)
            }
            .padding(.horizontal)

            HStack(alignment: .top, spacing: 15) {
                VStack(alignment: .leading) {
                    Text("Summary:")
                        .font(.headline)
                    Text(summaryText)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)
                        .animation(.easeOut(duration: 0.1), value: summaryText)
                }

                VStack(alignment: .leading) {
                    Text("Key Insights:")
                        .font(.headline)
                    Text(insightsText)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(8)
                        .animation(.easeOut(duration: 0.1), value: insightsText)
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical)
        .navigationTitle("Research Dashboard")
        .onDisappear {
            parentTask?.cancel() // Ensure all child tasks are cancelled when view disappears
        }
    }

    private func startAllStreams() {
        // Cancel any existing parent task to ensure a clean start
        parentTask?.cancel()
        isStreaming = true
        summaryText = ""
        insightsText = ""

        parentTask = Task {
            await withTaskGroup(of: Void.self) { group in
                // Add task for SummaryStream
                group.addTask {
                    await streamSummary()
                }

                // Add task for InsightsStream
                group.addTask {
                    await streamInsights()
                }

                // Wait for all child tasks in the group to complete or be cancelled
                for await _ in group { }
            }
            // This block executes when the TaskGroup is empty (all tasks completed or cancelled)
            await MainActor.run {
                self.isStreaming = false
                if self.summaryText.isEmpty { self.summaryText = "Summary stream stopped or failed." }
                if self.insightsText.isEmpty { self.insightsText = "Insights stream stopped or failed." }
            }
        }
    }

    private func stopAllStreams() {
        parentTask?.cancel()
        isStreaming = false
        summaryText = "Streams cancelled."
        insightsText = "Streams cancelled."
    }

    @MainActor
    private func streamSummary() async {
        let stream = SummaryStream(summary: mockSummary, delay: 0.1)
        do {
            for await word in stream {
                summaryText += (summaryText.isEmpty ? "" : " ") + word
                // Yield to allow other tasks (like insights stream) to run
                await Task.yield()
            }
        } catch {
            if Task.isCancelled {
                print("Summary stream cancelled.")
            } else {
                print("Summary stream error: \(error.localizedDescription)")
                summaryText = "Error: \(error.localizedDescription)"
            }
        }
    }

    @MainActor
    private func streamInsights() async {
        let stream = InsightsStream(insights: mockInsights, delay: 0.2)
        do {
            for await phrase in stream {
                insightsText += (insightsText.isEmpty ? "" : "\n") + "- " + phrase
                // Yield to allow other tasks (like summary stream) to run
                await Task.yield()
            }
        } catch {
            if Task.isCancelled {
                print("Insights stream cancelled.")
            } else {
                print("Insights stream error: \(error.localizedDescription)")
                insightsText = "Error: \(error.localizedDescription)"
            }
        }
    }
}
