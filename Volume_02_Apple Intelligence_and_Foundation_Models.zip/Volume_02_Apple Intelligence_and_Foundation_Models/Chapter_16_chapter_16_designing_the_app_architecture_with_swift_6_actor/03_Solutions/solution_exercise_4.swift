
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - 1. AIStory Type

/// Represents an AI-generated story.
/// Needs to be `Sendable` to be safely passed between actors.
struct AIStory: Identifiable, Hashable, Sendable {
    let id: UUID
    let title: String
    let content: String
    
    init(id: UUID = UUID(), title: String, content: String) {
        self.id = id
        self.title = title
        self.content = content
    }
}

// MARK: - 2. BackendServiceActor (Simulated)

enum SyncError: Error, LocalizedError, Sendable {
    case networkFailure(reason: String)
    case serverError(code: Int)
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .networkFailure(let reason): return "Network failure: \(reason)"
        case .serverError(let code): return "Server error: \(code)"
        case .unknown: return "An unknown synchronization error occurred."
        }
    }
}

/// A simulated backend service actor for uploading AI stories.
actor BackendServiceActor {
    private let successRate: Double
    
    init(successRate: Double = 0.7) { // 70% success rate by default
        self.successRate = successRate
        print("BackendServiceActor initialized with success rate: \(Int(successRate * 100))%")
    }
    
    /// Simulates uploading an AI story to a backend service.
    /// Introduces latency and random success/failure.
    /// - Parameter story: The AIStory to upload.
    /// - Throws: `SyncError` on failure.
    /// - Returns: `true` if upload was successful.
    func uploadStory(story: AIStory) async throws -> Bool {
        print("[\(Thread.current.description)] Backend: Attempting to upload story '\(story.title)' (ID: \(story.id.uuidString.prefix(8)))...")
        try await Task.sleep(for: .seconds(Double.random(in: 0.5...1.5))) // Simulate network latency
        
        if Double.random(in: 0...1) < successRate {
            print("[\(Thread.current.description)] Backend: Successfully uploaded story '\(story.title)'.")
            return true
        } else {
            let errorType = Int.random(in: 0...1)
            if errorType == 0 {
                throw SyncError.networkFailure(reason: "Connection timed out")
            } else {
                throw SyncError.serverError(code: 500)
            }
        }
    }
}

// MARK: - 3. AISyncManagerActor

actor AISyncManagerActor {
    private var pendingStories: Set<AIStory> = []
    private var syncedStories: Set<AIStory> = []
    private var retryCounts: [UUID: Int] = [:] // Track retries per story
    private let maxRetries = 3
    
    private let backendService: BackendServiceActor
    private var processingTask: Task<Void, Never>? // Task for the continuous processing loop
    
    init(backendService: BackendServiceActor) {
        self.backendService = backendService
        print("AISyncManagerActor initialized.")
    }
    
    /// Adds an AIStory to the pending synchronization queue.
    /// If the story is already pending, it does nothing.
    /// - Parameter story: The AIStory to queue.
    func queueStoryForSync(story: AIStory) async {
        if pendingStories.contains(story) || syncedStories.contains(story) {
            print("[\(Thread.current.description)] SyncManager: Story '\(story.title)' (ID: \(story.id.uuidString.prefix(8))) already pending or synced. Skipping.")
            return
        }
        
        pendingStories.insert(story)
        print("[\(Thread.current.description)] SyncManager: Story '\(story.title)' (ID: \(story.id.uuidString.prefix(8))) queued for sync. Pending count: \(pendingStories.count)")
        
        // Ensure the processing loop is running
        startProcessingIfNeeded()
    }
    
    /// Starts the continuous background processing loop if it's not already running.
    private func startProcessingIfNeeded() {
        if processingTask == nil {
            processingTask = Task.detached { [weak self] in
                await self?._processSyncQueue()
            }
        }
    }
    
    /// Private method that continuously monitors and processes the pending stories queue.
    private func _processSyncQueue() async {
        print("[\(Thread.current.description)] SyncManager: Starting background sync queue processing.")
        while !Task.isCancelled {
            if let storyToProcess = pendingStories.first { // Take one story from the queue
                print("[\(Thread.current.description)] SyncManager: Attempting to process story '\(storyToProcess.title)'...")
                
                do {
                    _ = try await backendService.uploadStory(story: storyToProcess)
                    
                    // On success: remove from pending, add to synced, clear retry count
                    pendingStories.remove(storyToProcess)
                    syncedStories.insert(storyToProcess)
                    retryCounts.removeValue(forKey: storyToProcess.id)
                    print("[\(Thread.current.description)] SyncManager: Story '\(storyToProcess.title)' successfully synced. Pending count: \(pendingStories.count), Synced count: \(syncedStories.count)")
                    
                } catch let error as SyncError {
                    let currentRetries = (retryCounts[storyToProcess.id] ?? 0) + 1
                    retryCounts[storyToProcess.id] = currentRetries
                    
                    if currentRetries <= maxRetries {
                        print("[\(Thread.current.description)] SyncManager: Upload failed for '\(storyToProcess.title)': \(error.localizedDescription). Retrying in 5s (Attempt \(currentRetries)/\(maxRetries)).")
                        // Re-queue by simply not removing it, and wait before next attempt
                        try? await Task.sleep(for: .seconds(5))
                    } else {
                        print("[\(Thread.current.description)] SyncManager: Upload failed for '\(storyToProcess.title)' after \(maxRetries) retries. Giving up on this story. Error: \(error.localizedDescription)")
                        // Remove from pending, but not added to synced
                        pendingStories.remove(storyToProcess)
                        retryCounts.removeValue(forKey: storyToProcess.id)
                    }
                } catch {
                    print("[\(Thread.current.description)] SyncManager: An unexpected error occurred during sync for '\(storyToProcess.title)': \(error.localizedDescription)")
                    // For unexpected errors, also give up for simplicity in this exercise
                    pendingStories.remove(storyToProcess)
                    retryCounts.removeValue(forKey: storyToProcess.id)
                }
            } else {
                // Queue is empty, wait for new stories or a short period before checking again
                // This prevents a busy-wait loop.
                print("[\(Thread.current.description)] SyncManager: Sync queue empty. Waiting for new stories...")
                try? await Task.sleep(for: .seconds(2))
            }
        }
        print("[\(Thread.current.description)] SyncManager: Background sync queue processing stopped.")
    }
    
    /// Cancels the background processing task.
    func stopProcessing() async {
        processingTask?.cancel()
        processingTask = nil
        print("[\(Thread.current.description)] SyncManager: Sync processing explicitly stopped.")
    }
    
    /// Returns the current set of pending stories.
    var currentPendingStories: Set<AIStory> {
        get async { pendingStories }
    }
    
    /// Returns the current set of successfully synced stories.
    var currentSyncedStories: Set<AIStory> {
        get async { syncedStories }
    }
}

// MARK: - Demonstration

@main
struct Exercise4 {
    static func main() async {
        print("--- Starting AI-Generated Content Sync Manager Demonstration ---")

        let backend = BackendServiceActor(successRate: 0.6) // 60% success rate for more retries
        let syncManager = AISyncManagerActor(backendService: backend)

        // Create several AI stories
        let story1 = AIStory(title: "The Whispering Woods", content: "A tale of ancient trees and forgotten magic.")
        let story2 = AIStory(title: "Stars of the Deep", content: "An epic space opera across galaxies.")
        let story3 = AIStory(title: "Silent City", content: "A post-apocalyptic mystery in a deserted metropolis.")
        let story4 = AIStory(title: "Dream Weaver", content: "A fantasy story about manipulating dreams.")
        let story5 = AIStory(title: "The Last Spark", content: "A short poem about hope in darkness.")
        
        // Concurrently queue stories for sync
        print("\n--- Concurrently queuing stories ---")
        await withTaskGroup(of: Void.self) { group in
            group.addTask { await syncManager.queueStoryForSync(story: story1) }
            group.addTask { try? await Task.sleep(for: .milliseconds(50)); await syncManager.queueStoryForSync(story: story2) }
            group.addTask { try? await Task.sleep(for: .milliseconds(100)); await syncManager.queueStoryForSync(story: story3) }
            group.addTask { try? await Task.sleep(for: .milliseconds(150)); await syncManager.queueStoryForSync(story: story4) }
            group.addTask { try? await Task.sleep(for: .milliseconds(200)); await syncManager.queueStoryForSync(story: story5) }
        }

        print("\n--- Monitoring sync process ---")
        // Allow time for the sync manager to process the queue, including retries
        try? await Task.sleep(for: .seconds(20)) // Give it ample time

        print("\n--- Sync process observation complete ---")
        let finalPending = await syncManager.currentPendingStories
        let finalSynced = await syncManager.currentSyncedStories

        print("Final Pending Stories (\(finalPending.count)):")
        finalPending.forEach { print("  - \($0.title) (ID: \($0.id.uuidString.prefix(8)))") }

        print("Final Synced Stories (\(finalSynced.count)):")
        finalSynced.forEach { print("  - \($0.title) (ID: \($0.id.uuidString.prefix(8)))") }
        
        // Explicitly stop the background task
        await syncManager.stopProcessing()
        
        print("\n--- Demonstration finished ---")
    }
}
