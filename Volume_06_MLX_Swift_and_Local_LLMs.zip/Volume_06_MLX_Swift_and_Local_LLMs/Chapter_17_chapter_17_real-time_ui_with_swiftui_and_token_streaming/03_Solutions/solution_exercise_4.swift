
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation
// import MLX // For actual MLX integration

// Reusing LLMServiceError from Exercise 1
// enum LLMServiceError: Error, LocalizedError { ... }

// MARK: - 1. SuggestionEngine Protocol and MLXSuggestionEngine Implementation

/// Defines the interface for a suggestion engine.
protocol SuggestionEngine {
    func getSuggestions(context: String) -> AsyncThrowingStream<String, Error>
}

/// A simulated MLX-powered suggestion engine.
/// In a real application, this would use a fast MLX model for text continuation.
final class MLXSuggestionEngine: SuggestionEngine {
    private let cannedSuggestions: [String: String] = [
        "I hope this email finds you": "well.",
        "Please let me know if you": "have any questions.",
        "Looking forward to your": "response.",
        "Best regards,": "John Doe",
        "Thank you for your": "time and consideration.",
        "I wanted to follow up on": "our previous discussion.",
        "Regarding our meeting on": "Tuesday,",
        "I'll get back to you": "shortly.",
        "Let me know if this works": "for you."
    ]

    /// Simulates generating a text continuation suggestion.
    /// In a real MLX scenario:
    /// - `context` would be tokenized into `MLXArray<Int32>`.
    /// - A prompt would be constructed (e.g., `<start_of_text>User: <context>Model:`).
    /// - The MLX model's `generate` or `decode` method would be called to produce a few continuation tokens.
    /// - These tokens would be detokenized and yielded.
    /// - The goal is low-latency, so a small, optimized MLX model would be critical.
    func getSuggestions(context: String) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                print("MLXSuggestionEngine: Request for context: '\(context)'")
                
                // Simulate network/model inference delay
                try await Task.sleep(for: .milliseconds(300)) // Simulate a fast LLM response

                if Task.isCancelled {
                    print("MLXSuggestionEngine: Suggestion task cancelled.")
                    continuation.finish(throwing: LLMServiceError.cancellationRequested)
                    return
                }

                // Simple heuristic: find a matching prefix in canned suggestions
                let trimmedContext = context.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                if let matchingKey = cannedSuggestions.keys.first(where: { trimmedContext.hasSuffix($0.lowercased()) }) {
                    let suggestion = cannedSuggestions[matchingKey] ?? ""
                    print("MLXSuggestionEngine: Found suggestion: '\(suggestion)' for context: '\(context)'")
                    continuation.yield(suggestion)
                } else {
                    print("MLXSuggestionEngine: No suggestion found for context: '\(context)'")
                }
                
                continuation.finish()
            }
        }
    }
}

// MARK: - 2. EmailComposerViewModel (macOS)

/// Manages the email body text and provides debounced, cancellable suggestions.
@MainActor
final class EmailComposerViewModel: ObservableObject {
    @Published var emailBody: String = "" {
        didSet {
            // Trigger suggestion request whenever emailBody changes
            // Only trigger if the body isn't empty and isn't just whitespace
            if !emailBody.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                debounceSuggestionRequest()
            } else {
                // Clear suggestion if text is empty
                currentSuggestion = nil
                currentSuggestionTask?.cancel() // Cancel any pending suggestion
            }
        }
    }
    @Published var currentSuggestion: String? // The suggested text continuation
    @Published var isSuggesting: Bool = false // To show a loading indicator for suggestions

    private let suggestionEngine: SuggestionEngine
    private var currentSuggestionTask: Task<Void, Never>? // Task for the current suggestion request
    private var debounceTask: Task<Void, Never>? // Task for debouncing user input
    private let debounceInterval: Duration = .milliseconds(400) // Debounce delay for suggestions

    init(suggestionEngine: SuggestionEngine = MLXSuggestionEngine()) {
        self.suggestionEngine = suggestionEngine
    }

    /// Debounces user typing to avoid excessive suggestion requests.
    private func debounceSuggestionRequest() {
        debounceTask?.cancel() // Cancel any previous debounce task

        debounceTask = Task {
            do {
                try await Task.sleep(for: debounceInterval)
                if !Task.isCancelled {
                    await fetchSuggestion(for: emailBody)
                }
            } catch is CancellationError {
                print("EmailComposerViewModel: Debounce task cancelled.")
            } catch {
                print("EmailComposerViewModel: Error in debounce task: \(error)")
            }
        }
    }

    /// Fetches a suggestion from the engine for the given context.
    private func fetchSuggestion(for context: String) async {
        // Cancel any existing suggestion request to ensure only the latest context is processed
        currentSuggestionTask?.cancel()
        currentSuggestion = nil // Clear previous suggestion immediately
        isSuggesting = true

        currentSuggestionTask = Task {
            do {
                for try await suggestionPart in suggestionEngine.getSuggestions(context: context) {
                    if Task.isCancelled {
                        print("EmailComposerViewModel: Suggestion consumption task cancelled.")
                        break
                    }
                    // For simplicity, we'll just take the first part as the full suggestion
                    // In a real streaming scenario, you might accumulate parts.
                    currentSuggestion = suggestionPart
                    break // Stop after first part for autocomplete
                }
            } catch let error as LLMServiceError where error == .cancellationRequested {
                print("EmailComposerViewModel: Suggestion request cancelled.")
            } catch {
                print("EmailComposerViewModel: Failed to get suggestion: \(error.localizedDescription)")
            }
            isSuggesting = false
            currentSuggestionTask = nil
        }
    }

    /// Accepts the current suggestion, appending it to the email body.
    func acceptSuggestion() {
        guard let suggestion = currentSuggestion else { return }
        emailBody += suggestion
        currentSuggestion = nil // Clear suggestion after acceptance
        // Optionally, immediately trigger a new suggestion based on the extended text
        debounceSuggestionRequest()
    }
}

// MARK: - 3. EmailComposerView (macOS SwiftUI)

/// macOS SwiftUI view for the email composer with smart autocomplete.
struct EmailComposerView: View {
    @StateObject private var viewModel = EmailComposerViewModel()
    @State private var textEditorHeight: CGFloat = 200 // Initial height for TextEditor

    var body: some View {
        VStack(alignment: .leading) {
            Text("To: recipient@example.com")
                .font(.headline)
                .padding(.bottom, 5)
            Text("Subject: Smart Compose Demo")
                .font(.headline)
                .padding(.bottom, 10)

            ZStack(alignment: .bottomLeading) { // Use ZStack to overlay suggestion
                TextEditor(text: $viewModel.emailBody)
                    .font(.body)
                    .frame(minHeight: textEditorHeight, maxHeight: .infinity)
                    .border(Color.gray.opacity(0.3), width: 1)
                    .onChange(of: viewModel.emailBody) { newBody in
                        // Adjust height if needed (basic example, more complex logic for dynamic height)
                        // This is mostly for visual comfort in an example, not critical for core feature
                        // let newHeight = calculateTextEditorHeight(for: newBody)
                        // if newHeight != textEditorHeight { textEditorHeight = newHeight }
                    }
                    .onKeyPress(.tab, action: handleTabPress) // Handle Tab key for acceptance
                    .onCommand(#selector(NSResponder.insertTab(_:)), perform: { // Fallback/alternative for Tab
                        .handled // Consume the event if we handle it
                    })
                    .onCommand(#selector(NSResponder.insertNewline(_:)), perform: { // Handle Enter key
                        .ignored // Allow default new line behavior
                    })
                
                // Overlay for the suggestion
                if let suggestion = viewModel.currentSuggestion, !viewModel.emailBody.isEmpty {
                    Text(viewModel.emailBody + suggestion)
                        .font(.body)
                        .foregroundColor(.gray.opacity(0.6)) // Lighter color for suggestion
                        .padding(.horizontal, 4) // Match TextEditor's internal padding
                        .allowsHitTesting(false) // Make sure it doesn't block TextEditor interaction
                        .lineLimit(nil) // Allow suggestion to wrap
                }
            }
            
            HStack {
                if viewModel.isSuggesting {
                    ProgressView()
                        .controlSize(.small)
                    Text("Thinking...")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                Spacer()
                Text("Press Tab to accept suggestion")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding(.top, 5)

            Spacer()
        }
        .padding()
        .frame(minWidth: 600, minHeight: 400) // Typical macOS window size
        .navigationTitle("Smart Email Composer")
    }
    
    // Helper to handle Tab key press
    private func handleTabPress() -> EventDisposition {
        if viewModel.currentSuggestion != nil {
            viewModel.acceptSuggestion()
            return .handled // Consume the Tab event
        }
        return .ignored // Allow default Tab behavior (e.g., focus change)
    }
}

// MARK: - App Entry Point (for macOS)
/*
// YourStreamingChatAppApp.swift
import SwiftUI

@main
struct YourStreamingChatAppApp: App {
    var body: some Scene {
        WindowGroup {
            EmailComposerView() // Or ContentView, MarkdownContentView
        }
    }
}
*/
