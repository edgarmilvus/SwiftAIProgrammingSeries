
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import ARKit
import RealityKit
import Foundation
import simd

// Extension to allow simd_float4x4 to conform to Codable for persistence
extension simd_float4x4: Codable {
    public init(from decoder: Decoder) throws {
        var container = try decoder.unkeyedContainer()
        let columns = try (0..<4).map { _ in
            try (0..<4).map { _ in try container.decode(Float.self) }
        }
        self.init(columns.map { simd_float4(columns[$0]) })
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.unkeyedContainer()
        for col in columns {
            for val in col {
                try container.encode(val)
            }
        }
    }
}

struct SpatialMarker: Codable {
    let anchorIdentifier: UUID
    let modelName: String
    let relativeTransform: simd_float4x4
}

@MainActor
class SpatialAnchorManager: ObservableObject {
    private var arKitSession: ARKitSession?
    private var worldTracking: WorldTrackingProvider?
    private var anchors: [UUID: Entity] = [:]
    
    // Persistence URL
    private let storageURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("markers.json")

    func setupSession() async throws {
        arKitSession = ARKitSession()
        worldTracking = WorldTrackingProvider()
        try await arKitSession?.run([worldTracking!])
    }

    func placeMarker(at transform: simd_float4x4) async throws {
        guard let worldTracking = worldTracking else { return }
        
        // 1. Explicitly request a WorldAnchor for high-priority tracking
        let anchor = try await worldTracking.createAnchor(at: transform)
        
        // 2. Create the visual entity
        let cube = ModelEntity(mesh: .generateBox(size: 0.1), materials: [SimpleMaterial(color: .cyan, isMetallic: true)])
        
        // 3. Attach to the anchor
        let anchorEntity = AnchorEntity(worldAnchor: anchor)
        anchorEntity.addChild(cube)
        
        // 4. Store in memory and persist
        anchors[anchor.identifier] = anchorEntity
        try await saveMarker(anchorID: anchor.identifier, transform: transform)
    }

    private func saveMarker(anchorID: UUID, transform: simd_float4x4) async throws {
        let marker = SpatialMarker(anchorIdentifier: anchorID, modelName: "cube", relativeTransform: transform)
        var currentMarkers = try loadMarkers()
        currentMarkers.append(marker)
        let data = try JSONEncoder().encode(currentMarkers)
        try data.write(to: storageURL)
    }

    func loadMarkers() throws -> [SpatialMarker] {
        guard FileManager.default.fileExists(atPath: storageURL.path) else { return [] }
        let data = try Data(contentsOf: storageURL)
        return try JSONDecoder().decode([SpatialMarker].self, from: data)
    }

    func restoreAnchors(into scene: Scene) async throws {
        let markers = try loadMarkers()
        guard let worldTracking = worldTracking else { return }

        for marker in markers {
            // Attempt to re-establish the anchor using the stored identifier
            // In a real app, we check if the anchor is already provided by the session
            if let existingAnchor = worldTracking.anchors.first(where: { $0.identifier == marker.anchorIdentifier }) {
                let entity = ModelEntity(mesh: .generateBox(size: 0.1), materials: [SimpleMaterial(color: .cyan, isMetallic: true)])
                let anchorEntity = AnchorEntity(worldAnchor: existingAnchor)
                anchorEntity.addChild(entity)
                scene.addAnchor(anchorEntity)
            }
        }
    }
}
