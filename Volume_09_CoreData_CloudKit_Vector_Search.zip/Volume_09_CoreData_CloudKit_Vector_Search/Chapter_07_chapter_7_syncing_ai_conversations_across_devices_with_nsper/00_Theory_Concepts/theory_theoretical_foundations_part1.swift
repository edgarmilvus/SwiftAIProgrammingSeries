
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreData
import Observation

@available(iOS 18.0, *)
/// A Sendable representation of an AI message to safely cross concurrency boundaries.
struct MessageSnapshot: Sendable, Identifiable {
    let id: UUID
    let content: String
    let timestamp: Date
    let role: String // "user" or "assistant"
}

/// The Actor responsible for managing the AI's long-term memory synchronization.
/// By using an actor, we ensure that all interactions with the persistence 
/// layer are serialized, preventing data races during CloudKit sync.
actor ConversationSyncManager {
    private let container: NSPersistentCloudKitContainer
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }
    
    /// Fetches the conversation history and converts it into Sendable snapshots.
    /// This prevents the UI or AI processing actors from holding onto 
    /// non-Sendable NSManagedObjects.
    func fetchConversationHistory(for conversationID: UUID) async throws -> [MessageSnapshot] {
        // Perform the fetch on a background context
        let context = container.newBackgroundContext()
        
        return try await context.perform {
            let request: NSFetchRequest<MessageEntity> = MessageEntity.fetchRequest()
            request.predicate = NSPredicate(format: "conversationID == %@", conversationID as CVarArg)
            request.sortDescriptors = [NSSortDescriptor(keyPath: \MessageEntity.timestamp, ascending: true)]
            
            let results = try context.fetch(request)
            
            // Transform ManagedObjects into Sendable Structs immediately
            return results.map { entity in
                MessageSnapshot(
                    id: entity.id ?? UUID(),
                    content: entity.content ?? "",
                    timestamp: entity.timestamp ?? Date(),
                    role: entity.role ?? "user"
                )
            }
        }
    }
}
