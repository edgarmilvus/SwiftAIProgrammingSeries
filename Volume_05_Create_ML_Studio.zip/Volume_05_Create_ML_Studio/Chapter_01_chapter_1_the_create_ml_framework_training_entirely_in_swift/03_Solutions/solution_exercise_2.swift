
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CreateML
import AppKit // For NSImage to create dummy images, or UIKit for iOS

// MARK: - Helper to create dummy image files
func createDummyImage(at url: URL, size: NSSize = NSSize(width: 100, height: 100), color: NSColor = .white) throws {
    let image = NSImage(size: size)
    image.lockFocus()
    color.drawSwatch(in: NSRect(origin: .zero, size: size))
    image.unlockFocus()
    
    guard let tiffData = image.tiffRepresentation,
          let bitmapImage = NSBitmapImageRep(data: tiffData),
          let pngData = bitmapImage.representation(using: .png, properties: [:]) else {
        throw NSError(domain: "ImageCreation", code: 1, userInfo: [NSLocalizedDescriptionKey: "Failed to create PNG data"])
    }
    try pngData.write(to: url)
}

// MARK: - Main Training Logic
func runExercise2() async {
    print("\n--- Exercise 2: Plant Species Identification ---")
    
    let fileManager = FileManager.default
    let tempDirectory = fileManager.temporaryDirectory
    let plantImagesDir = tempDirectory.appendingPathComponent("PlantImages_\(UUID().uuidString)")
    
    do {
        // 1. Data Preparation: Create directory structure and dummy images
        let species = ["Monstera", "Pothos", "SnakePlant"]
        for s in species {
            let speciesDir = plantImagesDir.appendingPathComponent(s)
            try fileManager.createDirectory(at: speciesDir, withIntermediateDirectories: true, attributes: nil)
            
            for i in 1...50 { // Create 50 dummy images per species
                let imageName = "img_\(s.lowercased())_\(String(format: "%02d", i)).png"
                let imageUrl = speciesDir.appendingPathComponent(imageName)
                try createDummyImage(at: imageUrl, color: NSColor(hue: CGFloat.random(in: 0...1), saturation: 0.8, brightness: 0.8, alpha: 1.0))
            }
        }
        print("Simulated plant image data created at: \(plantImagesDir.path)")
        
        // 2. MLImageClassifier Training: Load data
        let dataSource = MLImageClassifier.DataSource.labeledDirectories(at: plantImagesDir)
        
        // Split data into training and testing sets
        let (trainingData, testingData) = try dataSource.randomSplit(by: 0.8, seed: 42)
        
        print("Training data images: \(trainingData.count)")
        print("Testing data images: \(testingData.count)")
        
        // 3. Model Training
        let imageClassifier = try await MLImageClassifier(trainingData: trainingData)
        
        print("MLImageClassifier trained successfully.")
        
        // 4. Model Evaluation
        let evaluation = imageClassifier.evaluation(on: testingData)
        let accuracy = (1.0 - evaluation.classificationError) * 100
        print("Model evaluation accuracy on test data: \(String(format: "%.2f", accuracy))%")
        
        // 5. Model Saving
        let modelURL = tempDirectory.appendingPathComponent("PlantClassifier.mlmodel")
        try imageClassifier.write(to: modelURL)
        print("Model saved to: \(modelURL.path)")
        
        // Optional: Clean up
        try fileManager.removeItem(at: plantImagesDir)
        print("Cleaned up: removed simulated image directory.")
        // try fileManager.removeItem(at: modelURL)
        // print("Cleaned up: removed saved model.")
        
    } catch {
        print("Error during Exercise 2: \(error.localizedDescription)")
    }
}

// Run the exercise
// Task { await runExercise2() } // Uncomment to run directly if not part of a larger app
