
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation
import SwiftUI

// Assume MyModel is the generated Swift class
@available(iOS 17.0, *)
@Observable
class ImageClassifierViewModel {
    var predictionResult: String = "No prediction yet"
    var isLoading: Bool = false
    var error: Error?

    private let modelActor: ModelActor // Use the actor for thread-safe model access

    init(modelName: String) {
        let config = MLModelConfiguration()
        config.computeUnits = .all
        self.modelActor = ModelActor(modelName: modelName, configuration: config)
    }

    func classifyImage(_ image: UIImage) {
        Task { @MainActor in // Ensure UI updates are on the main actor
            isLoading = true
            error = nil
            do {
                guard let inputProvider = prepareImageInput(image: image) else {
                    throw NSError(domain: "ImageProcessingError", code: 0, userInfo: nil)
                }

                // Call the actor's method to perform prediction
                let output = try await modelActor.predict(input: inputProvider)

                guard let classLabel = output.featureValue(for: "classLabel")?.stringValue else {
                    throw NSError(domain: "ModelOutputError", code: 1, userInfo: nil)
                }
                predictionResult = "Predicted: \(classLabel)"
            } catch {
                self.error = error
                predictionResult = "Error: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }
}

@available(iOS 17.0, *)
struct ClassifierView: View {
    @State private var viewModel = ImageClassifierViewModel(modelName: "MyImageClassifier")
    @State private var selectedImage: UIImage? // Assume this is set by a PhotoPicker

    var body: some View {
        VStack {
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
            }
            Text(viewModel.predictionResult)
                .font(.headline)
            if viewModel.isLoading {
                ProgressView()
            }
            if let error = viewModel.error {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
            }
            Button("Classify Image") {
                if let imageToClassify = selectedImage {
                    viewModel.classifyImage(imageToClassify)
                }
            }
        }
        .padding()
    }
}
