/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Accelerometer } from 'expo-sensors';

interface MotionToggleProps {
  label: string;
  onToggle: (isOn: boolean) => void;
}

export default function MotionToggle({ label, onToggle }: MotionToggleProps) {
  const [isOn, setIsOn] = useState(false);
  const [isCoolingDown, setIsCoolingDown] = useState(false);
  const lastUpdateRef = useRef(0);

  // TODO: Setup Accelerometer subscription
  // TODO: Calculate magnitude of acceleration
  // TODO: Check if magnitude > threshold AND not cooling down
  // TODO: Toggle state and trigger onToggle callback
  // TODO: Manage cooldown timer

  return (
    <TouchableOpacity 
      style={[styles.container, { backgroundColor: isOn ? 'green' : 'red' }]}
      activeOpacity={0.8}
    >
      <Text style={styles.text}>{label}: {isOn ? 'ON' : 'OFF'}</Text>
      <Text style={styles.subtext}>{isOn ? 'Shake to turn OFF' : 'Shake to turn ON'}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    width: 200,
    height: 100,
    margin: 10,
  },
  text: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  subtext: { color: 'white', fontSize: 12, marginTop: 5 },
});
