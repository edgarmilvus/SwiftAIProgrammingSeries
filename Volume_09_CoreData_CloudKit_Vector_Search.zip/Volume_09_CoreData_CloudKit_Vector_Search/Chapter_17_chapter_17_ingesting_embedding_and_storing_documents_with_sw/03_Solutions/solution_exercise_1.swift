
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftData

@Model
final class ResearchDocument {
    @Attribute(.unique) var id: UUID
    var title: String
    var author: String
    
    // Critical Optimization: .externalStorage tells SwiftData to store 
    // large blobs in a separate file, keeping the SQLite database lean.
    @Attribute(.externalStorage) var content: String
    
    var timestamp: Date
    
    init(title: String, author: String, content: String, timestamp: Date = .now) {
        self.id = UUID()
        self.title = title
        self.author = author
        self.content = content
        self.timestamp = timestamp
    }
}

@MainActor
class DocumentIngestor {
    private let context: ModelContext
    
    init(context: ModelContext) {
        self.context = context
    }
    
    /// Ingests a new document into the persistent store.
    /// Marked as async to allow for future non-blocking background operations.
    func ingest(title: String, author: String, content: String) async throws {
        let newDocument = ResearchDocument(
            title: title,
            author: author,
            content: content
        )
        
        context.insert(newDocument)
        
        // Explicitly save to ensure the data is committed to disk.
        try context.save()
    }
}
