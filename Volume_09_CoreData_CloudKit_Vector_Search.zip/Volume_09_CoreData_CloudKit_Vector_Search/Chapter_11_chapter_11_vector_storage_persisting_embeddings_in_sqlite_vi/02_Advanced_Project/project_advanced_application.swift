
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import GRDB
import NaturalLanguage
import OSLog

// MARK: - Dependencies

/// Package.swift equivalent requirements:
/// .package(url: "https://github.com/groue/GRDB.swift", from: "6.0.0")
/// Note: This implementation assumes the 'sqlite-vec' C-extension is linked 
/// to the SQLite binary used by GRDB.

// MARK: - Error Handling

/// Represents specific failures in the vector storage lifecycle.
enum VectorEngineError: LocalizedError {
    case embeddingGenerationFailed
    case databaseConnectionError(Error)
    case searchExecutionError(String)
    case dimensionMismatch(expected: Int, actual: Int)

    var errorDescription: String? {
        switch self {
        case .embeddingGenerationFailed: return "Failed to generate embedding from text."
        case .databaseConnectionError(let err): return "SQLite Error: \(err.localizedDescription)"
        case .searchExecutionError(let msg): return "Search failed: \(msg)"
        case .dimensionMismatch(let e, let a): return "Vector dimension mismatch. Expected \(e), got \(a)."
        }
    }
}

// MARK: - Models

/// A single semantic unit stored in the database.
/// Conforms to `Codable` and `FetchableRecord` for GRDB integration.
struct SemanticNote: Identifiable, Codable, FetchableRecord, PersistableRecord {
    static let databaseTableName = "semantic_notes"
    
    let id: UUID
    let content: String
    let timestamp: Date
    /// The embedding is stored as a Data BLOB representing a Float32 array.
    let embedding: Data
    let dimension: Int

    /// Defines the columns for GRDB queries.
    enum Columns {
        static let id = Column(CodingKeys.id)
        static let content = Column(CodingKeys.content)
        static let timestamp = Column(CodingKeys.timestamp)
        static let embedding = Column(CodingKeys.embedding)
        static let dimension = Column(CodingKeys.dimension)
    }
}

/// A result wrapper for similarity searches.
struct SemanticSearchResult: Sendable {
    let note: SemanticNote
    let distance: Float
}

// MARK: - The Vector Engine Actor

/// `VectorStorageActor` provides a thread-safe gateway to the SQLite database.
/// By using an `actor`, we ensure that all database interactions are isolated,
/// preventing data races in a multi-threaded environment.
@available(iOS 18.0, *)
actor VectorStorageActor {
    private let dbPool: DatabasePool
    private let logger = Logger(subsystem: "com.ai.app", category: "VectorEngine")
    private let vectorDimension: Int = 384 // Standard for many lightweight models

    /// Initializes the engine and performs migrations.
    /// - Parameter databaseURL: The file URL for the SQLite database.
    init(databaseURL: URL) throws {
        do {
            // 1. Use DatabasePool for high-performance concurrent read/write (WAL mode).
            var config = Configuration()
            config.prepareDatabase = { db in
                // Enable Write-Ahead Logging for concurrent access
                try db.execute(sql: "PRAGMA journal_mode = WAL;")
                try db.execute(sql: "PRAGMA synchronous = NORMAL;")
            }
            
            self.dbPool = try DatabasePool(path: databaseURL.path, configuration: config)
            try self.performMigrations()
            self.logger.info("Vector Engine initialized successfully.")
        } catch {
            throw VectorEngineError.databaseConnectionError(error)
        }
    }

    /// Sets up the schema, including the specialized vector table.
    private func performMigrations() throws {
        var migrator = DatabaseMigrator()

        migrator.registerMigration("create_semantic_notes") { db in
            // Create the table. Note: In a real sqlite-vec setup, 
            // we might use a specialized vector type if the extension supports it.
            // Here we use a standard BLOB for maximum compatibility.
            try db.create(table: SemanticNote.databaseTableName) { t in
                t.column(SemanticNote.Columns.id, .text).primaryKey()
                t.column(SemanticNote.Columns.content, .text).notNull()
                t.column(SemanticNote.Columns.timestamp, .datetime).notNull()
                t.column(SemanticNote.Columns.embedding, .blob).notNull()
                t.column(SemanticNote.Columns.dimension, .integer).notNull()
            }
            
            // Indexing content for standard text search (FTS5) could be added here.
        }

        try migrator.migrate(dbPool)
    }

    /// Persists a new note and its embedding.
    /// - Parameters:
    ///   - content: The raw text.
    ///   - embedding: The Float32 array converted to Data.
    func saveNote(content: String, embedding: Data) async throws {
        // Validate dimension before writing
        let count = embedding.count / MemoryLayout<Float>.size
        guard count == vectorDimension else {
            throw VectorEngineError.dimensionMismatch(expected: vectorDimension, actual: count)
        }

        let note = SemanticNote(
            id: UUID(),
            content: content,
            timestamp: Date(),
            embedding: embedding,
            dimension: vectorDimension
        )

        try await dbPool.write { db in
            try note.insert(db)
        }
        logger.debug("Saved note: \(content.prefix(20))...")
    }

    /// Performs a K-Nearest Neighbor search using cosine similarity.
    /// - Parameters:
    ///   - queryEmbedding: The vector representing the user's search query.
    ///   - limit: Maximum number of results to return.
    /// - Returns: An array of `SemanticSearchResult` sorted by proximity.
    func search(queryEmbedding: Data, limit: Int = 5) async throws -> [SemanticSearchResult] {
        try await dbPool.read { db in
            // We use raw SQL to leverage the 'sqlite-vec' extension's distance function.
            // The syntax 'vec_distance_cosine(embedding, ?)' is a placeholder 
            // for how the extension exposes similarity.
            let sql = """
            SELECT 
                id, content, timestamp, embedding, dimension,
                vec_distance_cosine(embedding, ?) as distance
            FROM semantic_notes
            ORDER BY distance ASC
            LIMIT ?
            """
            
            let rows = try Row.fetchAll(db, sql: sql, arguments: [queryEmbedding, limit])
            
            return rows.map { row in
                let note = try SemanticNote(row: row)
                let distance: Float = row["distance"]
                return SemanticSearchResult(note: note, distance: distance)
            }
        }
    }
    
    /// Batch processes multiple text snippets into embeddings and saves them.
    /// Demonstrates Swift 6 Structured Concurrency with TaskGroups.
    func batchIngest(texts: [String], embedder: @escaping (String) async throws -> Data) async throws {
        try await withThrowingTaskGroup(of: Void.self) { group in
            for text in texts {
                group.addTask {
                    let vector = try await embedder(text)
                    try await self.saveNote(content: text, embedding: vector)
                }
            }
            // Wait for all tasks to complete and propagate errors
            try await group.waitForAll()
        }
    }
}

// MARK: - High-Level Service

/// The `SemanticMemoryService` is the public-facing API for the app.
/// It bridges the gap between the Natural Language Framework and the Storage Actor.
@available(iOS 18.0, *)
final class SemanticMemoryService: Sendable {
    private let engine: VectorStorageActor
    private let embeddingModel: NLEmbedding?

    init(engine: VectorStorageActor) {
        self.engine = engine
        // Initialize the NL embedding model (e.g., sentence embeddings)
        self.embeddingModel = NLEmbedding.sentenceEmbedding(for: .english)
    }

    /// Converts text to a Data-backed Float32 array.
    private func generateEmbedding(for text: String) throws -> Data {
        guard let model = embeddingModel,
              let vector = model.vector(for: text) else {
            throw VectorEngineError.embeddingGenerationFailed
        }
        
        // Convert [Float] to Data
        return vector.withUnsafeBytes { Data($0) }
    }

    /// The primary entry point for adding information to the AI's memory.
    func remember(text: String) async throws {
        let vector = try generateEmbedding(for: text)
        try await engine.saveNote(content: text, embedding: vector)
    }

    /// The primary entry point for semantic querying.
    func ask(query: String) async throws -> [SemanticSearchResult] {
        let vector = try generateEmbedding(for: query)
        return try await engine.search(queryEmbedding: vector)
    }
    
    /// Ingests a large dataset efficiently.
    func ingest(documents: [String]) async throws {
        try await engine.batchIngest(texts: documents) { [weak self] text in
            guard let self = self else { throw VectorEngineError.embeddingGenerationFailed }
            return try self.generateEmbedding(for: text)
        }
    }
}
