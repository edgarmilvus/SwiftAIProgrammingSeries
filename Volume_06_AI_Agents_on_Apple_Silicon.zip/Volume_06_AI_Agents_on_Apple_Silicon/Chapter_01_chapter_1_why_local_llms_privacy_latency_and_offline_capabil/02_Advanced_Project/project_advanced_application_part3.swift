
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

// MARK: - 2. Local LLM Service Protocol and Mock Implementation

/// A protocol defining the interface for interacting with a local LLM service.
/// This abstracts away the underlying LLM implementation (e.g., llama.cpp bindings, Ollama client).
@available(iOS 18.0, macOS 15.0, *)
protocol LocalLLMService {
    /// Generates a response from the LLM based on a given prompt.
    /// - Parameters:
    ///   - prompt: The input prompt for the LLM.
    ///   - model: The identifier for the LLM model to use (e.g., "llama3", "mistral").
    /// - Returns: The generated text response from the LLM.
    /// - Throws: `DocumentProcessingError.llmServiceError` if the LLM encounters an issue.
    func generate(prompt: String, model: String) async throws -> String

    /// Summarizes the provided text using the LLM.
    /// - Parameters:
    ///   - text: The text content to summarize.
    ///   - model: The identifier for the LLM model.
    /// - Returns: A summarized version of the text.
    /// - Throws: `DocumentProcessingError.llmServiceError`.
    func summarize(text: String, model: String) async throws -> String

    /// Redacts sensitive information from the provided text using the LLM.
    /// - Parameters:
    ///   - text: The text content to redact.
    ///   - redactionInstructions: Specific instructions or patterns for redaction.
    ///   - model: The identifier for the LLM model.
    /// - Returns: The text with sensitive information redacted.
    /// - Throws: `DocumentProcessingError.llmServiceError`.
    func redact(text: String, redactionInstructions: String, model: String) async throws -> String
}

/// A mock implementation of `LocalLLMService` for testing and demonstration purposes.
/// It simulates LLM responses with artificial delays and predefined logic.
@available(iOS 18.0, macOS 15.0, *)
class MockLLMService: LocalLLMService {
    private let latency: Duration

    /// Initializes the mock service with a specified latency for simulated responses.
    /// - Parameter latency: The duration to pause before returning a response, simulating LLM inference time.
    init(latency: Duration = .seconds(1.5)) {
        self.latency = latency
    }

    /// Simulates a general LLM generation task.
    func generate(prompt: String, model: String) async throws -> String {
        try await Task.sleep(for: latency) // Simulate network/inference delay
        guard !Task.isCancelled else { throw DocumentProcessingError.operationCancelled }

        // Simple mock logic based on prompt keywords
        if prompt.lowercased().contains("hello") {
            return "Hello there! How can I assist you today with model \(model)?"
        } else if prompt.lowercased().contains("error") {
            throw DocumentProcessingError.llmServiceError(reason: "Simulated LLM generation error.")
        }
        return "Mock LLM response for prompt: '\(prompt)' using model: \(model)."
    }

    /// Simulates summarizing text.
    func summarize(text: String, model: String) async throws -> String {
        try await Task.sleep(for: latency) // Simulate inference delay
        guard !Task.isCancelled else { throw DocumentProcessingError.operationCancelled }

        if text.count < 50 {
            return "Summary (model \(model)): The text is too short to summarize effectively: '\(text)'"
        }
        // Simple mock summarization: take the first few words and add an ellipsis.
        let words = text.split(separator: " ")
        let summaryWords = words.prefix(min(15, words.count))
        return "Summary (model \(model)): \(summaryWords.joined(separator: " "))... (Original length: \(text.count) chars)"
    }

    /// Simulates redacting sensitive information.
    func redact(text: String, redactionInstructions: String, model: String) async throws -> String {
        try await Task.sleep(for: latency) // Simulate inference delay
        guard !Task.isCancelled else { throw DocumentProcessingError.operationCancelled }

        var redactedText = text
        // Simple mock redaction based on common patterns and instructions
        let sensitivePatterns = ["John Doe", "123 Main St", "john.doe@example.com", "SSN: XXX-XX-XXXX", "Credit Card: XXXX-XXXX-XXXX-XXXX"]
        let customPatterns = redactionInstructions.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }

        for pattern in sensitivePatterns + customPatterns {
            if let regex = try? Regex(pattern, .caseInsensitive) {
                redactedText = redactedText.replacing(regex) { _ in "[REDACTED]" }
            }
        }
        return "Redacted (model \(model)): \(redactedText)"
    }
}
