
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreML
import Foundation // For CGRect

// 1. Define the DetectedObject struct here.
struct DetectedObject {
    let classID: Int
    let confidence: Float
    let boundingBox: CGRect // Normalized 0-1, top-left (x,y)

    // For better debugging output
    var description: String {
        return "Class ID: \(classID), Confidence: \(String(format: "%.2f", confidence)), Bounding Box: \(boundingBox)"
    }
}

// 2. Implement the function signature.
func processObjectDetectionOutput(modelOutput: MLMultiArray, confidenceThreshold: Float) throws -> [DetectedObject] {
    // Ensure the MLMultiArray has the expected shape [1, num_detections, 7]
    guard modelOutput.shape.count == 3,
          modelOutput.shape[0].intValue == 1,
          modelOutput.shape[2].intValue == 7 else {
        throw NSError(domain: "ObjectDetectionError", code: 4, userInfo: [NSLocalizedDescriptionKey: "Unexpected MLMultiArray shape. Expected [1, num_detections, 7]. Found \(modelOutput.shape)"])
    }

    let numDetections = modelOutput.shape[1].intValue
    var detectedObjects: [DetectedObject] = []

    // Loop from 0 to numDetections - 1. This will be your 'detectionIndex'.
    for detectionIndex in 0..<numDetections {
        // Extract values using `modelOutput[[0, detectionIndex, featureIndex]]`.
        let classID = modelOutput[[0, detectionIndex, 0]].intValue
        let confidence = modelOutput[[0, detectionIndex, 1]].floatValue
        let x_center = modelOutput[[0, detectionIndex, 2]].floatValue
        let y_center = modelOutput[[0, detectionIndex, 3]].floatValue
        let width = modelOutput[[0, detectionIndex, 4]].floatValue
        let height = modelOutput[[0, detectionIndex, 5]].floatValue
        // rotation_angle is at index 6, but ignored as per task.

        // Apply the confidence threshold.
        if confidence >= confidenceThreshold {
            // Convert (x_center, y_center, width, height) to CGRect(x:minX, y:minY, width:w, height:h).
            // Remember: minX = x_center - (width / 2), minY = y_center - (height / 2).
            let minX = x_center - (width / 2.0)
            let minY = y_center - (height / 2.0)

            // Create a CGRect (using CGFloat for UIKit/AppKit compatibility)
            let boundingBox = CGRect(x: CGFloat(minX), y: CGFloat(minY), width: CGFloat(width), height: CGFloat(height))

            // Create a DetectedObject and append it to the `detectedObjects` array.
            let detectedObject = DetectedObject(classID: classID, confidence: confidence, boundingBox: boundingBox)
            detectedObjects.append(detectedObject)
        }
    }

    return detectedObjects
}

// Example usage (for testing your implementation):
/*
// Simulate a model output MLMultiArray
func createDummyModelOutput(numDetections: Int) throws -> MLMultiArray {
    let shape = [1, NSNumber(value: numDetections), 7]
    let multiArray = try MLMultiArray(shape: shape, dataType: .float32)

    // Populate with some dummy data
    for i in 0..<numDetections {
        let classID = Float(i % 3) // Classes 0, 1, 2
        let confidence = Float.random(in: 0.3...0.95)
        let x_center = Float.random(in: 0.1...0.9)
        let y_center = Float.random(in: 0.1...0.9)
        let width = Float.random(in: 0.05...0.2)
        let height = Float.random(in: 0.05...0.2)
        let rotation_angle = Float.random(in: 0...360)

        multiArray[[0, i, 0]] = NSNumber(value: classID)
        multiArray[[0, i, 1]] = NSNumber(value: confidence)
        multiArray[[0, i, 2]] = NSNumber(value: x_center)
        multiArray[[0, i, 3]] = NSNumber(value: y_center)
        multiArray[[0, i, 4]] = NSNumber(value: width)
        multiArray[[0, i, 5]] = NSNumber(value: height)
        multiArray[[0, i, 6]] = NSNumber(value: rotation_angle)
    }
    return multiArray
}

do {
    let dummyOutput = try createDummyModelOutput(numDetections: 10)
    let threshold: Float = 0.6

    let processedDetections = try processObjectDetectionOutput(modelOutput: dummyOutput, confidenceThreshold: threshold)

    print("Processed Detections (Threshold: \(threshold)):")
    for (index, obj) in processedDetections.enumerated() {
        print("Detection \(index): \(obj.description)")
    }
    print("Total detections above threshold: \(processedDetections.count)")

} catch {
    print("Error processing model output: \(error)")
}
*/
