
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftData

/// Represents a single transcription record from a voice assistant.
/// This model will be managed by SwiftData for persistence.
@Model
final class Transcription {
    /// A unique identifier for the transcription.
    /// SwiftData can automatically manage IDs, but providing one
    /// can be useful for external references or debugging.
    @Attribute(.unique) var id: UUID

    /// The actual text transcribed from the user's speech.
    var text: String

    /// The timestamp when the transcription was recorded.
    var timestamp: Date

    /// An optional sentiment score, which could be derived from NLP analysis
    /// (e.g., -1.0 for very negative, 1.0 for very positive).
    var sentimentScore: Double?

    /// A flag indicating if the user has marked this transcription as a favorite.
    var isFavorite: Bool

    /// Initializes a new Transcription instance.
    ///
    /// - Parameters:
    ///   - id: The unique identifier for the transcription. Defaults to a new UUID.
    ///   - text: The transcribed text.
    ///   - timestamp: The date and time of the transcription. Defaults to the current date.
    ///   - sentimentScore: An optional sentiment score.
    ///   - isFavorite: A boolean indicating if it's a favorite.
    init(id: UUID = UUID(), text: String, timestamp: Date = Date(), sentimentScore: Double? = nil, isFavorite: Bool = false) {
        self.id = id
        self.text = text
        self.timestamp = timestamp
        self.sentimentScore = sentimentScore
        self.isFavorite = isFavorite
    }
}

// MARK: - Basic SwiftData Operations Example

/// Main entry point for demonstrating basic SwiftData model operations.
/// This function simulates a part of an application's lifecycle where
/// data is created, read, updated, and deleted.
@available(iOS 18.0, macOS 15.0, *) // SwiftData is iOS 17+, but using 18.0 as per instruction for @available
func demonstrateBasicSwiftDataOperations() async {
    print("--- Starting SwiftData Operations Demonstration ---")

    do {
        // 1. Configure the ModelContainer
        // The ModelContainer is the central object that manages the persistent store.
        // For demonstration, we'll use an in-memory store, which is temporary and
        // ideal for testing or previews. For a real app, you'd typically use
        // .default(), which creates a persistent SQLite store.
        let config = ModelConfiguration(is           StoredInMemoryOnly: true)
        let container = try ModelContainer(for: Transcription.self, configurations: config)

        // 2. Obtain a ModelContext
        // The ModelContext is your primary interface for interacting with your data.
        // It's like a scratchpad where you make changes before saving them to the persistent store.
        let context = ModelContext(container)

        // 3. Create New Transcription Records
        print("\nCreating new transcription records...")
        let transcription1 = Transcription(text: "Hey Siri, what's the weather like today?", sentimentScore: 0.7)
        let transcription2 = Transcription(text: "Remind me to buy groceries.", sentimentScore: 0.2, isFavorite: true)
        let transcription3 = Transcription(text: "Cancel my 3 PM meeting.", sentimentScore: -0.5)

        // 4. Insert Records into the ModelContext
        // Inserting adds the objects to the context, making them known to SwiftData.
        // They are not yet saved to the persistent store until the context saves changes.
        context.insert(transcription1)
        context.insert(transcription2)
        context.insert(transcription3)

        // 5. Save Changes
        // Explicitly saving the context persists all pending changes (inserts, updates, deletes)
        // to the underlying data store. If not called, changes might be lost or not visible
        // across different contexts.
        try context.save()
        print("Successfully inserted 3 transcriptions and saved.")

        // 6. Fetch All Transcription Records
        // Fetching allows you to retrieve stored objects.
        // A `FetchDescriptor` specifies which model to fetch and can include predicates, sorts, etc.
        print("\nFetching all transcriptions:")
        let allTranscriptions = try context.fetch(FetchDescriptor<Transcription>())
        for transcription in allTranscriptions {
            print("  - [\(transcription.id.uuidString.prefix(8))] Text: '\(transcription.text)', Favorite: \(transcription.isFavorite)")
        }

        // 7. Update a Record
        // To update, simply modify the properties of an object already managed by the context.
        // SwiftData tracks these changes automatically.
        print("\nUpdating transcription2 to no longer be a favorite...")
        transcription2.isFavorite = false // Modify the property
        transcription2.text = "Remind me to buy groceries and milk." // Another update
        try context.save() // Save the update
        print("Transcription2 updated and saved.")

        // 8. Fetch the updated record to verify
        print("\nVerifying update for transcription2:")
        let updatedTranscription2 = try context.fetch(FetchDescriptor<Transcription>(predicate: #Predicate { $0.id == transcription2.id })).first
        if let updated = updatedTranscription2 {
            print("  - [\(updated.id.uuidString.prefix(8))] Updated Text: '\(updated.text)', Favorite: \(updated.isFavorite)")
        }

        // 9. Delete a Record
        // To delete, pass the managed object to the context's delete method.
        print("\nDeleting transcription3...")
        context.delete(transcription3)
        try context.save() // Save the deletion
        print("Transcription3 deleted and saved.")

        // 10. Fetch All Records Again to Verify Deletion
        print("\nFetching all transcriptions after deletion:")
        let remainingTranscriptions = try context.fetch(FetchDescriptor<Transcription>())
        if remainingTranscriptions.isEmpty {
            print("  No transcriptions remaining.")
        } else {
            for transcription in remainingTranscriptions {
                print("  - [\(transcription.id.uuidString.prefix(8))] Text: '\(transcription.text)'")
            }
        }

    } catch {
        print("An error occurred during SwiftData operations: \(error.localizedDescription)")
    }

    print("\n--- SwiftData Operations Demonstration Complete ---")
}

// To run this example in a Playground or an application:
// You would typically call this from an async context, e.g., in a Task.
// Task {
//     await demonstrateBasicSwiftDataOperations()
// }
