
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import RealityKit
import Observation

// MARK: - 1. Sendable Result
struct InferenceResult: Sendable, Identifiable {
    let id: UUID
    let label: String
    let position: SIMD3<Float>
}

// MARK: - 2. The Inference Actor
actor SpatialInferenceActor {
    private var isRunning = false
    
    /// Simulates a heavy CoreML inference process
    func startInferenceStream() -> AsyncStream<InferenceResult> {
        isRunning = true
        
        return AsyncStream { continuation in
            Task {
                while isRunning {
                    // Simulate heavy computation delay (e.g., 500ms inference)
                    try? await Task.sleep(for: .milliseconds(500))
                    
                    // Create a simulated detection
                    let result = InferenceResult(
                        id: UUID(),
                        label: "Object \(Int.random(in: 1...100))",
                        position: [
                            Float.random(in: -0.5...0.5),
                            0,
                            Float.random(in: -0.5...0.5)
                        ]
                    )
                    
                    continuation.yield(result)
                }
                continuation.finish()
            }
        }
    }
    
    func stop() {
        isRunning = false
    }
}

// MARK: - 3. The Scene Manager (Main Actor)
@MainActor
class SpatialSceneManager: ObservableObject {
    private let inferenceActor = SpatialInferenceActor()
    private var tags: [UUID: Entity] = [:]
    private var inferenceTask: Task<Void, Never>?
    
    var realityViewContent: RealityViewContent?

    func startMonitoring(content: RealityViewContent) {
        self.realityViewContent = content
        
        // Start the async pipeline
        inferenceTask = Task {
            let stream = await inferenceActor.startInferenceStream()
            
            for await result in stream {
                // Check for cancellation
                if Task.isCancelled { break }
                
                updateScene(with: result)
            }
        }
    }
    
    func stopMonitoring() {
        inferenceTask?.cancel()
        Task {
            await inferenceActor.stop()
        }
    }
    
    private func updateScene(with result: InferenceResult) {
        // 1. Remove old tags (Simulating "Object No Longer Detected")
        if tags.count > 5 {
            let firstKey = tags.keys.first!
            tags[firstKey]?.removeFromParent()
            tags.removeValue(forKey: firstKey)
        }
        
        // 2. Create new Information Tag
        let mesh = MeshResource.generateText(
            result.label,
            extrusionDepth: 0.01,
            font: .system(size: 0.05)
        )
        let material = UnlitMaterial(color: .cyan)
        let tagEntity = ModelEntity(mesh: mesh, materials: [material])
        
        tagEntity.position = result.position
        
        // 3. Add to scene
        realityViewContent?.add(tagEntity)
        tags[result.id] = tagEntity
    }
}

// MARK: - 4. View
struct AISpatialView: View {
    @StateObject private var sceneManager = SpatialSceneManager()
    
    var body: some View {
        RealityView { content in
            // Initial scene setup
            sceneManager.startMonitoring(content: content)
        } onUpdate: { content in
            // Handle updates if necessary
        }
        .onDisappear {
            sceneManager.stopMonitoring()
        }
    }
}
