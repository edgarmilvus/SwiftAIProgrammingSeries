
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import RoomPlan

enum FitResult {
    case fits(area: CGRect)
    case tooLarge
    case obstructs(element: RoomPlan.RoomElement.Category)
}

struct FurnitureDimensions {
    let width: Double
    let height: Double
    let depth: Double
    
    var footprint: CGSize {
        CGSize(width: width, height: depth)
    }
}

actor SmartFitEngine {
    
    /// Validates if furniture fits in the provided captured room
    func checkFit(for dimensions: FurnitureDimensions, in room: CapturedRoom) async -> FitResult {
        // 1. Find the floor
        guard let floor = room.elements.first(where: { $0.category == .floor }) else {
            return .tooLarge
        }
        
        // 2. Extract floor bounds (Simplified for calculation)
        // In a real app, we would convert the floor's transform and dimensions into a CGRect
        let floorRect = CGRect(x: 0, y: 0, width: floor.dimensions.x, height: floor.dimensions.z)
        
        // 3. Check if furniture footprint fits within floor area
        if dimensions.width > floor.dimensions.x || dimensions.depth > floor.dimensions.z {
            return .tooLarge
        }
        
        // 4. Obstacle Awareness: Door Check
        // We check the distance between the furniture's proposed center and any door
        for element in room.elements {
            if element.category == .door {
                let distance = calculateDistance(
                    from: floor.transform.translation, 
                    to: element.transform.translation
                )
                
                // If the furniture is within the 'swing radius' of the door
                // We assume door width is a proxy for the buffer zone
                if distance < element.dimensions.x {
                    return .obstructs(element: .door)
                }
            }
        }
        
        return .fits(area: floorRect)
    }
    
    // Helper to calculate Euclidean distance between two SIMD3 positions
    private func calculateDistance(from: SIMD3<Float>, to: SIMD3<Float>) -> Float {
        distance(from, to)
    }
}

// Extension to help extract translation from a transform matrix
extension simd_float4x4 {
    var translation: SIMD3<Float> {
        SIMD3<Float>(columns.3.x, columns.3.y, columns.3.z)
    }
}
