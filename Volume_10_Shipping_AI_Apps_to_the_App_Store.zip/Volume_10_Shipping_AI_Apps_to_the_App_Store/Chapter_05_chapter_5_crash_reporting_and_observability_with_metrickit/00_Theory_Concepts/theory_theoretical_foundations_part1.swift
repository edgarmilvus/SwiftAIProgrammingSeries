
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import MetricKit

/// An actor responsible for handling MetricKit payloads.
/// Using an actor ensures that as we process large, complex 
/// MXMetricPayloads, we do not introduce data races 
/// when updating our internal analytics state.
@available(iOS 18.0, *)
actor TelemetryEngine: NSObject, MXMetricManagerDelegate {
    
    // Internal state representing the health of our AI models
    private(set) var totalInferenceCrashes: Int = 0
    private(set) var averageMemoryPressure: Double = 0.0
    
    // A Sendable structure to pass processed insights to the UI
    struct AIHealthReport: Sendable {
        let crashCount: Int
        let isMemoryCritical: Bool
    }

    /// This method is called by the system when new metrics are available.
    /// Because this is an actor, the system's call to this delegate 
    /// is safely isolated.
    nonisolated func didReceive(_ payloads: [MXMetricPayload],!) {
        // We transition from the nonisolated delegate callback 
        // into the actor's isolated context using a Task.
        Task {
            await self.processPayloads(payloads)
        }
    }

    private func processPayloads(_ payloads: [MXMetricPayload]) {
        for payload in payloads {
            // Analyze CPU/GPU/NPU usage
            // In a real AI app, we would correlate these with 
            // our custom 'InferenceDuration' metrics.
            if let cpuMetric = payload.cpuMetrics {
                // Log CPU usage for heavy pre-processing tasks
                print("CPU Utilization: \(cpuMetric.cumulativeCPUUsage)")
            }
            
            // Analyze Memory: Crucial for Large Language Models (LLMs)
            if let memoryMetric = payload.memoryMetrics {
                self.averageMemoryPressure = memoryMetric.peakMemoryUsage
                
                // If peak memory usage exceeds a threshold, we flag it.
                // This is where we catch the "Silent Failures" 
                // discussed earlier.
            }
            
            // Analyze Crashes
            if let crashMetric = payload.crashMetrics {
                self.totalInferenceCrashes += crashMetric.crashCount
            }
        }
    }
    
    func generateReport() -> AIHealthReport {
        return AIHealthReport(
            crashCount: totalInferenceCrashes,
            isMemoryCritical: averageMemoryPressure > 1_500_000_000 // 1.5GB threshold
        )
    }
}
