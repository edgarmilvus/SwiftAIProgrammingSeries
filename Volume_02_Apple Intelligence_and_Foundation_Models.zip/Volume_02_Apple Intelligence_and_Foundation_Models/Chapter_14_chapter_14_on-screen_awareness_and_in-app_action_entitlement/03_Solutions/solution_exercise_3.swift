
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AppIntents
import Foundation // For URL, etc.

// MARK: - On-Screen Awareness Components

@available(iOS 18.0, *)
struct EmailSenderMetadata: Codable {
    let emailAddress: String
    let senderName: String?
}

// Dummy Email data model
struct Email {
    let id = UUID()
    let senderEmail: String
    let senderName: String?
    let subject: String
    let body: String
}

@available(iOS 18.0, *)
class EmailDetailViewController: UIViewController {
    var currentEmail: Email! // Assume this is populated with the currently viewed email

    private let senderLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .headline)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isUserInteractionEnabled = true // Essential for context menus and AI interaction
        return label
    }()

    private let subjectLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .title2)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let bodyTextView: UITextView = {
        let textView = UITextView()
        textView.font = .preferredFont(forTextStyle: .body)
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Email"
        view.backgroundColor = .systemBackground

        // Simulate an email being loaded
        currentEmail = Email(senderEmail: "john.doe@example.com", senderName: "John Doe", subject: "Project Update", body: "Hi team, here's the latest update...")

        setupUI()
        provideContentContext()
    }

    private func setupUI() {
        view.addSubview(senderLabel)
        view.addSubview(subjectLabel)
        view.addSubview(bodyTextView)

        NSLayoutConstraint.activate([
            senderLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            senderLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            senderLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            subjectLabel.topAnchor.constraint(equalTo: senderLabel.bottomAnchor, constant: 10),
            subjectLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            subjectLabel.trailingAnchor.constraint(equalTo: view.trailingGuide.trailingAnchor, constant: -20),

            bodyTextView.topAnchor.constraint(equalTo: subjectLabel.bottomAnchor, constant: 10),
            bodyTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            bodyTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            bodyTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        senderLabel.text = currentEmail.senderName ?? currentEmail.senderEmail
        subjectLabel.text = currentEmail.subject
        bodyTextView.text = currentEmail.body
    }

    private func provideContentContext() {
        let metadata = EmailSenderMetadata(emailAddress: currentEmail.senderEmail, senderName: currentEmail.senderName)
        
        guard let encodedMetadata = try? JSONEncoder().encode(metadata) else {
            print("Failed to encode EmailSenderMetadata.")
            return
        }

        let senderContentContext = UIContentContext(
            identifier: ContentIdentifier(rawValue: "email-sender-\(currentEmail.senderEmail.hashValue)"),
            metadata: encodedMetadata
            // No specific ContentAction here, as the AppIntent will be suggested by AI based on context.
        )

        // Associate with the UI element displaying the sender's information.
        senderLabel.contentContext = senderContentContext

        // Why this is important:
        // By providing the sender's email address as structured content, Apple Intelligence can understand "who" is on screen.
        // This allows it to suggest actions relevant to that sender, like archiving all their emails, without the user manually typing the address.
        // The `resolvesByContentContext` parameter in the AppIntent will then leverage this on-screen information.
    }
}

// MARK: - In-App Action Declaration

@available(iOS 18.0, *)
struct ArchiveSenderEmailsIntent: AppIntent {
    static var title: LocalizedStringResource = "Archive Sender's Emails"
    static var description: IntentDescription = "Archives all emails from a specific sender."

    // This parameter is crucial. It tells Apple Intelligence that this parameter can be
    // automatically filled by content visible on the screen.
    @Parameter(
        title: "Sender Email Address",
        description: "The email address of the sender whose emails should be archived.",
        resolvesByContentContext: true // This hint enables AI to pick up the email from UIContentContext
    )
    var senderEmailAddress: String

    // Provide a summary for Siri/Apple Intelligence to display
    static var parameterSummary: some ParameterSummary {
        Summary("Archive all emails from \(\.$senderEmailAddress)") {
            // Optional: Provide a custom prompt for the parameter if needed
            $0.presenter("Which sender's emails would you like to archive?")
        }
    }

    // This intent requires user confirmation before performing a potentially destructive action.
    // Conforming to `ProvidesConfirmation` enables the `requestConfirmation` method.
    func perform() async throws -> some IntentResult & ProvidesConfirmation {
        // First, request confirmation from the user.
        // The confirmation dialog should clearly state what action will be performed.
        let confirmation = try await requestConfirmation(
            confirmationMessage: "Are you sure you want to archive all emails from \(senderEmailAddress)? This action cannot be undone."
        )

        guard confirmation else {
            // User cancelled the action
            return .result(response: "Archiving cancelled for \(senderEmailAddress).")
        }

        // Your actual archiving logic goes here.
        // For this exercise, simulate the action.
        print("Archiving all emails from \(senderEmailAddress)...")
        // In a real app:
        // await EmailClient.shared.archiveEmails(from: senderEmailAddress)
        // You might also update UI or notify the user of the progress/completion.

        // Return a result indicating success or failure.
        return .result(response: "Successfully archived emails from \(senderEmailAddress).")
    }
}

// Remember to add the com.apple.developer.siri.action-intents entitlement for ArchiveSenderEmailsIntent.
// This is done via Xcode's "Signing & Capabilities" tab by adding "Siri & Search" and then
// configuring the App Intents in the Info.plist section or the App Intents Definition file.
