
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import ARKit

struct PhysicsAgentView: View {
    var body: some View {
        ARViewContainer().edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        config.sceneReconstruction = .meshWithClassification
        arView.session.run(config)
        
        arView.session.delegate = context.coordinator
        context.coordinator.arView = arView
        
        // Add a tap gesture to "throw" the ball
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.throwBall(_:)))
        arView.addGestureRecognizer(tap)
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    class Coordinator: NSObject, ARSessionDelegate {
        weak var arView: ARView?
        var meshEntities: [UUID: Entity] = [:]
        
        @objc func throwBall(_ recognizer: UITapGestureRecognizer) {
            guard let arView = arView else { return }
            let tapLocation = recognizer.location(in: arView)
            
            // Create the "Bouncy Ball"
            let ballMesh = MeshResource.generateSphere(radius: 0.05)
            let ballMaterial = PhysicsMaterialResource.generate(friction: 0.1, restitution: 0.9)
            let ballEntity = ModelEntity(mesh: ballMesh, materials: [SimpleMaterial(color: .red, isMetallic: true)])
            
            // Add Physics
            let physicsBody = PhysicsBodyComponent(massProperties: .init(mass: 0.5), material: ballMaterial, mode: .dynamic)
            ballEntity.components.set(physicsBody)
            ballEntity.components.set(CollisionComponent(shapes: [.generateSphere(radius: 0.05)]))
            
            // Position at camera and launch
            let cameraTransform = arView.cameraTransform
            ballEntity.setTransformMatrix(cameraTransform.matrix, relativeTo: nil)
            
            let anchor = AnchorEntity(world: cameraTransform.matrix.columns.3.xyz) // Simplified
            arView.scene.addAnchor(AnchorEntity(world: cameraTransform.matrix))
            arView.scene.anchors.last?.addChild(ballEntity)
            
            // Apply impulse
            let impulse = SIMD3<Float>(0, 0, -5) // Forward launch
            ballEntity.applyImpulse(impulse, at: [0,0,0], relativeTo: nil)
        }
        
        // MARK: - ARSessionDelegate (Physics Integration)
        
        func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
            for anchor in anchors {
                if let meshAnchor = anchor as? ARMeshAnchor {
                    processMeshAnchor(meshAnchor)
                }
            }
        }
        
        private func processMeshAnchor(_ anchor: ARMeshAnchor) {
            guard let arView = arView else { return }
            
            // Optimization: Physics Culling
            // Only process meshes within 3 meters of the camera
            let cameraPos = arView.cameraTransform.translation
            let anchorPos = anchor.transform.translation
            if distance(cameraPos, anchorPos) > 3.0 { return }
            
            // Perform heavy collision generation on a background thread
            Task.detached(priority: .high) {
                let collisionShape = try? await self.generateCollisionShape(from: anchor)
                
                await MainActor.run {
                    self.applyPhysicsToEntity(anchor: anchor, shape: collisionShape, in: arView)
                }
            }
        }
        
        private func generateCollisionShape(from anchor: ARMeshAnchor) async throws -> ShapeResource? {
            // This is a heavy computation
            return try await Task.detached {
                // In a production app, we convert the mesh geometry to a ShapeResource
                // Using ShapeResource.generateStaticMesh(from: meshDescriptor)
                return ShapeResource.generateBox(size: [1, 1, 1]) // Placeholder
            }.value
        }
        
        @MainActor
        private func applyPhysicsToEntity(anchor: ARMeshAnchor, shape: ShapeResource?, in arView: ARView) {
            guard let shape = shape else { return }
            
            let entity = ModelEntity()
            entity.components.set(CollisionComponent(shapes: [shape]))
            entity.components.set(PhysicsBodyComponent(massProperties: .default, material: .default, mode: .static))
            
            let anchorEntity = AnchorEntity(anchor: anchor)
            anchorEntity.addChild(entity)
            arView.scene.addAnchor(anchorEntity)
        }
    }
}

extension simd_float4x4 {
    var xyz: SIMD3<Float> { SIMD3<Float>(columns.3.x, columns.3.y, columns.3.z) }
}
