
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

// LLMInferenceError.swift
/// Custom error types for LLM operations, providing specific context for failures.
enum LLMInferenceError: Error, LocalizedError {
    case modelNotFound(path: String)
    case modelLoadingFailed(reason: String)
    case inferenceFailed(reason: String)
    case noModelLoaded
    case invalidResponse(details: String)
    case cancellationError

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let path):
            return "The specified model file was not found at: \(path)"
        case .modelLoadingFailed(let reason):
            return "Failed to load the LLM model: \(reason)"
        case .inferenceFailed(let reason):
            return "LLM inference failed: \(reason)"
        case .noModelLoaded:
            return "No LLM model is currently loaded. Please load a model first."
        case .invalidResponse(let details):
            return "The LLM returned an invalid or unexpected response: \(details)"
        case .cancellationError:
            return "The LLM operation was cancelled."
        }
    }
}
