
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import PhotosUI
import CoreML
import UIKit
import VideoToolbox // Needed for CVPixelBuffer conversion

// MARK: - UIImage Extension (from Exercise 1, reused)

extension UIImage {
    func toCVPixelBuffer(width: Int, height: Int, pixelFormat: OSType) -> CVPixelBuffer? {
        // ... (Same implementation as in Exercise 1) ...
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: AnyObject] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:] as AnyObject
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: width,
                                height: height,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        guard let cgImage = self.cgImage else {
            CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

        return pixelBuffer
    }
}

// MARK: - AppState Observable Object

@Observable
class SightSenseViewModel {
    enum AppState {
        case loadingModel
        case ready
        case inferring
        case error(String)
    }

    var appState: AppState = .loadingModel
    var selectedImage: UIImage?
    var classificationResult: String?
    var confidence: String?
    var showAlert: Bool = false // Controls alert presentation

    private var coreMLModel: SqueezeNet? // Hold the loaded model instance

    // SqueezeNet expects 227x227 image in BGRA 8-bit format
    private let modelInputWidth: Int = 227
    private let modelInputHeight: Int = 227
    private let modelInputPixelFormat: OSType = kCVPixelFormatType_32BGRA

    init() {
        // Asynchronously load the model when the ViewModel is initialized
        Task { await loadModel() }
    }

    @MainActor
    func loadModel() async {
        appState = .loadingModel
        showAlert = false // Reset alert state

        do {
            self.coreMLModel = try SqueezeNet(configuration: MLModelConfiguration())
            appState = .ready
        } catch {
            appState = .error("Failed to load Core ML model: \(error.localizedDescription). Please restart the app.")
            showAlert = true
            print("Model Loading Error: \(error)")
        }
    }

    @MainActor
    func classifyImage(_ uiImage: UIImage) async {
        guard case .ready = appState else {
            // Cannot classify if model isn't ready or already inferring/errored
            if case .error(let msg) = appState {
                errorMessage = msg
                showAlert = true
            } else {
                errorMessage = "Model not ready for classification. Current state: \(String(describing: appState))"
                showAlert = true
            }
            return
        }

        appState = .inferring
        showAlert = false // Reset alert state
        classificationResult = nil
        confidence = nil
        selectedImage = uiImage // Store the image for display

        guard let model = coreMLModel else {
            appState = .error("Core ML model is not loaded.")
            showAlert = true
            return
        }

        guard let pixelBuffer = uiImage.toCVPixelBuffer(width: modelInputWidth, height: modelInputHeight, pixelFormat: modelInputPixelFormat) else {
            appState = .error("Selected image is not compatible. Failed to convert to required format (227x227 BGRA).")
            showAlert = true
            return
        }

        do {
            let input = SqueezeNetInput(image: pixelBuffer)
            let output = try await model.prediction(input: input)

            if let (label, confidenceValue) = output.featureValue(for: "classLabelProbs")?.dictionaryValue.max(by: { $0.value.doubleValue < $1.value.doubleValue }) {
                classificationResult = label
                confidence = String(format: "%.2f%%", confidenceValue.doubleValue * 100)
                appState = .ready // Ready for next classification
            } else {
                appState = .error("Could not interpret model output.")
                showAlert = true
            }
        } catch {
            appState = .error("Classification failed: \(error.localizedDescription)")
            showAlert = true
            print("Core ML Inference Error: \(error)")
        }
    }

    // Helper to extract error message from appState
    var errorMessage: String? {
        if case .error(let message) = appState {
            return message
        }
        return nil
    }

    // Helper to determine if a retry is possible
    var canRetry: Bool {
        if case .error = appState {
            return true
        }
        return false
    }
}

// MARK: - SwiftUI View

struct SightSenseView: View {
    @State private var viewModel = SightSenseViewModel()
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            VStack {
                // Display selected image
                if let image = viewModel.selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .cornerRadius(10)
                        .padding()
                } else {
                    Text("Select an image to classify!")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding()
                }

                // Display current state and results
                switch viewModel.appState {
                case .loadingModel:
                    ProgressView("Loading AI Model...")
                        .padding()
                case .ready:
                    if let result = viewModel.classificationResult, let conf = viewModel.confidence {
                        VStack {
                            Text("Prediction: \(result)")
                                .font(.title2)
                                .fontWeight(.bold)
                            Text("Confidence: \(conf)")
                                .font(.title3)
                                .foregroundColor(.secondary)
                        }
                        .padding()
                    } else {
                        Text("Model Ready. Awaiting image selection.")
                            .foregroundColor(.green)
                            .padding()
                    }
                case .inferring:
                    ProgressView("Classifying Image...")
                        .padding()
                case .error(let message):
                    VStack {
                        Text("Error: \(message)")
                            .foregroundColor(.red)
                            .padding()
                        if viewModel.canRetry {
                            Button("Retry Model Load") {
                                Task { await viewModel.loadModel() }
                            }
                            .buttonStyle(.borderedProminent)
                            .padding(.top, 5)
                        }
                    }
                }

                Spacer()

                PhotosPicker(
                    selection: $selectedPhotoItem,
                    matching: .images,
                    photoLibrary: .shared()
                ) {
                    Label("Select Photo", systemImage: "photo.on.rectangle.angled")
                        .font(.headline)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .disabled(viewModel.appState == .loadingModel || viewModel.appState == .inferring) // Disable picker during loading/inference
                .padding(.bottom)
            }
            .navigationTitle("SightSense")
            .onChange(of: selectedPhotoItem) { newItem in
                Task {
                    if let newItem {
                        do {
                            if let data = try await newItem.loadTransferable(type: Data.self),
                               let uiImage = UIImage(data: data) {
                                await viewModel.classifyImage(uiImage)
                            } else {
                                viewModel.appState = .error("Could not load selected image data.")
                                viewModel.showAlert = true
                            }
                        } catch {
                            viewModel.appState = .error("Failed to load image: \(error.localizedDescription)")
                            viewModel.showAlert = true
                        }
                    } else {
                        // User cancelled photo picker
                        if case .inferring = viewModel.appState {
                            // If cancellation happened during an ongoing inference, leave it.
                            // Otherwise, if in an error state from a previous action, don't clear it.
                        } else if case .error = viewModel.appState {
                            // Don't clear error if user cancelled picker
                        } else {
                            viewModel.appState = .ready // Back to ready state if nothing was happening
                        }
                    }
                }
            }
            .alert("Error", isPresented: $viewModel.showAlert, presenting: viewModel.errorMessage) { errorMessage in
                Button("OK") { viewModel.showAlert = false }
                if viewModel.canRetry {
                    Button("Retry") {
                        Task { await viewModel.loadModel() }
                    }
                }
            } message: { errorMessage in
                Text(errorMessage)
            }
        }
    }
}
