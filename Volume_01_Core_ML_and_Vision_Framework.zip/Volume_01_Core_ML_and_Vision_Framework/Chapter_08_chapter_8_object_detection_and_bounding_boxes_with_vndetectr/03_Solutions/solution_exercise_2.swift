
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import Vision
import PhotosUI

// Re-using the UIImage extension from Exercise 1 for coordinate conversion
extension UIImage {
    func rectForImageView(imageView: UIImageView) -> CGRect {
        let imageViewSize = imageView.bounds.size
        let imageSize = self.size

        let scaleWidth = imageViewSize.width / imageSize.width
        let scaleHeight = imageViewSize.height / imageSize.height

        var scale: CGFloat
        var xOffset: CGFloat = 0
        var yOffset: CGFloat = 0

        switch imageView.contentMode {
        case .scaleAspectFit:
            scale = min(scaleWidth, scaleHeight)
            xOffset = (imageViewSize.width - imageSize.width * scale) / 2.0
            yOffset = (imageViewSize.height - imageSize.height * scale) / 2.0
        case .scaleAspectFill:
            scale = max(scaleWidth, scaleHeight)
            xOffset = (imageViewSize.width - imageSize.width * scale) / 2.0
            yOffset = (imageViewSize.height - imageSize.height * scale) / 2.0
        case .center:
            scale = 1.0
            xOffset = (imageViewSize.width - imageSize.width) / 2.0
            yOffset = (imageViewSize.height - imageSize.height) / 2.0
        case .scaleToFill:
            return imageView.bounds
        default:
            scale = 1.0
        }
        return CGRect(x: xOffset, y: yOffset, width: imageSize.width * scale, height: imageSize.height * scale)
    }
}

class ScreenDetectionViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private let imageView = UIImageView()
    private let selectImageButton = UIButton(type: .system)
    private var overlayLayers: [CALayer] = []

    // Define aspect ratio ranges with a small tolerance
    private let aspectRatio16x9Range: ClosedRange<CGFloat> = (16.0/9.0 - 0.05)...(16.0/9.0 + 0.05) // ~1.777 +/- 0.05
    private let aspectRatio4x3Range: ClosedRange<CGFloat> = (4.0/3.0 - 0.05)...(4.0/3.0 + 0.05)   // ~1.333 +/- 0.05

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .lightGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        selectImageButton.setTitle("Select Image", for: .normal)
        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        selectImageButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImageButton)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor, multiplier: 3/4), // Example aspect ratio

            selectImageButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    @objc private func selectImageTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }

    // MARK: - UIImagePickerControllerDelegate

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) { [weak self] in
            guard let self = self, let originalImage = info[.originalImage] as? UIImage else { return }
            self.imageView.image = originalImage
            self.detectScreens(in: originalImage)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    // MARK: - Screen Detection

    private func detectScreens(in image: UIImage) {
        // Clear previous overlays
        overlayLayers.forEach { $0.removeFromSuperlayer() }
        overlayLayers.removeAll()

        guard let cgImage = image.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return
        }

        let request = VNDetectRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                print("Rectangle detection error: \(error.localizedDescription)")
                return
            }

            guard let observations = request.results as? [VNRectangleObservation] else {
                print("No rectangles detected or could not cast results.")
                return
            }

            DispatchQueue.main.async {
                self.drawFilteredBoundingBoxes(for: observations, on: image)
            }
        }

        // Configure request parameters to be broad enough to catch potential screens
        request.minimumAspectRatio = 1.0 // Square or wider
        request.maximumAspectRatio = 2.0 // Up to 2:1 aspect ratio
        request.minimumSize = 0.1 // Detect smaller rectangles
        request.quadratureTolerance = 20 // Allow more deviation for screens that might be at an angle

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        Task {
            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
            }
        }
    }

    private func drawFilteredBoundingBoxes(for observations: [VNRectangleObservation], on image: UIImage) {
        guard let image = imageView.image else { return }

        let imageRectInView = image.rectForImageView(imageView: imageView)

        for observation in observations {
            let normalizedBoundingBox = observation.boundingBox
            let visionRectInImageCoords = VNImageRectForNormalizedRect(normalizedBoundingBox, Int(image.size.width), Int(image.size.height))

            // Calculate aspect ratio
            let aspectRatio = visionRectInImageCoords.width / visionRectInImageCoords.height

            var strokeColor: UIColor?
            var aspectRatioLabel: String?

            if aspectRatio16x9Range.contains(aspectRatio) {
                strokeColor = .blue
                aspectRatioLabel = "16:9"
            } else if aspectRatio4x3Range.contains(aspectRatio) {
                strokeColor = .green
                aspectRatioLabel = "4:3"
            }

            guard let finalStrokeColor = strokeColor, let finalLabel = aspectRatioLabel else {
                continue // Skip rectangles that don't match our criteria
            }

            // Convert Vision rect to view coordinates
            let scaledRect = CGRect(
                x: imageRectInView.origin.x + visionRectInImageCoords.origin.x * imageRectInView.width / image.size.width,
                y: imageRectInView.origin.y + (image.size.height - visionRectInImageCoords.origin.y - visionRectInImageCoords.height) * imageRectInView.height / image.size.height,
                width: visionRectInImageCoords.width * imageRectInView.width / image.size.width,
                height: visionRectInImageCoords.height * imageRectInView.height / image.size.height
            )

            // Draw bounding box
            let boundingBoxLayer = CAShapeLayer()
            boundingBoxLayer.frame = scaledRect
            boundingBoxLayer.path = UIBezierPath(rect: CGRect(origin: .zero, size: scaledRect.size)).cgPath
            boundingBoxLayer.strokeColor = finalStrokeColor.cgColor
            boundingBoxLayer.lineWidth = 2.0
            boundingBoxLayer.fillColor = nil
            imageView.layer.addSublayer(boundingBoxLayer)
            overlayLayers.append(boundingBoxLayer)

            // Draw aspect ratio label
            let textLayer = CATextLayer()
            textLayer.string = finalLabel
            textLayer.font = UIFont.systemFont(ofSize: 14)
            textLayer.fontSize = 14
            textLayer.foregroundColor = finalStrokeColor.cgColor
            textLayer.backgroundColor = UIColor.black.withAlphaComponent(0.6).cgColor
            textLayer.alignmentMode = .center
            textLayer.frame = CGRect(x: scaledRect.origin.x, y: scaledRect.origin.y - 20, width: scaledRect.width, height: 20)
            textLayer.contentsScale = UIScreen.main.scale // Important for high-res display
            imageView.layer.addSublayer(textLayer)
            overlayLayers.append(textLayer)
        }
    }
}
