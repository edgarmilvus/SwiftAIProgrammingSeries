
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

// MARK: - AIChatBubbleContentType Enum
@available(iOS 18.0, *) // Using modern SwiftUI features and for consistency with other exercises
enum AIChatBubbleContentType: Identifiable, Hashable {
    case text(String)
    case code(String)
    case image(Image) // Using SwiftUI Image directly for simplicity

    var id: String {
        switch self {
        case .text(let content): return "text-\(content.hashValue)"
        case .code(let content): return "code-\(content.hashValue)"
        case .image(_): return "image-\(UUID().uuidString)" // Images need unique IDs
        }
    }

    // Conformance to Hashable for Identifiable and use in collections
    func hash(into hasher: inout Hasher) {
        switch self {
        case .text(let content):
            hasher.combine("text")
            hasher.combine(content)
        case .code(let content):
            hasher.combine("code")
            hasher.combine(content)
        case .image(_):
            hasher.combine("image")
            // For images, hashing the image itself is complex; relying on ID for uniqueness
        }
    }

    static func == (lhs: AIChatBubbleContentType, rhs: AIChatBubbleContentType) -> Bool {
        lhs.id == rhs.id
    }
}

// MARK: - VersatileAIChatBubbleView
@available(iOS 18.0, *)
struct VersatileAIChatBubbleView: View {
    let content: AIChatBubbleContentType
    let bubbleColor: Color = .purple.opacity(0.2) // Distinct color for versatile bubble

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                switch content {
                case .text(let message):
                    Text(message)
                        .padding(10)
                        .background(bubbleColor)
                        .cornerRadius(15)
                        .contextMenu {
                            Button("Copy Message") {
                                // Conceptually copy to pasteboard
                                UIPasteboard.general.string = message
                                print("Copied text: \(message)")
                            }
                        }

                case .code(let codeSnippet):
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Code Snippet:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        ScrollView(.horizontal) { // For long lines of code
                            Text(codeSnippet)
                                .font(.system(.body, design: .monospaced)) // Monospaced font for code
                                .padding(10)
                                .background(Color.black.opacity(0.1)) // Darker background for code
                                .cornerRadius(8)
                        }
                        Button("Copy Code") {
                            // Conceptually copy to pasteboard
                            UIPasteboard.general.string = codeSnippet
                            print("Copied code: \(codeSnippet)")
                        }
                        .buttonStyle(.borderedProminent)
                        .font(.caption)
                    }
                    .padding(10)
                    .background(bubbleColor)
                    .cornerRadius(15)

                case .image(let image):
                    VStack(alignment: .leading, spacing: 4) {
                        Text("AI Generated Image:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(maxWidth: 200, maxHeight: 200)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.primary.opacity(0.2), lineWidth: 1)
                            )
                            .onTapGesture {
                                print("Tapped image to expand (conceptual)")
                                // In a real app, present a full-screen image viewer
                            }
                    }
                    .padding(10)
                    .background(bubbleColor)
                    .cornerRadius(15)
                }
            }
            .frame(maxWidth: 300, alignment: .leading) // Constrain width for all content types
            Spacer()
        }
    }
}

// MARK: - ContentView for demonstration
@available(iOS 18.0, *)
struct ContentViewVersatile: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                UserChatBubbleView(message: "Show me an example of a versatile AI response.") // Reusing Ex1 bubble
                
                VersatileAIChatBubbleView(content: .text("Here's a standard text response from the AI. You can long-press this message to copy its content."))
                
                VersatileAIChatBubbleView(content: .code("""
                func calculateFibonacci(n: Int) -> Int {
                    if n <= 1 { return n }
                    return calculateFibonacci(n: n - 1) + calculateFibonacci(n: n - 2)
                }
                print(calculateFibonacci(n: 10))
                """))
                
                VersatileAIChatBubbleView(content: .image(Image(systemName: "photo.fill"))) // Placeholder image
                
                UserChatBubbleView(message: "That's really cool! The code formatting and copy button are great.")
            }
            .padding()
        }
        .navigationTitle("Versatile AI Chat")
    }
}

// MARK: - Preview Provider
@available(iOS 18.0, *)
#Preview {
    ContentViewVersatile()
}
