/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part6.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * FILE: app/projects/[id]/@modal/edit/page.tsx
 * PURPOSE: Intercepting Route (Modal Context).
 *          This renders when the URL matches /projects/:id/@modal/edit.
 *          It acts as a "modal" overlay over the current view.
 * ==============================================================================
 */
'use client';

import { useRouter } from 'next/navigation';
import { UpdateProjectForm } from '../../dashboard/update-form';

export default function EditModal({ params }: { params: { id: string } }) {
  const router = useRouter();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Quick Edit (Modal)</h2>
          <button 
            onClick={() => router.back()} 
            className="text-gray-500 hover:text-gray-800"
          >
            ✕
          </button>
        </div>
        
        <p className="mb-4 text-sm text-gray-600">
          This content is intercepted. The URL is <code>/projects/{params.id}/@modal/edit</code>, 
          but the underlying route is <code>/projects/{params.id}/dashboard</code>.
        </p>

        <UpdateProjectForm projectId={params.id} initialName="Project Name" />
      </div>
    </div>
  );
}
