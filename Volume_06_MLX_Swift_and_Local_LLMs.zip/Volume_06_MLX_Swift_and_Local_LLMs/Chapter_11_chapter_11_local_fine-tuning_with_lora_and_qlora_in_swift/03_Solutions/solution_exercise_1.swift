
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX
import MLXNN
import MLXOptimizers
import Foundation // For URL and file operations

// MARK: - 1. LoRALinear Module

@available(iOS 18.0, macOS 15.0, *)
final class LoRALinear: MLXNN.Module {
    let baseLinear: MLXNN.Linear // Represents the frozen pre-trained weights
    let loraA: MLXNN.Linear      // Adapter A: inputFeatures -> rank
    let loraB: MLXNN.Linear      // Adapter B: rank -> outputFeatures
    let scale: Float             // Scaling factor for LoRA delta

    init(inputFeatures: Int, outputFeatures: Int, rank: Int, scale: Float = 1.0) {
        // Initialize the base linear layer. Its weights will be frozen.
        self.baseLinear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        // Initialize LoRA adapters without bias, as per common LoRA implementations.
        self.loraA = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: rank, bias: false)
        self.loraB = MLXNN.Linear(inputFeatures: rank, outputFeatures: outputFeatures, bias: false)
        self.scale = scale
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Compute the output from the base (frozen) linear layer.
        let baseOutput = baseLinear(x)

        // Compute the LoRA delta: (input @ loraA.weight) @ loraB.weight * scale
        // Since loraA and loraB are MLXNN.Linear modules (without bias),
        // their call method performs the matrix multiplication with their weights.
        let delta = loraB(loraA(x)) * scale

        // The final output is the sum of the base output and the scaled LoRA delta.
        return baseOutput + delta
    }

    // Crucially, override parameters() to only expose the parameters of loraA and loraB.
    // This ensures that only the LoRA adapter weights are considered trainable by the optimizer.
    override var parameters: [MLXArray] {
        return loraA.parameters + loraB.parameters
    }
}

// MARK: - 2. Simple Base Classifier Model

@available(iOS 18.0, macOS 15.0, *)
final class SentimentClassifier: MLXNN.Module {
    let linear1: MLXNN.Linear
    let relu: MLXNN.ReLU
    let linear2: MLXNN.Linear

    init(inputFeatures: Int, hiddenFeatures: Int, outputFeatures: Int) {
        self.linear1 = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: hiddenFeatures)
        self.relu = MLXNN.ReLU()
        self.linear2 = MLXNN.Linear(inputFeatures: hiddenFeatures, outputFeatures: outputFeatures)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        return linear2(relu(linear1(x)))
    }
}

// MARK: - 3. LoRA-Adapted Classifier

@available(iOS 18.0, macOS 15.0, *)
final class LoRASentimentClassifier: MLXNN.Module {
    let loraLinear1: LoRALinear
    let relu: MLXNN.ReLU
    let loraLinear2: LoRALinear

    init(inputFeatures: Int, hiddenFeatures: Int, outputFeatures: Int, rank: Int) {
        // Replace the standard MLXNN.Linear layers with our custom LoRALinear layers.
        // In a real scenario, you would initialize `loraLinear1.baseLinear` and
        // `loraLinear2.baseLinear` with weights from a pre-trained `SentimentClassifier`.
        // For this exercise, they are randomly initialized, simulating pre-trained weights.
        self.loraLinear1 = LoRALinear(inputFeatures: inputFeatures, outputFeatures: hiddenFeatures, rank: rank)
        self.relu = MLXNN.ReLU()
        self.loraLinear2 = LoRALinear(inputFeatures: hiddenFeatures, outputFeatures: outputFeatures, rank: rank)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        return loraLinear2(relu(loraLinear1(x)))
    }

    // This model's `parameters` property will automatically aggregate parameters
    // from its sub-modules (`loraLinear1`, `loraLinear2`). Since `LoRALinear`
    // overrides its `parameters` to only return LoRA weights, this model will
    // correctly expose only the trainable LoRA parameters.
}

// MARK: - Training Loop and Execution

@available(iOS 18.0, macOS 15.0, *)
func runExercise1() {
    let inputFeatures = 128
    let hiddenFeatures = 64
    let outputFeatures = 2 // Binary sentiment: positive/negative
    let loraRank = 8      // LoRA rank, a small value for low-rank adaptation
    let learningRate: Float = 1e-3
    let batchSize = 32
    let numSteps = 100

    // 1. Instantiate the LoRA-adapted model
    let model = LoRASentimentClassifier(
        inputFeatures: inputFeatures,
        hiddenFeatures: hiddenFeatures,
        outputFeatures: outputFeatures,
        rank: loraRank
    )

    // 2. Optimizer for LoRA parameters only
    // The optimizer will automatically receive only the LoRA parameters
    // because `model.parameters` calls the overridden `parameters` in `LoRALinear`.
    let optimizer = MLXNN.Optimizers.AdamW(learningRate: learningRate)

    // 3. Training Loop
    print("Starting LoRA fine-tuning...")
    for step in 0..<numSteps {
        // Generate synthetic data for a binary classification task
        let x = MLXArray.randomUniform(low: 0, high: 1, [batchSize, inputFeatures]) // Input features
        // Labels (0 or 1) for cross-entropy loss, reshaped to [batchSize]
        let y = MLXArray.randomUniform(low: 0, high: 2, [batchSize], type: .int32)

        // Define the loss function closure
        let lossFn = { (model: LoRASentimentClassifier, x: MLXArray, y: MLXArray) -> MLXArray in
            let logits = model(x) // Model outputs logits for each class
            return MLXNN.Loss.crossEntropy(predictions: logits, targets: y)
        }

        // Compute loss and gradients using MLX's functional API.
        // `valueAndGradient` efficiently builds and executes the computation graph.
        let (loss, gradients) = MLX.valueAndGradient(model: model, lossFn, x, y)

        // Update *only* the LoRA parameters using the optimizer.
        optimizer.update(model: model, gradients: gradients)

        // Evaluate and print loss. `.item(Float.self)` forces eager evaluation.
        let currentLoss = loss.item(Float.self)
        if step % 10 == 0 {
            print("Step \(step), Loss: \(currentLoss)")
        }
    }
    print("LoRA fine-tuning complete.")

    // Example inference after training
    let testInput = MLXArray.randomUniform(low: 0, high: 1, [1, inputFeatures])
    let logits = model(testInput)
    let predictedSentiment = MLX.argmax(logits, axis: -1).item(Int.self)
    print("Test input predicted sentiment (0 or 1): \(predictedSentiment)")

    // Demonstrate parameter counts
    print("\nTotal trainable parameters in LoRA-adapted model: \(model.parameters.count)")
    print("Parameters of loraLinear1 (LoRA A + B): \(model.loraLinear1.parameters.count)")
    print("Parameters of loraLinear2 (LoRA A + B): \(model.loraLinear2.parameters.count)")
    // Verify that baseLinear's parameters are NOT part of the trainable set
    print("BaseLinear1 parameters count (frozen, not trained): \(model.loraLinear1.baseLinear.parameters.count)")
    print("BaseLinear2 parameters count (frozen, not trained): \(model.loraLinear2.baseLinear.parameters.count)")
}

// Call the function to run the exercise
// runExercise1()
