
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import AVFoundation
import Speech

@available(iOS 18.0, *)
actor SpeechRecognizer: ObservableObject { // ObservableObject for compatibility, @Observable is preferred
    // MARK: - Published Properties (for UI observation)
    @MainActor @Published var transcribedText: String = ""
    @MainActor @Published var isRecording: Bool = false
    @MainActor @Published var authorizationStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined
    @MainActor @Published var error: Error?

    // MARK: - Internal State (isolated by the actor)
    private var audioEngine: AVAudioEngine?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let speechRecognizer: SFSpeechRecognizer?

    init() {
        // Initialize SFSpeechRecognizer for a specific locale
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        Task { // Check authorization status on initialization
            await MainActor.run {
                self.authorizationStatus = SFSpeechRecognizer.authorizationStatus()
            }
        }
    }

    // MARK: - Public Actor Methods
    func startRecording() async throws {
        // Ensure previous task is cancelled
        if let recognitionTask {
            recognitionTask.cancel()
            self.recognitionTask = nil
        }

        // Request authorization if not determined or denied
        if await speechRecognizer?.authorizationStatus() != .authorized {
            let status = await SFSpeechRecognizer.requestAuthorization()
            await MainActor.run { self.authorizationStatus = status }
            guard status == .authorized else {
                throw SpeechRecognizerError.notAuthorized
            }
        }

        guard let speechRecognizer, speechRecognizer.isAvailable else {
            throw SpeechRecognizerError.recognizerUnavailable
        }

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        let engine = AVAudioEngine()
        self.audioEngine = engine // Store engine in actor's isolated state
        let request = SFSpeechAudioBufferRecognitionRequest()
        self.recognitionRequest = request // Store request in actor's isolated state
        request.shouldReportPartialResults = true

        // Start a recognition task
        recognitionTask = speechRecognizer.recognitionTask(with: request) { result, error in
            Task { @MainActor in // Update UI on MainActor
                if let result {
                    self.transcribedText = result.bestTranscription.formattedString
                    self.error = nil // Clear any previous error on successful result
                } else if let error {
                    self.error = error
                    self.stopRecording() // Stop on error
                }
            }
        }

        // Configure audio input
        let inputNode = engine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer) // Append buffer from background thread
        }

        engine.prepare()
        try engine.start()

        await MainActor.run { self.isRecording = true }
    }

    func stopRecording() {
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0)
        audioEngine = nil

        recognitionRequest?.endAudio()
        recognitionRequest = nil

        recognitionTask?.finish() // Or cancel() if needed
        recognitionTask = nil

        Task { @MainActor in
            self.isRecording = false
        }
    }

    enum SpeechRecognizerError: Error, LocalizedError {
        case notAuthorized
        case recognizerUnavailable
        case audioEngineError(Error)

        var errorDescription: String? {
            switch self {
            case .notAuthorized: return "Speech recognition not authorized."
            case .recognizerUnavailable: return "Speech recognizer is not available for this locale."
            case .audioEngineError(let error): return "Audio engine error: \(error.localizedDescription)"
            }
        }
    }
}
