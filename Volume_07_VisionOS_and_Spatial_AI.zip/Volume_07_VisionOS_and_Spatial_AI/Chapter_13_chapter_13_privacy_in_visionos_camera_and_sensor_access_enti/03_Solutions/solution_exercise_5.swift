
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import ARKit

/// A set of capabilities detected at runtime.
struct CapabilitySet: Sendable {
    let hasEyeTracking: Bool
    let hasHandTracking: Bool
    let hasSceneReconstruction: Bool
}

/// The Strategy Protocol: Defines how an interaction is performed.
protocol SpatialInteractionStrategy: Sendable {
    var modeName: String { get }
    func performSelection()
}

// MARK: - Concrete Strategies

struct GazeHandStrategy: SpatialInteractionStrategy {
    let modeName = "Ultra-High (Gaze + Hand)"
    func performSelection() { print("Selecting via Eye Gaze + Hand Pinch") }
}

struct HandOnlyStrategy: SpatialInteractionStrategy {
    let modeName = "Standard (Hand Only)"
    func performSelection() { print("Selecting via Hand Pinch Only") }
}

struct GazeOnlyStrategy: SpatialInteractionStrategy {
    let modeName = "Basic (Gaze Only)"
    func performSelection() { print("Selecting via Eye Gaze Only") }
}

// MARK: - Engine Implementation

@MainActor
class ZenithGameEngine: ObservableObject {
    @Published private(set) var currentStrategy: any SpatialInteractionStrategy = GazeOnlyStrategy()
    @Published private(set) var statusMessage: String = "Initializing..."
    
    /// Probes the system for available ARKit providers.
    func discoverCapabilities() async -> CapabilitySet {
        // In a real app, we would attempt to initialize providers and catch errors.
        // Mocking the discovery process:
        return CapabilitySet(
            hasEyeTracking: true, 
            hasHandTracking: false, // User denied hand tracking in settings
            hasSceneReconstruction: true
        )
    }
    
    /// Dynamically swaps the interaction strategy based on discovered capabilities.
    func configureInteractionModel() async {
        statusMessage = "Checking permissions..."
        let capabilities = await discoverCapabilities()
        
        // The Strategy Pattern: Decoupling the 'Select' intent from the 'Input' method.
        if capabilities.hasEyeTracking && capabilities.hasHandTracking {
            currentStrategy = GazeHandStrategy()
            statusMessage = "Full Experience Active"
        } else if capabilities.hasHandTracking {
            currentStrategy = HandOnlyStrategy()
            statusMessage = "Hand Tracking Active"
        } else {
            currentStrategy = GazeOnlyStrategy()
            statusMessage = "Privacy Mode: Gaze-Only Interaction"
        }
    }
    
    func userDidTapSelect() {
        currentStrategy.performSelection()
    }
}
