
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AVFoundation
import SoundAnalysis
import RealityKit
import Combine

/// Represents a specific type of environmental sound detected by the engine.
enum SonicEvent: String, CaseIterable, Sendable {
    case siren = "Siren"
    case doorbell = "Doorbell"
    case babyCrying = "Baby Crying"
    case barkingDog = "Dog Barking"
    case unknown = "Unknown"
}

/// Errors specific to the SonicSight audio processing pipeline.
enum SonicSightError: Error, LocalizedError {
    case audioEngineConfigurationFailed
    case soundAnalysisInitializationFailed
    case microphoneAccessDenied
    
    var errorDescription: String? {
        switch self {
        case .audioEngineConfigurationFailed: return "Failed to configure the AVAudioEngine."
        case .soundAnalysisInitializationFailed: return "Failed to initialize the SNAnalyzer."
        case .microphoneAccessDenied: return "Microphone access was denied by the user."
        }
    }
}

/// A data structure representing a detected sound event in 3D space.
/// Conforms to Sendable to safely pass between the Actor and the MainActor (UI/RealityKit).
struct SpatialSoundEvent: Sendable {
    let type: SonicEvent
    let confidence: Float
    let timestamp: Date
    let direction: SIMD3<Float> // The normalized direction vector of the sound
}

/// The core engine responsible for audio capture, sound classification, and spatial coordination.
/// Uses the `actor` model to ensure thread-safe processing of high-frequency audio buffers.
@available(visionOS 1.0, *)
actor SonicSightEngine {
    
    private let audioEngine = AVAudioEngine()
    private var analyzer: SNAnalyzer?
    private var classificationTask: SNResultsListener?
    
    /// A stream of detected spatial sound events that the UI/RealityKit can subscribe to.
    /// We use a PassthroughSubject to broadcast events to the MainActor.
    private let eventSubject = PassthroughSubject<SpatialSoundEvent, Never>()
    
    /// Public access to the event stream.
    nonisolated var eventStream: AnyPublisher<SpatialSoundEvent, Never> {
        eventSubject.eraseToAnyPublisher()
    }
    
    init() {
        // Initialization is handled in the start() method to allow for error handling.
    }
    
    /// Starts the audio engine and the sound analysis pipeline.
    /// - Throws: `SonicSightError` if the hardware or analysis frameworks fail.
    func start() throws {
        let inputNode = audioEngine.inputNode
        let inputFormat = inputNode.inputFormat(forBus: 0)
        
        // 1. Initialize the Sound Analyzer
        guard let analyzer = try? SNAnalyzer(format: inputFormat) else {
            throw SonicSightError.soundAnalysisInitializationFailed
        }
        self.analyzer = analyzer
        
        // 2. Define the Classification Request
        // We use the built-in system classification request.
        let request = SNClassifySoundRequest()
        
        // 3. Setup the Results Listener
        // This listener will receive classification updates as they happen.
        let listener = try SNResultsListener(analyzing: request, queue: .global(qos: .userInteractive))
        self.classificationTask = listener
        
        // 4. Subscribe to classification results
        listener.append(on: .global(qos: .userInteractive)) { [weak self] result in
            guard let self = self else { return }
            Task {
                await self.process(result: result)
            }
        }
        
        // 5. Install the Audio Tap
        // We tap the input node to feed the analyzer.
        inputNode.installTap(onBus: 0, bufferSize: 4096, format: inputFormat) { [weak self] buffer, _ in
            guard let self = self else { return }
            Task {
                await self.analyze(buffer: buffer)
            }
        }
        
        // 6. Start the Engine
        do {
            try audioEngine.start()
            try listener.startAnalyzing()
        } catch {
            throw SonicSightError.audioEngineConfigurationFailed
        }
    }
    
    /// Feeds an audio buffer into the SNAnalyzer.
    /// - Parameter buffer: The PCM buffer captured from the microphone.
    private func analyze(buffer: AVAudioPCMBuffer) {
        guard let analyzer = analyzer else { return }
        analyzer.analyze(buffer)
    }
    
    /// Processes the classification results and converts them into SpatialSoundEvents.
    /// - Parameter result: The SNClassificationResult containing identified sounds and confidence.
    private func process(result: SNClassificationResult) {
        // We look for the highest confidence classification.
        guard let topClassification = result.classifications.first(where: { $0.confidence > 0.7 }) else {
            return
        }
        
        let soundName = topClassification.identifier
        let confidence = topClassification.confidence
        
        // Map the identifier to our SonicEvent enum.
        let eventType = SonicEvent(rawValue: soundName) ?? .unknown
        
        // In a production scenario, we would use the phase/directionality of the 
        // input buffer to calculate the 'direction' vector.
        // For this advanced demonstration, we simulate a spatial direction.
        let simulatedDirection = calculateSimulatedDirection()
        
        let event = SpatialSoundEvent(
            type: eventType,
            confidence: confidence,
            timestamp: Date(),
            direction: simulatedDirection
        )
        
        // Broadcast the event to the subscribers.
        eventSubject.send(event)
    }
    
    /// Simulates directional audio detection.
    /// In a real visionOS app, this would integrate with AVFoundation's spatial audio metadata.
    private func calculateSimulatedDirection() -> SIMD3<Float> {
        // Returning a random direction for demonstration purposes.
        let angle = Float.random(in: 0...(2 * .pi))
        return SIMD3<Float>(cos(angle), 0, sin(angle))
    }
    
    /// Stops all audio processing and cleans up resources.
    func stop() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        classificationTask?.stopAnalyzing()
        analyzer = nil
    }
}

/// The RealityKit coordinator that manages the visual representation of sound events.
/// This must run on the `@MainActor` because it manipulates the Entity hierarchy.
@MainActor
class SonicSightSpatialVisualizer {
    
    private var rootEntity: Entity
    private var cancellables = Set<AnyCancellable>()
    
    /// - Parameter rootEntity: The root entity of the visionOS scene where visuals will be attached.
    init(rootEntity: Entity) {
        self.rootEntity = rootEntity
    }
    
    /// Subscribes to the engine's event stream and triggers visual feedback.
    func observe(engine: SonicSightEngine) {
        engine.eventStream
            .receive(on: RunLoop.main)
            .sink { [weak self] event in
                self?.spawnVisualIndicator(for: event)
            }
            .store(in: &cancellables)
    }
    
    /// Spawns a 3D visual indicator in the spatial environment.
    /// - Parameter event: The detected sound event.
    private func spawnVisualIndicator(for event: SpatialSoundEvent) {
        // 1. Create a visual representation (a sphere/glow)
        let mesh = MeshResource.generateSphere(radius: 0.05)
        let material = UnlitMaterial(color: color(for: event.type))
        let indicator = ModelEntity(mesh: mesh, materials: [material])
        
        // 2. Position the indicator based on the sound's direction.
        // We place it 1.5 meters away from the user in the direction of the sound.
        let distance: Float = 1.5
        indicator.position = event.direction * distance
        
        // 3. Add to the scene
        rootEntity.addChild(indicator)
        
        // 4. Animate the indicator (Pulse effect)
        let pulseAnimation = indicator.move(to: Transform(scale: .one * 1.5, 
                                                         rotation: indicator.orientation, 
                                                         translation: indicator.position),
                                           relativeTo: rootEntity,
                                           duration: 0.5,
                                           timingFunction: .easeOut)
        
        // 5. Cleanup: Remove the entity after a short duration.
        Task {
            try? await Task.sleep(nanoseconds: 2_000_000_000) // 2 seconds
            indicator.removeFromParent()
        }
    }
    
    private func color(for type: SonicEvent) -> UIColor {
        switch type {
        case .siren: return .red
        case .doorbell: return .yellow
        case .babyCrying: return .cyan
        case .barkingDog: return .orange
        case .unknown: return .white
        }
    }
}
