
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Vision
import CoreML
import AVFoundation // For camera access

// 1. Model Training (Conceptual - performed in Create ML)
//    - Assume 'FruitVegClassifier.mlmodel' is trained and added to the Xcode project.
//    - It classifies images into categories like "Apple", "Banana", "Orange", "Carrot", "Broccoli", "Tomato".

struct FruitVegClassifierView: View {
    @StateObject private var cameraManager = CameraManager()
    @State private var classificationResult: String = "No detection."
    @State private var confidenceThreshold: Float = 0.7 // Only show predictions above this confidence

    var body: some View {
        VStack {
            // Camera feed view
            CameraPreviewView(session: cameraManager.captureSession)
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
                .overlay(
                    Text(classificationResult)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.6))
                        .cornerRadius(10)
                        .offset(y: -50),
                    alignment: .bottom
                )
                .ignoresSafeArea()

        }
        .onAppear {
            cameraManager.setupCamera()
            cameraManager.setClassificationHandler { result in
                Task { @MainActor in // Ensure UI updates on the main thread
                    self.classificationResult = result
                }
            }
        }
        .onDisappear {
            cameraManager.stopSession()
        }
    }
}

// MARK: - CameraPreviewView (UIKitRepresentable for AVCaptureVideoPreviewLayer)
struct CameraPreviewView: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)

        // Ensure the preview layer fills the view's bounds
        DispatchQueue.main.async {
            previewLayer.frame = view.bounds
        }

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        if let previewLayer = uiView.layer.sublayers?.first(where: { $0 is AVCaptureVideoPreviewLayer }) as? AVCaptureVideoPreviewLayer {
            previewLayer.frame = uiView.bounds
        }
    }
}

// MARK: - CameraManager (Handles AVCaptureSession and Vision inference)
class CameraManager: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    var captureSession: AVCaptureSession = AVCaptureSession()
    private var videoOutput: AVCaptureVideoDataOutput!
    private var classificationRequest: VNCoreMLRequest?
    private let visionQueue = DispatchQueue(label: "com.example.visionQueue") // Dedicated queue for Vision processing
    private var classificationHandler: ((String) -> Void)?

    override init() {
        super.init()
        setupVision()
    }

    func setClassificationHandler(_ handler: @escaping (String) -> Void) {
        self.classificationHandler = handler
    }

    private func setupVision() {
        do {
            let config = MLModelConfiguration()
            let model = try FruitVegClassifier(configuration: config)
            let visionModel = try VNCoreMLModel(for: model.model)
            classificationRequest = VNCoreMLRequest(model: visionModel)
            classificationRequest?.imageCropAndScaleOption = .centerCrop // Or .scaleFit, depending on model training
        } catch {
            print("Error setting up Vision: \(error.localizedDescription)")
        }
    }

    func setupCamera() {
        // Request camera access
        AVCaptureDevice.requestAccess(for: .video) { granted in
            guard granted else {
                print("Camera access denied.")
                return
            }

            DispatchQueue.global(qos: .userInitiated).async { // Perform setup on a background queue
                self.captureSession = AVCaptureSession() // Re-initialize session to ensure clean state

                guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                      let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
                    print("Could not create video device input.")
                    return
                }

                self.captureSession.beginConfiguration()
                self.captureSession.sessionPreset = .hd1280x720 // Or other suitable preset

                if self.captureSession.canAddInput(videoInput) {
                    self.captureSession.addInput(videoInput)
                }

                self.videoOutput = AVCaptureVideoDataOutput()
                self.videoOutput.setSampleBufferDelegate(self, queue: self.visionQueue) // Delegate on background queue
                self.videoOutput.alwaysDiscardsLateVideoFrames = true // Discard frames if processing is slow
                self.videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

                if self.captureSession.canAddOutput(self.videoOutput) {
                    self.captureSession.addOutput(self.videoOutput)
                }

                // Ensure video orientation is correct for Vision
                if let connection = self.videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
                    connection.videoOrientation = .portrait
                }

                self.captureSession.commitConfiguration()
                self.captureSession.startRunning()
            }
        }
    }

    func stopSession() {
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Perform Vision request on the dedicated visionQueue
        guard let request = classificationRequest else { return }

        // Create a VNImageRequestHandler with the CVPixelBuffer
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        do {
            try handler.perform([request])
            guard let observations = request.results as? [VNClassificationObservation],
                  let topObservation = observations.first else {
                classificationHandler?("No detection.")
                return
            }

            // Apply a confidence threshold
            let confidenceThreshold: Float = 0.7
            if topObservation.confidence >= confidenceThreshold {
                let confidence = String(format: "%.1f%%", topObservation.confidence * 100)
                classificationHandler?("\(topObservation.identifier) \(confidence)")
            } else {
                classificationHandler?("Detecting...") // Or "Unclear" if nothing is confidently identified
            }

        } catch {
            print("Failed to perform Vision request: \(error.localizedDescription)")
            classificationHandler?("Error classifying.")
        }
    }
}

// For preview purposes
struct FruitVegClassifierView_Previews: PreviewProvider {
    static var previews: some View {
        FruitVegClassifierView()
    }
}
