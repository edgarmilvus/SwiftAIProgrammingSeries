
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

@available(iOS 18.0, *)
@Observable
@MainActor
class LuminaWriteViewModel {
    var accumulatedResponse: String = ""
    var isGenerating: Bool = false
    var errorMessage: String? = nil
    
    // Track the active task to allow for cancellation
    private var streamingTask: Task<Void, Never>?

    func sendPrompt(_ prompt: String) async {
        // 1. Cancel any existing task to prevent overlapping streams
        stopGeneration()
        
        // 2. Create a new Task and capture it
        streamingTask = Task {
            // In a real app, you would call your network service here
            // For this exercise, we assume 'service.stream(prompt:)' returns our AsyncThrowingStream
            let stream = MockStreamingService.shared.stream(prompt: prompt)
            
            await startStreaming(with: stream)
        }
    }

    private func startStreaming(with stream: AsyncThrowingStream<ChatCompletionChunk, Error>) async {
        isGenerating = true
        accumulatedResponse = ""
        
        do {
            for try await chunk in stream {
                // Check for cancellation explicitly if the loop is heavy, 
                // though 'for try await' on URLSession.bytes is natively cancellation-aware.
                try Task.checkCancellation()
                
                if let content = chunk.choices.first?.delta.content {
                    accumulatedResponse += content
                }
            }
        } catch is CancellationError {
            // User stopped the generation; clean up silently
            print("User requested interruption.")
        } catch {
            errorMessage = "Error: \(error.localizedDescription)"
        }
        
        isGenerating = false
        streamingTask = nil
    }

    func stopGeneration() {
        // 3. Trigger cooperative cancellation
        streamingTask?.cancel()
        streamingTask = nil
        
        // 4. Reset UI state immediately
        isGenerating = false
        errorMessage = nil
    }
    
    func regenerate(with prompt: String) async {
        stopGeneration()
        await sendPrompt(prompt)
    }
}

// Mock for demonstration purposes
struct MockStreamingService {
    static let shared = MockStreamingService()
    func stream(prompt: String) -> AsyncThrowingStream<ChatCompletionChunk, Error> {
        AsyncThrowingStream { continuation in
            Task {
                for i in 1...10 {
                    try? await Task.sleep(for: .seconds(0.5))
                    let chunk = ChatCompletionChunk(id: "\(i)", choices: [.init(delta: .init(content: " \(i)") )])
                    continuation.yield(chunk)
                }
                continuation.finish()
            }
        }
    }
}
