
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.swift
// Description: Solution for Exercise 9
// ==========================================

@available(macOS 14.0, iOS 18.0, *) // Adjust platform availability as per llama.cpp.swift support
import Foundation
import llama_cpp // From Package.swift dependency

// Reuse ChatMessage from Exercise 1
// Reuse Tokenizer protocol/MockTokenizer from Exercise 1

// 2. LlamaTokenizerWrapper (Mocked for easier exercise setup)
// In a real application, this would wrap llama_cpp.LlamaTokenizer
// and require a LlamaContext initialized with a .gguf model.
struct LlamaTokenizerWrapper: Tokenizer { // Conforms to Tokenizer from Exercise 1
    // Using MockTokenizer internally for simplicity in this exercise.
    // In a real app, you'd initialize and hold a llama_cpp.LlamaTokenizer instance.
    private let internalMockTokenizer = MockTokenizer() 

    // For a real llama.cpp integration, this init would take a LlamaContext
    // or an already initialized llama_cpp.LlamaTokenizer.
    // Example for real llama.cpp (requires a tiny .gguf model file, e.g., tinyllama-1.1b-chat-v1.0.Q4_0.gguf):
    /*
    private let realLlamaTokenizer: llama_cpp.LlamaTokenizer
    init(context: LlamaContext) throws {
        self.realLlamaTokenizer = try llama_cpp.LlamaTokenizer(context: context)
    }
    */
    // For the exercise, a parameterless init using the internal mock is sufficient.
    init() {
        // No-op for mock. If using real llama.cpp, this would be where a LlamaContext
        // (loaded from a model) is used to initialize the LlamaTokenizer.
        // For example, if you have a tiny model at a known path:
        /*
        do {
            let modelPath = Bundle.main.path(forResource: "tinyllama", ofType: "gguf")! // Adjust filename
            let context = try LlamaContext(modelPath: modelPath)
            self.realLlamaTokenizer = try llama_cpp.LlamaTokenizer(context: context)
        } catch {
            fatalError("Failed to initialize LlamaTokenizer: \(error)")
        }
        */
    }
    
    func tokenize(_ text: String) -> [Int] {
        // In a real app: do { return try realLlamaTokenizer.tokenize(text: text) } catch { print("Error: \(error)"); return [] }
        return internalMockTokenizer.tokenize(text)
    }

    func countTokens(_ text: String) -> Int {
        // In a real app: do { return try realLlamaTokenizer.tokenize(text: text).count } catch { return 0 }
        return internalMockTokenizer.countTokens(text)
    }
}

// 3. AsyncTokenBudgetManager Actor
actor AsyncTokenBudgetManager {
    private var messages: [ChatMessage] = [] // Isolated mutable state
    let tokenBudget: Int
    private let tokenizer: LlamaTokenizerWrapper
    private var currentTotalTokens: Int = 0 // Cached token count

    init(tokenBudget: Int, tokenizer: LlamaTokenizerWrapper) {
        self.tokenBudget = tokenBudget
        self.tokenizer = tokenizer
    }

    // Helper method to asynchronously recalculate tokens and truncate messages.
    // This is an internal method of the actor, ensuring safe access to `messages` and `currentTotalTokens`.
    private func recalculateAndTruncate() async {
        // Offload the potentially CPU-intensive token counting and array manipulation
        // to a detached task. This prevents blocking the actor's serial executor,
        // allowing other actor calls to be enqueued and potentially processed faster
        // if they don't depend on the state being modified here.
        let (newMessages, newTotalTokens) = await Task.detached { [tokenizer, tokenBudget] in
            // Capture `self.messages` by value (implicitly by the closure)
            // to work on a snapshot of the actor's current state.
            // This is crucial to avoid re-accessing `self.messages` directly
            // within the detached task, which would require `await` calls back
            // to the actor, potentially causing deadlocks or performance issues.
            var tempMessages = self.messages // `self` is implicitly captured and isolated within `Task.detached`
            var tokens = 0
            
            // Calculate initial token count for the snapshot of messages
            for msg in tempMessages {
                tokens += tokenizer.countTokens(msg.content)
            }

            // Truncate if necessary (tail truncation strategy)
            // Optimize token recalculation: instead of re-calculating all tokens,
            // subtract tokens of removed message.
            while tokens > tokenBudget && !tempMessages.isEmpty {
                let removedMessageTokens = tokenizer.countTokens(tempMessages.first!.content)
                tempMessages.removeFirst() // Remove the oldest message
                tokens -= removedMessageTokens
                // Ensure tokens don't go negative if a single message was huge and removed
                tokens = max(0, tokens) 
            }
            return (tempMessages, tokens)
        }.value // Await the result of the detached task to get the updated state
        
        // Once the background work is done, update the actor's isolated state.
        // This update happens on the actor's serial executor, ensuring thread-safety.
        self.messages = newMessages
        self.currentTotalTokens = newTotalTokens
    }

    // Public asynchronous method to add a new message.
    func addMessage(_ newMessage: ChatMessage) async {
        messages.append(newMessage) // Modify isolated state directly
        await recalculateAndTruncate() // Trigger asynchronous recalculation and truncation
    }

    // Public asynchronous method to get the current budget-compliant context.
    func getEffectiveContext() async -> [ChatMessage] {
        await recalculateAndTruncate() // Ensure context is up-to-date before returning
        return messages // Return isolated state
    }

    // Public asynchronous method to get the current total token count.
    func getCurrentTokenCount() async -> Int {
        await recalculateAndTruncate() // Ensure count is up-to-date before returning
        return currentTotalTokens // Return isolated state
    }
}
