
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
import Foundation

// A theoretical document model manager that interacts with AI
actor DocumentManager {
    private var documentContent: String
    private let aiProcessor = AITextProcessor() // Our AI actor from above

    init(initialContent: String) {
        self.documentContent = initialContent
    }

    func getContent() -> String {
        return documentContent
    }

    // Safely update document content
    func updateContent(_ newContent: String) {
        documentContent = newContent
        print("Document content updated.")
    }

    // Request AI rewrite and update content
    func requestAIRewrite(for text: String) async throws -> [String] {
        print("DocumentManager requesting AI rewrite for: '\(text)'")
        let suggestions = try await aiProcessor.rewriteText(text) // Call to another actor is safe
        // In a real app, you'd present these suggestions to the user
        // and only update documentContent if one is accepted.
        print("Received AI suggestions: \(suggestions.joined(separator: ", "))")
        return suggestions
    }
    
    // Example of applying a suggestion (after user acceptance)
    func applySuggestion(_ suggestion: String, replacing originalText: String) {
        if let range = documentContent.range(of: originalText) {
            documentContent.replaceSubrange(range, with: suggestion)
            print("Applied AI suggestion: '\(suggestion)'")
        }
    }
}
