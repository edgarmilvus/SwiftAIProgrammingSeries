
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Combine // For @Published

/// Represents the UI state for the image upscaling feature.
@available(iOS 18.0, *)
@Observable
class ImageUpscalerViewModel {
    private let upscaler: ImageUpscaler
    private var upscaleTask: Task<Void, Never>?
    private let logger = Logger(label: "com.example.AIPoweredPhotoEditor.ImageUpscalerViewModel")

    var isLoading: Bool = false
    var progressMessage: String = "Ready to upscale"
    var upscaledImage: Image?
    var errorMessage: String?
    var showAlert: Bool = false

    init(upscaler: ImageUpscaler) {
        self.upscaler = upscaler
    }

    /// Initiates the image upscaling process.
    /// - Parameter imageData: The image data to be upscaled.
    func startUpscaling(imageData: Data) {
        guard !isLoading else { return } // Prevent multiple simultaneous operations

        isLoading = true
        errorMessage = nil
        upscaledImage = nil
        showAlert = false
        progressMessage = "Starting upscaling..."

        upscaleTask = Task {
            do {
                // The AsyncThrowingStream allows us to process progress updates as they come.
                for try await progress in upscaler.upscaleImage(imageData: imageData) {
                    // Check for cancellation within the stream processing loop
                    try Task.checkCancellation()

                    await MainActor.run {
                        switch progress {
                        case .started:
                            self.progressMessage = "Upscaling started."
                        case .uploading(let percentage):
                            self.progressMessage = String(format: "Uploading: %.0f%%", percentage * 100)
                        case .processing(let message):
                            self.progressMessage = message
                        case .retrying(let attempt, let delay):
                            self.progressMessage = "Retrying (Attempt \(attempt)) in \(delay.formatted())s..."
                        case .completed(let data):
                            // In a real app, you'd convert Data to UIImage/NSImage and then to SwiftUI.Image
                            // For simplicity, we'll just show a placeholder.
                            self.upscaledImage = Image(systemName: "photo.fill")
                                .resizable()
                                .scaledToFit()
                            self.progressMessage = "Upscaling complete!"
                            self.isLoading = false
                            logger.info("Image upscaling completed successfully.")
                        }
                    }
                }
            } catch {
                // All errors from the stream, including cancellation, are caught here.
                await MainActor.run {
                    self.isLoading = false
                    if let aiError = error as? AIInferenceError {
                        self.errorMessage = aiError.errorDescription
                        if aiError == .cancelled {
                            self.progressMessage = "Upscaling cancelled."
                        } else {
                            self.progressMessage = "Upscaling failed."
                            self.showAlert = true
                        }
                    } else {
                        self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                        self.progressMessage = "Upscaling failed."
                        self.showAlert = true
                    }
                    logger.error("Upscaling task failed: \(error.localizedDescription)")
                }
            }
        }
    }

    /// Cancels the ongoing upscaling task.
    func cancelUpscaling() {
        upscaleTask?.cancel()
        upscaleTask = nil
        isLoading = false
        progressMessage = "Upscaling cancelled."
        logger.info("Upscaling operation explicitly cancelled by user.")
    }
}

/// A simplified SwiftUI view to demonstrate the ImageUpscalerViewModel.
@available(iOS 18.0, *)
struct UpscaleView: View {
    @State private var viewModel: ImageUpscalerViewModel
    @State private var selectedImageData: Data? = nil // Mock data

    init() {
        // Initialize the client and upscaler
        let client = AIInferenceClient()
        let upscaler = ImageUpscaler(client: client)
        // Initialize the ViewModel with the upscaler
        _viewModel = State(initialValue: ImageUpscalerViewModel(upscaler: upscaler))
    }

    var body: some View {
        VStack(spacing: 20) {
            if let upscaledImage = viewModel.upscaledImage {
                upscaledImage
                    .frame(width: 200, height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            } else {
                Image(systemName: "photo.on.rectangle.angled")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                    .foregroundColor(.gray)
            }

            Text(viewModel.progressMessage)
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            if viewModel.isLoading {
                ProgressView()
                    .progressViewStyle(.circular)
                Button("Cancel Upscale") {
                    viewModel.cancelUpscaling()
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
            } else {
                Button("Start AI Upscale") {
                    // Simulate selecting image data (e.g., from PhotoPicker)
                    selectedImageData = Data(repeating: 0x01, count: 1024 * 50) // 50KB mock image
                    if let data = selectedImageData {
                        viewModel.startUpscaling(imageData: data)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedImageData == nil)
            }
        }
        .padding()
        .alert("Upscale Error", isPresented: $viewModel.showAlert) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "An unknown error occurred.")
        }
        .navigationTitle("AI Photo Upscaler")
    }
}
