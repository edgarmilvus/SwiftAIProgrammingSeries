
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Speech
import AVFoundation

class RealtimeTranscriptionViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 18)
        tv.isEditable = false
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 18)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 18)
        button.backgroundColor = .systemRed
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false // Disabled by default
        return button
    }()

    // MARK: - Speech Recognition Properties
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US")) // Default locale
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupButtons()
        requestPermissions()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Ensure engine and recognition are stopped when view disappears
        stopRecording()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        let stackView = UIStackView(arrangedSubviews: [startButton, stopButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(statusLabel)
        view.addSubview(textView)
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            textView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: stackView.topAnchor, constant: -20),

            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func setupButtons() {
        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)
    }

    // MARK: - Permissions
    private func requestPermissions() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized:
                    self.startButton.isEnabled = true
                    self.statusLabel.text = "Ready"
                case .denied:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Speech recognition denied by user."
                case .restricted:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Speech recognition restricted on this device."
                case .notDetermined:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Speech recognition not yet authorized."
                @unknown default:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Unknown speech recognition authorization status."
                }
                self.requestMicrophonePermission()
            }
        }
    }

    private func requestMicrophonePermission() {
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                if !granted {
                    self?.startButton.isEnabled = false
                    self?.statusLabel.text = "Microphone access denied."
                } else if self?.speechRecognizer?.isAvailable == false {
                    self?.startButton.isEnabled = false
                    self?.statusLabel.text = "Speech recognizer not available."
                }
            }
        }
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        textView.text = "" // Clear previous transcription
        statusLabel.text = "Recording..."
        startButton.isEnabled = false
        stopButton.isEnabled = true

        do {
            try startAudioEngineAndRecognition()
        } catch {
            statusLabel.text = "Error starting recording: \(error.localizedDescription)"
            stopRecording() // Clean up on error
        }
    }

    @objc private func stopRecordingTapped() {
        stopRecording()
        statusLabel.text = "Processing..." // Status while waiting for final result
    }

    private func startAudioEngineAndRecognition() throws {
        // Cancel the previous task if it's running.
        if let recognitionTask = recognitionTask {
            recognitionTask.cancel()
            self.recognitionTask = nil
        }

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true // Enable real-time updates

        // Configure the audio engine
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        // Start the recognition task
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                self.textView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // Stop the audio engine and clean up when an error occurs or recognition is final
                self.stopRecording()
                if let error = error {
                    self.statusLabel.text = "Recognition error: \(error.localizedDescription)"
                } else if isFinal {
                    self.statusLabel.text = "Ready"
                }
            }
        }
    }

    private func stopRecording() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0) // Remove the tap to stop feeding audio
        recognitionRequest?.endAudio() // Signal the end of audio input
        recognitionRequest = nil // Release the request
        recognitionTask?.cancel() // Cancel any pending recognition tasks
        recognitionTask = nil // Release the task

        // Deactivate audio session
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }

        DispatchQueue.main.async {
            self.startButton.isEnabled = self.speechRecognizer?.isAvailable ?? false
            self.stopButton.isEnabled = false
            if self.statusLabel.text != "Recognition error..." { // Don't overwrite error message
                self.statusLabel.text = "Ready"
            }
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        DispatchQueue.main.async {
            if available {
                self.startButton.isEnabled = true
                self.statusLabel.text = "Ready"
            } else {
                self.startButton.isEnabled = false
                self.statusLabel.text = "Speech recognition not available."
            }
        }
    }
}
