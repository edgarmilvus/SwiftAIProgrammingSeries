
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreMotion
import CoreML // For MLModel, though MLActivityClassifier abstracts it
import Foundation

// Assuming a structure for processed sensor data that is Sendable
struct SensorWindow: Sendable {
    let accelerometer: [CMAccelerometerData] // CMAccelerometerData is not Sendable, so this would need transformation
    let gyroscope: [CMGyroData] // CMGyroData is not Sendable
    let timestamp: Date

    // In a real scenario, you'd extract relevant numerical features or transform
    // CMAccelerometerData/CMGyroData into a Sendable representation (e.g., an array of tuples of Doubles)
    // for safe cross-actor transfer.
    // For this theoretical example, we'll assume a simplified Sendable version of sensor data.
}

@available(iOS 18.0, *)
actor ActivityMonitor {
    private let motionManager = CMMotionManager()
    private var currentAccelerometerBuffer: [CMAccelerometerData] = []
    private var currentGyroscopeBuffer: [CMGyroData] = []
    private let bufferSize = 100 // e.g., 2 seconds at 50Hz
    private let classifier: MLActivityClassifier // Your trained model

    @Published private(set) var currentActivity: String = "Unknown" // Published for reactive updates

    init(classifier: MLActivityClassifier) {
        self.classifier = classifier
        // Initialize motion manager
        motionManager.accelerometerUpdateInterval = 1.0 / 50.0
        motionManager.gyroUpdateInterval = 1.0 / 50.0
    }

    func startMonitoring() {
        guard motionManager.isAccelerometerAvailable, motionManager.isGyroAvailable else {
            print("Sensors not available.")
            return
        }

        motionManager.startAccelerometerUpdates(to: .main) { [weak self] (data, error) in
            guard let self = self, let data = data else { return }
            Task { await self.processAccelerometerData(data) } // Isolate actor state
        }

        motionManager.startGyroUpdates(to: .main) { [weak self] (data, error) in
            guard let self = self, let data = data else { return }
            Task { await self.processGyroscopeData(data) } // Isolate actor state
        }
    }

    func stopMonitoring() {
        motionManager.stopAccelerometerUpdates()
        motionManager.stopGyroUpdates()
    }

    private func processAccelerometerData(_ data: CMAccelerometerData) {
        currentAccelerometerBuffer.append(data)
        if currentAccelerometerBuffer.count >= bufferSize {
            Task { await classifyCurrentBuffer() } // Trigger classification
        }
    }

    private func processGyroscopeData(_ data: CMGyroData) {
        currentGyroscopeBuffer.append(data)
        // Note: In a real app, you'd likely want to ensure both buffers are ready
        // before classifying, or use a more sophisticated synchronization.
    }

    private func classifyCurrentBuffer() async {
        guard currentAccelerometerBuffer.count >= bufferSize,
              currentGyroscopeBuffer.count >= bufferSize else { return }

        // Take a snapshot of the buffers for classification
        let accelWindow = Array(currentAccelerometerBuffer.suffix(bufferSize))
        let gyroWindow = Array(currentGyroscopeBuffer.suffix(bufferSize))

        // Clear buffers or shift them for the next window
        currentAccelerometerBuffer.removeAll(keepingCapacity: true)
        currentGyroscopeBuffer.removeAll(keepingCapacity: true)

        do {
            // In a real scenario, you'd feed the accelWindow and gyroWindow
            // (after appropriate conversion to MLMultiArray or similar)
            // into your MLActivityClassifier's prediction method.
            // For theoretical purposes, we simulate.
            // Example: let prediction = try await classifier.prediction(accelerometer: accelInput, gyroscope: gyroInput)
            // let activity = prediction.activityLabel

            try await Task.sleep(for: .milliseconds(50)) // Simulate inference time
            let activity = ["Walking", "Running", "Standing", "Sitting"].randomElement()!
            self.currentActivity = activity // Update isolated state safely
            print("Detected activity: \(activity)")

        } catch {
            print("Classification error: \(error.localizedDescription)")
        }
    }
}
