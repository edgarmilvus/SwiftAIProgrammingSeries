
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Represents specific error categories encountered when interacting with an LLM.
enum LLMError: Error, LocalizedError, Sendable {
    // Transient Errors (Retryable)
    case networkError(Error)
    case serviceUnavailable // HTTP 503
    
    // Rate Limiting (Retryable)
    case rateLimited(retryAfter: TimeInterval?) // HTTP 429
    
    // Content Errors (Non-Retryable)
    case safetyRefusal
    
    // Context Errors (Non-Retryable)
    case contextWindowExceeded
    
    // Parsing Errors (Non-Retryable)
    case parsingFailure(details: String)

    /// Determines if the error warrants an automatic retry attempt.
    var isRetryable: Bool {
        switch self {
        case .networkError, .serviceUnavailable, .rateLimited:
            return true
        case .safetyRefusal, .contextWindowExceeded, .parsingFailure:
            return false
        }
    }

    /// Provides user-friendly messages for semantic errors, 
    /// while keeping technical details for system logs.
    var errorDescription: String? {
        switch self {
        case .safetyRefusal:
            return "The AI cannot answer this request due to safety guidelines."
        case .contextWindowExceeded:
            return "Your request is too long for the AI to process. Please shorten it."
        case .rateLimited(let retryAfter):
            return "System is busy. Please try again in \(retryAfter.map { "\($0)s" } ?? "a moment")."
        case .networkError(let error):
            return "Network connection issue: \(error.localizedDescription)"
        case .serviceUnavailable:
            return "The server is temporarily unavailable."
        case .parsingFailure(let details):
            return "Received an unexpected response format: \(details)"
        }
    }
}
