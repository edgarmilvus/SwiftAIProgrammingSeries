
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// MARK: - Data Structures

enum PetType: String, CaseIterable, Hashable {
    case cat = "Cat"
    case dog = "Dog"
    case bird = "Bird"
}

struct PhotoPrediction {
    let actual: PetType
    let predicted: PetType
}

// MARK: - Core Functions for Multi-Class

/// Calculates a multi-class confusion matrix.
/// - Parameter predictions: An array of PhotoPrediction instances.
/// - Returns: A nested dictionary where `matrix[actualClass][predictedClass]` gives the count.
func calculateMultiClassConfusionMatrix(predictions: [PhotoPrediction]) -> [PetType: [PetType: Int]] {
    var matrix: [PetType: [PetType: Int]] = [:]

    // Initialize matrix with zeros for all actual-predicted pairs
    for actualClass in PetType.allCases {
        matrix[actualClass] = [:]
        for predictedClass in PetType.allCases {
            matrix[actualClass]?[predictedClass] = 0
        }
    }

    // Populate the matrix
    for prediction in predictions {
        matrix[prediction.actual]?[prediction.predicted]? += 1
    }

    return matrix
}

/// Calculates per-class precision and recall from a multi-class confusion matrix.
/// - Parameters:
///   - multiClassMatrix: The multi-class confusion matrix.
///   - targetClass: The specific PetType for which to calculate metrics.
/// - Returns: A tuple `(precision: Double, recall: Double)`. Returns (0.0, 0.0) if metrics cannot be calculated.
func calculatePerClassMetrics(multiClassMatrix: [PetType: [PetType: Int]], forClass targetClass: PetType) -> (precision: Double, recall: Double, f1Score: Double) {
    let allClasses = PetType.allCases

    // True Positives for targetClass
    let tp = multiClassMatrix[targetClass]?[targetClass] ?? 0

    // False Positives for targetClass: Sum of predictions for targetClass when actual was another class
    var fp = 0
    for actualClass in allClasses where actualClass != targetClass {
        fp += multiClassMatrix[actualClass]?[targetClass] ?? 0
    }

    // False Negatives for targetClass: Sum of predictions for other classes when actual was targetClass
    var fn = 0
    for predictedClass in allClasses where predictedClass != targetClass {
        fn += multiClassMatrix[targetClass]?[predictedClass] ?? 0
    }

    let precisionDenominator = Double(tp + fp)
    let precision = (precisionDenominator > 0) ? Double(tp) / precisionDenominator : 0.0

    let recallDenominator = Double(tp + fn)
    let recall = (recallDenominator > 0) ? Double(tp) / recallDenominator : 0.0
    
    // F1-Score: 2 * (Precision * Recall) / (Precision + Recall)
    let f1ScoreDenominator = precision + recall
    let f1Score = (f1ScoreDenominator > 0) ? 2 * (precision * recall) / f1ScoreDenominator : 0.0

    return (precision, recall, f1Score)
}

/// Calculates macro-averaged precision and recall.
/// - Parameter perClassMetrics: A dictionary of per-class metrics.
/// - Returns: A tuple `(macroPrecision: Double, macroRecall: Double)`.
func calculateMacroAverages(perClassMetrics: [PetType: (precision: Double, recall: Double, f1Score: Double)]) -> (macroPrecision: Double, macroRecall: Double, macroF1Score: Double) {
    guard !perClassMetrics.isEmpty else { return (0.0, 0.0, 0.0) }

    let totalPrecision = perClassMetrics.values.reduce(0.0) { $0 + $1.precision }
    let totalRecall = perClassMetrics.values.reduce(0.0) { $0 + $1.recall }
    let totalF1Score = perClassMetrics.values.reduce(0.0) { $0 + $1.f1Score }

    let numClasses = Double(perClassMetrics.count)
    return (totalPrecision / numClasses, totalRecall / numClasses, totalF1Score / numClasses)
}

// MARK: - Simulation and Reporting

// 2. Simulate Data
var photoPredictions: [PhotoPrediction] = []

// 50 actual Cat photos
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .cat, predicted: .cat), count: 45))
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .cat, predicted: .dog), count: 3))
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .cat, predicted: .bird), count: 2))

// 60 actual Dog photos
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .dog, predicted: .dog), count: 55))
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .dog, predicted: .cat), count: 4))
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .dog, predicted: .bird), count: 1))

// 40 actual Bird photos
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .bird, predicted: .bird), count: 35))
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .bird, predicted: .cat), count: 3))
photoPredictions.append(contentsOf: Array(repeating: PhotoPrediction(actual: .bird, predicted: .dog), count: 2))

photoPredictions.shuffle() // Mix the data

print("--- Multi-Class Pet Photo Classifier Evaluation ---")
print("Total Photos: \(photoPredictions.count)\n")

// 3. Calculate Multi-Class Confusion Matrix
let multiClassMatrix = calculateMultiClassConfusionMatrix(predictions: photoPredictions)

print("--- Multi-Class Confusion Matrix ---")
// Print header
print(String(format: "%-10s | %@", "Actual \\ Pred", PetType.allCases.map { String(format: "%-10s", $0.rawValue) }.joined(separator: " | ")))
print(String(repeating: "-", count: 10 + (13 * PetType.allCases.count)))

// Print rows
for actualClass in PetType.allCases {
    let rowValues = PetType.allCases.map { predictedClass in
        String(format: "%-10d", multiClassMatrix[actualClass]?[predictedClass] ?? 0)
    }.joined(separator: " | ")
    print(String(format: "%-10s | %@", actualClass.rawValue, rowValues))
}
print(String(repeating: "-", count: 10 + (13 * PetType.allCases.count)))
print("\n")

// 4. Calculate Per-Class Precision and Recall
var perClassMetrics: [PetType: (precision: Double, recall: Double, f1Score: Double)] = [:]
print("--- Per-Class Metrics ---")
for petType in PetType.allCases {
    let metrics = calculatePerClassMetrics(multiClassMatrix: multiClassMatrix, forClass: petType)
    perClassMetrics[petType] = metrics
    print(String(format: "%@: Precision = %.4f, Recall = %.4f, F1-Score = %.4f", petType.rawValue, metrics.precision, metrics.recall, metrics.f1Score))
}
print("\n")

// 5. Calculate Macro-Averaged Metrics
let (macroPrecision, macroRecall, macroF1Score) = calculateMacroAverages(perClassMetrics: perClassMetrics)
print("--- Macro-Averaged Metrics ---")
print(String(format: "Macro-Averaged Precision: %.4f", macroPrecision))
print(String(format: "Macro-Averaged Recall:    %.4f", macroRecall))
print(String(format: "Macro-Averaged F1-Score:  %.4f", macroF1Score))
print("\n")

// 6. Report and Interpret
print("--- Interpretation ---")
print("The full confusion matrix shows how often each actual pet type was predicted as each possible pet type.")
print("Diagonal elements (e.g., Actual Cat -> Predicted Cat) are correct classifications.")
print("Off-diagonal elements show misclassifications.")
print("\nLooking at per-class metrics:")
print("- **Cat:** Precision (%.2f) is high, meaning when the model says 'Cat', it's usually right. Recall (%.2f) is also good, meaning it catches most actual cats.".formatted(perClassMetrics[.cat]!.precision, perClassMetrics[.cat]!.recall))
print("- **Dog:** Precision (%.2f) and Recall (%.2f) are both very high, indicating strong performance for dogs.".formatted(perClassMetrics[.dog]!.precision, perClassMetrics[.dog]!.recall))
print("- **Bird:** Precision (%.2f) is good, but Recall (%.2f) is slightly lower than other classes. This suggests the model might miss some actual birds (False Negatives), classifying them as Cat or Dog.".formatted(perClassMetrics[.bird]!.precision, perClassMetrics[.bird]!.recall))

print("\nOverall, the model performs best on **Dog** photos, with very high precision and recall. It performs reasonably well on **Cat** photos. Performance on **Bird** photos is slightly weaker, primarily due to a lower recall, indicating it might struggle to identify all actual bird photos.")
print("The **Macro-Averaged Precision (%.2f), Recall (%.2f), and F1-Score (%.2f)** provide an overall picture of the model's performance, giving equal weight to each class regardless of its size in the dataset. These values are a good indication of the model's general effectiveness across all pet types.".formatted(macroPrecision, macroRecall, macroF1Score))
