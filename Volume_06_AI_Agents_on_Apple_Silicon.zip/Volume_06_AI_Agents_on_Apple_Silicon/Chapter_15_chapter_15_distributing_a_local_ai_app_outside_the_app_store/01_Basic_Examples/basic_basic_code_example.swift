
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - 1. Imports and Model Setup

import SwiftUI
import PhotosUI // For image selection
import CoreML   // For MLModel and VNCoreMLRequest
import Vision   // For image processing and Core ML integration

// Assume 'MobileNetV2' is the name of your Core ML model file (e.g., MobileNetV2.mlmodel)
// Xcode automatically generates a class for your model, like 'MobileNetV2'.

/// Manages the loading and inference of a Core ML model.
/// This class is responsible for abstracting away the complexities of Core ML and Vision frameworks.
@available(iOS 18.0, macOS 15.0, *) // Using modern concurrency features, suitable for latest SDKs
actor MLModelManager {
    private var model: MobileNetV2? // Replace with your model's generated class name
    
    /// Initializes the model manager by loading the Core ML model.
    /// This is an asynchronous operation as model loading can be resource-intensive.
    init() {
        // Model loading can fail, so it's good practice to handle errors.
        do {
            self.model = try MobileNetV2(configuration: MLModelConfiguration())
            print("MobileNetV2 model loaded successfully.")
        } catch {
            print("Error loading MobileNetV2 model: \(error.localizedDescription)")
            self.model = nil
        }
    }
    
    /// Performs classification on a given CGImage.
    /// - Parameters:
    ///   - image: The CGImage to classify.
    ///   - computeUnit: The desired compute unit for inference (CPU, GPU, or Neural Engine).
    /// - Returns: A string describing the top classification result, or nil if classification fails.
    /// This function uses Vision framework for robust image preprocessing and Core ML for inference.
    func classifyImage(_ image: CGImage, computeUnit: MLComputeUnit = .all) async -> String? {
        guard let model = self.model else {
            print("Model not loaded.")
            return nil
        }

        // Configure the model's compute unit. This is crucial for performance and power efficiency.
        // The configuration must be set before creating the VNCoreMLModel.
        let configuration = MLModelConfiguration()
        configuration.computeUnits = computeUnit
        
        do {
            let visionModel = try VNCoreMLModel(for: model.model) // Use model.model to get the underlying MLModel
            
            // Create a Vision request for Core ML.
            // This request will handle image scaling and other preprocessing required by the model.
            let request = VNCoreMLRequest(model: visionModel) { request, error in
                guard error == nil else {
                    print("Vision Core ML request error: \(error!.localizedDescription)")
                    return
                }
                
                // Process the classification results.
                guard let observations = request.results as? [VNClassificationObservation] else {
                    print("No classification observations found.")
                    return
                }
                
                // Sort observations by confidence and get the top result.
                if let topClassification = observations.first {
                    // Send the result back to the caller.
                    // This uses a continuation to bridge the callback-based Vision API to async/await.
                    // The result is captured and passed to the continuation.
                    // (Note: In a real-world scenario, you might want to return all observations)
                    // For simplicity, we'll return only the identifier.
                }
            }
            
            // Set the image orientation for correct processing.
            request.imageCropAndScaleOption = .centerCrop // Or .scaleFit, .scaleFill
            
            // Create a Vision request handler for the image.
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            
            // Perform the request. This is synchronous from the perspective of the handler call.
            // We use a withCheckedContinuation to make it async/await friendly.
            return await withCheckedContinuation { continuation in
                do {
                    try handler.perform([request])
                    
                    // After perform, the request.results will be populated if successful.
                    // We need to re-access the results from the request object inside the completion handler.
                    if let observations = request.results as? [VNClassificationObservation],
                       let topClassification = observations.first {
                        continuation.resume(returning: "\(topClassification.identifier) (Confidence: \(String(format: "%.2f", topClassification.confidence * 100))%)")
                    } else {
                        continuation.resume(returning: nil)
                    }
                    
                } catch {
                    print("Failed to perform Vision request: \(error.localizedDescription)")
                    continuation.resume(returning: nil)
                }
            }
        } catch {
            print("Error creating VNCoreMLModel: \(error.localizedDescription)")
            return nil
        }
    }
}

// MARK: - 2. SwiftUI View for User Interface

/// The main view of the Smart Photo Organizer app.
/// This view allows users to pick an image, trigger classification, and display the results.
@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    // State variables to manage UI updates.
    @State private var selectedImage: PhotosPickerItem?
    @State private var classifiedImage: Image?
    @State private var classificationResult: String = "No image selected"
    @State private var isClassifying: Bool = false
    @State private var showingErrorAlert: Bool = false
    @State private var errorMessage: String = ""
    
    // An instance of our MLModelManager, managed by the view.
    // Use @StateObject for reference types that need to be owned by the view.
    @StateObject private var modelManager = MLModelManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Smart Photo Organizer")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            if let classifiedImage = classifiedImage {
                classifiedImage
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .shadow(radius: 5)
            } else {
                Rectangle()
                    .fill(.gray.opacity(0.3))
                    .frame(width: 250, height: 250)
                    .cornerRadius(10)
                    .overlay(Text("No Image").foregroundColor(.secondary))
            }
            
            Text(classificationResult)
                .font(.headline)
                .padding()
                .background(RoundedRectangle(cornerRadius: 8).fill(.blue.opacity(0.1)))
            
            // PhotosPicker allows users to select images from their photo library.
            PhotosPicker(selection: $selectedImage, matching: .images) {
                Label("Select Photo", systemImage: "photo.on.rectangle.angled")
            }
            .buttonStyle(.borderedProminent)
            .tint(.accentColor)
            
            Button {
                // Trigger classification when the button is tapped.
                classifySelectedImage()
            } label: {
                if isClassifying {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                } else {
                    Label("Classify Image", systemImage: "brain.head.profile")
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
            .disabled(selectedImage == nil || isClassifying) // Disable if no image or currently classifying
        }
        .padding()
        // Respond to changes in selectedImage
        .onChange(of: selectedImage) { oldItem, newItem in
            Task {
                await loadImage(from: newItem)
            }
        }
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { showingErrorAlert = false }
        } message: {
            Text(errorMessage)
        }
    }
    
    /// Loads the selected image into the UI.
    /// This function runs asynchronously to avoid blocking the main thread for image loading.
    /// - Parameter item: The PhotosPickerItem representing the selected image.
    @MainActor // UI updates must happen on the main actor
    private func loadImage(from item: PhotosPickerItem?) async {
        classifiedImage = nil // Clear previous image
        classificationResult = "Loading image..."
        guard let item = item else { return }
        
        do {
            // Load the image data. This can be a lengthy operation for large images.
            if let data = try await item.loadTransferable(type: Data.self),
               let uiImage = UIImage(data: data) { // Use UIImage for cross-platform image handling
                self.classifiedImage = Image(uiImage: uiImage)
                self.classificationResult = "Image loaded. Ready to classify."
            } else {
                self.classificationResult = "Could not load image."
            }
        } catch {
            self.classificationResult = "Failed to load image: \(error.localizedDescription)"
            self.errorMessage = error.localizedDescription
            self.showingErrorAlert = true
        }
    }
    
    /// Initiates the image classification process using the MLModelManager.
    /// This function runs asynchronously and updates the UI with the result.
    @MainActor // UI updates must happen on the main actor
    private func classifySelectedImage() {
        guard let selectedImage = selectedImage else {
            classificationResult = "Please select an image first."
            return
        }
        
        isClassifying = true
        classificationResult = "Classifying..."
        
        Task {
            do {
                // Load the image data again, specifically for classification.
                // It's generally better to pass the CGImage directly to the model manager.
                guard let data = try await selectedImage.loadTransferable(type: Data.self),
                      let uiImage = UIImage(data: data),
                      let cgImage = uiImage.cgImage else {
                    throw NSError(domain: "ImageError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to get CGImage from selected photo."])
                }
                
                // Perform classification using the MLModelManager.
                // The modelManager is an actor, so calling its methods is implicitly asynchronous.
                let result = await modelManager.classifyImage(cgImage, computeUnit: .all) // Try .cpuOnly, .gpuOnly, .neuralEngine
                
                // Update UI with the classification result.
                // Since this block is within a Task on the MainActor, UI updates are safe.
                if let result = result {
                    self.classificationResult = "Result: \(result)"
                } else {
                    self.classificationResult = "Classification failed."
                }
                
            } catch {
                self.classificationResult = "Error during classification: \(error.localizedDescription)"
                self.errorMessage = error.localizedDescription
                self.showingErrorAlert = true
            }
            isClassifying = false
        }
    }
}

// MARK: - 3. App Entry Point

/// The entry point for the SwiftUI application.
@available(iOS 18.0, macOS 15.0, *)
@main
struct SmartPhotoOrganizerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
