
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
enum SafetyLevel: String, CaseIterable, Sendable {
    case toddler = "Toddler (Strict)"
    case child = "Child (Moderate)"
    case teen = "Teen (Creative)"
    
    var systemInstruction: String {
        switch self {
        case .toddler: return "Use only words for 3-year-olds. No conflict. No scary themes."
        case .child: return "Use simple language. Avoid violence or complex themes."
        case .teen: return "Use standard language. Allow adventure and mild conflict."
        }
    }
}

@available(iOS 18.0, *)
@Observable
class SafetySettings {
    var currentLevel: SafetyLevel = .child
}

@available(iOS 18.0, *)
actor PromptEngine {
    private let settings: SafetySettings
    
    init(settings: SafetySettings) {
        self.settings = settings
    }
    
    func generateStory(topic: String) async throws -> String {
        // Capture the current setting at the start of the task
        let instruction = settings.currentLevel.systemInstruction
        print("Starting generation with: \(instruction)")
        
        // Simulate a long-running generation process
        for i in 1...10 {
            // CRITICAL: Check for cancellation
            try Task.checkCancellation()
            
            // Simulate work
            try await Task.sleep(for: .milliseconds(500))
            
            // Check if settings changed mid-stream
            if settings.currentLevel.systemInstruction != instruction {
                print("Safety level changed! Cancelling current task.")
                throw CancellationError()
            }
            
            print("Generating segment \(i)...")
        }
        
        return "Once upon a time, in a world of \(topic)... [Story Complete]"
    }
}

@available(iOS 18.0, *)
struct SafeGenView: View {
    @State private var settings = SafetySettings()
    @State private var story = ""
    @State private var isGenerating = false
    @State private var generationTask: Task<Void, Never>?
    
    private let engine: PromptEngine
    
    init() {
        let sharedSettings = SafetySettings()
        _settings = State(initialValue: sharedSettings)
        self.engine = PromptEngine(settings: sharedSettings)
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Picker("Safety Mode", selection: $settings.currentLevel) {
                    ForEach(SafetyLevel.allCases, id: \.self) { level in
                        Text(level.rawValue).tag(level)
                    }
                }
                .pickerStyle(.segmented)
                .onChange(of: settings.currentLevel) {
                    handleSettingsChange()
                }
                
                Divider()
                
                ScrollView {
                    Text(story)
                        .font(.body)
                        .padding()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.secondary.opacity(0.1))
                .cornerRadius(12)
                
                Button(isGenerating ? "Generating..." : "Generate Story") {
                    startGeneration()
                }
                .disabled(isGenerating)
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .navigationTitle("SafeGen")
        }
    }
    
    private func startGeneration() {
        story = ""
        isGenerating = true
        
        generationTask = Task {
            do {
                let result = try await engine.generateStory(topic: "Space Adventures")
                story = result
                isGenerating = false
            } catch is CancellationError {
                story = "Generation interrupted due to safety setting change."
                isGenerating = false
            } catch {
                story = "An error occurred."
                isGenerating = false
            }
        }
    }
    
    private func handleSettingsChange() {
        // If a user changes settings while a task is running, cancel it.
        generationTask?.cancel()
    }
}
