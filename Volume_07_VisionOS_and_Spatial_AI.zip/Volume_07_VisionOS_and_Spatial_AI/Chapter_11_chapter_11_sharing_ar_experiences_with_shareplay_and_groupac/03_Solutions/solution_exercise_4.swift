
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import RealityKit
import GroupActivities

typealias ParticipantID = String

struct FurnitureState: Codable, Sendable {
    let id: UUID
    var position: SIMD3<Float>
    var isLockedBy: ParticipantID?
}

enum FurnitureCommand: Codable, Sendable {
    case requestLock(entityID: UUID, participantID: ParticipantID)
    case releaseLock(entityID: UUID, participantID: ParticipantID)
    case updateTransform(entityID: UUID, position: SIMD3<Float>, participantID: ParticipantID)
}

/// The "Source of Truth" for the distributed world.
actor FurnitureSyncEngine {
    private var registry: [UUID: FurnitureState] = [:]
    private let localParticipantID = ParticipantID(UUID().uuidString)
    
    // Callback to notify the UI/Scene of changes
    var onStateChanged: (@Sendable (FurnitureState) -> Void)?

    func process(command: FurnitureCommand) {
        switch command {
        case .requestLock(let id, let requesterID):
            guard var state = registry[id] else { return }
            
            // Conflict Resolution: Only grant lock if currently unowned
            if state.isLockedBy == nil {
                state.isLockedBy = requesterID
                registry[id] = state
                onStateChanged?(state)
            }
            
        case .releaseLock(let id, let requesterID):
            guard var state = registry[id], state.isLockedBy == requesterID else { return }
            state.isLockedBy = nil
            registry[id] = state
            onStateChanged?(state)
            
        case .updateTransform(let id, let pos, let requesterID):
            guard var state = registry[id], state.isLockedBy == requesterID else { return }
            state.position = pos
            registry[id] = state
            onStateChanged?(state)
        }
    }
    
    func canUserEdit(entityID: UUID) -> Bool {
        guard let state = registry[entityID] else { return true }
        return state.isLockedBy == nil || state.isLockedBy == localParticipantID
    }
    
    func getLocalID() -> ParticipantID { localParticipantID }
}
