
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Represents the role of a participant in the conversation.
/// Conforming to Sendable allows it to be safely passed across actor boundaries.
enum ChatRole: String, Sendable {
    case user
    case assistant
    case system
}

/// The fundamental unit of conversation.
/// Conforming to Sendable is critical for Swift 6 concurrency safety.
struct ChatMessage: Identifiable, Sendable {
    let id: UUID = UUID()
    let role: ChatRole
    let content: String
}

/// An actor that manages a sliding window of messages.
/// Using an actor ensures that concurrent access to the underlying array 
/// from different threads is serialized, preventing data races.
actor SlidingWindowBuffer {
    private var messages: [ChatMessage] = []
    private let maxMessages: Int
    
    init(maxMessages: Int) {
        self.maxMessages = maxMessages
    }
    
    /// Appends a new message and prunes the oldest if capacity is exceeded.
    func append(_ message: ChatMessage) {
        messages.append(message)
        
        // FIFO Pruning: If we exceed capacity, remove the oldest (first) element.
        // Note: removeFirst() is O(n), which is acceptable for small windows.
        while messages.count > maxMessages {
            messages.removeFirst()
        }
    }
    
    /// Returns a copy of the current message window.
    /// Because ChatMessage is Sendable, returning the array is safe.
    func getMessages() -> [ChatMessage] {
        return messages
    }
    
    /// Returns the current count for monitoring purposes.
    func count() -> Int {
        return messages.count
    }
}

// --- Implementation Test ---
@main
struct BufferTest {
    static func main() async {
        let buffer = SlidingWindowBuffer(maxMessages: 3)
        
        let msg1 = ChatMessage(role: .user, content: "Hello!")
        let msg2 = ChatMessage(role: .assistant, content: "Hi there!")
        let msg3 = ChatMessage(role: .user, content: "How are you?")
        let msg4 = ChatMessage(role: .assistant, content: "I am doing great!")
        
        await buffer.append(msg1)
        await buffer.append(msg2)
        await buffer.append(msg3)
        
        print("Buffer after 3 messages: \(await buffer.count())") // Should be 3
        
        await buffer.append(msg4)
        print("Buffer after 4th message: \(await buffer.count())") // Should be 3
        
        let currentMessages = await buffer.getMessages()
        for msg in currentMessages {
            print("[\(msg.role.rawValue)]: \(msg.content)")
        }
        // Expected: msg2, msg3, msg4 (msg1 was dropped)
    }
}
