
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CreateML // Core framework for Create ML models
import UniformTypeIdentifiers // For file types

// Ensure this code runs on a compatible OS version for Swift 6 and modern concurrency features.
@available(iOS 18.0, macOS 15.0, *)
enum DocumentClassifierError: Error, LocalizedError {
    case trainingDataNotFound(String)
    case trainingFailed(String)
    case modelSaveFailed(String)
    case cancellationRequested

    var errorDescription: String? {
        switch self {
        case .trainingDataNotFound(let path):
            return "Training data not found at: \(path)"
        case .trainingFailed(let reason):
            return "Model training failed: \(reason)"
        case .modelSaveFailed(let reason):
            return "Failed to save the trained model: \(reason)"
        case .cancellationRequested:
            return "Training was cancelled by the user."
        }
    }
}

/// Represents the type of a document that can be classified.
enum DocumentType: String, CaseIterable, Codable {
    case invoice = "Invoice"
    case receipt = "Receipt"
    case contract = "Contract"
    case report = "Report"
    case unknown = "Unknown"
}

/// A simple structure to represent a document for training.
struct Document: Identifiable, Hashable, Sendable {
    let id: UUID = UUID()
    let url: URL // URL to the document image or text file
    let type: DocumentType
    let datasetName: String // To group documents into datasets

    init(url: URL, type: DocumentType, datasetName: String = "Default") {
        self.url = url
        self.type = type
        self.datasetName = datasetName
    }
}

/// Represents a progress update during model training.
struct TrainingProgressUpdate: Identifiable, Sendable {
    let id = UUID()
    let trainingSessionID: UUID
    let datasetName: String
    let progress: Double // 0.0 to 1.0
    let message: String
    let isComplete: Bool
    let error: DocumentClassifierError?

    static func initial(sessionID: UUID, datasetName: String) -> TrainingProgressUpdate {
        TrainingProgressUpdate(trainingSessionID: sessionID, datasetName: datasetName, progress: 0.0, message: "Starting training...", isComplete: false, error: nil)
    }

    static func update(sessionID: UUID, datasetName: String, progress: Double, message: String) -> TrainingProgressUpdate {
        TrainingProgressUpdate(trainingSessionID: sessionID, datasetName: datasetName, progress: progress, message: message, isComplete: false, error: nil)
    }

    static func completed(sessionID: UUID, datasetName: String, modelURL: URL?) -> TrainingProgressUpdate {
        TrainingProgressUpdate(trainingSessionID: sessionID, datasetName: datasetName, progress: 1.0, message: "Training complete! Model saved to: \(modelURL?.lastPathComponent ?? "N/A")", isComplete: true, error: nil)
    }

    static func failed(sessionID: UUID, datasetName: String, error: DocumentClassifierError) -> TrainingProgressUpdate {
        TrainingProgressUpdate(trainingSessionID: sessionID, datasetName: datasetName, progress: 0.0, message: "Training failed!", isComplete: true, error: error)
    }
}

/// Manages the training of a single document classifier model.
/// It encapsulates Create ML's training logic and bridges `MLProgress` to `AsyncThrowingStream`.
@available(iOS 18.0, macOS 15.0, *)
class DocumentClassifierTrainer {

    /// Simulates generating training data. In a real app, this would load actual images/text.
    /// - Parameters:
    ///   - count: The number of dummy documents to generate.
    ///   - datasetName: The name of the dataset.
    /// - Returns: An array of `Document` instances.
    static func generateDummyTrainingData(count: Int, datasetName: String) -> [Document] {
        var documents: [Document] = []
        let documentTypes = DocumentType.allCases.filter { $0 != .unknown }
        for i in 0..<count {
            let type = documentTypes[i % documentTypes.count]
            // Create a dummy URL for simulation.
            let dummyURL = URL(fileURLWithPath: "/tmp/dummy_doc_\(datasetName)_\(i).png")
            documents.append(Document(url: dummyURL, type: type, datasetName: datasetName))
        }
        return documents
    }

    /// Trains a new document classifier model with the given dataset.
    /// - Parameters:
    ///   - trainingSessionID: A unique identifier for this training session.
    ///   - datasetName: The name of the dataset being used for training.
    ///   - trainingData: An array of `Document` objects representing the training examples.
    ///   - modelOutputDirectory: The directory where the trained `.mlmodelc` will be saved.
    /// - Returns: An `AsyncThrowingStream` that yields `TrainingProgressUpdate` values.
    /// - Throws: `DocumentClassifierError` if training fails or is cancelled.
    func trainModel(
        trainingSessionID: UUID,
        datasetName: String,
        trainingData: [Document],
        modelOutputDirectory: URL
    ) -> AsyncThrowingStream<TrainingProgressUpdate, DocumentClassifierError> {

        // 1. Create an AsyncThrowingStream to bridge MLProgress callbacks to async/await.
        return AsyncThrowingStream { continuation in
            Task {
                do {
                    // Check for cancellation early.
                    try Task.checkCancellation()
                    continuation.yield(.initial(sessionID: trainingSessionID, datasetName: datasetName))

                    // Simulate Create ML data format: [MLImageClassifier.DataSource.Element]
                    // In a real scenario, you'd load actual images and their labels.
                    let mlDataElements: [MLImageClassifier.DataSource.Element] = trainingData.map { doc in
                        // For demonstration, we'll use dummy data.
                        // In a real app, you'd load UIImage or NSImage from doc.url.
                        // For simplicity, we're passing a placeholder image and relying on the label.
                        // Create ML expects actual image data, so this part is heavily simplified for the example.
                        // A more realistic approach would involve `MLImageClassifier.DataSource.labeledImages(at:)`
                        // pointing to a directory structure like `root/labelA/img1.png`, `root/labelB/img2.png`.
                        // For this code, we'll assume a dummy image and focus on the MLProgress aspect.
                        let dummyImage = NSImage(size: NSSize(width: 100, height: 100)) // macOS specific, use UIImage for iOS
                        return (dummyImage, doc.type.rawValue)
                    }

                    // For Create ML, a real `MLImageClassifier.DataSource` would be created from actual image files.
                    // Example: `let dataSource = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataRootURL)`
                    // Or, for programmatic data:
                    let trainingTable = try MLDataTable(dictionary: [
                        "image": mlDataElements.map { $0.0 }, // Array of images
                        "label": mlDataElements.map { $0.1 }  // Array of labels
                    ])

                    // 2. Initialize MLImageClassifier with the training data.
                    // This is where the actual Create ML training begins.
                    let classifier = try MLImageClassifier(trainingData: trainingTable, parameters: .init()) { progress in
                        // This progress handler is called frequently by Create ML during training.
                        // It's crucial to yield these updates to our AsyncThrowingStream.
                        // We also check for task cancellation within the progress handler.
                        if Task.isCancelled {
                            // If cancellation is detected, stop the training.
                            // This is a crucial pattern for responsive cancellation.
                            progress.cancel()
                            continuation.finish(throwing: .cancellationRequested)
                            return
                        }
                        // Yield progress updates to the stream.
                        let message = "Training epoch \(Int(progress.fractionCompleted * 100))% complete..."
                        continuation.yield(.update(sessionID: trainingSessionID, datasetName: datasetName, progress: progress.fractionCompleted, message: message))
                    }

                    // 3. Save the trained model to the specified output directory.
                    let modelName = "\(datasetName)_DocumentClassifier"
                    let outputURL = modelOutputDirectory.appendingPathComponent(modelName)
                    try classifier.write(to: outputURL)

                    // 4. Signal completion to the stream.
                    continuation.yield(.completed(sessionID: trainingSessionID, datasetName: datasetName, modelURL: outputURL))
                    continuation.finish()

                } catch is CancellationError {
                    // Catch Swift's native CancellationError.
                    continuation.finish(throwing: .cancellationRequested)
                } catch let createMLError as MLCore.Error {
                    // Catch specific Create ML errors.
                    continuation.finish(throwing: .trainingFailed(createMLError.localizedDescription))
                } catch let error as DocumentClassifierError {
                    // Catch custom errors.
                    continuation.finish(throwing: error)
                } catch {
                    // Catch any other unexpected errors.
                    continuation.finish(throwing: .trainingFailed(error.localizedDescription))
                }
            }
        }
    }
}

/// Manages multiple concurrent training sessions using `TaskGroup`.
/// It exposes a single `AsyncStream` for all training updates, allowing a UI to observe progress.
@available(iOS 18.0, macOS 15.0, *)
class TrainingCoordinator {
    private let trainer = DocumentClassifierTrainer()
    private var activeTrainingTasks: [UUID: Task<Void, Never>] = [:]
    private var updatesContinuation: AsyncStream<TrainingProgressUpdate>.Continuation?

    /// An `AsyncStream` that provides real-time updates for all active training sessions.
    /// UI components can iterate over this stream to display progress.
    lazy var trainingUpdates: AsyncStream<TrainingProgressUpdate> = {
        AsyncStream { continuation in
            self.updatesContinuation = continuation
            // Handle stream termination (e.g., when the consumer stops iterating)
            continuation.onTermination = { @Sendable [weak self] _ in
                self?.cancelAllTraining() // Cancel all tasks if the stream is terminated
                self?.updatesContinuation = nil
            }
        }
    }()

    /// Initiates a new training session for a given dataset.
    /// - Parameters:
    ///   - datasetName: The name of the dataset to train with.
    ///   - numberOfDocuments: The number of dummy documents to simulate training with.
    ///   - modelOutputDirectory: The directory where the trained model will be saved.
    /// - Returns: The UUID of the initiated training session.
    func startTrainingSession(
        datasetName: String,
        numberOfDocuments: Int,
        modelOutputDirectory: URL
    ) -> UUID {
        let sessionID = UUID()
        let trainingData = DocumentClassifierTrainer.generateDummyTrainingData(count: numberOfDocuments, datasetName: datasetName)

        // 5. Create a new Task for each training session.
        // This allows multiple training sessions to run concurrently.
        let trainingTask = Task {
            // Use a TaskGroup for structured concurrency if you wanted to coordinate
            // sub-tasks within a single training session (e.g., data preprocessing + training).
            // For this example, each `trainModel` call is treated as one atomic task.
            do {
                // Iterate over the AsyncThrowingStream from the trainer.
                for await update in trainer.trainModel(
                    trainingSessionID: sessionID,
                    datasetName: datasetName,
                    trainingData: trainingData,
                    modelOutputDirectory: modelOutputDirectory
                ) {
                    // Ensure updates are sent on the main actor if they affect UI.
                    // For this example, we directly yield to the shared stream.
                    updatesContinuation?.yield(update)
                }
            } catch let error as DocumentClassifierError {
                // Handle errors from the training stream.
                updatesContinuation?.yield(.failed(sessionID: sessionID, datasetName: datasetName, error: error))
            } catch {
                // Catch any other unexpected errors during stream consumption.
                updatesContinuation?.yield(.failed(sessionID: sessionID, datasetName: datasetName, error: .trainingFailed(error.localizedDescription)))
            }
            // Remove the task from active tasks once it completes or fails.
            await MainActor.run { // Ensure modification of `activeTrainingTasks` is on main actor if not an actor itself
                self.activeTrainingTasks[sessionID] = nil
            }
        }
        activeTrainingTasks[sessionID] = trainingTask
        return sessionID
    }

    /// Cancels a specific training session.
    /// - Parameter sessionID: The UUID of the session to cancel.
    func cancelTraining(sessionID: UUID) {
        if let task = activeTrainingTasks[sessionID] {
            task.cancel() // Request cancellation for the specific task.
            print("Cancellation requested for session: \(sessionID)")
            activeTrainingTasks[sessionID] = nil // Remove immediately, as it's now cancelled
        }
    }

    /// Cancels all currently active training sessions.
    func cancelAllTraining() {
        print("Cancelling all active training sessions.")
        for (_, task) in activeTrainingTasks {
            task.cancel()
        }
        activeTrainingTasks.removeAll()
    }
}

// MARK: - Example Usage in a Conceptual App ViewModel/Controller

/// A conceptual ViewModel that would integrate with a SwiftUI or UIKit view.
/// It uses `@Observable` for automatic UI updates (requires iOS 17+/macOS 14+).
@available(iOS 18.0, macOS 15.0, *)
@Observable
class AppViewModel {
    private let trainingCoordinator = TrainingCoordinator()
    var currentTrainingStatuses: [UUID: TrainingProgressUpdate] = [:]
    var logs: [String] = []

    init() {
        // 6. Start observing training updates as soon as the ViewModel is initialized.
        Task {
            await observeTrainingUpdates()
        }
    }

    /// Observes the `trainingUpdates` stream from the coordinator and updates UI state.
    private func observeTrainingUpdates() async {
        for await update in trainingCoordinator.trainingUpdates {
            // Ensure UI updates are on the main actor. `@Observable` typically handles this,
            // but explicit `MainActor.run` is good practice for non-Observable state.
            await MainActor.run {
                self.currentTrainingStatuses[update.trainingSessionID] = update
                let logMessage = "[\(update.datasetName)] Progress: \(String(format: "%.1f%%", update.progress * 100)) - \(update.message)"
                self.logs.append(logMessage)

                if update.isComplete {
                    if let error = update.error {
                        self.logs.append("[\(update.datasetName)] Training FAILED: \(error.localizedDescription)")
                    } else {
                        self.logs.append("[\(update.datasetName)] Training COMPLETED.")
                    }
                    // Optionally remove completed tasks from `currentTrainingStatuses` if desired.
                }
            }
        }
        await MainActor.run {
            self.logs.append("Training updates stream terminated.")
        }
    }

    /// Simulates a user action to start a new training session.
    func startNewTraining(datasetName: String, numberOfDocuments: Int) {
        let outputDir = FileManager.default.temporaryDirectory.appendingPathComponent("TrainedModels")
        try? FileManager.default.createDirectory(at: outputDir, withIntermediateDirectories: true, attributes: nil)

        let sessionID = trainingCoordinator.startTrainingSession(
            datasetName: datasetName,
            numberOfDocuments: numberOfDocuments,
            modelOutputDirectory: outputDir
        )
        // Initialize status for the new session
        currentTrainingStatuses[sessionID] = .initial(sessionID: sessionID, datasetName: datasetName)
        logs.append("Initiated training for dataset: \(datasetName) (Session ID: \(sessionID))")
    }

    /// Simulates a user action to cancel a specific training session.
    func cancelTraining(sessionID: UUID) {
        trainingCoordinator.cancelTraining(sessionID: sessionID)
        logs.append("User requested cancellation for session: \(sessionID)")
        // Update status to reflect cancellation
        if var status = currentTrainingStatuses[sessionID] {
            status.isComplete = true
            status.error = .cancellationRequested
            status.message = "Training cancelled."
            currentTrainingStatuses[sessionID] = status
        }
    }

    /// Simulates a user action to cancel all training sessions.
    func cancelAllTraining() {
        trainingCoordinator.cancelAllTraining()
        logs.append("User requested cancellation for ALL sessions.")
    }
}

// MARK: - Demonstration of Usage (Main Execution Block)

@available(iOS 18.0, macOS 15.0, *)
@main
struct SmartDocumentClassifierApp {
    static func main() async {
        let viewModel = AppViewModel()

        print("--- Starting Smart Document Classifier Training Demo ---")

        // Start a few training sessions concurrently
        viewModel.startNewTraining(datasetName: "Client A Invoices", numberOfDocuments: 500)
        try? await Task.sleep(for: .milliseconds(100)) // Slight delay for distinct start times
        viewModel.startNewTraining(datasetName: "Client B Receipts", numberOfDocuments: 700)
        try? await Task.sleep(for: .milliseconds(100))
        let contractSessionID = viewModel.startNewTraining(datasetName: "Client C Contracts", numberOfDocuments: 300)

        // Simulate some time passing and then cancelling one task
        try? await Task.sleep(for: .seconds(2))
        viewModel.cancelTraining(sessionID: contractSessionID)

        // Let remaining tasks run for a bit
        try? await Task.sleep(for: .seconds(3))

        // Start another one
        viewModel.startNewTraining(datasetName: "Internal Reports", numberOfDocuments: 600)

        // Let all tasks finish or run for a maximum duration
        print("\n--- Awaiting all training to complete or for timeout (10 seconds) ---")
        let monitorTask = Task {
            var allComplete = false
            while !allComplete {
                try Task.checkCancellation()
                await MainActor.run {
                    allComplete = viewModel.currentTrainingStatuses.values.allSatisfy { $0.isComplete }
                }
                if !allComplete {
                    try? await Task.sleep(for: .milliseconds(500))
                }
            }
            print("\n--- All training sessions have completed or been cancelled. ---")
        }

        // Add a timeout for the monitor task
        let timeoutTask = Task {
            try? await Task.sleep(for: .seconds(10))
            monitorTask.cancel() // Cancel the monitor task after timeout
            print("\n--- Demo timeout reached. Forcing cancellation of any remaining tasks. ---")
            viewModel.cancelAllTraining()
        }

        // Wait for the monitor or timeout task to complete
        _ = await monitorTask.result
        timeoutTask.cancel() // Cancel the timeout task if monitor finished early

        print("\n--- Final Training Statuses ---")
        await MainActor.run {
            for (id, status) in viewModel.currentTrainingStatuses {
                print("Session ID: \(id.uuidString.prefix(8))... - Dataset: \(status.datasetName) - Status: \(status.message) (\(String(format: "%.1f%%", status.progress * 100)))")
                if let error = status.error {
                    print("  Error: \(error.localizedDescription)")
                }
            }
            print("\n--- Full Log ---")
            for log in viewModel.logs {
                print(log)
            }
        }
        print("\n--- Demo Finished ---")
    }
}
