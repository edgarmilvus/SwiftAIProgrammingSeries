
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppTrackingTransparency
import AdSupport
import SwiftUI
import OSLog

// MARK: - Dependencies

/// Package.swift equivalent for conceptual dependencies:
/// .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
/// .package(url: "https://github.com/apple/swift-collections", from: "1.1.0")

// MARK: - Models & Errors

/// Represents the operational modes of the AI engine based on privacy permissions.
enum AIModelMode: String, Codable {
    /// High-fidelity personalization using cloud-based user profiling.
    case cloudEnhanced
    /// Privacy-first mode using only on-device, ephemeral data.
    case localOnly
}

/// Errors related to privacy management and permission requests.
enum PrivacyError: LocalizedError {
    case permissionDenied
    case requestFailed(Error)
    case unavailableOnPlatform
    
    var errorDescription: String? {
        switch self {
        case .permissionDenied: return "User declined tracking permissions."
        case .requestFailed(let error): return "Failed to request tracking: \(error.localizedDescription)"
        case .unavailableOnPlatform: return "ATT is not available on this platform."
        }
    }
}

// MARK: - Privacy Manager (Actor)

/// `PrivacyManager` is a thread-safe actor responsible for interfacing with the 
/// `AppTrackingTransparency` framework. Using an actor ensures that privacy 
/// state transitions are atomic and safe from data races in a concurrent environment.
@available(iOS 18.0, *)
actor PrivacyManager {
    private let logger = Logger(subsystem: "com.ai.app.privacy", category: "PrivacyManager")
    
    /// The current authorization status of the application.
    private(set) var currentStatus: ATTrackingManager.AuthorizationStatus = .notDetermined
    
    init() {
        // In a real app, we might initialize by checking the existing status.
        self.currentStatus = ATTrackingManager.trackingAuthorizationStatus
    }
    
    /// Requests authorization from the user.
    /// - Returns: The resulting `ATTrackingManager.AuthorizationStatus`.
    /// - Throws: `PrivacyError` if the request fails or is impossible.
    func requestTrackingPermission() async throws -> ATTrackingManager.AuthorizationStatus {
        logger.info("Initiating ATT request flow.")
        
        // Ensure we are on the main thread for the UI-blocking ATT prompt.
        let status = await MainActor.run { () -> ATTrackingManager.AuthorizationStatus in
            return ATTrackingManager.requestTrackingAuthorization { status in
                // The callback is handled via the return value of the MainActor block.
            }
        }
        
        // Note: In a real production environment, the closure-based API of ATTrackingManager 
        // is slightly awkward with async/await. We wrap it to provide a modern interface.
        
        // We use a CheckedContinuation to bridge the old callback-based API to Swift Concurrency.
        let finalStatus = try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<ATTrackingManager.AuthorizationStatus, Error>) in
            ATTrackingManager.requestTrackingAuthorization { status in
                continuation.resume(returning: status)
            }
        }
        
        self.currentStatus = finalStatus
        logger.info("ATT status updated to: \(String(describing: finalStatus))")
        return finalStatus
    }
    
    /// Returns the current status without triggering a prompt.
    func getStatus() -> ATTrackingManager.AuthorizationStatus {
        return currentStatus
    }
}

// MARK: - AI Personalization Engine

/// `PersonalizationEngine` manages the AI model's configuration. 
/// It reacts to privacy changes by swapping out the data injection layer.
@available(iOS 18.0, *)
class PersonalizationEngine: ObservableObject {
    @Published private(set) var currentMode: AIModelMode = .localOnly
    @Published private(set) var isConfiguring: Bool = false
    
    private let privacyManager: PrivacyManager
    private let logger = Logger(subsystem: "com.ai.app.engine", category: "Personalization")

    init(privacyManager: PrivacyManager) {
        self.privacyManager = privacyManager
    }

    /// Synchronizes the AI engine's configuration with the current privacy state.
    /// This is the core of the 'Graceful Degradation' pattern.
    @MainActor
    func synchronizeEngineWithPrivacy() async {
        isConfiguring = true
        logger.debug("Synchronizing engine configuration...")
        
        do {
            let status = try await privacyManager.requestTrackingPermission()
            applyStatus(status)
        } catch {
            logger.error("Failed to sync privacy: \(error.localizedDescription)")
            // Fallback to safest mode on error.
            applyStatus(.denied)
        }
        
        isConfiguring = false
    }

    /// Internal helper to map ATT status to AI operational modes.
    private func applyStatus(_ status: ATTrackingManager.AuthorizationStatus) {
        switch status {
        case .authorized:
            self.currentMode = .cloudEnhanced
            configureCloudFeatures()
        case .denied, .restricted:
            self.currentMode = .localOnly
            configurePrivacyFeatures()
        case .notDetermined:
            // Default to local-only until user decides.
            self.currentMode = .localOnly
            configurePrivacyFeatures()
        @unknown default:
            self.currentMode = .localOnly
            configurePrivacyFeatures()
        }
    }

    private func configureCloudFeatures() {
        logger.info("Configuring AI for Cloud-Enhanced Personalization.")
        // Logic to initialize connection to remote vector databases, 
        // user preference telemetry, and cross-session memory.
    }

    private func configurePrivacyFeatures() {
        logger.info("Configuring AI for Local-Only Privacy Mode.")
        // Logic to initialize on-device CoreML models, 
        // use ephemeral memory, and disable telemetry.
    }
    
    /// Simulates an AI inference call.
    func runInference(prompt: String) async -> String {
        if currentMode == .cloudEnhanced {
            // Simulate network latency for cloud-based model.
            try? await Task.sleep(for: .seconds(1))
            return "Cloud-Enhanced Response to: \(prompt)"
        } else {
            // Instant on-device response.
            return "Local-Only Response to: \(prompt)"
        }
    }
}

// MARK: - UI Layer (SwiftUI)

/// The main interface for the AI Assistant, demonstrating how the UI 
/// reacts to the underlying privacy and engine states.
@available(iOS 18.0, *)
struct AIAssistantView: View {
    @StateObject private var engine: PersonalizationEngine
    private let privacyManager: PrivacyManager
    
    init(privacyManager: PrivacyManager) {
        self.privacyManager = privacyManager
        let engine = PersonalizationEngine(privacyManager: privacyManager)
        self._engine = StateObject(wrappedValue: engine)
    }
    
    @State private var userInput: String = ""
    @State private var aiResponse: String = "Waiting for input..."

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Privacy Status Banner
                PrivacyStatusBanner(mode: engine.currentMode)
                
                // AI Chat Interface
                ScrollView {
                    Text(aiResponse)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.secondary.opacity(0.1))
                        .cornerRadius(12)
                }
                .frame(maxHeight: .infinity)
                
                // Input Area
                HStack {
                    TextField("Ask the AI...", text: $userInput)
                        .textFieldStyle(.roundedBorder)
                    
                    Button(action: sendPrompt) {
                        Image(systemName: "paperplane.fill")
                    }
                    .disabled(engine.isConfiguring)
                }
                
                // Manual Privacy Trigger (For testing/UX)
                Button("Adjust Privacy Settings") {
                    Task {
                        await engine.synchronizeEngineWithPrivacy()
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            .padding()
            .navigationTitle("AI Personal Assistant")
            .task {
                // Initial sync on launch
                await engine.synchronizeEngineWithPrivacy()
            }
        }
    }
    
    private func sendPrompt() {
        let prompt = userInput
        userInput = ""
        Task {
            aiResponse = "Thinking..."
            aiResponse = await engine.runInference(prompt: prompt)
        }
    }
}

struct PrivacyStatusBanner: View {
    let mode: AIModelMode
    
    var body: some View {
        HStack {
            Image(systemName: mode == .cloudEnhanced ? "cloud.fill" : "lock.shield.fill")
            Text(mode == .cloudEnhanced ? "Cloud-Enhanced Mode" : "Privacy Mode (Local Only)")
                .font(.caption.bold())
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(mode == .cloudEnhanced ? Color.blue.opacity(0.2) : Color.green.opacity(0.2))
        .foregroundColor(mode == .cloudEnhanced ? .blue : .green)
        .clipShape(Capsule())
    }
}

// MARK: - App Entry Point

@main
struct AIAssistantApp: App {
    // We initialize the PrivacyManager here to ensure it lives for the app lifecycle.
    @State private var privacyManager = PrivacyManager()
    
    var body: some Scene {
        WindowGroup {
            AIAssistantView(privacyManager: privacyManager)
        }
    }
}
