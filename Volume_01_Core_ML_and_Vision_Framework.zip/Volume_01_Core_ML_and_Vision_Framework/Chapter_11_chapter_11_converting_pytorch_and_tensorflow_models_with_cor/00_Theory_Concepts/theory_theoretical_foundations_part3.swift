
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import CoreML
import Vision

// Assume ModelLoader and InferenceActor are defined as above
// For simplicity, we'll use a mock MLFeatureProvider
struct MockImageFeatureProvider: MLFeatureProvider {
    var featureNames: Set<String> { ["image"] }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        // In a real app, this would provide a CVPixelBuffer or similar
        return MLFeatureValue(string: "mock_image_data")
    }
}

@available(iOS 18.0, macOS 15.0, *)
@Observable
class MLViewModel {
    var isLoadingModel: Bool = false
    var inferenceResults: [InferenceActor.InferenceResult] = []
    var errorMessage: String?
    
    private var modelLoader = ModelLoader()
    private var inferenceActor: InferenceActor?

    @MainActor // UI updates and model loading often start from MainActor
    func setupModelAndPerformInference() async {
        isLoadingModel = true
        errorMessage = nil
        do {
            let loadedModel = try await modelLoader.loadModel(named: "MyImageClassifier")
            self.inferenceActor = InferenceActor(model: loadedModel)
            
            // Simulate an image input
            let mockImage = MockImageFeatureProvider()
            let results = try await inferenceActor!.classifyImage(input: mockImage)
            
            self.inferenceResults = results
            isLoadingModel = false
        } catch {
            self.errorMessage = "Failed to load or infer: \(error.localizedDescription)"
            isLoadingModel = false
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct InferenceView: View {
    @State private var viewModel = MLViewModel()

    var body: some View {
        VStack {
            if viewModel.isLoadingModel {
                ProgressView("Loading Model & Inferring...")
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            } else {
                List(viewModel.inferenceResults, id: \.identifier) { result in
                    HStack {
                        Text(result.identifier)
                        Spacer()
                        Text(String(format: "%.2f%%", result.confidence * 100))
                    }
                }
            }
            
            Button("Run Inference") {
                Task {
                    await viewModel.setupModelAndPerformInference()
                }
            }
            .padding()
            .disabled(viewModel.isLoadingModel)
        }
        .onAppear {
            // Optional: run inference on appear
            // Task { await viewModel.setupModelAndPerformInference() }
        }
        .navigationTitle("Image Classification")
    }
}
