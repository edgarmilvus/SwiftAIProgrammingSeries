
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML // Required for MLTextClassifier

// MARK: - 1. Data Models

/// Represents a single customer support ticket.
struct SupportTicket: Identifiable, Hashable {
    let id: UUID
    let subject: String
    let body: String
    var classificationResult: ClassificationResult?

    init(id: UUID = UUID(), subject: String, body: String, classificationResult: ClassificationResult? = nil) {
        self.id = id
        self.subject = subject
        self.body = body
        self.classificationResult = classificationResult
    }

    /// Combines subject and body for classification.
    var fullText: String {
        "Subject: \(subject). Body: \(body)"
    }
}

/// Represents the classification outcome for a support ticket.
struct ClassificationResult: Hashable {
    let topic: String
    let sentiment: String // Could be "Positive", "Negative", "Neutral", "Urgent"
    let topicProbabilities: [String: Double]
    let sentimentProbabilities: [String: Double]
}

// MARK: - 2. Custom Error Handling

/// Custom errors that can occur during text classification operations.
enum MLTextClassifierServiceError: Error, LocalizedError {
    case modelNotFound(name: String, ext: String)
    case modelLoadingFailed(Error)
    case predictionFailed(Error)
    case modelNotLoaded

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let name, let ext):
            return "ML Model '\(name).\(ext)' could not be found in the app bundle."
        case .modelLoadingFailed(let error):
            return "Failed to load ML model: \(error.localizedDescription)"
        case .predictionFailed(let error):
            return "Failed to perform prediction: \(error.localizedDescription)"
        case .modelNotLoaded:
            return "ML model is not loaded. Call loadModel() first."
        }
    }
}

// MARK: - 3. MLTextClassifierService

/// A service class responsible for loading and interacting with a custom MLTextClassifier model.
///
/// This service encapsulates the logic for loading a pre-trained Core ML text classification model
/// and performing both single and batch predictions asynchronously. It handles potential errors
/// during model operations and ensures the model is ready before predictions are attempted.
@available(iOS 18.0, *) // Using iOS 18 for latest Swift 6 concurrency features like TaskGroup refinements
final class MLTextClassifierService: ObservableObject {
    // The actual MLTextClassifier instance. It's optional because it's loaded asynchronously.
    private var topicClassifier: MLTextClassifier?
    private var sentimentClassifier: MLTextClassifier?

    // Model names for loading from the app bundle.
    private let topicModelName: String
    private let sentimentModelName: String

    /// Initializes the service with the names of the topic and sentiment classification models.
    ///
    /// - Parameters:
    ///   - topicModelName: The filename of the topic classification model (without extension).
    ///   - sentimentModelName: The filename of the sentiment classification model (without extension).
    init(topicModelName: String = "TicketTopicClassifier", sentimentModelName: String = "TicketSentimentClassifier") {
        self.topicModelName = topicModelName
        self.sentimentModelName = sentimentModelName
    }

    /// Asynchronously loads the MLTextClassifier models from the app bundle.
    ///
    /// This method should be called once, typically during app startup or when the service is initialized,
    /// to prepare the models for prediction. It handles potential file not found or loading errors.
    ///
    /// - Throws: `MLTextClassifierServiceError` if models cannot be found or loaded.
    func loadModels() async throws {
        // Load Topic Classifier
        guard let topicModelURL = Bundle.main.url(forResource: topicModelName, withExtension: "mlmodelc") else {
            throw MLTextClassifierServiceError.modelNotFound(name: topicModelName, ext: "mlmodelc")
        }
        do {
            self.topicClassifier = try MLTextClassifier(contentsOf: topicModelURL)
            print("Topic classifier '\(topicModelName)' loaded successfully.")
        } catch {
            throw MLTextClassifierServiceError.modelLoadingFailed(error)
        }

        // Load Sentiment Classifier
        guard let sentimentModelURL = Bundle.main.url(forResource: sentimentModelName, withExtension: "mlmodelc") else {
            throw MLTextClassifierServiceError.modelNotFound(name: sentimentModelName, ext: "mlmodelc")
        }
        do {
            self.sentimentClassifier = try MLTextClassifier(contentsOf: sentimentModelURL)
            print("Sentiment classifier '\(sentimentModelName)' loaded successfully.")
        } catch {
            throw MLTextClassifierServiceError.modelLoadingFailed(error)
        }
    }

    /// Performs sentiment and topic classification for a single piece of text.
    ///
    /// - Parameter text: The input string to classify.
    /// - Returns: A `ClassificationResult` containing the predicted topic, sentiment, and their probabilities.
    /// - Throws: `MLTextClassifierServiceError` if models are not loaded or prediction fails.
    func classifyText(_ text: String) async throws -> ClassificationResult {
        guard let topicModel = topicClassifier, let sentimentModel = sentimentClassifier else {
            throw MLTextClassifierServiceError.modelNotLoaded
        }

        do {
            // Perform topic classification
            let topicPrediction = try topicModel.prediction(from: text)
            let topic = topicPrediction.label
            let topicProbabilities = topicPrediction.labelProbabilities

            // Perform sentiment classification
            let sentimentPrediction = try sentimentModel.prediction(from: text)
            let sentiment = sentimentPrediction.label
            let sentimentProbabilities = sentimentPrediction.labelProbabilities

            return ClassificationResult(
                topic: topic,
                sentiment: sentiment,
                topicProbabilities: topicProbabilities,
                sentimentProbabilities: sentimentProbabilities
            )
        } catch {
            throw MLTextClassifierServiceError.predictionFailed(error)
        }
    }

    /// Concurrently classifies a batch of support tickets.
    ///
    /// This method leverages `TaskGroup` to process multiple tickets in parallel,
    /// significantly improving performance for large batches. Each ticket's full text
    /// is classified, and its `classificationResult` property is updated.
    ///
    /// - Parameter tickets: An inout array of `SupportTicket` to be classified.
    ///   The `classificationResult` of each ticket will be updated directly.
    /// - Throws: `MLTextClassifierServiceError` if models are not loaded or
    ///   any individual prediction fails.
    func classifyTickets(batch tickets: inout [SupportTicket]) async throws {
        guard topicClassifier != nil, sentimentClassifier != nil else {
            throw MLTextClassifierServiceError.modelNotLoaded
        }

        // Use a TaskGroup to process tickets concurrently
        await withTaskGroup(of: (Int, Result<ClassificationResult, Error>).self) { group in
            for (index, ticket) in tickets.enumerated() {
                group.addTask {
                    do {
                        let result = try await self.classifyText(ticket.fullText)
                        return (index, .success(result))
                    } catch {
                        return (index, .failure(error))
                    }
                }
            }

            // Collect results as they complete
            for await (index, result) in group {
                switch result {
                case .success(let classification):
                    tickets[index].classificationResult = classification
                    print("Ticket \(tickets[index].id) classified: Topic=\(classification.topic), Sentiment=\(classification.sentiment)")
                case .failure(let error):
                    // Log or handle individual ticket classification failures
                    print("Error classifying ticket \(tickets[index].id): \(error.localizedDescription)")
                    // Depending on requirements, you might want to re-throw,
                    // or set a nil classificationResult for failed tickets.
                    tickets[index].classificationResult = nil // Mark as failed
                }
            }
        }
    }
}

// MARK: - 4. Integration with a ViewModel (Conceptual Example)

/// A conceptual ViewModel for a SwiftUI view that manages support tickets.
///
/// This ViewModel demonstrates how the `MLTextClassifierService` would be used
/// in a real application to load models, add new tickets, and classify them.
@available(iOS 18.0, *)
final class TicketAnalyzerViewModel: ObservableObject {
    @Published var tickets: [SupportTicket] = []
    @Published var isLoadingModels: Bool = false
    @Published var isClassifying: Bool = false
    @Published var errorMessage: String?

    private let classifierService: MLTextClassifierService

    /// Initializes the ViewModel with the classification service.
    ///
    /// - Parameter classifierService: An instance of `MLTextClassifierService`.
    init(classifierService: MLTextClassifierService = MLTextClassifierService()) {
        self.classifierService = classifierService
    }

    /// Loads the ML models asynchronously.
    ///
    /// This should typically be called once when the app or view appears.
    func loadModels() async {
        isLoadingModels = true
        errorMessage = nil
        do {
            try await classifierService.loadModels()
        } catch {
            errorMessage = error.localizedDescription
            print("Error loading models: \(error.localizedDescription)")
        }
        isLoadingModels = false
    }

    /// Adds a new support ticket to the list.
    ///
    /// - Parameters:
    ///   - subject: The subject line of the ticket.
    ///   - body: The main body text of the ticket.
    func addTicket(subject: String, body: String) {
        let newTicket = SupportTicket(subject: subject, body: body)
        tickets.append(newTicket)
        // Optionally classify immediately, or wait for a batch process
    }

    /// Classifies all unclassified tickets in the current list.
    ///
    /// This method demonstrates using the batch classification feature.
    func classifyAllTickets() async {
        isClassifying = true
        errorMessage = nil
        do {
            // Filter for unclassified tickets or all tickets if re-classifying
            var ticketsToClassify = tickets.filter { $0.classificationResult == nil }
            if ticketsToClassify.isEmpty && !tickets.isEmpty {
                // If all are classified, re-classify all for demo purposes
                ticketsToClassify = tickets
            } else if ticketsToClassify.isEmpty {
                print("No tickets to classify.")
                isClassifying = false
                return
            }

            try await classifierService.classifyTickets(batch: &ticketsToClassify)

            // Update the main tickets array with classified results
            for classifiedTicket in ticketsToClassify {
                if let index = tickets.firstIndex(where: { $0.id == classifiedTicket.id }) {
                    tickets[index] = classifiedTicket
                }
            }
            print("All tickets classified successfully.")
        } catch {
            errorMessage = error.localizedDescription
            print("Error classifying tickets: \(error.localizedDescription)")
        }
        isClassifying = false
    }

    // MARK: - Example Usage (for demonstration in a playground or main app)

    /// A simple demonstration function to run the classification process.
    ///
    /// This function simulates the lifecycle of the ViewModel and service.
    func runDemo() async {
        print("\n--- Starting MLTextClassifier Service Demo ---")

        // 1. Load Models
        print("Attempting to load ML models...")
        await loadModels()
        if let error = errorMessage {
            print("Demo aborted due to model loading error: \(error)")
            return
        }
        print("Models loaded. Adding demo tickets...")

        // 2. Add Demo Tickets
        addTicket(subject: "Billing Issue: Incorrect Charge", body: "I was charged twice for my subscription this month. Please investigate and refund the duplicate charge immediately. This is urgent!")
        addTicket(subject: "Feature Request: Dark Mode", body: "I love your app, but I would really appreciate a dark mode option for better night-time viewing. Thanks!")
        addTicket(subject: "Technical Problem: App Crashing", body: "My app keeps crashing every time I try to open the settings menu on my iPhone 15 Pro Max running iOS 18. It's very frustrating.")
        addTicket(subject: "Positive Feedback", body: "Just wanted to say how much I enjoy using your product. The new update is fantastic!")
        addTicket(subject: "Question about API", body: "Could you provide more documentation on your public API's authentication methods? I'm having trouble integrating.")

        print("Added \(tickets.count) demo tickets.")

        // 3. Classify Tickets
        print("Attempting to classify all tickets...")
        await classifyAllTickets()

        // 4. Display Results
        print("\n--- Classification Results ---")
        for ticket in tickets {
            print("Ticket ID: \(ticket.id)")
            print("  Subject: \(ticket.subject)")
            if let result = ticket.classificationResult {
                print("  Topic: \(result.topic) (Prob: \(result.topicProbabilities[result.topic, default: 0.0] * 100.0, specifier: "%.2f")%)")
                print("  Sentiment: \(result.sentiment) (Prob: \(result.sentimentProbabilities[result.sentiment, default: 0.0] * 100.0, specifier: "%.2f")%)")
            } else {
                print("  Classification: Failed or Pending")
            }
            print("---")
        }

        print("--- MLTextClassifier Service Demo Complete ---")
    }
}

// MARK: - App Entry Point (Conceptual)

/*
// In a real SwiftUI app, your App struct would look something like this:

@main
struct SupportTicketAnalyzerApp: App {
    @StateObject private var viewModel = TicketAnalyzerViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel) // Make ViewModel available to views
                .task {
                    // Load models when the app starts
                    await viewModel.loadModels()
                }
        }
    }
}

// And a ContentView might look like:
struct ContentView: View {
    @EnvironmentObject var viewModel: TicketAnalyzerViewModel
    @State private var newTicketSubject: String = ""
    @State private var newTicketBody: String = ""

    var body: some View {
        NavigationView {
            List {
                Section("New Ticket") {
                    TextField("Subject", text: $newTicketSubject)
                    TextEditor(text: $newTicketBody)
                        .frame(minHeight: 80)
                    Button("Add Ticket") {
                        viewModel.addTicket(subject: newTicketSubject, body: newTicketBody)
                        newTicketSubject = ""
                        newTicketBody = ""
                    }
                    .disabled(newTicketSubject.isEmpty || newTicketBody.isEmpty)
                }

                if viewModel.isLoadingModels {
                    ProgressView("Loading ML Models...")
                } else if let error = viewModel.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                } else {
                    Section("Tickets") {
                        if viewModel.tickets.isEmpty {
                            Text("No tickets yet. Add some above!")
                        } else {
                            ForEach(viewModel.tickets) { ticket in
                                VStack(alignment: .leading) {
                                    Text(ticket.subject).font(.headline)
                                    Text(ticket.body).font(.subheadline).lineLimit(2)
                                    if let result = ticket.classificationResult {
                                        HStack {
                                            Label(result.topic, systemImage: "tag.fill")
                                                .font(.caption)
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 3)
                                                .background(Color.blue.opacity(0.2))
                                                .cornerRadius(5)
                                            Label(result.sentiment, systemImage: "hand.thumbsup.fill") // or appropriate icon
                                                .font(.caption)
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 3)
                                                .background(sentimentColor(result.sentiment))
                                                .cornerRadius(5)
                                        }
                                    } else {
                                        Text("Awaiting classification...")
                                            .font(.caption)
                                            .foregroundColor(.gray)
                                    }
                                }
                            }
                        }
                    }

                    if !viewModel.tickets.isEmpty {
                        Section {
                            Button {
                                Task {
                                    await viewModel.classifyAllTickets()
                                }
                            } label: {
                                if viewModel.isClassifying {
                                    ProgressView("Classifying...")
                                } else {
                                    Text("Classify All Tickets")
                                }
                            }
                            .disabled(viewModel.isClassifying)
                        }
                    }
                }
            }
            .navigationTitle("Support Analyzer")
        }
    }

    private func sentimentColor(_ sentiment: String) -> Color {
        switch sentiment {
        case "Positive": return .green.opacity(0.2)
        case "Negative": return .red.opacity(0.2)
        case "Urgent": return .orange.opacity(0.2)
        default: return .gray.opacity(0.2)
        }
    }
}
*/

// To run the demo in a Playground or a simple command-line tool:
/*
@available(iOS 18.0, *)
Task {
    let viewModel = TicketAnalyzerViewModel()
    await viewModel.runDemo()
}
*/
