
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import WritingTools

// Define a custom error for our actor
enum WritingToolServiceError: Error, LocalizedError {
    case sessionNotFound(UUID)
    case requestFailed(Error)

    var errorDescription: String? {
        switch self {
        case .sessionNotFound(let id):
            return "Writing session with ID \(id) not found."
        case .requestFailed(let error):
            return "Writing tool request failed: \(error.localizedDescription)"
        }
    }
}

@available(iOS 18.0, *)
actor WritingToolCoordinator {
    private var activeSessions: [UUID: WritingToolSession] = [:] // Isolated mutable state

    /// Creates and registers a new writing session.
    /// - Returns: The UUID of the new session.
    func createNewSession() -> UUID {
        let id = UUID()
        activeSessions[id] = WritingToolSession()
        return id
    }

    /// Performs a writing tool request on a specific session.
    /// - Parameters:
    ///   - sessionId: The ID of the session to use.
    ///   - request: The WritingToolRequest to perform.
    /// - Returns: The result of the writing tool request.
    /// - Throws: `WritingToolServiceError` if the session is not found or the request fails.
    func performRequest(sessionId: UUID, request: WritingToolRequest) async throws -> WritingToolResult {
        guard let session = activeSessions[sessionId] else {
            throw WritingToolServiceError.sessionNotFound(sessionId)
        }
        do {
            return try await session.perform(request)
        } catch {
            throw WritingToolServiceError.requestFailed(error)
        }
    }

    /// Cleans up a specific session.
    func invalidateSession(sessionId: UUID) {
        activeSessions.removeValue(forKey: sessionId)
    }

    /// Example of using the coordinator
    func processMultipleRequests() async {
        let session1Id = createNewSession()
        let session2Id = createNewSession()

        // Perform requests concurrently using different sessions
        async let result1 = try? performRequest(sessionId: session1Id, request: .rephrase(text: "Hello, how are you?"))
        async let result2 = try? performRequest(sessionId: session2Id, request: .summarize(text: "This is a very long text that needs to be summarized."))

        let (r1, r2) = await (result1, result2)

        if let r1 = r1 { print("Session 1 Suggestions: \(r1.suggestions.count)") }
        if let r2 = r2 { print("Session 2 Suggestions: \(r2.suggestions.count)") }

        invalidateSession(sessionId: session1Id)
        invalidateSession(sessionId: session2Id)
    }
}
