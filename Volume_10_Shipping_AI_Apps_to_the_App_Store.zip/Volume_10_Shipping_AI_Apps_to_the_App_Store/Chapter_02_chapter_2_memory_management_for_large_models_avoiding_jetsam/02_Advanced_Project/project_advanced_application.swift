
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog

// MARK: - Package Dependencies
/*
 [Package.swift]
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ]
*/

/// Represents the severity of memory pressure reported by the iOS kernel.
enum MemoryPressureLevel: Int, Sendable, Comparable {
    case normal = 0
    case warning = 1
    case critical = 2

    static func < (lhs: MemoryPressureLevel, rhs: MemoryPressureLevel) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
}

/// Errors specifically related to AI Model lifecycle and memory constraints.
enum AIModelError: Error, LocalizedError {
    case insufficientMemoryForModel(modelID: String)
    case modelLoadFailed(reason: String)
    case orchestrationFailure(underlying: Error)

    var errorDescription: String? {
        switch self {
        case .insufficientMemoryForModel(let id): return "Insufficient RAM to load model: \(id)"
        case .modelLoadFailed(let reason): return "Model load failed: \(reason)"
        case .orchestrationFailure(let error): return "Orchestration error: \(error.localizedDescription)"
        }
    }
}

/// A protocol defining the requirements for a memory-intensive AI resource.
protocol AIResource: AnyObject, Sendable {
    var identifier: String { get }
    var estimatedMemoryUsage: UInt64 { get }
    func purgeCache() async
    func unloadFromMemory() async
}

/// A mock implementation of a Large Language Model for demonstration.
/// In a real app, this would wrap a CoreML or llama.cpp instance.
final class LargeLanguageModel: AIResource, @unchecked Sendable {
    let identifier: String
    let estimatedMemoryUsage: UInt64
    private let logger = Logger(subsystem: "com.ai.app", category: "Model")

    init(identifier: String, sizeInGB: Double) {
        self.identifier = identifier
        self.estimatedMemoryUsage = UInt64(sizeInGB * 1024 * 1024 * 1024)
    }

    /// Purges the KV Cache (Key-Value cache) to free up immediate RAM.
    func purgeCache() async {
        logger.info("[\(self.identifier)] Purging KV Cache...")
        // Simulate latency of cache clearing
        try? await Task.sleep(for: .milliseconds(100))
    }

    /// Completely unloads the model weights from the resident set.
    func unloadFromMemory() async {
        logger.info("[\(self.identifier)] Unloading weights from RAM...")
        // In practice, this would involve deallocating buffers or unmapping files.
        try? await Task.sleep(for: .milliseconds(300))
    }
}

/// The core orchestrator responsible for preventing Jetsam kills.
/// It uses Swift 6 Concurrency (Actor) to ensure thread-safe memory management.
@available(iOS 18.0, *)
actor AILogicMemoryOrchestrator {
    private let logger = Logger(subsystem: "com.ai.app", category: "Orchestrator")
    
    /// The currently active model being used for inference.
    private var activeModel: (model: LargeLanguageModel, priority: Int)?
    
    /// A registry of loaded models that are currently in a "suspended" state in RAM.
    private var loadedModels: [String: LargeLanguageModel] = [:]
    
    /// The current system memory pressure level.
    private(set) var currentPressure: MemoryPressureLevel = .normal
    
    private var pressureSource: DispatchSourceMemoryPressure?

    init() {
        setupMemoryMonitoring()
    }

    /// Initializes the kernel-level memory pressure monitor.
    private func setupMemoryMonitoring() {
        // We use DispatchSource to listen to the kernel's memory pressure events.
        let source = DispatchSource.makeMemoryPressureSource(eventMask: [.warning, .critical], queue: .main)
        
        source.setEventHandler { [weak self] in
            // This closure runs on the main queue, but we will bridge to the actor.
            let event = source.data
            Task { [weak self] in
                await self?.handlePressureEvent(event)
            }
        }
        
        source.resume()
        self.pressureSource = source
    }

    /// Responds to kernel pressure events by executing tiered eviction strategies.
    private func handlePressureEvent(_ event: DispatchSource.MemoryPressureEvent) async {
        let newPressure: MemoryPressureLevel
        
        if event.contains(.critical) {
            newPressure = .critical
            logger.critical("CRITICAL memory pressure detected! Initiating emergency purge.")
        } else if event.contains(.warning) {
            newPressure = .warning
            logger.warning("Memory pressure warning detected. Optimizing resources.")
        } else {
            newPressure = .normal
        }

        self.currentPressure = newPressure
        await performEvictionStrategy(for: newPressure)
    }

    /// The decision engine for memory eviction.
    /// 1. Warning: Purge non-essential caches.
    /// 2. Critical: Unload all non-active models and clear all caches.
    private func performEvictionStrategy(for level: MemoryPressureLevel) async {
        switch level {
        case .normal:
            logger.info("Memory pressure normalized.")
            
        case .warning:
            // Strategy: Keep models, but clear their volatile KV caches to reduce RSS.
            logger.info("Executing Warning Strategy: Purging all KV caches.")
            for model in loadedModels.values {
                await model.purgeCache()
            }
            if let active = activeModel {
                await active.model.purgeCache()
            }

        case .critical:
            // Strategy: Immediate survival. Unload everything except the absolute minimum.
            logger.error("Executing Critical Strategy: Unloading all non-active models.")
            
            // 1. Unload all background models
            for (id, model) in loadedModels {
                if activeModel?.model.identifier != id {
                    await model.unloadFromMemory()
                    loadedModels.removeValue(forKey: id)
                }
            }
            
            // 2. If even the active model is too much, we may need to signal the UI to stop inference.
            if let active = activeModel {
                await active.model.purgeCache()
                // Note: We do NOT unload the active model here to avoid a total app failure,
                // but we have cleared its transient memory.
            }
        }
    }

    /// Safely loads a model into the orchestrator's management.
    /// - Parameters:
    ///   - model: The model instance to manage.
    ///   - priority: Importance of the model (higher = harder to evict).
    func registerModel(_ model: LargeLanguageModel, priority: Int) async throws {
        // Check if we are already in a critical state before attempting load.
        guard currentPressure != .critical else {
            throw AIModelError.insufficientMemoryForModel(modelID: model.identifier)
        }

        logger.info("Registering model: \(model.identifier)")
        loadedModels[model.identifier] = model
    }

    /// Sets the primary model for inference.
    func setActiveModel(_ model: LargeLanguageModel, priority: Int) async {
        // If we are switching models, ensure the previous one is handled.
        if let oldActive = activeModel {
            logger.info("Switching from \(oldActive.model.identifier) to \(model.identifier)")
            // We don't necessarily unload it, just move it to the 'loaded' pool.
        }
        
        activeModel = (model, priority)
        logger.info("Active model set to: \(model.identifier)")
    }
}

// MARK: - Application Integration Example

@main
struct AIApp {
    static func main() async {
        let orchestrator = AILogicMemoryOrchestrator()
        
        // 1. Initialize models
        let smallModel = LargeLanguageModel(identifier: "Llama-3-8B-Quantized", sizeInGB: 4.5)
        let backgroundModel = LargeLanguageModel(identifier: "Embedding-Model", sizeInGB: 1.2)

        do {
            // 2. Register models
            try await orchestrator.registerModel(smallModel, priority: 10)
            try await orchestrator.registerModel(backgroundModel, priority: 5)

            // 3. Set the active model for the user's chat session
            await orchestrator.setActiveModel(smallModel, priority: 10)

            // Simulate an app running...
            print("AI Orchestrator is running. Monitoring kernel pressure...")
            
            // In a real scenario, the system would trigger the pressure events.
            // Here we simulate a critical event manually for demonstration.
            try await Task.sleep(for: .seconds(2))
            print("\n--- SIMULATING KERNEL CRITICAL PRESSURE ---")
            // In real life, this is triggered by the OS.
            // We call the internal handler to demonstrate the logic.
            // (In a real test, we would use XCTest to trigger memory pressure)
            
        } catch {
            print("Initialization failed: \(error.localizedDescription)")
        }

        // Keep the process alive for simulation
        try? await Task.sleep(for: .seconds(5))
    }
}
