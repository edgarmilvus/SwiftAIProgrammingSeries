
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *) // Actors were introduced earlier, but using 18.0 for potential future features
actor AIManagementActor {
    // Internal state, safely isolated
    private var loadedModel: MLModel?
    private var inferenceQueue: [Data] = [] // Example: queue of inputs

    // An observable object to publish results to SwiftUI
    @Published var latestPrediction: String = "No prediction yet."

    init() {
        // Asynchronous initialization could happen here
    }

    func loadModel(named modelName: String) async throws {
        // Simulate loading a large model
        print("Loading model: \(modelName)...")
        try await Task.sleep(for: .seconds(2)) // Simulate network/disk I/O
        // In a real app, this would load an MLModel or similar
        self.loadedModel = MLModel() // Placeholder
        print("Model '\(modelName)' loaded.")
    }

    func performInference(input: Data) async throws -> String {
        guard let model = loadedModel else {
            throw AIError.modelNotLoaded
        }

        // Simulate adding to an internal queue and serial processing
        inferenceQueue.append(input)
        print("Input added to queue. Queue size: \(inferenceQueue.count)")

        // Simulate actual inference, which runs serially within the actor
        try await Task.sleep(for: .seconds(3)) // Simulate complex computation
        let result = "Prediction for \(input.count) bytes: \(UUID().uuidString)"
        print("Inference complete: \(result)")

        // Update published property
        await MainActor.run {
            self.latestPrediction = result
        }

        // Remove from queue after processing
        if let index = inferenceQueue.firstIndex(of: input) {
            inferenceQueue.remove(at: index)
        }
        return result
    }

    // Example of an internal error type
    enum AIError: Error {
        case modelNotLoaded
        case inferenceFailed
    }
}

// How to interact with the actor from a SwiftUI View or other task:
@available(iOS 18.0, *)
class AIViewModel: ObservableObject {
    private let aiActor = AIManagementActor()

    @Published var modelStatus: String = "Not loaded"
    @Published var predictionResult: String = "Awaiting inference..."

    init() {
        Task {
            await aiActor.$latestPrediction
                .receive(on: RunLoop.main) // Ensure updates are on main thread for UI
                .assign(to: &self.$predictionResult)
        }
    }

    func startAITask() {
        Task {
            do {
                await self.aiActor.loadModel(named: "MyAwesomeAI")
                await MainActor.run { self.modelStatus = "Model loaded" }

                let inputData = Data("Hello AI".utf8)
                let result = try await self.aiActor.performInference(input: inputData)
                await MainActor.run { self.predictionResult = result }

            } catch {
                await MainActor.run {
                    self.modelStatus = "Error: \(error.localizedDescription)"
                    self.predictionResult = "Error during inference."
                }
            }
        }
    }
}
