
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CloudKit
import UserNotifications

/// Manages the synchronization state to prevent data races between 
/// background pushes and foreground user interactions.
actor TaskSyncManager {
    private var isSyncing = false
    private let database = CKContainer.default().privateCloudDatabase
    
    /// Performs a lightweight check to see if remote data has changed.
    /// Returns true if an update was required.
    func performLightweightSync() async -> Bool {
        // Prevent "Thundering Herd" - if already syncing, skip this pulse
        guard !isSyncing else { return false }
        isSyncing = true
        
        defer { isSyncing = false }
        
        do {
            // A lightweight query looking only for the most recent modification date
            // to determine if a full sync is actually needed.
            let predicate = NSPredicate(value: true)
            let query = CKQuery(recordType: "Task", predicate: predicate)
            query.sortDescriptors = [NSSortDescriptor(key: "modificationDate", ascending: false)]
            
            // We only fetch the record ID and modification date to save bandwidth/time
            let (results, _) = try await database.records(matching: query, resultsLimit: 1)
            
            if let firstResult = results.first {
                // Logic to compare remote modificationDate with local Core Data max date
                // would go here. For this exercise, we assume we found a change.
                print("Silent Pulse: Remote change detected.")
                return true
            }
        } catch {
            print("Silent Pulse: Sync failed with error: \(error)")
        }
        
        return false
    }
}

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    let syncManager = TaskSyncManager()

    func application(_ application: UIApplication, 
                     didReceiveRemoteNotification userInfo: [AnyHashable : Any], 
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        // 1. Verify this is a silent push (content-available: 1)
        guard userInfo[NSNotificationInfoKey.contentAvailable] as? Int == 1 else {
            completionHandler(.noData)
            return
        }

        // 2. Use Swift 6 Task to bridge the synchronous completion handler to async code
        Task {
            let needsUpdate = await syncManager.performLightweightSync()
            
            if needsUpdate {
                // Trigger local Core Data refresh logic here
                completionHandler(.newData)
            } else {
                completionHandler(.noData)
            }
        }
    }
}
