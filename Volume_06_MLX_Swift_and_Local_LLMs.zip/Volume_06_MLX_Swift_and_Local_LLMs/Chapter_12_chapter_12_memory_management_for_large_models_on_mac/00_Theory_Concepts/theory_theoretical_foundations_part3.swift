
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN // Assuming SimpleLinearModel is defined here

@available(iOS 18.0, macOS 15.0, *)
actor LLMInferenceActor {
    private var model: SimpleLinearModel?
    private let inputFeatures: Int
    private let outputFeatures: Int

    init(inputFeatures: Int, outputFeatures: Int) {
        self.inputFeatures = inputFeatures
        self.outputFeatures = outputFeatures
    }

    // Safely load the model within the actor's isolated context
    func loadModel() async throws {
        // Simulate a long loading operation
        try await Task.sleep(for: .seconds(2))
        self.model = SimpleLinearModel(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        print("Model loaded successfully.")
    }

    // Perform inference safely
    func performInference(input: MLXArray) async throws -> MLXArray {
        guard let model = self.model else {
            throw LLMError.modelNotLoaded
        }
        // MLX operations are efficient on Unified Memory
        let output = model(input)
        // Explicitly evaluate if needed for immediate value, otherwise MLX handles it
        return output.eval()
    }

    enum LLMError: Error {
        case modelNotLoaded
    }
}

// Example usage outside the actor:
@available(iOS 18.0, macOS 15.0, *)
func runInferenceConcurrently() async {
    let actor = LLMInferenceActor(inputFeatures: 768, outputFeatures: 128)

    Task {
        await actor.loadModel()
    }

    // Multiple inference requests can be sent concurrently,
    // the actor will handle them in its isolated context.
    Task {
        let input = MLXArray.random(shape: [1, 768])
        do {
            let output = try await actor.performInference(input: input)
            print("Inference 1 result shape: \(output.shape)")
        } catch {
            print("Inference 1 failed: \(error)")
        }
    }

    Task {
        let input = MLXArray.random(shape: [1, 768])
        do {
            let output = try await actor.performInference(input: input)
            print("Inference 2 result shape: \(output.shape)")
        } catch {
            print("Inference 2 failed: \(error)")
        }
    }
}
