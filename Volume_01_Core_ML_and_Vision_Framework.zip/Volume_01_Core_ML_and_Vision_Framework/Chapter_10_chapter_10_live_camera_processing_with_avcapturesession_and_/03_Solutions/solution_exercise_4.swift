
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import AVFoundation
import Vision
import AudioToolbox // For SystemSoundID
// For more robust audio, AVAudioPlayer could be used, but SystemSoundID is simpler for a beep.

class SignRecognitionViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var overlayLayer: CALayer! // Layer for text detection overlays
    private var alertBorderLayer: CALayer! // Layer for visual alert

    private var lastStopSignAlertTime: Date?
    private let alertCooldown: TimeInterval = 5.0 // 5 seconds cooldown

    // System sound ID for a simple beep (replace with your own sound if needed)
    private var alertSoundID: SystemSoundID = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupVisionOverlay()
        setupAlertLayers()
        loadAlertSound()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        videoPreviewLayer?.frame = view.bounds
        overlayLayer?.frame = view.bounds
        alertBorderLayer?.frame = view.bounds
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            DispatchQueue.global(qos: .userInitiated).async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get the camera device.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                print("Could not add video input to the session")
                return
            }
        } catch {
            print("Could not create video device input: \(error)")
            return
        }

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue", qos: .userInitiated))
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output to the session")
            return
        }

        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }

        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.frame = view.bounds
        view.layer.addSublayer(videoPreviewLayer)
    }

    private func setupVisionOverlay() {
        overlayLayer = CALayer()
        overlayLayer.frame = view.bounds
        videoPreviewLayer.addSublayer(overlayLayer)
    }

    private func setupAlertLayers() {
        alertBorderLayer = CALayer()
        alertBorderLayer.frame = view.bounds
        alertBorderLayer.borderColor = UIColor.clear.cgColor // Initially clear
        alertBorderLayer.borderWidth = 10.0
        alertBorderLayer.opacity = 0.0 // Initially hidden
        view.layer.addSublayer(alertBorderLayer)
    }
    
    private func loadAlertSound() {
        // You'll need a 'beep.mp3' or 'beep.wav' file in your project bundle
        if let soundURL = Bundle.main.url(forResource: "beep", withExtension: "mp3") {
            AudioServicesCreateSystemSoundID(soundURL as CFURL, &alertSoundID)
        } else {
            print("Could not find 'beep.mp3' in bundle.")
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let textRecognitionRequest = VNRecognizeTextRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                print("Text recognition error: \(error.localizedDescription)")
                return
            }
            self.processTextObservations(for: request.results as? [VNTextObservation])
        }

        textRecognitionRequest.recognitionLevel = .fast // .accurate for higher quality
        textRecognitionRequest.usesLanguageCorrection = true // Helps with accuracy
        textRecognitionRequest.customWords = ["STOP", "YIELD", "SPEED", "LIMIT"] // Help Vision recognize these words

        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        do {
            try imageRequestHandler.perform([textRecognitionRequest])
        } catch {
            print("Failed to perform text recognition request: \(error)")
        }
    }

    private func processTextObservations(for observations: [VNTextObservation]?) {
        DispatchQueue.main.async {
            self.overlayLayer.sublayers?.forEach { $0.removeFromSuperlayer() } // Clear previous overlays
            var stopSignDetected = false

            guard let observations = observations else { return }

            for observation in observations {
                // Get the top candidate for the recognized text
                guard let topCandidate = observation.topCandidates(1).first else { continue }
                let recognizedText = topCandidate.string.uppercased()
                let confidence = topCandidate.confidence

                let targetSigns = ["STOP", "YIELD", "SPEED LIMIT"]
                var isTargetSign = false

                for sign in targetSigns {
                    if recognizedText.contains(sign) { // Simple contains check
                        isTargetSign = true
                        if sign == "STOP" && confidence > 0.8 { // High confidence for STOP alert
                            stopSignDetected = true
                        }
                        break
                    }
                }

                if isTargetSign {
                    // Convert Vision bounding box to AVCaptureVideoPreviewLayer coordinates
                    let boundingBox = observation.boundingBox
                    let convertedRect = self.videoPreviewLayer.rectForMetadataOutputRectOfInterest(boundingBox)

                    // Bounding Box Layer
                    let shapeLayer = CAShapeLayer()
                    shapeLayer.frame = convertedRect
                    shapeLayer.borderColor = UIColor.cyan.cgColor
                    shapeLayer.borderWidth = 2.0
                    shapeLayer.cornerRadius = 5.0
                    self.overlayLayer.addSublayer(shapeLayer)

                    // Text Layer
                    let text = String(format: "%@ (%.1f%%)", recognizedText, confidence * 100)
                    let textLayer = CATextLayer()
                    textLayer.string = text
                    textLayer.foregroundColor = UIColor.white.cgColor
                    textLayer.backgroundColor = UIColor.cyan.withAlphaComponent(0.6).cgColor
                    textLayer.fontSize = 12
                    textLayer.alignmentMode = .center
                    textLayer.contentsScale = UIScreen.main.scale

                    let textHeight: CGFloat = 20
                    textLayer.frame = CGRect(x: convertedRect.origin.x,
                                             y: convertedRect.origin.y - textHeight - 5,
                                             width: convertedRect.size.width,
                                             height: textHeight)
                    self.overlayLayer.addSublayer(textLayer)
                }
            }

            // Handle STOP sign alert
            if stopSignDetected {
                self.triggerStopSignAlert()
            } else {
                self.hideStopSignAlert()
            }
        }
    }

    private func triggerStopSignAlert() {
        let now = Date()
        if let lastAlert = lastStopSignAlertTime, now.timeIntervalSince(lastAlert) < alertCooldown {
            return // Still in cooldown period
        }

        // Visual alert: Red flashing border
        self.alertBorderLayer.borderColor = UIColor.red.cgColor
        self.alertBorderLayer.opacity = 1.0

        let animation = CABasicAnimation(keyPath: "opacity")
        animation.fromValue = 1.0
        animation.toValue = 0.2
        animation.duration = 0.5
        animation.autoreverses = true
        animation.repeatCount = .infinity
        self.alertBorderLayer.add(animation, forKey: "flashAnimation")

        // Audible alert: Beep sound
        if alertSoundID != 0 {
            AudioServicesPlaySystemSound(alertSoundID)
        }

        self.lastStopSignAlertTime = now // Reset cooldown timer
    }

    private func hideStopSignAlert() {
        self.alertBorderLayer.removeAnimation(forKey: "flashAnimation")
        self.alertBorderLayer.opacity = 0.0
        self.alertBorderLayer.borderColor = UIColor.clear.cgColor
    }
}
