
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import UIKit // For UIImage
import Vision // For VNImageRequestHandler, VNRequest, VNCoreMLRequest, VNCoreMLModel, VNClassificationObservation
import CoreML // For MLModel, MLModelConfiguration

/// Custom error types for the ImageClassifier.
enum ImageClassifierError: Error, LocalizedError {
    case modelNotFound
    case invalidImage
    case classificationFailed(Error)
    case noObservations

    var errorDescription: String? {
        switch self {
        case .modelNotFound:
            return "Core ML model 'MobileNetV2.mlmodelc' not found in the app bundle. Ensure it's added to the project and compiled."
        case .invalidImage:
            return "Could not convert UIImage to CGImage for Vision processing."
        case .classificationFailed(let underlyingError):
            return "Image classification failed: \(underlyingError.localizedDescription)"
        case .noObservations:
            return "No classification observations were returned by the Vision request."
        }
    }
}

/// A simple class demonstrating how to use VNImageRequestHandler and VNCoreMLRequest
/// to classify an image using a Core ML model. This mimics a core component
/// of an image analysis feature within an iOS app (e.g., a photo viewer, a camera app).
@available(iOS 17.0, *) // Using modern concurrency features, suitable for latest SDK
class ImageClassifier {

    /// The Core ML model wrapped for Vision framework use.
    /// This is a lightweight wrapper that makes the raw MLModel compatible with Vision requests.
    private var coreMLModel: VNCoreMLModel

    /// The Vision request specifically for Core ML models.
    /// This request tells Vision to run the wrapped Core ML model.
    private var classificationRequest: VNCoreMLRequest

    /// A closure to handle the classification results, typically for UI updates.
    /// It receives an array of classification observations and an optional error.
    var completionHandler: (([VNClassificationObservation]?, Error?) -> Void)?

    /// Initializes the ImageClassifier with a Core ML model.
    /// - Throws: An `ImageClassifierError` if the Core ML model cannot be loaded or wrapped.
    init() throws {
        // 1. Load the Core ML model.
        // This assumes 'MobileNetV2' is the name of your .mlmodel file in the bundle.
        // Xcode automatically compiles .mlmodel files into .mlmodelc directories.
        // We look for the compiled version.
        guard let modelURL = Bundle.main.url(forResource: "MobileNetV2", withExtension: "mlmodelc") else {
            throw ImageClassifierError.modelNotFound
        }

        // MLModelConfiguration allows specifying compute units (e.g., CPU, GPU, Neural Engine).
        // For this basic example, we use default settings.
        let configuration = MLModelConfiguration()
        let mlModel = try MLModel(contentsOf: modelURL, configuration: configuration)
        
        // 2. Wrap the MLModel for Vision framework.
        // VNCoreMLModel adapts the generic MLModel for use with Vision's request system.
        self.coreMLModel = try VNCoreMLModel(for: mlModel)

        // 3. Create the VNCoreMLRequest.
        // This request uses the wrapped Core ML model and specifies a completion handler.
        // The completion handler is called by Vision once the request processing is done.
        self.classificationRequest = VNCoreMLRequest(model: coreMLModel) { [weak self] request, error in
            // Using [weak self] to prevent strong reference cycles, especially if the classifier
            // instance has a longer lifetime than the request.
            self?.handleClassification(request: request, error: error)
        }

        // Optional: Configure the request for better performance or specific behavior.
        // .centerCrop is a common option for image classification models, ensuring the
        // input image is cropped to the model's expected aspect ratio and size.
        self.classificationRequest.imageCropAndScaleOption = .centerCrop
        
        // Optional: Set a confidence threshold to filter out low-confidence results
        // self.classificationRequest.confidenceObjectMinimum = 0.5
    }

    /// Performs image classification on the given `UIImage`.
    /// This method is asynchronous to allow for background processing.
    /// - Parameter image: The `UIImage` to classify.
    /// - Throws: An `ImageClassifierError` if the image cannot be converted to `CGImage`
    ///           or if the Vision request fails.
    func classifyImage(image: UIImage) async throws {
        // 4. Prepare Image Data: Convert UIImage to CGImage.
        // Vision typically works with CGImage, CIImage, or raw image data.
        guard let cgImage = image.cgImage else {
            throw ImageClassifierError.invalidImage
        }

        // 5. Create a VNImageRequestHandler.
        // This handler takes the image data (CGImage in this case) and is responsible
        // for executing one or more Vision requests on it.
        // The options dictionary can be used to provide additional context,
        // such as image orientation, which is crucial for correct analysis.
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        // 6. Perform the Vision request(s).
        // The handler executes the request(s) on a background thread managed by Vision.
        // In this example, we only have one request (classificationRequest).
        do {
            try handler.perform([classificationRequest])
        } catch {
            print("Failed to perform classification: \(error.localizedDescription)")
            // Re-throw the error wrapped in our custom error type for better context.
            throw ImageClassifierError.classificationFailed(error)
        }
    }

    /// Handles the completion of the classification request.
    /// This method is called by the Vision framework once the request is processed.
    /// - Parameters:
    ///   - request: The `VNRequest` that just completed.
    ///   - error: An optional `Error` if the request failed.
    private func handleClassification(request: VNRequest, error: Error?) {
        // 8. UI Updates on Main Actor: Ensure that UI updates happen on the main thread.
        // The Vision completion handler is often called on a background thread.
        Task { @MainActor in
            if let error = error {
                print("Classification failed with error: \(error.localizedDescription)")
                self.completionHandler?(nil, ImageClassifierError.classificationFailed(error))
                return
            }

            // 7. Handle Results: Extract and process the observations.
            // Check if the results are of the expected type ([VNClassificationObservation]).
            guard let observations = request.results as? [VNClassificationObservation] else {
                print("No classification observations found or incorrect type.")
                self.completionHandler?(nil, ImageClassifierError.noObservations)
                return
            }

            // Sort observations by confidence in descending order and get the top 5.
            let topClassifications = observations.sorted(by: { $0.confidence > $1.confidence }).prefix(5)

            // Print the top classifications to the console.
            print("Top Classifications:")
            for classification in topClassifications {
                print("  \(classification.identifier) - \(String(format: "%.2f", classification.confidence * 100))%")
            }

            // Pass the results to the external completion handler for display in UI.
            self.completionHandler?(Array(topClassifications), nil)
        }
    }
}

// MARK: - Example Usage in an iOS App Context

/// A simple `UIViewController` to demonstrate the `ImageClassifier`.
/// In a real application, this might be part of a camera view or photo picker,
/// providing real-time or on-demand image analysis.
@available(iOS 17.0, *)
class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private var classifier: ImageClassifier?
    private let imageView = UIImageView()
    private let resultLabel = UILabel()
    private let classifyButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        setupUI()
        setupClassifier()
    }

    /// Sets up the user interface elements for displaying the image and classification results.
    private func setupUI() {
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .lightGray
        imageView.layer.borderColor = UIColor.systemGray.cgColor
        imageView.layer.borderWidth = 1.0
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        resultLabel.textAlignment = .center
        resultLabel.numberOfLines = 0
        resultLabel.font = UIFont.systemFont(ofSize: 16)
        resultLabel.textColor = .label
        resultLabel.text = "Select an image to classify."
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultLabel)

        classifyButton.setTitle("Select Image & Classify", for: .normal)
        classifyButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        classifyButton.addTarget(self, action: #selector(selectImageAndClassify), for: .touchUpInside)
        classifyButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(classifyButton)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),

            resultLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 30),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            classifyButton.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 30),
            classifyButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            classifyButton.heightAnchor.constraint(equalToConstant: 50),
            classifyButton.widthAnchor.constraint(equalToConstant: 250)
        ])
    }

    /// Initializes the `ImageClassifier` instance. This is done once when the view loads.
    private func setupClassifier() {
        do {
            classifier = try ImageClassifier()
            // Set the completion handler for the classifier.
            // This closure will be called when classification results are ready,
            // allowing the UI to be updated.
            classifier?.completionHandler = { [weak self] observations, error in
                guard let self = self else { return }

                if let error = error {
                    self.resultLabel.text = "Error: \(error.localizedDescription)"
                    print("Classifier completion handler received error: \(error)")
                    return
                }

                if let observations = observations, !observations.isEmpty {
                    let resultText = observations.map {
                        "\($0.identifier) (\(String(format: "%.2f", $0.confidence * 100))%)"
                    }.joined(separator: "\n")
                    self.resultLabel.text = "Top Classifications:\n\(resultText)"
                } else {
                    self.resultLabel.text = "No classifications found."
                }
            }
        } catch {
            resultLabel.text = "Failed to initialize classifier: \(error.localizedDescription)"
            print("Error initializing ImageClassifier: \(error.localizedDescription)")
        }
    }

    /// Presents an image picker to allow the user to select an image from their photo library.
    @objc private func selectImageAndClassify() {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            print("Photo library not available on this device.")
            let alert = UIAlertController(title: "Error", message: "Photo library not available.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            return
        }

        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }

    // MARK: - UIImagePickerControllerDelegate

    /// Called when the user has selected an image from the photo library.
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) { [weak self] in
            guard let self = self,
                  let selectedImage = info[.originalImage] as? UIImage else { return }

            self.imageView.image = selectedImage
            self.resultLabel.text = "Classifying image..."

            // Perform classification asynchronously using Swift's new concurrency features.
            Task {
                do {
                    // The classifier's completion handler will update the UI.
                    try await self.classifier?.classifyImage(image: selectedImage)
                } catch {
                    // This catch block handles errors thrown by `classifyImage` itself
                    // (e.g., invalid image), separate from errors reported via the completion handler.
                    print("Error during image classification: \(error.localizedDescription)")
                    self.resultLabel.text = "Classification failed: \(error.localizedDescription)"
                }
            }
        }
    }

    /// Called when the user cancels the image picker.
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
