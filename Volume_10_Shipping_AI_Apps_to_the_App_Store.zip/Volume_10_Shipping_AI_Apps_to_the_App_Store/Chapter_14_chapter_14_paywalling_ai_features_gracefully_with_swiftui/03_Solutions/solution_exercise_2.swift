
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
@Observable
class UsageManager {
    var currentTokens: Int = 4
    var maxTokens: Int = 50
    
    var progress: Double {
        Double(currentTokens) / Double(maxTokens)
    }
    
    var percentage: Double {
        progress * 100
    }
}

@available(iOS 18.0, *)
struct TokenGaugeView: View {
    var usage: UsageManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("High-Reasoning Tokens")
                    .font(.subheadline.bold())
                Spacer()
                Text("\(usage.currentTokens) / \(usage.maxTokens)")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            
            // 1. Use a Gauge view to show usage
            Gauge(value: usage.progress, in: 0...1) {
                Text("Tokens")
            } currentValueLabel: {
                Text("\(Int(usage.percentage))%")
            }
            // 2. Change color based on threshold
            .gaugeStyle(.accessoryCircular)
            .foregroundStyle(gaugeColor)
            // 3. Add PhaseAnimator for the heartbeat pulse when low
            .phaseAnimator([0.8, 1.0, 0.8], trigger: usage.progress < 0.1) { content, phase in
                content
                    .scaleEffect(phase)
                    .opacity(usage.progress < 0.1 ? 0.7 : 1.0)
            } animation: { _ in
                .easeInOut(duration: 0.6)
            }
        }
        .padding()
        .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
    }
    
    private var gaugeColor: Color {
        if usage.progress > 0.2 { return .green }
        if usage.progress > 0.1 { return .yellow }
        return .red
    }
}

@available(iOS 18.0, *)
struct TokenGaugeView_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 40) {
            // Healthy state
            TokenGaugeView(usage: UsageManager())
            
            // Warning state
            let lowUsage = UsageManager()
            lowUsage.currentTokens = 3
            TokenGaugeView(usage: lowUsage)
        }
    }
}
