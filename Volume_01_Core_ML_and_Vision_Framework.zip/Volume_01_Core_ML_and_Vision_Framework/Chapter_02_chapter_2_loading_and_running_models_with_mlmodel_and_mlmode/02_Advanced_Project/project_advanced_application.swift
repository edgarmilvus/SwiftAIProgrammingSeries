
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import CoreML
import Vision // For CVPixelBuffer and image processing helpers
import UIKit // For UIImage
import CoreGraphics // For image context
import ImageIO // For CGImageDestination

// MARK: - 1. Custom Errors for Robust Handling

/// Custom errors specific to the DocumentClassifier operations.
enum DocumentClassifierError: Error, LocalizedError {
    case modelLoadingFailed(Error)
    case modelNotLoaded
    case invalidModelInput(String)
    case predictionFailed(Error)
    case invalidModelOutput(String)
    case imageConversionFailed
    case missingInputFeature(String)
    case missingOutputFeature(String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error):
            return "Failed to load Core ML model: \(error.localizedDescription)"
        case .modelNotLoaded:
            return "Core ML model is not loaded. Call loadModel() first."
        case .invalidModelInput(let message):
            return "Invalid model input: \(message)"
        case .predictionFailed(let error):
            return "Core ML prediction failed: \(error.localizedDescription)"
        case .invalidModelOutput(let message):
            return "Invalid model output format: \(message)"
        case .imageConversionFailed:
            return "Failed to convert UIImage to CVPixelBuffer."
        case .missingInputFeature(let name):
            return "Model input feature '\(name)' is missing or has an unexpected type."
        case .missingOutputFeature(let name):
            return "Model output feature '\(name)' is missing or has an unexpected type."
        }
    }
}

// MARK: - 2. Compute Unit Preference Enum

/// Defines user-selectable preferences for Core ML compute units.
/// This directly maps to `MLComputeUnits` for dynamic configuration.
enum ComputeUnitPreference: String, CaseIterable, Identifiable {
    case all = "All (GPU/ANE/CPU)"
    case cpuOnly = "CPU Only"
    case neuralEngine = "Neural Engine Only" // Requires device with Apple Neural Engine

    var id: String { self.rawValue }

    /// Converts the preference to the corresponding `MLComputeUnits` value.
    var mlComputeUnits: MLComputeUnits {
        switch self {
        case .all: return .all
        case .cpuOnly: return .cpuOnly
        case .neuralEngine: return .neuralEngine
        }
    }
}

// MARK: - 3. Classification Result Structure

/// Represents the result of a document classification, including label, confidence, and inference time.
struct ClassificationResult: Identifiable, Equatable {
    let id = UUID()
    let label: String
    let confidence: Double
    let inferenceTime: TimeInterval // Time in seconds for the prediction
}

// MARK: - 4. UIImage Extension for CVPixelBuffer Conversion

/// Extension to `UIImage` to facilitate conversion to `CVPixelBuffer`,
/// a common input format for Core ML image models.
extension UIImage {
    /// Converts a `UIImage` to a `CVPixelBuffer` of a specified size and pixel format.
    /// - Parameters:
    ///   - size: The target size (width, height) for the pixel buffer.
    ///   - pixelFormatType: The desired pixel format (e.g., `kCVPixelFormatType_32BGRA`).
    /// - Returns: An optional `CVPixelBuffer` if the conversion is successful, otherwise `nil`.
    func toCVPixelBuffer(size: CGSize, pixelFormatType: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        // Ensure the image has a valid CGImage
        guard let cgImage = self.cgImage else { return nil }

        // Define pixel buffer attributes
        let attributes: [NSObject: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferMetalCompatibilityKey: kCFBooleanTrue!, // Good for GPU/ANE usage
            kCVPixelBufferIOSurfacePropertiesKey: [:] // Enable iOSurface for efficiency
        ]

        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            Int(size.width),
            Int(size.height),
            pixelFormatType,
            attributes as CFDictionary,
            &pixelBuffer
        )

        guard status == kCVReturnSuccess, let unwrappedPixelBuffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(unwrappedPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(unwrappedPixelBuffer)

        // Create a Core Graphics bitmap context to draw the image into the pixel buffer
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(
            data: pixelData,
            width: Int(size.width),
            height: Int(size.height),
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(unwrappedPixelBuffer),
            space: rgbColorSpace,
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        ) else {
            CVPixelBufferUnlockBaseAddress(unwrappedPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        // Flip the image vertically, as Core Graphics draws from bottom-left
        context.translateBy(x: 0, y: size.height)
        context.scaleBy(x: 1.0, y: -1.0)

        // Draw the image into the context, scaling it to the target size
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: size.width, height: size.height))

        CVPixelBufferUnlockBaseAddress(unwrappedPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))

        return unwrappedPixelBuffer
    }
}


// MARK: - 5. DocumentClassifier Class

/// `DocumentClassifier` manages loading, configuring, and running a Core ML document classification model.
/// It demonstrates advanced configuration of compute units for individual predictions and robust error handling.
@available(iOS 18.0, *) // Using iOS 18.0 for modern async/await context and potential future Core ML features.
class DocumentClassifier {
    private var model: MLModel?
    private let modelURL: URL
    private let initialConfiguration: MLModelConfiguration

    // MARK: - Initialization

    /// Initializes the classifier with the model's URL and an initial configuration.
    /// - Parameters:
    ///   - modelURL: The URL to the compiled Core ML model (.mlmodelc directory).
    ///   - initialConfiguration: The base configuration for the model.
    ///     Note: `computeUnits` in this configuration can be overridden by `MLPredictionOptions`
    ///     during individual predictions.
    init(modelURL: URL, initialConfiguration: MLModelConfiguration) {
        self.modelURL = modelURL
        self.initialConfiguration = initialConfiguration
    }

    // MARK: - Model Loading

    /// Asynchronously loads the Core ML model from the provided URL.
    /// This method should be called once before attempting any predictions.
    /// - Throws: `DocumentClassifierError.modelLoadingFailed` if the model cannot be loaded.
    func loadModel() async throws {
        // Core ML model loading can be a blocking operation, so we perform it in a background task.
        do {
            // MLModel(contentsOf:configuration:) is the preferred way to load a compiled model.
            // The configuration sets default parameters, but computeUnits can be overridden per prediction.
            self.model = try await MLModel.load(contentsOf: modelURL, configuration: initialConfiguration)
            print("Successfully loaded Core ML model from \(modelURL.lastPathComponent)")
        } catch {
            // Catch any errors during model loading and wrap them in our custom error type.
            throw DocumentClassifierError.modelLoadingFailed(error)
        }
    }

    // MARK: - Model Inference

    /// Performs document classification on the given image using the specified compute units.
    /// This method demonstrates how to dynamically set `computeUnits` for a single prediction
    /// using `MLPredictionOptions`.
    /// - Parameters:
    ///   - image: The `UIImage` to classify.
    ///   - preferredComputeUnits: The compute units to use for this specific inference.
    ///     This value will override the `computeUnits` set in the `initialConfiguration` for this prediction.
    ///   - targetImageSize: The expected input size for the Core ML model (e.g., 224x224).
    ///   - inputFeatureName: The name of the input feature in the Core ML model (e.g., "image").
    ///   - outputLabelFeatureName: The name of the output feature containing the predicted label (e.g., "classLabel").
    ///   - outputProbabilityFeatureName: The name of the output feature containing class probabilities (e.g., "classLabelProbs").
    /// - Returns: A `ClassificationResult` containing the detected label, confidence, and inference time.
    /// - Throws: `DocumentClassifierError` if the model is not loaded, image conversion fails, or prediction fails.
    func classifyImage(_ image: UIImage,
                       preferredComputeUnits: ComputeUnitPreference,
                       targetImageSize: CGSize,
                       inputFeatureName: String = "image", // Common input name for image models
                       outputLabelFeatureName: String = "classLabel",
                       outputProbabilityFeatureName: String = "classLabelProbs") async throws -> ClassificationResult {

        // Ensure the model is loaded before attempting a prediction.
        guard let model = self.model else {
            throw DocumentClassifierError.modelNotLoaded
        }

        // 1. Image Preprocessing: Convert UIImage to CVPixelBuffer.
        // This is a common step as Core ML image models typically expect CVPixelBuffer.
        guard let pixelBuffer = image.toCVPixelBuffer(size: targetImageSize) else {
            throw DocumentClassifierError.imageConversionFailed
        }

        // 2. Prepare Input: Create an MLFeatureProvider from the CVPixelBuffer.
        // The input feature name must match what the model expects.
        let inputFeatures = try createInputFeatureProvider(from: pixelBuffer, inputName: inputFeatureName)

        // 3. Configure Prediction Options: Dynamically set compute units for this prediction.
        // This is the "advanced" part, allowing runtime control over hardware usage.
        let predictionOptions = MLPredictionOptions()
        predictionOptions.computeUnits = preferredComputeUnits.mlComputeUnits

        // Start timing for performance measurement.
        let startTime = CFAbsoluteTimeGetCurrent()

        // 4. Perform Inference: Execute the prediction.
        let outputFeatures: MLFeatureProvider
        do {
            outputFeatures = try await model.prediction(from: inputFeatures, options: predictionOptions)
        } catch {
            throw DocumentClassifierError.predictionFailed(error)
        }

        // End timing.
        let endTime = CFAbsoluteTimeGetCurrent()
        let inferenceTime = endTime - startTime

        // 5. Parse Output: Extract the label and confidence from the MLFeatureProvider.
        let (label, confidence) = try parseOutput(from: outputFeatures,
                                                  outputLabelFeatureName: outputLabelFeatureName,
                                                  outputProbabilityFeatureName: outputProbabilityFeatureName)

        // Return the classification result.
        return ClassificationResult(label: label, confidence: confidence, inferenceTime: inferenceTime)
    }

    // MARK: - Private Helpers

    /// Creates an `MLFeatureProvider` from a `CVPixelBuffer` for model input.
    /// - Parameters:
    ///   - pixelBuffer: The `CVPixelBuffer` containing the image data.
    ///   - inputName: The expected name of the image input feature in the Core ML model.
    /// - Returns: An `MLFeatureProvider` containing the image input.
    /// - Throws: `DocumentClassifierError.missingInputFeature` if the input feature cannot be created.
    private func createInputFeatureProvider(from pixelBuffer: CVPixelBuffer, inputName: String) throws -> MLFeatureProvider {
        // MLFeatureValue(pixelBuffer:) is used for image inputs.
        guard let imageFeature = MLFeatureValue(pixelBuffer: pixelBuffer) else {
            throw DocumentClassifierError.missingInputFeature("Could not create MLFeatureValue from CVPixelBuffer for input '\(inputName)'.")
        }
        // MLFeatureProvider is a dictionary-like interface for model inputs/outputs.
        return MLDictionaryFeatureProvider(dictionary: [inputName: imageFeature])
    }

    /// Parses the `MLFeatureProvider` output from the model to extract the classification label and confidence.
    /// - Parameters:
    ///   - output: The `MLFeatureProvider` containing the model's prediction output.
    ///   - outputLabelFeatureName: The name of the output feature containing the predicted label.
    ///   - outputProbabilityFeatureName: The name of the output feature containing class probabilities.
    /// - Returns: A tuple containing the predicted label (String) and its confidence (Double).
    /// - Throws: `DocumentClassifierError.invalidModelOutput` or `DocumentClassifierError.missingOutputFeature`
    ///           if the output format is unexpected.
    private func parseOutput(from output: MLFeatureProvider,
                             outputLabelFeatureName: String,
                             outputProbabilityFeatureName: String) throws -> (label: String, confidence: Double) {

        // Retrieve the predicted label.
        guard let labelFeature = output.featureValue(for: outputLabelFeatureName),
              let label = labelFeature.stringValue else {
            throw DocumentClassifierError.missingOutputFeature("Expected string output for '\(outputLabelFeatureName)'.")
        }

        // Retrieve the class probabilities.
        guard let probFeature = output.featureValue(for: outputProbabilityFeatureName),
              let probabilities = probFeature.dictionaryValue as? [String: Double] else {
            throw DocumentClassifierError.missingOutputFeature("Expected dictionary output for '\(outputProbabilityFeatureName)'.")
        }

        // Find the confidence for the predicted label.
        guard let confidence = probabilities[label] else {
            throw DocumentClassifierError.invalidModelOutput("Confidence for predicted label '\(label)' not found in probabilities.")
        }

        return (label, confidence)
    }
}

// MARK: - 6. Example Usage in a Simulated ViewController

/// A simulated `UIViewController` demonstrating how to integrate and use the `DocumentClassifier`.
/// This acts as the entry point for demonstrating the advanced Core ML features.
@available(iOS 18.0, *)
class DocumentClassificationViewController: UIViewController {
    var classifier: DocumentClassifier?
    // Assume a Core ML model named "DocumentClassifierModel.mlmodelc" is in the app bundle.
    // This model should take an image (CVPixelBuffer) and output a class label (String)
    // and class probabilities (Dictionary<String, Double>).
    let modelName = "DocumentClassifierModel"
    let targetImageSize = CGSize(width: 224, height: 224) // Example: common input size for image models

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupClassifier()
        setupUI() // Add some basic UI for demonstration
    }

    /// Sets up the `DocumentClassifier` instance and asynchronously loads the Core ML model.
    func setupClassifier() {
        // Locate the compiled Core ML model (.mlmodelc directory) in the app bundle.
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            print("🛑 Error: Core ML model '\(modelName).mlmodelc' not found in app bundle.")
            // In a real app, you might show an alert to the user or disable functionality.
            return
        }

        // Initialize MLModelConfiguration.
        // For this example, we'll use a default configuration, as we're dynamically
        // overriding `computeUnits` with `MLPredictionOptions` for each prediction.
        let initialConfig = MLModelConfiguration()
        classifier = DocumentClassifier(modelURL: modelURL, initialConfiguration: initialConfig)

        // Asynchronously load the model to avoid blocking the UI.
        Task {
            do {
                print("⏳ Loading Core ML model '\(modelName).mlmodelc'...")
                try await classifier?.loadModel()
                print("✅ Model loaded successfully.")
                // Enable UI elements that depend on the model being loaded.
            } catch {
                print("❌ Failed to load model: \(error.localizedDescription)")
                // Handle the error (e.g., show an error message, disable classification features).
            }
        }
    }

    /// Sets up basic UI elements for interaction.
    private func setupUI() {
        let classifyButton = UIButton(type: .system)
        classifyButton.setTitle("Classify Document (All Units)", for: .normal)
        classifyButton.addTarget(self, action: #selector(performClassificationAllUnits), for: .touchUpInside)
        classifyButton.frame = CGRect(x: 20, y: 100, width: view.bounds.width - 40, height: 50)
        view.addSubview(classifyButton)

        let classifyCPUButton = UIButton(type: .system)
        classifyCPUButton.setTitle("Classify Document (CPU Only)", for: .normal)
        classifyCPUButton.addTarget(self, action: #selector(performClassificationCPUOnly), for: .touchUpInside)
        classifyCPUButton.frame = CGRect(x: 20, y: 170, width: view.bounds.width - 40, height: 50)
        view.addSubview(classifyCPUButton)

        let classifyANEButton = UIButton(type: .system)
        classifyANEButton.setTitle("Classify Document (Neural Engine)", for: .normal)
        classifyANEButton.addTarget(self, action: #selector(performClassificationNeuralEngine), for: .touchUpInside)
        classifyANEButton.frame = CGRect(x: 20, y: 240, width: view.bounds.width - 40, height: 50)
        view.addSubview(classifyANEButton)
    }

    /// Action handler for classifying with `.all` compute units.
    @objc func performClassificationAllUnits() {
        performClassification(with: .all)
    }

    /// Action handler for classifying with `.cpuOnly` compute units.
    @objc func performClassificationCPUOnly() {
        performClassification(with: .cpuOnly)
    }

    /// Action handler for classifying with `.neuralEngine` compute units.
    @objc func performClassificationNeuralEngine() {
        performClassification(with: .neuralEngine)
    }

    /// Generic method to perform classification with a specified compute unit preference.
    /// - Parameter preference: The `ComputeUnitPreference` to use for this classification.
    func performClassification(with preference: ComputeUnitPreference) {
        // Simulate picking an image. In a real app, this would come from the camera or photo library.
        // For demonstration, ensure you have an image named "sample_document_image" in your Assets.xcassets.
        guard let sampleImage = UIImage(named: "sample_document_image") else {
            print("🛑 Error: Sample image 'sample_document_image' not found in assets.")
            return
        }

        Task {
            do {
                print("\n🚀 Starting classification with \(preference.rawValue)...")
                let result = try await classifier?.classifyImage(sampleImage,
                                                                preferredComputeUnits: preference,
                                                                targetImageSize: targetImageSize)
                if let result = result {
                    print("✅ Classification Result (via \(preference.rawValue)):")
                    print("   - Label: \(result.label)")
                    print("   - Confidence: \(String(format: "%.2f", result.confidence * 100))%")
                    print("   - Inference Time: \(String(format: "%.4f", result.inferenceTime)) seconds")
                }
            } catch {
                print("❌ Classification failed (via \(preference.rawValue)): \(error.localizedDescription)")
            }
        }
    }
}

/*
// To use this code:
// 1. Create a new Xcode project (e.g., iOS App with SwiftUI or UIKit).
// 2. Add a compiled Core ML model (e.g., "DocumentClassifierModel.mlmodelc") to your project bundle.
//    (You can generate a dummy .mlmodel from a .mlpackage and then compile it for testing,
//     or use a pre-trained image classification model and rename its .mlmodelc output.)
//    For example, if you have a model with input "image" (Image) and outputs "classLabel" (String)
//    and "classLabelProbs" (Dictionary<String, Double>), this code will work as-is.
// 3. Add a sample image named "sample_document_image" to your project's Assets.xcassets.
// 4. In your SceneDelegate or AppDelegate, set `DocumentClassificationViewController` as the root view controller:
//
//    class SceneDelegate: UIResponder, UIWindowSceneDelegate {
//        var window: UIWindow?
//        func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
//            guard let windowScene = (scene as? UIWindowScene) else { return }
//            let window = UIWindow(windowScene: windowScene)
//            window.rootViewController = DocumentClassificationViewController()
//            self.window = window
//            window.makeKeyAndVisible()
//        }
//    }
//
// 5. Run the app on a device (especially for Neural Engine testing) or simulator.
*/
