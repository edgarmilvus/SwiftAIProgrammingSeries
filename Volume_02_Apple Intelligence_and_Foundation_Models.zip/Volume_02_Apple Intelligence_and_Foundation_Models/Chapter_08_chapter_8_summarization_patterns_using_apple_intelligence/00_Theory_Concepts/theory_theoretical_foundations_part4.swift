
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// Example of a custom struct that is implicitly Sendable
struct SummarizationRequest: Sendable {
    let textContent: String
    let maxLength: Int?
    let minLength: Int?
}

// Example of a custom class that needs explicit Sendable consideration
// (though often better to use value types or actors for AI-related data)
final class SummarizationResult: @unchecked Sendable { // @unchecked is for demonstration, use with care!
    let generatedSummary: String
    let sourceTextIdentifier: String

    init(summary: String, identifier: String) {
        self.generatedSummary = summary
        self.sourceTextIdentifier = identifier
    }
    // If this class had mutable state, it would need internal synchronization
    // or be an actor to be truly Sendable without @unchecked.
    // For immutable classes, it's often implicitly Sendable if all its properties are Sendable.
}

@available(iOS 18.0, *)
actor SummarizerAgent {
    func processRequest(_ request: SummarizationRequest) async throws -> SummarizationResult {
        print("Processing request for: \(request.textContent.prefix(20))...")
        // Simulate LLM processing
        try await Task.sleep(for: .seconds(1.0))
        let summary = "Summary of \(request.textContent.prefix(request.maxLength ?? 50))..."
        return SummarizationResult(summary: summary, identifier: request.textContent)
    }
}

@available(iOS 18.0, *)
func demonstrateSendable() {
    let agent = SummarizerAgent()
    let request1 = SummarizationRequest(textContent: "This is a very important article about Swift concurrency and AI.", maxLength: 100, minLength: 20)
    let request2 = SummarizationRequest(textContent: "Another article discussing the benefits of on-device machine learning.", maxLength: 80, minLength: 15)

    Task {
        // request1 (a struct) is Sendable and can be passed safely
        let result1 = try await agent.processRequest(request1)
        print("Result 1: \(result1.generatedSummary)")
    }

    Task {
        // request2 (a struct) is Sendable and can be passed safely
        let result2 = try await agent.processRequest(request2)
        print("Result 2: \(result2.generatedSummary)")
    }
}
