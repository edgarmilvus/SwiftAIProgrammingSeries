
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import ARKit
import RealityKit
import SwiftUI

@MainActor
class SpatialQueryManager: ObservableObject {
    private var lastRayOrigin: SIMD3<Float>?
    private var smoothedOrigin: SIMD3<Float> = .zero
    private let smoothingFactor: Float = 0.2 // Low value = more smoothing
    
    // To store the response for the ViewAttachment
    @Published var activeResponse: String?
    @Published var responsePosition: SIMD3<Float>?

    func performQuery(handAnchor: HandAnchor, scene: Scene) {
        let indexMCP = handAnchor.handSkeleton.joint(.indexFingerMCP).anchorPose.position
        let indexTip = handAnchor.handSkeleton.joint(.indexFingerTip).anchorPose.position
        
        // 1. Calculate Ray Direction (Vector from MCP to Tip)
        let direction = simd_normalize(indexTip - indexMCP)
        
        // 2. Apply Moving Average Filter for Smoothing
        if let last = lastRayOrigin {
            smoothedOrigin = (last * (1.0 - smoothingFactor)) + (indexTip * smoothingFactor)
        } else {
            smoothedOrigin = indexTip
        }
        lastRayOrigin = smoothedOrigin
        
        // 3. Raycast into the scene
        // In visionOS, we raycast from the smoothed origin in the finger's direction
        let raycastResults = scene.raycast(from: smoothedOrigin, direction: direction)
        
        if let firstHit = raycastResults.first {
            handleHit(entity: firstHit.entity, position: firstHit.position)
        } else {
            // Reset if pointing at empty space
            activeResponse = nil
        }
    }
    
    private func handleHit(entity: Entity, position: SIMD3<Float>) {
        // Simulate VLM Context Capture
        let context = entity.components[SemanticComponent.self]?.personality ?? "an unknown object"
        
        Task {
            let response = await simulateVLMQuery(for: context)
            self.activeResponse = response
            self.responsePosition = position
        }
    }
    
    private func simulateVLMQuery(for context: String) async -> String {
        try? await Task.sleep(for: .seconds(0.5))
        return "This \(context) has a fascinating history in spatial design."
    }
}

// SwiftUI View for the Attachment
struct AIResponseView: View {
    let text: String
    
    var body: some View {
        Text(text)
            .padding()
            .glassBackgroundEffect()
            .font(.caption)
    }
}
