
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import SwiftData

@Model
final class StockQuote {
    @Attribute(.unique) var compositeKey: String // "symbol_timestamp"
    var symbol: String
    var price: Double
    var volume: Int
    var timestamp: Date
    var movingAverage: Double?
    
    init(symbol: String, price: Double, volume: Int, timestamp: Date) {
        self.symbol = symbol
        self.price = price
        self.volume = volume
        self.timestamp = timestamp
        self.compositeKey = "\(symbol)_\(timestamp.timeIntervalSince1970)"
    }
}

struct StockQuoteDTO: Decodable, Sendable {
    let symbol: String
    let price: Double
    let volume: Int
    let timestamp: Date
}

actor DataSyncActor: ModelActor {
    let modelContainer: ModelContainer
    let modelExecutor: any ModelExecutor
    
    init(container: ModelContainer) {
        self.modelContainer = container
        let context = ModelContext(container)
        self.modelExecutor = DefaultSerialModelExecutor(modelContext: context)
    }
    
    func syncBatch(jsonPayload: Data) async throws {
        let decoder = JSONDecoder()
        let dtos = try decoder.decode([StockQuoteDTO].self, from: jsonPayload)
        
        // 1. Optimization: Pre-fetch existing quotes to avoid O(n^2) lookups
        let symbols = Set(dtos.map { $0.symbol })
        let existingQuotes = try fetchExistingQuotes(for: symbols)
        
        var processedCount = 0
        var window: [Double] = [] // For moving average calculation
        
        for (index, dto) in dtos.enumerated() {
            let key = "\(dto.symbol)_\(dto.timestamp.timeIntervalSince1970)"
            
            // 2. Conflict Resolution: Upsert logic
            let quote: StockQuote
            if let existing = existingQuotes[key] {
                quote = existing
                quote.price = dto.price
                quote.volume = dto.volume
            } else {
                quote = StockQuote(symbol: dto.symbol, price: dto.price, volume: dto.volume, timestamp: dto.timestamp)
                modelContext.insert(quote)
            }
            
            // 3. Calculation: Moving Average (every 10th object)
            window.append(dto.price)
            if window.count > 10 { window.removeFirst() }
            
            if index % 10 == 0 && window.count == 10 {
                quote.movingAverage = window.reduce(0, +) / 10.0
            }
            
            processedCount += 1
            
            // 4. Chunked Save: Prevent memory bloat
            if processedCount % 500 == 0 {
                try modelContext.save()
                // Clear window/cache if necessary, though here we keep the moving average window
            }
        }
        
        try modelContext.save() // Final save for remaining items
    }
    
    private func fetchExistingQuotes(for symbols: Set<String>) throws -> [String: StockQuote] {
        // In a real app, you'd use a more complex predicate to fetch only relevant symbols
        let descriptor = FetchDescriptor<StockQuote>()
        let all = try modelContext.fetch(descriptor)
        
        // Map to dictionary for O(1) lookup during the loop
        return Dictionary(uniqueKeysWithValues: all.map { ($0.compositeKey, $0) })
    }
}
