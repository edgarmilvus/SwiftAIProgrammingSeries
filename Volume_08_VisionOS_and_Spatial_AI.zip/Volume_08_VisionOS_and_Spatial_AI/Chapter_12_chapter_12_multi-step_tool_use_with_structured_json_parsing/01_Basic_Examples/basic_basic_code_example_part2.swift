
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation

// MARK: - Models

/// Represents the arguments required to adjust a light.
/// We use Codable to ensure the LLM's JSON matches our Swift types.
struct LightSettings: Codable, Sendable {
    let room: String
    let brightness: Int // 0 to 100
}

/// Represents the arguments required to check a room's temperature.
struct TemperatureRequest: Codable, Sendable {
    let room: String
}

/// The types of tools our LLM is allowed to call.
/// Using an enum with associated values allows us to handle different 
/// tool schemas in a type-safe manner.
enum SmartHomeTool: Sendable {
    case getTemperature(TemperatureRequest)
    case setLight(LightSettings)
}

/// A container representing a tool call received from an LLM.
/// This mimics the structure of OpenAI's 'function_call' or 'tool_calls'.
struct LLMToolCall: Codable, Sendable {
    let id: String
    let functionName: String
    let arguments: Data // The raw JSON string from the LLM
}

// MARK: - Tool Executor

/// The `SmartHomeManager` is an `actor` to ensure that hardware state 
/// (simulated here) is modified in a thread-safe manner, preventing 
/// data races when multiple tool calls arrive rapidly.
@available(iOS 18.0, *)
actor SmartHomeManager {
    /// Simulated state of the home
    private var roomTemperatures: [String: Double] = ["Living Room": 22.5, "Kitchen": 24.0]
    private var lightLevels: [String: Int] = ["Living Room": 80, "Kitchen": 100]

    /// Executes a tool based on the parsed type.
    /// - Parameter tool: The strongly-typed tool to execute.
    /// - Returns: A string describing the result to be fed back to the LLM.
    func execute(_ tool: SmartHomeTool) async -> String {
        print("🛠 Executing Tool: \(tool)")
        
        switch tool {
        case .getTemperature(let request):
            let temp = roomTemperatures[request.room] ?? 0.0
            return "The temperature in the \(request.room) is \(temp)°C."
            
        case .setLight(let settings):
            lightLevels[settings.room] = settings.brightness
            return "Successfully set \(settings.room) lights to \(settings.brightness)%."
        }
    }
}

// MARK: - Orchestrator

/// The `AgentOrchestrator` manages the loop between the LLM and the Tools.
/// It uses `@Observable` to allow a SwiftUI view to react to the agent's progress.
@available(iOS 18.0, *)
@Observable
class AgentOrchestrator {
    var conversationHistory: [String] = []
    var isProcessing: Bool = false
    
    private let homeManager = SmartHomeManager()
    private let decoder = JSONDecoder()

    init() {
        // Ensure we handle snake_case if the LLM uses it (common in Python-based LLMs)
        decoder.keyDecodingStrategy = .convertFromSnakeCase
    }

    /// Simulates the multi-step reasoning loop.
    /// In a real app, this function would call an actual OpenAI API endpoint.
    func processUserPrompt(_ prompt: String) async {
        await MainActor.run {
            isProcessing = true
            conversationHistory.append("User: \(prompt)")
        }

        // STEP 1: Simulate LLM deciding to call a tool.
        // In a real scenario, this comes from the API response.
        // Let's simulate a multi-step request: 1. Get Temp, 2. Set Light.
        let simulatedToolCalls = [
            LLMToolCall(
                id: "call_001",
                functionName: "get_temperature",
                arguments: #"{"room": "Living Room"}"#.data(using: .utf8)!
            ),
            LLMToolCall(
                id: "call_002",
                functionName: "set_light",
                arguments: #"{"room": "Living Room", "brightness": 40}"#.data(using: .utf8)!
            )
        ]

        // STEP 2: The Loop
        for toolCall in simulatedToolCalls {
            let result = await handleToolCall(toolCall)
            await MainActor.run {
                conversationHistory.append("System (Tool Result): \(result)")
            }
        }

        // STEP 3: Final response simulation
        await MainActor.run {
            conversationHistory.append("Assistant: I've checked the temperature and dimmed the living room lights for you.")
            isProcessing = false
        }
    }

    /// The core logic of parsing JSON and mapping it to Swift types.
    private func handleToolCall(_ call: LLMToolCall) async -> String {
        do {
            // Map the string function name to our Swift Enum
            let tool: SmartHomeTool
            
            switch call.functionName {
            case "get_temperature":
                let args = try decoder.decode(TemperatureRequest.self, from: call.arguments)
                tool = .getTemperature(args)
                
            case "set_light":
                let args = try decoder.decode(LightSettings.self, from: call.arguments)
                tool = .setLight(args)
                
            default:
                return "Error: Unknown tool \(call.functionName)"
            }

            // Execute the tool via the Actor
            return await homeManager.execute(tool)
            
        } catch {
            return "Error parsing tool arguments: \(error.localizedDescription)"
        }
    }
}
