
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CreateML
import CoreML
import Foundation

@available(macOS 15.0, *)
func createAndExportModel() async throws {
    print("Starting model training and export...")

    // 1. Generate a simple synthetic dataset
    let data = try MLDataTable(dictionary: [
        "feature1": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0],
        "feature2": [10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0],
        "target":   [11.0, 11.0, 11.0, 11.0, 11.0, 11.0, 11.0, 11.0, 11.0, 11.0] // Simple linear relationship: target = feature1 + feature2
    ])

    print("Dataset created with \(data.rows.count) rows.")

    // 2. Programmatically Train a Tabular Regression Model
    // MLRegressorBuilder can infer the model type, or you can specify it.
    // For simplicity, we'll let it choose a default regressor.
    let regressor = try MLRegressorBuilder(trainingData: data, targetColumn: "target") { builder in
        // Optional: Configure training parameters
        builder.maxIterations = 100
        builder.validationData = data // Use training data for validation in this simple example
        print("Regressor builder configured. Training...")
    }

    print("Model training complete.")

    // 3. Export with Custom Metadata
    let dateFormatter = ISO8601DateFormatter()
    dateFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    let trainingDate = dateFormatter.string(from: Date())

    let metadata = MLModelMetadata(
        author: "ML Engineering Team",
        license: "MIT License",
        shortDescription: "Tabular regression model predicting 'target' from 'feature1' and 'feature2'. Trained on synthetic data.",
        versionString: "1.0.0-alpha.1", // Semantic versioning
        userDefined: [
            "projectID": "MLP-001",
            "trainingDate": trainingDate,
            "gitCommit": "abcdef123",
            "modelType": "LinearRegressor", // Custom info
            "trainingFramework": "CreateML Swift"
        ]
    )

    // Define output URL. Using NSTemporaryDirectory for ease of testing.
    // In a real pipeline, this would be a specific deployment directory.
    let outputURL = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("MySyntheticRegressor")
        .appendingPathExtension("mlpackage")

    print("Exporting model to: \(outputURL.path)")
    try regressor.write(to: outputURL, metadata: metadata)
    print("Model exported successfully.")

    // 4. Verify Exported Package (programmatically)
    print("\nVerifying exported model metadata...")
    let loadedModel = try MLModel(contentsOf: outputURL, configuration: MLModelConfiguration())

    print("Model Name: \(loadedModel.modelDescription.metadata[MLModelMetadataKey.modelName] as? String ?? "N/A")")
    print("Version: \(loadedModel.modelDescription.metadata[MLModelMetadataKey.versionString] as? String ?? "N/A")")
    print("Author: \(loadedModel.modelDescription.metadata[MLModelMetadataKey.author] as? String ?? "N/A")")
    print("License: \(loadedModel.modelDescription.metadata[MLModelMetadataKey.license] as? String ?? "N/A")")
    print("Short Description: \(loadedModel.modelDescription.metadata[MLModelMetadataKey.shortDescription] as? String ?? "N/A")")

    if let userDefinedMetadata = loadedModel.modelDescription.metadata[MLModelMetadataKey.userDefined] as? [String: String] {
        print("User Defined Metadata:")
        for (key, value) in userDefinedMetadata {
            print("  - \(key): \(value)")
        }
    } else {
        print("No user defined metadata found.")
    }
    print("Verification complete.")
}

// MARK: - Main execution for a macOS command-line tool or Playgrounds
@available(macOS 15.0, *)
@main
struct ModelExporter {
    static func main() async {
        do {
            try await createAndExportModel()
        } catch {
            print("An error occurred: \(error.localizedDescription)")
            // For Create ML errors, sometimes a more detailed description is available
            if let mlError = error as? MLCoreMLError {
                print("Create ML Error Code: \(mlError.errorCode)")
                print("Create ML Error Domain: \(mlError.errorDomain)")
            }
        }
    }
}
