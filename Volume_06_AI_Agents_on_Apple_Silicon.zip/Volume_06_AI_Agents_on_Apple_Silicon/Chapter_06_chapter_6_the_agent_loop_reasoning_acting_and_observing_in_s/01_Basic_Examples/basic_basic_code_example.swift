
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// Package.swift Snippet (Illustrative - not strictly needed for this basic example)
// If you were to integrate real LLM bindings like llama.cpp, your Package.swift
// would include dependencies. For this example, we're using standard Foundation/SwiftUI.

/*
import PackageDescription

let package = Package(
    name: "AgentLoopExample",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 for latest async/await features, though many work on earlier.
        .macOS(.v15) // Targeting macOS 15 for consistency.
    ],
    products: [
        .library(
            name: "AgentLoopExample",
            targets: ["AgentLoopExample"]),
    ],
    dependencies: [
        // Example of a real LLM binding dependency:
        // .package(url: "https://github.com/ggerganov/llama.cpp", from: "0.1.0"),
        // .package(url: "https://github.com/your-org/swift-ollama-bindings", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "AgentLoopExample",
            dependencies: [
                // "llama.cpp" // If using Swift bindings directly, you'd list it here.
            ]),
        .testTarget(
            name: "AgentLoopExampleTests",
            dependencies: ["AgentLoopExample"]),
    ]
)
*/

import Foundation
import SwiftUI
import Combine

// Annotate for modern OS versions to ensure latest async/await and SwiftUI features.
@available(iOS 18.0, macOS 15.0, *)
/// Represents a single message in the chat interface.
struct AgentMessage: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool // True for user messages, false for agent messages
}

/// A protocol defining the interface for an LLM that can predict actions.
///
/// This abstraction is crucial. In a real application, this protocol would be
/// conformed to by classes that interface with:
/// - Ollama (for local LLMs)
/// - Swift bindings to `llama.cpp` (for local LLM inference)
/// - Cloud-based LLM APIs (e.g., OpenAI, Anthropic, Google Gemini).
///
/// The agent doesn't need to know *how* the action is predicted, only that it *can* be.
protocol AgentLLMProtocol {
    /// Simulates predicting an `AgentAction` based on the agent's current understanding
    /// or the user's query.
    ///
    /// - Parameter context: The current context or user query string provided to the LLM.
    /// - Returns: An `AgentAction` that the LLM suggests the agent should take.
    /// - Throws: An error if the LLM fails to predict an action.
    func predictAction(from context: String) async throws -> AgentAction
}

/// Represents the possible actions an AI agent can take.
///
/// Using an `enum` with associated values provides a type-safe and clear way
/// to define the agent's capabilities and the parameters for each action.
enum AgentAction: CustomStringConvertible, Equatable {
    case tellTime
    case searchWeb(query: String)
    case respond(message: String) // Directly respond to the user
    case unknown(reason: String)   // Agent could not determine a specific action
    case doNothing                 // Agent decides no specific action is needed

    /// Provides a human-readable description of the action.
    var description: String {
        switch self {
        case .tellTime: return "Telling the current time."
        case .searchWeb(let query): return "Searching the web for: '\(query)'."
        case .respond(let message): return "Responding with: '\(message)'."
        case .unknown(let reason): return "Could not determine action: \(reason)."
        case .doNothing: return "No specific action required."
        }
    }
}

/// Represents observations or results obtained after an action is performed.
///
/// These observations are critical feedback for the agent, allowing it to update its
/// internal state and inform subsequent reasoning steps.
enum AgentObservation: CustomStringConvertible {
    case time(String)
    case searchResult(String)
    case acknowledgement(String) // General acknowledgement for a direct response
    case error(String)           // An error occurred during action execution
    case noObservation           // Action was performed but yielded no specific observation

    /// Provides a human-readable description of the observation.
    var description: String {
        switch self {
        case .time(let timeString): return "Observed time: \(timeString)"
        case .searchResult(let result): return "Observed search result: \(result)"
        case .acknowledgement(let ack): return "Acknowledged: \(ack)"
        case .error(let err): return "Error: \(err)"
        case .noObservation: return "No specific observation."
        }
    }
}

/// Represents the current state of the agent's understanding and conversation history.
///
/// The `AgentState` is the agent's memory and context. It's updated after each
/// observation and used as input for the next reasoning step.
struct AgentState {
    var conversationHistory: [String] // Raw history for LLM context
    var currentQuery: String?         // The immediate query being processed
    var lastAction: AgentAction?      // The last action taken by the agent
    var lastObservation: AgentObservation? // The result of the last action
    var internalThought: String?      // A place for the agent to log its internal reasoning steps

    /// Initializes a new agent state.
    init(conversationHistory: [String] = [], currentQuery: String? = nil) {
        self.conversationHistory = conversationHistory
        self.currentQuery = currentQuery
    }

    /// Appends a message to the conversation history.
    mutating func appendMessage(_ message: String, isUser: Bool) {
        conversationHistory.append(isUser ? "User: \(message)" : "Agent: \(message)")
    }

    /// Updates the `lastAction` property.
    mutating func updateLastAction(_ action: AgentAction) {
        self.lastAction = action
    }

    /// Updates the `lastObservation` property.
    mutating func updateLastObservation(_ observation: AgentObservation) {
        self.lastObservation = observation
    }

    /// Updates the `internalThought` property.
    mutating func updateInternalThought(_ thought: String) {
        self.internalThought = thought
    }
}

/// A simulated LLM for demonstration purposes.
///
/// This `MockAgentLLM` class conforms to `AgentLLMProtocol` and simulates an LLM's
/// behavior by parsing simple keywords from the input context to determine an action.
/// This stands in for a real LLM integration (e.g., via Ollama or `llama.cpp`).
class MockAgentLLM: AgentLLMProtocol {
    /// Simulates the time taken for an LLM to process a request.
    private let processingDelay: UInt64 = 500_000_000 // 0.5 seconds in nanoseconds

    /// Predicts an `AgentAction` based on the given context.
    ///
    /// This method contains simple `if-else` logic to simulate the LLM's ability
    /// to understand intent and choose an action.
    func predictAction(from context: String) async throws -> AgentAction {
        // Simulate network/computation delay inherent in real LLM calls.
        try await Task.sleep(nanoseconds: processingDelay)

        let lowercasedContext = context.lowercased()

        if lowercasedContext.contains("time") {
            return .tellTime
        } else if lowercasedContext.contains("search for") {
            let query = lowercasedContext.replacingOccurrences(of: "search for", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
            return .searchWeb(query: query.isEmpty ? "general information" : query)
        } else if lowercasedContext.contains("hello") || lowercasedContext.contains("hi") {
            return .respond(message: "Hello there! How can I help you today?")
        } else if lowercasedContext.contains("how are you") {
            return .respond(message: "I'm an AI, so I don't have feelings, but I'm ready to assist you!")
        } else if lowercasedContext.contains("thank you") {
            return .respond(message: "You're welcome!")
        } else if lowercasedContext.contains("nothing") || lowercasedContext.contains("never mind") {
            return .doNothing
        }
        return .unknown(reason: "Could not parse specific action from: '\(context)'")
    }
}

/// Represents a collection of "tools" or capabilities the agent can use.
///
/// In a real system, these would be separate modules, APIs, or functions that
/// the agent can invoke to interact with the outside world.
struct AgentTools {
    /// Retrieves the current local time.
    static func getCurrentTime() -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        formatter.dateStyle = .none
        return formatter.string(from: Date())
    }

    /// Simulates performing a web search for a given query.
    ///
    /// This function introduces an artificial delay and provides predefined
    /// responses for certain queries to mimic external API calls.
    static func performWebSearch(query: String) async -> String {
        // Simulate network delay for an external API call.
        try? await Task.sleep(nanoseconds: 1_000_000_000) // 1 second delay
        if query.contains("weather") {
            return "The weather in Cupertino is sunny with a high of 75°F."
        } else if query.contains("apple") {
            return "Apple Inc. is an American multinational technology company headquartered in Cupertino, California."
        }
        return "Search results for '\(query)': No specific information found, but generally, the internet is vast."
    }
}

/// The core AI Agent, implementing the Reasoning, Acting, Observing loop.
///
/// This class orchestrates the entire agent workflow, managing its state,
/// interacting with the LLM for reasoning, and invoking tools for acting.
@available(iOS 18.0, macOS 15.0, *)
class AIAgent {
    private let llm: AgentLLMProtocol // The LLM for reasoning
    private(set) var state: AgentState // The agent's current state, readable externally
    private var agentResponseHandler: (String) -> Void // Callback for sending responses to the UI

    /// Initializes the AI Agent.
    ///
    /// - Parameters:
    ///   - llm: An object conforming to `AgentLLMProtocol` (e.g., `MockAgentLLM`).
    ///   - responseHandler: A closure that the agent calls to send messages back
    ///                      to the user interface or other external systems.
    init(llm: AgentLLMProtocol, responseHandler: @escaping (String) -> Void) {
        self.llm = llm
        self.state = AgentState()
        self.agentResponseHandler = responseHandler
    }

    /// The main entry point for processing a user query.
    ///
    /// This method updates the agent's state with the new query and then
    /// initiates a single cycle of the agent loop.
    /// - Parameter query: The user's input query string.
    func processQuery(_ query: String) async {
        state.appendMessage(query, isUser: true) // Add user query to history
        state.currentQuery = query // Set the current query for reasoning
        await runAgentLoop() // Start the loop
    }

    /// Executes a single iteration of the agent loop: Reasoning, Acting, and Observing.
    ///
    /// This method encapsulates the core logic of the agent.
    private func runAgentLoop() async {
        // Inform the user that the agent is processing.
        agentResponseHandler("Agent thinking...")

        // MARK: 1. Reasoning Phase
        // The agent consults its LLM to determine the next action based on the current state.
        let action: AgentAction
        do {
            state.updateInternalThought("Consulting LLM for action based on query: '\(state.currentQuery ?? "N/A")'")
            // Pass the current query (or last message if no current query) to the LLM.
            action = try await llm.predictAction(from: state.currentQuery ?? state.conversationHistory.last ?? "")
            state.updateLastAction(action) // Record the decided action in state
            agentResponseHandler("Agent has decided to: \(action.description)")
        } catch {
            // Handle errors during LLM interaction gracefully.
            action = .unknown(reason: "LLM error: \(error.localizedDescription)")
            state.updateLastAction(action)
            agentResponseHandler("Agent encountered an error during reasoning: \(error.localizedDescription)")
        }

        // MARK: 2. Acting Phase
        // The agent executes the action determined by the LLM.
        let observation: AgentObservation
        switch action {
        case .tellTime:
            state.updateInternalThought("Executing action: Tell Time.")
            let time = AgentTools.getCurrentTime() // Invoke the 'tellTime' tool
            observation = .time(time)
            agentResponseHandler("The current time is \(time).")
        case .searchWeb(let query):
            state.updateInternalThought("Executing action: Search Web for '\(query)'.")
            agentResponseHandler("Searching for '\(query)'...")
            let result = await AgentTools.performWebSearch(query: query) // Invoke the 'searchWeb' tool
            observation = .searchResult(result)
            agentResponseHandler("Search result: \(result)")
        case .respond(let message):
            state.updateInternalThought("Executing action: Respond with message.")
            observation = .acknowledgement(message)
            agentResponseHandler(message) // Direct response, no tool needed
        case .unknown(let reason):
            state.updateInternalThought("Executing action: Respond with unknown action reason.")
            observation = .error("Failed to understand. \(reason)")
            agentResponseHandler("I'm sorry, I don't understand that request. \(reason)")
        case .doNothing:
            state.updateInternalThought("Executing action: Do Nothing.")
            observation = .noObservation
            agentResponseHandler("Okay, I won't do anything specific right now.")
        }
        
        // MARK: 3. Observing Phase
        // The agent updates its internal state based on the outcome of the action.
        state.updateLastObservation(observation) // Record the observation
        state.appendMessage(observation.description, isUser: false) // Add observation to history for future context
        state.currentQuery = nil // Clear the current query as it's been processed
        state.updateInternalThought("Loop complete. Ready for next input.")
    }
}

// MARK: - SwiftUI Integration (ViewModel and View)

/// ViewModel to bridge the Agent logic with SwiftUI.
///
/// `@MainActor` ensures all state updates and UI interactions happen on the main thread,
/// which is critical for SwiftUI's rendering cycle and preventing race conditions.
@available(iOS 18.0, macOS 15.0, *)
@MainActor
class AgentViewModel: ObservableObject {
    @Published var messages: [AgentMessage] = [] // Published property for chat messages
    @Published var currentInput: String = ""    // Published property for the user's input field
    @Published var isProcessing: Bool = false   // Published property to indicate agent activity

    private var agent: AIAgent! // The AI Agent instance
    private var cancellables = Set<AnyCancellable>() // For Combine publishers if needed

    /// Initializes the ViewModel and sets up the `AIAgent`.
    init() {
        // Initialize the agent with a mock LLM and a closure to update messages.
        // The closure uses `[weak self]` to prevent strong reference cycles,
        // ensuring proper memory management.
        let mockLLM = MockAgentLLM()
        agent = AIAgent(llm: mockLLM) { [weak self] response in
            // This closure is called by the agent whenever it generates a response.
            // Since `AgentViewModel` is `@MainActor`, this update is safe for the UI.
            self?.addAgentMessage(response)
        }
    }

    /// Sends the user's current input message to the agent for processing.
    func sendUserMessage() {
        guard !currentInput.isEmpty else { return } // Don't send empty messages
        let messageText = currentInput
        addMessage(messageText, isUser: true) // Add user message to UI
        currentInput = "" // Clear the input field

        isProcessing = true // Indicate that the agent is busy
        Task {
            // Call the agent's `processQuery` method asynchronously.
            // The agent will then run its R-A-O loop and update the UI via the handler.
            await agent.processQuery(messageText)
            isProcessing = false // Agent is done processing
        }
    }

    /// Helper method to add any message (user or agent) to the chat history.
    private func addMessage(_ text: String, isUser: Bool) {
        messages.append(AgentMessage(text: text, isUser: isUser))
    }

    /// Helper method specifically for adding agent-generated messages.
    private func addAgentMessage(_ text: String) {
        messages.append(AgentMessage(text: text, isUser: false))
    }
}

/// A simple SwiftUI view to demonstrate the AI Agent chat interface.
@available(iOS 18.0, macOS 15.0, *)
struct AgentView: View {
    @StateObject private var viewModel = AgentViewModel() // Instantiate ViewModel

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(viewModel.messages) { message in
                        HStack {
                            if message.isUser {
                                Spacer() // Push user messages to the right
                                Text(message.text)
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            } else {
                                Text(message.text)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                Spacer() // Push agent messages to the left
                            }
                        }
                    }
                }
                .padding()
            }
            .defaultScrollAnchor(.bottom) // Automatically scroll to the bottom of the chat

            HStack {
                TextField("Ask the agent...", text: $viewModel.currentInput)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .disabled(viewModel.isProcessing) // Disable input while agent is thinking

                Button("Send") {
                    viewModel.sendUserMessage()
                }
                .padding(.trailing)
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.currentInput.isEmpty || viewModel.isProcessing) // Disable send button when no input or processing
            }
            .padding(.bottom)
        }
        .navigationTitle("AI Agent Chat") // Title for the navigation bar
    }
}

// MARK: - App Entry Point (for Xcode Previews or actual App)

/// The main App structure for the example.
@available(iOS 18.0, macOS 15.0, *)
struct AgentLoopExampleApp: App {
    var body: some Scene {
        WindowGroup {
            AgentView() // The root view of the application
        }
    }
}
