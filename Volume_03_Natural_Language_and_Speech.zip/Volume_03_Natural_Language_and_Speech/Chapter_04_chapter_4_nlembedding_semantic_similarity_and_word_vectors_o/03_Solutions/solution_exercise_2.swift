
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
struct Article: Identifiable { // Added Identifiable for easier SwiftUI integration if needed
    let id: UUID
    let title: String
    let summary: String
    // Pre-computed embedding property, will be set after computation
    var embedding: [Double]? = nil

    init(id: UUID = UUID(), title: String, summary: String) {
        self.id = id
        self.title = title
        self.summary = summary
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct RelatedArticlesFinder {
    private let language: NLLanguage
    private let embeddingModel: NLEmbedding?

    init(language: NLLanguage) {
        self.language = language
        // Initialize the embedding model once for potential reuse.
        self.embeddingModel = NLEmbedding.wordEmbedding(for: language)
        if self.embeddingModel == nil {
            print("Warning: NLEmbedding word model not available for \(language.rawValue). Related article finding will fail.")
        }
    }

    /// Generates an average word embedding for a given text (e.g., an article summary).
    /// This serves as a simplified "document embedding."
    /// - Parameter text: The text to embed.
    /// - Returns: An array of Doubles representing the averaged embedding, or nil if no valid words were found or model is unavailable.
    private func averageWordEmbedding(for text: String) -> [Double]? {
        guard let embeddingModel = self.embeddingModel else { return nil }

        let tokenizer = NLTokenizer(unit: .word)
        tokenizer.string = text

        var sumEmbedding: [Double]? = nil
        var wordCount = 0

        // Enumerate tokens (words) in the text
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
            let word = String(text[tokenRange])
            // Get the embedding for each word
            if let currentWordEmbedding = embeddingModel.embedding(for: word) {
                if sumEmbedding == nil {
                    // Initialize sumEmbedding with the dimension of the first word's embedding
                    sumEmbedding = Array(repeating: 0.0, count: currentWordEmbedding.count)
                }
                // Add current word's embedding to the sum
                for i in 0..<currentWordEmbedding.count {
                    sumEmbedding?[i] += currentWordEmbedding[i]
                }
                wordCount += 1
            }
            return true // Continue enumeration
        }

        // If no words had embeddings or text was empty, return nil
        guard let finalSumEmbedding = sumEmbedding, wordCount > 0 else { return nil }

        // Average the sum embedding by dividing by the number of words
        return finalSumEmbedding.map { $0 / Double(wordCount) }
    }

    /// Finds the top N most semantically similar articles to a target article from a list of candidates.
    /// - Parameters:
    ///   - targetArticle: The article for which to find related articles.
    ///   - candidates: A list of articles to search through.
    ///   - count: The maximum number of related articles to return.
    /// - Returns: An array of `Article`s, sorted by similarity in descending order.
    func findRelated(
        to targetArticle: Article,
        from candidates: [Article],
        count: Int
    ) -> [Article] {
        guard let embeddingModel = self.embeddingModel else {
            print("Embedding model not available. Cannot find related articles.")
            return []
        }

        // 1. Generate embedding for the target article's summary
        // If the target article already has a pre-computed embedding, use it. Otherwise, compute it.
        let targetEmbedding = targetArticle.embedding ?? averageWordEmbedding(for: targetArticle.summary)
        guard let finalTargetEmbedding = targetEmbedding else {
            print("Could not generate embedding for target article: \(targetArticle.title)")
            return []
        }

        var similarities: [(article: Article, score: Double)] = []

        // 2. Iterate through candidate articles
        for var candidate in candidates { // Use 'var' to allow modifying candidate.embedding
            // Skip the target article itself if it's in the candidates list
            if candidate.id == targetArticle.id {
                continue
            }

            // Get or compute the embedding for the candidate article's summary
            let candidateEmbedding = candidate.embedding ?? averageWordEmbedding(for: candidate.summary)

            if let finalCandidateEmbedding = candidateEmbedding {
                // 3. Calculate similarity between target and candidate embeddings
                // NLEmbedding.similarity can compare two explicit [Double] vectors.
                let score = embeddingModel.similarity(for: finalTargetEmbedding, to: finalCandidateEmbedding)
                similarities.append((article: candidate, score: score))
            } else {
                print("Could not generate embedding for candidate article: \(candidate.title)")
            }
        }

        // 4. Sort by similarity score in descending order and return the top N
        return similarities
            .sorted { $0.score > $1.score }
            .prefix(count)
            .map { $0.article }
    }
}

// MARK: - Example Usage
@available(iOS 18.0, macOS 15.0, *)
func demonstrateRelatedArticlesFinder() {
    print("--- Exercise 2: Related Articles Finder ---")

    let finder = RelatedArticlesFinder(language: .english)

    let targetArticle = Article(
        title: "The Future of Electric Cars",
        summary: "Electric vehicles are rapidly evolving, with new battery technologies and charging infrastructure driving their adoption. Autonomous features are also becoming more common."
    )

    var candidateArticles = [
        Article(title: "New Advances in Battery Technology", summary: "Scientists are developing solid-state batteries that promise longer range and faster charging for EVs and mobile devices."),
        Article(title: "Smartphones: Latest Models Reviewed", summary: "A comprehensive review of the newest smartphones, focusing on camera quality, processing power, and user interface."),
        Article(title: "The Rise of Autonomous Driving", summary: "Self-driving cars are moving from concept to reality, with major automakers investing heavily in AI and sensor technology."),
        Article(title: "Home Appliances for a Modern Kitchen", summary: "Explore the latest smart refrigerators, ovens, and dishwashers that integrate with home automation systems."),
        Article(title: "Renewable Energy Solutions", summary: "Solar panels and wind turbines are becoming more efficient, contributing to a greener energy grid and reducing carbon footprints."),
        Article(title: "Impact of AI on Healthcare", summary: "Artificial intelligence is transforming medical diagnostics, drug discovery, and personalized treatment plans."),
        Article(title: "Next-Gen Gaming Consoles", summary: "A look at the powerful new gaming consoles, their exclusive titles, and virtual reality integration.")
    ]

    // Pre-compute embeddings for candidate articles for potential performance gain if many searches are performed
    // In a real app, this might be done on data ingestion or in a background task.
    for i in 0..<candidateArticles.count {
        candidateArticles[i].embedding = finder.averageWordEmbedding(for: candidateArticles[i].summary)
    }

    let relatedArticles = finder.findRelated(to: targetArticle, from: candidateArticles, count: 3)

    print("\nTarget Article: \"\(targetArticle.title)\"")
    print("Finding 3 related articles:")
    if relatedArticles.isEmpty {
        print("No related articles found.")
    } else {
        for (index, article) in relatedArticles.enumerated() {
            // Re-calculate similarity to display the score (optional, could pass score in result tuple)
            let score = finder.embeddingModel?.similarity(
                for: targetArticle.embedding ?? finder.averageWordEmbedding(for: targetArticle.summary)!,
                to: article.embedding ?? finder.averageWordEmbedding(for: article.summary)!
            ) ?? 0.0
            print("\(index + 1). \"\(article.title)\" (Similarity: \(score, specifier: "%.4f"))")
        }
    }
}

// Call the demonstration function
// demonstrateRelatedArticlesFinder()
