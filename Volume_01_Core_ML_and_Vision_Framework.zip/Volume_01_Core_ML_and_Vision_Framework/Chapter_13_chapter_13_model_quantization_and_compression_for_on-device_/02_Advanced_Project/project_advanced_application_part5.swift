
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import Foundation // For Date and TimeInterval

@available(iOS 18.0, *)
final class ModelInferenceManager {
    /// The currently selected quantization strategy for inference.
    var currentStrategy: QuantizationStrategy {
        didSet {
            print("⚙️ Quantization strategy changed to: \(currentStrategy.description)")
        }
    }

    private let modelCache: ModelCache
    private let visionClassifier: VisionClassifier

    /// Initializes the inference manager with a default strategy.
    /// - Parameter defaultStrategy: The initial quantization strategy to use.
    init(defaultStrategy: QuantizationStrategy = .quantized) {
        self.currentStrategy = defaultStrategy
        self.modelCache = ModelCache.shared
        self.visionClassifier = VisionClassifier()
    }

    /// Performs document classification using the currently selected model.
    /// - Parameter image: The UIImage to classify.
    /// - Returns: A tuple containing the classification observations and the inference duration.
    /// - Throws: ModelInferenceError if any step of the process fails.
    func classifyDocument(image: UIImage) async throws -> (observations: [VNClassificationObservation], duration: TimeInterval) {
        guard let ciImage = CIImage(image: image) else {
            throw ModelInferenceError.invalidInputImage
        }

        let startTime = Date()

        // 1. Retrieve the appropriate model based on the current strategy.
        // The ModelCache handles loading and caching.
        let mlModel = try await modelCache.getModel(for: currentStrategy)

        // 2. Perform classification using the Vision framework.
        let observations = try await visionClassifier.classify(image: ciImage, with: mlModel)

        let endTime = Date()
        let duration = endTime.timeIntervalSince(startTime)

        return (observations, duration)
    }

    /// Allows dynamic switching of the quantization strategy.
    /// - Parameter newStrategy: The new quantization strategy to adopt.
    func setQuantizationStrategy(_ newStrategy: QuantizationStrategy) {
        self.currentStrategy = newStrategy
    }

    /// Clears the model cache, useful for memory management or forced reloads.
    func clearModelCache() {
        modelCache.clearCache()
    }
}
