
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "SmartDocumentEditor",
    platforms: [
        .iOS(.v18),
        .macOS(.v15),
        .visionOS(.v2)
    ],
    products: [
        .library(
            name: "SmartDocumentEditor",
            targets: ["SmartDocumentEditor"]),
    ],
    dependencies: [
        // The Intelligence framework is a system framework and typically linked directly in Xcode
        // rather than via SwiftPM. This entry is illustrative of how an *external* AI model
        // library might be included, or how a future modularization of Apple frameworks might look.
        // For Apple Intelligence, you just `import Intelligence`.
        // .package(url: "https://github.com/apple/intelligence-sdk.git", from: "1.0.0"), // Illustrative
    ],
    targets: [
        .target(
            name: "SmartDocumentEditor",
            dependencies: [
                // If Intelligence were a SwiftPM package, it would be listed here.
                // For now, it's a system framework.
                // .product(name: "Intelligence", package: "intelligence-sdk"), // Illustrative
            ]),
        .testTarget(
            name: "SmartDocumentEditorTests",
            dependencies: ["SmartDocumentEditor"]),
    ]
)
