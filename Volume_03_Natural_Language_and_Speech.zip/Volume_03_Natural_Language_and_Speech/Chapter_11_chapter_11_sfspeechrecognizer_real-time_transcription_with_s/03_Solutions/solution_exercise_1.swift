
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Speech
import AVFoundation

class VoiceMemoViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemRed
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false // Disabled initially
        return button
    }()

    private let transcriptionTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.textColor = .label
        textView.backgroundColor = .systemBackground
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Tap 'Start Recording' to begin."
        return textView
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.textColor = .systemGray
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine() // Manages audio input

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestAuthorization()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Ensure resources are cleaned up if view goes off screen
        stopRecording()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Voice Memo"

        let stackView = UIStackView(arrangedSubviews: [startButton, stopButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(statusLabel)
        view.addSubview(stackView)
        view.addSubview(transcriptionTextView)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 40),

            stackView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalToConstant: 50),

            transcriptionTextView.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 20),
            transcriptionTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            transcriptionTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            transcriptionTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)
    }

    // MARK: - Speech Recognition Setup
    private func setupSpeechRecognizer() {
        // Initialize speech recognizer for the default locale
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        speechRecognizer?.delegate = self
    }

    // MARK: - Authorization
    private func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            // Microphone authorization is implicitly requested when setting up AVAudioSession for recording.
            // We'll check it explicitly here for completeness.
            AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    switch (authStatus, granted) {
                    case (.authorized, true):
                        self.startButton.isEnabled = true
                        self.statusLabel.text = "Ready to record."
                        self.statusLabel.textColor = .systemGreen
                    case (.denied, _), (.restricted, _):
                        self.startButton.isEnabled = false
                        self.stopButton.isEnabled = false
                        self.statusLabel.text = "Speech recognition or microphone access denied. Please enable in Settings."
                        self.statusLabel.textColor = .systemRed
                    case (.notDetermined, _):
                        self.startButton.isEnabled = false
                        self.stopButton.isEnabled = false
                        self.statusLabel.text = "Authorization not determined. Please try again."
                        self.statusLabel.textColor = .systemOrange
                    case (_, false): // Microphone denied specifically
                        self.startButton.isEnabled = false
                        self.stopButton.isEnabled = false
                        self.statusLabel.text = "Microphone access denied. Please enable in Settings."
                        self.statusLabel.textColor = .systemRed
                    default:
                        // This case should ideally not be reached if previous cases cover all possibilities
                        self.startButton.isEnabled = false
                        self.stopButton.isEnabled = false
                        self.statusLabel.text = "Unknown authorization status."
                        self.statusLabel.textColor = .systemRed
                    }
                }
            }
        }
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        if audioEngine.isRunning {
            stopRecording()
            return
        }

        do {
            try startRecording()
            startButton.isEnabled = false
            stopButton.isEnabled = true
            transcriptionTextView.text = ""
            statusLabel.text = "Recording..."
            statusLabel.textColor = .systemBlue
        } catch {
            displayError(error, title: "Recording Error")
            startButton.isEnabled = true
            stopButton.isEnabled = false
            statusLabel.text = "Error starting recording."
            statusLabel.textColor = .systemRed
        }
    }

    @objc private func stopRecordingTapped() {
        stopRecording()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        statusLabel.text = "Recording stopped."
        statusLabel.textColor = .systemGray
    }

    private func startRecording() throws {
        // Cancel the previous task if it's running.
        recognitionTask?.cancel()
        recognitionTask = nil

        // Configure the audio session for recording.
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        // Create a recognition request.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true // Enable real-time updates

        // Configure the audio engine.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        // Start the recognition task.
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                self.transcriptionTextView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // Stop the audio engine and recognition task if an error occurs or the task is final.
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil

                // Re-enable start button, disable stop button
                DispatchQueue.main.async {
                    self.startButton.isEnabled = true
                    self.stopButton.isEnabled = false
                    if error != nil {
                        self.displayError(error!, title: "Speech Recognition Error")
                        self.statusLabel.text = "Error during recognition."
                        self.statusLabel.textColor = .systemRed
                    } else if isFinal {
                        self.statusLabel.text = "Transcription complete."
                        self.statusLabel.textColor = .systemGreen
                    }
                }
            }
        }
    }

    private func stopRecording() {
        audioEngine.stop()
        if let inputNode = audioEngine.inputNode {
            inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel() // Explicitly cancel the task
        recognitionRequest = nil
        recognitionTask = nil

        // Deactivate audio session
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        DispatchQueue.main.async {
            if available {
                self.startButton.isEnabled = true
                self.statusLabel.text = "Ready to record."
                self.statusLabel.textColor = .systemGreen
            } else {
                self.startButton.isEnabled = false
                self.stopButton.isEnabled = false
                self.statusLabel.text = "Speech recognition is not available on this device or locale."
                self.statusLabel.textColor = .systemRed
            }
        }
    }

    // MARK: - Error Handling
    private func displayError(_ error: Error, title: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
}

// MARK: - Info.plist Requirements
/*
 Add these keys to your Info.plist:
 <key>NSMicrophoneUsageDescription</key>
 <string>This app needs access to your microphone to record your speech for transcription.</string>
 <key>NSSpeechRecognitionUsageDescription</key>
 <string>This app uses speech recognition to convert your voice into text in real-time.</string>
 */
