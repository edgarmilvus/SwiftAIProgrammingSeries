
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftData

@available(iOS 18.0, *)
@Model
class ResearchNote {
    var content: String
    var embedding: [Float]?
    
    init(content: String) {
        self.content = content
    }
}

@available(iOS 18.0, *)
@ModelActor
actor VectorProcessingActor {
    /// Processes a note's embedding in the background.
    /// Note: We pass the PersistentIdentifier, NOT the model itself.
    func generateEmbedding(for noteID: PersistentIdentifier) async throws {
        // 1. Fetch the note in this actor's private context
        guard let note = modelContext.model(for: noteID) as? ResearchNote else {
            return
        }
        
        // 2. Simulate heavy ML/Transformer computation
        // In a real app, this is where CoreML/Apple Intelligence would run.
        let simulatedEmbedding = try await performHeavyMLComputation()
        
        // 3. Update the model
        note.embedding = simulatedEmbedding
        
        // 4. Save changes to the persistent store
        try modelContext.save()
        print("Successfully processed embedding for note: \(note.content.prefix(10))...")
    }
    
    private func performHeavyMLComputation() async throws -> [Float] {
        // Simulate 2 seconds of heavy GPU/NPU usage
        try await Task.sleep(for: .seconds(2))
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}

@MainActor
class NoteViewModel: ObservableObject {
    @Published var notes: [ResearchNote] = []
    private let container: ModelContainer
    private var processor: VectorProcessingActor?

    init(container: ModelContainer) {
        self.container = container
        // Initialize the actor once to be reused
        self.processor = VectorProcessingActor(modelContainer: container)
    }

    func addNoteAndProcess(content: String) {
        let newNote = ResearchNote(content: content)
        // Accessing the main context to insert
        let context = container.mainContext
        context.insert(newNote)
        
        // Capture the ID to pass across the actor boundary
        let noteID = newNote.persistentModelID
        
        Task {
            do {
                // Pass the ID to the actor, not the 'newNote' object
                try await processor?.generateEmbedding(for: noteID)
            } catch {
                print("Processing error: \(error)")
            }
        }
    }
}
