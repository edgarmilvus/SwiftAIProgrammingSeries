
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
@Observable
class DocumentEditorViewModel {
    var documentText: String = "Write your thoughts here. The system will help you."
    var aiSuggestions: [String] = [] // For custom AI features, not directly from writingToolsBehavior
    
    // Example of a method that might update documentText, triggering UI updates
    func applyAITextChange(newText: String) {
        self.documentText = newText
        print("Document text updated by AI.")
    }
    
    // A hypothetical method to fetch custom AI suggestions
    func fetchCustomSuggestions() async {
        // Simulate fetching from an AI service
        try? await Task.sleep(for: .seconds(0.5))
        await MainActor.run {
            self.aiSuggestions = ["Make it more concise", "Expand on the idea"]
        }
    }
}

@available(iOS 18.0, *)
struct DocumentEditorView: View {
    @State private var viewModel = DocumentEditorViewModel()

    var body: some View {
        VStack {
            TextEditor(text: $viewModel.documentText)
                .frame(minHeight: 200)
                .border(Color.gray, width: 0.5)
                .padding()
                // The core of the Writing Tools API integration
                .writingToolsBehavior(.enabled) 
            
            Button("Simulate AI Update") {
                viewModel.applyAITextChange(newText: "This text has been updated by a simulated AI. It is now longer and more descriptive.")
            }
            .padding()

            if !viewModel.aiSuggestions.isEmpty {
                Text("Custom AI Suggestions:")
                ForEach(viewModel.aiSuggestions, id: \.self) { suggestion in
                    Text(suggestion)
                }
            }
        }
        .task {
            // Fetch custom suggestions when the view appears
            await viewModel.fetchCustomSuggestions()
        }
        .navigationTitle("AI Document Editor")
    }
}
