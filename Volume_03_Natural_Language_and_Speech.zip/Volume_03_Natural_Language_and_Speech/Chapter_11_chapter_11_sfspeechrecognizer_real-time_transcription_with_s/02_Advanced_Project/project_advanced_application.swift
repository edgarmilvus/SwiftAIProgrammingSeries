
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Illustrative - SFSpeechRecognizer and NaturalLanguage are built-in frameworks)
// No external Swift Package Manager dependencies are required for SFSpeechRecognizer
// or NaturalLanguage frameworks, as they are part of the Apple SDK.
// If you were to add other NLP libraries or utility packages, they would be listed here.
//
// let package = Package(
//     name: "SmartVoiceNotes",
//     platforms: [.iOS(.v17)], // Or .v18 if using cutting-edge APIs
//     products: [
//         .library(
//             name: "SmartVoiceNotes",
//             targets: ["SmartVoiceNotes"]),
//     ],
//     dependencies: [
//         // Example: If you needed a custom logging framework
//         // .package(url: "https://github.com/your-org/YourLoggingFramework.git", from: "1.0.0"),
//     ],
//     targets: [
//         .target(
//             name: "SmartVoiceNotes",
//             dependencies: []),
//         .testTarget(
//             name: "SmartVoiceNotesTests",
//             dependencies: ["SmartVoiceNotes"]),
//     ]
// )

import Foundation
import AVFoundation
import Speech
import NaturalLanguage // For advanced text analysis

/// Custom errors for the SmartVoiceNoteProcessor.
enum SmartVoiceNoteError: Error, LocalizedError {
    case notAuthorized
    case audioEngineFailed(Error)
    case recognitionFailed(Error)
    case alreadyRecording
    case notRecording
    case audioSessionSetupFailed(Error)

    var errorDescription: String? {
        switch self {
        case .notAuthorized: return "Speech recognition is not authorized."
        case .audioEngineFailed(let error): return "Audio engine failed: \(error.localizedDescription)"
        case .recognitionFailed(let error): return "Speech recognition failed: \(error.localizedDescription)"
        case .alreadyRecording: return "Already recording a voice note."
        case .notRecording: return "No active recording to stop."
        case .audioSessionSetupFailed(let error): return "Failed to set up audio session: \(error.localizedDescription)"
        }
    }
}

/// A class responsible for real-time speech transcription and basic insight extraction.
/// It uses SFSpeechRecognizer for speech-to-text and NaturalLanguage for identifying action items.
@available(iOS 17.0, *) // SFSpeechRecognizer is available from iOS 10, but we target modern APIs.
final class SmartVoiceNoteProcessor: NSObject, SFSpeechRecognizerDelegate {

    // MARK: - Properties

    /// The speech recognizer instance.
    private let speechRecognizer: SFSpeechRecognizer?
    /// The audio engine to manage audio input from the microphone.
    private var audioEngine: AVAudioEngine?
    /// The recognition request to feed audio to the speech recognizer.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    /// The recognition task that manages the speech recognition process.
    private var recognitionTask: SFSpeechRecognitionTask?

    /// A closure to deliver real-time transcription updates.
    var onTranscriptionUpdate: ((String) -> Void)?
    /// A closure to deliver identified action items.
    var onActionItemFound: ((String) -> Void)?
    /// A closure to deliver error messages.
    var onError: ((SmartVoiceNoteError) -> Void)?
    /// A closure to notify when recording state changes.
    var onRecordingStateChanged: ((Bool) -> Void)?

    /// Indicates if the processor is currently recording.
    private(set) var isRecording: Bool = false {
        didSet {
            onRecordingStateChanged?(isRecording)
        }
    }

    /// Initializes the SmartVoiceNoteProcessor.
    /// - Parameter locale: The locale for speech recognition. Defaults to the device's current locale.
    init(locale: Locale = Locale.current) {
        self.speechRecognizer = SFSpeechRecognizer(locale: locale)
        super.init()
        self.speechRecognizer?.delegate = self // Set self as the delegate for availability changes.
    }

    /// Cleans up resources when the object is deallocated.
    deinit {
        stopRecording() // Ensure all audio and recognition resources are released.
        print("SmartVoiceNoteProcessor deinitialized.")
    }

    // MARK: - Authorization

    /// Requests speech recognition authorization from the user.
    /// This method should be called before attempting to start recording.
    /// - Returns: `true` if authorized, `false` otherwise.
    /// - Throws: `SmartVoiceNoteError.notAuthorized` if authorization is denied or restricted.
    func requestAuthorization() async throws {
        return try await withCheckedThrowingContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { authStatus in
                OperationQueue.main.addOperation { // Ensure UI updates or completion handlers are on main thread.
                    switch authStatus {
                    case .authorized:
                        print("Speech recognition authorized.")
                        continuation.resume(returning: ())
                    case .denied, .restricted, .notDetermined:
                        let error = SmartVoiceNoteError.notAuthorized
                        self.onError?(error)
                        continuation.resume(throwing: error)
                    @unknown default:
                        let error = SmartVoiceNoteError.notAuthorized
                        self.onError?(error)
                        continuation.resume(throwing: error)
                    }
                }
            }
        }
    }

    // MARK: - Recording Control

    /// Starts the speech recognition process.
    /// - Throws: `SmartVoiceNoteError` if recording cannot be started.
    func startRecording() async throws {
        guard !isRecording else {
            throw SmartVoiceNoteError.alreadyRecording
        }

        // 1. Cancel any previous recognition task.
        recognitionTask?.cancel()
        recognitionTask = nil

        // 2. Configure Audio Session for recording.
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            let sessionError = SmartVoiceNoteError.audioSessionSetupFailed(error)
            onError?(sessionError)
            throw sessionError
        }

        // 3. Initialize Audio Engine and Recognition Request.
        audioEngine = AVAudioEngine()
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        recognitionRequest?.shouldReportPartialResults = true // Enable real-time updates.

        guard let audioEngine = audioEngine, let recognitionRequest = recognitionRequest else {
            let error = SmartVoiceNoteError.audioEngineFailed(
                NSError(domain: "SmartVoiceNoteProcessor", code: 1, userInfo: [NSLocalizedDescriptionKey: "Audio engine or request not initialized."])
            )
            onError?(error)
            throw error
        }
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            let error = SmartVoiceNoteError.notAuthorized // More specifically, not available
            onError?(error)
            throw error
        }

        // 4. Set up audio input node.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer) // Feed audio buffers to the recognition request.
        }

        // 5. Prepare and start the audio engine.
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            let engineError = SmartVoiceNoteError.audioEngineFailed(error)
            onError?(engineError)
            throw engineError
        }

        // 6. Start the speech recognition task.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            if let result = result {
                self.onTranscriptionUpdate?(result.bestTranscription.formattedString)
                if result.isFinal {
                    // Process final transcription for insights.
                    self.processTranscriptionForInsights(result.bestTranscription.formattedString)
                }
            } else if let error = error {
                self.stopRecording() // Stop on error.
                let recognitionError = SmartVoiceNoteError.recognitionFailed(error)
                self.onError?(recognitionError)
            }
        }
        
        isRecording = true
        print("Recording started.")
    }

    /// Stops the speech recognition process and cleans up resources.
    func stopRecording() {
        guard isRecording else { return }

        // 1. Stop audio engine and remove tap.
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0)
        audioEngine = nil // Release engine resources.

        // 2. End recognition request and cancel task.
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil

        // 3. Deactivate audio session.
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
            // Potentially report this error, but don't re-throw as recording is already stopping.
        }

        isRecording = false
        print("Recording stopped.")
    }

    // MARK: - SFSpeechRecognizerDelegate

    /// Called when the availability of the speech recognizer changes.
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if !available {
            print("Speech recognizer is no longer available. Stopping recording.")
            if isRecording {
                stopRecording()
                onError?(SmartVoiceNoteError.recognitionFailed(
                    NSError(domain: "SmartVoiceNoteProcessor", code: 2, userInfo: [NSLocalizedDescriptionKey: "Speech recognizer became unavailable."])
                ))
            }
        }
    }

    // MARK: - Natural Language Processing for Insights

    /// Processes a transcribed string to identify potential action items.
    /// This is a simplified example using keyword spotting.
    /// - Parameter transcription: The transcribed text.
    private func processTranscriptionForInsights(_ transcription: String) {
        let actionItemKeywords = [
            "I need to", "remember to", "follow up on", "make sure to",
            "don't forget", "my goal is to", "action item"
        ]

        // Using NLTagger for basic tokenization and finding phrases.
        // For more advanced scenarios, consider custom NLModels or rule-based systems.
        let tagger = NLTagger(tagSchemes: [.tokenType])
        tagger.string = transcription

        tagger.enumerateTags(in: transcription.startIndex..<transcription.endIndex, unit: .sentence, scheme: .tokenType, options: []) { tag, tokenRange in
            let sentence = String(transcription[tokenRange])
            for keyword in actionItemKeywords {
                if sentence.lowercased().contains(keyword) {
                    self.onActionItemFound?("💡 Action Item: \(sentence)")
                    // For demonstration, we stop after finding the first keyword in a sentence.
                    // In a real app, you might collect all matches.
                    break
                }
            }
            return true // Continue enumeration
        }
    }
}

// MARK: - Usage Example (within a ViewController or ViewModel)

/*
// Example of how to integrate SmartVoiceNoteProcessor into an app.
// This would typically be managed by a ViewModel or directly in a UIViewController.

@available(iOS 17.0, *)
class VoiceNotesViewModel: ObservableObject {
    @Published var currentTranscription: String = ""
    @Published var actionItems: [String] = []
    @Published var errorMessage: String?
    @Published var isRecording: Bool = false

    private let processor = SmartVoiceNoteProcessor()

    init() {
        processor.onTranscriptionUpdate = { [weak self] text in
            self?.currentTranscription = text
        }
        processor.onActionItemFound = { [weak self] item in
            self?.actionItems.append(item)
        }
        processor.onError = { [weak self] error in
            self?.errorMessage = error.localizedDescription
            self?.isRecording = false // Ensure UI reflects stopped state
        }
        processor.onRecordingStateChanged = { [weak self] recording in
            self?.isRecording = recording
        }
    }

    func toggleRecording() async {
        if isRecording {
            processor.stopRecording()
        } else {
            do {
                // Request authorization first
                try await processor.requestAuthorization()
                // Clear previous data
                currentTranscription = ""
                actionItems = []
                errorMessage = nil
                // Start recording
                try await processor.startRecording()
            } catch {
                errorMessage = error.localizedDescription
                isRecording = false // Ensure UI reflects stopped state
            }
        }
    }

    // Call this when the view disappears to ensure resources are released.
    func cleanup() {
        processor.stopRecording()
    }
}

// In a SwiftUI View:
// struct VoiceNotesView: View {
//     @StateObject private var viewModel = VoiceNotesViewModel()
//
//     var body: some View {
//         VStack {
//             Text(viewModel.currentTranscription)
//                 .padding()
//             List(viewModel.actionItems, id: \.self) { item in
//                 Text(item)
//             }
//             Button(action: {
//                 Task { await viewModel.toggleRecording() }
//             }) {
//                 Text(viewModel.isRecording ? "Stop Recording" : "Start Recording")
//             }
//             .padding()
//             .background(viewModel.isRecording ? Color.red : Color.green)
//             .foregroundColor(.white)
//             .cornerRadius(10)
//
//             if let error = viewModel.errorMessage {
//                 Text("Error: \(error)")
//                     .foregroundColor(.red)
//             }
//         }
//         .onDisappear {
//             viewModel.cleanup()
//         }
//     }
// }
*/
