
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Vision
import AVFoundation
import Combine

// MARK: - Models

/// A thread-safe representation of a detected object in 3D space.
/// Conforming to `Sendable` is critical for Swift 6 concurrency safety.
struct DetectedObject: Sendable, Identifiable {
    let id: UUID
    let label: String
    let confidence: Float
    let boundingBox: CGRect // Normalized coordinates (0.0 to 1.0)
    let spatialTransform: simd_float4x4 // The position/rotation in the real world
}

// MARK: - AI Processing Actor

/// An `actor` is used to isolate the heavy computational work of Vision/CoreML.
/// This prevents the main thread (UI) from stuttering during inference.
@available(visionOS 2.0, *)
actor SpatialAIProcessor {
    private var detectionRequest: VNCoreMLRequest?
    
    /// Initializes the processor with a specific CoreML model.
    /// - Parameter model: The compiled CoreML model to use for detection.
    init(model: VNCoreMLModel) {
        // Create a request that performs classification/detection
        self.detectionRequest = VNCoreMLRequest(model: model)
        self.detectionRequest?.imageCropAndScaleOption = .scaleFill
    }
    
    /// Processes a captured frame from the ARKit session.
    /// - Parameter pixelBuffer: The raw image data from the camera.
    /// - Returns: An array of detected objects with their spatial context.
    func process(pixelBuffer: CVPixelBuffer, currentTransform: simd_float4x4) async -> [DetectedObject] {
        return await withCheckedContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            
            do {
                try handler.perform([self.detectionRequest].compactMap { $0 })
                
                // Extract results from the Vision request
                let observations = detectionRequest?.results as? [VNRecognizedObjectObservation] ?? []
                
                let detected = observations.map { observation in
                    // In a real app, we would use ARKit's raycasting to convert 
                    // the 2D bounding box into a 3D transform.
                    // For this example, we simulate the spatial mapping.
                    let simulatedTransform = currentTransform // Simplified for example
                    
                    return DetectedObject(
                        id: UUID(),
                        label: observation.labels.first?.identifier ?? "Unknown Object",
                        confidence: observation.confidence,
                        boundingBox: observation.boundingBox,
                        spatialTransform: simulatedTransform
                    )
                }
                
                continuation.resume(returning: detected)
            } catch {
                print("Vision Error: \(error)")
                continuation.resume(returning: [])
            }
        }
    }
}

// MARK: - Accessibility Coordinator

/// Manages the delivery of accessibility feedback.
/// It ensures that all VoiceOver and audio announcements happen on the `@MainActor`.
@MainActor
class AccessibilityCoordinator: ObservableObject {
    private let synthesizer = AVSpeechSynthesizer()
    
    /// Announces a detected object using spatial-aware language.
    /// - Parameter object: The detected object to describe.
    func announceDetection(_ object: DetectedObject) {
        // 1. Create a descriptive string. 
        // Note: We include confidence to manage user expectations (crucial for AI).
        let confidenceText = object.confidence > 0.8 ? "" : "possibly a "
        let description = "\(confidenceText)\(object.label)."
        
        // 2. Prepare the speech utterance.
        let utterance = AVSpeechUtterance(string: description)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        
        // 3. Execute the announcement.
        // In a production visionOS app, we would also trigger a Spatial Audio 
        // sound effect positioned at the object's transform.
        if !synthesizer.isSpeaking {
            synthesizer.speak(utterance)
        }
        
        // 4. Trigger a system-level Accessibility announcement.
        // This ensures the VoiceOver cursor or focus can react to the change.
        AccessibilityNotification.Announcement("Detected \(object.label)".url)
    }
}

// MARK: - Main View

@available(visionOS 2.0, *)
struct SpatialObjectNarratorView: View {
    @StateObject private var accessibilityCoordinator = AccessibilityCoordinator()
    @State private var lastDetectedLabel: String = "Scanning environment..."
    
    // The AI Processor is stored in a way that respects its actor isolation.
    // In a real app, this would be injected via a Dependency Injection container.
    private let aiProcessor: SpatialAIProcessor? 

    init(model: VNCoreMLModel?) {
        // Initialize the actor with the provided model
        if let model = model {
            self._aiProcessor = State(initialValue: SpatialAIProcessor(model: model))
        } else {
            self._aiProcessor = State(initialValue: nil)
        }
    }

    var body: some View {
        VStack(spacing: 20) {
            Text("Spatial AI Narrator")
                .font(.largeTitle)
            
            Text(lastDetectedLabel)
                .font(.title2)
                .foregroundColor(.secondary)
                // Highlighting the object for the visual layer
                .accessibilityLabel("Current detection: \(lastDetectedLabel)")

            // A simulated AR View
            RealityView { content in
                // Setup scene...
            }
            .frame(width: 600, height: 400)
            .background(Color.black.opacity(0.2))
            .cornerRadius(20)
        }
        .task {
            // Start the continuous detection loop
            await startDetectionLoop()
        }
    }

    /// The main loop that drives the AI inference.
    private func startDetectionLoop() async {
        guard let processor = aiProcessor else { return }
        
        while true {
            // 1. Simulate capturing a frame from ARKit.
            // In a real app, this comes from the ARSessionDelegate.
            let mockBuffer = createMockPixelBuffer() 
            let currentTransform = matrix_identity_float4x4
            
            // 2. Offload inference to the Actor.
            // This 'await' suspends the loop, but does NOT block the UI.
            let detections = await processor.process(pixelBuffer: mockBuffer, currentTransform: currentTransform)
            
            // 3. Handle results on the MainActor.
            if let topDetection = detections.first {
                self.lastDetectedLabel = topDetection.label
                
                // 4. Communicate via Accessibility.
                await accessibilityCoordinator.announceDetection(topDetection)
            }
            
            // 5. Throttle the loop to prevent overheating and excessive battery drain.
            // AI inference is expensive; 2-5 FPS is often enough for accessibility.
            try? await Task.sleep(for: .seconds(1))
        }
    }
    
    /// Helper to simulate CVPixelBuffer for compilation purposes.
    private func createMockPixelBuffer() -> CVPixelBuffer {
        // In a real implementation, this would be provided by the ARKit session.
        var pixelBuffer: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, 640, 480, kCVPixelFormatType_32BGRA, nil, &pixelBuffer)
        return pixelBuffer!
    }
}
