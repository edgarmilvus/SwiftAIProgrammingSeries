
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage

@available(iOS 18.0, *)
actor EmbeddingCache {
    private var cache: [String: [Float]] = [:]
    private let embeddingGenerator = NLEmbedding.document

    /// Retrieves an embedding, generating it if not found in the cache.
    func getEmbedding(for text: String) async throws -> [Float] {
        if let cached = cache[text] {
            return cached
        }
        // If not in cache, generate it (this is an async call)
        let embedding = try await embeddingGenerator.embedding(for: text)
        cache[text] = embedding // Store in cache
        return embedding
    }

    /// Clears the entire cache.
    func clearCache() {
        cache.removeAll()
    }

    /// Pre-populates the cache with embeddings for a batch of texts.
    func prewarmCache(with texts: [String]) async {
        await withTaskGroup(of: (String, [Float]?).self) { group in
            for text in texts {
                group.addTask {
                    do {
                        let embedding = try await self.embeddingGenerator.embedding(for: text)
                        return (text, embedding)
                    } catch {
                        print("Error prewarming embedding for '\(text)': \(error)")
                        return (text, nil)
                    }
                }
            }

            for await (text, embedding) in group {
                if let embedding = embedding {
                    // This modification to `cache` is safe because it's happening
                    // within the actor's isolated context.
                    self.cache[text] = embedding
                }
            }
        }
    }
}
