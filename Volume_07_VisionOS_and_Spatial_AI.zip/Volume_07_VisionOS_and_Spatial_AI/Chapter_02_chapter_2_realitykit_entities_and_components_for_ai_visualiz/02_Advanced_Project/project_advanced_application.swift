
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import RealityKit
import ARKit
import Combine
import SwiftUI

// MARK: - Package Dependencies
/*
 To use this in a real project, ensure your Package.swift includes:
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ]
*/

// MARK: - Error Definitions

/// Errors specific to the AI-Spatial integration layer.
enum AISpatialError: Error {
    /// Thrown when the dimensionality of the input vector does not match the expected model output.
    case dimensionMismatch(expected: Int, actual: Int)
    /// Thrown when the data ingestion actor is overloaded.
    case ingestionBufferOverflow
    /// Thrown when the projection math results in NaN or infinite values.
    case invalidProjectionResult
}

// MARK: - Components

/// A component that stores high-dimensional AI data and its projected 3D state.
/// This is a pure data struct, adhering to ECS principles.
@available(visionOS 2.0, *)
struct AIEmbeddingComponent: Component, Sendable {
    /// The raw high-dimensional vector (e.g., 1536 dimensions from OpenAI or local CoreML).
    let embedding: [Float]
    
    /// The semantic label associated with this vector.
    let label: String
    
    /// The current relevance score (0.0 to 1.0) calculated based on user proximity or gaze.
    var relevance: Float = 0.0
    
    /// The target position in 3D space after dimensionality reduction.
    var targetPosition: SIMD3<Float>
    
    /// Metadata for visual styling.
    let color: UIColor
}

/// A component used to mark entities that should be treated as "Focus Targets" by the AI system.
@available(visionOS 2.0, *)
struct AIFocusComponent: Component {}

// MARK: - Data Management (Concurrency)

/// An Actor responsible for managing the influx of AI data from the Neural Engine.
/// Using an Actor ensures that we don't have data races when the AI model 
/// pushes new embeddings while the RealityKit System is reading them.
@available(visionOS 2.0, *)
actor LatentSpaceManager {
    /// A thread-safe collection of newly arrived embeddings waiting to be integrated into the scene.
    private var pendingEmbeddings: [(vector: [Float], label: String, color: UIColor)] = []
    
    /// The expected dimensionality of the model's output.
    let expectedDimensions: Int
    
    init(expectedDimensions: Int) {
        self.expectedDimensions = expectedDimensions
    }
    
    /// Ingests a new embedding from the AI model.
    /// - Parameters:
    ///   - vector: The high-dimensional array.
    ///   - label: The human-readable name.
    ///   - color: The semantic color.
    /// - Throws: `AISpatialError.dimensionMismatch` if the vector size is incorrect.
    func ingest(vector: [Float], label: String, color: UIColor) throws {
        guard vector.count == expectedDimensions else {
            throw AISpatialError.dimensionMismatch(expected: expectedDimensions, actual: vector.count)
        }
        
        pendingEmbeddings.append((vector, label, color))
    }
    
    /// Flushes the pending embeddings for the System to process.
    /// - Returns: An array of processed data tuples.
    func flush() -> [(vector: [Float], label: String, color: UIColor)] {
        let current = pendingEmbeddings
        pendingEmbeddings.removeAll()
        return current
    }
}

// MARK: - The Logic Engine (System)

/// The `AISpatialSystem` is the heart of the visualization.
/// It runs every frame, querying all entities with `AIEmbeddingComponent`.
@available(visionOS 2.0, *)
class AISpatialSystem: System {
    
    /// A query to find all entities that have both an AIEmbeddingComponent and a ModelComponent.
    private static let query = EntityQuery(where: .has(AIEmbeddingComponent.self) && .has(ModelComponent.self))
    
    /// Required initializer for RealityKit Systems.
    required init(scene: Scene) { }
    
    /// The update loop called every frame.
    /// - Parameter context: Contains the time delta and scene information.
    func update(context: SceneUpdateContext) {
        let deltaTime = Float(context.deltaTime)
        
        // 1. Iterate through all entities matching our query.
        context.scene.performQuery(Self.query).forEach { entity in
            guard var aiComp = entity.components[AIEmbeddingComponent.self] as? AIEmbeddingComponent else { return }
            
            // 2. Calculate "Relevance" based on proximity to the camera (simulated here).
            // In a real app, you would use ARKit's gaze tracking or hand gestures.
            let cameraTransform = context.scene.findEntity(named: "Camera")?.transform ?? Transform()
            let distance = distance(entity.position(relativeTo: nil), cameraTransform.translation)
            
            // Smoothly interpolate relevance: closer = higher relevance.
            let targetRelevance: Float = max(0, 1.0 - (distance / 2.0)) 
            aiComp.relevance = lerp(aiComp.relevance, targetRelevance, t: deltaTime * 2.0)
            
            // 3. Update Visuals based on relevance.
            // We scale the entity up if it's highly relevant.
            let scaleFactor = 1.0 + (aiComp.relevance * 0.5)
            entity.scale = SIMD3<Float>(repeating: scaleFactor)
            
            // 4. Update the component back on the entity (since components are value types).
            entity.components[AIEmbeddingComponent.self] = aiComp
            
            // 5. Apply a "pulse" animation using the relevance score.
            applyPulseEffect(to: entity, relevance: aiComp.relevance, deltaTime: deltaTime)
        }
    }
    
    /// Helper to interpolate values.
    private func lerp(_ start: Float, _ end: Float, t: Float) -> Float {
        return start + (end - start) * min(t, 1.0)
    }
    
    /// Applies a subtle spatial pulse to the entity to indicate AI "activity".
    private func applyPulseEffect(to entity: Entity, relevance: Float, deltaTime: Float) {
        let pulse = sin(Float(Date().timeIntervalSince1970) * 5.0) * 0.05 * relevance
        entity.scale += SIMD3<Float>(repeating: pulse)
    }
}

// MARK: - Spatial Coordinator (View Model / App Logic)

/// High-level coordinator that bridges the AI Model and the RealityKit Scene.
@available(visionOS 2.0, *)
@MainActor
class SemanticExplorerCoordinator: ObservableObject {
    private let manager = LatentSpaceManager(expectedDimensions: 1536)
    private var scene: Scene
    private var cancellables = Set<AnyCancellable>()
    
    init(scene: Scene) {
        self.scene = scene
        // Register the system before the scene starts updating.
        AISpatialSystem.registerSystem()
    }
    
    /// Simulates receiving data from a CoreML model.
    func simulateAIInference() {
        Task {
            do {
                // Simulate a high-dimensional vector.
                let mockVector = (0..<1536).map { _ in Float.random(in: -1...1) }
                let mockLabel = "Concept \(Int.random(in: 1...1000))"
                let mockColor = UIColor.systemBlue
                
                // Send to the actor for safe storage.
                try await manager.ingest(vector: mockVector, label: mockLabel, color: mockColor)
                
                // Trigger the integration into the scene.
                await integrateNewEmbeddings()
            } catch {
                print("AI Ingestion Error: \(error)")
            }
        }
    }
    
    /// Moves data from the Actor to the RealityKit Scene.
    private func integrateNewEmbeddings() async {
        let newItems = await manager.flush()
        
        for item in newItems {
            // 1. Perform Dimensionality Reduction (Mocked).
            // In production, use PCA or t-SNE logic here to map 1536D -> 3D.
            let projectedPos = projectHighDimTo3D(item.vector)
            
            // 2. Create the RealityKit Entity.
            let entity = createVisualNode(for: item, at: projectedPos)
            
            // 3. Add to scene.
            let anchor = AnchorEntity(world: .zero)
            anchor.addChild(entity)
            scene.addAnchor(anchor)
        }
    }
    
    /// Mock dimensionality reduction logic.
    private func projectHighDimTo3D(_ vector: [Float]) -> SIMD3<Float> {
        // Real-world: Use a linear projection matrix or a trained autoencoder.
        // Here, we take the first three components as a naive proxy.
        return SIMD3<Float>(vector[0], vector[1], vector[2]) * 0.5
    }
    
    /// Creates a visual representation of a semantic node.
    private func createVisualNode(for item: (vector: [Float], label: String, color: UIColor), at position: SIMD3<Float>) -> Entity {
        let mesh = MeshResource.generateSphere(radius: 0.02)
        let material = SimpleMaterial(color: item.color, isMetallic: true)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        
        entity.position = position
        
        // Attach the AI Component.
        let aiComp = AIEmbeddingComponent(
            embedding: item.vector,
            label: item.label,
            targetPosition: position,
            color: item.color
        )
        entity.components.set(aiComp)
        
        return entity
    }
}
