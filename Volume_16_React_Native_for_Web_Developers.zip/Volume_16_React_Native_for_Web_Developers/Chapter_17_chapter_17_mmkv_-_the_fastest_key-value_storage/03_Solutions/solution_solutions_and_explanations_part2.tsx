/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// components/SearchHistory.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, Button, TextInput, FlatList, StyleSheet } from 'react-native';
import { storage } from '../lib/storage';

export const SearchHistory = () => {
  const [history, setHistory] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  // Key for storing the history array in MMKV
  const HISTORY_KEY = 'search_history';

  // 1. Initialize state from MMKV on mount
  useEffect(() => {
    const savedHistory = storage.getString(HISTORY_KEY);
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse search history", e);
      }
    }
  }, []);

  // 2. Function to add a new search term
  const addSearchTerm = (term: string) => {
    if (!term.trim()) return;

    // Create new array: prepend term, limit to 10 items
    const newHistory = [term, ...history.filter(h => h !== term)].slice(0, 10);
    
    // Write synchronously to MMKV
    storage.set(HISTORY_KEY, JSON.stringify(newHistory));
    
    // Update state to trigger re-render
    setHistory(newHistory);
    setSearchTerm(''); // Clear input
  };

  // 3. Function to clear history
  const clearHistory = () => {
    storage.delete(HISTORY_KEY); // Remove key from MMKV
    setHistory([]); // Reset state
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Search..."
        value={searchTerm}
        onChangeText={setSearchTerm}
        onSubmitEditing={() => addSearchTerm(searchTerm)}
      />
      <Text style={styles.title}>Recent Searches:</Text>
      <FlatList
        data={history}
        keyExtractor={(item, index) => item + index}
        renderItem={({ item }) => <Text style={styles.item}>{item}</Text>}
        ListEmptyComponent={<Text>No recent searches.</Text>}
      />
      <Button title="Clear History" onPress={clearHistory} color="red" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16 },
  input: { borderWidth: 1, padding: 8, marginBottom: 16 },
  title: { fontWeight: 'bold', marginBottom: 8 },
  item: { padding: 4, fontSize: 16 },
});
