
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
actor TrainingProgressMonitor {
    // The MLProgress object itself is @Observable, but we can encapsulate it
    // within an actor to ensure all interactions (e.g., cancellation,
    // advanced state management) are thread-safe.
    // Alternatively, the actor could hold a *copy* of the relevant state
    // and update it from the MLProgress object.
    private let progress: MLProgress
    private var trainingTask: Task<MLModel, Error>? // To hold and manage the training task

    init(initialProgress: MLProgress) {
        self.progress = initialProgress
    }

    // Provides safe, isolated access to the current progress state
    nonisolated var currentProgress: MLProgress { // nonisolated to allow direct observation if @Observable
        return progress
    }

    func startTraining(trainer: MyModelTrainer, epochs: Int) async throws {
        // Ensure only one training task is active at a time
        if trainingTask != nil {
            print("Training already in progress or not properly cleared.")
            // Or throw an error
            return
        }

        // Start the training task and store its handle
        trainingTask = Task {
            let (model, progress) = try await trainer.trainCustomImageClassifier(epochs: epochs)
            // The progress object returned here is the same one we're observing.
            // The actor's role here is more about managing the *lifecycle* of the training
            // and potentially providing a unified interface for multiple MLProgress instances
            // or derived state.
            return model
        }
    }

    func cancelTraining() async {
        trainingTask?.cancel()
        // Update the MLProgress status to cancelled safely
        await progress.update(status: .cancelled)
        print("Training cancelled.")
        trainingTask = nil
    }

    func waitForCompletion() async throws -> MLModel {
        guard let task = trainingTask else {
            throw TrainingError.noTrainingInProgress
        }
        do {
            let model = try await task.value
            trainingTask = nil // Clear the task once completed
            return model
        } catch {
            trainingTask = nil // Clear the task even on error
            throw error
        }
    }

    enum TrainingError: Error {
        case noTrainingInProgress
    }
}
