/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Save as architecture.dot
digraph G {
    rankdir=TB;
    compound=true;
    node [shape=box, style="rounded,filled", fillcolor="lightgray"];

    // Subgraph for Shared Packages
    subgraph cluster_shared {
        label = "Shared Packages";
        style = dashed;
        node [fillcolor="lightblue"];
        
        pkg_eslint [label="eslint-config"];
        pkg_ts [label="typescript-config"];
        pkg_utils [label="utils"];
        pkg_hooks [label="hooks"];
        pkg_ui [label="ui"];
    }

    // Subgraph for Applications
    subgraph cluster_apps {
        label = "Applications";
        style = dashed;
        node [fillcolor="lightgreen"];
        
        app_web [label="Next.js Web"];
        app_mobile [label="Expo Mobile"];
    }

    // Subgraph for Build Pipeline
    subgraph cluster_pipeline {
        label = "Turborepo Pipeline";
        style = solid;
        node [fillcolor="wheat"];
        
        task_shared [label="Build: Shared"];
        task_web [label="Build: Web"];
        task_mobile [label="Build: Mobile"];
        orchestrator [label="Turborepo", shape=ellipse, fillcolor="gold"];
    }

    // Dependency Edges (Code)
    app_web -> pkg_ui;
    app_web -> pkg_utils;
    app_web -> pkg_hooks;
    app_web -> pkg_eslint;
    app_web -> pkg_ts;

    app_mobile -> pkg_ui;
    app_mobile -> pkg_utils;
    app_mobile -> pkg_hooks;
    app_mobile -> pkg_eslint;
    app_mobile -> pkg_ts;

    pkg_ui -> pkg_utils;
    pkg_ui -> pkg_hooks;

    // Pipeline Edges (Execution Order)
    orchestrator -> task_shared [label="triggers"];
    orchestrator -> task_web [label="triggers"];
    orchestrator -> task_mobile [label="triggers"];

    // Critical Dependency: Shared must build before Apps
    task_shared -> task_web [label="depends on", style=dashed, color=red];
    task_shared -> task_mobile [label="depends on", style=dashed, color=red];

    // Invisible edges to enforce rank ordering if needed
    {rank = same; task_shared; orchestrator}
    {rank = same; task_web; task_mobile}
}
