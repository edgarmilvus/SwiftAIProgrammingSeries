
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

@available(macOS 14.0, iOS 18.0, *) // @Observable requires macOS 14.0+
@Observable
class ModelLoadingMonitor {
    var isLoading: Bool = false
    var progress: Double = 0.0 // 0.0 to 1.0
    var statusMessage: String = "Idle"
    var errorMessage: String?
    
    private let dataLoader: LLMDataLoader
    
    init(dataLoader: LLMDataLoader) {
        self.dataLoader = dataLoader
    }

    func startLoadingModel() async {
        isLoading = true
        progress = 0.0
        statusMessage = "Loading model..."
        errorMessage = nil

        do {
            // Simulate progress for a large file read
            for i in 0...100 {
                try await Task.sleep(for: .milliseconds(20)) // Simulate I/O latency
                await MainActor.run { // Update @Observable properties on the main actor
                    self.progress = Double(i) / 100.0
                    self.statusMessage = "Loading: \(Int(self.progress * 100))%"
                }
            }
            
            // Actual model loading using the dataLoader
            let result = try await dataLoader.loadLLMModel()
            await MainActor.run {
                self.statusMessage = result
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.statusMessage = "Error loading model."
            }
        }
        await MainActor.run {
            self.isLoading = false
        }
    }
}

// Example SwiftUI View:
@available(macOS 14.0, iOS 18.0, *)
struct ModelLoadingView: View {
    @State private var monitor: ModelLoadingMonitor
    @State private var fileAccessManager = FileAccessManager() // For bookmark creation
    @State private var llmDataLoader: LLMDataLoader // For setting bookmark

    init() {
        let dataLoader = LLMDataLoader()
        _llmDataLoader = State(initialValue: dataLoader)
        _monitor = State(initialValue: ModelLoadingMonitor(dataLoader: dataLoader))
    }

    var body: some View {
        VStack {
            Text(monitor.statusMessage)
                .font(.headline)
            
            if monitor.isLoading {
                ProgressView(value: monitor.progress)
                    .progressViewStyle(.linear)
                    .padding()
            }
            
            if let error = monitor.errorMessage {
                Text("Error: \(error)")
                    .foregroundStyle(.red)
            }
            
            Button("Select LLM Model File") {
                // macOS specific file picker
                #if os(macOS)
                let openPanel = NSOpenPanel()
                openPanel.canChooseFiles = true
                openPanel.canChooseDirectories = false
                openPanel.allowsMultipleSelection = false
                
                if openPanel.runModal() == .OK, let url = openPanel.url {
                    Task {
                        do {
                            let bookmarkData = try await fileAccessManager.createAndStoreBookmark(for: url)
                            llmDataLoader.setLLMModelBookmark(data: bookmarkData)
                            await monitor.startLoadingModel() // Start loading after bookmark is set
                        } catch {
                            await MainActor.run {
                                monitor.errorMessage = error.localizedDescription
                            }
                        }
                    }
                }
                #endif
            }
            .disabled(monitor.isLoading)
            .padding()
        }
        .padding()
    }
}
