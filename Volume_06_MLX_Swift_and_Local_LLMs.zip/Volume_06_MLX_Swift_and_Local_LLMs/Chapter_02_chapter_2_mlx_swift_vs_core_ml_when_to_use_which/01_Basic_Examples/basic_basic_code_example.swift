
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - Swift Package Manager Dependency
// To use MLX Swift, you need to add it as a dependency in your project's Package.swift file.
// This snippet shows how you would declare the dependency.

/*
 import PackageDescription

 let package = Package(
     name: "PhotoFilterApp",
     platforms: [
         .iOS(.v18), // MLX Swift requires iOS 18+ or macOS 15+
         .macOS(.v15)
     ],
     products: [
         .library(
             name: "PhotoFilterApp",
             targets: ["PhotoFilterApp"]),
     ],
     dependencies: [
         // Add the mlx-swift package. Use 'main' branch for the latest,
         // or a specific version tag for stability.
         .package(url: "https://github.com/ml-explore/mlx-swift.git", branch: "main")
     ],
     targets: [
         .target(
             name: "PhotoFilterApp",
             dependencies: [
                 .product(name: "MLX", package: "mlx-swift"), // Core MLX operations
                 .product(name: "MLXNN", package: "mlx-swift") // Neural Network modules
             ]),
         .testTarget(
             name: "PhotoFilterAppTests",
             dependencies: ["PhotoFilterApp"]),
     ]
 )
 */

import Foundation
import MLX // Core MLX framework for tensor operations
import MLXNN // MLX Neural Network module for building models
import CoreML // For Core ML comparison
import Vision // For Vision framework integration with Core ML (conceptual)
import UIKit // For UIImage and pixel buffer operations (conceptual in real app)
import SwiftUI // For @MainActor context and ObservableObject

// MARK: - 1. MLX Swift: Building a Custom Inference Engine (Learnable Edge Detector)

/// A simple neural network module for detecting edges in an image.
/// This module uses a single 2D convolutional layer, making it a learnable filter.
/// It inherits from `MLXNN.Module`, which is the base class for all neural
/// network layers and models in MLX Swift. `MLXNN.Module` automatically tracks
/// trainable parameters (like weights and biases) and provides infrastructure
/// for functional transformations (e.g., gradient computation).
@available(iOS 18.0, macOS 15.0, *)
class SimpleEdgeDetector: MLXNN.Module {
    /// The 2D convolutional layer. This is the core component that will learn
    /// to detect edges. Its weights and biases are the trainable parameters
    /// of this module.
    let convolution: MLXNN.Conv2d

    /// Initializes the `SimpleEdgeDetector` module.
    ///
    /// - Parameters:
    ///   - inputChannels: The number of input channels for the image (e.g., 3 for RGB, 1 for grayscale).
    ///   - outputChannels: The number of output channels for the edge map (e.g., 1 for a single grayscale edge map).
    required init(inputChannels: Int, outputChannels: Int) {
        // Initialize a 2D convolutional layer.
        // - `inputChannels`: Matches the input image's channel count.
        // - `outputChannels`: Determines the number of feature maps produced.
        // - `kernelSize: 3`: A 3x3 filter is common for edge detection.
        // - `padding: .same`: Ensures the output spatial dimensions (height, width)
        //   remain the same as the input, preventing reduction in image size.
        //   The weights of this `Conv2d` layer are randomly initialized by default
        //   and are designed to be learned during a training process.
        self.convolution = MLXNN.Conv2d(
            inputChannels: inputChannels,
            outputChannels: outputChannels,
            kernelSize: 3,
            padding: .same
        )

        // Always call `super.init()` for `MLXNN.Module` subclasses.
        super.init()
    }

    /// Performs the forward pass of the neural network.
    /// This method defines the sequence of operations that transform the input
    /// into the output, constructing the computation graph.
    ///
    /// - Parameter x: The input `MLXArray`, typically representing an image tensor.
    ///                For `MLXNN.Conv2d`, the default expected shape is
    ///                `[batch_size, height, width, channels]`.
    /// - Returns: The output `MLXArray` containing the processed image (e.g., the detected edge map).
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Apply the convolutional layer to the input.
        // MLX employs 'lazy evaluation': this call does not immediately execute
        // the convolution. Instead, it adds a node to an internal computation graph.
        // The actual computation is deferred until the result is explicitly needed
        // (e.g., by calling `.eval()` or accessing its data).
        return convolution(x)
    }
}

/// A utility class to encapsulate the logic for processing images using either
/// MLX Swift for custom filters or Core ML for deployed models.
@available(iOS 18.0, macOS 15.0, *)
class PhotoFilterProcessor {

    private var mlxEdgeDetector: SimpleEdgeDetector?
    private var coreMLEdgeDetector: MLModel? // Placeholder for Core ML model

    init() {
        // Initialization can be deferred or done here.
    }

    // MARK: - MLX Swift Operations

    /// **Step 1: Initialize and Prepare MLX Swift Model**
    /// This function demonstrates instantiating our custom MLX Swift model.
    func setupMLXModel() {
        // For a typical RGB image, we use 3 input channels.
        // For an edge map, we usually want 1 output channel (grayscale).
        mlxEdgeDetector = SimpleEdgeDetector(inputChannels: 3, outputChannels: 1)
        print("MLX Swift SimpleEdgeDetector initialized.")

        // Under the Hood: MLX models are automatically placed on the most capable
        // device available (GPU if present, otherwise CPU). MLX leverages Apple's
        // Unified Memory Architecture (UMA), which allows CPU and GPU to share
        // the same physical memory. This enables 'zero-copy' operations where
        // data can be accessed by both processors without explicit transfers,
        // significantly enhancing performance.
    }

    /// **Step 2: Prepare Input Data for MLX Swift**
    /// This function simulates converting an image into an `MLXArray`.
    /// In a real application, you would convert `CVPixelBuffer` data (from `UIImage`
    /// or camera frames) directly into an `MLXArray` to leverage zero-copy benefits.
    ///
    /// - Parameters:
    ///   - width: The width of the simulated image.
    ///   - height: The height of the simulated image.
    ///   - channels: The number of channels (e.g., 3 for RGB).
    /// - Returns: An `MLXArray` representing the input image tensor.
    func prepareMLXInput(width: Int, height: Int, channels: Int) -> MLXArray {
        // Simulate an image with random pixel values for demonstration.
        // The shape convention for MLXNN.Conv2d is `[batch_size, height, width, channels]`.
        let inputShape: [Int] = [1, height, width, channels] // Batch size of 1
        let inputImage = MLXArray.randomUniform(low: 0.0, high: 1.0, shape: inputShape, type: MLX.float32)
        print("MLX Swift input data prepared with shape: \(inputImage.shape)")

        // Under the Hood: When creating an `MLXArray` from existing memory (e.g., a `CVPixelBuffer`'s base address),
        // MLX can often wrap that memory directly, avoiding a copy. This is a key benefit of Unified Memory.
        // Example (conceptual, requires CVPixelBuffer and image processing):
        /*
         func mlxArrayFromPixelBuffer(_ pixelBuffer: CVPixelBuffer) -> MLXArray? {
             CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
             defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }

             guard let baseAddress = CVPixelBufferGetBaseAddress(pixelBuffer) else { return nil }
             let width = CVPixelBufferGetWidth(pixelBuffer)
             let height = CVPixelBufferGetHeight(pixelBuffer)
             let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
             let channels = 4 // Assuming BGRA for example

             // Create a Data object that doesn't copy the bytes
             let data = Data(bytesNoCopy: baseAddress, count: height * bytesPerRow, deallocator: .none)

             // Create MLXArray (adjust shape and type as needed, e.g., to RGB float)
             // This would typically involve converting BGRA to RGB and normalizing,
             // or using a custom kernel if MLX supports direct BGRA input.
             let mlxInput = MLXArray(data: data, shape: [1, height, width, channels], type: MLX.uint8)
             return mlxInput // Further processing needed for float32 RGB
         }
         */
        return inputImage
    }

    /// **Step 3: Perform Inference with MLX Swift**
    /// This function demonstrates executing a forward pass through the MLX Swift model.
    ///
    /// - Parameter input: The input `MLXArray` representing the image.
    /// - Returns: The output `MLXArray` (e.g., the detected edge map), or `nil` if the model isn't initialized.
    func performMLXInference(input: MLXArray) -> MLXArray? {
        guard let model = mlxEdgeDetector else {
            print("MLX model not initialized.")
            return nil
        }

        print("Performing MLX Swift inference...")
        // Perform the forward pass. This call builds the computation graph,
        // but due to lazy evaluation, the actual computation is not yet executed.
        let output = model(input)

        // Under the Hood: MLX uses lazy evaluation. The computation graph is built
        // as you chain `MLXArray` operations and `MLXNN.Module` calls.
        // The actual GPU/CPU computation only occurs when you explicitly
        // request the result (e.g., by calling `.eval()`, accessing `.item()`,
        // or converting to a Swift Array). This allows MLX to optimize the
        // entire graph before execution.
        output.eval() // Force evaluation of the computation graph to get the concrete result.
        print("MLX Swift inference complete. Output shape: \(output.shape)")
        return output
    }

    /// **Step 4: Demonstrate MLX Functional Transformation: `valueAndGradient`**
    /// This step showcases MLX's powerful automatic differentiation capabilities,
    /// which are fundamental for training neural networks. We define a simple
    /// loss function and then use `valueAndGradient` to compute both the loss
    /// value and the gradients of that loss with respect to the model's parameters.
    ///
    /// - Parameters:
    ///   - input: The input `MLXArray` (e.g., the original image).
    ///   - target: A dummy `MLXArray` representing the desired output (ground truth edge map).
    func demonstrateMLXTrainingStep(input: MLXArray, target: MLXArray) {
        guard let model = mlxEdgeDetector else {
            print("MLX model not initialized for training step.")
            return
        }

        print("\nDemonstrating MLX Swift functional transformation (valueAndGradient)...")

        // Define a simple Mean Squared Error (MSE) loss function as a closure.
        // This closure takes the model, input, and target, and returns the loss.
        let lossFn = { (model: SimpleEdgeDetector, input: MLXArray, target: MLXArray) -> MLXArray in
            let prediction = model(input) // Get the model's prediction
            // Calculate MSE Loss: mean of the squared differences between prediction and target.
            let loss = MLX.mean(MLX.square(prediction - target))
            return loss
        }

        // `valueAndGradient` is a higher-order function that takes another function (`lossFn`)
        // and returns a new function. When this new function is called with the model
        // and data, it computes:
        // 1. The value of the `lossFn` (the loss itself).
        // 2. The gradients of the loss with respect to the trainable parameters
        //    of the `model` (e.g., `convolution.weight` and `convolution.bias`).
        let (lossValue, gradients) = valueAndGradient(lossFn)(model, input, target)

        // Force evaluation of the loss and gradients.
        // These are also lazy MLXArray computations that need to be materialized.
        lossValue.eval()
        gradients.eval()

        print("Computed Loss Value: \(lossValue.item(Float.self)!)")
        print("Gradients for model parameters computed.")
        // Example: Accessing gradients for a specific parameter
        if let convWeightGradients = gradients.parameters["convolution.weight"] {
            print("  Gradients for convolution.weight (first item): \(convWeightGradients.item(Float.self) ?? 0.0)")
        }

        // Under the Hood: This is how optimizers (e.g., SGD, Adam) work in MLX.
        // After computing gradients, an optimizer would use them to update the
        // model's parameters to minimize the loss: `optimizer.update(model, gradients)`.
    }

    // MARK: - Core ML Operations (for comparison)

    /// **Step 5: Load and Prepare Core ML Model (Conceptual)**
    /// This function describes how a pre-trained `.mlmodel` file would be loaded.
    /// Core ML models are typically generated from models trained in other frameworks
    /// (like PyTorch, TensorFlow, JAX) and then converted using `coremltools`.
    func setupCoreMLModel() {
        // In a real app, you would add your compiled `.mlmodel` file to your Xcode project.
        // Xcode automatically generates a Swift class for it (e.g., `YourPretrainedEdgeDetectorModel`).

        // Example of loading a Core ML model:
        /*
         let config = MLModelConfiguration()
         // Core ML allows explicit selection of compute units for optimal performance.
         // .all (default): Core ML decides (CPU, GPU, Neural Engine).
         // .cpuOnly: Guarantees CPU usage.
         // .gpuOnly: Prioritizes GPU.
         // .neuralEngine: Prioritizes Apple Neural Engine (ANE) for supported layers.
         config.computeUnits = .neuralEngine // Try to use ANE for best performance on neural networks

         do {
             // Replace `YourPretrainedEdgeDetectorModel` with your actual model class name.
             coreMLEdgeDetector = try YourPretrainedEdgeDetectorModel(configuration: config).model
             print("Core ML Edge Detector loaded and configured for .neuralEngine.")
         } catch {
             print("Failed to load Core ML model: \(error.localizedDescription)")
         }
         */
        print("\nCore ML Model setup (conceptual): A pre-trained .mlmodel would be loaded here.")
        print("Core ML models are optimized for deployment on Apple hardware (CPU, GPU, Neural Engine) for inference.")
        print("Unlike MLX Swift, Core ML primarily focuses on inference of static, pre-trained models.")
    }

    /// **Step 6: Perform Inference with Core ML (Conceptual)**
    /// This function demonstrates the typical workflow for using a Core ML model,
    /// often integrated with the Vision framework for image-based tasks.
    ///
    /// - Parameter uiImage: A `UIImage` to process.
    /// - Returns: A `UIImage` representing the processed output, or `nil`.
    func performCoreMLInference(uiImage: UIImage) async -> UIImage? {
        guard let coreMLEdgeDetector else {
            print("Core ML model not initialized.")
            return nil
        }

        print("Performing Core ML inference (conceptual)...")

        // For image processing tasks, Core ML is frequently used via the Vision framework.
        // Vision handles image preprocessing, model input/output conversion, and result interpretation.

        /*
         do {
             // 1. Create a VNCoreMLModel from your MLModel.
             let visionModel = try VNCoreMLModel(for: coreMLEdgeDetector)

             // 2. Create a VNCoreMLRequest.
             // The completion handler processes the model's output.
             let request = VNCoreMLRequest(model: visionModel) { request, error in
                 if let error = error {
                     print("Core ML Vision request failed: \(error.localizedDescription)")
                     return
                 }

                 // Process results. The type of results depends on your model's output.
                 // For an image filter, it might be a VNPixelBufferObservation.
                 if let observations = request.results as? [VNPixelBufferObservation],
                    let outputPixelBuffer = observations.first?.pixelBuffer {
                     print("Core ML produced a pixel buffer output.")
                     // Convert CVPixelBuffer to UIImage for display
                     // let ciImage = CIImage(cvPixelBuffer: outputPixelBuffer)
                     // let context = CIContext()
                     // if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
                     //     return UIImage(cgImage: cgImage)
                     // }
                 } else {
                     print("Core ML request returned unexpected results.")
                 }
             }

             // 3. Perform the request on the input image.
             let handler = VNImageRequestHandler(uiImage: uiImage, options: [:])
             try handler.perform([request])

             print("Core ML inference complete via Vision framework (conceptual).")
             // In a real async function, you'd use a continuation to return the result.
         } catch {
             print("Core ML Vision setup failed: \(error.localizedDescription)")
         }
         */
        print("Core ML inference complete (conceptual). Output would be a processed image or prediction.")
        return nil // Placeholder
    }
}

// MARK: - Application Entry Point (Simulated for a SwiftUI App)

/// A simulated `AppDelegate` or `ViewModel` to orchestrate the MLX Swift and Core ML examples.
/// The `@MainActor` attribute ensures that all properties and methods of this class
/// are executed on the main thread, which is crucial for UI updates in SwiftUI.
@available(iOS 18.0, macOS 15.0, *)
@MainActor
class AppDelegateSimulator: ObservableObject {
    private let processor = PhotoFilterProcessor()

    // Published properties to update a SwiftUI view
    @Published var mlxOutputDescription: String = "MLX Output: N/A"
    @Published var coreMLOutputDescription: String = "Core ML Output: N/A"

    /// Runs a simulation of the photo filtering process, demonstrating both MLX Swift and Core ML.
    func runSimulation() async {
        print("--- Starting Photo Filter App Simulation ---")

        // MARK: MLX Swift Workflow Demonstration
        print("\n--- MLX Swift Workflow ---")
        processor.setupMLXModel()
        // Prepare a dummy input image (256x256 RGB)
        let mlxInput = processor.prepareMLXInput(width: 256, height: 256, channels: 3)
        if let mlxOutput = processor.performMLXInference(input: mlxInput) {
            // In a real app, `mlxOutput` (an MLXArray) would be converted back
            // to a `CVPixelBuffer` or `UIImage` for display.
            // For this example, we just print its shape and a sample value.
            self.mlxOutputDescription = "MLX Output: Shape \(mlxOutput.shape), First item: \(mlxOutput.item(Float.self) ?? 0.0)"
        }

        // Demonstrate the training step (valueAndGradient)
        let dummyTarget = MLXArray.randomUniform(low: 0.0, high: 1.0, shape: mlxInput.shape, type: MLX.float32)
        processor.demonstrateMLXTrainingStep(input: mlxInput, target: dummyTarget)

        // MARK: Core ML Workflow Demonstration (Conceptual)
        print("\n--- Core ML Workflow (Conceptual) ---")
        processor.setupCoreMLModel()
        // Use a placeholder image for the conceptual Core ML inference
        let dummyUIImage = UIImage(systemName: "photo")!
        _ = await processor.performCoreMLInference(uiImage: dummyUIImage)
        self.coreMLOutputDescription = "Core ML Output: (Details in console for conceptual example)"

        print("\n--- Photo Filter App Simulation Complete ---")
    }
}

/*
// Example of how to integrate and run this in a simple SwiftUI App's `ContentView`:

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    // Use @StateObject to manage the lifecycle of the simulator
    @StateObject private var appSimulator = AppDelegateSimulator()

    var body: some View {
        VStack(spacing: 20) {
            Text("Photo Filter App")
                .font(.largeTitle)
                .bold()

            Text(appSimulator.mlxOutputDescription)
                .font(.headline)
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(8)

            Text(appSimulator.coreMLOutputDescription)
                .font(.headline)
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(8)

            Button("Run ML Simulation") {
                Task {
                    await appSimulator.runSimulation()
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.purple)
        }
        .padding()
        .onAppear {
            // Optional: You can uncomment this to run the simulation automatically on app launch.
            // Task {
            //     await appSimulator.runSimulation()
            // }
        }
    }
}

// To preview in Xcode:
@available(iOS 18.0, macOS 15.0, *)
#Preview {
    ContentView()
}
*/

// MARK: - ### Common Pitfalls

This section highlights common issues and best practices when developing machine learning applications with Swift on Apple platforms, particularly when integrating MLX Swift and Core ML.

1.  **Forgetting `@MainActor` for UI Updates from Async Contexts:**
    *   **Problem**: When performing computationally intensive ML tasks (like MLX inference or Core ML requests) in `async` functions or on background threads, attempting to directly update `@Published` properties of an `ObservableObject` (which typically drive SwiftUI views) will lead to runtime warnings or crashes. UI updates *must* occur on the main thread.
    *   **Solution**: Mark your `ObservableObject` class with `@MainActor` (as shown in `AppDelegateSimulator`) to ensure all its methods and property access are main-actor isolated. Alternatively, explicitly dispatch UI updates to the main actor using `await MainActor.run { ... }` within your async methods.
    *   **Example**:
        