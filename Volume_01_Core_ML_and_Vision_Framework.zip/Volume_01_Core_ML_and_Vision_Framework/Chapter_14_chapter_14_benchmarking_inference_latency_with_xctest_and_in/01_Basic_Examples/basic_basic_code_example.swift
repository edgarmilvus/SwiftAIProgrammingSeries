
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import XCTest
import Foundation // For Thread.sleep
import CoreML // Though we're mocking, good to include for context
import Vision // Also good for context
import SwiftUI // For @MainActor context in ViewModel

// MARK: - Real-world App Context: A Camera App

/// Represents a simplified image structure for our mock classifier.
struct AppImage {
    let id = UUID()
    let data: Data // In a real app, this might be a CVPixelBuffer or UIImage
    let description: String // A textual description for mock classification
}

/// Represents the output of our image classification.
struct ImageClassificationResult {
    let label: String
    let confidence: Double
    let timestamp: Date = Date()
}

/// A mock Core ML model wrapper for image classification.
/// In a real application, this would load and interact with an actual .mlmodel file.
/// For this basic example, we simulate the inference process.
class MockImageClassifier {
    private let modelName: String
    private let simulatedLatencyMilliseconds: UInt32

    /// Initializes the mock classifier.
    /// - Parameters:
    ///   - modelName: The name of the model being mocked.
    ///   - simulatedLatencyMilliseconds: The amount of time (in milliseconds) this mock
    ///     classifier will "sleep" to simulate inference latency.
    init(modelName: String, simulatedLatencyMilliseconds: UInt32 = 100) {
        self.modelName = modelName
        self.simulatedLatencyMilliseconds = simulatedLatencyMilliseconds
        print("[\(modelName)] MockImageClassifier initialized with simulated latency: \(simulatedLatencyMilliseconds)ms")
    }

    /// Simulates performing an image classification inference.
    /// In a real Core ML scenario, this would involve `VNCoreMLRequest` and `VNImageRequestHandler`.
    /// - Parameter image: The `AppImage` to classify.
    /// - Returns: An `ImageClassificationResult` representing the classification.
    func classify(image: AppImage) -> ImageClassificationResult {
        // Simulate actual ML inference work.
        // In a real Core ML app, this would involve:
        // 1. Preprocessing the image (e.g., resizing, normalizing to CVPixelBuffer).
        // 2. Creating a VNCoreMLRequest from VNCoreMLModel.
        // 3. Performing the request with VNImageRequestHandler.
        // 4. Processing the VNClassificationObservation results.

        // For this basic example, we just simulate the time taken.
        // Thread.sleep blocks the current thread, simulating a synchronous, time-consuming operation.
        Thread.sleep(forTimeInterval: Double(simulatedLatencyMilliseconds) / 1000.0)

        // Return a dummy result based on the image description
        let label = image.description.contains("cat") ? "Cat" : "Dog"
        return ImageClassificationResult(label: label, confidence: 0.95)
    }
}

/// ViewModel for a hypothetical camera app feature that performs on-device image classification.
/// This class would typically live in the main app target and interact with SwiftUI views.
@MainActor // All properties and methods of this class will run on the main actor by default
class CameraAppViewModel: ObservableObject {
    private let classifier: MockImageClassifier

    @Published var latestClassification: ImageClassificationResult?
    @Published var isClassifying: Bool = false

    /// Initializes the ViewModel with a classifier.
    /// - Parameter classifier: The image classifier instance to use.
    init(classifier: MockImageClassifier) {
        self.classifier = classifier
    }

    /// Performs image classification on a given image.
    /// The actual classification is performed off the main actor to keep the UI responsive.
    /// UI updates are then brought back to the main actor.
    func performClassification(on image: AppImage) {
        isClassifying = true
        latestClassification = nil

        // Perform the potentially long-running classification on a background thread.
        // `Task.detached` is used here to explicitly run the classification work
        // on a background thread, preventing UI freezes.
        Task.detached {
            let result = self.classifier.classify(image: image)

            // Update UI on the main actor after classification is complete.
            // `await MainActor.run` ensures these updates are safely performed on the main thread.
            await MainActor.run {
                self.latestClassification = result
                self.isClassifying = false
                print("Classification complete: \(result.label) with confidence \(result.confidence)")
            }
        }
    }
}

// MARK: - Benchmarking Inference Latency with XCTest

/// XCTestCase subclass to benchmark the inference latency of our mock image classifier.
/// This class would typically live in a separate 'Tests' target in your Xcode project.
final class ImageClassificationPerformanceTests: XCTestCase {

    var classifier: MockImageClassifier!
    var testImage: AppImage!

    /// Sets up the test environment before each test method is run.
    override func setUpWithError() throws {
        try super.setUpWithError()
        // 1. Initialize our mock classifier with a known simulated latency.
        //    This `classifier` instance is the component whose performance we want to measure.
        classifier = MockImageClassifier(modelName: "AnimalClassifier", simulatedLatencyMilliseconds: 150) // Simulate 150ms latency
        // 2. Create a dummy image for classification. This represents the input to our model.
        testImage = AppImage(data: Data(), description: "A test image of a cat")
    }

    /// Tears down the test environment after each test method is run.
    override func tearDownWithError() throws {
        // 3. Clean up resources after each test to ensure no memory leaks or interference.
        classifier = nil
        testImage = nil
        try super.tearDownWithError()
    }

    /// Benchmarks the performance of a single image classification inference.
    /// The `measure` block executes the enclosed code multiple times
    /// and collects performance metrics (like CPU time, elapsed time).
    func testImageClassificationLatency() {
        print("\n--- Starting Performance Test: testImageClassificationLatency ---")
        // 4. The core of performance testing: the `measure` block.
        self.measure {
            // This is the critical code block whose performance we want to measure.
            // In a real Core ML scenario, this would be the actual call to your
            // Core ML model's prediction method (e.g., `model.prediction(input:...)`)
            // or the Vision framework's request handler (`requestHandler.perform(...)`).
            _ = classifier.classify(image: testImage)
        }
        print("--- Performance Test Complete: testImageClassificationLatency ---\n")
    }

    /// Benchmarks the performance of classifying multiple images in a batch (or sequence).
    /// This demonstrates how to measure a sequence of operations, useful for throughput analysis.
    func testBatchImageClassificationLatency() {
        print("\n--- Starting Performance Test: testBatchImageClassificationLatency ---")
        let batchSize = 10
        // Create a batch of dummy images for classification.
        let images = (0..<batchSize).map { i in
            AppImage(data: Data(), description: "Image \(i) of a dog")
        }

        // 5. Measure the cumulative time taken to classify a batch of images.
        self.measure {
            for image in images {
                _ = classifier.classify(image: image)
            }
        }
        print("--- Performance Test Complete: testBatchImageClassificationLatency ---\n")
    }
}

// MARK: - Explanation

1.  **Real-world Context: Camera App Integration**
    We've set up a scenario with a `CameraAppViewModel` that interacts with an `ImageClassifier`.
    *   `AppImage` and `ImageClassificationResult`: Simple data structures representing image input and classification output.
    *   `MockImageClassifier`: This class simulates a Core ML model's `predict` method. It uses `Thread.sleep` to introduce a configurable `simulatedLatencyMilliseconds` (e.g., 150ms) to mimic the time a real model would take for inference. This allows us to focus on the benchmarking mechanism without needing to set up an actual `.mlmodel` file.
    *   `CameraAppViewModel`: An `@MainActor` class (common for SwiftUI ViewModels) that demonstrates how an app would call the classifier. It uses `Task.detached` to perform the potentially long-running classification off the main thread and `await MainActor.run` to safely update UI-related properties back on the main thread, ensuring a responsive user interface.

2.  **XCTestCase Setup for Performance Benchmarking**
    *   `ImageClassificationPerformanceTests`: This is a standard `XCTestCase` subclass. In an Xcode project, it would reside in a dedicated 'Tests' target.
    *   `setUpWithError()`: This method is executed before each test function runs. It's used to initialize the test environment. Here, we create an instance of our `MockImageClassifier` with a specified `simulatedLatencyMilliseconds` (150ms) and a `testImage`. This ensures that every performance test starts with a clean, consistent state.
    *   `tearDownWithError()`: This method runs after each test function completes. It's crucial for cleaning up resources, preventing memory leaks, or unintended side effects between tests.

3.  **The `measure` Block: Core of Performance Testing**
    *   `func testImageClassificationLatency()`: This is our primary performance test method. Performance test methods conventionally start with `test`.
    *   `self.measure { ... }`: This is the central XCTest API for performance measurement.
        *   **How it works:** XCTest executes the code within this closure multiple times (by default, 10 iterations). It then collects various performance metrics, including the average execution time, CPU usage, and memory footprint across these runs.
        *   **What to measure:** The code inside the `measure` block should *only* be the specific operation whose performance you want to evaluate. In our example, it's `_ = classifier.classify(image: testImage)`. In a real Core ML app, this would be the direct call to your `MLModel`'s `prediction` method or the Vision framework's `VNImageRequestHandler.perform` method with your `VNCoreMLRequest`.
        *   **Results:** After running the test (via Xcode's Test Navigator), a grey diamond icon will appear next to the test method. Clicking this icon reveals a detailed performance report, showing the average time taken, standard deviation, and other metrics.

4.  **Benchmarking Multiple Operations: `testBatchImageClassificationLatency()`**
    *   This method extends the concept to measure the cumulative performance of a sequence of operations.
    *   It simulates classifying a `batchSize` (e.g., 10) of images within a single `measure` block.
    *   This is particularly useful for evaluating the throughput of your model or the total latency for processing a collection of inputs, which is common in scenarios like processing multiple frames from a video or scanning multi-page documents.

5.  **Running and Analyzing Performance Tests in Xcode**
    *   **Execution:** In Xcode, open the Test Navigator (Cmd+6). Locate the `ImageClassificationPerformanceTests` class and click the play button next to `testImageClassificationLatency` or `testBatchImageClassificationLatency`.
    *   **Results:** Once the test completes, a grey diamond icon will appear.
        *   **Setting Baselines:** The first time you run a performance test, you can click the "Set Baseline" button (or the upward arrow icon) to establish a performance benchmark.
        *   **Regression Detection:** In subsequent runs, if the measured performance deviates significantly (e.g., gets slower) from the established baseline by more than a configurable threshold, the test will fail. This automatically alerts you to performance regressions, making performance testing an integral part of your continuous integration pipeline.
        *   **Instruments Integration:** You can also click the "Profile" button (a timer icon) to launch the test in Instruments. This provides a much deeper analysis of CPU usage, memory allocations, energy impact, and other system metrics during the test execution, helping you pinpoint the exact cause of performance issues.

### Common Pitfalls

1.  **Forgetting `@MainActor` for UI Updates from Async Contexts:**
    Core ML inference, especially when using Vision, often executes on background threads or dedicated ML queues to keep the UI responsive. If you attempt to update UI elements (e.g., `UILabel.text`, `UIImageView.image`) directly from the completion handler of an asynchronous inference call, you will encounter runtime warnings or crashes because all UI manipulations must occur on the main thread.
    **Solution:** Always dispatch UI updates back to the main actor. With Swift's modern concurrency, this is best achieved by marking UI-related properties/methods with `@MainActor` or by explicitly using `await MainActor.run { ... }` within `Task` blocks, as demonstrated in our `CameraAppViewModel`.

2.  **Retaining Core ML Models Unnecessarily:**
    `MLModel` instances (and their Vision counterparts like `VNCoreMLModel`) can consume significant memory and computational resources. Loading a model multiple times or holding onto instances longer than they are actively needed can lead to excessive memory pressure, especially on devices with limited resources.
    **Solution:** Load your `MLModel` once and reuse the instance throughout its lifecycle. If your application uses multiple models for different features, consider lazy loading them when a feature is activated and potentially releasing them when no longer in use.

3.  **Ignoring `MLModel` Compute Unit Selection:**
    Core ML allows you to specify which hardware unit should perform the inference: `.cpuOnly`, `.gpuAndNeuralEngine` (the default, leveraging GPU and Apple Neural Engine), or `.all` (attempts GPU/Neural Engine, falls back to CPU).
    **Pitfall:** Not explicitly considering the `MLModel.Configuration().computeUnits` can lead to suboptimal performance. For instance, a very small model might incur more overhead from data transfer to the GPU/Neural Engine than it gains in processing speed, potentially making `.cpuOnly` faster. Conversely, for large, complex models, failing to utilize the dedicated hardware will drastically increase inference time.
    **Solution:** Always benchmark your model with different `computeUnits` settings on your target devices to identify the most efficient configuration for your specific model and hardware.
    