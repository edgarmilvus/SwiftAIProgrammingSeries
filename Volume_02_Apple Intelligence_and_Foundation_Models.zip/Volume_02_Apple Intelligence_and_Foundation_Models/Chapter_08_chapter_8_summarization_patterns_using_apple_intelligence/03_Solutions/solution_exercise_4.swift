
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftUI
import NaturalLanguage // Contains TextGenerationService

@available(iOS 18.0, macOS 15.0, *)
struct MeetingSummarizerView: View {
    @State private var transcript: String = """
    **Meeting: Q4 Planning & Review**
    **Date:** October 26, 2024
    **Attendees:** Alice (PM), Bob (Eng Lead), Carol (Marketing), David (Sales)

    **Agenda:**
    1. Q3 Performance Review
    2. Q4 Project Prioritization
    3. Marketing Strategy for New Product
    4. Action Items & Next Steps

    **Discussion:**

    **1. Q3 Performance Review (Alice)**
    Alice presented Q3 results. Revenue was up 5% YoY, but slightly below target due to delays in Project Alpha. Project Beta exceeded expectations. Customer satisfaction scores remained high (92%). David highlighted strong sales in the enterprise segment, but noted a dip in SMB.

    **2. Q4 Project Prioritization (Bob)**
    Bob discussed the engineering roadmap. Project Gamma (new AI feature) is high priority for Q4. Project Delta (backend refactor) is also critical for scalability. There was a debate about resources between Gamma and Delta. Consensus was to prioritize Gamma with 70% resources, Delta with 30% for foundational work. Alice emphasized the need for clear milestones.

    **3. Marketing Strategy for New Product (Carol)**
    Carol outlined the launch plan for 'Nexus'. Proposed a phased rollout, starting with early access for key partners, followed by a public beta. Discussed budget allocation for digital ads and influencer campaigns. David suggested a joint webinar with a key enterprise client. Carol will explore this.

    **4. Action Items & Next Steps**
    - Alice: Follow up with engineering on Project Gamma milestones.
    - Bob: Allocate engineering resources (70% Gamma, 30% Delta).
    - Carol: Develop detailed Nexus launch plan, investigate joint webinar with David.
    - David: Provide list of potential enterprise clients for Nexus early access.
    - All: Next meeting scheduled for November 9th to review Gamma progress and Nexus launch plan.
    """
    @State private var summary: String = "Generated summary will appear here."
    @State private var selectedLength: SummaryLength = .medium
    @State private var focusKeywords: String = ""
    @State private var isSummarizing: Bool = false
    @State private var showingErrorAlert: Bool = false
    @State private var errorMessage: String = ""

    enum SummaryLength: String, CaseIterable, Identifiable {
        case short = "Short"
        case medium = "Medium"
        case long = "Long"
        var id: String { self.rawValue }
    }

    var body: some View {
        VStack {
            Text("Meeting Transcript")
                .font(.headline)
            TextEditor(text: $transcript)
                .frame(minHeight: 200)
                .border(Color.gray, width: 1)
                .padding([.horizontal, .bottom])

            Picker("Summary Length", selection: $selectedLength) {
                ForEach(SummaryLength.allCases) { length in
                    Text(length.rawValue).tag(length)
                }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)

            TextField("Focus Keywords (e.g., 'action items', 'decisions')", text: $focusKeywords)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .autocorrectionDisabled()

            Button {
                Task {
                    await generateMeetingSummary()
                }
            } label: {
                if isSummarizing {
                    ProgressView()
                } else {
                    Text("Generate Meeting Summary")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isSummarizing || transcript.isEmpty)
            .padding()

            Text("Summary")
                .font(.headline)
            TextEditor(text: $summary)
                .frame(minHeight: 150)
                .border(Color.gray, width: 1)
                .padding([.horizontal, .top])
        }
        .navigationTitle("Meeting Minutes Summarizer")
        .padding()
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }

    @available(iOS 18.0, macOS 15.0, *)
    private func generateMeetingSummary() async {
        isSummarizing = true
        errorMessage = ""
        showingErrorAlert = false
        do {
            let service = TextGenerationService()
            
            // Craft the prompt based on user preferences
            var prompt = "Summarize the following meeting transcript. "
            
            switch selectedLength {
            case .short:
                prompt += "Make the summary very concise, 2-3 sentences max. "
            case .medium:
                prompt += "Provide a medium-length summary, focusing on key points and decisions. "
            case .long:
                prompt += "Generate a detailed summary, including all important discussion points, decisions, and action items. "
            }
            
            if !focusKeywords.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                prompt += "Specifically focus on: \(focusKeywords). "
            } else {
                prompt += "Ensure all critical information is included. "
            }
            
            prompt += "\n\nTranscript:\n\(transcript)"
            
            let generatedText = try await service.generate(prompt)
            summary = generatedText
        } catch {
            errorMessage = "Failed to generate summary: \(error.localizedDescription)"
            showingErrorAlert = true
            summary = "Error: Could not generate summary."
            print("Error generating summary: \(error)")
        }
        isSummarizing = false
    }
}

// Minimal App structure for demonstration
/*
@main
@available(iOS 18.0, macOS 15.0, *)
struct MeetingApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                MeetingSummarizerView()
            }
        }
    }
}
*/
