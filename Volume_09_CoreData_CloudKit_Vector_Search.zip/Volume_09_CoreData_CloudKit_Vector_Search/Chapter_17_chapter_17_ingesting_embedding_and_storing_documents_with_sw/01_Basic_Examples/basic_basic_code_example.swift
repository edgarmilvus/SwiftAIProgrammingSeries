
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import SwiftData
import NaturalLanguage

// MARK: - Models

/// Represents a document within the application.
/// This model is designed to store both the human-readable content 
/// and the high-dimensional vector used for semantic similarity searches.
@available(iOS 18.0, macOS 15.0, *)
@Model
final class Document {
    /// The actual text content of the document.
    var content: String
    
    /// The semantic embedding of the content.
    /// This is a high-dimensional vector (array of Floats) representing 
    /// the "meaning" of the text in a mathematical space.
    var embedding: [Float]
    
    /// The date the document was ingested.
    var timestamp: Date
    
    /// Initializes a new Document with content and a pre-calculated embedding.
    /// - Parameters:
    ///   - content: The raw text string.
    ///   - embedding: The vector representation of the text.
    init(content: String, embedding: [Float]) {
        self.content = content
        self.embedding = embedding
        self.timestamp = Date()
    }
}

// MARK: - Services

/// A service responsible for transforming natural language strings into 
/// mathematical vector representations (embeddings).
@available(iOS 18.0, macOS 15.0, *)
actor EmbeddingService {
    
    /// Errors that can occur during the embedding process.
    enum EmbeddingError: Error {
        case embeddingNotFound
        case processingFailed
    }
    
    /// Generates a vector embedding for a given string using Apple's NaturalLanguage framework.
    /// - Parameter text: The input string to embed.
    /// - Returns: An array of Floats representing the semantic meaning.
    /// - Throws: `EmbeddingError` if the embedding cannot be generated.
    func generateEmbedding(for text: String) async throws -> [Float] {
        // We use NLEmbedding to access pre-trained word/sentence embeddings.
        // In a production-grade app, you might use a custom CoreML Transformer model.
        guard let embedding = NLEmbedding.wordEmbedding(for: .english) else {
            throw EmbeddingError.embeddingNotFound
        }
        
        // We split the text into tokens (words) and average their embeddings.
        // This is a "Bag of Embeddings" approach, which is a simplified 
        // version of more complex sentence-transformer architectures.
        let words = text.lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
        
        guard !words.isEmpty else {
            throw EmbeddingError.processingFailed
        }
        
        var combinedVector: [Float] = []
        var validWordCount: Float = 0
        
        for word in words {
            // Retrieve the vector for the specific word.
            if let vector = embedding.vector(for: word) {
                // Sum the vectors component-wise.
                if combinedVector.isEmpty {
                    combinedVector = vector
                } else {
                    for i in 0..<min(combinedVector.count, vector.count) {
                        combinedVector[i] += vector[i]
                    }
                }
                validWordCount += 1
            }
        }
        
        // If no words were found in the embedding dictionary, throw error.
        guard validWordCount > 0 else {
            throw EmbeddingError.processingFailed
        }
        
        // Average the vector to normalize the magnitude.
        return combinedVector.map { $0 / validWordCount }
    }
}

// MARK: - View Model

/// The orchestration layer that manages the interaction between the UI, 
/// the EmbeddingService, and the SwiftData ModelContext.
@available(iOS 18.0, macOS 15.0, *)
@MainActor
@Observable
final class DocumentViewModel {
    /// The service used for generating embeddings.
    private let embeddingService = EmbeddingService()
    
    /// The SwiftData context used for persistence.
    private let modelContext: ModelContext
    
    /// The current text being typed by the user.
    var inputText: String = ""
    
    /// Indicates if an ingestion process is currently running.
    var isProcessing: Bool = false
    
    /// Error message for the UI to display.
    var errorMessage: String?

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    /// The primary workflow: Ingest text -> Generate Embedding -> Save to SwiftData.
    func ingestDocument() async {
        guard !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return
        }
        
        isProcessing = true
        errorMessage = nil
        
        do {
            // 1. Generate the semantic vector.
            // This happens on the EmbeddingService actor to avoid blocking the Main Thread.
            let vector = try await embeddingService.generateEmbedding(for: inputText)
            
            // 2. Create the SwiftData model instance.
            let newDocument = Document(content: inputText, embedding: vector)
            
            // 3. Persist the model.
            // Since this function is @MainActor, we can safely interact with the context.
            modelContext.insert(newDocument)
            
            // 4. Clear the input field.
            inputText = ""
            
        } catch {
            errorMessage = "Failed to ingest document: \(error.localizedDescription)"
            print("Error: \(error)")
        }
        
        isProcessing = false
    }
}

// MARK: - UI Layer

@available(iOS 18.0, macOS 15.0, *)
struct DocumentScannerView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Document.timestamp, order: .reverse) private var documents: [Document]
    
    @State private var viewModel: DocumentViewModel?

    var body: some View {
        NavigationStack {
            VStack {
                // Input Section
                VStack(alignment: .leading) {
                    Text("New Document Content")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    TextEditor(text: Binding(
                        get: { viewModel?.inputText ?? "" },
                        set: { viewModel?.inputText = $0 }
                    ))
                    .frame(height: 150)
                    .padding(4)
                    .background(Color(uiColor: .secondarySystemBackground))
                    .cornerRadius(8)
                    
                    Button(action: {
                        Task { await viewModel?.ingestDocument() }
                    }) {
                        HStack {
                            if viewModel?.isProcessing == true {
                                ProgressView()
                                    .padding(.trailing, 5)
                            }
                            Text(viewModel?.isProcessing == true ? "Processing..." : "Ingest & Embed")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(viewModel?.isProcessing == true || viewModel?.inputText.isEmpty == true)
                }
                .padding()

                // List Section
                List {
                    Section("Stored Documents (Semantic Storage)") {
                        ForEach(documents) { doc in
                            VStack(alignment: .leading) {
                                Text(doc.content)
                                    .font(.headline)
                                    .lineLimit(1)
                                
                                HStack {
                                    Text("Vector Size: \(doc.embedding.count) dims")
                                    Spacer()
                                    Text(doc.timestamp, style: .date)
                                }
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                            }
                        }
                        .onDelete(perform: deleteDocuments)
                    }
                }
            }
            .navigationTitle("Smart Scanner")
            .onAppear {
                // Initialize the ViewModel with the environment's context.
                if viewModel == nil {
                    viewModel = DocumentViewModel(modelContext: modelContext)
                }
            }
            .overlay {
                if let error = viewModel?.errorMessage {
                    Text(error)
                        .foregroundStyle(.red)
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                }
            }
        }
    }

    private func deleteDocuments(offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(documents[index])
        }
    }
}

// MARK: - App Entry Point

@main
struct SmartScannerApp: App {
    // Define the container for SwiftData.
    var container: ModelContainer = {
        let schema = Schema([Document.self])
        let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        do {
            return try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            DocumentScannerView()
                .modelContainer(container)
        }
    }
}
