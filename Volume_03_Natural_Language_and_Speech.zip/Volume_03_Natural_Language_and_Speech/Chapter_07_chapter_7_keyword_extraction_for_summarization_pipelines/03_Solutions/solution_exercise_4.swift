
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import NaturalLanguage
import Foundation
import Combine // For a reactive approach to updates

@available(iOS 18.0, macOS 15.0, *)
class LiveKeywordTracker {
    private let stopWords: Set<String> = [
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "and", "or", "but", "for", "nor", "so", "yet",
        "in", "on", "at", "by", "with", "from", "of", "to", "into", "onto",
        "this", "that", "these", "those", "it", "its", "he", "him", "his", "she", "her", "hers",
        "we", "us", "our", "ours", "you", "your", "yours", "they", "them", "their", "theirs",
        "i", "me", "my", "mine", "what", "which", "who", "whom", "whose", "where", "when", "why", "how",
        "am", "can", "will", "would", "should", "could", "may", "might", "must",
        "do", "does", "did", "don't", "doesn't", "didn't",
        "have", "has", "had", "not", "no", "yes", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such",
        "only", "own", "same", "so", "than", "too", "very", "s", "t", "can't", "will", "just", "don't", "shouldn't", "now", "d", "ll", "m", "o", "re", "ve", "y", "ain", "aren", "couldn", "didn", "doesn", "hadn", "hasn", "haven", "isn", "ma", "mightn", "mustn", "needn", "shan", "shouldn", "wasn", "weren", "won", "wouldn"
    ]

    private var textBuffer: String = "" {
        didSet {
            // Trim buffer if it exceeds max word count
            let words = textBuffer.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }
            if words.count > maxBufferSize {
                // Keep only the last 'maxBufferSize' words
                textBuffer = words.suffix(maxBufferSize).joined(separator: " ")
            }
        }
    }
    private let maxBufferSize: Int = 500 // Max words to keep in buffer for analysis
    private let updateInterval: TimeInterval = 1.5 // Update keywords every 1.5 seconds

    // Use a PassthroughSubject for reactive updates, or a simple closure/delegate
    let keywordsPublisher = PassthroughSubject<[String], Never>()
    private(set) var currentKeywords: [String] = [] {
        didSet {
            // Only send update if keywords have actually changed
            if oldValue != currentKeywords {
                keywordsPublisher.send(currentKeywords)
            }
        }
    }

    private var extractionWorkItem: DispatchWorkItem?
    private let processingQueue = DispatchQueue(label: "com.example.keywordProcessor", qos: .userInitiated)

    init() { }

    // Helper to check if a word is a stop word (case-insensitive)
    private func isStopWord(_ word: String) -> Bool {
        return stopWords.contains(word.lowercased())
    }

    // Helper to extract keywords from a given string (reusing logic from Exercise 2)
    private func extractKeywords(from text: String) -> [String] {
        guard !text.isEmpty else { return [] }

        let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        tagger.string = text

        var lemmatizedWords: [String] = [] // Stores filtered, lemmatized words for bigram generation
        var keywordFrequencies: [String: Int] = [:] // Stores frequencies for both single words and bigrams

        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation, .omitOther]) { lexicalClassTag, tokenRange in
            guard let lexicalClassTag = lexicalClassTag else { return true }

            // Consider nouns, proper nouns, verbs for keywords
            guard lexicalClassTag == .noun || lexicalClassTag == .properNoun || lexicalClassTag == .verb else {
                return true
            }

            let word = String(text[tokenRange])
            let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma).0
            let lemmatizedWord = (lemmaTag?.rawValue ?? word).lowercased()

            if !isStopWord(lemmatizedWord) {
                lemmatizedWords.append(lemmatizedWord)
                keywordFrequencies[lemmatizedWord, default: 0] += 1
            }
            return true
        }

        // Generate Bigrams
        if lemmatizedWords.count >= 2 {
            for i in 0..<(lemmatizedWords.count - 1) {
                let word1 = lemmatizedWords[i]
                let word2 = lemmatizedWords[i+1]

                // Bigram filtering heuristic: at least one word must not be a stop word
                if !isStopWord(word1) || !isStopWord(word2) {
                    let bigram = "\(word1) \(word2)"
                    keywordFrequencies[bigram, default: 0] += 1
                }
            }
        }

        // Sort and Select Top 10 Keywords (or fewer if not enough)
        let sortedKeywords = keywordFrequencies.sorted { (entry1, entry2) -> Bool in
            if entry1.value != entry2.value {
                return entry1.value > entry2.value
            } else {
                return entry1.key < entry2.key
            }
        }
        
        return sortedKeywords.prefix(10).map { $0.key }
    }

    func addTextChunk(_ chunk: String) {
        // 1. Append new chunk to textBuffer.
        textBuffer.append(chunk)

        // 2. Invalidate previous work item if it exists (debouncing).
        extractionWorkItem?.cancel()

        // 3. Schedule a new work item with a delay for keyword extraction.
        let workItem = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            let keywords = self.extractKeywords(from: self.textBuffer)
            
            // Update currentKeywords on the main thread as it's a published property
            DispatchQueue.main.async {
                self.currentKeywords = keywords
            }
        }
        self.extractionWorkItem = workItem
        processingQueue.asyncAfter(deadline: .now() + updateInterval, execute: workItem)
    }
}

// Example usage simulation
@available(iOS 18.0, macOS 15.0, *)
func simulateLiveTranscription() {
    print("--- Starting Live Transcription Simulation ---")
    let tracker = LiveKeywordTracker()

    // Subscribe to updates (e.g., in a UIViewController)
    var cancellables = Set<AnyCancellable>()
    tracker.keywordsPublisher
        .sink { keywords in
            print("[\(Date().formatted(date: .none, time: .shortened))] Live Keywords: \(keywords)")
        }
        .store(in: &cancellables)

    let chunks = [
        "Hello everyone, welcome to our quarterly business review. ",
        "Today, we will discuss financial performance and market trends. ",
        "Our revenue grew significantly in the last quarter. ",
        "We also have some exciting new product announcements. ",
        "The team has been working hard on innovation. ",
        "Looking forward to a productive discussion and Q&A session.",
        "Let's dive into the details of our growth strategy. ",
        "We need to focus on customer acquisition and retention. ",
        "The market is highly competitive, so innovation is key. "
    ]

    var currentChunkIndex = 0
    let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { timer in // Add chunks every 0.5s
        if currentChunkIndex < chunks.count {
            tracker.addTextChunk(chunks[currentChunkIndex])
            currentChunkIndex += 1
        } else {
            timer.invalidate()
            print("--- Transcription simulation ended. ---")
            // Give a moment for the last debounced task to complete
            DispatchQueue.main.asyncAfter(deadline: .now() + tracker.updateInterval + 0.5) {
                exit(0) // Terminate process gracefully after final update
            }
        }
    }

    // Keep the program running for the timer.
    // In a real app, this would be handled by the app's run loop.
    RunLoop.current.add(timer, forMode: .common)
    RunLoop.current.run()
}

// Uncomment to run the example in a playground or app
// simulateLiveTranscription()
