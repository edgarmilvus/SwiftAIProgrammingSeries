
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

        import Foundation
        import Observation // For @Observable

        @available(iOS 18.0, *)
        @Observable
        class TrainingProgressMonitor {
            var totalTrials: Int = 0
            var completedTrials: Int = 0
            var currentProgress: Double {
                totalTrials > 0 ? Double(completedTrials) / Double(totalTrials) : 0.0
            }
            var currentBestAccuracy: Double = 0.0
            var statusMessage: String = "Initializing..."

            func updateProgress(completed: Int, total: Int) {
                self.completedTrials = completed
                self.totalTrials = total
                self.statusMessage = "Running trial \(completed) of \(total)..."
            }

            func updateBestAccuracy(_ accuracy: Double) {
                if accuracy > currentBestAccuracy {
                    currentBestAccuracy = accuracy
                }
            }

            func setStatus(_ message: String) {
                statusMessage = message
            }
        }

        // Example integration into a tuning process:
        /*
        @available(iOS 18.0, *)
        func performHyperparameterTuningWithProgress(
            trainingData: MLDataTable,
            validationData: MLDataTable,
            monitor: TrainingProgressMonitor
        ) async {
            let learningRates = [0.001, 0.01, 0.1]
            let batchSizes = [16, 32, 64]
            let totalTrials = learningRates.count * batchSizes.count
            
            monitor.totalTrials = totalTrials
            monitor.setStatus("Starting hyperparameter tuning...")

            let tuner = HyperparameterTuner() // Our actor from before
            var completedCount = 0

            await withTaskGroup(of: Void.self) { group in
                for lr in learningRates {
                    for bs in batchSizes {
                        group.addTask {
                            await runHyperparameterTrial(
                                trainingData: trainingData,
                                validationData: validationData,
                                learningRate: lr,
                                batchSize: bs,
                                tuner: tuner
                            )
                            await MainActor.run { // Update @Observable on main actor
                                completedCount += 1
                                monitor.updateProgress(completed: completedCount, total: totalTrials)
                                if let best = await tuner.getBestResult() {
                                    monitor.updateBestAccuracy(best.validationAccuracy)
                                }
                            }
                        }
                    }
                }
            }
            
            await MainActor.run {
                monitor.setStatus("Tuning complete!")
            }
            // ... rest of the logic
        }
        */
        