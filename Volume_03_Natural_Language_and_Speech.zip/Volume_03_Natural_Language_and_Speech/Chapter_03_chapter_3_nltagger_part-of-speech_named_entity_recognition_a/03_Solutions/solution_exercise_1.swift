
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage
import UIKit // For NSAttributedString attributes like .foregroundColor, .font

@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
func styledTextForPartsOfSpeech(text: String) -> NSAttributedString {
    let attributedString = NSMutableAttributedString(string: text)
    
    let tagger = NLTagger(tagSchemes: [.lexicalClass])
    tagger.string = text
    
    // Define styles for different parts of speech
    let nounAttributes: [NSAttributedString.Key: Any] = [
        .font: UIFont.systemFont(ofSize: 16, weight: .bold),
        .foregroundColor: UIColor.blue
    ]
    let verbAttributes: [NSAttributedString.Key: Any] = [
        .font: UIFont.italicSystemFont(ofSize: 16),
        .foregroundColor: UIColor.green
    ]
    let adjectiveAttributes: [NSAttributedString.Key: Any] = [
        .underlineStyle: NSUnderlineStyle.single.rawValue,
        .foregroundColor: UIColor.purple
    ]
    let adverbAttributes: [NSAttributedString.Key: Any] = [
        .foregroundColor: UIColor.orange
    ]
    
    // Enumerate tags and apply styles
    let fullRange = NSRange(text.startIndex..<text.endIndex, in: text)
    tagger.enumerateTags(in: fullRange, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation]) { tag, range in
        if let tag = tag {
            switch tag {
            case .noun:
                attributedString.addAttributes(nounAttributes, range: range)
            case .verb:
                attributedString.addAttributes(verbAttributes, range: range)
            case .adjective:
                attributedString.addAttributes(adjectiveAttributes, range: range)
            case .adverb:
                attributedString.addAttributes(adverbAttributes, range: range)
            default:
                // Apply default or no specific style for other parts of speech
                break
            }
        }
        return true // Continue enumeration
    }
    
    return attributedString
}
