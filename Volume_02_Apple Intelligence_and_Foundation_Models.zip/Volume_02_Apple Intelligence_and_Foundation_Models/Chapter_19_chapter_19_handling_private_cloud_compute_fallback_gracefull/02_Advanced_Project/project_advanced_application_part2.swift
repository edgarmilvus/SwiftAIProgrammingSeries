
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Combine // For @Published in a ViewModel context (not shown fully, but implied)

// MARK: - 1. Core Data Models and Enums

/// Represents a document or a part of it being processed.
struct DocumentPart {
    let id = UUID()
    let content: String
    let language: String = "en" // Assume English for simplicity
}

/// Defines the stylistic goals for rephrasing.
enum RephraseStyle: String, CaseIterable, Identifiable {
    case concise = "Concise & Direct"
    case formal = "Formal & Academic"
    case informal = "Informal & Conversational"
    case poetic = "Poetic & Evocative"
    case shakespearean = "Shakespearean Sonnet" // High complexity, likely PCC
    
    var id: String { self.rawValue }
    
    /// Heuristic to determine if a style is likely to require PCC.
    var requiresPCCLikely: Bool {
        switch self {
        case .poetic, .shakespearean: return true
        default: return false
        }
    }
}

/// Custom errors for AI processing.
enum ProcessingError: Error, LocalizedError {
    case onDeviceModelCapacityExceeded
    case privateCloudComputeUnavailable
    case privateCloudComputeFailed(String)
    case userDeniedPCC
    case invalidInput
    case unknown(Error)
    
    var errorDescription: String? {
        switch self {
        case .onDeviceModelCapacityExceeded:
            return "The on-device model could not handle the complexity or length of this request. Private Cloud Compute may be required."
        case .privateCloudComputeUnavailable:
            return "Private Cloud Compute is currently unavailable. Please check your network connection or try again later."
        case .privateCloudComputeFailed(let message):
            return "Private Cloud Compute failed: \(message)"
        case .userDeniedPCC:
            return "Private Cloud Compute was denied by the user."
        case .invalidInput:
            return "The input provided is invalid for this operation."
        case .unknown(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

// MARK: - 2. Conceptual Private Cloud Compute (PCC) Manager

/// A conceptual manager for interacting with Apple's Private Cloud Compute.
/// In a real scenario, this would be a system-provided API like `PrivateCloudComputeManager`.
@available(iOS 18.0, *)
class PCCManager {
    /// Represents a request to Private Cloud Compute.
    /// Crucially, this struct should contain only the necessary, non-identifying data.
    struct PCCRequest: Codable {
        let text: String
        let style: RephraseStyle
        let requestedQuality: String // e.g., "high", "standard"
    }

    /// Represents the response from Private Cloud Compute.
    struct PCCResponse: Codable {
        let rephrasedText: String
        let qualityAchieved: String // e.g., "high", "standard"
        let processingTimeMs: Int
    }

    /// Simulates requesting Private Cloud Compute for a task.
    /// - Parameters:
    ///   - request: The `PCCRequest` containing the task data.
    ///   - progress: An optional `Progress` object to report progress.
    /// - Returns: A `PCCResponse` upon successful completion.
    /// - Throws: `ProcessingError` if PCC fails or is unavailable.
    ///
    /// This method simulates network latency, processing time, and potential failures.
    /// **Under the Hood:** Apple's PCC ensures that data is encrypted end-to-end,
    /// processed on specialized, isolated servers, and deleted immediately after use.
    /// No logs or persistent identifiers are associated with the request.
    func requestPCC(
        for request: PCCRequest,
        progress: Progress? = nil
    ) async throws -> PCCResponse {
        print("PCCManager: Initiating Private Cloud Compute request for style '\(request.style.rawValue)'...")
        
        // Simulate network latency and processing time
        let totalUnits = 100
        progress?.totalUnitCount = Int64(totalUnits)
        
        for i in 0..<totalUnits {
            try await Task.sleep(for: .milliseconds(Double.random(in: 10...50))) // Simulate work
            progress?.completedUnitCount = Int64(i + 1)
            if Task.isCancelled {
                print("PCCManager: PCC request cancelled.")
                throw CancellationError()
            }
        }
        
        // Simulate potential PCC unavailability or failure
        if Bool.random(probability: 0.05) { // 5% chance of failure
            print("PCCManager: Simulated PCC failure.")
            throw ProcessingError.privateCloudComputeFailed("Service temporarily overloaded.")
        }
        
        // Simulate success
        let rephrased: String
        switch request.style {
        case .shakespearean:
            rephrased = "Hark, what light through yonder window breaks? It is the east, and Juliet is the sun! Forsooth, this text, by my troth, doth now possess a most noble and poetic guise."
        case .poetic:
            rephrased = "Whispers of dawn, a canvas of words, painted anew with hues of sentiment, finding rhythm in the silent spaces between."
        case .formal:
            rephrased = "The provided textual segment has undergone a comprehensive transformation, resulting in a refined and academically appropriate rendition."
        default:
            rephrased = "PCC rephrased: " + request.text.prefix(50) + "... (style: \(request.style.rawValue))"
        }
        
        print("PCCManager: Private Cloud Compute request completed successfully.")
        return PCCResponse(
            rephrasedText: rephrased,
            qualityAchieved: "high",
            processingTimeMs: Int.random(in: 1000...5000)
        )
    }
    
    /// Simulates the system-level prompt for user consent for PCC.
    /// - Returns: `true` if the user grants consent, `false` otherwise.
    /// **Under the Hood:** This would be handled by the OS, presenting a standardized
    /// prompt that explains what PCC is and its privacy guarantees.
    func requestUserConsentForPCC() async -> Bool {
        print("PCCManager: Requesting user consent for Private Cloud Compute...")
        // Simulate user interaction with a system dialog
        try? await Task.sleep(for: .seconds(1))
        let consent = Bool.random(probability: 0.8) // 80% chance of consent
        print("PCCManager: User consent \(consent ? "granted" : "denied").")
        return consent
    }
}

// MARK: - 3. On-Device AI Service (Conceptual)

/// A conceptual on-device AI service for text processing.
/// In a real scenario, this would be an API like `TextGenerationService`
/// or other on-device Apple Intelligence APIs.
@available(iOS 18.0, *)
class OnDeviceAIService {
    /// Simulates rephrasing text using an on-device model.
    /// - Parameters:
    ///   - text: The input text to rephrase.
    ///   - style: The desired `RephraseStyle`.
    /// - Returns: The rephrased text.
    /// - Throws: `ProcessingError.onDeviceModelCapacityExceeded` if the on-device model
    ///           cannot meet the request's complexity or if the input is too long.
    ///
    /// **Under the Hood:** On-device models run entirely on the user's device,
    /// ensuring maximum privacy and minimal latency for supported tasks.
    func rephraseOnDevice(text: String, style: RephraseStyle) async throws -> String {
        print("OnDeviceAIService: Attempting on-device rephrase for style '\(style.rawValue)'...")
        try await Task.sleep(for: .milliseconds(Int.random(in: 200...800))) // Simulate on-device processing
        
        // Simulate on-device model limitations:
        // - Very long text might exceed capacity.
        // - Complex styles might be out of scope for on-device models.
        let isTooLong = text.count > 300
        
        if style.requiresPCCLikely || isTooLong {
            print("OnDeviceAIService: On-device model capacity exceeded for style '\(style.rawValue)' or text length.")
            throw ProcessingError.onDeviceModelCapacityExceeded
        }
        
        // Simulate successful on-device rephrase
        let rephrased: String
        switch style {
        case .concise:
            rephrased = "On-device concise: " + text.prefix(50) + "..."
        case .formal:
            rephrased = "On-device formal: " + text.prefix(50) + "..."
        case .informal:
            rephrased = "On-device informal: " + text.prefix(50) + "..."
        default: // Should ideally not reach here if `requiresPCCLikely` is handled
            rephrased = "On-device default rephrased: " + text.prefix(50) + "..."
        }
        
        print("OnDeviceAIService: On-device rephrase completed successfully.")
        return rephrased
    }
}

// MARK: - 4. DocumentProcessor: Orchestrating AI Tasks with PCC Fallback

/// Manages AI-powered document processing, including on-device operations and PCC fallback.
@available(iOS 18.0, *)
class DocumentProcessor {
    private let onDeviceAIService: OnDeviceAIService
    private let pccManager: PCCManager
    
    /// Initializes the document processor with necessary AI services.
    init(onDeviceAIService: OnDeviceAIService = OnDeviceAIService(),
         pccManager: PCCManager = PCCManager()) {
        self.onDeviceAIService = onDeviceAIService
        self.pccManager = pccManager
    }
    
    /// Rephrases a given paragraph, attempting on-device first, then falling back to PCC if needed.
    /// - Parameters:
    ///   - paragraph: The text to rephrase.
    ///   - style: The desired `RephraseStyle`.
    ///   - usePCCIfAvailable: If `true`, allows fallback to PCC. If `false`, only attempts on-device.
    ///   - progress: An optional `Progress` object to report overall task progress.
    /// - Returns: The rephrased text.
    /// - Throws: `ProcessingError` if any stage of processing fails.
    func rephrase(
        paragraph: String,
        style: RephraseStyle,
        usePCCIfAvailable: Bool,
        progress: Progress? = nil
    ) async throws -> String {
        guard !paragraph.isEmpty else { throw ProcessingError.invalidInput }
        
        // Create a top-level progress object for the entire rephrase operation.
        // It will have two child operations: on-device attempt and potential PCC fallback.
        let overallProgress = progress ?? Progress.discreteProgress(totalUnitCount: 2)
        overallProgress.localizedDescription = "Rephrasing document content..."
        
        // 4.1 Attempt on-device rephrasing first.
        overallProgress.becomeCurrent(withPendingUnitCount: 1)
        do {
            let rephrasedText = try await onDeviceAIService.rephraseOnDevice(text: paragraph, style: style)
            overallProgress.resignCurrent()
            print("DocumentProcessor: Rephrased on-device successfully.")
            return rephrasedText
        } catch ProcessingError.onDeviceModelCapacityExceeded where usePCCIfAvailable {
            overallProgress.resignCurrent()
            print("DocumentProcessor: On-device model capacity exceeded. Preparing for PCC fallback.")
            
            // 4.2 If on-device fails due to capacity and PCC is allowed, proceed with PCC.
            overallProgress.becomeCurrent(withPendingUnitCount: 1)
            defer { overallProgress.resignCurrent() } // Ensure progress is resigned
            
            // 4.3 Request user consent for PCC.
            // This is a critical privacy step. The system will handle the UI prompt.
            let userGrantedConsent = await pccManager.requestUserConsentForPCC()
            guard userGrantedConsent else {
                print("DocumentProcessor: User denied PCC consent.")
                throw ProcessingError.userDeniedPCC
            }
            
            // 4.4 Formulate PCC request.
            // Ensure only necessary, non-identifying data is sent.
            let pccRequest = PCCManager.PCCRequest(
                text: paragraph,
                style: style,
                requestedQuality: "high"
            )
            
            // 4.5 Execute PCC request with its own child progress.
            let pccChildProgress = Progress(totalUnitCount: 100, parent: overallProgress, pendingUnitCount: 1)
            pccChildProgress.localizedDescription = "Using Private Cloud Compute..."
            pccChildProgress.cancellable = true // PCC operations should be cancellable
            
            do {
                let pccResponse = try await pccManager.requestPCC(for: pccRequest, progress: pccChildProgress)
                print("DocumentProcessor: Rephrased via Private Cloud Compute successfully.")
                return pccResponse.rephrasedText
            } catch {
                if let pccError = error as? ProcessingError {
                    print("DocumentProcessor: PCC operation failed: \(pccError.localizedDescription)")
                    throw pccError
                } else if error is CancellationError {
                    print("DocumentProcessor: PCC operation cancelled.")
                    throw error // Propagate cancellation
                } else {
                    print("DocumentProcessor: Unknown error during PCC: \(error.localizedDescription)")
                    throw ProcessingError.unknown(error)
                }
            }
        } catch {
            overallProgress.resignCurrent()
            print("DocumentProcessor: On-device rephrase failed with unexpected error: \(error.localizedDescription)")
            throw ProcessingError.unknown(error)
        }
    }
}

// MARK: - 5. ViewModel (Conceptual) for UI Interaction

/// A conceptual ViewModel to demonstrate how a SwiftUI View might interact
/// with the `DocumentProcessor` and observe progress.
@available(iOS 18.0, *)
class DocumentViewModel: ObservableObject {
    @Published var inputText: String = "The quick brown fox jumps over the lazy dog. This sentence demonstrates basic English syntax and is often used for typing tests. We will attempt to rephrase it in various styles to show the capabilities of our AI assistant."
    @Published var rephrasedText: String = ""
    @Published var selectedStyle: RephraseStyle = .concise
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var currentProgress: Progress?
    @Published var showPCCConfirmation: Bool = false // For a real UI, this would trigger a system sheet
    
    private let documentProcessor: DocumentProcessor
    private var rephraseTask: Task<Void, Never>?
    
    init(documentProcessor: DocumentProcessor = DocumentProcessor()) {
        self.documentProcessor = documentProcessor
    }
    
    /// Initiates the rephrasing process.
    func performRephrase() {
        rephraseTask?.cancel() // Cancel any ongoing task
        isLoading = true
        errorMessage = nil
        rephrasedText = ""
        
        let progress = Progress.discreteProgress(totalUnitCount: 100)
        currentProgress = progress
        
        rephraseTask = Task {
            do {
                let result = try await documentProcessor.rephrase(
                    paragraph: inputText,
                    style: selectedStyle,
                    usePCCIfAvailable: true, // Allow PCC fallback
                    progress: progress
                )
                await MainActor.run {
                    self.rephrasedText = result
                    self.isLoading = false
                    self.currentProgress = nil
                }
            } catch {
                await MainActor.run {
                    if let processingError = error as? ProcessingError {
                        self.errorMessage = processingError.localizedDescription
                    } else if error is CancellationError {
                        self.errorMessage = "Operation cancelled."
                    } else {
                        self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                    }
                    self.isLoading = false
                    self.currentProgress = nil
                }
            }
        }
    }
    
    /// Cancels the current rephrasing operation.
    func cancelRephrase() {
        rephraseTask?.cancel()
        rephraseTask = nil
        isLoading = false
        currentProgress = nil
        errorMessage = "Operation cancelled by user."
        print("ViewModel: Rephrase operation cancelled.")
    }
}

// MARK: - 6. Utility Extension for Random Booleans

extension Bool {
    /// Generates a random boolean with a given probability of being true.
    init(probability: Double) {
        self = Double.random(in: 0...1) < probability
    }
}

// MARK: - 7. Example Usage (Main App Entry Point or Test)

@available(iOS 18.0, *)
@main
struct SmartDocumentAssistantApp {
    static func main() async {
        let viewModel = DocumentViewModel()
        
        print("--- DocGenius: Smart Document Assistant Demo ---")
        
        // Scenario 1: Simple rephrase (on-device capable)
        print("\nScenario 1: Concise Rephrase (On-device expected)")
        viewModel.inputText = "This is a rather verbose sentence that needs to be made shorter and more to the point."
        viewModel.selectedStyle = .concise
        viewModel.performRephrase()
        await Task.sleep(for: .seconds(2)) // Allow time for on-device processing
        print("Result: \(viewModel.rephrasedText)")
        if let error = viewModel.errorMessage { print("Error: \(error)") }
        
        // Scenario 2: Complex rephrase (PCC fallback expected)
        print("\nScenario 2: Shakespearean Rephrase (PCC Fallback expected)")
        viewModel.inputText = "To be or not to be, that is the question. Whether 'tis nobler in the mind to suffer the slings and arrows of outrageous fortune, or to take arms against a sea of troubles, and by opposing end them."
        viewModel.selectedStyle = .shakespearean
        viewModel.performRephrase()
        // Allow more time for PCC processing and user consent simulation
        await Task.sleep(for: .seconds(7))
        print("Result: \(viewModel.rephrasedText)")
        if let error = viewModel.errorMessage { print("Error: \(error)") }
        
        // Scenario 3: PCC unavailable/failed (simulated)
        print("\nScenario 3: Poetic Rephrase with simulated PCC failure")
        // Temporarily make PCC fail often for this scenario
        let originalPCCRequest = PCCManager().requestPCC // Store original
        PCCManager.self.init(onDeviceAIService: OnDeviceAIService(), pccManager: PCCManager())
        // (This part is tricky to mock directly without changing the class. For a real test,
        // you'd inject a mock PCCManager. Here, we'll just rely on the random failure chance.)
        
        viewModel.inputText = "The sun sets slowly, casting long shadows across the quiet fields."
        viewModel.selectedStyle = .poetic
        viewModel.performRephrase()
        await Task.sleep(for: .seconds(7)) // Enough time for PCC attempt
        print("Result: \(viewModel.rephrasedText)")
        if let error = viewModel.errorMessage { print("Error: \(error)") }
        
        // Scenario 4: User denies PCC
        print("\nScenario 4: User denies PCC consent for Shakespearean rephrase")
        // To simulate user denial, we'd need to mock `requestUserConsentForPCC` to return false.
        // For this live demo, we'll rely on the 20% chance of denial.
        viewModel.inputText = "A tale told by an idiot, full of sound and fury, signifying nothing."
        viewModel.selectedStyle = .shakespearean
        viewModel.performRephrase()
        await Task.sleep(for: .seconds(7))
        print("Result: \(viewModel.rephrasedText)")
        if let error = viewModel.errorMessage { print("Error: \(error)") }
        
        print("\n--- Demo End ---")
    }
}
