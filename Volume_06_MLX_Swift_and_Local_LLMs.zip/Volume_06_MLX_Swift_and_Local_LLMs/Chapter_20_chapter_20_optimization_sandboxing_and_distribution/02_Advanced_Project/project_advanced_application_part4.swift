
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import SimpleTokenizer

/// Main application entry point or a view model.
@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
class DocumentSummarizerAppViewModel: ObservableObject {
    @Published var inputText: String = ""
    @Published var summaryText: String = "Summary will appear here..."
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let summarizerService: DocumentSummarizerService
    private let tokenizer: SimpleTokenizer

    init() {
        self.tokenizer = SimpleTokenizer()
        self.summarizerService = DocumentSummarizerService(tokenizer: tokenizer)
        
        // Asynchronously load the model when the app starts or view appears
        Task {
            await loadModel()
        }
    }

    /// Loads the MLX model asynchronously.
    private func loadModel() async {
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = nil
            self.summaryText = "Loading AI model..."
        }
        do {
            try await summarizerService.loadModel()
            DispatchQueue.main.async {
                self.summaryText = "Model ready. Enter text to summarize."
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = "Failed to load model: \(error.localizedDescription)"
                self.summaryText = "Error loading model."
            }
        }
        DispatchQueue.main.async {
            self.isLoading = false
        }
    }

    /// Triggers the summarization process.
    func performSummarization() async {
        guard !inputText.isEmpty else {
            DispatchQueue.main.async {
                self.errorMessage = "Input text cannot be empty."
            }
            return
        }

        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = nil
            self.summaryText = "Summarizing..."
        }

        do {
            let summary = try await summarizerService.summarize(text: inputText)
            DispatchQueue.main.async {
                self.summaryText = summary
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = "Summarization failed: \(error.localizedDescription)"
                self.summaryText = "Error during summarization."
            }
        }
        DispatchQueue.main.async {
            self.isLoading = false
        }
    }
}

// Example usage in a hypothetical SwiftUI View (conceptual)
/*
import SwiftUI

@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
struct SummarizerView: View {
    @StateObject private var viewModel = DocumentSummarizerAppViewModel()

    var body: some View {
        VStack {
            TextEditor(text: $viewModel.inputText)
                .frame(height: 200)
                .border(Color.gray, width: 1)
                .padding()
                .accessibilityLabel("Input text for summarization")

            Button("Summarize Document") {
                Task {
                    await viewModel.performSummarization()
                }
            }
            .disabled(viewModel.isLoading)
            .padding()

            if viewModel.isLoading {
                ProgressView()
                    .padding()
            }

            Text(viewModel.summaryText)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .accessibilityLabel("Summarized text output")

            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .navigationTitle("On-Device Summarizer")
        .padding()
    }
}

// To run this example in a playground or an actual app:
// let viewModel = DocumentSummarizerAppViewModel()
// Task {
//     await viewModel.loadModel() // This is already called in init, but explicit for clarity
//     viewModel.inputText = "This is a very long document about the benefits of on-device AI for privacy and efficiency. MLX Swift is a new framework by Apple that leverages unified memory to achieve high performance for machine learning workloads. It supports lazy evaluation and functional transformations, which are crucial for optimizing complex models like Large Language Models (LLMs). Deploying LLMs locally ensures that user data never leaves the device, providing superior privacy and allowing offline functionality. LoRA (Low-Rank Adaptation) is a technique used to fine-tune LLMs efficiently by only updating a small fraction of parameters, making model distribution smaller and training faster."
//     await viewModel.performSummarization()
//     print("Final Summary: \(viewModel.summaryText)")
//     if let error = viewModel.errorMessage {
//         print("Error: \(error)")
//     }
// }
*/
