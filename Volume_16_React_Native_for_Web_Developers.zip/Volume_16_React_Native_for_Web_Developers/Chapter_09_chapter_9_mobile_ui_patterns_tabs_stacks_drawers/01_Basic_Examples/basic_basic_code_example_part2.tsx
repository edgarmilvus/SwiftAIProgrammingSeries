/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

import React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

// Type definitions for our Tab Navigator parameters
// This ensures type safety when navigating between screens.
type TabParamList = {
  Dashboard: undefined;
  Settings: undefined;
};

const Tab = createBottomTabNavigator<TabParamList>();

/**
 * Dashboard Screen Component
 * Represents the main analytics view of the SaaS app.
 */
const DashboardScreen = () => {
  return (
    <View className="flex-1 items-center justify-center bg-slate-50">
      <Text className="text-2xl font-bold text-slate-800">SaaS Dashboard</Text>
      <Text className="mt-2 text-slate-500">Real-time Analytics View</Text>
      <View className="mt-8 p-4 bg-white rounded-lg shadow-md">
        <Text className="text-lg font-semibold text-emerald-600">Active Users: 1,240</Text>
        <Text className="text-sm text-slate-600">+12% from yesterday</Text>
      </View>
    </View>
  );
};

/**
 * Settings Screen Component
 * Represents the configuration area of the SaaS app.
 */
const SettingsScreen = () => {
  return (
    <View className="flex-1 items-center justify-center bg-slate-50">
      <Text className="text-2xl font-bold text-slate-800">Settings</Text>
      <Text className="mt-2 text-slate-500">Manage your account preferences</Text>
      <View className="mt-8 p-4 bg-white rounded-lg shadow-md border border-slate-200">
        <Text className="text-base text-slate-700">Notifications: On</Text>
        <Text className="text-base text-slate-700 mt-2">Theme: Light</Text>
      </View>
    </View>
  );
};

/**
 * Main Application Component
 * Wraps the app in NavigationContainer and SafeAreaProvider.
 * SafeAreaProvider ensures content doesn't overlap with device notches or status bars.
 */
export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="auto" />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={{
            // Common styling for all tabs
            headerStyle: { backgroundColor: '#f8fafc' }, // slate-50
            headerTintColor: '#0f172a', // slate-900
            headerTitleStyle: { fontWeight: '600' },
            tabBarActiveTintColor: '#0ea5e9', // sky-500 (Brand color)
            tabBarInactiveTintColor: '#64748b', // slate-500
            tabBarStyle: { backgroundColor: '#ffffff' }, // white background
          }}
        >
          <Tab.Screen 
            name="Dashboard" 
            component={DashboardScreen} 
            options={{
              // In a real app, these would be SVG icons imported from a library
              tabBarLabel: 'Analytics',
              // Placeholder for icon logic
              tabBarIcon: ({ color, size }) => (
                <View style={{ width: size, height: size, borderRadius: size/2, backgroundColor: color }} />
              ),
            }}
          />
          <Tab.Screen 
            name="Settings" 
            component={SettingsScreen} 
            options={{
              tabBarLabel: 'Settings',
              tabBarIcon: ({ color, size }) => (
                <View style={{ width: size, height: size, borderRadius: size/2, backgroundColor: color }} />
              ),
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
