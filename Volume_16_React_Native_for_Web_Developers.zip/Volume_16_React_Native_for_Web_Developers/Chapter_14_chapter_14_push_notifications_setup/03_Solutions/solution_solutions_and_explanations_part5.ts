/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph NotificationFlow {
    rankdir=LR;
    node [shape=box, style=rounded];

    Trigger [label="1. Database Trigger\n(e.g., INSERT on messages)"];
    Listener [label="2. Node.js Listener\n(Postgres NOTIFY/LISTEN)"];
    Queue [label="3. Redis Queue\n(BullMQ)", shape=cylinder];
    Worker [label="4. Worker Process\n(Event Loop)"];
    ExpoAPI [label="5. Expo Push API\n(HTTP Request)"];
    Device [label="6. Device\n(APNs/FCM)", shape=ellipse];
    UI [label="7. Client UI\n(SSE / Local Notification)"];

    Trigger -> Listener [label="Async I/O"];
    Listener -> Queue [label="Enqueue Job"];
    Worker -> Queue [label="Dequeue Job"];
    Worker -> ExpoAPI [label="HTTP Request\n(Non-blocking)"];
    ExpoAPI -> Device [label="Vendor Push"];
    Device -> UI [label="User Interaction"];

    // Feedback loop for status
    ExpoAPI -> Worker [label="Response (Ticket ID)"];
    Worker -> Queue [label="Store Status"];
    Queue -> UI [label="SSE Stream\n(Notification Status)"];
}
