
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog

/// Errors specific to the Privacy Engine operations.
enum PrivacyError: Error, LocalizedError {
    case epsilonBudgetExhausted
    case invalidSensitivity
    case dataClampingFailure
    
    var errorDescription: String? {
        switch self {
        case .epsilonBudgetExhausted: return "The privacy budget (epsilon) for this session has been exhausted."
        case .invalidSensitivity: return "Sensitivity must be a positive non-zero value."
        case .dataClampingFailure: return "Failed to clamp data within the specified bounds."
        }
    }
}

/// Represents the configuration for the Differential Privacy mechanism.
struct PrivacyConfig: Sendable {
    /// The privacy budget (epsilon). Lower values mean more privacy but more noise.
    let epsilon: Double
    /// The maximum possible change a single user's data can cause (the range of the data).
    let sensitivity: Double
    /// The bounds within which data must be clamped to maintain sensitivity guarantees.
    let lowerBound: Double
    let upperBound: Double
}

/// A protocol defining the requirements for a privacy-preserving engine.
protocol PrivacyEngineProtocol: Actor {
    func obfuscate(_ value: Double, using config: PrivacyConfig) async throws -> Double
}

/// An actor-based implementation of the Laplace Mechanism for Local Differential Privacy.
/// Using an `actor` ensures that the privacy budget and internal state are protected
/// from data races in a highly concurrent Swift 6 environment.
@available(iOS 18.0, *)
actor LaplacePrivacyEngine: PrivacyEngineProtocol {
    private let logger = Logger(subsystem: "com.ai.privacy.engine", category: "DifferentialPrivacy")
    
    /// The remaining privacy budget for the current session.
    /// As we send more data, we "spend" epsilon.
    private var remainingEpsilon: Double
    private let totalEpsilon: Double

    init(totalEpsilon: Double) {
        self.totalEpsilon = totalEpsilon
        self.remainingEpsilon = totalEpsilon
    }

    /// Obfuscates a raw numerical value using the Laplace Mechanism.
    ///
    /// The Laplace mechanism adds noise drawn from a Laplace distribution:
    /// Noise ~ Lap(sensitivity / epsilon)
    ///
    /// - Parameters:
    ///   - value: The raw, sensitive numerical value.
    ///   - config: The configuration defining epsilon, sensitivity, and bounds.
    /// - Returns: An obfuscated value that satisfies epsilon-differential privacy.
    /// - Throws: `PrivacyError` if the budget is exhausted or parameters are invalid.
    func obfuscate(_ value: Double, using config: PrivacyConfig) async throws -> Double {
        // 1. Check Privacy Budget
        guard remainingEpsilon >= config.epsilon else {
            logger.error("Privacy budget exhausted. Remaining: \(self.remainingEpsilon)")
            throw PrivacyError.epsilonBudgetExhausted
        }
        
        // 2. Validate Sensitivity
        guard config.sensitivity > 0 else {
            throw PrivacyError.invalidSensitivity
        }

        // 3. Data Clamping (Crucial for Sensitivity Control)
        // We must ensure the value is within [lowerBound, upperBound].
        // If a user provides a value outside this, it could disproportionately 
        // impact the noise calculation, breaking the privacy guarantee.
        let clampedValue = max(config.lowerBound, min(config.upperBound, value))
        
        // 4. Generate Laplace Noise
        // The scale (b) of the Laplace distribution is sensitivity / epsilon.
        let scale = config.sensitivity / config.epsilon
        let noise = generateLaplaceNoise(scale: scale)
        
        // 5. Deduct from Budget
        remainingEpsilon -= config.epsilon
        
        let obfuscatedValue = clampedValue + noise
        
        logger.info("Obfuscation complete. Original: \(value), Obfuscated: \(obfuscatedValue), Remaining Epsilon: \(self.remainingEpsilon)")
        
        return obfuscatedValue
    }

    /// Generates noise using the inverse transform sampling method for the Laplace distribution.
    /// Formula: X = μ - b * sgn(u) * ln(1 - 2|u|) where u is uniform in [-0.5, 0.5]
    private func generateLaplaceNoise(scale: Double) -> Double {
        // Generate a uniform random number in the range (-0.5, 0.5]
        let u = Double.random(in: -0.5...0.5)
        
        // Calculate the sign of u
        let sgn = u < 0 ? -1.0 : 1.0
        
        // Apply the inverse Laplace transform
        // We use the absolute value of u to ensure the logarithm argument is within (0, 1]
        let noise = -scale * sgn * log(1.0 - 2.0 * abs(u))
        return noise
    }
    
    /// Returns the current state of the privacy budget.
    func getRemainingBudget() -> Double {
        return remainingEpsilon
    }
}

/// A high-level service that manages the collection and transmission of telemetry data.
/// This class demonstrates how to integrate the PrivacyEngine into a real-world app workflow.
@available(iOS 18.0, *)
final class HealthTelemetryManager: Sendable {
    private let privacyEngine: any PrivacyEngineProtocol
    private let config: PrivacyConfig
    private let logger = Logger(subsystem: "com.ai.healthapp", category: "Telemetry")

    init(engine: any PrivacyEngineProtocol, config: PrivacyConfig) {
        self.privacyEngine = engine
        self.config = config
    }

    /// Collects a health metric (e.g., steps) and prepares it for cloud transmission.
    /// This is an asynchronous function to prevent blocking the UI during noise generation.
    func processAndSendMetric(_ rawMetric: Double) async {
        do {
            // Perform the privacy-preserving transformation
            let safeMetric = try await privacyEngine.obfuscate(rawMetric, using: config)
            
            // In a real app, this would be a network call to your AI backend
            try await uploadToCloud(value: safeMetric)
            
            logger.info("Successfully uploaded privacy-preserved metric: \(safeMetric)")
        } catch {
            logger.error("Failed to process telemetry: \(error.localizedDescription)")
            // In production, handle budget exhaustion by stopping telemetry collection
        }
    }

    private func uploadToCloud(value: Double) async throws {
        // Simulate network latency
        try await Task.sleep(for: .seconds(0.5))
        // Simulated network success
    }
}

// MARK: - Execution Example

@main
struct PrivacyAppDemo {
    static func main() async {
        print("🚀 Starting Privacy-Preserving Telemetry Demo...\n")

        // 1. Define our Privacy Parameters
        // We want to track "Steps per Day". 
        // Max steps we care about is 30,000 (Clamping).
        // Sensitivity is 30,000 (the max range a single user can change).
        // We allocate a total epsilon of 1.0 for the entire app session.
        let config = PrivacyConfig(
            epsilon: 0.1,        // Each data point "costs" 0.1 epsilon
            sensitivity: 30000.0, 
            lowerBound: 0.0, 
            upperBound: 30000.0
        )

        // 2. Initialize the Privacy Engine (Actor)
        let engine = LaplacePrivacyEngine(totalEpsilon: 1.0)

        // 3. Initialize the Telemetry Manager
        let manager = HealthTelemetryManager(engine: engine, config: config)

        // 4. Simulate a stream of user activity data
        let simulatedSteps = [5000.0, 12000.0, 45000.0, 8000.0, 15000.0, 2000.0, 10000.0, 500.0, 3000.0, 1200.0]

        print("📊 Processing \(simulatedSteps.count) data points...\n")

        // Use a TaskGroup to simulate concurrent data collection (e.g., from different sensors)
        await withTaskGroup(of: Void.self) { group in
            for steps in simulatedSteps {
                group.addTask {
                    await manager.processAndSendMetric(steps)
                }
            }
        }

        print("\n✅ Demo Complete.")
    }
}
