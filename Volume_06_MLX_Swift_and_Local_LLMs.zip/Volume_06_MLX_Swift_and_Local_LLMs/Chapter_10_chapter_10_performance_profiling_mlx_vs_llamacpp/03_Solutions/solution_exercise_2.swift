
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import MLX

func runExercise2() {
    print("--- Exercise 2: Understanding Lazy Evaluation and `MLX.eval()` Impact ---")

    let shape: [Int] = [1000, 1000] // Larger shape to make timing differences more noticeable

    // MARK: - 1. Construct a Chained Computation Graph
    let inputArray = MLXArray.randomUniform(low: 0.0, high: 1.0, shape: shape)
    print("1. Initial input array created with shape \(inputArray.shape).")

    // MARK: - 2. Observe Lazy Evaluation
    print("\n--- Defining the computation graph (Lazy Evaluation) ---")
    let defineGraphStartTime = CFAbsoluteTimeGetCurrent()

    let step1 = inputArray + 1.0 // Operation defined, not executed
    print("Operation 1 (add) defined. Intermediate result shape: \(step1.shape)")

    let step2 = step1 * 2.0 // Operation defined, not executed
    print("Operation 2 (multiply) defined. Intermediate result shape: \(step2.shape)")

    let step3 = MLX.sqrt(step2) // Operation defined, not executed
    print("Operation 3 (sqrt) defined. Intermediate result shape: \(step3.shape)")

    let finalResultLazy = MLX.mean(step3, axis: 0) // Operation defined, not executed
    print("Operation 4 (mean) defined. Final result shape: \(finalResultLazy.shape)")

    let defineGraphEndTime = CFAbsoluteTimeGetCurrent()
    print("Time to define the entire graph: \(defineGraphEndTime - defineGraphStartTime) seconds")
    print("Notice how quickly the graph is 'defined' – no heavy numerical computation has occurred yet.")

    // MARK: - 3. Profile with `MLX.eval()` at the End
    print("\n--- Evaluating the entire graph at once ---")
    let evalGraphStartTime = CFAbsoluteTimeGetCurrent()
    MLX.eval(finalResultLazy) // Trigger computation for the entire graph
    let evalGraphEndTime = CFAbsoluteTimeGetCurrent()
    print("Time to evaluate the entire graph: \(evalGraphEndTime - evalGraphStartTime) seconds")
    print("This time reflects the actual numerical computation, which is often significantly longer.")

    // MARK: - 4. Profile with `MLX.eval()` at Each Step (Anti-Pattern Demonstration)
    print("\n--- Evaluating at each step (Anti-pattern) ---")
    let evalStepByStepStartTime = CFAbsoluteTimeGetCurrent()

    let step1_eager = inputArray + 1.0
    MLX.eval(step1_eager) // Forces execution of step 1
    print("Operation 1 (add) evaluated. Result shape: \(step1_eager.shape)")

    let step2_eager = step1_eager * 2.0
    MLX.eval(step2_eager) // Forces execution of step 2
    print("Operation 2 (multiply) evaluated. Result shape: \(step2_eager.shape)")

    let step3_eager = MLX.sqrt(step2_eager)
    MLX.eval(step3_eager) // Forces execution of step 3
    print("Operation 3 (sqrt) evaluated. Result shape: \(step3_eager.shape)")

    let finalResultEager = MLX.mean(step3_eager, axis: 0)
    MLX.eval(finalResultEager) // Forces execution of step 4
    print("Operation 4 (mean) evaluated. Final result shape: \(finalResultEager.shape)")

    let evalStepByStepEndTime = CFAbsoluteTimeGetCurrent()
    print("Total time to evaluate step-by-step: \(evalStepByStepEndTime - evalStepByStepStartTime) seconds")

    print("\n// Discussion: You should observe that evaluating the entire graph at once (step 3) is generally more efficient than evaluating each step individually (step 4). This is because MLX's lazy evaluation allows the framework to optimize the entire computation graph before execution, potentially fusing operations, reducing memory transfers, and avoiding redundant computations. Frequent `MLX.eval()` calls break this optimization potential, forcing intermediate results to materialize and potentially incurring overhead.")
}

runExercise2()
