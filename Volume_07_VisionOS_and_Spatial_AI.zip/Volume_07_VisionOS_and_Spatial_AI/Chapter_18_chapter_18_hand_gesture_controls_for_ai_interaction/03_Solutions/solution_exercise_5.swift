
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import ARKit
import CoreML
import Vision

// 1. Data Structure for a Frame
struct HandFrame: Sendable {
    let jointDeltas: [Float] // Relative movement of all 21 joints
}

// 2. The Gesture Classifier Actor
actor GestureClassifier {
    private var frameBuffer: [HandFrame] = []
    private let windowSize = 30 // 30 frames of temporal context
    
    // Mock CoreML Model
    // In production: let model = try! MyGestureModel(configuration: .init())
    
    func addFrame(joints: [SIMD3<Float>], previousJoints: [SIMD3<Float>]?) -> String? {
        // 1. Feature Engineering: Calculate Deltas (Motion Invariance)
        var deltas: [Float] = []
        for i in 0..<joints.count {
            if let prev = previousJoints?[i] {
                let delta = joints[i] - prev
                deltas.append(contentsOf: [delta.x, delta.y, delta.z])
            } else {
                deltas.append(contentsOf: [0, 0, 0])
            }
        }
        
        let newFrame = HandFrame(jointDeltas: deltas)
        frameBuffer.append(newFrame)
        
        if frameBuffer.count > windowSize {
            frameBuffer.removeFirst()
        }
        
        // 2. Inference Trigger
        if frameBuffer.count == windowSize {
            return performInference()
        }
        
        return nil
    }
    
    private func performInference() -> String? {
        // Convert buffer to MLMultiArray
        // let input = try? MLMultiArray(frameBuffer.flatMap { $0.jointDeltas })
        // let output = try? model.prediction(input: input)
        
        // Mocking high-confidence detection
        let mockConfidence = Float.random(in: 0...1)
        if mockConfidence > 0.9 {
            return "Z_GESTURE"
        }
        return nil
    }
}

// 3. High-level Controller
@MainActor
class CustomGestureEngine: ObservableObject {
    private let classifier = GestureClassifier()
    private var lastJointPositions: [SIMD3<Float>]?
    
    @Published var detectedIntent: String?

    func update(handAnchor: HandAnchor) async {
        let currentJoints = handAnchor.handSkeleton.joints.map { $0.anchorPose.position }
        
        // Pass to actor for processing
        if let intent = await classifier.addFrame(joints: currentJoints, 
                                                 previousJoints: lastJointPositions) {
            self.detectedIntent = intent
        }
        
        self.lastJointPositions = currentJoints
    }
}
