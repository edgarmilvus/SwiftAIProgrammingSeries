
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import PhotosUI
import CoreML
import UIKit
import VideoToolbox // Needed for CVPixelBuffer conversion

// MARK: - UIImage Extension (from Exercise 1, reused)

extension UIImage {
    func toCVPixelBuffer(width: Int, height: Int, pixelFormat: OSType) -> CVPixelBuffer? {
        // ... (Same implementation as in Exercise 1) ...
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: AnyObject] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:] as AnyObject
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: width,
                                height: height,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        guard let cgImage = self.cgImage else {
            CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

        return pixelBuffer
    }
}

// MARK: - Data Structures

struct ClassifiedImage: Identifiable, Sendable {
    let id = UUID()
    let originalImage: UIImage
    let thumbnailImage: UIImage // For displaying in the list
    let label: String
    let confidence: Float
    let error: String? // To capture specific errors for an image

    init(originalImage: UIImage, label: String, confidence: Float, error: String? = nil) {
        self.originalImage = originalImage
        // Create a thumbnail for efficient display
        let size = CGSize(width: 100, height: 100)
        UIGraphicsBeginImageContext(size)
        originalImage.draw(in: CGRect(origin: .zero, size: size))
        self.thumbnailImage = UIGraphicsGetImageFromCurrentImageContext() ?? originalImage
        UIGraphicsEndImageContext()

        self.label = label
        self.confidence = confidence
        self.error = error
    }
}

// MARK: - AppState Observable Object

@Observable
class GalleryClassifierViewModel {
    enum BatchState {
        case idle
        case processing(progress: Double, total: Int)
        case completed
        case error(String)
    }

    var batchState: BatchState = .idle
    var classifiedImages: [ClassifiedImage] = []
    var showAlert: Bool = false
    var currentErrorMessage: String?

    // Assuming SqueezeNet.mlmodel is added to the project
    private var coreMLModel: SqueezeNet?

    private let modelInputWidth: Int = 227
    private let modelInputHeight: Int = 227
    private let modelInputPixelFormat: OSType = kCVPixelFormatType_32BGRA

    // Task for batch processing, allowing cancellation
    private var classificationTask: Task<Void, Never>?

    init() {
        Task { await loadModel() }
    }

    @MainActor
    private func loadModel() async {
        batchState = .idle // Ensure we're idle before trying to load
        do {
            self.coreMLModel = try SqueezeNet(configuration: MLModelConfiguration())
        } catch {
            batchState = .error("Failed to load Core ML model: \(error.localizedDescription).")
            currentErrorMessage = "Failed to load Core ML model: \(error.localizedDescription)."
            showAlert = true
            print("Model Loading Error: \(error)")
        }
    }

    @MainActor
    func classifyBatch(items: [PhotosPickerItem]) async {
        guard let model = coreMLModel else {
            batchState = .error("Core ML model is not loaded. Please retry.")
            currentErrorMessage = "Core ML model is not loaded. Please retry."
            showAlert = true
            return
        }

        classifiedImages.removeAll()
        batchState = .processing(progress: 0.0, total: items.count)
        currentErrorMessage = nil
        showAlert = false

        classificationTask = Task {
            var processedCount = 0
            var results: [ClassifiedImage] = []

            await withTaskGroup(of: ClassifiedImage?.self) { group in
                for item in items {
                    group.addTask {
                        // Check for cancellation before processing each item
                        guard !Task.isCancelled else { return nil }

                        do {
                            guard let data = try await item.loadTransferable(type: Data.self),
                                  let uiImage = UIImage(data: data) else {
                                return ClassifiedImage(originalImage: UIImage(), label: "Error", confidence: 0, error: "Failed to load image data.")
                            }

                            guard let pixelBuffer = uiImage.toCVPixelBuffer(width: self.modelInputWidth, height: self.modelInputHeight, pixelFormat: self.modelInputPixelFormat) else {
                                return ClassifiedImage(originalImage: uiImage, label: "Error", confidence: 0, error: "Image conversion failed.")
                            }

                            let input = SqueezeNetInput(image: pixelBuffer)
                            let output = try await model.prediction(input: input)

                            if let (label, confidenceValue) = output.featureValue(for: "classLabelProbs")?.dictionaryValue.max(by: { $0.value.doubleValue < $1.value.doubleValue }) {
                                return ClassifiedImage(originalImage: uiImage, label: label, confidence: Float(confidenceValue.doubleValue))
                            } else {
                                return ClassifiedImage(originalImage: uiImage, label: "Unknown", confidence: 0, error: "Could not interpret model output.")
                            }
                        } catch {
                            return ClassifiedImage(originalImage: UIImage(), label: "Error", confidence: 0, error: "Classification failed: \(error.localizedDescription)")
                        }
                    }
                }

                for await result in group {
                    guard !Task.isCancelled else { break } // Check cancellation after each result
                    if let result = result {
                        results.append(result)
                    }
                    processedCount += 1
                    await MainActor.run {
                        self.batchState = .processing(progress: Double(processedCount) / Double(items.count), total: items.count)
                    }
                }
            }

            // Only update results if the task wasn't cancelled
            guard !Task.isCancelled else {
                await MainActor.run {
                    self.batchState = .idle // Reset state on cancellation
                }
                return
            }

            await MainActor.run {
                self.classifiedImages = results
                self.batchState = .completed
            }
        }
    }

    @MainActor
    func cancelClassification() {
        classificationTask?.cancel()
        classificationTask = nil
        batchState = .idle
        currentErrorMessage = "Batch classification cancelled."
        showAlert = true // Inform user of cancellation
    }
}

// MARK: - SwiftUI View

struct SmartGalleryView: View {
    @State private var viewModel = GalleryClassifierViewModel()
    @State private var selectedPhotoItems: [PhotosPickerItem] = []

    var body: some View {
        NavigationStack {
            VStack {
                switch viewModel.batchState {
                case .idle:
                    Text("Select images to classify them in a batch.")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding()
                case .processing(let progress, let total):
                    VStack {
                        ProgressView(value: progress) {
                            Text("Processing \(Int(progress * Double(total))) of \(total) images...")
                        } currentValueLabel: {
                            Text(String(format: "%.0f%%", progress * 100))
                        }
                        .progressViewStyle(.linear)
                        .padding()

                        Button("Cancel Classification") {
                            viewModel.cancelClassification()
                        }
                        .buttonStyle(.destructive)
                    }
                case .completed:
                    Text("Classification Complete!")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding()
                case .error(let message):
                    Text("Error: \(message)")
                        .foregroundColor(.red)
                        .padding()
                    Button("Reload Model") {
                        Task { await viewModel.loadModel() }
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.top, 5)
                }

                if !viewModel.classifiedImages.isEmpty {
                    List {
                        ForEach(viewModel.classifiedImages) { classifiedImage in
                            HStack {
                                Image(uiImage: classifiedImage.thumbnailImage)
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .cornerRadius(5)
                                VStack(alignment: .leading) {
                                    Text(classifiedImage.label)
                                        .font(.headline)
                                    if let error = classifiedImage.error {
                                        Text("Error: \(error)")
                                            .font(.subheadline)
                                            .foregroundColor(.red)
                                    } else {
                                        Text(String(format: "Confidence: %.2f%%", classifiedImage.confidence * 100))
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                    }
                                }
                                Spacer()
                            }
                        }
                    }
                    .listStyle(.plain)
                } else {
                    Spacer()
                }

                PhotosPicker(
                    selection: $selectedPhotoItems,
                    maxSelectionCount: 0, // Allows multiple selections
                    matching: .images,
                    photoLibrary: .shared()
                ) {
                    Label("Select Photos", systemImage: "photo.stack")
                        .font(.headline)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .disabled(viewModel.batchState == .processing(.zero, 0)) // Disable picker during processing
                .padding(.bottom)
            }
            .navigationTitle("Smart Gallery")
            .onChange(of: selectedPhotoItems) { newItems in
                if !newItems.isEmpty {
                    Task {
                        await viewModel.classifyBatch(items: newItems)
                        // Clear selected items after processing to allow re-selection
                        selectedPhotoItems = []
                    }
                }
            }
            .alert("Info", isPresented: $viewModel.showAlert, presenting: viewModel.currentErrorMessage) { errorMessage in
                Button("OK") { viewModel.showAlert = false }
            } message: { errorMessage in
                Text(errorMessage)
            }
        }
    }
}
