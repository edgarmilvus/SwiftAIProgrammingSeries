/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// SecureVault.tsx
import React, { useState } from 'react';
import { View, Text, Button, ActivityIndicator, Switch, StyleSheet, Alert } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { useBiometricAuth } from './useBiometricAuth'; // Assuming path

export default function SecureVault() {
  // State for UI Flow
  const [authState, setAuthState] = useState<'locked' | 'unlocking' | 'unlocked'>('locked');
  const [isDevMode, setIsDevMode] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Use the hook from Exercise 1
  const { isSupported, biometricType, checkCapabilities, isLoading, error: hookError } = useBiometricAuth();

  // The sensitive data
  const sensitiveData = "sk_live_51MzXyZ... (Secret API Key)";

  const handleUnlock = async () => {
    setError(null);
    
    // 1. Ensure capabilities are checked first
    if (!isSupported) {
      // Trigger check if not already done, or show error
      await checkCapabilities();
      // Re-check state after capability check (simplified for this flow, ideally check the return of checkCapabilities)
      // In a real app, we might wait for the hook state to update.
      // For this exercise, we assume checkCapabilities updates the hook state.
      if (hookError) {
        setError(hookError);
        return;
      }
    }

    setAuthState('unlocking');

    try {
      let success = false;

      if (isDevMode) {
        // 2. Developer Simulation
        await new Promise(resolve => setTimeout(resolve, 1000));
        success = true;
      } else {
        // 3. Native Authentication
        const result = await LocalAuthentication.authenticateAsync({
          promptMessage: 'Unlock Vault',
          fallbackLabel: 'Use Passcode',
        });
        success = result.success;
      }

      if (success) {
        setAuthState('unlocked');
      } else {
        setAuthState('locked');
        setError('Authentication failed or was canceled.');
      }
    } catch (err) {
      setAuthState('locked');
      setError('An unexpected error occurred.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Secure Vault</Text>
      
      {/* Developer Mode Toggle */}
      <View style={styles.devRow}>
        <Text>Developer Mode (Simulate)</Text>
        <Switch value={isDevMode} onValueChange={setIsDevMode} />
      </View>

      {/* Status Display */}
      {authState === 'locked' && (
        <View style={styles.lockedView}>
          <Text style={styles.lockIcon}>🔒</Text>
          <Button title="Unlock Vault" onPress={handleUnlock} />
        </View>
      )}

      {authState === 'unlocking' && (
        <View style={styles.unlockingView}>
          <ActivityIndicator size="large" color="#0000ff" />
          <Text>Verifying Identity...</Text>
        </View>
      )}

      {authState === 'unlocked' && (
        <View style={styles.unlockedView}>
          <Text style={styles.checkIcon}>✅</Text>
          <Text style={styles.secretText}>{sensitiveData}</Text>
          <Button title="Lock Vault" onPress={() => setAuthState('locked')} color="gray" />
        </View>
      )}

      {/* Error Display */}
      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  devRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  lockedView: { alignItems: 'center' },
  unlockingView: { alignItems: 'center' },
  unlockedView: { alignItems: 'center', backgroundColor: '#e8f5e9', padding: 20, borderRadius: 8 },
  lockIcon: { fontSize: 60, marginBottom: 10 },
  checkIcon: { fontSize: 40, marginBottom: 10 },
  secretText: { fontFamily: 'monospace', backgroundColor: '#eee', padding: 10, borderRadius: 4, marginVertical: 10 },
  errorText: { color: 'red', marginTop: 10, textAlign: 'center' },
});
