
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
struct SummarizeDocumentIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Document"
    static var description = IntentDescription("Summarizes the content of a document using a local LLM.")

    @Parameter(title: "Document Content", description: "The text content to summarize.")
    var content: String

    @Parameter(title: "Summary Length", description: "Desired length of the summary (e.g., 'short', 'medium').", default: "medium")
    var length: SummaryLength

    enum SummaryLength: String, AppEnum {
        static var typeDisplayRepresentation = TypeDisplayRepresentation(name: "Summary Length")
        static var caseDisplayRepresentations: [Self: DisplayRepresentation] = [
            .short: "Short",
            .medium: "Medium",
            .long: "Long"
        ]
        case short, medium, long
    }

    static var parameterEditor: some ParameterEditor {
        Group {
            ParameterEditor(keyPath: \.$content)
            ParameterEditor(keyPath: \.$length)
        }
    }

    func perform() async throws -> some IntentResult {
        // Simulate a long-running on-device LLM inference
        // This is where you might integrate with a Core ML model or a local Foundation Model API
        print("Starting summarization for content: \(content.prefix(50))... with length: \(length)")

        // Imagine a call to a local LLM API here
        // let llmResult = await LocalLLMService.shared.summarize(content, length: length)
        await Task.sleep(for: .seconds(3)) // Simulate work

        let summary: String
        switch length {
        case .short:
            summary = "This is a concise summary of the document."
        case .medium:
            summary = "This is a moderately detailed summary that captures the main points of the document."
        case .long:
            summary = "This is an extensive summary, providing a thorough overview and key details from the document."
        }

        print("Summarization complete.")
        return .result(value: summary, dialog: "Here's the summary: \(summary)")
    }
}
