
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import AVFoundation
import Vision
import CoreGraphics // For CGRect, CGPoint, CGSize

// MARK: - 1. CameraPreviewRepresentable
/// A SwiftUI `UIViewRepresentable` that embeds an `AVCaptureVideoPreviewLayer`
/// to display the live camera feed. It also configures the `AVCaptureSession`
/// and directs video output to a delegate for real-time processing.
@available(iOS 18.0, *)
struct CameraPreviewRepresentable: UIViewRepresentable {
    /// The `AVCaptureSession` managed by the `DocumentScannerViewModel`.
    let session: AVCaptureSession

    /// The delegate that will receive `CMSampleBuffer` frames for processing.
    weak var videoOutputDelegate: AVCaptureVideoDataOutputSampleBufferDelegate?

    /// The dispatch queue on which video frames will be delivered.
    /// This is crucial for offloading frame processing from the main thread.
    let videoOutputQueue = DispatchQueue(label: "com.ai-apps.videoOutputQueue", qos: .userInitiated)

    /// Creates the `UIView` that will host the `AVCaptureVideoPreviewLayer`.
    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black // Ensure background is black before preview loads

        // Configure the AVCaptureVideoPreviewLayer
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill // Fill the view while maintaining aspect ratio
        previewLayer.connection?.videoOrientation = .portrait // Lock orientation to portrait for consistency
        view.layer.addSublayer(previewLayer)

        // Configure AVCaptureVideoDataOutput to deliver frames for AI processing
        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(videoOutputDelegate, queue: videoOutputQueue)
        
        // Discard frames if the processing queue is full to prevent memory issues
        videoOutput.alwaysDiscardsLateVideoFrames = true 

        if session.canAddOutput(videoOutput) {
            session.addOutput(videoOutput)
        } else {
            print("Error: Could not add video output to AVCaptureSession.")
        }

        return view
    }

    /// Updates the `UIView` when SwiftUI state changes.
    /// Here, we primarily ensure the preview layer's frame matches the view's bounds.
    func updateUIView(_ uiView: UIView, context: Context) {
        // Ensure the preview layer resizes with the UIView
        if let previewLayer = uiView.layer.sublayers?.first(where: { $0 is AVCaptureVideoPreviewLayer }) as? AVCaptureVideoPreviewLayer {
            previewLayer.frame = uiView.bounds
        }
    }

    /// Cleans up resources when the view is removed.
    static func dismantleUIView(_ uiView: UIView, coordinator: ()) {
        // No explicit cleanup needed for AVCaptureSession here, as it's managed by the ViewModel.
        // The session will be stopped when the ViewModel is deallocated or explicitly stopped.
    }
}

// MARK: - 2. DocumentScannerViewModel
/// An `ObservableObject` responsible for managing the camera session,
/// handling camera authorization, performing real-time Vision processing
/// for rectangle detection, and publishing results to SwiftUI.
@available(iOS 18.0, *)
class DocumentScannerViewModel: NSObject, ObservableObject {
    /// The `AVCaptureSession` that manages camera input and output.
    let session = AVCaptureSession()

    /// Published property to inform the UI about camera authorization status.
    @Published var authorizationStatus: AVAuthorizationStatus = .notDetermined

    /// Published property to hold the detected rectangles from Vision.
    /// `[VNRectangleObservation]` contains normalized coordinates.
    @Published var detectedRectangles: [VNRectangleObservation] = []

    /// Published property to indicate if the camera session is running.
    @Published var isSessionRunning: Bool = false

    /// A `Task` reference used for debouncing Vision requests.
    private var visionProcessingTask: Task<Void, Never>?

    /// The timestamp of the last Vision request to control processing rate.
    private var lastVisionProcessTime: Date = .distantPast

    /// The minimum interval between Vision processing requests (e.g., 0.1 seconds = 10 FPS).
    private let visionProcessingInterval: TimeInterval = 0.1

    override init() {
        super.init()
        checkCameraAuthorization() // Check authorization on initialization
    }

    /// Requests camera authorization if not already determined.
    /// Updates `authorizationStatus` accordingly.
    func checkCameraAuthorization() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            authorizationStatus = .authorized
            setupSession()
        case .notDetermined:
            Task {
                let granted = await AVCaptureDevice.requestAccess(for: .video)
                await MainActor.run {
                    self.authorizationStatus = granted ? .authorized : .denied
                    if granted {
                        self.setupSession()
                    }
                }
            }
        case .denied, .restricted:
            authorizationStatus = .denied
        @unknown default:
            authorizationStatus = .denied
        }
    }

    /// Sets up the `AVCaptureSession` with a default camera input.
    /// This method is called once camera authorization is granted.
    private func setupSession() {
        guard authorizationStatus == .authorized else { return }

        session.beginConfiguration()
        defer { session.commitConfiguration() } // Ensure configuration is committed

        // 1. Remove existing inputs/outputs to prevent duplicates on re-setup
        for input in session.inputs { session.removeInput(input) }
        for output in session.outputs { session.removeOutput(output) }

        // 2. Add video input
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Error: No back camera found.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if session.canAddInput(videoInput) {
                session.addInput(videoInput)
            } else {
                print("Error: Could not add video input to session.")
                return
            }
        } catch {
            print("Error creating video device input: \(error.localizedDescription)")
            return
        }

        // 3. Configure video output for frame processing
        // The actual AVCaptureVideoDataOutput is added in CameraPreviewRepresentable
        // This ensures the delegate is set correctly when the UIView is made.
    }

    /// Starts the `AVCaptureSession`. Should be called when the view appears.
    func startSession() {
        guard authorizationStatus == .authorized, !session.isRunning else { return }
        Task(priority: .background) {
            self.session.startRunning()
            await MainActor.run {
                self.isSessionRunning = true
            }
        }
    }

    /// Stops the `AVCaptureSession`. Should be called when the view disappears.
    func stopSession() {
        guard session.isRunning else { return }
        Task(priority: .background) {
            self.session.stopRunning()
            await MainActor.run {
                self.isSessionRunning = false
            }
        }
        visionProcessingTask?.cancel() // Cancel any pending Vision tasks
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate Conformance
extension DocumentScannerViewModel: AVCaptureVideoDataOutputSampleBufferDelegate {
    /// Called when a new video frame (CMSampleBuffer) is available from the camera.
    /// This method is invoked on the `videoOutputQueue` defined in `CameraPreviewRepresentable`.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Implement a debouncing mechanism to avoid overwhelming the system with Vision requests.
        // We only process frames if enough time has passed since the last processing.
        let now = Date()
        guard now.timeIntervalSince(lastVisionProcessTime) > visionProcessingInterval else { return }
        lastVisionProcessTime = now

        // Cancel any previous Vision processing task if it's still running.
        // This ensures only the latest frame is processed, preventing a backlog.
        visionProcessingTask?.cancel()

        // Create a new Task for Vision processing.
        // This allows the camera delegate method to return quickly, preventing frame drops.
        visionProcessingTask = Task {
            // Ensure the task hasn't been cancelled before proceeding.
            guard !Task.isCancelled else { return }

            // Create a VNImageRequestHandler with the current sample buffer.
            // Using `cmSampleBuffer` directly is efficient.
            let handler = VNImageRequestHandler(cmSampleBuffer: sampleBuffer, orientation: .up, options: [:])
            let request = VNDetectRectanglesRequest()

            // Configure the rectangle detection request
            request.minimumAspectRatio = 0.5 // Allow for wider/taller rectangles
            request.maximumAspectRatio = 2.0
            request.minimumSize = 0.2 // Minimum size relative to image dimension
            request.quadratureTolerance = 20 // Tolerance for non-rectangular shapes

            do {
                try handler.perform([request])
                // Ensure the task hasn't been cancelled after performing the request.
                guard !Task.isCancelled else { return }

                // Process results on the main actor to update the UI.
                if let observations = request.results as? [VNRectangleObservation] {
                    await MainActor.run {
                        self.detectedRectangles = observations
                    }
                }
            } catch {
                print("Error performing Vision rectangle detection: \(error.localizedDescription)")
                // Optionally, clear rectangles on error or publish an error state.
                await MainActor.run {
                    self.detectedRectangles = []
                }
            }
        }
    }
}

// MARK: - 3. DocumentScannerView
/// A SwiftUI view that displays the camera feed and overlays real-time
/// Vision-detected rectangles. It uses `DocumentScannerViewModel` to manage
/// camera and AI logic.
@available(iOS 18.0, *)
struct DocumentScannerView: View {
    /// The `ObservableObject` that manages camera and Vision logic.
    @StateObject private var viewModel = DocumentScannerViewModel()

    var body: some View {
        Group {
            switch viewModel.authorizationStatus {
            case .authorized:
                cameraView
            case .notDetermined:
                Text("Requesting Camera Access...")
                    .onAppear(perform: viewModel.checkCameraAuthorization) // Re-check authorization if view appears
            case .denied, .restricted:
                Text("Camera access denied. Please enable it in Settings.")
                    .multilineTextAlignment(.center)
                    .padding()
            @unknown default:
                Text("Unknown camera authorization status.")
            }
        }
        .onAppear {
            viewModel.startSession() // Start camera session when view appears
        }
        .onDisappear {
            viewModel.stopSession() // Stop camera session when view disappears
        }
    }

    /// The view displaying the camera preview and rectangle overlays.
    private var cameraView: some View {
        GeometryReader { geometry in
            ZStack {
                // 1. Camera Preview
                CameraPreviewRepresentable(session: viewModel.session, videoOutputDelegate: viewModel)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .edgesIgnoringSafeArea(.all)

                // 2. Rectangle Overlays
                ForEach(viewModel.detectedRectangles, id: \.self) { observation in
                    // Convert Vision's normalized coordinates to SwiftUI view coordinates.
                    // Vision coordinates are normalized (0-1) and origin is bottom-left.
                    // SwiftUI coordinates are (0-1) and origin is top-left.
                    let boundingBox = observation.boundingBox
                    let rect = VNImageRectForNormalizedRect(boundingBox,
                                                            Int(geometry.size.width),
                                                            Int(geometry.size.height))

                    // Adjust for SwiftUI's top-left origin
                    let adjustedRect = CGRect(x: rect.minX,
                                              y: geometry.size.height - rect.maxY,
                                              width: rect.width,
                                              height: rect.height)

                    // Draw the rectangle
                    Rectangle()
                        .stroke(Color.green, lineWidth: 4)
                        .frame(width: adjustedRect.width, height: adjustedRect.height)
                        .position(x: adjustedRect.midX, y: adjustedRect.midY)
                        .animation(.easeInOut(duration: 0.2), value: adjustedRect) // Smooth animation for rectangle movement
                }
            }
        }
    }
}

// MARK: - Example Usage (for a full app)
/*
 @main
 struct AIDocumentScannerApp: App {
     var body: some Scene {
         WindowGroup {
             DocumentScannerView()
         }
     }
 }
 */
