
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import ARKit
import Observation
import RealityKit

/// Represents the inferred intent of the user based on gaze patterns.
/// Conforming to Sendable ensures this can safely cross actor boundaries.
@Sendable
enum UserIntent: Sendable {
    case idling
    case investigating(entityID: UUID)
    case preparingToSelect(entityID: UUID)
    case focused(entityID: UUID)
}

/// The GazeIntelligenceEngine is responsible for consuming high-frequency
/// gaze data, applying temporal filters, and running AI inference to 
/// determine user intent.
///
/// We use an `actor` to ensure that the high-frequency updates from ARKit
/// do not cause data races when updating our internal temporal buffers.
actor GazeIntelligenceEngine {
    
    // A buffer of recent gaze points used for smoothing and pattern recognition.
    private var gazeHistory: [SIMD3<Float>] = []
    private let maxBufferSize = 60
    
    // The current inferred intent, which will be published to the UI.
    // Note: Since this is an actor, we cannot directly use @Observable here 
    // if we want to update the MainActor. We will bridge this via a separate 
    // @Observable class.
    private(set) var currentIntent: UserIntent = .idling

    /// Processes a new gaze sample.
    /// - Parameter point: The 3D coordinate of the gaze intersection.
    /// - Returns: The newly calculated intent.
    func process(gazePoint: SIMD3<Float>, intersectedEntity: UUID?) async -> UserIntent {
        // 1. Update temporal buffer
        gazeHistory.append(gazePoint)
        if gazeHistory.count > maxBufferSize {
            gazeHistory.removeFirst()
        }
        
        // 2. Perform "Under the Hood" smoothing (e.g., a simple Moving Average)
        let smoothedPoint = calculateSmoothedPoint()
        
        // 3. AI Inference Logic (Conceptual)
        // In a real-world scenario, this would involve passing the buffer 
        // to a Core ML model trained to recognize fixation patterns.
        let newIntent = performInference(on: smoothedPoint, entityID: intersectedEntity)
        
        self.currentIntent = newIntent
        return newIntent
    }
    
    private func calculateSmoothedPoint() -> SIMD3<Float> {
        guard !gazeHistory.isEmpty else { return .zero }
        let sum = gazeHistory.reduce(SIMD3<Float>.zero, +)
        return sum / Float(gazeHistory.count)
    }
    
    private func performInference(on point: SIMD3<Float>, entityID: UUID?) -> UserIntent {
        // Placeholder for complex AI logic:
        // - Check for fixation duration
        // - Check for saccadic velocity
        // - Cross-reference with spatial semantic data
        guard let id = entityID else { return .idling }
        
        // If the user has been looking at the same entity for a sustained period:
        if gazeHistory.count > 30 { // Simplified fixation check
            return .focused(entityID: id)
        }
        
        return .investigating(entityID: id)
    }
}

/// The ViewModel acts as the bridge between the high-performance Actor
/// and the MainActor-bound SwiftUI views.
@Observable
@MainActor
final class GazeInteractionViewModel {
    
    /// The intent that the SwiftUI view will react to.
    var activeIntent: UserIntent = .idling
    
    private let engine = GazeIntelligenceEngine()
    
    /// This method would be called from the ARKit session delegate.
    /// It demonstrates the use of Task to bridge the synchronous delegate
    /// to the asynchronous actor.
    func handleGazeUpdate(point: SIMD3<Float>, entityID: UUID?) {
        Task {
            // We offload the heavy lifting to the actor.
            let newIntent = await engine.process(gazePoint: point, intersectedEntity: entityID)
            
            // We return to the MainActor to update the UI.
            self.activeIntent = newIntent
        }
    }
}
