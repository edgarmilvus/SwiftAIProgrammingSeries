/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// 1. Root .env file
API_URL=https://api.example.com/v1

// 2. Next.js Configuration (apps/web/next.config.js)
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Expose env vars starting with NEXT_PUBLIC_ or defined in env object
  env: {
    API_URL: process.env.API_URL,
  },
  // Webpack alias for @components
  webpack: (config) => {
    config.resolve.alias['@components'] = path.join(__dirname, '../../packages/ui/src/components');
    return config;
  },
};
module.exports = nextConfig;

// 3. Expo Configuration (apps/mobile/app.json)
{
  "expo": {
    "extra": {
      "API_URL": process.env.API_URL || "https://api.example.com/v1",
      "eas": { "projectId": "..." }
    }
  }
}

// 4. Shared Hook (packages/hooks/src/useConfig.ts)
import { Platform } from 'react-native';
import Constants from 'expo-constants';

// Define a type for the config
interface Config {
  API_URL: string;
}

export const useConfig = (): Config => {
  // Check if running in a native environment (React Native)
  if (typeof window === 'undefined') {
    // React Native / Expo
    const manifest = Constants.expoConfig;
    return {
      API_URL: manifest?.extra?.API_URL as string || 'default-fallback',
    };
  } else {
    // Web environment
    return {
      API_URL: process.env.API_URL as string || 'default-fallback',
    };
  }
};

// 5. Shared Component using the Hook (packages/ui/src/components/InfoCard.tsx)
import React from 'react';
import { View, Text } from 'react-native'; // Assuming a universal wrapper or .native file
import { useConfig } from '@repo/hooks';

export const InfoCard = () => {
  const { API_URL } = useConfig();

  return (
    <div style={{ padding: 20, border: '1px solid #ccc' }}>
      <h3>Configuration Info</h3>
      <p>API Endpoint: {API_URL}</p>
    </div>
  );
};

// 6. Usage in Next.js (apps/web/pages/index.tsx)
import { InfoCard } from '@components/InfoCard'; // Resolved via next.config.js alias

export default function WebPage() {
  return <InfoCard />;
}

// 7. Usage in Expo (apps/mobile/app/index.tsx)
import { InfoCard } from '@components/InfoCard'; // Resolved via tsconfig paths

export default function MobilePage() {
  return <InfoCard />;
}
