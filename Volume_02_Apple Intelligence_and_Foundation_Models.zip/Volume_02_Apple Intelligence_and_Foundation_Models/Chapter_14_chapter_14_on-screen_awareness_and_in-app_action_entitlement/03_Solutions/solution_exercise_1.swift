
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import AppIntents // Required for ContentIdentifier, ContentAction, UIContentContext

@available(iOS 18.0, *)
struct RecipeIngredientMetadata: Codable {
    let name: String
    let quantity: Double
    let unit: String?
    let state: String? // e.g., "sifted", "chopped"
}

// Dummy RecipeIngredient model to simulate data
struct RecipeIngredient: Identifiable {
    let id = UUID()
    let name: String
    let quantity: Double
    let unit: String?
    let state: String?

    var displayText: String {
        "\(quantity) \(unit ?? "") \(name) \(state ?? "")".trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

@available(iOS 18.0, *)
class RecipeDetailViewController: UIViewController {

    var ingredients: [RecipeIngredient] = [
        RecipeIngredient(name: "all-purpose flour", quantity: 2, unit: "cups", state: nil),
        RecipeIngredient(name: "baking soda", quantity: 1, unit: "tsp", state: nil),
        RecipeIngredient(name: "granulated sugar", quantity: 0.75, unit: "cup", state: "sifted")
    ]

    // A stack view to hold ingredient labels, each with its own contentContext
    private let ingredientsStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Recipe Details"
        view.backgroundColor = .systemBackground

        view.addSubview(ingredientsStackView)
        NSLayoutConstraint.activate([
            ingredientsStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            ingredientsStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            ingredientsStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        setupIngredientContexts()
    }

    private func setupIngredientContexts() {
        for ingredient in ingredients {
            let metadata = RecipeIngredientMetadata(name: ingredient.name, quantity: ingredient.quantity, unit: ingredient.unit, state: ingredient.state)

            // Encode the metadata for UIContentContext
            guard let encodedMetadata = try? JSONEncoder().encode(metadata) else {
                print("Failed to encode RecipeIngredientMetadata for \(ingredient.name)")
                continue
            }

            let contentContext = UIContentContext(
                identifier: ContentIdentifier(rawValue: "recipe-ingredient-\(ingredient.id.uuidString)"),
                metadata: encodedMetadata,
                actions: [
                    ContentAction(
                        identifier: ContentIdentifier(rawValue: "add-to-shopping-list"),
                        title: NSLocalizedString("Add to Shopping List", comment: "Action to add ingredient to shopping list"),
                        // Parameter values are passed as a dictionary, matching expected parameters in an AppIntent
                        parameterValues: [
                            "ingredientName": ingredient.name,
                            "ingredientQuantity": ingredient.quantity,
                            "ingredientUnit": ingredient.unit ?? "",
                            "ingredientState": ingredient.state ?? ""
                        ]
                    )
                ]
            )

            // Create a UILabel for each ingredient and assign the contentContext
            let ingredientLabel = UILabel()
            ingredientLabel.text = ingredient.displayText
            ingredientLabel.font = .preferredFont(forTextStyle: .body)
            ingredientLabel.numberOfLines = 0
            ingredientLabel.isUserInteractionEnabled = true // Essential for context menus, etc.
            ingredientLabel.contentContext = contentContext // Associate the context with the UI element

            ingredientsStackView.addArrangedSubview(ingredientLabel)
        }

        // Why this is important:
        // By providing structured content context, Apple Intelligence can:
        // 1. Understand the semantic meaning of "flour" as an ingredient, not just a word.
        // 2. Offer contextually relevant actions, like "Add to Shopping List", directly from the UI when a user highlights "baking soda" or asks Siri about it.
        // 3. Potentially provide quick lookups for nutritional information or substitutions directly from the app's UI, leveraging the rich metadata.
        // 4. Improve accessibility features by providing more semantic information about UI elements.
    }
}
