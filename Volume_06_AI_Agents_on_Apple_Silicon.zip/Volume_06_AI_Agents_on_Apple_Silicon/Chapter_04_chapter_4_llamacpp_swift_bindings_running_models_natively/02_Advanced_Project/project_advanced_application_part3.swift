
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import Foundation
import llama_cpp // The product name from llama.cpp.swift

/// A service for summarizing documents using a local llama.cpp LLM.
/// This service manages the LLM model lifecycle and provides a context-aware summarization API.
@available(macOS 14.0, iOS 18.0, *) // Requires modern OS for async/await and potentially newer llama.cpp.swift features
final class DocumentSummarizerService: @unchecked Sendable { // @unchecked Sendable for LLM instance management
    /// The URL to the GGUF model file on disk.
    private let modelPath: URL
    /// Configuration for the LLM context, including context window size and GPU layers.
    private let configuration: LLMContextConfiguration

    /// The loaded LLM instance. This is optional because it's loaded asynchronously.
    private var llm: LLM?
    /// A lock to ensure thread-safe access to the `llm` instance during loading and access.
    private let llmAccessLock = OSAllocatedUnfairLock()

    /// Initializes the summarizer service with the model path and configuration.
    /// - Parameters:
    ///   - modelPath: The file URL to the GGUF model.
    ///   - configuration: The configuration for the LLM context.
    init(modelPath: URL, configuration: LLMContextConfiguration) {
        self.modelPath = modelPath
        self.configuration = configuration
    }

    /// Loads the LLM model asynchronously. This method should be called once before performing summarizations.
    /// It ensures the model is loaded safely and efficiently.
    /// - Throws: `SummarizerError.modelNotFound` if the model file doesn't exist.
    /// - Throws: `SummarizerError.modelLoadFailed` if there's an issue loading the model.
    func loadModel() async throws {
        // Use a lock to prevent multiple concurrent calls from loading the model simultaneously
        // and to ensure only one LLM instance is created.
        try await llmAccessLock.withLockAsync {
            // If the model is already loaded, do nothing.
            guard self.llm == nil else { return }

            guard FileManager.default.fileExists(atPath: modelPath.path(percentEncoded: false)) else {
                throw SummarizerError.modelNotFound(path: modelPath)
            }

            do {
                // Initialize the LLM with the specified model path and configuration.
                // This can be a long-running operation, especially for large models.
                self.llm = try LLM(modelPath: modelPath.path(percentEncoded: false), configuration: configuration)
                print("LLM model loaded successfully from \(modelPath.lastPathComponent)")
            } catch {
                // Wrap the underlying llama.cpp error for better context.
                throw SummarizerError.modelLoadFailed(underlyingError: error)
            }
        }
    }

    /// Summarizes the provided document text, optionally focusing on a specific query.
    /// - Parameters:
    ///   - documentText: The full text content of the document to summarize.
    ///   - query: An optional query string to guide the summarization (e.g., "focus on legal liabilities").
    ///   - maxLength: The maximum desired length of the summary in tokens.
    /// - Returns: The generated summary string.
    /// - Throws: `SummarizerError.modelLoadFailed` if the model hasn't been loaded yet.
    /// - Throws: `SummarizerError.inputTooLong` if the combined prompt and document exceed the model's context.
    /// - Throws: `SummarizerError.inferenceFailed` if the LLM fails to generate a summary.
    /// - Throws: `SummarizerError.invalidOutput` if the summary is empty.
    func summarize(documentText: String, query: String? = nil, maxLength: Int = 200) async throws -> String {
        // Ensure the model is loaded before attempting inference.
        guard let currentLLM = llmAccessLock.withLock({ self.llm }) else {
            throw SummarizerError.modelLoadFailed(underlyingError: NSError(domain: "DocumentSummarizerService", code: 1, userInfo: [NSLocalizedDescriptionKey: "LLM model not loaded. Call loadModel() first."]))
        }

        // 4. Prompt Construction
        // Construct the prompt based on whether a query is provided.
        let promptTemplate: String
        if let query = query, !query.isEmpty {
            promptTemplate = "Document: \(documentText)\n\nBased on the document above, \(query). Provide a concise summary:\nSummary:"
        } else {
            promptTemplate = "Document: \(documentText)\n\nSummarize the above document concisely:\nSummary:"
        }

        // 5. Context Window Management
        // Tokenize the prompt to check its length against the model's context window.
        // This is a critical step to prevent inference failures or truncated responses.
        let promptTokens = currentLLM.tokenize(text: promptTemplate, addBos: true)
        let maxContext = Int(currentLLM.contextConfiguration.n_ctx)

        // We reserve some tokens for the output, typically `maxLength`.
        // A more robust check might consider the actual output tokens, but `maxLength` is a good heuristic.
        let estimatedTotalTokens = promptTokens.count + maxLength
        if estimatedTotalTokens >= maxContext {
            throw SummarizerError.inputTooLong(currentLength: estimatedTotalTokens, maxContext: maxContext)
        }

        // 6. LLM Inference Execution
        do {
            // Generate the summary.
            // maxTokens: The maximum number of tokens the LLM should generate for the response.
            // temperature: Controls randomness; lower values make output more deterministic.
            // topK, topP: Sampling parameters for controlling diversity.
            let output = try await currentLLM.generate(
                prompt: promptTemplate,
                maxTokens: maxLength,
                temperature: 0.7,
                topK: 40,
                topP: 0.9,
                stopSequences: ["\nDocument:", "\nSummary:", "<|im_end|>"] // Common stop sequences for chat/summary models
            )

            guard !output.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw SummarizerError.invalidOutput
            }

            return output.trimmingCharacters(in: .whitespacesAndNewlines)
        } catch {
            throw SummarizerError.inferenceFailed(underlyingError: error)
        }
    }

    /// Cleans up the LLM instance. This is important for resource management.
    /// In a real app, this might be called when the app goes to the background or when the service is no longer needed.
    func unloadModel() {
        llmAccessLock.withLock {
            self.llm = nil
            print("LLM model unloaded.")
        }
    }

    // MARK: - Advanced Considerations for Context Window Management
    // For documents significantly larger than the LLM's context window,
    // a more advanced strategy would be required:
    // 1. Chunking: Split the document into smaller segments that fit the context.
    // 2. Summarize Chunks: Summarize each chunk individually.
    // 3. Recursive Summarization: Combine the summaries of the chunks and summarize them again,
    //    repeating until a single summary is obtained.
    // This example focuses on a single-pass summarization, assuming the input fits or is truncated.
}
