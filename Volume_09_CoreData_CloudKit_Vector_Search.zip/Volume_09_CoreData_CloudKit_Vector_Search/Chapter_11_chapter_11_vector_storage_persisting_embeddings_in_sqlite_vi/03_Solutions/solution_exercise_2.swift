
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import GRDB

struct NoteRepository {
    private let dbWriter: any DatabaseWriter
    
    init(dbWriter: any DatabaseWriter) {
        self.dbWriter = dbWriter
    }
    
    /// Fetches notes similar to the provided embedding using Cosine Similarity.
    func fetchSimilarNotes(to queryEmbedding: [Float], limit: Int) async throws -> [Note] {
        // 1. Fetch all notes that actually have embeddings
        // In a production app, you'd use a vector index or a custom SQL function.
        let notesWithVectors = try await dbWriter.read { db in
            try Note.filter(Note.Columns.vectorEmbedding != nil).fetchAll(db)
        }
        
        // 2. Calculate similarity in Swift
        let scoredNotes = notesWithVectors.compactMap { note -> (Note, Float)? in
            guard let storedData = note.vectorEmbedding,
                  let storedVector = storedData.toFloatArray() else { return nil }
            
            let similarity = cosineSimilarity(queryEmbedding, storedVector)
            return (note, similarity)
        }
        
        // 3. Sort by similarity descending and return top K
        return scoredNotes
            .sorted { $0.1 > $1.1 }
            .prefix(limit)
            .map { $0.0 }
    }
    
    // MARK: - Math Helpers
    
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count, !a.isEmpty else { return 0 }
        
        var dotProduct: Float = 0
        var normA: Float = 0
        var normB: Float = 0
        
        for i in 0..<a.count {
            dotProduct += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        
        let denominator = sqrt(normA) * sqrt(normB)
        // Robustness: Handle the "Zero Vector" problem
        return denominator == 0 ? 0 : dotProduct / denominator
    }
}
