
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

    /// Simulates a real-world application workflow where a user interacts with the
    /// `DocumentRefinementService`.
    @available(iOS 18.0, *)
    func simulateDocumentEditingWorkflow() async {
        print("--- Starting Document Editing Workflow Simulation ---")

        let initialText = """
        The quick brown fox jumps over the lazy dog. This is a very long sentence that could be made more concise.
        Also, there is a gramatical error in this text. We need to corect it.
        This paragraph needs to be expanded upon, perhaps with more details about the fox's adventure.
        """
        let service = DocumentRefinementService(initialContent: initialText)
        print("\nInitial Document Content:\n\(service.documentContent)")

        // --- Workflow Step 1: Proofread a section ---
        print("\n--- Workflow Step 1: Proofread a section ---")
        // Simulate user selecting "gramatical error in this text. We need to corect it."
        // Find the range of the text to be proofread.
        if let rangeToProofread = service.documentContent.range(of: "gramatical error in this text. We need to corect it.") {
            let nsRange = NSRange(rangeToProofread, in: service.documentContent)
            do {
                print("Initiating proofreading...")
                let proofreadResult = try await service.initiateRefinement(in: nsRange, action: .proofread)
                print("Proofreading Suggestion:")
                print("  Original: '\(proofreadResult.originalText)'")
                print("  Suggested: '\(proofreadResult.suggestedText)'")

                // Simulate user accepting the suggestion
                print("Applying proofreading suggestion...")
                service.applyRefinement(proofreadResult)
                print("Document after proofread:\n\(service.documentContent)")
            } catch {
                print("Error during proofreading: \(error.localizedDescription)")
            }
        } else {
            print("Could not find text for proofreading.")
        }

        // --- Workflow Step 2: Make a sentence more concise ---
        print("\n--- Workflow Step 2: Make a sentence more concise ---")
        // Simulate user selecting "This is a very long sentence that could be made more concise."
        if let rangeToConcise = service.documentContent.range(of: "This is a very long sentence that could be made more concise.") {
            let nsRange = NSRange(rangeToConcise, in: service.documentContent)
            do {
                print("Initiating 'make concise' action...")
                let conciseResult = try await service.initiateRefinement(in: nsRange, action: .makeConcise)
                print("Concise Suggestion:")
                print("  Original: '\(conciseResult.originalText)'")
                print("  Suggested: '\(conciseResult.suggestedText)'")

                // Simulate user accepting the suggestion
                print("Applying concise suggestion...")
                service.applyRefinement(conciseResult)
                print("Document after conciseness:\n\(service.documentContent)")
            } catch {
                print("Error during conciseness refinement: \(error.localizedDescription)")
            }
        } else {
            print("Could not find text for conciseness.")
        }

        // --- Workflow Step 3: Expand on an idea ---
        print("\n--- Workflow Step 3: Expand on an idea ---")
        // Simulate user selecting "This paragraph needs to be expanded upon, perhaps with more details about the fox's adventure."
        if let rangeToExpand = service.documentContent.range(of: "This paragraph needs to be expanded upon, perhaps with more details about the fox's adventure.") {
            let nsRange = NSRange(rangeToExpand, in: service.documentContent)
            do {
                print("Initiating 'expand' action...")
                let expandResult = try await service.initiateRefinement(in: nsRange, action: .expand)
                print("Expand Suggestion:")
                print("  Original: '\(expandResult.originalText)'")
                print("  Suggested: '\(expandResult.suggestedText)'")

                // Simulate user accepting the suggestion
                print("Applying expansion suggestion...")
                service.applyRefinement(expandResult)
                print("Document after expansion:\n\(service.documentContent)")
            } catch {
                print("Error during expansion refinement: \(error.localizedDescription)")
            }
        } else {
            print("Could not find text for expansion.")
        }

        print("\nFinal Document Content:\n\(service.documentContent)")
        print("--- Document Editing Workflow Simulation Complete ---")
    }

    // To run this in a playground or an app:
    // Ensure your target is set to iOS 18.0+ and the Intelligence framework is linked.
    // Then call:
    //
    // Task {
    //     await simulateDocumentEditingWorkflow()
    // }
    //
    // Note: Actual TextProcessor calls will only work on a device/simulator
    // running iOS 18.0+ with Apple Intelligence capabilities.
    