
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import RealityKit
import ARKit

class PlaneVisualizerManager: NSObject, ARSessionDelegate {
    private var arView: ARView
    /// Maps ARPlaneAnchor identifiers to their corresponding 3D entities
    private var planeEntities: [UUID: ModelEntity] = [:]
    
    init(arView: ARView) {
        self.arView = arView
        super.init()
        self.arView.session.delegate = self
        setupSession()
    }
    
    private func setupSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        arView.session.run(configuration)
    }
    
    // MARK: - ARSessionDelegate
    
    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        for anchor in anchors {
            guard let planeAnchor = anchor as? ARPlaneAnchor else { continue }
            
            // Create a semi-transparent grid plane
            let mesh = MeshResource.generatePlane(width: planeAnchor.extent.x, depth: planeAnchor.extent.z)
            let material = UnlitMaterial(color: .systemBlue.withAlphaComponent(0.4))
            let entity = ModelEntity(mesh: mesh, materials: [material])
            
            // Create an AnchorEntity to attach the model to the ARAnchor
            let anchorEntity = AnchorEntity(anchor: planeAnchor)
            anchorEntity.addChild(entity)
            arView.scene.addAnchor(anchorEntity)
            
            planeEntities[planeAnchor.identifier] = entity
        }
    }
    
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        for anchor in anchors {
            guard let planeAnchor = anchor as? ARPlaneAnchor,
                  let entity = planeEntities[planeAnchor.identifier] else { continue }
            
            // Update the mesh to match the new extent of the plane
            let newMesh = MeshResource.generatePlane(width: planeAnchor.extent.x, depth: planeAnchor.extent.z)
            entity.model?.mesh = newMesh
            
            // Update position to match the center of the anchor
            entity.position = [planeAnchor.center.x, 0, planeAnchor.center.z]
        }
    }
    
    func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
        for anchor in anchors {
            if let planeAnchor = anchor as? ARPlaneAnchor {
                // Remove the entity from the scene
                if let entity = planeEntities[planeAnchor.identifier] {
                    entity.anchor?.removeFromParent()
                    planeEntities.removeValue(forKey: planeAnchor.identifier)
                }
            }
        }
    }
}
