
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage

/// A utility class for performing sentiment analysis on text using Apple's Natural Language framework.
/// This class is available on iOS 13.0+, macOS 10.15+, tvOS 13.0+, and watchOS 6.0+.
@available(iOS 13.0, macOS 10.15, tvOS 13.0, watchOS 6.0, *)
class FeedbackSentimentAnalyzer {

    // MARK: - Properties

    /// An instance of NLTagger configured specifically for sentiment analysis.
    /// It is highly efficient to reuse a single NLTagger instance for multiple analyses
    /// rather than creating a new one each time, as initialization can be resource-intensive.
    private let tagger = NLTagger(tagSchemes: [.sentiment])

    // MARK: - Initialization

    /// Initializes a new sentiment analyzer. The NLTagger is set up during instance creation.
    init() {
        // The tagger is already initialized with the sentiment scheme in its declaration.
    }

    // MARK: - Public Methods

    /// Analyzes the sentiment of a given text string.
    ///
    /// The sentiment score typically ranges from -1.0 to 1.0.
    ///   - Scores closer to 1.0 indicate very positive sentiment.
    ///   - Scores closer to 0.0 indicate neutral sentiment.
    ///   - Scores closer to -1.0 indicate very negative sentiment.
    ///
    /// - Parameter text: The input string to analyze.
    /// - Returns: A `Double` representing the sentiment score, or `nil` if sentiment
    ///            could not be determined (e.g., due to empty text, unsupported language, or analysis failure).
    func analyzeSentiment(for text: String) -> Double? {
        // 1. Basic validation: Ensure the input text is not empty.
        guard !text.isEmpty else {
            print("Warning: Cannot analyze sentiment for empty text.")
            return nil
        }

        // 2. Set the string for the tagger. This prepares the text for analysis.
        //    It's crucial to update this property whenever a new text needs to be analyzed.
        tagger.string = text

        // 3. Perform sentiment analysis on the entire document.
        //    - `at: text.startIndex`: Start analysis from the beginning of the string.
        //    - `unit: .document`: Analyze the text as a single, cohesive document for overall sentiment.
        //    - `scheme: .sentiment`: Explicitly request the sentiment tag.
        //    - `options: []`: No special options are needed for basic sentiment analysis.
        let (sentimentTag, _) = tagger.tag(at: text.startIndex,
                                           unit: .document,
                                           scheme: .sentiment,
                                           options: [])

        // 4. Extract and convert the sentiment score from the tag.
        //    The `rawValue` of the `NLTag` for sentiment is a String representation of the score.
        if let sentimentString = sentimentTag?.rawValue,
           let sentimentScore = Double(sentimentString) {
            return sentimentScore
        } else {
            // This block is reached if `sentimentTag` is nil or `rawValue` cannot be converted to a Double.
            print("Could not determine sentiment for: \"\(text)\"")
            return nil
        }
    }

    /// Provides a human-readable interpretation of a sentiment score.
    /// This helper function categorizes the numerical score into descriptive strings.
    ///
    /// - Parameter score: The sentiment score (e.g., obtained from `analyzeSentiment`).
    /// - Returns: A `String` describing the sentiment (e.g., "Very Positive 😊", "Neutral 😐").
    func interpretSentiment(score: Double) -> String {
        switch score {
        case 0.7...1.0:
            return "Very Positive 😊"
        case 0.3..<0.7:
            return "Positive 🙂"
        case -0.3...0.3:
            return "Neutral 😐"
        case -0.7 ..< -0.3:
            return "Negative 🙁"
        case -1.0 ..< -0.7:
            return "Very Negative 😠"
        default:
            return "Undetermined" // Should ideally not be reached with a valid score range.
        }
    }
}

// MARK: - Example Usage in a Simulated App Context

/// Simulates a component of a Customer Feedback app.
/// This struct demonstrates how the `FeedbackSentimentAnalyzer` would be integrated and used.
@available(iOS 13.0, macOS 10.15, tvOS 13.0, watchOS 6.0, *)
struct FeedbackApp {
    /// An instance of the sentiment analyzer, ready to process feedback.
    let analyzer = FeedbackSentimentAnalyzer()

    /// Processes a user's feedback string, analyzes its sentiment, and prints the result.
    /// In a real app, this might update UI, save to a database, or trigger further actions.
    ///
    /// - Parameter feedback: The feedback text provided by the user.
    func processFeedback(feedback: String) {
        print("\n--- Processing Feedback ---")
        print("Feedback: \"\(feedback)\"")

        // Perform sentiment analysis.
        if let score = analyzer.analyzeSentiment(for: feedback) {
            // Interpret the numerical score into a user-friendly string.
            let interpretation = analyzer.interpretSentiment(score: score)
            print("Sentiment Score: \(String(format: "%.2f", score))") // Format score to two decimal places
            print("Interpretation: \(interpretation)")
        } else {
            print("Failed to analyze sentiment for this feedback.")
        }
    }
}

// MARK: - Main Execution Block

/// This function runs a series of sentiment analysis examples to demonstrate functionality.
@available(iOS 13.0, macOS 10.15, tvOS 13.0, watchOS 6.0, *)
func runSentimentAnalysisExample() {
    let feedbackApp = FeedbackApp()

    // Test cases with varying sentiments
    feedbackApp.processFeedback(feedback: "This product is absolutely amazing! I love it so much.")
    feedbackApp.processFeedback(feedback: "It's okay, nothing special. Works as expected.")
    feedbackApp.processFeedback(feedback: "I am extremely disappointed with this service. It was terrible.")
    feedbackApp.processFeedback(feedback: "The quick brown fox jumps over the lazy dog.") // Example of neutral/irrelevant text
    feedbackApp.processFeedback(feedback: "") // Example of empty text
    feedbackApp.processFeedback(feedback: "This is fantastic, truly wonderful, I'm so happy!")
    feedbackApp.processFeedback(feedback: "What a disaster, I regret buying this. Horrible experience.")
    feedbackApp.processFeedback(feedback: "The camera quality is decent, but the battery life is quite poor.") // Mixed sentiment
}

// Ensure the example runs only on compatible OS versions.
if #available(iOS 13.0, macOS 10.15, tvOS 13.0, watchOS 6.0, *) {
    runSentimentAnalysisExample()
} else {
    print("Natural Language framework sentiment analysis (iOS 13.0+ required) is not available on this OS version.")
}
