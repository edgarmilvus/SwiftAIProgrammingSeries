
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// This exercise is a conceptual design and does not require Swift code implementation for the tool itself.
// The solution outlines the design of the feature request.

/*
## Feature Request: Integrated Object Annotation Tool for "Smart Shelf Organizer" (macOS)

**Feature Title:** Annotation Studio

**Goal:** To enable users and internal annotators to efficiently create bounding box annotations for images of shelves, generating datasets compatible with Create ML's object detection models. This will allow the "Smart Shelf Organizer" app to automatically identify and inventory items.

---

### 1. User Experience (UI/UX Flow)

The Annotation Studio will be accessible via a dedicated tab or menu item within the "Smart Shelf Organizer" app.

**Workflow:**

1.  **Load Image:**
    *   User navigates to the "Annotation Studio."
    *   A prominent "Load Image" button or a drag-and-drop area will allow users to select an image file (e.g., JPG, PNG) from their file system.
    *   Upon loading, the image will be displayed prominently in the main canvas area.

2.  **Define Bounding Box:**
    *   **Selection Mode:** The cursor will default to a crosshair or similar indicator.
    *   **Click-and-Drag:** The user clicks and drags to draw a rectangle around an object. As they drag, a semi-transparent bounding box will appear, showing its current dimensions.
    *   **Resizing/Moving:** Once drawn, the bounding box will be selectable. Small handles at the corners and edges will allow for precise resizing. The entire box can be moved by clicking and dragging its interior.

3.  **Assign Label:**
    *   Upon completing a bounding box (e.e., releasing the mouse button after drawing, or selecting an existing box), a small pop-over or sidebar input field will appear.
    *   **Label Input:** The user types in the label for the object (e.g., "Book", "Vase", "Mug").
    *   **Autocompletion/Suggestions:** To ensure consistency, the input field will offer autocompletion from a predefined list of common shelf items, and suggest previously used labels.
    *   **Confirmation:** Pressing Enter or clicking an "Apply" button will associate the label with the bounding box.

4.  **Manage Multiple Bounding Boxes:**
    *   **Add New:** Users can continue drawing new bounding boxes on the same image.
    *   **Edit Existing:** Clicking on an existing bounding box will highlight it and bring up its label input for editing.
    *   **Delete:** A small "X" icon or a keyboard shortcut (e.g., Delete key) when a box is selected will remove it.
    *   **Layering/Order:** If boxes overlap, the most recently drawn or selected box will appear on top for easier interaction.

5.  **Navigation and Review:**
    *   **Image Gallery/List:** A sidebar will display thumbnails or a list of all images currently loaded for annotation, allowing quick switching between them.
    *   **Zoom/Pan:** Standard macOS gestures for zooming and panning the image will be supported for detailed annotation.

6.  **Save Annotations:**
    *   A "Save Annotations" button will trigger the saving process.
    *   The app will generate a JSON file for each annotated image, containing all bounding box and label data.
    *   The user will be prompted to select a destination folder for the entire dataset (images + JSONs), or the app can default to a pre-configured `ShelfOrganizerDataset` directory within the app's sandboxed data.

---

### 2. Annotation Data Format (JSON)

The annotations for each image will be stored in a separate JSON file. The structure will be fully compatible with Create ML's object detection training input, using normalized coordinates.

**JSON Structure for a Single Image's Annotation:**

