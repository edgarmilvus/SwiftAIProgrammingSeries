
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import NaturalLanguage
import CreateML
import Foundation

// MARK: - 3.1. User Feedback Data Structure (as requested by prompt)

// Note: @available(iOS 18.0, macOS 15.0, *) is used as per the exercise prompt.
// For NLModel itself, it's available on older OS versions.
@available(iOS 18.0, macOS 15.0, *)
struct UserFeedback: Identifiable, Codable {
    let id = UUID()
    let articleText: String // Could be title + summary
    let originalPrediction: String
    let userCorrectedLabel: String
    let timestamp: Date
}

// MARK: - 1. Initial Model Training

// Helper to generate synthetic news article data
func generateNewsArticleTrainingData() -> [(text: String, label: String)] {
    var data: [(text: String, label: String)] = []

    let categories = [
        "Artificial Intelligence", "Elections", "Basketball", "Stock Market",
        "Space Exploration", "Climate Change", "Cybersecurity", "Gaming",
        "Health & Wellness", "Automotive"
    ]

    let articleTemplates: [String: [String]] = [
        "Artificial Intelligence": [
            "New AI model achieves human-level performance in language understanding.",
            "Ethics in AI: Debating the future of autonomous systems.",
            "Machine learning breakthroughs accelerate drug discovery.",
            "Robotics and AI transforming manufacturing industries.",
            "Deep learning algorithms enhance facial recognition accuracy."
        ],
        "Elections": [
            "Presidential candidates debate economic policy ahead of election.",
            "Voter turnout projected to be record high in upcoming election.",
            "Midterm election results reshape political landscape.",
            "Campaign finance reform proposals gain traction.",
            "Polls show tight race in key swing states."
        ],
        "Basketball": [
            "Team wins championship with last-second three-pointer.",
            "Star player signs record-breaking contract extension.",
            "NBA draft prospects showcase talent at combine.",
            "Coach implements new offensive strategy for playoffs.",
            "Legendary player announces retirement after stellar career."
        ],
        "Stock Market": [
            "Tech stocks rally as market recovers from recent dip.",
            "Inflation concerns impact global stock market indices.",
            "Analysts predict strong earnings season for S&P 500 companies.",
            "Cryptocurrency market experiences high volatility.",
            "Interest rate hike sends bond yields soaring."
        ],
        "Space Exploration": [
            "NASA launches new mission to Mars seeking signs of ancient life.",
            "Private space companies unveil plans for lunar tourism.",
            "Hubble telescope captures stunning new images of distant galaxies.",
            "Astronauts prepare for extended stay on International Space Station.",
            "Breakthrough in propulsion technology could enable faster space travel."
        ],
        "Climate Change": [
            "International summit addresses urgent need for climate action.",
            "New report highlights accelerating global warming trends.",
            "Renewable energy investments surge amidst climate crisis.",
            "Extreme weather events cause widespread disruption.",
            "Conservation efforts aim to protect endangered species."
        ],
        "Cybersecurity": [
            "Major data breach exposes millions of user records.",
            "Governments collaborate on new cybersecurity defense strategies.",
            "Ransomware attacks target critical infrastructure.",
            "Two-factor authentication becomes standard for online security.",
            "Experts warn of growing threats from nation-state hackers."
        ],
        "Gaming": [
            "New open-world RPG breaks sales records on launch day.",
            "Esports industry sees massive growth in viewership and revenue.",
            "Virtual reality gaming experiences become more immersive.",
            "Indie game developers showcase innovative titles at expo.",
            "Next-gen consoles introduce advanced graphics capabilities."
        ],
        "Health & Wellness": [
            "Study reveals benefits of plant-based diets for heart health.",
            "Mental health awareness campaigns gain momentum.",
            "New vaccine shows promise against infectious disease.",
            "Wearable tech monitors fitness and sleep patterns.",
            "Mindfulness meditation reduces stress and improves focus."
        ],
        "Automotive": [
            "Electric vehicles dominate new car sales reports.",
            "Autonomous driving technology faces regulatory hurdles.",
            "Classic car auction sets new price records.",
            "Manufacturers unveil concept cars with futuristic designs.",
            "Global chip shortage impacts automotive production."
        ]
    ]

    for category in categories {
        for _ in 0..<10 { // Generate 10 examples per category, total 100
            if let templates = articleTemplates[category] {
                let text = templates.randomElement()!
                data.append((text, category))
            }
        }
    }
    // Add more diverse examples to reach a larger dataset size if needed
    for _ in 0..<50 { // Add 50 more random samples
        let randomCategory = categories.randomElement()!
        if let templates = articleTemplates[randomCategory] {
            let text = templates.randomElement()!
            data.append((text, randomCategory))
        }
    }

    return data.shuffled()
}

func trainAndSaveNewsClassifier(version: String) throws -> URL {
    let trainingData = generateNewsArticleTrainingData()
    
    let dataTable = try MLDataTable(array: trainingData.map { ["text": $0.text, "label": $0.label] })
    let (trainingTable, testingTable) = dataTable.randomSplit(by: 0.8, seed: 123)

    let classifier = try MLTextClassifier(trainingData: trainingTable,
                                          textColumn: "text",
                                          labelColumn: "label")

    let evaluation = classifier.evaluation(on: testingTable, textColumn: "text", labelColumn: "label")
    print("News Classifier v\(version) Training Accuracy: \(evaluation.accuracy)")

    let fileManager = FileManager.default
    let documentsURL = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let modelURL = documentsURL.appendingPathComponent("SwiftNewsClassifier_v\(version).mlmodel")

    try classifier.write(to: modelURL)
    print("News Classifier v\(version) model saved to: \(modelURL.path)")
    return modelURL
}

// MARK: - 2. Real-time Classification

class NewsArticleClassifier {
    private var model: NLModel?
    
    // In a real app, this would be loaded from the app bundle or a downloaded location
    init(modelURL: URL) {
        do {
            self.model = try NLModel(contentsOf: modelURL)
            print("News article classifier model loaded successfully from \(modelURL.lastPathComponent).")
        } catch {
            print("Error loading NLModel from \(modelURL.lastPathComponent): \(error.localizedDescription)")
            self.model = nil
        }
    }

    func classifyArticle(title: String, summary: String) -> String {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return "Unknown"
        }
        // Combine title and summary for classification
        let combinedText = "\(title). \(summary)"
        return model.predictedLabel(for: combinedText) ?? "Unknown"
    }
    
    func classifyArticleWithConfidence(title: String, summary: String) -> (label: String, confidence: Double) {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return ("Unknown", 0.0)
        }
        let combinedText = "\(title). \(summary)"
        let (label, probabilities) = model.predictedLabel(for: combinedText, probabilities: ())
        if let label = label, let confidence = probabilities[label] {
            return (label, confidence)
        }
        return ("Unknown", 0.0)
    }
    
    // Consideration for multi-label:
    // NLModel is single-label. For multi-label, one might train multiple binary classifiers
    // (e.g., "Is this AI?" yes/no, "Is this Politics?" yes/no), or use a different ML framework
    // that supports multi-label output. For NLModel, we'd typically pick the highest confidence
    // label as the primary, and perhaps display other high-confidence labels as secondary tags.
}

// MARK: - 3. User Feedback Mechanism

// In-memory storage for feedback for this exercise
@available(iOS 18.0, macOS 15.0, *)
var collectedUserFeedback: [UserFeedback] = []

@available(iOS 18.0, macOS 15.0, *)
func simulateUserCorrection(articleText: String, originalPrediction: String, userCorrectedLabel: String) {
    let feedback = UserFeedback(articleText: articleText,
                                originalPrediction: originalPrediction,
                                userCorrectedLabel: userCorrectedLabel,
                                timestamp: Date())
    collectedUserFeedback.append(feedback)
    print("User feedback recorded: '\(articleText)' was '\(originalPrediction)', corrected to '\(userCorrectedLabel)'.")
}

// MARK: - 4. Model Improvement Strategy (Conceptual & Simplified Implementation)

@available(iOS 18.0, macOS 15.0, *)
func prepareFeedbackForRetraining(feedback: [UserFeedback]) -> [(String, String)] {
    // This function converts UserFeedback objects into (text, label) tuples
    // suitable for NLModel.Trainer.
    // For simplicity, use the userCorrectedLabel as the ground truth.
    return feedback.map { ($0.articleText, $0.userCorrectedLabel) }
}

// MARK: - 5. Model Versioning (Conceptual)

/*
    **Model Versioning Strategy:**

    1.  **Naming Convention:** Use clear versioning in model filenames (e.g., `SwiftNewsClassifier_v1.mlmodel`, `SwiftNewsClassifier_v2.mlmodel`).
    2.  **Deployment:**
        *   **Initial Deployment:** `SwiftNewsClassifier_v1.mlmodel` is bundled with the app.
        *   **Over-the-Air (OTA) Updates:** When a new model (`v2`, `v3`, etc.) is trained using accumulated user feedback, it can be hosted on a remote server. The app would periodically check for new model versions, download them, and store them in the app's document directory or a dedicated cache.
        *   **A/B Testing:** For critical updates, different user groups could receive different model versions (e.g., 50% get v1, 50% get v2) to compare real-world performance metrics before a full rollout.
    3.  **Loading Logic:** The app needs logic to decide which model version to load. This could be:
        *   Always load the latest downloaded version if available, otherwise fallback to the bundled version.
        *   A configuration flag from the backend could dictate which version to use for a specific user.
    4.  **Rollback:** Maintain older versions on the server to allow for quick rollbacks if a new model performs poorly.
    5.  **Monitoring:** Continuously monitor model performance in production (e.g., prediction accuracy, latency) to detect degradation and trigger retraining or rollbacks.
*/

// MARK: - Main Execution

// Helper to check for iOS 18.0 / macOS 15.0 availability
func isUserFeedbackAvailable() -> Bool {
    if #available(iOS 18.0, macOS 15.0, *) {
        return true
    } else {
        return false
    }
}

func runNewsCategorizationDemo() {
    var initialModelURL: URL?
    do {
        // 1. Initial Model Training
        initialModelURL = try trainAndSaveNewsClassifier(version: "1")
    } catch {
        print("Failed to train or save initial news classifier model: \(error.localizedDescription)")
        return
    }

    guard let loadedModelURL = initialModelURL else {
        print("Initial news classifier model URL not available.")
        return
    }

    // 2. Real-time Classification
    let classifier = NewsArticleClassifier(modelURL: loadedModelURL)

    print("\n--- Initial Article Classification ---")
    let articlesToClassify = [
        ("AI Breakthrough: New Neural Network Achieves Record Accuracy", "Researchers at Google have unveiled a revolutionary AI model that surpasses previous benchmarks in complex pattern recognition, promising advances in various fields."),
        ("Election Polls Tighten in Swing States Ahead of November Vote", "With just weeks until the general election, recent polls indicate a narrow margin between leading candidates in several battleground states, intensifying campaign efforts."),
        ("Lakers Secure Playoff Spot with Dominant Performance", "The Los Angeles Lakers clinched their berth in the NBA playoffs after a decisive victory against their rivals, fueled by a stellar performance from their star forward."),
        ("Market Volatility Continues Amidst Economic Uncertainty", "Global stock markets experienced another day of fluctuations as investors react to rising inflation concerns and geopolitical tensions, impacting tech and energy sectors."),
        ("A recipe for delicious pasta.", "This simple recipe for carbonara will delight your taste buds."), // Out-of-category example
        ("SpaceX Prepares for Manned Mission to Moon", "Elon Musk's SpaceX is gearing up for its ambitious project to send astronauts to the lunar surface within the next five years, marking a new era of space travel.")
    ]

    for (title, summary) in articlesToClassify {
        let (prediction, confidence) = classifier.classifyArticleWithConfidence(title: title, summary: summary)
        let confidenceString = String(format: "%.2f", confidence)
        print("Article: '\(title)' -> Predicted: \(prediction) (Confidence: \(confidenceString))")
        
        // 3. Simulate User Feedback (if available OS version)
        if isUserFeedbackAvailable() {
            if prediction == "Automotive" && title.contains("AI Breakthrough") { // Simulate a misclassification
                simulateUserCorrection(articleText: "\(title). \(summary)",
                                       originalPrediction: prediction,
                                       userCorrectedLabel: "Artificial Intelligence")
            } else if prediction == "Basketball" && title.contains("Moon") { // Another simulated misclassification
                 simulateUserCorrection(articleText: "\(title). \(summary)",
                                       originalPrediction: prediction,
                                       userCorrectedLabel: "Space Exploration")
            }
        } else {
            print("Skipping user feedback simulation: Requires iOS 18.0+ / macOS 15.0+ for UserFeedback struct.")
        }
    }

    // 4. Model Improvement Strategy (Simplified Implementation)
    if isUserFeedbackAvailable() {
        if !collectedUserFeedback.isEmpty {
            print("\n--- Preparing User Feedback for Retraining ---")
            let feedbackForRetraining = prepareFeedbackForRetraining(feedback: collectedUserFeedback)
            print("Collected \(feedbackForRetraining.count) feedback items for retraining.")
            // In a real scenario, this data would be sent to a backend for actual retraining.
            // For this exercise, we just show the preparation.
            print("Example feedback for retraining: \(feedbackForRetraining.first ?? ("N/A", "N/A"))")
        } else {
            print("\nNo user feedback collected to prepare for retraining.")
        }
    }
}

// Call the demo function
runNewsCategorizationDemo()
