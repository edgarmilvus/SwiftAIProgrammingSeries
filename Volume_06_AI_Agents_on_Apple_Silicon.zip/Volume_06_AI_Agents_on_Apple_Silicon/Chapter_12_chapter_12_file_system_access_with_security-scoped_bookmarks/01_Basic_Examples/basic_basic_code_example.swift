
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Cocoa // For NSViewController, NSOpenPanel, etc.
import Foundation // For URL, FileManager, UserDefaults

// MARK: - Entitlements Requirement
// To use security-scoped bookmarks, your macOS app needs specific entitlements.
// Add these to your app's .entitlements file:
//
// <key>com.apple.security.app-sandbox</key>
// <true/>
// <key>com.apple.security.files.bookmarks.app-scope</key>
// <true/>
// <key>com.apple.security.files.user-selected.read-write</key>
// <true/>


/// A simple macOS View Controller to demonstrate security-scoped bookmarks.
/// It allows the user to select a directory, persist its bookmark, and then
/// save a new file into that directory using the resolved bookmark.
@available(macOS 13.0, *) // Using modern Concurrency and some newer APIs
class DocumentBookmarkViewController: NSViewController {

    // MARK: - UI Elements (Simplified for demonstration)
    private let selectDirectoryButton = NSButton()
    private let saveFileButton = NSButton()
    private let statusLabel = NSTextField(labelWithString: "No directory selected.")

    // MARK: - Properties
    private let bookmarkKey = "documentAnalysisDirectoryBookmark"
    private var securityScopedURL: URL? // The URL resolved from the bookmark, ready for access

    // MARK: - View Lifecycle
    override func loadView() {
        self.view = NSView()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadBookmarkAndResolveURL() // Attempt to load and resolve a bookmark on launch
    }

    /// Sets up the basic UI elements for the view controller.
    private func setupUI() {
        // Configure buttons
        selectDirectoryButton.title = "Select Document Directory"
        selectDirectoryButton.target = self
        selectDirectoryButton.action = #selector(selectDirectoryButtonTapped)
        selectDirectoryButton.translatesAutoresizingMaskIntoConstraints = false

        saveFileButton.title = "Save 'Analyzed' File"
        saveFileButton.target = self
        saveFileButton.action = #selector(saveFileButtonTapped)
        saveFileButton.translatesAutoresizingMaskIntoConstraints = false
        saveFileButton.isEnabled = false // Disable until a directory is selected/resolved

        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.maximumNumberOfLines = 0
        statusLabel.lineBreakMode = .byWordWrapping

        // Add to view hierarchy
        view.addSubview(selectDirectoryButton)
        view.addSubview(saveFileButton)
        view.addSubview(statusLabel)

        // Layout constraints (basic stack for vertical alignment)
        NSLayoutConstraint.activate([
            selectDirectoryButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectDirectoryButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 50),
            selectDirectoryButton.widthAnchor.constraint(equalToConstant: 250),
            selectDirectoryButton.heightAnchor.constraint(equalToConstant: 30),

            saveFileButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            saveFileButton.topAnchor.constraint(equalTo: selectDirectoryButton.bottomAnchor, constant: 20),
            saveFileButton.widthAnchor.constraint(equalToConstant: 250),
            saveFileButton.heightAnchor.constraint(equalToConstant: 30),

            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.topAnchor.constraint(equalTo: saveFileButton.bottomAnchor, constant: 40),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    /// Attempts to load a previously saved bookmark from UserDefaults and resolve it into a URL.
    private func loadBookmarkAndResolveURL() {
        guard let bookmarkData = UserDefaults.standard.data(forKey: bookmarkKey) else {
            updateStatus("No saved directory bookmark found. Please select a directory.")
            return
        }

        var isStale = false
        do {
            // 5. Resolve the bookmark data back into a URL.
            // The `securityScoped` option is crucial here.
            let resolvedURL = try URL(resolvingBookmarkData: bookmarkData,
                                      options: .withSecurityScope,
                                      relativeTo: nil,
                                      bookmarkDataIsStale: &isStale)

            if isStale {
                updateStatus("Bookmark is stale. Attempting to resolve, but may need re-selection.")
                // If stale, you might want to re-create the bookmark,
                // but often, the resolved URL is still valid.
                // For a robust app, you might prompt the user to re-select.
            }

            // 6. Call startAccessingSecurityScopedResource() to gain access.
            // This must be done before any file operations on the URL.
            if resolvedURL.startAccessingSecurityScopedResource() {
                self.securityScopedURL = resolvedURL
                updateStatus("Successfully resolved and accessed: \(resolvedURL.lastPathComponent)")
                saveFileButton.isEnabled = true
            } else {
                updateStatus("Failed to start accessing security-scoped resource. User likely revoked access.")
                self.securityScopedURL = nil
                saveFileButton.isEnabled = false
            }

        } catch {
            updateStatus("Error resolving bookmark: \(error.localizedDescription)")
            self.securityScopedURL = nil
            saveFileButton.isEnabled = false
        }
    }

    // MARK: - Actions

    /// Handles the "Select Document Directory" button tap.
    @objc private func selectDirectoryButtonTapped() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = false
        openPanel.prompt = "Select for AI Analysis"

        openPanel.begin { [weak self] response in
            guard response == .OK, let selectedURL = openPanel.url else {
                self.map { $0.updateStatus("Directory selection cancelled.") }
                return
            }

            // Ensure UI updates happen on the main actor
            Task { @MainActor in
                self?.handleSelectedDirectory(selectedURL)
            }
        }
    }

    /// Processes the user-selected directory, creates a bookmark, and persists it.
    /// - Parameter url: The URL of the directory selected by the user.
    private func handleSelectedDirectory(_ url: URL) {
        // 1. User selects a directory using NSOpenPanel. (Done in selectDirectoryButtonTapped)

        // Stop accessing any previously held resource before replacing it.
        securityScopedURL?.stopAccessingSecurityScopedResource()
        securityScopedURL = nil
        saveFileButton.isEnabled = false

        do {
            // 2. App creates a security-scoped bookmark from the selected directory URL.
            // The `withSecurityScope` option is essential here.
            let bookmarkData = try url.bookmarkData(options: .withSecurityScope,
                                                    includingResourceValuesForKeys: nil,
                                                    relativeTo: nil)

            // 3. App persists the bookmark data (e.g., to UserDefaults).
            UserDefaults.standard.set(bookmarkData, forKey: bookmarkKey)
            updateStatus("Bookmark created and saved for: \(url.lastPathComponent)")

            // Immediately resolve and gain access for current session
            loadBookmarkAndResolveURL()

        } catch {
            updateStatus("Error creating bookmark: \(error.localizedDescription)")
            self.securityScopedURL = nil
            saveFileButton.isEnabled = false
        }
    }

    /// Handles the "Save 'Analyzed' File" button tap.
    @objc private func saveFileButtonTapped() {
        guard let targetDirectoryURL = securityScopedURL else {
            updateStatus("No directory resolved. Please select or re-select a directory.")
            return
        }

        // 7. App performs file operations within that directory.
        let fileName = "AI_Analyzed_Document_\(UUID().uuidString.prefix(8)).txt"
        let fileURL = targetDirectoryURL.appendingPathComponent(fileName)
        let content = "This document was analyzed by our AI agent at \(Date()).\n" +
                      "Summary: The AI identified key themes related to LLMs and Apple Silicon."

        do {
            try content.write(to: fileURL, atomically: true, encoding: .utf8)
            updateStatus("Successfully saved '\(fileName)' to \(targetDirectoryURL.lastPathComponent)")
        } catch {
            updateStatus("Error saving file: \(error.localizedDescription)")
        }
        // 8. App calls stopAccessingSecurityScopedResource() when done with access.
        // For persistent access throughout the app's lifecycle, you might keep access open
        // and only call stopAccessingSecurityScopedResource() when the app quits,
        // or when the user explicitly changes the directory.
        // For this example, we'll keep it open after initial resolution.
        // A more granular approach would be to start/stop around specific file operations.
    }

    /// Updates the status label on the main thread.
    /// - Parameter message: The message to display.
    @MainActor
    private func updateStatus(_ message: String) {
        statusLabel.stringValue = message
        print(message) // Also print to console for debugging
    }

    deinit {
        // Crucial: Stop accessing the resource when the controller is deallocated
        // or when the app is about to quit if access was held globally.
        securityScopedURL?.stopAccessingSecurityScopedResource()
        print("Stopped accessing security-scoped resource.")
    }
}

// MARK: - Application Delegate (for a minimal macOS app setup)

@main
class AppDelegate: NSObject, NSApplicationDelegate {

    var window: NSWindow!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Create a window
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 600, height: 400),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.title = "AI Document Manager"
        window.contentViewController = DocumentBookmarkViewController()
        window.makeKeyAndOrderFront(nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }
}
