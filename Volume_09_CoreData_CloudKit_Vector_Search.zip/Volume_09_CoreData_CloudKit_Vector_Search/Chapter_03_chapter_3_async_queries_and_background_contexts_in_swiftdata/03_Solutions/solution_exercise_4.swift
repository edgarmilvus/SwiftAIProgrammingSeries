
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftData
import SwiftUI

@Model
final class Note {
    var id: UUID
    var text: String
    var vector: [Float]?
    var isAnalyzing: Bool
    
    init(id: UUID = UUID(), text: String, vector: [Float]? = nil, isAnalyzing: Bool = false) {
        self.id = id
        self.text = text
        self.vector = vector
        self.isAnalyzing = isAnalyzing
    }
}

actor SemanticIntelligenceEngine: ModelActor {
    let modelContainer: ModelContainer
    let modelExecutor: any ModelExecutor
    
    init(container: ModelContainer) {
        self.modelContainer = container
        let context = ModelContext(container)
        self.modelExecutor = DefaultSerialModelExecutor(modelContext: context)
    }
    
    func analyzeNote(noteID: PersistentIdentifier) async throws {
        // 1. Fetch the latest version of the note using the ID
        guard let note = try modelContext.model(for: noteID) as? Note else { return }
        
        // 2. Set state to analyzing and save immediately to update UI
        note.isAnalyzing = true
        try modelContext.save()
        
        do {
            // 3. Simulate heavy AI workload (3 seconds)
            try await Task.sleep(for: .seconds(3))
            
            // 4. Generate dummy vector
            let dummyVector = (0..<1536).map { _ in Float.random(in: -1...1) }
            
            // 5. Update note and finalize
            note.vector = dummyVector
            note.isAnalyzing = false
            try modelContext.save()
            
        } catch {
            // 6. Error Handling: Ensure the UI doesn't get stuck in "Analyzing" state
            note.isAnalyzing = false
            try? modelContext.save()
            throw error
        }
    }
}

struct NoteListView: View {
    @Query var notes: [Note]
    @Environment(\.modelContext) private var mainContext
    @State private var engine: SemanticIntelligenceEngine?
    
    var body: some View {
        List(notes) { note in
            HStack {
                VStack(alignment: .leading) {
                    Text(note.text).lineLimit(1)
                    if note.vector != nil {
                        Text("Analysis Complete").font(.caption).foregroundStyle(.green)
                    }
                }
                Spacer()
                if note.isAnalyzing {
                    ProgressView()
                } else {
                    Button("Analyze") {
                        analyze(note)
                    }
                }
            }
        }
        .onAppear {
            // Initialize the engine with the shared container
            self.engine = SemanticIntelligenceEngine(container: mainContext.container)
        }
    }
    
    private func analyze(_ note: Note) {
        let id = note.persistentModelID
        let engine = self.engine
        
        Task {
            do {
                try await engine?.analyzeNote(noteID: id)
            } catch {
                print("AI Analysis failed: \(error)")
            }
        }
    }
}
