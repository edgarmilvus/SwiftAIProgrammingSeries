
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // Required for @Observable

// Assuming ChatViewModel is defined as above, but now using @Observable
@available(iOS 18.0, macOS 15.0, *)
@Observable
class ChatViewModel {
    private let llmEngine = LLMInferenceActor()
    var currentResponse: String = ""
    var isLoading: Bool = false
    var errorMessage: String?
    var isModelLoaded: Bool = false

    init() {
        // Load model asynchronously
        Task {
            do {
                try await llmEngine.loadModel(path: "/path/to/your/model.gguf")
                await MainActor.run {
                    self.isModelLoaded = true
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to load LLM model: \(error.localizedDescription)"
                }
            }
        }
    }

    func sendPrompt(_ text: String) {
        guard isModelLoaded else {
            errorMessage = "Model not loaded yet."
            return
        }
        isLoading = true
        errorMessage = nil
        currentResponse = ""
        let prompt = Prompt(text: text, temperature: 0.7, maxTokens: 256)

        Task {
            do {
                let response = try await llmEngine.generate(prompt: prompt)
                await MainActor.run {
                    self.currentResponse = response.generatedText
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "LLM inference failed: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ChatView: View {
    @State private var viewModel = ChatViewModel() // Use @State for initial creation
    @State private var inputText: String = ""

    var body: some View {
        VStack {
            if !viewModel.isModelLoaded {
                ProgressView("Loading LLM model...")
                    .padding()
            } else if viewModel.isLoading {
                ProgressView("Generating response...")
                    .padding()
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            } else {
                ScrollView {
                    Text(viewModel.currentResponse)
                        .padding()
                }
            }

            Spacer()

            HStack {
                TextField("Enter your prompt", text: $inputText)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button("Send") {
                    viewModel.sendPrompt(inputText)
                    inputText = ""
                }
                .disabled(viewModel.isLoading || !viewModel.isModelLoaded)
                .padding(.trailing)
            }
        }
        .navigationTitle("Local LLM Chat")
    }
}
