
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

enum BudgetError: Error {
    case insufficientFunds(required: Int, available: Int)
    case budgetExhausted
}

/// An actor that manages the user's token budget in a thread-safe manner.
actor TokenBudgetManager {
    private let storageKey = "com.writeflow.remainingTokens"
    private let limitKey = "com.writeflow.dailyLimit"
    
    private(set) var remainingTokens: Int {
        didSet {
            persist()
        }
    }
    
    private(set) var dailyLimit: Int {
        didSet {
            persist()
        }
    }

    init(initialLimit: Int, initialBalance: Int) {
        // Load persisted values or use defaults
        let defaults = UserDefaults.standard
        self.dailyLimit = defaults.object(forKey: limitKey) as? Int ?? initialLimit
        self.remainingTokens = defaults.object(forKey: storageKey) as? Int ?? initialBalance
    }

    /// Heuristic: 1 token is approximately 4 characters.
    func estimateTokens(for text: String) -> Int {
        let characterCount = text.count
        // Adding a 10% safety buffer to the estimate
        let estimate = Int(Double(characterCount) / 4.0)
        return Int(Double(estimate) * 1.1)
    }

    /// A "pre-flight" check to see if the request is likely to succeed.
    func canAfford(estimatedTokens: Int) async -> Bool {
        return remainingTokens >= estimatedTokens
    }

    /// The single source of truth for balance deduction.
    /// This prevents race conditions where multiple tasks pass 'canAfford'
    /// but collectively exceed the budget.
    func consume(tokens: Int) async throws {
        guard remainingTokens >= tokens else {
            throw BudgetError.insufficientFunds(required: tokens, available: remainingTokens)
        }
        
        remainingTokens -= tokens
        
        if remainingTokens <= 0 {
            remainingTokens = 0
            throw BudgetError.budgetExhausted
        }
    }

    // MARK: - Persistence
    
    private func persist() {
        UserDefaults.standard.set(remainingTokens, forKey: storageKey)
        UserDefaults.standard.set(dailyLimit, forKey: limitKey)
    }
}

// Example Usage
@MainActor
func runBudgetDemo() async {
    let manager = TokenBudgetManager(initialLimit: 1000, initialBalance: 100)
    let userInput = "Hello, how are you today?"
    
    let estimate = await manager.estimateTokens(for: userInput)
    print("Estimated tokens: \(estimate)")
    
    if await manager.canAfford(estimatedTokens: estimate) {
        do {
            try await manager.consume(tokens: estimate)
            print("Success! Remaining: \(await manager.remainingTokens)")
        } catch {
            print("Error: \(error)")
        }
    } else {
        print("Insufficient credits.")
    }
}
