
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI
import Observation

// MARK: - Dependencies
/*
 To run this in a real project, you would add the following to your Package.swift:
 dependencies: [
    .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
 ]
 For this example, we implement a lightweight version to demonstrate the logic.
*/

// MARK: - Models & Errors

/// Represents the types of errors that can occur during the AI processing pipeline.
/// This is crucial for App Store submission to ensure the user receives meaningful feedback.
enum AIProcessingError: LocalizedError {
    case piiDetectedAndUnmaskable
    case budgetExceeded(limit: Int)
    case networkError(Error)
    case invalidResponse
    
    var errorDescription: String? {
        switch self {
        case .piiDetectedAndUnmaskable:
            return "Privacy protection blocked the request due to sensitive information."
        case .budgetExceeded(let limit):
            return "The request is too large. Please limit your entry to \(limit) characters."
        case .networkError(let error):
            return "Connection error: \(error.localizedDescription)"
        case .invalidResponse:
            return "The AI returned an unexpected response."
        }
    }
}

/// A structure representing the final result of an AI analysis.
struct AIAnalysis: Sendable, Identifiable {
    let id = UUID()
    let sentiment: String
    let summary: String
}

// MARK: - Privacy Layer

/// An actor responsible for scrubbing sensitive information.
/// Using an `actor` ensures that privacy-sensitive scrubbing operations 
/// are isolated and thread-safe.
actor PrivacyGuard {
    /// A collection of regex patterns to identify PII.
    /// In a real-world app, this would be much more sophisticated (e.g., using Natural Language framework).
    private let piiPatterns: [String: String] = [
        "email": "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}",
        "phone": "\\+?\\d{1,4}?[-.\\s]?\\(?\\d{1,3}?\\)?[-.\\s]?\\d{1,4}[-.\\s]?\\d{1,4}[-.\\s]?\\d{1,9}"
    ]
    
    /// Scans the input text and replaces sensitive data with generic placeholders.
    /// - Parameter text: The raw user input.
    /// - Returns: A sanitized version of the text.
    func scrub(_ text: String) -> String {
        var sanitizedText = text
        
        for (label, pattern) in piiPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
                let range = NSRange(sanitizedText.startIndex..<sanitizedText.endIndex, in: sanitizedText)
                sanitizedText = regex.stringByReplacingMatches(
                    in: sanitizedText,
                    options: [],
                    range: range,
                    withTemplate: "[\(label.uppercased())]"
                )
            }
        }
        return sanitizedText
    }
}

// MARK: - Cost Management Layer

/// An actor that manages the "Token Budget" to prevent excessive API costs.
/// By using an actor, we prevent data races when multiple requests attempt 
/// to update the usage statistics simultaneously.
actor CostController {
    private let maxCharacterLimit = 1000
    private(set) var totalTokensUsed: Int = 0
    
    /// Estimates the "cost" of a request based on character count.
    /// Real-world implementation would use a Tiktoken-like algorithm.
    /// - Parameter text: The text to evaluate.
    /// - Throws: `AIProcessingError.budgetExceeded` if the text is too long.
    func validateAndTrackUsage(for text: String) throws {
        let estimatedCost = text.count // Simple heuristic for this example
        
        if estimatedCost > maxCharacterLimit {
            throw AIProcessingError.budgetExceeded(limit: maxCharacterLimit)
        }
        
        totalTokensUsed += estimatedCost
    }
}

// MARK: - AI Service Layer

/// The service responsible for communicating with the external LLM API.
/// Marked as `Sendable` to ensure it can be safely passed across concurrency boundaries.
final class LLMService: Sendable {
    private let apiKey = "sk-placeholder" // In production, use a secure backend proxy!
    
    /// Sends the sanitized text to the AI provider.
    /// - Parameter sanitizedText: The text after privacy scrubbing.
    /// - Returns: An `AIAnalysis` object.
    func fetchAnalysis(for sanitizedText: String) async throws -> AIAnalysis {
        // Simulate network latency
        try await Task.sleep(for: .seconds(2))
        
        // In a real app, this is where the URLSession call to OpenAI/LangChain happens.
        // We simulate a successful response.
        return AIAnalysis(
            sentiment: "Positive",
            summary: "The user is reflecting on a productive day."
        )
    }
}

// MARK: - ViewModel (The Orchestrator)

@Observable
@MainActor
final class JournalViewModel {
    /// The user's current input.
    var journalEntry: String = ""
    
    /// The result of the AI analysis.
    var analysis: AIAnalysis?
    
    /// Loading state for the UI.
    var isProcessing: Bool = false
    
    /// Error message for the UI.
    var errorMessage: String?
    
    // Dependencies
    private let privacyGuard = PrivacyGuard()
    private let costController = CostController()
    private let llmService = LLMService()
    
    /// The primary workflow for processing a journal entry.
    /// This function demonstrates the orchestration of the privacy and cost layers.
    func processEntry() async {
        isProcessing = true
        errorMessage = nil
        
        do {
            // 1. Privacy Scrubbing (Local)
            // We move the work to the PrivacyGuard actor to keep the MainActor free for UI.
            let sanitized = await privacyGuard.scrub(journalEntry)
            
            // 2. Cost Validation (Local)
            // We check if the request is within budget before making a network call.
            try await costController.validateAndTrackUsage(for: sanitized)
            
            // 3. Remote API Call (Network)
            // Only the sanitized and validated text is sent over the wire.
            let result = try await llmService.fetchAnalysis(for: sanitized)
            
            // 4. UI Update
            // Since we are on @MainActor, this is safe.
            self.analysis = result
            
        } catch let error as AIProcessingError {
            self.errorMessage = error.localizedDescription
        } catch {
            self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
        }
        
        isProcessing = false
    }
}

// MARK: - UI Layer

@available(iOS 18.0, *)
struct JournalView: View {
    @State private var viewModel = JournalViewModel()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                TextEditor(text: $viewModel.journalEntry)
                    .frame(height: 200)
                    .padding(4)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.secondary.opacity(0.5)))
                    .padding(.horizontal)
                
                if viewModel.isProcessing {
                    ProgressView("AI is thinking...")
                } else {
                    Button(action: {
                        Task {
                            await viewModel.processEntry()
                        }
                    }) {
                        Label("Analyze Entry", systemImage: "sparkles")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.horizontal)
                    .disabled(viewModel.journalEntry.isEmpty)
                }
                
                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .font(.caption)
                        .multilineTextAlignment(.center)
                        .padding()
                }
                
                if let analysis = viewModel.analysis {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("AI Insights")
                            .font(.headline)
                        Divider()
                        Text("Sentiment: \(analysis.sentiment)")
                        Text("Summary: \(analysis.summary)")
                    }
                    .padding()
                    .background(Color.secondary.opacity(0.1))
                    .cornerRadius(12)
                    .padding()
                }
                
                Spacer()
            }
            .navigationTitle("Smart Journal")
        }
    }
}

#Preview {
    JournalView()
}
