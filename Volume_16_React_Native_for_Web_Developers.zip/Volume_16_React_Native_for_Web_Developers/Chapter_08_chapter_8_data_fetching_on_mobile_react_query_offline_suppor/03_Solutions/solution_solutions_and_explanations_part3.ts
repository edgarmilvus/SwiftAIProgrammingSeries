/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useQuery, focusManager } from '@tanstack/react-query';
import { useAppState, AppStateStatus } from '@react-native-community/hooks'; // Assuming external hook for AppState

// Mock fetching user balance
const fetchBalance = async () => {
  console.log('Fetching balance...');
  return { amount: (Math.random() * 1000).toFixed(2) };
};

export const Dashboard = () => {
  // 1. Check App State (Foreground/Background)
  // Note: In a real RN app, we use AppState from 'react-native' or a hook wrapper
  const appState = useAppState(); 

  // 2. Determine if we should poll
  // Polling should only run if the app is in the foreground ('active')
  const isActive = appState === 'active';

  const { data, isRefetching, refetch } = useQuery({
    queryKey: ['balance'],
    queryFn: fetchBalance,
    
    // 3. Refetch Strategies
    refetchOnWindowFocus: true, // Standard web/mobile focus refetch
    refetchOnReconnect: true,   // Refetch when network comes back
    
    // 4. Conditional Polling
    // Only poll if the app is active
    refetchInterval: isActive ? 5000 : false, // 5 seconds
    refetchIntervalInBackground: false, // Explicitly stop polling in background
    
    // Optional: To prevent UI flashing during background refetches when returning to foreground
    refetchOnMount: true, 
  });

  // Visual Feedback for background refetch
  // 'isRefetching' is true for background fetches too, but we can distinguish
  // by checking if we have data already.
  const isBackgroundUpdate = isRefetching && data;

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Current Balance</Text>
      <Text style={styles.amount}>${data?.amount || '0.00'}</Text>
      
      {isBackgroundUpdate && (
        <Text style={styles.updateIndicator}>Updating...</Text>
      )}
      
      <Text style={styles.info}>
        Refetch on Focus: Enabled{'\n'}
        Polling: {isActive ? 'Active (5s)' : 'Paused'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5' },
  label: { fontSize: 16, color: '#666' },
  amount: { fontSize: 48, fontWeight: 'bold', marginVertical: 20 },
  updateIndicator: { color: 'green', fontSize: 12, marginTop: 5 },
  info: { marginTop: 40, textAlign: 'center', color: '#888', fontSize: 11 },
});

// Mock useAppState hook implementation for context
const useAppState = () => {
  // In a real implementation, this hooks into React Native's AppState API
  // For this solution, we assume it returns 'active' or 'background'
  return 'active' as AppStateStatus; 
};
