
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage // Essential for NLP tasks

// MARK: - SmartNoteProcessor Class

/// A utility class for processing text notes using Apple's Natural Language framework.
/// It demonstrates basic tokenization, Part-of-Speech (POS) tagging, and Named Entity Recognition (NER).
///
/// This class encapsulates the logic for analyzing a piece of text, breaking it
/// down into tokens (words) and assigning linguistic tags.
@available(iOS 13.0, macOS 10.15, *) // NLTagger is available from these versions
class SmartNoteProcessor {

    /// Processes a given text note to extract linguistic information.
    /// It performs Part-of-Speech (POS) tagging and Named Entity Recognition (NER)
    /// on the input text and prints the results to the console.
    ///
    /// - Parameter text: The input string representing the note to be analyzed.
    func processNote(_ text: String) {
        print("--- Processing Note: \"\(text)\" ---")

        // 1. Initialize NLTagger with the desired tag schemes.
        // NLTagger is the primary class for performing linguistic analysis.
        // We specify an array of `NLTagScheme`s that we want the tagger to compute.
        // `.lexicalCategory` is for Part-of-Speech (e.g., Noun, Verb).
        // `.namedEntity` is for identifying entities like people, places, organizations.
        //
        // IMPORTANT: NLTagger is NOT thread-safe. If you need to use it in a multi-threaded
        // environment, instantiate a separate tagger for each thread or synchronize access.
        let tagger = NLTagger(tagSchemes: [.lexicalCategory, .namedEntity])
        tagger.string = text // Assign the text to be processed by the tagger.

        // 2. Define the options for enumeration.
        // These options control how the tokenizer breaks down the text and what it includes/excludes.
        // `.omitWhitespace`: Ignores whitespace characters when tokenizing.
        // `.omitPunctuation`: Ignores punctuation characters.
        // `.joinNames`: Attempts to group multi-word named entities (e.g., "San Francisco" as one token).
        let options: NLTokenizer.Options = [.omitWhitespace, .omitPunctuation, .joinNames]

        print("\n--- Part-of-Speech (POS) Tagging ---")
        // 3. Enumerate tokens and their Part-of-Speech tags.
        // The `enumerateTags` method iterates through the text, finding tokens and applying tags
        // based on the specified `unit` (e.g., `.word`, `.sentence`) and `scheme`.
        // The closure provides the identified `tag`, the `tokenRange` within the original string,
        // and a boolean `stop` flag (which we always return `true` for to continue enumeration).
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalCategory, options: options) { tag, tokenRange in
            // Extract the actual token string from the original text using the `tokenRange`.
            let token = String(text[tokenRange])

            // Print the token and its Part-of-Speech tag.
            // `tag?.rawValue` provides the string representation of the tag (e.g., "Verb", "Noun").
            // We use nil-coalescing (`?? "Unknown"`) for robustness if a tag isn't found.
            print("  Token: '\(token)' | POS: \(tag?.rawValue ?? "Unknown")")
            return true // Return true to continue the enumeration process.
        }

        print("\n--- Named Entity Recognition (NER) ---")
        // 4. Enumerate named entities.
        // We re-use the same `tagger` instance but switch to the `.namedEntity` scheme.
        // This demonstrates how different analysis schemes can be applied to the same text.
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .namedEntity, options: options) { tag, tokenRange in
            let token = String(text[tokenRange])
            // Filter out "other" tags. `.other` indicates that a token was processed but
            // did not match any specific named entity type (like Person, Place, Organization).
            if let entityTag = tag, entityTag != .other {
                // Print the identified named entity and its type (e.g., "Person", "Place").
                print("  Entity: '\(token)' | Type: \(entityTag.rawValue)")
            }
            return true // Return true to continue enumeration.
        }
    }
}

// MARK: - Example Usage

/// Main function to demonstrate the `SmartNoteProcessor`.
/// This function creates an instance of the processor and feeds it several example notes.
@available(iOS 13.0, macOS 10.15, *)
func runBasicNLExample() {
    print("Starting Natural Language Basic Example...")

    let processor = SmartNoteProcessor()

    // Example 1: A note with a person, organization, and place.
    let note1 = "Apple is located in Cupertino, California. Tim Cook is the CEO."
    processor.processNote(note1)

    print("\n----------------------------------------\n")

    // Example 2: A note with a product and a travel destination.
    let note2 = "I need to buy a new MacBook Pro for my trip to Paris next month."
    processor.processNote(note2)

    print("\n----------------------------------------\n")

    // Example 3: A more complex note with an organization, a date, and a specific location.
    let note3 = "The conference will be held by Google on October 26th at the Moscone Center in San Francisco."
    processor.processNote(note3)

    print("\nNatural Language Basic Example Finished.")
}

// To run this example:
// 1. Create a new iOS or macOS project (or Playground).
// 2. Ensure your target's deployment minimum is iOS 13.0 / macOS 10.15 or later.
// 3. Paste the code into a Swift file.
// 4. Call `runBasicNLExample()` from your main entry point (e.g., `ContentView` for SwiftUI, `AppDelegate` for UIKit, or directly in a Playground).
//
// Example for a Playground:
// import PlaygroundSupport
// PlaygroundPage.current.needsIndefiniteExecution = true // For async operations if any, though not strictly needed here.
// runBasicNLExample()
