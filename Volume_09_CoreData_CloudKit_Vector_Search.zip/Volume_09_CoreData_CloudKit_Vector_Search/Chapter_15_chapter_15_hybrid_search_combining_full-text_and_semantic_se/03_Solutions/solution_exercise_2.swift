
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// A protocol that allows any type to be processed by the normalizer.
protocol Scoreable: Sendable {
    var id: UUID { get }
    var rawScore: Double { get }
}

/// A value-type representation of a search result.
struct RawSearchResult: Scoreable {
    let id: UUID
    let rawScore: Double
}

struct ScoreNormalizer {
    
    /// Performs Min-Max Normalization on a collection of Scoreable items.
    /// Complexity: O(n)
    func normalize<T: Scoreable>(_ results: [T]) -> [T] {
        guard !results.isEmpty else { return [] }
        
        // Find Min and Max in a single pass
        // We use a manual loop or reduce to ensure O(n)
        var minScore = Double.greatestFiniteMagnitude
        var maxScore = -Double.greatestFiniteMagnitude
        
        for result in results {
            if result.rawScore < minScore { minScore = result.rawScore }
            if result.rawScore > maxScore { maxScore = result.rawScore }
        }
        
        // Handle the "Zero Variance" case: 
        // If max == min, all scores are identical. 
        // To avoid division by zero, we return a score of 1.0 (or 0.0) for all.
        let range = maxScore - minScore
        guard range > 0 else {
            // If all scores are the same, we treat them as equally relevant (1.0)
            // or equally irrelevant (0.0). Here we choose 1.0.
            return results.map { result in
                // We must return the same type, so we'd ideally use a 
                // specialized mapping if T was a class, but since T is Scoreable 
                // and we want to return T, this works best with structs.
                // For this exercise, we'll assume we return a new instance of the same type.
                return result 
            }
        }
        
        // Map the results to their normalized versions.
        // Note: In a real generic implementation, we'd need a way to reconstruct T.
        // For this exercise, we'll return a specialized normalized version.
        return results // In a real implementation, you'd return [NormalizedResult]
    }
    
    /// A more practical implementation for the exercise requirements
    func normalizeScores(in results: [RawSearchResult]) -> [RawSearchResult] {
        guard !results.isEmpty else { return [] }
        
        let scores = results.map { $0.rawScore }
        guard let minScore = scores.min(), let maxScore = scores.max() else { return [] }
        
        let range = maxScore - minScore
        
        return results.map { result in
            let normalized = range == 0 ? 1.0 : (result.rawScore - minScore) / range
            return RawSearchResult(id: result.id, rawScore: normalized)
        }
    }
}

// MARK: - Example Usage
let normalizer = ScoreNormalizer()
let rawResults = [
    RawSearchResult(id: UUID(), rawScore: 10.0),
    RawSearchResult(id: UUID(), rawScore: 50.0),
    RawSearchResult(id: UUID(), rawScore: 100.0),
    RawSearchResult(id: UUID(), rawScore: 100.0) // Duplicate max
]

let normalized = normalizer.normalizeScores(in: rawResults)
for res in normalized {
    print("ID: \(res.id), Normalized Score: \(res.rawScore)")
}
