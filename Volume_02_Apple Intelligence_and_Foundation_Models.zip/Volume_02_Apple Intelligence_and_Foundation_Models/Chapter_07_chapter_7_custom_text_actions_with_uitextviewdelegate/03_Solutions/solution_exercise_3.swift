
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import Foundation // In a real iOS 18 project, you would import Foundation.AI

// Reusing the MockAITextGenerator and AI alias from Exercise 1.
// In a real project, these would be defined once or imported from the framework.

// MARK: - Custom Reply Suggestions View
class ReplySuggestionsView: UIView {
    var onReplySelected: ((String) -> Void)?
    
    private let stackView: UIStackView = {
        let sv = UIStackView()
        sv.axis = .vertical
        sv.spacing = 8
        sv.distribution = .fillEqually
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Quick Replies:"
        label.font = UIFont.preferredFont(forTextStyle: .headline)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        backgroundColor = .systemGray5.withAlphaComponent(0.95)
        layer.cornerRadius = 12
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.1
        layer.shadowOffset = .zero
        layer.shadowRadius = 10
        
        addSubview(titleLabel)
        addSubview(stackView)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: topAnchor, constant: 12),
            titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            
            stackView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            stackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            stackView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -12)
        ])
    }
    
    func configure(with replies: [String]) {
        stackView.arrangedSubviews.forEach { $0.removeFromSuperview() } // Clear previous replies
        
        for reply in replies {
            let button = UIButton(type: .system)
            button.setTitle(reply, for: .normal)
            button.titleLabel?.font = UIFont.preferredFont(forTextStyle: .subheadline)
            button.setTitleColor(.label, for: .normal)
            button.contentHorizontalAlignment = .leading
            button.backgroundColor = .systemBackground.withAlphaComponent(0.7)
            button.layer.cornerRadius = 8
            button.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
            button.addTarget(self, action: #selector(replyButtonTapped(_:)), for: .touchUpInside)
            stackView.addArrangedSubview(button)
        }
    }
    
    @objc private func replyButtonTapped(_ sender: UIButton) {
        if let reply = sender.title(for: .normal) {
            onReplySelected?(reply)
        }
    }
}


class IntelligentReplyGeneratorViewController: UIViewController, UITextViewDelegate {

    private lazy var textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        tv.text = "Hello there! I just wanted to check in about our meeting tomorrow. Are we still on for 10 AM?\n\n(Select this message to generate a reply.)\n\nAnother message: 'I finished the report, it's in the shared drive. Let me know if you need anything else.'\n\n(Select this one too!)\n\nThis is a long paragraph that is not a message. This should not trigger the reply generator."
        return tv
    }()
    
    private var replySuggestionsView: ReplySuggestionsView?
    private var replySuggestionsViewBottomConstraint: NSLayoutConstraint?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Intelligent Reply"
        view.backgroundColor = .systemBackground
        setupTextView()
        
        // Observe keyboard notifications to adjust reply suggestions view
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupTextView() {
        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
        textView.delegate = self
    }

    // MARK: - UITextViewDelegate

    @available(iOS 16.0, *)
    func textInput(_ textInput: UITextInput, menuElementsFor textRange: UITextRange, at point: CGPoint, sender: Any?) -> [UIMenuElement] {
        guard let textView = textInput as? UITextView else { return [] }

        // Get the currently selected text
        guard let selectedText = textView.text(in: textRange), !selectedText.isEmpty else {
            return []
        }

        // Heuristic: Only offer reply generation for "message-like" selections
        // e.g., not too short, not too long, and doesn't span many paragraphs.
        if selectedText.count < 10 || selectedText.count > 500 || selectedText.components(separatedBy: "\n\n").count > 2 {
            return []
        }

        let generateReplyAction = UIAction(title: "Generate Quick Reply", image: UIImage(systemName: "text.insert")) { [weak self] _ in
            self?.generateQuickReplies(for: selectedText)
        }

        // Return a menu with our custom action.
        return [generateReplyAction]
    }

    // MARK: - AI Integration

    private func generateQuickReplies(for message: String) {
        // Feature availability check for iOS 18
        guard #available(iOS 18.0, *) else {
            self.showAlert(title: "Feature Unavailable", message: "This AI feature requires iOS 18 or later.")
            return
        }

        self.showLoadingAlert(message: "Generating replies...")

        Task {
            do {
                let prompt = "Given the message: '\(message)', suggest 3 short, polite reply options."
                let options = AI.TextGenerationOptions()
                options.numberOfCompletions = 3 // Request multiple suggestions
                
                let result = try await AI.TextGenerator.generate(prompt, options: options)
                let replies = result.completions.map { $0.text }
                
                DispatchQueue.main.async {
                    self.dismissLoadingAlert()
                    if replies.isEmpty {
                        self.showAlert(title: "No Replies", message: "Could not generate any quick replies.")
                    } else {
                        self.showReplySuggestions(replies: replies)
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.dismissLoadingAlert()
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }
    
    // MARK: - Reply Suggestions UI Management
    
    private func showReplySuggestions(replies: [String]) {
        dismissReplySuggestions() // Dismiss any existing ones first
        
        let suggestionsView = ReplySuggestionsView()
        suggestionsView.translatesAutoresizingMaskIntoConstraints = false
        suggestionsView.configure(with: replies)
        suggestionsView.onReplySelected = { [weak self] reply in
            self?.insertReplyIntoTextView(reply)
            self?.dismissReplySuggestions()
        }
        
        view.addSubview(suggestionsView)
        self.replySuggestionsView = suggestionsView
        
        // Position the suggestions view above the keyboard or at the bottom if no keyboard
        let bottomConstraint = suggestionsView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        self.replySuggestionsViewBottomConstraint = bottomConstraint
        
        NSLayoutConstraint.activate([
            suggestionsView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            suggestionsView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            bottomConstraint
        ])
        
        // Animate its appearance
        suggestionsView.alpha = 0
        UIView.animate(withDuration: 0.3) {
            suggestionsView.alpha = 1
        }
    }
    
    private func dismissReplySuggestions() {
        replySuggestionsView?.removeFromSuperview()
        replySuggestionsView = nil
        replySuggestionsViewBottomConstraint = nil
    }
    
    private func insertReplyIntoTextView(_ reply: String) {
        // Ensure text is inserted at the current cursor position, not replacing selection
        if let selectedRange = textView.selectedTextRange {
            textView.replace(selectedRange, withText: reply + " ") // Add a space for convenience
            // Move cursor to end of inserted text
            if let newEndPosition = textView.position(from: selectedRange.start, offset: reply.count + 1) {
                textView.selectedTextRange = textView.textRange(from: newEndPosition, to: newEndPosition)
            }
        } else {
            // If no selection, append to the end
            textView.text += reply + " "
        }
        textView.becomeFirstResponder() // Ensure keyboard is up
    }
    
    // MARK: - Keyboard Adjustments
    
    @objc private func keyboardWillShow(notification: NSNotification) {
        guard let userInfo = notification.userInfo,
              let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
              let animationDuration = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double else { return }
        
        let keyboardHeight = keyboardFrame.height - view.safeAreaInsets.bottom
        
        UIView.animate(withDuration: animationDuration) {
            self.replySuggestionsViewBottomConstraint?.constant = -keyboardHeight - 20
            self.view.layoutIfNeeded()
        }
    }
    
    @objc private func keyboardWillHide(notification: NSNotification) {
        guard let userInfo = notification.userInfo,
              let animationDuration = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double else { return }
        
        UIView.animate(withDuration: animationDuration) {
            self.replySuggestionsViewBottomConstraint?.constant = -20 // Back to default position
            self.view.layoutIfNeeded()
        }
    }

    // MARK: - UI Utility Functions (reused from Exercise 1)

    private var loadingAlert: UIAlertController?

    private func showLoadingAlert(message: String) {
        loadingAlert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        loadingAlert?.view.addSubview(indicator)
        
        NSLayoutConstraint.activate([
            indicator.centerXAnchor.constraint(equalTo: loadingAlert!.view.centerXAnchor),
            indicator.centerYAnchor.constraint(equalTo: loadingAlert!.view.centerYAnchor, constant: 20)
        ])
        indicator.startAnimating()
        present(loadingAlert!, animated: true)
    }

    private func dismissLoadingAlert() {
        loadingAlert?.dismiss(animated: true)
        loadingAlert = nil
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
