
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreData
import Combine
import Observation

// MARK: - Supporting Types

/// A representation of a high-dimensional vector.
/// In a production app, this would be a specialized type or a wrapper around Data.
typealias VectorEmbedding = [Float]

/// Errors specific to the Knowledge Base domain.
enum KnowledgeError: Error {
    case embeddingFailed
    case persistenceError(Error)
    case searchFailed
}

/// A lightweight representation of a Note for the UI layer.
/// Using the @Observable macro (iOS 17+) for seamless SwiftUI integration.
@Observable
@available(iOS 18.0, *)
final class NoteModel: Sendable {
    let id: UUID
    let content: String
    let timestamp: Date
    let embedding: VectorEmbedding
    
    init(id: UUID = UUID(), content: String, timestamp: Date = .now, embedding: VectorEmbedding) {
        self.id = id
        self.content = content
        self.timestamp = timestamp
        self.embedding = embedding
    }
}

// MARK: - Embedding Service

/// An actor responsible for transforming text into mathematical vectors.
/// Using an `actor` ensures that heavy ML computations do not block the MainActor
/// and provides a thread-safe environment for model inference.
actor EmbeddingService {
    
    /// Simulates the process of generating a vector embedding using a model like CLIP or BERT.
    /// - Parameter text: The raw string to be vectorized.
    /// - Returns: A simulated 384-dimensional vector.
    func generateEmbedding(for text: String) async throws -> VectorEmbedding {
        // In a real-world scenario, you would use:
        // let model = try NLPModel(configuration: ...)
        // let embedding = try model.prediction(text: text)
        
        // Simulating network or compute latency
        try await Task.sleep(for: .milliseconds(500))
        
        // Creating a deterministic "fake" vector based on the text content
        // This allows the example to be repeatable and testable.
        let seed = text.hashValue
        return (0..<384).map { i in
            let val = sin(Float(seed + i))
            return val
        }
    }
}

// MARK: - Knowledge Manager

/// The central orchestrator for the Knowledge Base.
/// It manages the lifecycle of a note from text input to semantic storage.
@available(iOS 18.0, *)
@MainActor
final class KnowledgeManager {
    
    /// The underlying Core Data context.
    private let container: NSPersistentCloudKitContainer
    
    /// The service used to generate semantic embeddings.
    private let embeddingService: EmbeddingService
    
    /// An in-memory cache of notes for rapid UI updates.
    private(set) var notes: [NoteModel] = []
    
    /// Initializes the manager with a persistent container.
    /// - Parameter container: The CloudKit-enabled Core Data container.
    init(container: NSPersistentCloudKitContainer, embeddingService: EmbeddingService) {
        self.container = container
        self.embeddingService = embeddingService
    }
    
    /// Adds a new note to the knowledge base.
    /// This process involves: 
    /// 1. Generating a vector via the EmbeddingService.
    /// 2. Saving the text and vector to Core Data.
    /// 3. Triggering CloudKit sync.
    /// - Parameter content: The user's text input.
    func addNote(content: String) async throws {
        // 1. Generate the semantic vector (Off-main-thread via Actor)
        let vector = try await embeddingService.generateEmbedding(for: content)
        
        // 2. Perform persistence on a background context to keep UI responsive
        try await container.performBackgroundTask { context in
            let noteEntity = NSEntityDescription.insertNewObject(forEntityName: "NoteEntity", into: context)
            
            noteEntity.setValue(UUID(), forKey: "id")
            noteEntity.setValue(content, forKey: "content")
            noteEntity.setValue(Date(), forKey: "timestamp")
            
            // Convert [Float] to Data for storage in Core Data (Transformable or Binary Data)
            let vectorData = vector.withUnsafeBufferPointer { Data(buffer: $0) }
            noteEntity.setValue(vectorData, forKey: "embeddingData")
            
            do {
                try context.save()
            } catch {
                throw KnowledgeError.persistenceError(error)
            }
        }
        
        // 3. Refresh local state
        await fetchAllNotes()
    }
    
    /// Performs a semantic search across the existing knowledge base.
    /// Instead of matching words, it calculates the distance between the query vector 
    /// and the stored vectors.
    /// - Parameter query: The natural language search string.
    /// - Returns: An array of NoteModels sorted by semantic similarity.
    func semanticSearch(query: String) async throws -> [NoteModel] {
        let queryVector = try await embeddingService.generateEmbedding(for: query)
        let allNotes = await fetchAllNotes()
        
        // Perform Cosine Similarity calculation
        // In a massive database, this would be offloaded to a Vector Database or 
        // specialized SQLite extension. For a mobile app, we do it in-memory.
        let sortedNotes = allNotes.sorted { noteA, noteB in
            let similarityA = cosineSimilarity(queryVector, noteA.embedding)
            let similarityB = cosineSimilarity(queryVector, noteB.embedding)
            return similarityA > similarityB
        }
        
        return sortedNotes
    }
    
    /// Fetches all notes from Core Data and converts them to NoteModel objects.
    private func fetchAllNotes() async -> [NoteModel] {
        let context = container.viewContext
        let request = NSFetchRequest<NSManagedObject>(entityName: "NoteEntity")
        request.sortDescriptors = [NSSortDescriptor(key: "timestamp", ascending: false)]
        
        do {
            let results = try context.fetch(request)
            return results.map { obj in
                let id = obj.value(forKey: "id") as? UUID ?? UUID()
                let content = obj.value(forKey: "content") as? String ?? ""
                let timestamp = obj.value(forKey: "timestamp") as? Date ?? .now
                let vectorData = obj.value(forKey: "embeddingData") as? Data ?? Data()
                
                // Reconstruct [Float] from Data
                let embedding = vectorData.withUnsafeBytes { 
                    Array($0.bindMemory(to: Float.self)) 
                }
                
                return NoteModel(id: id, content: content, timestamp: timestamp, embedding: embedding)
            }
        } catch {
            print("Fetch failed: \(error)")
            return []
        }
    }
    
    /// Calculates the cosine similarity between two vectors.
    /// Formula: (A · B) / (||A|| * ||B||)
    private func cosineSimilarity(_ v1: [Float], _ v2: [Float]) -> Float {
        guard v1.count == v2.count else { return 0 }
        
        let dotProduct = zip(v1, v2).map(*).reduce(0, +)
        let magnitude1 = sqrt(v1.map { $0 * $0 }.reduce(0, +))
        let magnitude2 = sqrt(v2.map { $0 * $0 }.reduce(0, +))
        
        guard magnitude1 > 0 && magnitude2 > 0 else { return 0 }
        return dotProduct / (magnitude1 * magnitude2)
    }
}
