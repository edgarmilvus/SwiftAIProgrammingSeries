
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import CoreML
    import Foundation // For Error

    // Assume a protocol for our AI model wrapper, potentially defined in a previous chapter
    protocol AIModelPredicting: Sendable {
        func predict(input: MLFeatureProvider) async throws -> MLFeatureProvider
        // Example: func loadModel() async throws // if model loading is also async
    }

    // A simple mock implementation for demonstration
    class MockCoreMLModel: AIModelPredicting {
        func predict(input: MLFeatureProvider) async throws -> MLFeatureProvider {
            // Simulate a delay for inference
            try await Task.sleep(for: .seconds(0.5))
            
            // Simulate a confidence output
            let features = try await MLFeatureProvider.from([
                "confidence": MLFeatureValue(double: Double.random(in: 0.1...0.99))
            ])
            return features
        }
    }

    enum AIInferenceError: Error, LocalizedError {
        case modelPredictionFailed(Error)
        case missingConfidenceOutput
        
        var errorDescription: String? {
            switch self {
            case .modelPredictionFailed(let error): return "Model prediction failed: \(error.localizedDescription)"
            case .missingConfidenceOutput: return "Model output did not contain a confidence score."
            }
        }
    }

    actor AIInferenceActor {
        private let model: AIModelPredicting // The actual Core ML model wrapper

        init(model: AIModelPredicting) {
            self.model = model
        }

        /// Performs AI inference and returns the confidence score.
        func getConfidence(for input: MLFeatureProvider) async throws -> Double {
            do {
                let output = try await model.predict(input: input)
                // Assuming "confidence" is the key for the confidence score in the MLFeatureProvider
                guard let confidence = output.featureValue(for: "confidence")?.doubleValue else {
                    throw AIInferenceError.missingConfidenceOutput
                }
                return confidence
            } catch {
                throw AIInferenceError.modelPredictionFailed(error)
            }
        }
    }

    @available(iOS 17.0, *)
    @MainActor // Ensures all UI-related state updates happen on the main thread
    class AIAppViewModel: ObservableObject { // Using ObservableObject for broader compatibility, or @Observable
        @Published var currentPredictionState: AIModelPredictionState
        @Published var isLoading: Bool = false
        @Published var errorMessage: String?

        private let inferenceActor: AIInferenceActor

        init(model: AIModelPredicting) {
            self.inferenceActor = AIInferenceActor(model: model)
            self.currentPredictionState = AIModelPredictionState(predictionLabel: "Waiting...", confidenceScore: 0.0, modelOutput: [])
        }

        func performPrediction(input: MLFeatureProvider) {
            isLoading = true
            errorMessage = nil
            Task {
                do {
                    let confidence = try await inferenceActor.getConfidence(for: input)
                    // Update the @Observable state on the MainActor
                    currentPredictionState.update(newConfidence: confidence, newLabel: "Predicted!", newOutput: [])
                } catch {
                    errorMessage = error.localizedDescription
                    print("Prediction failed: \(error)")
                }
                isLoading = false
            }
        }
    }
    