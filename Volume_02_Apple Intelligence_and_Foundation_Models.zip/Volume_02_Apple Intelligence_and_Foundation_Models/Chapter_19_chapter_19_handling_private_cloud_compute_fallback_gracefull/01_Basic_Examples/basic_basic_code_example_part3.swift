
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

/// ViewModel for the Document Scanner app, managing UI state and AI processing.
@MainActor // Ensures all state updates happen on the main actor, safe for SwiftUI
@available(iOS 18.0, macOS 15.0, *)
class DocumentScannerViewModel: ObservableObject {
    @Published var scannedText: String = "The quick brown fox jumps over the lazy dog. This is a sample document for summarization."
    @Published var selectedPolicy: AIComputePolicy = .onDevicePreferred
    @Published var processingState: ProcessingState = .idle
    @Published var resultSummary: String?
    @Published var computeSource: AIComputeSource?
    @Published var errorMessage: String?

    private let aiService = AIProcessingService()

    /// Enum to represent the current processing state for UI feedback.
    enum ProcessingState {
        case idle
        case processing(AIComputePolicy)
        case finished
        case error
    }

    /// Initiates the document summarization process using the selected compute policy.
    func summarizeDocument() {
        errorMessage = nil
        resultSummary = nil
        computeSource = nil
        processingState = .processing(selectedPolicy)

        Task {
            do {
                let result = try await aiService.processDocument(documentText: scannedText, policy: selectedPolicy)
                self.resultSummary = result.summary
                self.computeSource = result.source
                self.processingState = .finished
                print("Processing completed. Source: \(result.source.rawValue)")
            } catch {
                if let aiError = error as? AIProcessingError {
                    self.errorMessage = aiError.localizedDescription
                } else {
                    self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                }
                self.processingState = .error
                print("Processing failed: \(error.localizedDescription)")
            }
        }
    }
}
