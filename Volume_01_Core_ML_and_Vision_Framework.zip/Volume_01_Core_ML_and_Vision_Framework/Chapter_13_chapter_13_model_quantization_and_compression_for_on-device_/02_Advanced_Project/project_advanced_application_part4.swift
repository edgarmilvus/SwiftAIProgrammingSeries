
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, *)
final class VisionClassifier {
    /// Performs image classification using a given Core ML model.
    /// - Parameters:
    ///   - image: The CIImage to classify.
    ///   - model: The Core ML model to use for classification.
    /// - Returns: An array of VNClassificationObservation results.
    /// - Throws: ModelInferenceError if image processing or classification fails.
    func classify(image: CIImage, with model: MLModel) async throws -> [VNClassificationObservation] {
        // 1. Create a VNCoreMLModel from the MLModel.
        let visionModel = try VNCoreMLModel(for: model)
        
        // 2. Create a VNCoreMLRequest for image classification.
        let request = VNCoreMLRequest(model: visionModel) { request, error in
            // Handle potential errors from the Vision request itself
            if let error = error {
                print("❌ Vision classification request failed: \(error.localizedDescription)")
            }
        }

        // 3. Configure the request for optimal performance.
        request.imageCropAndScaleOption = .centerCrop // Common preprocessing for many models
        request.usesCPUOnly = false // Allow use of GPU/Neural Engine if available

        // 4. Create a VNImageRequestHandler to perform the request.
        let handler = VNImageRequestHandler(ciImage: image, options: [:])

        do {
            // 5. Perform the request asynchronously.
            try await handler.perform([request])

            // 6. Extract and return the classification observations.
            guard let observations = request.results as? [VNClassificationObservation] else {
                throw ModelInferenceError.classificationFailed(underlyingError: nil)
            }
            return observations
        } catch {
            throw ModelInferenceError.classificationFailed(underlyingError: error)
        }
    }
}
