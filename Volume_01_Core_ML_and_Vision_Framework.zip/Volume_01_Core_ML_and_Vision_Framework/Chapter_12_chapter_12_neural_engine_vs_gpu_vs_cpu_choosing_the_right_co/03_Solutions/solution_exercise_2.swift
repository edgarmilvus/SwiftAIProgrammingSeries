
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage and CVPixelBuffer conversion
import Foundation

// MARK: - Exercise 2: Object Detection with Compute Unit Fallback

// Helper for CVPixelBuffer resizing (simplified, for exercise focus)
// In a real app, use Core Image (CIImage) or vImage for efficient, high-quality resizing.
extension CVPixelBuffer {
    func resized(to width: Int, _ height: Int) -> CVPixelBuffer? {
        let originalWidth = CVPixelBufferGetWidth(self)
        let originalHeight = CVPixelBufferGetHeight(self)
        let pixelFormat = CVPixelBufferGetPixelFormatType(self)

        guard width > 0 && height > 0 && originalWidth > 0 && originalHeight > 0 else { return nil }

        var newPixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, pixelFormat, nil, &newPixelBuffer)
        guard status == kCVReturnSuccess, let buffer = newPixelBuffer else { return nil }

        // Placeholder for actual resizing logic.
        // For a real implementation, you would use Core Image or vImage:
        // CVPixelBufferLockBaseAddress(self, .readOnly)
        // CVPixelBufferLockBaseAddress(buffer, .readWrite)
        // let ciImage = CIImage(cvPixelBuffer: self)
        // let scaledImage = ciImage.transformed(by: CGAffineTransform(scaleX: CGFloat(width)/CGFloat(originalWidth), y: CGFloat(height)/CGFloat(originalHeight)))
        // let context = CIContext()
        // context.render(scaledImage, to: buffer)
        // CVPixelBufferUnlockBaseAddress(buffer, .readWrite)
        // CVPixelBufferUnlockBaseAddress(self, .readOnly)

        // For this exercise, we'll just return an empty buffer of the correct size.
        // This is sufficient to demonstrate compute unit selection, but not for actual image processing.
        return buffer
    }
}

func loadAndPerformObjectDetection(
    image: UIImage,
    modelInputWidth: Int,
    modelInputHeight: Int
) throws {
    let computeUnitPreferences: [MLComputeUnits] = [.cpuAndNeuralEngine, .cpuAndGPU, .cpuOnly]
    var loadedModel: MLModel?
    var actualComputeUnitUsed: MLComputeUnits?

    for unit in computeUnitPreferences {
        let configuration = MLModelConfiguration()
        configuration.computeUnits = unit
        do {
            // IMPORTANT: Replace 'YOLOv3' with your actual generated model class name.
            // Ensure YOLOv3.mlmodel (or MobileNetV2_SSDLite.mlmodel) is added to your project.
            loadedModel = try YOLOv3(configuration: configuration)
            actualComputeUnitUsed = unit
            print("Successfully loaded model with \(unit.description).")
            break // Model loaded, exit loop
        } catch let error as MLModelError {
            if error.errorCode == MLModelError.modelIncompatibleWithComputeUnits.rawValue {
                print("Model incompatible with \(unit.description) or unit unavailable. Trying next preference...")
            } else {
                print("Error loading model with \(unit.description): \(error.localizedDescription). Trying next preference...")
            }
        } catch {
            print("Generic error loading model with \(unit.description): \(error.localizedDescription). Trying next preference...")
        }
    }

    guard let finalModel = loadedModel, let finalComputeUnit = actualComputeUnitUsed else {
        fatalError("Failed to load object detection model with any compute unit.")
    }

    guard let imagePixelBuffer = image.toCVPixelBuffer(width: modelInputWidth, height: modelInputHeight) else {
        fatalError("Failed to convert UIImage to CVPixelBuffer.")
    }
    
    // Vision framework often handles internal resizing/preprocessing, but providing a correctly sized buffer is good practice.
    guard let inputBufferForVision = imagePixelBuffer.resized(to: modelInputWidth, modelInputHeight) else {
        fatalError("Failed to resize image for Vision request.")
    }

    // Use Vision framework for easier object detection setup
    let vnModel = try VNCoreMLModel(for: finalModel)
    let request = VNCoreMLRequest(model: vnModel) { request, error in
        guard let observations = request.results as? [VNRecognizedObjectObservation] else {
            print("No observations or error: \(error?.localizedDescription ?? "unknown error")")
            return
        }

        print("\n--- Object Detection Results (Compute Unit: \(finalComputeUnit.description)) ---")
        if observations.isEmpty {
            print("No objects detected.")
        } else {
            for observation in observations {
                // Vision groups labels by confidence. Get the highest confidence label.
                let topLabel = observation.labels.first
                let confidence = topLabel?.confidence ?? 0.0
                let boundingBox = observation.boundingBox // Normalized bounding box (0.0 to 1.0)
                print("Detected: \(topLabel?.identifier ?? "Unknown") (Confidence: \(String(format: "%.2f", confidence * 100))%) at \(boundingBox)")
            }
        }
        print("--------------------------------------------------------------------")
    }
    
    // Set the image crop and scale option for the Vision request
    // This tells Vision how to handle the input image to match the model's expectations.
    request.imageCropAndScaleOption = .scaleFit

    // Perform the request on the image pixel buffer
    let handler = VNImageRequestHandler(cvPixelBuffer: inputBufferForVision, options: [:])
    try handler.perform([request])
}

// Example usage (you would call this from your UI or a test harness):
/*
// 1. Add YOLOv3.mlmodel (or MobileNetV2_SSDLite.mlmodel) to your project.
//    You can download YOLOv3 from Apple's Core ML Models page.
// 2. Add a sample image named "sample_object_image.jpg" to your project's assets.
if let sampleImage = UIImage(named: "sample_object_image") {
    // YOLOv3 typically expects 416x416 input
    try loadAndPerformObjectDetection(image: sampleImage, modelInputWidth: 416, modelInputHeight: 416)
} else {
    print("Error: Could not load 'sample_object_image.jpg'. Make sure it's in your assets.")
}
*/
