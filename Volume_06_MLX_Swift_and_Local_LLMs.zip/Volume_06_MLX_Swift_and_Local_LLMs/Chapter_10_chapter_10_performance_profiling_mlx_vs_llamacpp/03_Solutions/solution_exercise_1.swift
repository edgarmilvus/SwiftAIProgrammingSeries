
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import MLX
import MLXNN

// Package.swift snippet for MLX dependencies:
/*
.package(url: "https://github.com/ml-explore/mlx-swift", .upToNextMajor(from: "0.13.0")),
...
.product(name: "MLX", package: "mlx-swift"),
.product(name: "MLXNN", package: "mlx-swift"),
*/

// MARK: - 1. Define a Custom MLX Module
class DataNormalizationLayer: MLXNN.Module {
    let linear: MLXNN.Linear

    /// Initializes a custom data normalization layer.
    /// It consists of a linear transformation followed by a ReLU activation.
    /// - Parameters:
    ///   - inputFeatures: The number of input features.
    ///   - outputFeatures: The number of output features.
    init(inputFeatures: Int, outputFeatures: Int) {
        // MLXNN.Linear automatically initializes its weights and biases
        // with `requiresGrad: true`, making them trainable.
        self.linear = MLXNN.Linear(inputSize: inputFeatures, outputSize: outputFeatures)
        super.init()
    }

    /// Performs the forward pass of the layer.
    /// Applies a linear transformation then a ReLU activation.
    /// - Parameter input: The input MLXArray.
    /// - Returns: The transformed MLXArray.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Apply linear transformation: input * W + b
        let transformed = linear(input)
        // Apply ReLU activation: max(0, x)
        return MLX.relu(transformed)
    }
}

func runExercise1() {
    print("--- Exercise 1: Custom MLX Layer and Basic Forward Pass Profiling ---")

    // MARK: - 2. Instantiate and Perform Inference
    let inputFeatures = 128
    let outputFeatures = 64
    let batchSize = 32

    // Instantiate the custom layer
    let normalizationLayer = DataNormalizationLayer(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
    // Create dummy input data simulating a batch of sensor readings
    let dummyInput = MLXArray.randomUniform(low: -1.0, high: 1.0, shape: [batchSize, inputFeatures])

    // MARK: - 3. Profile the Forward Pass
    print("Performing forward pass...")
    let startTime = CFAbsoluteTimeGetCurrent() // Record start time

    let output = normalizationLayer(dummyInput) // Perform the forward pass

    // MLX.eval() is crucial here. It forces the execution of the computation graph
    // that was lazily built by the MLX operations. Without it, `endTime - startTime`
    // would only measure the time taken to *construct* the graph, not to *execute*
    // the actual numerical computations on the hardware.
    MLX.eval(output) // Trigger computation

    let endTime = CFAbsoluteTimeGetCurrent() // Record end time
    print("Forward pass completed. Output shape: \(output.shape)")
    print("Execution time: \(endTime - startTime) seconds")

    // Explanation about MLX.eval()
    print("\n// Explanation: MLX uses lazy evaluation, meaning computations are not performed immediately when you define operations. Instead, a computation graph is built. `MLX.eval()` explicitly triggers the execution of this graph, forcing all pending operations to complete. Without `MLX.eval()`, timing the operation would only measure the time taken to *build* the graph, not to *execute* the actual numerical computations, leading to misleading performance metrics.")
}

runExercise1()
