
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - 1. Swift Package Manager Dependencies (Conceptual)

// In a real-world Swift Package, you would define your dependencies in a Package.swift file.
// For system frameworks like Foundation and CoreML, explicit dependencies are often not
// listed in the Package.swift itself if you're building an app target, as they are
// implicitly available. However, for a library or a framework, specifying platform
// availability is good practice.

/*
import PackageDescription

let package = Package(
    name: "PersonalFinanceAppFeatures",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 for latest Swift 6 concurrency features and API availability
        .macOS(.v15),
        .tvOS(.v18),
        .watchOS(.v11)
    ],
    products: [
        .library(
            name: "PersonalFinanceAppFeatures",
            targets: ["PersonalFinanceAppFeatures"]),
    ],
    dependencies: [
        // No external dependencies beyond Foundation and CoreML for this specific example.
        // If advanced Natural Language Processing was required, the `NaturalLanguage`
        // framework would be used, which is also a system framework.
    ],
    targets: [
        .target(
            name: "PersonalFinanceAppFeatures",
            dependencies: []),
        .testTarget(
            name: "PersonalFinanceAppFeaturesTests",
            dependencies: ["PersonalFinanceAppFeatures"]),
    ]
)
*/

import Foundation
import CoreML

// MARK: - 2. Raw Data Model: Transaction

/// Represents a raw financial transaction as it might be entered by a user or imported
/// from a bank statement. This is the initial, unprocessed data.
@available(iOS 18.0, *)
struct Transaction: Identifiable {
    let id: UUID
    let description: String
    let amount: Decimal // Using Decimal for financial accuracy to avoid floating-point errors
    let date: Date

    /// Initializes a new `Transaction` instance.
    /// - Parameters:
    ///   - id: A unique identifier for the transaction. Defaults to a new UUID.
    ///   - description: A textual description of the transaction.
    ///   - amount: The monetary amount of the transaction.
    ///   - date: The date and time the transaction occurred.
    init(id: UUID = UUID(), description: String, amount: Decimal, date: Date) {
        self.id = id
        self.description = description
        self.amount = amount
        self.date = date
    }
}

// MARK: - 3. Engineered Features Model: TransactionFeatures (MLFeatureProvider)

/// A struct designed to hold the engineered features derived from a raw `Transaction`.
/// This struct conforms to `MLFeatureProvider`, making it directly consumable by any
/// Core ML model (e.g., one trained with Create ML for tabular data).
@available(iOS 18.0, *)
struct TransactionFeatures: MLFeatureProvider {
    // Textual Features
    let descriptionWordCount: Int
    let descriptionHasKeywords: Bool
    let descriptionLength: Int

    // Numerical Features
    let amountLog10: Double // Logarithmic transformation helps with skewed financial data
    let amountIsLarge: Bool // Binary feature for significant amounts
    let amountBin: String   // Categorical binning (e.g., "small", "medium", "large")

    // Date/Time Features
    let dateDayOfWeek: Int  // 1 (Sunday) - 7 (Saturday)
    let dateMonth: Int      // 1-12
    let dateIsWeekend: Bool // Binary feature
    let dateHourOfDay: Int  // 0-23

    /// The set of feature names this provider can supply. This must match the input
    /// feature names expected by the Core ML model.
    var featureNames: Set<String> {
        [
            "descriptionWordCount",
            "descriptionHasKeywords",
            "descriptionLength",
            "amountLog10",
            "amountIsLarge",
            "amountBin",
            "dateDayOfWeek",
            "dateMonth",
            "dateIsWeekend",
            "dateHourOfDay"
        ]
    }

    /// Provides an `MLFeatureValue` for a given feature name.
    /// This is the core method for `MLFeatureProvider` conformance, allowing Core ML
    /// to retrieve feature values dynamically.
    /// - Parameter featureName: The name of the feature to retrieve.
    /// - Returns: An `MLFeatureValue` corresponding to the feature, or `nil` if the
    ///            feature name is not recognized or the value is unavailable.
    func featureValue(for featureName: String) -> MLFeatureValue? {
        switch featureName {
        case "descriptionWordCount": return MLFeatureValue(int: descriptionWordCount)
        case "descriptionHasKeywords": return MLFeatureValue(bool: descriptionHasKeywords)
        case "descriptionLength": return MLFeatureValue(int: descriptionLength)
        case "amountLog10": return MLFeatureValue(double: amountLog10)
        case "amountIsLarge": return MLFeatureValue(bool: amountIsLarge)
        case "amountBin": return MLFeatureValue(string: amountBin)
        case "dateDayOfWeek": return MLFeatureValue(int: dateDayOfWeek)
        case "dateMonth": return MLFeatureValue(int: dateMonth)
        case "dateIsWeekend": return MLFeatureValue(bool: dateIsWeekend)
        case "dateHourOfDay": return MLFeatureValue(int: dateHourOfDay)
        default: return nil // Return nil if the feature name is not handled
        }
    }
}

// MARK: - 4. Feature Engineering Logic: TransactionFeatureEngineer

/// A class responsible for transforming a raw `Transaction` object into a
/// `TransactionFeatures` object, applying various feature engineering techniques.
/// This class encapsulates all the domain-specific logic for feature creation.
@available(iOS 18.0, *)
class TransactionFeatureEngineer {

    private let calendar: Calendar
    private let largeAmountThreshold: Decimal
    private let relevantKeywords: Set<String>

    /// Initializes the `TransactionFeatureEngineer`.
    /// - Parameters:
    ///   - locale: The locale to use for calendar calculations (e.g., to correctly identify weekends).
    ///             Defaults to the current locale.
    ///   - largeAmountThreshold: The monetary threshold above which an amount is considered "large".
    ///                           Defaults to 500.0.
    ///   - relevantKeywords: A set of keywords to check for existence in transaction descriptions.
    ///                       These can indicate specific categories (e.g., "starbucks" -> Coffee).
    init(locale: Locale = .current, largeAmountThreshold: Decimal = 500.0, relevantKeywords: Set<String> = ["starbucks", "amazon", "spotify", "rent", "utility"]) {
        var calendar = Calendar(identifier: .gregorian) // Use gregorian for consistent weekday numbers
        calendar.locale = locale // Apply locale for proper weekend detection, etc.
        self.calendar = calendar
        self.largeAmountThreshold = largeAmountThreshold
        self.relevantKeywords = relevantKeywords
    }

    /// Transforms a raw `Transaction` into a `TransactionFeatures` object.
    /// This method performs all the necessary feature engineering steps.
    /// - Parameter transaction: The raw transaction data to be processed.
    /// - Returns: An `TransactionFeatures` object containing all derived features.
    /// - Throws: `FeatureEngineeringError` if any critical feature cannot be derived
    ///           due to invalid input data (e.g., negative amount, unextractable date components).
    func engineerFeatures(for transaction: Transaction) throws -> TransactionFeatures {
        // MARK: - Description Features
        // 1. Calculate word count: Split description by spaces and filter out empty strings.
        let descriptionWords = transaction.description.split(separator: " ").filter { !$0.isEmpty }
        let descriptionWordCount = descriptionWords.count
        
        // 2. Calculate description length: Character count of the raw description.
        let descriptionLength = transaction.description.count
        
        // 3. Check for relevant keywords: Case-insensitive search for predefined keywords.
        let descriptionHasKeywords = relevantKeywords.contains { keyword in
            transaction.description.lowercased().contains(keyword)
        }

        // MARK: - Amount Features
        // 1. Validate amount: Ensure amount is non-negative for financial transactions.
        guard transaction.amount >= 0 else {
            throw FeatureEngineeringError.invalidAmount(transaction.amount)
        }
        
        // 2. Logarithmic transformation: Convert Decimal to Double for log10, handle zero safely.
        //    Logarithmic scaling helps normalize skewed distributions (common with financial amounts).
        let amountDouble = NSDecimalNumber(decimal: transaction.amount).doubleValue
        let amountLog10 = amountDouble > 0 ? log10(amountDouble) : 0.0
        
        // 3. Binary feature for large amounts: Check if amount exceeds a predefined threshold.
        let amountIsLarge = transaction.amount >= largeAmountThreshold

        // 4. Categorical binning for amounts: Assigns transaction to a size category.
        let amountBin: String
        switch transaction.amount {
        case 0..<50: amountBin = "small"
        case 50..<200: amountBin = "medium"
        case 200..<largeAmountThreshold: amountBin = "significant"
        case largeAmountThreshold...: amountBin = "large"
        default: amountBin = "unknown" // Should ideally not be reached with the guard above
        }

        // MARK: - Date Features
        // 1. Extract date components: Use the configured calendar to get weekday, month, and hour.
        let components = calendar.dateComponents([.weekday, .month, .hour], from: transaction.date)

        // 2. Validate component extraction: Ensure all required components are available.
        guard let dayOfWeek = components.weekday, // 1 (Sunday) ... 7 (Saturday)
              let month = components.month,
              let hourOfDay = components.hour else {
            throw FeatureEngineeringError.dateComponentExtractionFailed(transaction.date)
        }

        // 3. Binary feature for weekend: Use calendar's built-in check for accuracy across locales.
        let dateIsWeekend = calendar.isDateInWeekend(transaction.date)

        // Return the fully engineered features
        return TransactionFeatures(
            descriptionWordCount: descriptionWordCount,
            descriptionHasKeywords: descriptionHasKeywords,
            descriptionLength: descriptionLength,
            amountLog10: amountLog10,
            amountIsLarge: amountIsLarge,
            amountBin: amountBin,
            dateDayOfWeek: dayOfWeek,
            dateMonth: month,
            dateIsWeekend: dateIsWeekend,
            dateHourOfDay: hourOfDay
        )
    }

    /// An asynchronous version of `engineerFeatures` for non-blocking execution,
    /// suitable for UI-responsive applications or batch processing.
    /// - Parameter transaction: The raw transaction data.
    /// - Returns: An `TransactionFeatures` object containing all engineered features.
    /// - Throws: `FeatureEngineeringError` if any critical feature cannot be derived.
    func engineerFeaturesAsync(for transaction: Transaction) async throws -> TransactionFeatures {
        // For simple CPU-bound tasks like this, `Task.detached` offloads to a global concurrent queue.
        // For more complex or I/O-bound tasks, dedicated actors or custom executors might be used.
        try await Task.detached {
            try self.engineerFeatures(for: transaction)
        }.value
    }
}

/// Custom error types specifically for feature engineering and model prediction.
/// Conforms to `LocalizedError` for user-friendly error messages.
@available(iOS 18.0, *)
enum FeatureEngineeringError: Error, LocalizedError {
    case invalidAmount(Decimal)
    case dateComponentExtractionFailed(Date)
    case modelPredictionFailed(Error)
    case modelNotLoaded
    case mockModelMissingFeature(String) // For our mock model specifically

    /// Provides a localized description for the error, suitable for display to the user.
    var errorDescription: String? {
        switch self {
        case .invalidAmount(let amount):
            return "Invalid transaction amount: \(amount). Amount must be non-negative."
        case .dateComponentExtractionFailed(let date):
            return "Failed to extract necessary date components from \(date)."
        case .modelPredictionFailed(let underlyingError):
            return "Model prediction failed: \(underlyingError.localizedDescription)"
        case .modelNotLoaded:
            return "The Core ML model could not be loaded or is not available. Please ensure the model is included in the app bundle."
        case .mockModelMissingFeature(let featureName):
            return "Mock ML model could not find required feature: \(featureName)."
        }
    }
}

// MARK: - 5. Integration with Core ML Model: FinancePredictor

/// A class responsible for loading a Core ML model and using it to predict transaction categories.
/// It orchestrates the feature engineering and the model inference steps.
@available(iOS 18.0, *)
class FinancePredictor {

    // In a real app, 'FinanceCategoryClassifier' would be a generated Swift class
    // from your .mlmodel file (e.g., `FinanceCategoryClassifier().model`).
    // For this demonstration, we use a mock `MLModel`.
    private var model: MLModel?
    private let featureEngineer: TransactionFeatureEngineer

    /// Initializes the `FinancePredictor`.
    /// - Parameter featureEngineer: An instance of `TransactionFeatureEngineer` to prepare
    ///                              input features for the model.
    init(featureEngineer: TransactionFeatureEngineer) {
        self.featureEngineer = featureEngineer
        self.loadModel() // Attempt to load the model upon initialization
    }

    /// Loads the Core ML model from the app bundle.
    /// In a production app, this would load the actual `MLModel` generated by Create ML.
    /// This method is kept synchronous for simplicity in loading, as model loading
    /// typically happens once at app startup or when a feature is first accessed.
    private func loadModel() {
        do {
            // !!! IMPORTANT: In a real app, replace `MockMLModel()` with your actual generated model:
            // self.model = try FinanceCategoryClassifier(configuration: MLModelConfiguration()).model
            
            // For demonstration, we use our mock model:
            self.model = MockMLModel()
            print("Successfully loaded mock Core ML model.")
        } catch {
            print("Error loading Core ML model: \(error.localizedDescription). Prediction functionality will be unavailable.")
            self.model = nil // Ensure model is nil if loading fails
        }
    }

    /// Predicts the category of a single transaction using the loaded Core ML model.
    /// This method is asynchronous to prevent blocking the UI during feature engineering
    /// and model inference, especially for batch predictions or complex models.
    /// - Parameter transaction: The raw transaction to categorize.
    /// - Returns: The predicted category string (e.g., "Groceries", "Utilities").
    /// - Throws: `FeatureEngineeringError` if feature engineering fails, or
    ///           `modelPredictionFailed` if the model is not loaded or prediction fails.
    func predictCategory(for transaction: Transaction) async throws -> String {
        // 1. Ensure the model is loaded and available.
        guard let model = self.model else {
            throw FeatureEngineeringError.modelNotLoaded
        }

        // 2. Engineer features for the transaction asynchronously.
        // This converts the raw data into the format the ML model expects.
        let features = try await featureEngineer.engineerFeaturesAsync(for: transaction)

        // 3. Perform prediction using the Core ML model.
        do {
            let prediction = try model.prediction(from: features)
            
            // Assuming the Create ML model's output feature for the category is named "category".
            guard let category = prediction.featureValue(for: "category")?.stringValue else {
                throw FeatureEngineeringError.modelPredictionFailed(
                    NSError(domain: "FinancePredictor", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model output 'category' not found or not a string."])
                )
            }
            return category
        } catch {
            // Wrap any Core ML prediction errors in our custom error type for consistency.
            throw FeatureEngineeringError.modelPredictionFailed(error)
        }
    }
}

// MARK: - Mock MLModel for Demonstration

/// A mock `MLModel` subclass to simulate a Create ML trained model for demonstration purposes.
/// In a real application, this would be the actual `MLModel` generated by Create ML
/// (e.g., `FinanceCategoryClassifier`). This mock provides plausible (though simplistic)
/// prediction logic based on the engineered features.
@available(iOS 18.0, *)
class MockMLModel: MLModel {
    /// Overrides the `prediction` method to provide simulated output.
    /// - Parameters:
    ///   - input: An `MLFeatureProvider` containing the engineered features.
    ///   - options: Prediction options (not used in this mock).
    /// - Returns: An `MLFeatureProvider` containing the mock predicted category.
    /// - Throws: `FeatureEngineeringError` if required input features are missing.
    override func prediction(from input: MLFeatureProvider, options: MLPredictionOptions) throws -> MLFeatureProvider {
        // Simulate some basic prediction logic based on a few key engineered features.
        // This logic is simplified for demonstration and does not represent a real ML model.
        guard let amountBin = input.featureValue(for: "amountBin")?.stringValue else {
            throw FeatureEngineeringError.mockModelMissingFeature("amountBin")
        }
        guard let descriptionHasKeywords = input.featureValue(for: "descriptionHasKeywords")?.boolValue else {
            throw FeatureEngineeringError.mockModelMissingFeature("descriptionHasKeywords")
        }
        guard let dayOfWeek = input.featureValue(for: "dateDayOfWeek")?.int64Value else {
            throw FeatureEngineeringError.mockModelMissingFeature("dateDayOfWeek")
        }
        
        // Access the original description for more specific keyword checks in the mock
        // (This relies on the feature engineer passing the original description, which isn't standard MLFeatureProvider behavior,
        // but it's okay for a mock to bend rules for illustrative purposes if the engineer also passes it).
        // For a true ML model, the 'descriptionHasKeywords' boolean would be sufficient.
        let originalDescription = input.featureValue(for: "originalDescription")?.stringValue ?? "" // Assume engineer could pass this too if needed for mock.

        var predictedCategory: String

        if descriptionHasKeywords {
            // More specific keyword checks for a richer mock prediction
            if originalDescription.lowercased().contains("starbucks") {
                 predictedCategory = "Coffee"
            } else if originalDescription.lowercased().contains("amazon") {
                 predictedCategory = "Shopping"
            } else if originalDescription.lowercased().contains("spotify") {
                 predictedCategory = "Subscriptions"
            } else if originalDescription.lowercased().contains("rent") {
                 predictedCategory = "Housing"
            } else if originalDescription.lowercased().contains("utility") {
                 predictedCategory = "Utilities"
            } else if originalDescription.lowercased().contains("restaurant") {
                 predictedCategory = "Dining Out"
            } else if originalDescription.lowercased().contains("uber") {
                 predictedCategory = "Transportation"
            }
            else {
                predictedCategory = "Miscellaneous"
            }
        } else if amountBin == "large" {
            predictedCategory = "Large Purchase"
        } else if dayOfWeek >= 6 { // 6 = Saturday, 7 = Sunday
            predictedCategory = "Weekend Spending"
        } else {
            predictedCategory = "Groceries" // Default category
        }

        // Return a mock output feature provider with the predicted category.
        return MockMLFeatureProvider(features: ["category": MLFeatureValue(string: predictedCategory)])
    }
}

/// A simple `MLFeatureProvider` implementation used by `MockMLModel` to return its output.
@available(iOS 18.0, *)
class MockMLFeatureProvider: MLFeatureProvider {
    let features: [String: MLFeatureValue]

    /// Initializes with a dictionary of feature names and their values.
    /// - Parameter features: A dictionary representing the output features.
    init(features: [String: MLFeatureValue]) {
        self.features = features
    }

    /// The set of feature names this provider can supply.
    var featureNames: Set<String> {
        Set(features.keys)
    }

    /// Provides an `MLFeatureValue` for a given feature name.
    /// - Parameter featureName: The name of the feature to retrieve.
    /// - Returns: An `MLFeatureValue` corresponding to the feature, or `nil` if not found.
    func featureValue(for featureName: String) -> MLFeatureValue? {
        features[featureName]
    }
}


// MARK: - 6. Real-world Apple App Context: FinanceManagerApp

/// Simulates the main application logic for a personal finance manager.
/// This class acts as the orchestrator, demonstrating how the `TransactionFeatureEngineer`
/// and `FinancePredictor` would be used within a real-world application flow.
@available(iOS 18.0, *)
class FinanceManagerApp {
    private let featureEngineer: TransactionFeatureEngineer
    private let financePredictor: FinancePredictor

    /// Initializes the `FinanceManagerApp`, setting up its dependencies.
    init() {
        // Configure the feature engineer with specific thresholds and keywords relevant to the app's domain.
        self.featureEngineer = TransactionFeatureEngineer(
            largeAmountThreshold: 500.0,
            relevantKeywords: ["starbucks", "amazon", "spotify", "rent", "utility", "restaurant", "uber", "apple", "gas"]
        )
        // Initialize the predictor with the configured feature engineer.
        self.financePredictor = FinancePredictor(featureEngineer: featureEngineer)
    }

    /// Processes a single new transaction, engineering its features and predicting its category.
    /// This method demonstrates the end-to-end workflow for a single transaction.
    /// - Parameter transaction: The `Transaction` object to process.
    func processNewTransaction(transaction: Transaction) async {
        print("\n--- Processing Transaction: '\(transaction.description)' (Amount: \(transaction.amount)) ---")
        do {
            // First, demonstrate the raw output of feature engineering.
            // In a real app, this might be logged or used for debugging/analytics.
            let engineeredFeatures = try await featureEngineer.engineerFeaturesAsync(for: transaction)
            print("  Engineered Features:")
            for featureName in engineeredFeatures.featureNames.sorted() {
                if let value = engineeredFeatures.featureValue(for: featureName) {
                    print("    \(featureName): \(value.description)")
                }
            }

            // Then, use the finance predictor to get the final category.
            let predictedCategory = try await financePredictor.predictCategory(for: transaction)
            print("  Predicted Category: \(predictedCategory)")

        } catch {
            // Comprehensive error handling for both feature engineering and prediction failures.
            if let feError = error as? FeatureEngineeringError {
                print("  Error during transaction processing: \(feError.localizedDescription)")
            } else {
                print("  An unexpected error occurred: \(error.localizedDescription)")
            }
        }
    }

    /// Runs a batch of sample transactions through the system to demonstrate concurrent processing.
    /// This simulates importing multiple transactions or processing a daily batch.
    func runSampleTransactions() async {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        dateFormatter.timeZone = TimeZone(identifier: "America/New_York")! // Consistent timezone for dates

        let transactions: [Transaction] = [
            Transaction(description: "Starbucks Coffee", amount: 5.25, date: dateFormatter.date(from: "2024-07-20 08:30")!), // Saturday
            Transaction(description: "Amazon.com purchase", amount: 75.00, date: dateFormatter.date(from: "2024-07-18 14:00")!),
            Transaction(description: "Monthly Rent Payment", amount: 1800.00, date: dateFormatter.date(from: "2024-07-01 09:00")!),
            Transaction(description: "Electricity Bill", amount: 120.50, date: dateFormatter.date(from: "2024-07-15 11:00")!),
            Transaction(description: "Groceries at Whole Foods", amount: 88.70, date: dateFormatter.date(from: "2024-07-19 17:45")!),
            Transaction(description: "Dinner at Italian Restaurant", amount: 60.00, date: dateFormatter.date(from: "2024-07-21 19:00")!), // Sunday
            Transaction(description: "Uber Ride to Airport", amount: 45.50, date: dateFormatter.date(from: "2024-07-17 22:00")!),
            Transaction(description: "Spotify Premium", amount: 10.99, date: dateFormatter.date(from: "2024-07-05 06:00")!),
            Transaction(description: "Gas Station Refuel", amount: 45.00, date: dateFormatter.date(from: "2024-07-16 10:00")!)
        ]

        // Use a TaskGroup to process multiple transactions concurrently,
        // improving performance for batch operations without blocking the main thread.
        await withTaskGroup(of: Void.self) { group in
            for transaction in transactions {
                group.addTask {
                    await self.processNewTransaction(transaction: transaction)
                }
            }
        }
    }
}

// MARK: - Application Entry Point (Example Usage)

// To run this code, ensure you are using an environment that supports Swift 6
// and iOS 18 APIs (e.g., Xcode 16 beta or later, or a Swift 6 toolchain).
// The `@main` attribute makes this struct the entry point for the executable.
@available(iOS 18.0, *)
@main
struct AppEntry {
    static func main() async {
        print("Starting Personal Finance Manager App Simulation...")
        let app = FinanceManagerApp()
        await app.runSampleTransactions()
        print("\nPersonal Finance Manager App Simulation Finished.")
    }
}
