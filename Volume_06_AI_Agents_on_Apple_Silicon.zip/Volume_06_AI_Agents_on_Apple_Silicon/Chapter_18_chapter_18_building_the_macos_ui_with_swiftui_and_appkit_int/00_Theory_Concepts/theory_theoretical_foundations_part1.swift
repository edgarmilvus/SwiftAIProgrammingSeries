
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example: An asynchronous function to perform AI inference
@available(macOS 14.0, *)
actor InferenceEngine {
    private var modelLoaded: Bool = false
    // Assume `llamaCppBridge` is a Swift binding to llama.cpp
    private let llamaCppBridge: LlamaCppBridge // Defined in a previous chapter

    init(modelPath: String) {
        // Initialize bridge, potentially load model
        self.llamaCppBridge = LlamaCppBridge(modelPath: modelPath)
    }

    func loadModel() async throws {
        // Simulate model loading
        try await Task.sleep(for: .seconds(2))
        modelLoaded = true
        print("Model loaded successfully.")
    }

    func generateResponse(prompt: String, parameters: InferenceParameters) async throws -> String {
        guard modelLoaded else {
            throw InferenceError.modelNotLoaded
        }
        print("Starting inference for prompt: \(prompt)")
        // This would call the actual llama.cpp binding
        let result = try await llamaCppBridge.infer(prompt: prompt, parameters: parameters)
        print("Inference complete.")
        return result
    }
}

// In a SwiftUI view model or parent view
@available(macOS 14.0, *)
@Observable class ChatViewModel {
    var currentPrompt: String = ""
    var generatedResponse: String = "Waiting for input..."
    var isLoading: Bool = false
    var errorMessage: String?

    private let inferenceEngine: InferenceEngine

    init(inferenceEngine: InferenceEngine) {
        self.inferenceEngine = inferenceEngine
        Task { await loadModel() }
    }

    func loadModel() async {
        isLoading = true
        do {
            try await inferenceEngine.loadModel()
            errorMessage = nil
        } catch {
            errorMessage = "Failed to load model: \(error.localizedDescription)"
        }
        isLoading = false
    }

    func sendPrompt() async {
        guard !currentPrompt.isEmpty else { return }
        isLoading = true
        errorMessage = nil
        let promptToSend = currentPrompt
        currentPrompt = "" // Clear input immediately

        do {
            let parameters = InferenceParameters(maxTokens: 512, temperature: 0.7) // Defined elsewhere
            let response = try await inferenceEngine.generateResponse(prompt: promptToSend, parameters: parameters)
            await MainActor.run {
                self.generatedResponse = response
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Inference failed: \(error.localizedDescription)"
            }
        }
        isLoading = false
    }
}
