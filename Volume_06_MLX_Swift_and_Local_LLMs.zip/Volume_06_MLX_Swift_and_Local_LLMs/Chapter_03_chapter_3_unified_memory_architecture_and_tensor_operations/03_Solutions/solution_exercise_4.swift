
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
class BatchNorm1D: MLXNN.Module {
    let numFeatures: Int
    let epsilon: Float

    // Trainable parameters: gamma (scale) and beta (shift)
    let gamma: MLXArray
    let beta: MLXArray

    // Non-trainable running statistics (for inference)
    // These are stored as MLXArray properties but are not marked as trainable parameters
    // by MLXNN.Module because they are not declared with `MLXArray` directly,
    // but rather updated. We would typically use MLXNN.Parameter and `track(runningMean)`
    // for proper state management in a real training loop.
    // For this exercise, we'll keep them as `var` MLXArray and acknowledge the limitation.
    var runningMean: MLXArray
    var runningVariance: MLXArray

    // Momentum for updating running statistics (optional, but good practice)
    let momentum: Float = 0.9

    init(numFeatures: Int, epsilon: Float = 1e-5) {
        self.numFeatures = numFeatures
        self.epsilon = epsilon

        // Initialize trainable parameters.
        // MLXNN.Module automatically makes these trainable.
        self.gamma = MLXArray.ones([numFeatures], dtype: .float32) // Scale
        self.beta = MLXArray.zeros([numFeatures], dtype: .float32) // Shift

        // Initialize non-trainable running statistics.
        // These are stateful and would be updated during training.
        // Note: For a true MLXNN.Module, running statistics are typically handled
        // using `MLXNN.Parameter` and `track` to ensure they are saved/loaded with the module,
        // but for this exercise, direct MLXArray `var` properties are used for simplicity.
        self.runningMean = MLXArray.zeros([numFeatures], dtype: .float32)
        self.runningVariance = MLXArray.ones([numFeatures], dtype: .float32)

        super.init()
    }

    override func callAsFunction(_ input: MLXArray, isTraining: Bool = true) -> MLXArray {
        // Assume input shape is [batchSize, numFeatures]
        // We need to calculate mean and variance along the batch dimension (axis 0)
        // and keep dimensions for broadcasting.

        var mean: MLXArray
        var variance: MLXArray

        if isTraining {
            // Calculate batch-specific mean and variance
            mean = MLX.mean(input, axis: 0, keepDims: true) // Shape: [1, numFeatures]
            variance = MLX.variance(input, axis: 0, keepDims: true) // Shape: [1, numFeatures]

            // Update running statistics using exponential moving average
            // Note: These updates are typically done outside the graph for efficiency
            // or handled as side effects, but for a direct implementation, we show it here.
            // For a real training loop, you might want to detach these updates from the gradient graph.
            self.runningMean = self.runningMean * momentum + mean.squeeze(axis: 0) * (1 - momentum)
            self.runningVariance = self.runningVariance * momentum + variance.squeeze(axis: 0) * (1 - momentum)

        } else {
            // Use running statistics for inference
            // Reshape runningMean/Variance to [1, numFeatures] for broadcasting
            mean = MLX.reshape(self.runningMean, [1, numFeatures])
            variance = MLX.reshape(self.runningVariance, [1, numFeatures])
        }

        // Normalize the input
        let normalizedInput = (input - mean) / MLX.sqrt(variance + epsilon)

        // Apply scale (gamma) and shift (beta)
        // gamma and beta have shape [numFeatures], MLX will broadcast them to [batchSize, numFeatures]
        let output = gamma * normalizedInput + beta

        return output
    }
}

@available(iOS 18.0, macOS 15.0, *)
func demonstrateBatchNorm1D() {
    print("--- Batch Normalization 1D Demonstration ---")
    let numFeatures = 16
    let batchSize = 4
    let bnLayer = BatchNorm1D(numFeatures: numFeatures)
    print("BatchNorm1D layer initialized with \(numFeatures) features.")
    print("Initial gamma (scale): \(bnLayer.gamma.flattened().data.map{$0.floatValue}.prefix(5))...")
    print("Initial beta (shift): \(bnLayer.beta.flattened().data.map{$0.floatValue}.prefix(5))...")
    print("Initial runningMean: \(bnLayer.runningMean.flattened().data.map{$0.floatValue}.prefix(5))...")
    print("Initial runningVariance: \(bnLayer.runningVariance.flattened().data.map{$0.floatValue}.prefix(5))...")


    // Create a sample input batch
    let input = MLXArray.random(
        low: -5.0, high: 5.0,
        shape: [batchSize, numFeatures],
        dtype: .float32
    )
    print("\nSample Input MLXArray shape: \(input.shape)")
    print("Sample Input (first row, first 5 elements): \(input[0].flattened().data.map{$0.floatValue}.prefix(5))...")

    // Perform forward pass in training mode
    let normalizedOutputTraining = bnLayer(input, isTraining: true)
    print("\nBatch Norm Output (Training Mode) Shape: \(normalizedOutputTraining.shape)")
    print("Output (Training Mode, first row, first 5 elements): \(normalizedOutputTraining[0].flattened().data.map{$0.floatValue}.prefix(5))...")

    // Check running statistics after one training pass
    print("\nRunningMean after training pass (first 5): \(bnLayer.runningMean.flattened().data.map{$0.floatValue}.prefix(5))...")
    print("RunningVariance after training pass (first 5): \(bnLayer.runningVariance.flattened().data.map{$0.floatValue}.prefix(5))...")

    // Perform forward pass in inference mode
    // For a real scenario, runningMean and runningVariance would have been updated over many batches.
    // Here, they reflect the update from the single batch above.
    let normalizedOutputInference = bnLayer(input, isTraining: false)
    print("\nBatch Norm Output (Inference Mode) Shape: \(normalizedOutputInference.shape)")
    print("Output (Inference Mode, first row, first 5 elements): \(normalizedOutputInference[0].flattened().data.map{$0.floatValue}.prefix(5))...")

    // Verify statistics in training mode (should be close to 0 mean, 1 variance per feature)
    let outputMean = MLX.mean(normalizedOutputTraining, axis: 0).item() // Mean across batch for each feature
    let outputVariance = MLX.variance(normalizedOutputTraining, axis: 0).item() // Variance across batch for each feature
    print("\nOutput (Training Mode) Mean (average of all feature means): \(outputMean)")
    print("Output (Training Mode) Variance (average of all feature variances): \(outputVariance)")
}

// Example usage:
// demonstrateBatchNorm1D()
