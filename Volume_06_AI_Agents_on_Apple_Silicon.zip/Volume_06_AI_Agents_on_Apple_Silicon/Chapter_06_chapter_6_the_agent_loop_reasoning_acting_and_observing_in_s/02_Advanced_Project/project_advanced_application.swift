
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Illustrative - this would be in a separate file for a real SPM package)
// This section demonstrates how you would declare dependencies if you were building
// a Swift Package that included a more sophisticated HTTP client or other libraries.
// For this example, we'll primarily use Foundation's URLSession and Codable,
// which are built-in and do not require explicit package declarations here.
/*
import PackageDescription

let package = Package(
    name: "SmartDocumentAgent",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 for modern concurrency APIs
        .macOS(.v15) // Targeting macOS 15 for modern concurrency APIs
    ],
    products: [
        .library(
            name: "SmartDocumentAgent",
            targets: ["SmartDocumentAgent"]),
    ],
    dependencies: [
        // Example: If using a dedicated async HTTP client like swift-http-client
        // .package(url: "https://github.com/swift-server/swift-http-client.git", from: "1.0.0"),
        // For this example, we rely on Foundation.URLSession and Codable, no external dependencies.
    ],
    targets: [
        .target(
            name: "SmartDocumentAgent",
            dependencies: []),
        .testTarget(
            name: "SmartDocumentAgentTests",
            dependencies: ["SmartDocumentAgent"]),
    ]
)
*/

import Foundation
import SwiftUI // Only for the example SwiftUI integration

// MARK: - 1. Agent-Specific Error Handling

/// Custom error types for the DocumentAgent to provide clear, specific failure contexts.
/// This improves debugging and allows for more granular error recovery or user feedback.
enum AgentError: Error, LocalizedError {
    /// Indicates a failure during the network request to the local Ollama server.
    case ollamaRequestFailed(String)
    /// Indicates that the LLM's response was not in the expected structured JSON format.
    case invalidLLMResponse(String)
    /// Indicates that an external tool invoked by the agent failed during execution.
    case toolExecutionFailed(String)
    /// A general error indicating a failure in the overall document processing pipeline.
    case documentProcessingFailed(String)

    /// Provides a user-friendly description for each error case.
    var errorDescription: String? {
        switch self {
        case .ollamaRequestFailed(let message):
            return "Ollama request failed: \(message)"
        case .invalidLLMResponse(let message):
            return "Invalid LLM response: \(message)"
        case .toolExecutionFailed(let message):
            return "Tool execution failed: \(message)"
        case .documentProcessingFailed(let message):
            return "Document processing failed: \(message)"
        }
    }
}

// MARK: - 2. Ollama Client Abstraction

/// A simplified client to interact with a local Ollama instance running an LLM.
/// In a production application, this would handle actual network requests, potentially
/// streaming responses, and more robust error parsing from the Ollama API.
/// For this pedagogical example, it mocks a successful LLM generation to focus on the agent logic.
@available(iOS 18.0, macOS 15.0, *)
class OllamaClient {
    let baseURL: URL
    let model: String

    /// Initializes the Ollama client with the target API endpoint and LLM model.
    /// - Parameters:
    ///   - baseURL: The base URL for the Ollama API (e.g., `http://localhost:11434/api/generate`).
    ///   - model: The name of the LLM model to use (e.g., "llama3", "mistral").
    init(baseURL: URL, model: String) {
        self.baseURL = baseURL
        self.model = model
    }

    /// Sends a prompt to the Ollama server and returns the raw string response.
    /// This method is asynchronous and can throw `AgentError` if the request fails.
    /// - Parameter prompt: The detailed text prompt to send to the LLM.
    /// - Returns: The raw string response from the LLM, expected to be JSON.
    func sendRequest(prompt: String) async throws -> String {
        // --- Real-world URLSession implementation (commented out for mock) ---
        /*
        var request = URLRequest(url: baseURL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let requestBody: [String: Any] = [
            "model": model,
            "prompt": prompt,
            "format": "json", // Instruct Ollama to return JSON
            "stream": false
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            let responseString = String(data: data, encoding: .utf8) ?? "No response body"
            throw AgentError.ollamaRequestFailed("HTTP status error or invalid response: \(response.debugDescription), Body: \(responseString)")
        }

        // Ollama's /api/generate endpoint returns a stream of JSON objects,
        // each with a "response" field. We need to concatenate these.
        // For non-streaming, it might return a single JSON object.
        // This example assumes a non-streaming, single-response format for simplicity.
        guard let jsonResult = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let llmResponse = jsonResult["response"] as? String else {
            throw AgentError.invalidLLMResponse("Ollama response did not contain 'response' field or was malformed.")
        }
        return llmResponse
        */

        // --- Mock Implementation for Demonstration ---
        print("🤖 OllamaClient: Sending prompt to model '\(model)':\n\(prompt.prefix(200))...\n")

        // Simulate network delay to mimic a real LLM call.
        try await Task.sleep(for: .milliseconds(800))

        // This mock response simulates a successful LLM generation that returns
        // structured JSON, which our `AgentOutput` struct is designed to parse.
        let mockJSONResponse = """
        {
          "summary": "This document outlines the Q3 2024 project review for the 'Apollo' initiative. Key stakeholders include Dr. Evelyn Reed and Mr. David Chen. The project is currently on track, with a critical dependency on the 'Orion' microservice integration, which is experiencing minor delays. A follow-up meeting is scheduled for next Tuesday to address these integration blockers.",
          "keyEntities": [
            "Q3 2024 Project Review",
            "Project Apollo",
            "Dr. Evelyn Reed",
            "Mr. David Chen",
            "Ms. Sarah Miller",
            "Orion Microservice",
            "December 15th",
            "Next Tuesday"
          ],
          "suggestedActions": {
            "email_david_chen": "Draft an email to Mr. David Chen to confirm follow-up with the Orion team.",
            "schedule_meeting_orion": "Schedule a follow-up meeting for next Tuesday to discuss Orion integration blockers and mitigation strategies."
          },
          "nextTool": "calendar_scheduler",
          "toolArguments": {
            "action": "create_event",
            "title": "Apollo Project - Orion Integration Review",
            "date": "next_tuesday",
            "attendees": "Dr. Evelyn Reed, Mr. David Chen, Ms. Sarah Miller"
          }
        }
        """
        print("🤖 OllamaClient: Received mock response.")
        return mockJSONResponse
    }
}

// MARK: - 3. Agent Output Structure

/// Defines the expected structured output from the LLM.
/// The agent's prompt will instruct the LLM to generate JSON conforming to this `Codable` structure.
/// This allows the agent to reliably extract specific pieces of information.
struct AgentOutput: Codable {
    let summary: String
    let keyEntities: [String]
    let suggestedActions: [String: String] // e.g., ["action_id": "description of action"]
    let nextTool: String? // Optional: The name of a tool the agent should call next.
    let toolArguments: [String: String]? // Optional: Arguments for the specified tool.
}

// MARK: - 4. Agent Tools (Simulated)

/// A protocol that defines the interface for any tool the agent can invoke.
/// This makes the agent's tool-use mechanism extensible and modular.
protocol AgentTool {
    var name: String { get }
    /// Executes the tool with a given set of arguments.
    /// - Parameter arguments: A dictionary of key-value arguments required by the tool.
    /// - Returns: A string representing the result or confirmation of the tool's action.
    func execute(arguments: [String: String]) async throws -> String
}

/// A simulated Calendar Scheduler tool that the agent can use to create calendar events.
/// This mimics interaction with an external system API (e.g., Apple Calendar, Google Calendar).
@available(iOS 18.0, macOS 15.0, *)
struct CalendarSchedulerTool: AgentTool {
    let name = "calendar_scheduler" // Unique identifier for this tool.

    /// Executes the calendar scheduling action based on provided arguments.
    /// - Parameter arguments: Expected to contain "action" (e.g., "create_event"), "title", "date", and "attendees".
    /// - Returns: A confirmation message indicating the event was "scheduled".
    /// - Throws: `AgentError.toolExecutionFailed` if required arguments are missing or invalid.
    func execute(arguments: [String: String]) async throws -> String {
        guard let action = arguments["action"], action == "create_event",
              let title = arguments["title"],
              let date = arguments["date"],
              let attendees = arguments["attendees"] else {
            throw AgentError.toolExecutionFailed("Missing or invalid arguments for CalendarSchedulerTool. Required: action=create_event, title, date, attendees.")
        }
        print("📅 CalendarSchedulerTool: Attempting to create event...")
        print("  Title: \(title)")
        print("  Date: \(date)")
        print("  Attendees: \(attendees)")
        // Simulate actual calendar API call or system integration delay.
        try await Task.sleep(for: .milliseconds(500))
        return "Successfully scheduled event: '\(title)' for \(date) with \(attendees)."
    }
}

// MARK: - 5. The Document Agent

/// The `DocumentAgent` is the central orchestrator of the agent loop.
/// It encapsulates the reasoning, acting, and observing phases for document analysis.
@available(iOS 18.0, macOS 15.0, *)
class DocumentAgent {
    private let ollamaClient: OllamaClient
    private var availableTools: [String: AgentTool] = [:]

    /// Initializes the DocumentAgent with an Ollama client and a collection of tools.
    /// - Parameters:
    ///   - ollamaClient: An instance of `OllamaClient` to interact with the local LLM.
    ///   - tools: An array of `AgentTool` instances that the agent can invoke.
    init(ollamaClient: OllamaClient, tools: [AgentTool]) {
        self.ollamaClient = ollamaClient
        // Register tools by their name for easy lookup.
        tools.forEach { self.availableTools[$0.name] = $0 }
        print("🧠 DocumentAgent initialized with model: \(ollamaClient.model)")
        print("🛠️ Available tools: \(availableTools.keys.joined(separator: ", "))")
    }

    /// Processes a given document text through the agent loop.
    /// This method orchestrates the core reasoning, acting, and observing steps.
    /// - Parameter documentText: The raw text content of the document to be analyzed.
    /// - Returns: An `AgentOutput` object containing the summary, key entities, and suggested actions.
    /// - Throws: `AgentError` if any part of the process (LLM call, parsing, tool execution) fails.
    func processDocument(documentText: String) async throws -> AgentOutput {
        print("\n--- Document Agent: Starting Analysis ---")

        // 1. Reasoning: Construct the prompt for the LLM.
        // This is the crucial step where the agent defines its goal and instructs the LLM
        // on the desired output format, including potential tool suggestions.
        let prompt = """
        You are an intelligent document analysis agent. Your primary task is to extract key information
        from the provided document text and suggest actionable next steps.
        Specifically, you need to:
        1.  Provide a concise summary of the document.
        2.  Identify and list all distinct key entities (e.g., people, organizations, projects, dates, specific terms).
        3.  Suggest relevant follow-up actions based on the document's content. Format these as a dictionary
            where keys are unique action identifiers and values are descriptive strings.
        4.  Crucially, if an action implies the use of an external tool (e.g., scheduling a meeting,
            drafting an email, setting a reminder), identify the appropriate `nextTool` and provide
            the necessary `toolArguments` as a dictionary.

        Respond ONLY with a JSON object that strictly conforms to the following structure:
        