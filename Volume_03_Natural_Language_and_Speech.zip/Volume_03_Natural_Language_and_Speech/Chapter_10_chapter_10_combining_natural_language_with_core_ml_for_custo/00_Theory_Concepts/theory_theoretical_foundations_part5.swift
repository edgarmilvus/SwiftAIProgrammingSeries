
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for a project using NaturalLanguage and CoreML
// Note: NaturalLanguage and CoreML are system frameworks,
// so they are typically imported directly in source files and don't require
// explicit Swift Package Manager dependencies for basic usage.
// However, if you were to wrap them in a custom Swift package
// that needs to declare dependencies, it would look like this
// (though for system frameworks, you usually just import them).

// In a real app target, you'd just import NaturalLanguage and CoreML.

// Example of a hypothetical Package.swift if these were external packages
// (which they are not, being system frameworks):

/*
// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "MyCustomNLPApp",
    platforms: [
        .iOS(.v18), // Specify minimum iOS version for @available annotations
        .macOS(.v15),
        .watchOS(.v11),
        .tvOS(.v18)
    ],
    products: [
        .library(
            name: "MyCustomNLPApp",
            targets: ["MyCustomNLPApp"]),
    ],
    dependencies: [
        // No explicit SPM dependencies for NaturalLanguage or CoreML
        // as they are system frameworks.
        // You would only list third-party libraries here.
    ],
    targets: [
        .target(
            name: "MyCustomNLPApp",
            dependencies: [
                // If there were specific modules from these frameworks
                // that needed to be explicitly linked, you might see them here.
                // For direct usage, simply 'import NaturalLanguage' and 'import CoreML'
                // in your Swift files is sufficient.
            ]),
        .testTarget(
            name: "MyCustomNLPAppTests",
            dependencies: ["MyCustomNLPApp"]),
    ]
)
*/

// Example Swift 6 code demonstrating basic NLModel usage with a custom Core ML model
import NaturalLanguage
import CoreML // Required for Core ML types and model loading

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
class CustomSentimentAnalyzer {
    private var customSentimentModel: NLModel?

    // Initializer to load the custom .mlmodel
    init(modelName: String) async throws {
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodel") else {
            // In a real app, provide a more robust error handling
            throw NSError(domain: "CustomSentimentAnalyzer", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Custom ML model '\(modelName).mlmodel' not found in app bundle."])
        }

        // NLModel.load(mlModel:) is an async method to load the Core ML model
        // and wrap it for Natural Language framework compatibility.
        self.customSentimentModel = try await NLModel.load(mlModel: modelURL)
        print("Custom sentiment model '\(modelName)' loaded successfully.")
    }

    // Function to predict sentiment for a given text
    func predictSentiment(for text: String) async throws -> String {
        guard let model = customSentimentModel else {
            throw NSError(domain: "CustomSentimentAnalyzer", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Sentiment model not loaded."])
        }

        // Use the predictedLabel(for:) method of NLModel
        // This method automatically handles text pre-processing (if built into the .mlmodel)
        // and calls Core ML for inference.
        let sentimentLabel = try await model.predictedLabel(for: text)
        return sentimentLabel
    }

    // Function to get the probabilities for all labels (e.g., "positive", "negative", "neutral")
    func predictSentimentProbabilities(for text: String) async throws -> [String: Double] {
        guard let model = customSentimentModel else {
            throw NSError(domain: "CustomSentimentAnalyzer", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Sentiment model not loaded."])
        }

        // Use the predictedLabelHypotheses(for:maximumHypotheses:) method for probabilities
        // The maximumHypotheses parameter limits the number of labels returned,
        // typically you'd want all for probabilities.
        let hypotheses = try await model.predictedLabelHypotheses(for: text, maximumHypotheses: 0) // 0 means all available
        return hypotheses
    }
}

// Example usage of the CustomSentimentAnalyzer
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
func demonstrateCustomNLP() async {
    let modelFileName = "MyCustomSentimentModel" // Replace with your actual .mlmodel file name

    do {
        // Initialize the analyzer, which loads the model asynchronously
        let analyzer = try await CustomSentimentAnalyzer(modelName: modelFileName)

        let text1 = "This movie was absolutely brilliant, a masterpiece!"
        let sentiment1 = try await analyzer.predictSentiment(for: text1)
        print("Text: '\(text1)' -> Predicted Sentiment: \(sentiment1)")

        let text2 = "It was just an average experience, nothing special."
        let sentiment2 = try await analyzer.predictSentiment(for: text2)
        print("Text: '\(text2)' -> Predicted Sentiment: \(sentiment2)")

        let text3 = "I encountered a critical bug, very frustrating."
        let sentiment3 = try await analyzer.predictSentiment(for: text3)
        print("Text: '\(text3)' -> Predicted Sentiment: \(sentiment3)")

        // Get probabilities for a text
        let text4 = "This product is fantastic!"
        let probabilities = try await analyzer.predictSentimentProbabilities(for: text4)
        print("Text: '\(text4)' -> Probabilities: \(probabilities)")

    } catch {
        print("Error demonstrating custom NLP: \(error.localizedDescription)")
        // Provide guidance for the user, e.g., "Ensure 'MyCustomSentimentModel.mlmodel' is added to your app target."
    }
}

// To run this example in a SwiftUI app, you might call demonstrateCustomNLP
// within a Task in .onAppear or from a button action.
/*
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .task {
                    await demonstrateCustomNLP()
                }
        }
    }
}
*/
