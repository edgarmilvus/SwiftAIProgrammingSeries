
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

@available(iOS 18.0, *)
enum AgentStep: Sendable {
    case weather(location: String)
    case todo(item: String)
    case finalResponse(String)
}

@available(iOS 18.0, *)
protocol WeatherServiceProtocol: Sendable {
    func getWeather(for location: String) async throws -> String
}

@available(iOS 18.0, *)
protocol TodoServiceProtocol: Sendable {
    func addTask(_ item: String) async throws -> Bool
}

// --- Concrete Implementations ---

@available(iOS 18.0, *)
actor WeatherService: WeatherServiceProtocol {
    func getWeather(for location: String) async throws -> String {
        try await Task.sleep(for: .seconds(1)) // Simulate API call
        return "Sunny in \(location)"
    }
}

@available(iOS 18.0, *)
actor TodoService: TodoServiceProtocol {
    func addTask(_ item: String) async throws -> Bool {
        try await Task.sleep(for: .seconds(0.5)) // Simulate DB write
        print("✅ Added to Todo: \(item)")
        return true
    }
}

// --- The Orchestrator ---

@available(iOS 18.0, *)
actor AgenticOrchestrator {
    let weatherService: any WeatherServiceProtocol
    let todoService: any TodoServiceProtocol
    
    init(weather: any WeatherServiceProtocol, todo: any TodoServiceProtocol) {
        self.weatherService = weather
        self.todoService = todo
    }
    
    func executeAgenticWorkflow(userPrompt: String) async throws -> String {
        // 1. Simulate LLM parsing the prompt into a plan
        // In a real app, this would be a network call to an LLM.
        let plan: [AgentStep] = [
            .weather(location: "Tokyo"),
            .weather(location: "New York"),
            .todo(item: "Check Flight")
        ]
        
        print("Orchestrator: Executing plan with \(plan.count) steps...")

        // 2. Use TaskGroup for structured concurrency
        return try await withThrowingTaskGroup(of: String.self) { group in
            for step in plan {
                group.addTask {
                    switch step {
                    case .weather(let location):
                        let result = try await self.weatherService.getWeather(for: location)
                        return "Weather Report: \(result)"
                        
                    case .todo(let item):
                        let success = try await self.todoService.addTask(item)
                        return success ? "Todo Success: \(item)" : "Todo Failed"
                        
                    case .finalResponse(let text):
                        return text
                    }
                }
            }
            
            var results: [String] = []
            
            // 3. Collect results and handle errors
            // If any task throws, the group will catch it.
            while let result = try await group.next() {
                results.append(result)
            }
            
            return "Workflow Complete. Results: \(results.joined(separator: " | "))"
        }
    }
}

// --- Execution ---
@available(iOS 18.0, *)
func runOrchestratorTest() async {
    let orchestrator = AgenticOrchestrator(
        weather: WeatherService(),
        todo: TodoService()
    )
    
    do {
        let summary = try await orchestrator.executeAgenticWorkflow(userPrompt: "Check weather in Tokyo and New York, then add 'Check Flight' to my todo list.")
        print(summary)
    } catch {
        print("Orchestrator Error: \(error.localizedDescription)")
    }
}
