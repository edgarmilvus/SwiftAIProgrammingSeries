
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import AVFoundation
import UIKit

@available(iOS 18.0, *)
struct CameraPreview: UIViewRepresentable {
    // AVCaptureSession is a reference type and manages the camera hardware.
    // It's created once and its lifecycle is managed by the UIViewRepresentable.
    private let session = AVCaptureSession()
    // The preview layer will be created in makeUIView and held by the UIView's layer.
    private var previewLayer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black // Background color for when the camera feed isn't ready

        // Setup the AVCaptureSession on a background queue to avoid blocking the main thread.
        DispatchQueue.global(qos: .userInitiated).async {
            self.setupSession(for: view)
        }

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        // Ensure the preview layer's frame always matches the UIView's bounds.
        // This is crucial for correct layout when the SwiftUI view's size changes.
        if let layer = previewLayer {
            layer.frame = uiView.bounds
        }
    }

    // MARK: - AVCaptureSession Setup

    private func setupSession(for view: UIView) {
        // Begin a configuration block to make multiple changes atomically.
        session.beginConfiguration()
        defer { session.commitConfiguration() } // Ensure commitConfiguration() is called

        // Remove any existing inputs to ensure a clean setup.
        for input in session.inputs {
            session.removeInput(input)
        }

        // 1. Find the default back camera device.
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Error: No default back camera available.")
            return
        }

        // 2. Create an input from the video device.
        guard let videoDeviceInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            print("Error: Could not create AVCaptureDeviceInput from device: \(videoDevice).")
            return
        }

        // 3. Add the input to the session if possible.
        if session.canAddInput(videoDeviceInput) {
            session.addInput(videoDeviceInput)
        } else {
            print("Error: Could not add video device input to the session.")
            return
        }

        // 4. Create and configure the preview layer.
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill // Scale the video to fill the layer bounds.
        layer.frame = view.bounds // Set initial frame.

        // Store the layer reference and add it to the view's layer on the main thread.
        DispatchQueue.main.async {
            self.previewLayer = layer
            view.layer.addSublayer(layer)
        }
    }

    // MARK: - Session Lifecycle Management

    // SwiftUI's .onAppear and .onDisappear modifiers will call these methods.
    // Starting and stopping the session should be done on a background queue.
    func startSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            if !self.session.isRunning {
                self.session.startRunning()
                print("AVCaptureSession started.")
            }
        }
    }

    func stopSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            if self.session.isRunning {
                self.session.stopRunning()
                print("AVCaptureSession stopped.")
            }
        }
    }
}

// MARK: - SwiftUI Wrapper for Exercise 1

@available(iOS 18.0, *)
struct Exercise1WrapperView: View {
    // Instantiate CameraPreview
    private let cameraPreview = CameraPreview()

    var body: some View {
        cameraPreview
            .onAppear {
                // When the view appears, start the camera session.
                cameraPreview.startSession()
            }
            .onDisappear {
                // When the view disappears, stop the camera session to save battery and resources.
                cameraPreview.stopSession()
            }
            .ignoresSafeArea() // Make the camera preview fill the entire screen.
    }
}
