
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

enum ScreenshotTemplate {
    case interaction
    case transformation
}

struct ScreenshotPrototyper: View {
    let template: ScreenshotTemplate
    let prompt: String
    let output: String
    let isThinking: Bool
    
    var body: some View {
        ZStack {
            backgroundAesthetic
            
            VStack(spacing: 40) {
                Text(templateTitle)
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                
                contentView
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(25)
                    .padding()
            }
        }
        .frame(width: 1290, height: 2796) // iPhone 15 Pro Max Aspect Ratio
    }
    
    @ViewBuilder
    private var backgroundAesthetic: some View {
        if #available(iOS 18.0, *) {
            MeshGradient(width: 3, height: 3, points: [
                [0, 0], [0.5, 0], [1, 0],
                [0, 0.5], [0.8, 0.8], [1, 0.5],
                [0, 1], [0.5, 1], [1, 1]
            ], colors: [
                .indigo, .purple, .blue,
                .black, .deepPurple, .black,
                .blue, .indigo, .black
            ])
            .ignoresSafeArea()
        } else {
            LinearGradient(colors: [.black, .indigo], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
        }
    }
    
    @ViewBuilder
    private var contentView: some View {
        switch template {
        case .interaction:
            VStack(alignment: .leading, spacing: 20) {
                // User Prompt
                Text(prompt)
                    .padding()
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(15)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                
                if isThinking {
                    HStack {
                        ProgressView()
                        Text("AI is thinking...")
                            .italic()
                    }
                    .frame(maxWidth: .infinity)
                } else {
                    // AI Response
                    Text(output)
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(15)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            
        case .transformation:
            VStack(spacing: 30) {
                VStack(alignment: .leading) {
                    Text("INPUT").font(.caption).bold()
                    Text(prompt).italic()
                }
                
                Image(systemName: "arrow.down.circle.fill")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                
                VStack(alignment: .leading) {
                    Text("AI ENHANCED").font(.caption).bold()
                    Text(output)
                }
            }
        }
    }
    
    private var templateTitle: String {
        template == .interaction ? "Seamless Chat" : "Instant Polish"
    }
}

// MARK: - Export Logic
extension View {
    @MainActor
    func exportToImage() -> UIImage? {
        let renderer = ImageRenderer(content: self)
        renderer.scale = 3.0 // High resolution
        return renderer.uiImage
    }
}

// Usage Example
#Preview {
    ScreenshotPrototyper(
        template: .interaction,
        prompt: "Write a poem about Swift 6 concurrency.",
        output: "In threads of light, the actors dance...",
        isThinking: false
    )
}
