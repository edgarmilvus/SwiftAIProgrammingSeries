
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import MLXNN
import MLXOptimizers
import Foundation // For URL and file operations

// Re-use LoRALinear from previous exercises for self-containment
@available(iOS 18.0, macOS 15.0, *)
final class LoRALinear: MLXNN.Module {
    let baseLinear: MLXNN.Linear
    let loraA: MLXNN.Linear
    let loraB: MLXNN.Linear
    let scale: Float

    init(inputFeatures: Int, outputFeatures: Int, rank: Int, scale: Float = 1.0) {
        self.baseLinear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        self.loraA = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: rank, bias: false)
        self.loraB = MLXNN.Linear(inputFeatures: rank, outputFeatures: outputFeatures, bias: false)
        self.scale = scale
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        let baseOutput = baseLinear(x)
        let delta = loraB(loraA(x)) * scale
        return baseOutput + delta
    }

    override var parameters: [MLXArray] {
        return loraA.parameters + loraB.parameters
    }
}

// MARK: - 1. Base Recommender Model with LoRA

@available(iOS 18.0, macOS 15.0, *)
final class PodcastRecommender: MLXNN.Module {
    let userEmbedding: MLXNN.Embedding // Maps user IDs to dense vectors
    let itemEmbedding: MLXNN.Embedding // Maps item IDs to dense vectors
    let loraLayer1: LoRALinear         // First LoRA-adapted linear layer
    let relu: MLXNN.ReLU
    let loraLayer2: LoRALinear         // Second LoRA-adapted linear layer, outputs preference score

    init(numUsers: Int, numItems: Int, embedDim: Int, hiddenDim: Int, loraRank: Int) {
        self.userEmbedding = MLXNN.Embedding(outputDimensions: embedDim, inputDimensions: numUsers)
        self.itemEmbedding = MLXNN.Embedding(outputDimensions: embedDim, inputDimensions: numItems)
        
        // The input to the first linear layer is the concatenation of user and item embeddings.
        let combinedInputDim = embedDim * 2

        self.loraLayer1 = LoRALinear(inputFeatures: combinedInputDim, outputFeatures: hiddenDim, rank: loraRank)
        self.relu = MLXNN.ReLU()
        // The final layer outputs a single preference score (e.g., between 0 and 1).
        self.loraLayer2 = LoRALinear(inputFeatures: hiddenDim, outputFeatures: 1, rank: loraRank)
        super.init()
    }

    override func callAsFunction(_ userIDs: MLXArray, _ itemIDs: MLXArray) -> MLXArray {
        let userEmbeds = userEmbedding(userIDs) // [batch, embed_dim]
        let itemEmbeds = itemEmbedding(itemIDs) // [batch, embed_dim]

        // Concatenate user and item embeddings to form the input feature vector.
        let combinedEmbeds = MLXArray.concatenate([userEmbeds, itemEmbeds], axis: -1) // [batch, embed_dim*2]

        let x = relu(loraLayer1(combinedEmbeds))
        return loraLayer2(x) // [batch, 1] - predicted preference score
    }

    // Expose only LoRA parameters for training.
    // The base `userEmbedding` and `itemEmbedding` are also frozen for this LoRA scenario.
    override var parameters: [MLXArray] {
        return loraLayer1.parameters + loraLayer2.parameters
    }
}

// MARK: - Training Loops, Saving/Loading, and Execution

@available(iOS 18.0, macOS 15.0, *)
func runExercise4() {
    let numUsers = 1000
    let numItems = 500
    let embedDim = 64
    let hiddenDim = 128
    let loraRank = 8
    let learningRate: Float = 5e-4
    let batchSize = 64

    let initialTrainingSteps = 200
    let incrementalTrainingSteps = 50

    // Define a temporary file path for saving LoRA weights.
    let loRAWeightsPath = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("podcast_recommender_lora_weights.safetensors")
        .path
    
    print("LoRA weights will be saved to: \(loRAWeightsPath)")

    // 1. Initial Training Phase (simulated general adaptation)
    print("--- Starting Initial LoRA Training Phase ---")
    var model = PodcastRecommender(
        numUsers: numUsers, numItems: numItems,
        embedDim: embedDim, hiddenDim: hiddenDim, loraRank: loraRank
    )
    var optimizer = MLXNN.Optimizers.AdamW(learningRate: learningRate)

    for step in 0..<initialTrainingSteps {
        // Generate synthetic data for user-item interactions and preference scores.
        let userIDs = MLXArray.randomUniform(low: 0, high: numUsers, [batchSize], type: .int32)
        let itemIDs = MLXArray.randomUniform(low: 0, high: numItems, [batchSize], type: .int32)
        // Simulate preference scores between 0 and 1.
        let preferenceScores = MLXArray.randomUniform(low: 0, high: 1, [batchSize, 1])

        let lossFn = { (model: PodcastRecommender, users: MLXArray, items: MLXArray, scores: MLXArray) -> MLXArray in
            let predictions = model(users, items)
            return MLXNN.Loss.mseLoss(predictions: predictions, targets: scores) // Mean Squared Error for regression
        }

        let (loss, gradients) = MLX.valueAndGradient(model: model, lossFn, userIDs, itemIDs, preferenceScores)
        optimizer.update(model: model, gradients: gradients)

        if step % 50 == 0 {
            print("Initial Training - Step \(step), Loss: \(loss.item(Float.self))")
        }
    }
    print("Initial LoRA training complete.")

    // 2. Save the trained LoRA parameters
    print("\nSaving LoRA parameters to: \(loRAWeightsPath)")
    MLX.save(parameters: model.parameters, path: loRAWeightsPath)
    print("LoRA parameters saved successfully.")

    // 3. Incremental Fine-tuning Mechanism (simulated new user interactions)
    print("\n--- Starting Incremental LoRA Fine-tuning Phase ---")

    // Create a new model instance. This simulates an app restart or a new session
    // where the base model is re-initialized, but we want to load and continue
    // fine-tuning the previously learned LoRA adaptations.
    var incrementalModel = PodcastRecommender(
        numUsers: numUsers, numItems: numItems,
        embedDim: embedDim, hiddenDim: hiddenDim, loraRank: loraRank
    )

    // Load previously saved LoRA parameters.
    print("Loading LoRA parameters from: \(loRAWeightsPath)")
    let loadedLoRAParams = MLX.load(path: loRAWeightsPath)
    // Update the incrementalModel's LoRA parameters with the loaded ones.
    incrementalModel.update(parameters: loadedLoRAParams)
    print("LoRA parameters loaded for incremental training.")

    // A new optimizer instance for incremental training.
    // Often, a lower learning rate is used for incremental fine-tuning.
    var incrementalOptimizer = MLXNN.Optimizers.AdamW(learningRate: learningRate / 2)

    for step in 0..<incrementalTrainingSteps {
        // Simulate new, specific user interactions (e.g., a user's recent listening history).
        let newUsers = MLXArray.randomUniform(low: 0, high: numUsers, [batchSize], type: .int32)
        let newItems = MLXArray.randomUniform(low: 0, high: numItems, [batchSize], type: .int32)
        // Simulate slightly different, perhaps more specific, preference scores reflecting new tastes.
        let newPreferenceScores = MLXArray.randomUniform(low: 0.5, high: 1.0, [batchSize, 1])

        let lossFn = { (model: PodcastRecommender, users: MLXArray, items: MLXArray, scores: MLXArray) -> MLXArray in
            let predictions = model(users, items)
            return MLXNN.Loss.mseLoss(predictions: predictions, targets: scores)
        }

        let (loss, gradients) = MLX.valueAndGradient(model: incrementalModel, lossFn, newUsers, newItems, newPreferenceScores)
        incrementalOptimizer.update(model: incrementalModel, gradients: gradients)

        if step % 10 == 0 {
            print("Incremental Training - Step \(step), Loss: \(loss.item(Float.self))")
        }
    }
    print("Incremental LoRA fine-tuning complete.")

    // Clean up the temporary file after demonstration.
    do {
        try FileManager.default.removeItem(atPath: loRAWeightsPath)
        print("Cleaned up temporary LoRA weights file.")
    } catch {
        print("Error cleaning up temporary file: \(error)")
    }

    print("\n--- Pedagogical Note: Incremental Learning & Persistence ---")
    print("This exercise vividly demonstrates how LoRA enables continuous, on-device model adaptation for applications like recommendation engines.")
    print("By training only the small LoRA adapter weights, the model can quickly learn from new user interactions (e.g., new podcast likes/dislikes)")
    print("without the immense computational and memory cost of retraining the entire base model from scratch.")
    print("MLX's `save(parameters:path:)` and `load(path:)` functions are crucial for persisting and restoring these learned LoRA adapters.")
    print("These functions efficiently serialize and deserialize `MLXArray` data directly from and to Unified Memory, avoiding any CPU-GPU data transfers.")
    print("This capability is fundamental for building responsive, personalized, and privacy-preserving AI features in real-world iOS/macOS applications, where models need to evolve with user behavior over time.")
}

// Call the function to run the exercise
// runExercise4()
