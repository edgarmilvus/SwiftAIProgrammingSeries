/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 1. Define the shape of our User State
// This ensures type safety across the entire application.
type UserState = {
  username: string | null;
  isAuthenticated: boolean;
  theme: 'light' | 'dark';
};

// 2. Define the Actions (State Mutations)
// We separate logic from state for cleaner code.
type UserActions = {
  login: (username: string) => void;
  logout: () => void;
  toggleTheme: () => void;
};

// 3. Combine State and Actions into a Store Type
type UserStore = UserState & UserActions;

// 4. Create the Store with Persistence Middleware
// 'persist' wraps the store and syncs it with storage.
export const useUserStore = create<UserStore>()(
  persist(
    (set, get) => ({
      // Initial State
      username: null,
      isAuthenticated: false,
      theme: 'light',

      // Actions Implementation
      login: (username: string) =>
        set({
          username,
          isAuthenticated: true,
        }),

      logout: () =>
        set({
          username: null,
          isAuthenticated: false,
        }),

      toggleTheme: () => {
        const currentTheme = get().theme;
        set({ theme: currentTheme === 'light' ? 'dark' : 'light' });
      },
    }),
    {
      // 5. Middleware Configuration
      // This tells Zustand where to store the data.
      name: 'user-session-storage', // Unique key for the storage item
      storage: createJSONStorage(() => AsyncStorage), // Use AsyncStorage for React Native
      // Note: On Web, you can swap AsyncStorage with 'localStorage' directly here.
    }
  )
);
