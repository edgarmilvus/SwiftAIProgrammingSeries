
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppKit // For macOS UI elements like NSTextView, NSTextDelegate
import Foundation

// Reusing LLMStreamResponse struct from Exercise 2/3
struct LLMStreamResponse: Decodable {
    let response: String?
    let done: Bool?
}

// MARK: - CodeEditorViewController

@available(macOS 15.0, *) // Targeting macOS for a code editor scenario
class CodeEditorViewController: NSViewController, NSTextDelegate {

    // MARK: - UI Elements

    private lazy var codeTextView: NSTextView = {
        let scrollView = NSTextView.scrollableTextView()
        let tv = scrollView.documentView as! NSTextView
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = NSFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        tv.backgroundColor = NSColor.windowBackgroundColor
        tv.textColor = NSColor.labelColor
        tv.isRichText = false
        tv.isAutomaticQuoteSubstitutionEnabled = false
        tv.isAutomaticDashSubstitutionEnabled = false
        tv.textContainerInset = NSSize(width: 10, height: 10)
        tv.delegate = self // Set delegate for text change notifications
        return tv
    }()

    private lazy var completionTextView: NSTextView = {
        let scrollView = NSTextView.scrollableTextView()
        let tv = scrollView.documentView as! NSTextView
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.isEditable = false
        tv.font = NSFont.monospacedSystemFont(ofSize: 14, weight: .light) // Lighter font for suggestions
        tv.backgroundColor = NSColor.controlBackgroundColor
        tv.textColor = NSColor.secondaryLabelColor
        tv.textContainerInset = NSSize(width: 10, height: 10)
        tv.alphaValue = 0.8 // Slightly transparent
        tv.isHidden = true // Initially hidden
        tv.layer?.cornerRadius = 5
        tv.layer?.masksToBounds = true
        return tv
    }()

    // MARK: - Properties

    private let streamingURL = URL(string: "http://127.0.0.1:5000/stream/json")! // Simulated LLM endpoint
    private let debounceInterval: TimeInterval = 0.5 // Seconds to wait after typing stops
    private var debounceTask: Task<Void, Never>? // Task for debouncing input
    private var currentCompletionTask: Task<Void, Error>? // Task for the active LLM streaming request

    // MARK: - Lifecycle

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true // Enable layers for cornerRadius on completionTextView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        codeTextView.string = "func greet(name: String) {\n  print(\"Hello, \\(name)!\")\n}" // Initial code
    }

    override func viewWillDisappear() {
        super.viewWillDisappear()
        debounceTask?.cancel()
        currentCompletionTask?.cancel()
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.addSubview(codeTextView.enclosingScrollView!) // Add the scroll view containing the text view
        view.addSubview(completionTextView.enclosingScrollView!)

        NSLayoutConstraint.activate([
            codeTextView.enclosingScrollView!.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            codeTextView.enclosingScrollView!.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            codeTextView.enclosingScrollView!.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            codeTextView.enclosingScrollView!.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            // Position completionTextView as an overlay below the codeTextView
            completionTextView.enclosingScrollView!.topAnchor.constraint(equalTo: codeTextView.enclosingScrollView!.topAnchor, constant: 100), // Adjust Y position as needed
            completionTextView.enclosingScrollView!.leadingAnchor.constraint(equalTo: codeTextView.enclosingScrollView!.leadingAnchor, constant: 40), // Adjust X position
            completionTextView.enclosingScrollView!.widthAnchor.constraint(equalTo: codeTextView.enclosingScrollView!.widthAnchor, multiplier: 0.7), // Make it narrower
            completionTextView.enclosingScrollView!.heightAnchor.constraint(equalToConstant: 150) // Fixed height for completion box
        ])
    }

    // MARK: - NSTextDelegate

    func textDidChange(_ notification: Notification) {
        guard notification.object as? NSTextView == codeTextView else { return }

        let currentCode = codeTextView.string
        print("Text did change. Current code length: \(currentCode.count)")

        // Cancel any existing debounce task
        debounceTask?.cancel()

        // Start a new debounce task
        debounceTask = Task {
            do {
                try await Task.sleep(for: .milliseconds(Int(debounceInterval * 1000)))
                // If we reach here, typing has paused for debounceInterval
                print("Debounce complete. Initiating LLM request for code: \(currentCode.prefix(50))...")
                await requestLLMCompletion(for: currentCode)
            } catch is CancellationError {
                print("Debounce task cancelled due to new input.")
            } catch {
                print("Error in debounce task: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - LLM Completion Logic

    private func requestLLMCompletion(for codeContext: String) async {
        // Cancel any *previously ongoing* LLM streaming task
        currentCompletionTask?.cancel()
        await MainActor.run {
            completionTextView.string = "" // Clear previous completion
            completionTextView.isHidden = false // Show completion overlay
        }

        currentCompletionTask = Task {
            defer { // Ensure completion UI is hidden when task finishes, errors, or cancels
                Task { @MainActor in
                    self.completionTextView.isHidden = true
                }
            }
            await streamLLMCompletion(for: codeContext)
        }
    }

    private func streamLLMCompletion(for codeContext: String) async {
        do {
            // In a real scenario, 'codeContext' would be part of the POST request body
            // to the LLM endpoint to provide context for completion.
            // For this POC, we just use the fixed streaming URL.
            let (bytes, response) = try await URLSession.shared.bytes(for: streamingURL)

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                throw URLError(.badServerResponse)
            }

            var buffer = Data()
            let newline = Data([0x0A]) // ASCII for '\n'

            for await chunk in bytes {
                try Task.checkCancellation() // Check for cancellation
                buffer.append(chunk)

                while let range = buffer.range(of: newline) {
                    let jsonLineData = buffer.prefix(upTo: range.lowerBound)
                    buffer.removeSubrange(0...range.lowerBound)

                    if jsonLineData.isEmpty { continue }

                    do {
                        let decoder = JSONDecoder()
                        let streamResponse = try decoder.decode(LLMStreamResponse.self, from: jsonLineData)

                        if let completionText = streamResponse.response, !completionText.isEmpty {
                            await MainActor.run {
                                completionTextView.string.append(completionText)
                                let bottom = NSRange(location: completionTextView.string.count - 1, length: 1)
                                completionTextView.scrollRangeToVisible(bottom)
                            }
                        }

                        if streamResponse.done == true {
                            print("LLM completion stream finished (done: true received).")
                            return
                        }

                    } catch {
                        print("Error decoding JSON line for completion: \(error.localizedDescription)")
                    }
                }
            }
            print("LLM completion stream finished (no more bytes).")

        } catch is CancellationError {
            print("LLM completion stream cancelled.")
        } catch {
            print("Error during LLM completion streaming: \(error.localizedDescription)")
            await MainActor.run {
                completionTextView.string = "Error: \(error.localizedDescription)"
                completionTextView.textColor = .systemRed
            }
        }
    }
}
