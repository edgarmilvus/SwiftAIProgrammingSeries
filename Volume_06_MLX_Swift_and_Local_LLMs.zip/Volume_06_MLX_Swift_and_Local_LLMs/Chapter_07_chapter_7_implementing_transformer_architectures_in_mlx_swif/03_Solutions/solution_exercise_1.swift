
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX
import MLXNN // For MLXNN.Module and MLXNN.Linear

@available(iOS 18.0, macOS 15.0, *)
class MultiHeadSelfAttention: MLXNN.Module {
    let queryProjection: MLXNN.Linear
    let keyProjection: MLXNN.Linear
    let valueProjection: MLXNN.Linear
    let outputProjection: MLXNN.Linear
    let numHeads: Int
    let headDimension: Int

    init(modelDimension: Int, numHeads: Int, keyQueryValueBias: Bool = true) {
        precondition(modelDimension % numHeads == 0, "modelDimension must be divisible by numHeads")
        self.numHeads = numHeads
        self.headDimension = modelDimension / numHeads

        // Initialize linear layers for Q, K, V projections and the final output projection.
        // These layers transform the input embedding into the respective Q, K, V spaces
        // and combine the attention heads.
        self.queryProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.keyProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.valueProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.outputProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension) // Output projection typically has no bias
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // x: [batchSize, sequenceLength, modelDimension]

        let batchSize = x.shape[0]
        let sequenceLength = x.shape[1]

        // 1. Project input to Q, K, V using independent linear transformations.
        // Each projection results in a tensor of shape [batchSize, sequenceLength, modelDimension].
        let q = queryProjection(x)
        let k = keyProjection(x)
        let v = valueProjection(x)

        // 2. Reshape and transpose for multi-head attention.
        // The goal is to transform [batchSize, sequenceLength, modelDimension]
        // into [batchSize, numHeads, sequenceLength, headDimension].
        // This involves splitting the `modelDimension` into `numHeads` * `headDimension`
        // and then transposing to bring `numHeads` to the second dimension.
        let q_heads = q.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)
        let k_heads = k.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)
        let v_heads = v.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)

        // 3. Calculate scaled dot-product attention.
        // QK^T: [batchSize, numHeads, sequenceLength, sequenceLength]
        // This computes attention scores between all query and key pairs for each head and batch.
        let scores = mlx.core.matmul(q_heads, k_heads.transposed(0, 1, 3, 2))

        // Scale the scores by the square root of the head dimension to prevent vanishing gradients.
        let scaledScores = scores / MLXArray(Float(headDimension).squareRoot())

        // Apply softmax to get attention weights. The softmax is applied along the last dimension
        // (the key dimension), ensuring weights for each query sum to 1.
        let attentionWeights = mlx.core.softmax(scaledScores, axis: -1)

        // Multiply attention weights by values to get the weighted sum of values for each head.
        // outputHeads: [batchSize, numHeads, sequenceLength, headDimension]
        let outputHeads = mlx.core.matmul(attentionWeights, v_heads)

        // 4. Concatenate heads and project back to the original model dimension.
        // First, transpose back to [batchSize, sequenceLength, numHeads, headDimension]
        // then reshape to combine the heads: [batchSize, sequenceLength, modelDimension].
        let concatenatedOutput = outputHeads.transposed(0, 2, 1, 3).reshaped([batchSize, sequenceLength, numHeads * headDimension])

        // Finally, project the concatenated output to the desired `modelDimension`.
        let finalOutput = outputProjection(concatenatedOutput)

        // MLX Swift's lazy evaluation means that operations like `matmul`, `softmax`, `reshaped`
        // do not immediately compute results. Instead, they build up a computation graph.
        // The actual computation will only be triggered when the result is explicitly needed,
        // for instance, when `finalOutput` is used in a loss function, printed, or saved.
        return finalOutput
    }
}
