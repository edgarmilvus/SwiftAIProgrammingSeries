
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - Codable Structures (Model Pull)

/// Represents the request body for the /api/pull endpoint.
struct PullRequest: Codable {
    let name: String // e.g., "phi3" or "llama3:8b"
    let insecure: Bool? // Optional: allow insecure connections to custom registries
}

/// Represents a single progress update chunk from the /api/pull endpoint.
struct PullProgressResponse: Codable {
    let status: String // e.g., "pulling manifest", "downloading 1/1 layer", "verifying checksum", "success"
    let digest: String? // Identifier for the layer/manifest being processed
    let total: Int? // Total bytes for the current layer/overall download
    let completed: Int? // Completed bytes for the current layer/overall download
    let eta: Int? // Estimated time of arrival in seconds
    let error: String? // If an error occurs within the stream

    // Custom CodingKeys for snake_case
    enum CodingKeys: String, CodingKey {
        case status, digest, total, completed, eta, error
    }

    /// Helper to calculate progress percentage for the current step.
    var progressPercentage: Double? {
        guard let total = total, let completed = completed, total > 0 else { return nil }
        return Double(completed) / Double(total)
    }

    /// Helper to provide a human-readable progress string.
    var progressDescription: String {
        if let percentage = progressPercentage {
            let p = String(format: "%.1f%%", percentage * 100)
            let formatter = ByteCountFormatter()
            formatter.countStyle = .file
            let completedStr = formatter.string(fromByteCount: Int64(completed ?? 0))
            let totalStr = formatter.string(fromByteCount: Int64(total ?? 0))
            return "\(status) - \(p) (\(completedStr) / \(totalStr))"
        }
        return status
    }
}

// MARK: - Ollama Service (Extension for Model Pull)

extension OllamaService {
    /// Initiates a model download (pull) from Ollama's registry and streams progress updates.
    /// - Parameters:
    ///   - modelName: The name of the model to pull (e.g., "phi3").
    ///   - onProgressUpdate: A closure called with each `PullProgressResponse` received.
    ///   - onComplete: A closure called when the pull operation finishes, with success or an error.
    func pullModel(
        modelName: String,
        onProgressUpdate: @escaping @MainActor (PullProgressResponse) -> Void,
        onComplete: @escaping @MainActor (Result<String, OllamaError>) -> Void
    ) async {
        guard let url = URL(string: "\(baseURLString)/api/pull") else {
            await onComplete(.failure(.invalidURL))
            return
        }

        let requestBody = PullRequest(name: modelName)

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase
            urlRequest.httpBody = try encoder.encode(requestBody)
        } catch {
            await onComplete(.failure(.encodingError(error)))
            return
        }

        var buffer = Data()
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase

        do {
            let (asyncBytes, response) = try await session.bytes(for: urlRequest)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw OllamaError.networkError(URLError(.badServerResponse))
            }

            guard (200...299).contains(httpResponse.statusCode) else {
                let errorData = try await asyncBytes.reduce(Data()) { $0 + $1 }
                if let apiError = try? decoder.decode(OllamaAPIError.self, from: errorData) {
                    throw OllamaError.apiError(apiError.error)
                }
                throw OllamaError.invalidHTTPResponse(httpResponse.statusCode)
            }

            for try await byte in asyncBytes {
                buffer.append(byte)

                while let newlineRange = buffer.firstRange(of: Data([0x0A])) {
                    let jsonChunkData = buffer.prefix(upTo: newlineRange.lowerBound)
                    buffer.removeSubrange(..<newlineRange.upperBound)

                    if jsonChunkData.isEmpty { continue }

                    do {
                        let progressResponse = try decoder.decode(PullProgressResponse.self, from: jsonChunkData)

                        await onProgressUpdate(progressResponse) // Deliver progress update

                        if let error = progressResponse.error {
                            // Ollama can report errors within the stream itself
                            await onComplete(.failure(.apiError(error)))
                            return
                        }

                        if progressResponse.status == "success" {
                            await onComplete(.success("Model '\(modelName)' pulled successfully."))
                            return
                        }
                    } catch {
                        print("Warning: Failed to decode pull progress chunk: \(error.localizedDescription) - Data: \(String(data: jsonChunkData, encoding: .utf8) ?? "N/A")")
                        // If it's the last chunk and decoding fails, it might still be a success message
                        // Or a final error. We'll let the loop finish or the next error catch handle it.
                    }
                }
            }
            // If the loop finishes without a 'success' status, it might be an unexpected termination
            await onComplete(.failure(.apiError("Model pull stream ended unexpectedly without success status.")))

        } catch {
            await onComplete(.failure(error as? OllamaError ?? .networkError(error)))
        }
    }
}

// MARK: - Example Usage (Conceptual UI interaction)

@MainActor
class ModelPullViewModel: ObservableObject {
    @Published var modelNameInput: String = "phi3" // Default model to suggest
    @Published var currentStatus: String = "Ready to pull model"
    @Published var progress: Double? // For a progress bar (0.0 to 1.0)
    @Published var isPulling: Bool = false
    @Published var errorMessage: String?

    private let ollamaService = OllamaService()
    private var pullTask: Task<Void, Never>?

    func startPull() {
        guard !modelNameInput.isEmpty else {
            errorMessage = "Model name cannot be empty."
            return
        }

        isPulling = true
        errorMessage = nil
        currentStatus = "Initiating pull for '\(modelNameInput)'..."
        progress = nil // Reset progress bar

        let modelToPull = modelNameInput

        pullTask = Task {
            await ollamaService.pullModel(
                modelName: modelToPull,
                onProgressUpdate: { [weak self] response in
                    self?.currentStatus = response.progressDescription
                    self?.progress = response.progressPercentage // Update progress bar value
                },
                onComplete: { [weak self] result in
                    self?.isPulling = false
                    self?.pullTask = nil // Clear the task reference
                    switch result {
                    case .success(let message):
                        self?.currentStatus = message
                        self?.progress = 1.0 // Ensure progress bar is full on success
                        print(message)
                    case .failure(let error):
                        self?.errorMessage = error.localizedDescription
                        self?.currentStatus = "Pull failed: \(error.localizedDescription)"
                        self?.progress = nil // Clear progress on failure
                        print("Model pull error: \(error.localizedDescription)")
                    }
                }
            )
        }
    }

    func cancelPull() {
        pullTask?.cancel()
        isPulling = false
        currentStatus = "Pull cancelled by user."
        progress = nil
        errorMessage = nil
        print("Model pull cancelled.")
    }
}

// To run this example in a Playground or a Swift application:
// You would typically integrate ModelPullViewModel into a SwiftUI View.
/*
import SwiftUI

struct ModelPullView: View {
    @StateObject private var viewModel = ModelPullViewModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Pull Ollama Model")
                .font(.headline)

            HStack {
                TextField("Model Name (e.g., phi3)", text: $viewModel.modelNameInput)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .disabled(viewModel.isPulling)

                Button(action: {
                    if viewModel.isPulling {
                        viewModel.cancelPull()
                    } else {
                        viewModel.startPull()
                    }
                }) {
                    Text(viewModel.isPulling ? "Cancel Pull" : "Pull Model")
                }
                .disabled(viewModel.modelNameInput.isEmpty)
            }

            if viewModel.isPulling {
                if let progressValue = viewModel.progress {
                    ProgressView(value: progressValue)
                        .progressViewStyle(.linear)
                } else {
                    ProgressView() // Indeterminate progress
                }
            }

            Text("Status: \(viewModel.currentStatus)")
                .font(.subheadline)
                .foregroundColor(.secondary)

            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .font(.callout)
            }
        }
        .padding()
        .navigationTitle("Ollama Model Manager")
    }
}

// To preview or run:
// #Preview {
//     ModelPullView()
// }
*/
