
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

// MARK: - Spatial AI View Manager: Orchestrating AI and RealityKit

/// Manages the integration of AI detection results with a RealityKit scene.
/// This class acts as the bridge between the AI model's output and the visual
/// representation within the spatial environment. It's designed to be an `ObservableObject`
/// to allow SwiftUI views to react to changes in the scene state or detected objects.
@available(visionOS 1.0, *)
@MainActor // Ensure all UI-related updates happen on the main thread
public class SpatialAIViewManager: ObservableObject {
    /// The root `Entity` for our RealityKit scene content.
    /// All AI-generated visualizations will be added as children to this entity.
    public let rootContentEntity = Entity()

    /// A dictionary to keep track of entities already created for detected objects,
    /// allowing for updates rather than constant recreation.
    private var detectedObjectEntities: [UUID: ModelEntity] = [:]

    private let aiModel = MockAIModel()

    /// Published property to inform SwiftUI views about current AI status or errors.
    @Published public var aiStatus: String = "Ready for analysis."
    @Published public var hasError: Bool = false
    @Published public var errorMessage: String = ""

    public init() {
        // Add a simple floor plane for visual context
        let floor = ModelEntity(mesh: .generatePlane(width: 5, depth: 5), materials: [SimpleMaterial(color: .gray.withAlphaComponent(0.5), isMetallic: false)])
        floor.position = [0, -0.1, 0] // Slightly below origin
        rootContentEntity.addChild(floor)
    }

    /// Initiates the spatial AI analysis process.
    /// This method performs object detection and property inference asynchronously.
    ///
    /// **Under the Hood: Concurrency with `Task` and `async/await`**
    /// AI model inference can be computationally intensive and time-consuming.
    /// Using `Task` allows us to run these operations on a background thread
    /// without blocking the main UI thread, ensuring a smooth user experience.
    /// `await` pauses execution until the asynchronous operation completes,
    /// and `@MainActor` ensures that any UI updates (like `aiStatus` or `errorMessage`)
    /// are safely performed on the main thread.
    public func startSpatialAnalysis() {
        aiStatus = "Performing object detection..."
        hasError = false
        errorMessage = ""

        Task {
            do {
                // 1. Perform object detection
                // This is the initial AI step, identifying objects in the scene.
                let detectedObjects = try await aiModel.detectObjects()
                aiStatus = "Detected \(detectedObjects.count) objects. Inferring properties..."

                // 2. Process each detected object and infer properties
                // This step takes the detected objects and requests more detailed AI analysis.
                await processDetectedObjects(detectedObjects)

                aiStatus = "Spatial analysis complete."

            } catch let error as AIError {
                // Handle specific AI-related errors
                aiStatus = "Analysis failed!"
                errorMessage = error.localizedDescription
                hasError = true
                print("AI Analysis Error: \(error.localizedDescription)")
            } catch {
                // Handle any other unexpected errors during the analysis
                aiStatus = "Analysis failed!"
                errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                hasError = true
                print("Unexpected Error: \(error.localizedDescription)")
            }
        }
    }

    /// Processes an array of detected objects, creating or updating their
    /// spatial visualizations in the RealityKit scene.
    /// - Parameter objects: An array of `DetectedObject` instances.
    ///
    /// **Under the Hood: `withTaskGroup` for Parallel Inference**
    /// For optimal performance, especially when dealing with multiple detected objects,
    /// we use `withTaskGroup`. This allows us to perform property inference for
    /// each object concurrently, significantly reducing the total waiting time
    /// compared to sequential `await` calls. Each inference task runs independently.
    private func processDetectedObjects(_ objects: [DetectedObject]) async {
        await withTaskGroup(of: (DetectedObject, Result<AIInferredProperty, Error>).self) { group in
            for object in objects {
                group.addTask {
                    let result = await Result { try await self.aiModel.inferProperties(for: object) }
                    return (object, result)
                }
            }

            // Collect results from all concurrent inference tasks
            for await (object, result) in group {
                await handleInferenceResult(for: object, result: result)
            }
        }
    }

    /// Handles the result of a single property inference, updating the RealityKit scene.
    /// - Parameters:
    ///   - object: The `DetectedObject` for which inference was performed.
    ///   - result: The `Result` of the inference operation (success or failure).
    private func handleInferenceResult(for object: DetectedObject, result: Result<AIInferredProperty, Error>) {
        do {
            let inferredProperty = try result.get()
            // 3. Create or update the RealityKit entity and attach the component
            // If inference is successful, visualize with the inferred property.
            createOrUpdateVisualization(for: object, with: inferredProperty)
        } catch let error as AIError {
            // Log and display specific AI inference errors
            errorMessage = "Failed to infer property for \(object.label): \(error.localizedDescription)"
            hasError = true
            print("Property Inference Error for \(object.label): \(error.localizedDescription)")
            // Even if inference fails, we can still visualize the detected object itself
            // with a default or error state.
            createOrUpdateVisualization(for: object, with: nil)
        } catch {
            // Log and display any other unexpected errors during inference
            errorMessage = "Unexpected error during inference for \(object.label): \(error.localizedDescription)"
            hasError = true
            print("Unexpected Error during inference for \(object.label): \(error.localizedDescription)")
            createOrUpdateVisualization(for: object, with: nil)
        }
    }


    /// Creates or updates a `ModelEntity` to visualize a detected object and its AI properties.
    /// - Parameters:
    ///   - object: The detected object.
    ///   - inferredProperty: The AI-inferred property, if available.
    ///
    /// **Under the Hood: RealityKit Entity Management and Dynamic Visualization**
    /// This method demonstrates how to dynamically create and manage `ModelEntity` objects
    /// in response to AI output. Each `ModelEntity` represents a spatial visualization
    /// of a detected object. The `AIVisualizationComponent` is attached to this entity,
    /// making the AI data an intrinsic part of the spatial object. We then create child
    /// `ModelEntity` objects (a colored sphere and text label) to visually represent
    /// the data from the component.
    private func createOrUpdateVisualization(for object: DetectedObject, with inferredProperty: AIInferredProperty?) {
        let entity: ModelEntity
        var visualizationColor: SIMD3<Float> = [0.0, 1.0, 0.0] // Default green for detected

        // Check if an entity for this object already exists to update it,
        // rather than creating duplicates.
        if let existingEntity = detectedObjectEntities[object.id] {
            entity = existingEntity
            // Update existing entity's position if needed, or other properties
            entity.position = object.worldPosition
        } else {
            // New detection, create a new entity
            entity = ModelEntity()
            entity.name = object.label // Assign a name for debugging/identification
            entity.position = object.worldPosition
            rootContentEntity.addChild(entity) // Add to the scene's root
            detectedObjectEntities[object.id] = entity // Store for future updates
        }

        // Determine visualization color based on inferred property for richer feedback
        if let inferredProp = inferredProperty {
            switch inferredProp.key {
            case "State" where inferredProp.value == "On": visualizationColor = [0.0, 0.8, 0.8] // Cyan for On
            case "State" where inferredProp.value == "Off": visualizationColor = [0.2, 0.2, 0.2] // Dark gray for Off
            case "Health" where inferredProp.value == "Healthy": visualizationColor = [0.0, 1.0, 0.0] // Green
            case "Health" where inferredProp.value == "Needs Water": visualizationColor = [1.0, 0.5, 0.0] // Orange
            case "Occupancy" where inferredProp.value == "Occupied": visualizationColor = [1.0, 0.0, 0.0] // Red
            case "Occupancy" where inferredProp.value == "Vacant": visualizationColor = [0.0, 0.0, 1.0] // Blue
            default: visualizationColor = [1.0, 1.0, 0.0] // Yellow for unknown inferred
            }
        }

        // Create or update the AIVisualizationComponent and attach it to the entity.
        // This component now holds the semantic AI data.
        var aiVisComponent = AIVisualizationComponent(
            primaryLabel: object.label,
            inferredProperty: inferredProperty?.value,
            visualizationColor: visualizationColor
        )
        entity.components.set(aiVisComponent)

        // Remove old visual cues (sphere and text) to prevent duplicates before adding new ones.
        // This ensures the visualization updates correctly.
        entity.children.filter { $0.name.starts(with: "AI_VIS_") }.forEach { $0.removeFromParent() }

        // Add a visual cue (e.g., a simple sphere) whose color reflects the inferred property.
        let mesh: MeshResource = .generateSphere(radius: 0.05)
        let material = SimpleMaterial(color: UIColor(red: CGFloat(visualizationColor.x), green: CGFloat(visualizationColor.y), blue: CGFloat(visualizationColor.z), alpha: 0.8), isMetallic: false)
        let model = ModelEntity(mesh: mesh, materials: [material])
        model.position = [0, 0.1, 0] // Slightly above the object's anchor point
        model.name = "AI_VIS_SHAPE_\(object.label)" // Name for easy identification and removal
        entity.addChild(model)

        // Add a TextEntity for the label and inferred property, providing textual context.
        // `generateText` creates a 3D mesh from text.
        if let textMesh = MeshResource.generateText(
            "\(object.label)\n\(inferredProperty?.value ?? "N/A")",
            extrusionDepth: 0.01, // Give the text some 3D depth
            font: .systemFont(ofSize: 0.05), // Font size in meters
            containerFrame: .zero,
            alignment: .center,
            lineBreakMode: .byWordWrapping
        ) {
            let textMaterial = SimpleMaterial(color: .white, isMetallic: false)
            let textEntity = ModelEntity(mesh: textMesh, materials: [textMaterial])
            textEntity.position = [0, 0.2, 0] // Position above the sphere
            textEntity.scale = [1, 1, 1] * 0.5 // Scale down the text for better readability
            textEntity.name = "AI_VIS_TEXT_\(object.label)"
            entity.addChild(textEntity)
        } else {
            print("Error generating text mesh for \(object.label)")
        }

        print("Visualized: \(object.label) with property \(inferredProperty?.value ?? "N/A") at \(object.worldPosition)")
    }

    /// Clears all AI-generated visualizations from the scene.
    /// This removes all child entities that were added for detected objects.
    public func clearVisualizations() {
        for entity in detectedObjectEntities.values {
            entity.removeFromParent()
        }
        detectedObjectEntities.removeAll()
        aiStatus = "Visualizations cleared."
    }
}
