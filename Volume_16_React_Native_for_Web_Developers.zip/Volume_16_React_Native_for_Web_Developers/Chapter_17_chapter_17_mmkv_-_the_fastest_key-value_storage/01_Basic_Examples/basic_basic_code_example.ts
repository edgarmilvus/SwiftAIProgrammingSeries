/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: hooks/useUserPreferences.ts

import { useState, useEffect, useCallback } from 'react';
import { MMKV } from 'react-native-mmkv';

// 1. MMKV Instance Initialization
// We create a dedicated storage instance for user preferences.
// This isolates our data from other app modules and allows for specific encryption keys if needed.
const storage = new MMKV({
  id: 'user-prefs-v1',
  encryptionKey: 'secure-key-placeholder', // In production, use Keychain/SecureStore
});

// 2. Type Definitions for Type Safety
// Using TypeScript interfaces ensures we don't accidentally store invalid data types.
interface UserPreferences {
  isDarkMode: boolean;
  dashboardView: 'grid' | 'list';
  lastActiveProjectId: string | null;
}

// 3. Default Configuration
// Fallback values used if no data exists in storage (first run).
const DEFAULT_PREFERENCES: UserPreferences = {
  isDarkMode: false,
  dashboardView: 'grid',
  lastActiveProjectId: null,
};

/**
 * Custom React Hook: useUserPreferences
 * 
 * Manages user-specific application settings using MMKV for synchronous persistence.
 * 
 * @returns {Object} An object containing the current preferences state and a setter function.
 */
export const useUserPreferences = () => {
  // 4. Local React State
  // Holds the current preferences in memory for UI reactivity.
  const [preferences, setPreferences] = useState<UserPreferences>(DEFAULT_PREFERENCES);

  // 5. Load Initial Data (Hydration)
  // Runs once on component mount to read from MMKV synchronously.
  useEffect(() => {
    try {
      // MMKV allows synchronous reading of JSON strings.
      const storedJson = storage.getString('user_prefs');
      
      if (storedJson) {
        // Parse the JSON and merge with defaults to ensure schema compatibility.
        const parsed = JSON.parse(storedJson) as Partial<UserPreferences>;
        setPreferences((prev) => ({ ...prev, ...parsed }));
      }
    } catch (error) {
      console.error('Failed to load preferences from MMKV:', error);
      // In a real app, you might trigger a reset to defaults here.
    }
  }, []);

  // 6. Synchronous Update Handler
  // Updates local state and writes to MMKV in the same execution cycle.
  const updatePreferences = useCallback(
    (updates: Partial<UserPreferences>) => {
      // Merge new updates with current state.
      const newPreferences = { ...preferences, ...updates };
      
      // Update React State immediately for UI responsiveness.
      setPreferences(newPreferences);

      // Synchronously persist to MMKV.
      // No 'await' required, unlike AsyncStorage.
      storage.set('user_prefs', JSON.stringify(newPreferences));
    },
    [preferences]
  );

  return {
    preferences,
    updatePreferences,
  };
};
