
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import AppKit // For GUI (NSAlert, NSWorkspace)
import SwiftUI // For the main application's UI

// MARK: - Main Application (SwiftUI)
@available(macOS 14.0, *)
class AIAgentAppViewModel: ObservableObject {
    @Published var agentStatus: String = "Checking for Ollama..."
    @Published var showOllamaMissingAlert: Bool = false

    // Path where the ollama CLI is expected to be installed by the installer.
    // This could also be a user-specific path like ~/.local/bin/ollama
    private let ollamaPath = "/usr/local/bin/ollama"

    init() {
        checkForOllama()
    }

    func checkForOllama() {
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: ollamaPath) {
            agentStatus = "Ollama detected! Agent is ready."
            print("Ollama found at: \(ollamaPath)")
            // In a real app, you might now run 'ollama serve' or query its status.
            // For this example, we'll just indicate readiness.
        } else {
            agentStatus = "Ollama not found. Please install it using the provided installer."
            print("Ollama NOT found at: \(ollamaPath)")
            DispatchQueue.main.async {
                self.showOllamaMissingAlert = true
            }
        }
    }

    func openOllamaWebsite() {
        if let url = URL(string: "https://ollama.ai/download") {
            NSWorkspace.shared.open(url)
        }
    }
}

@available(macOS 14.0, *)
struct AIAgentView: View {
    @StateObject private var viewModel = AIAgentAppViewModel()

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "brain.head.profile")
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
                .foregroundColor(.accentColor)

            Text("Local AI Desktop Agent")
                .font(.largeTitle)
                .padding(.bottom, 10)

            Text(viewModel.agentStatus)
                .font(.title2)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            if !viewModel.agentStatus.contains("detected") {
                Button("Re-check Ollama Status") {
                    viewModel.checkForOllama()
                }
                .padding(.top)
            }
        }
        .padding(40)
        .frame(minWidth: 400, minHeight: 250)
        .alert("Ollama Not Found", isPresented: $viewModel.showOllamaMissingAlert) {
            Button("OK") { }
            Button("Download Ollama") {
                viewModel.openOllamaWebsite()
            }
        } message: {
            Text("The 'ollama' CLI helper tool is required but was not found at \(viewModel.ollamaPath).\n\nPlease ensure you run the full installer package.")
        }
    }
}

@available(macOS 14.0, *)
@main
struct AIAgentApp: App {
    var body: some Scene {
        WindowGroup {
            AIAgentView()
        }
    }
}

/*
--- Conceptual Steps for Helper Tool and Custom Installer ---

1.  **Helper Tool (`ollama` CLI):**
    *   Download the `ollama` CLI executable for macOS from `ollama.ai`.
    *   Alternatively, for simulation, create a simple shell script named `ollama` with `#!/bin/bash && echo "Ollama CLI is running!"` and make it executable (`chmod +x ollama`).

2.  **Installer Package Creation (using `productbuild` and a postinstall script):**

    *   **a. Prepare Application:** Build your `AIAgentApp` in Xcode for "Release" and locate the `.app` bundle (e.g., in `DerivedData`).
        *   `cp -R /path/to/DerivedData/Build/Products/Release/AIAgentApp.app /tmp/AIAgentApp.app`

    *   **b. Prepare Helper Tool:** Place the `ollama` executable in a temporary location.
        *   `cp /path/to/downloaded/ollama /tmp/ollama`
        *   `chmod +x /tmp/ollama`

    *   **c. Create Component Package for Main App:** This package will install the `.app` into `/Applications`.
        *   `pkgbuild --component /tmp/AIAgentApp.app --install-location /Applications /tmp/AIAgentApp.pkg`

    *   **d. Create Component Package for Helper Tool:** This package will install `ollama` into `/usr/local/bin`.
        *   `pkgbuild --component /tmp/ollama --install-location /usr/local/bin /tmp/OllamaHelper.pkg`

    *   **e. Create Postinstall Script (optional but recommended for realism):**
        *   Create a file named `postinstall.sh` with the content provided in the challenge description:
            