
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// MARK: - Common Data Structures for Binary Classification

enum EmailCategory: String, CaseIterable {
    case spam = "Spam"
    case notSpam = "Not Spam"
}

struct EmailPrediction {
    let actual: EmailCategory
    let predicted: EmailCategory
}

struct ConfusionMatrix {
    let tp: Int // True Positives
    let tn: Int // True Negatives
    let fp: Int // False Positives
    let fn: Int // False Negatives

    // Convenience initializer for creating an empty matrix
    init(tp: Int = 0, tn: Int = 0, fp: Int = 0, fn: Int = 0) {
        self.tp = tp
        self.tn = tn
        self.fp = fp
        self.fn = fn
    }

    func describe() {
        print("--- Confusion Matrix ---")
        print("True Positives (TP): \(tp)")
        print("True Negatives (TN): \(tn)")
        print("False Positives (FP): \(fp)")
        print("False Negatives (FN): \(fn)")
        print("------------------------")
    }
}

// MARK: - Core Functions

/// Calculates the confusion matrix for a binary classification problem.
/// - Parameters:
///   - predictions: An array of EmailPrediction instances.
///   - positiveClass: The EmailCategory considered as the 'positive' class.
/// - Returns: A ConfusionMatrix struct.
func calculateConfusionMatrix(predictions: [EmailPrediction], forPositiveClass positiveClass: EmailCategory) -> ConfusionMatrix {
    var tp = 0
    var tn = 0
    var fp = 0
    var fn = 0

    let negativeClass = (positiveClass == .spam) ? EmailCategory.notSpam : EmailCategory.spam

    for prediction in predictions {
        if prediction.actual == positiveClass {
            // Actual is positive
            if prediction.predicted == positiveClass {
                tp += 1 // True Positive
            } else {
                fn += 1 // False Negative
            }
        } else {
            // Actual is negative
            if prediction.predicted == positiveClass {
                fp += 1 // False Positive
            } else {
                tn += 1 // True Negative
            }
        }
    }
    return ConfusionMatrix(tp: tp, tn: tn, fp: fp, fn: fn)
}

/// Calculates Precision for the positive class.
/// Precision = TP / (TP + FP)
/// - Parameter confusionMatrix: The calculated ConfusionMatrix.
/// - Returns: The precision as a Double, or 0.0 if (TP + FP) is zero.
func calculatePrecision(confusionMatrix: ConfusionMatrix) -> Double {
    let denominator = Double(confusionMatrix.tp + confusionMatrix.fp)
    guard denominator > 0 else { return 0.0 }
    return Double(confusionMatrix.tp) / denominator
}

/// Calculates Recall for the positive class.
/// Recall = TP / (TP + FN)
/// - Parameter confusionMatrix: The calculated ConfusionMatrix.
/// - Returns: The recall as a Double, or 0.0 if (TP + FN) is zero.
func calculateRecall(confusionMatrix: ConfusionMatrix) -> Double {
    let denominator = Double(confusionMatrix.tp + confusionMatrix.fn)
    guard denominator > 0 else { return 0.0 }
    return Double(confusionMatrix.tp) / denominator
}

// MARK: - Simulation and Reporting

// 2. Simulate Data
var emailPredictions: [EmailPrediction] = []

// 80 emails actual "Not Spam"
// 75 correctly predicted as "Not Spam" (TN for "Spam")
emailPredictions.append(contentsOf: Array(repeating: EmailPrediction(actual: .notSpam, predicted: .notSpam), count: 75))
// 5 incorrectly predicted as "Spam" (FP for "Spam")
emailPredictions.append(contentsOf: Array(repeating: EmailPrediction(actual: .notSpam, predicted: .spam), count: 5))

// 20 emails actual "Spam"
// 18 correctly predicted as "Spam" (TP for "Spam")
emailPredictions.append(contentsOf: Array(repeating: EmailPrediction(actual: .spam, predicted: .spam), count: 18))
// 2 incorrectly predicted as "Not Spam" (FN for "Spam")
emailPredictions.append(contentsOf: Array(repeating: EmailPrediction(actual: .spam, predicted: .notSpam), count: 2))

// Shuffle to mix the order (optional, but good practice for real data)
emailPredictions.shuffle()

print("--- Email Spam Detector Evaluation ---")
print("Total Emails: \(emailPredictions.count)\n")

// 3. Calculate Confusion Matrix for "Spam" class
let spamPositiveClass = EmailCategory.spam
let confusionMatrix = calculateConfusionMatrix(predictions: emailPredictions, forPositiveClass: spamPositiveClass)
confusionMatrix.describe()

// 4. Calculate Precision and Recall for "Spam" class
let precision = calculatePrecision(confusionMatrix: confusionMatrix)
let recall = calculateRecall(confusionMatrix: confusionMatrix)

print(String(format: "Precision (for '%@'): %.4f", spamPositiveClass.rawValue, precision))
print(String(format: "Recall (for '%@'): %.4f", spamPositiveClass.rawValue, recall))
print("\n--- Interpretation ---")
print("A spam filter ideally needs high precision (to avoid legitimate emails being marked as spam) and high recall (to catch most spam).")
print("In this case, for the 'Spam' class:")
print("- Precision (%.2f): Out of all emails the model predicted as 'Spam', %.0f%% were actually spam.".formatted(precision, precision * 100))
print("  This means \(confusionMatrix.fp) legitimate emails were incorrectly flagged as spam (False Positives). A high FP rate is annoying for users.")
print("- Recall (%.2f): Out of all emails that were actually 'Spam', %.0f%% were correctly identified by the model.".formatted(recall, recall * 100))
print("  This means \(confusionMatrix.fn) actual spam emails slipped through the filter (False Negatives). A low FN rate is crucial for user experience.")
print("\nFor a spam filter, a high False Positive rate (low precision) is often considered more detrimental than a high False Negative rate (low recall). Users are more annoyed by missing important emails than by seeing a few spam emails. Therefore, **precision is often more critical** for a spam filter, though recall is also very important to maintain effectiveness.")

