
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI // Required for all SwiftUI views and modifiers

// MARK: - Model and Data Structures

/// Represents a single message in the chat.
/// Conforms to `Identifiable` for use in `ForEach`.
struct ChatMessage: Identifiable {
    let id = UUID()        // Unique identifier for each message
    let content: String    // The text content of the message
    let isUser: Bool       // True if the message is from the user, false for AI
}

// MARK: - Main View

/// A basic AI chat interface demonstrating declarative keyboard avoidance.
/// This view allows users to type messages, and the input field
/// will automatically adjust its position when the keyboard appears.
/// The chat messages can be scrolled, and the keyboard can be
/// dismissed interactively by dragging down the scroll view.
@available(iOS 18.0, *) // Target iOS 18.0 for latest SwiftUI features and APIs
struct BasicKeyboardAvoidanceView: View {
    // State variables to manage the chat messages and the current input text
    @State private var messages: [ChatMessage] = [
        ChatMessage(content: "Hello! How can I assist you today?", isUser: false),
        ChatMessage(content: "Tell me about the latest SwiftUI features.", isUser: true),
        ChatMessage(content: "SwiftUI 6 introduces new APIs for view transitions, improved data flow management, and enhanced accessibility features. It also brings more robust support for AI model integration.", isUser: false)
    ]
    @State private var newMessageText: String = "" // Binds to the TextField

    var body: some View {
        VStack { // The main container for the chat interface
            // 1. Scrollable Chat Message Display Area
            // ScrollViewReader allows programmatic scrolling (e.g., to the latest message).
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(messages) { message in
                            ChatMessageRow(message: message)
                                .id(message.id) // Assign ID for ScrollViewReader to target
                        }
                    }
                    .padding() // Add padding around the chat bubbles
                    .frame(maxWidth: .infinity, alignment: .leading) // Ensure content aligns left
                }
                // 2. Interactive Keyboard Dismissal
                // This modifier allows the user to dismiss the keyboard by
                // dragging down on the scrollable content area. This is a key
                // "polish" feature for chat applications.
                .scrollDismissesKeyboard(.interactively)
                
                // 3. Auto-Scroll to Bottom on New Message
                // When the number of messages changes (i.e., a new message is added),
                // automatically scroll to the bottom to show the latest message.
                .onChange(of: messages.count) {
                    if let lastMessageId = messages.last?.id {
                        // Use a small delay to ensure the layout has updated
                        // before attempting to scroll, especially after keyboard appearance.
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            proxy.scrollTo(lastMessageId, anchor: .bottom)
                        }
                    }
                }
            }

            // 4. Input Field and Send Button
            // This HStack forms the user input area at the bottom of the screen.
            HStack {
                TextField("Type your message...", text: $newMessageText)
                    .textFieldStyle(.roundedBorder) // Apply a standard visual style
                    .submitLabel(.send) // Changes the keyboard's return key to "Send"
                    .onSubmit { // Action performed when the "Send" key is pressed
                        sendMessage()
                    }

                Button("Send") { // Button to manually send the message
                    sendMessage()
                }
                .buttonStyle(.borderedProminent) // Apply a prominent button style
                // Disable the send button if the text field is empty or contains only whitespace
                .disabled(newMessageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding() // Add padding around the input field and button
            // 5. Automatic Keyboard Avoidance (Implicit)
            // SwiftUI, by default, respects the safe area insets. When the keyboard appears,
            // it reduces the available safe area at the bottom. SwiftUI's layout engine
            // automatically adjusts the views (in this case, pushing the HStack up)
            // to ensure they are not obscured by the keyboard. No explicit code
            // for keyboard height calculation is needed in this basic setup.
        }
        .navigationTitle("AI Chat") // Title for the navigation bar
        .navigationBarTitleDisplayMode(.inline) // Compact title display
    }

    /// Handles sending a new message, adding it to the chat history,
    /// and simulating an AI response.
    private func sendMessage() {
        // Ensure the message is not empty or just whitespace
        guard !newMessageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        // Create and append the user's message
        let userMessage = ChatMessage(content: newMessageText, isUser: true)
        messages.append(userMessage)
        newMessageText = "" // Clear the input field

        // Simulate an asynchronous AI response
        Task { @MainActor in // Ensure UI updates happen on the main actor
            try await Task.sleep(for: .seconds(1)) // Simulate network/processing delay
            let aiResponse = ChatMessage(content: "I received your message: '\(userMessage.content)'. Let me process that and generate a thoughtful reply...", isUser: false)
            messages.append(aiResponse)
        }
    }
}

/// A view for displaying a single chat message, styled differently for user and AI.
@available(iOS 18.0, *)
struct ChatMessageRow: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            // If it's a user message, push it to the right
            if message.isUser {
                Spacer()
            }
            Text(message.content)
                .padding(.horizontal, 12) // Horizontal padding inside the bubble
                .padding(.vertical, 8)   // Vertical padding inside the bubble
                // Background color based on sender (user or AI)
                .background(message.isUser ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                // Text color based on sender
                .foregroundColor(message.isUser ? .white : .primary)
                .cornerRadius(10) // Rounded corners for the message bubble
            // If it's an AI message, push it to the left
            if !message.isUser {
                Spacer()
            }
        }
        // Ensure the HStack takes full width and aligns content appropriately
        .frame(maxWidth: .infinity, alignment: message.isUser ? .trailing : .leading)
    }
}

// MARK: - Preview

@available(iOS 18.0, *)
#Preview {
    // Embed the view in a NavigationView to display the navigation title
    NavigationView {
        BasicKeyboardAvoidanceView()
    }
}
