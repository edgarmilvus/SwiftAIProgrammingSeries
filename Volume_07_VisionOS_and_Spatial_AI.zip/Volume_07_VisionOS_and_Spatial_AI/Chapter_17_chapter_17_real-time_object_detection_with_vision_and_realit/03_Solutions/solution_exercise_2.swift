
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import RealityKit
import ARKit

struct InfoCardView: View {
    let title: String
    let description: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.headline).foregroundColor(.white)
            Text(description).font(.caption).foregroundColor(.white.opacity(0.8))
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(12)
    }
}

@MainActor
class SpatialAttachmentManager: ObservableObject {
    var arView: ARView?
    private var attachments: [UUID: Entity] = [:]
    
    func updateAttachments(with observations: [VNRecognizedObjectObservation]) {
        guard let arView = arView else { return }
        
        // 1. Clear old attachments that no longer have detections (simplified)
        // In production, use tracking IDs to manage lifecycle
        
        for observation in observations {
            let centerPoint = CGPoint(
                x: observation.boundingBox.midX,
                y: 1.0 - observation.boundingBox.midY // Convert Vision to normalized screen space
            )
            
            // 2. Perform Raycast to find 3D position
            // We use the center of the 2D box to project into the 3D world
            let raycastResults = arView.raycast(from: centerPoint, allowing: .estimatedPlane, alignment: .any)
            
            if let firstResult = raycastResults.first {
                let worldTransform = firstResult.worldTransform
                let position = SIMD3<Float>(worldTransform.columns.3.x, 
                                            worldTransform.columns.3.y, 
                                            worldTransform.columns.3.z)
                
                updateOrSpawnEntity(at: position, for: observation.uuid)
            }
        }
    }
    
    private func updateOrSpawnEntity(at position: SIMD3<Float>, for id: UUID) {
        if let existing = attachments[id] {
            existing.position = position
        } else {
            let entity = createAttachmentEntity()
            entity.position = position
            attachments[id] = entity
            arView?.scene.addAnchor(AnchorEntity(world: position).adding(entity))
        }
    }
    
    private func createAttachmentEntity() -> Entity {
        // In visionOS, we use ViewAttachmentEntity
        // For iOS/ARKit, we'd use a ModelEntity with a plane mesh
        let attachment = Entity() 
        // Implementation details for ViewAttachmentEntity would go here
        return attachment
    }
}

extension AnchorEntity {
    func adding(_ entity: Entity) -> AnchorEntity {
        self.addChild(entity)
        return self
    }
}
