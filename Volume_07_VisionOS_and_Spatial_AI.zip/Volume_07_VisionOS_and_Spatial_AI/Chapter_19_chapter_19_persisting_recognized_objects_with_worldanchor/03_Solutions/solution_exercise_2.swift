
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import ARKit
import RealityKit
import SwiftData

@Model
final class SpatialLabel {
    @Attribute(.unique) var anchorID: UUID
    var textContent: String
    var colorHex: String // Storing color as hex for easier SwiftData persistence
    var isPending: Bool = true // Handle "Ghost" labels
    
    init(anchorID: UUID, textContent: String, color: UIColor) {
        self.anchorID = anchorID
        self.textContent = textContent
        self.isPending = true
        self.colorHex = color.toHexString() 
    }
}

@MainActor
class LabelingEngine: ObservableObject {
    var modelContext: ModelContext
    var arKitSession: ARKitSession?
    var worldTracking: WorldTrackingProvider?
    
    // Dictionary to track active UI entities
    private var activeLabels: [UUID: Entity] = [:]

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    func createLabel(at transform: simd_float4x4, text: String, color: UIColor) async throws {
        guard let worldTracking = worldTracking else { return }
        
        // 1. Create the spatial anchor
        let anchor = try await worldTracking.createAnchor(at: transform)
        
        // 2. Create the domain model (SwiftData)
        let newLabel = SpatialLabel(anchorID: anchor.identifier, textContent: text, color: color)
        modelContext.insert(newLabel)
        
        // 3. Immediate rendering
        renderLabel(for: newLabel, anchor: anchor)
    }

    func synchronizeWithSession() {
        // This would be called on every session update or via a timer
        let storedLabels = try? modelContext.fetch(FetchDescriptor<SpatialLabel>())
        let availableAnchors = worldTracking?.anchors ?? []

        for label in storedLabels ?? [] {
            let anchorExists = availableAnchors.contains(where: { $0.identifier == label.anchorID })
            
            if anchorExists {
                label.isPending = false
                if activeLabels[label.anchorID] == nil {
                    if let anchor = availableAnchors.first(where: { $0.identifier == label.anchorID }) {
                        renderLabel(for: label, anchor: anchor)
                    }
                }
            } else {
                // Handle "Ghost" labels: If anchor isn't found, mark as pending
                label.isPending = true
                activeLabels[label.anchorID]?.removeFromParent()
                activeLabels.removeValue(forKey: label.anchorID)
            }
        }
    }

    private func renderLabel(for label: SpatialLabel, anchor: ARKitAnchor) {
        let mesh = MeshResource.generateText(label.textContent, extrusionDepth: 0.01, font: .systemFont(ofSize: 0.05))
        let material = UnlitMaterial(color: UIColor(hex: label.colorHex) ?? .white)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        
        let anchorEntity = AnchorEntity(worldAnchor: anchor)
        anchorEntity.addChild(entity)
        // In a real app, add to the scene
        activeLabels[label.anchorID] = anchorEntity
    }
}

// Helper extensions for Color/Hex omitted for brevity
