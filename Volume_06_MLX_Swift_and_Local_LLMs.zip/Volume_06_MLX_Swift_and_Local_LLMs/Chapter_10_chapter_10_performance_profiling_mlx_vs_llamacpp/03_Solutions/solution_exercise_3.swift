
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import MLX
import MLXNN

// MARK: - 1. Design a Simplified LoRA Adapter Module
/// `LoRAAdapter` implements a single Low-Rank Adaptation layer.
/// It introduces two low-rank matrices (A and B) that, when multiplied,
/// approximate a full-rank update to an existing pre-trained layer.
class LoRAAdapter: MLXNN.Module {
    let adapterA: MLXArray
    let adapterB: MLXArray

    /// Initializes the LoRA adapter.
    /// - Parameters:
    ///   - inputFeatures: The input dimension of the layer being adapted.
    ///   - outputFeatures: The output dimension of the layer being adapted.
    ///   - rank: The low rank 'r' (e.g., 4, 8, 16). Determines the number of parameters.
    init(inputFeatures: Int, outputFeatures: Int, rank: Int) {
        // Initialize adapterA with shape [inputFeatures, rank]
        // `requiresGrad: true` makes these parameters trainable during fine-tuning.
        self.adapterA = MLXArray.randomNormal(shape: [inputFeatures, rank], requiresGrad: true)
        // Initialize adapterB with shape [rank, outputFeatures]
        self.adapterB = MLXArray.randomNormal(shape: [rank, outputFeatures], requiresGrad: true)
        super.init()
    }

    /// Computes the LoRA-induced update.
    /// This is `input @ adapterA @ adapterB`.
    /// - Parameter input: The input to the original linear layer.
    /// - Returns: The low-rank update to be added to the base layer's output.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Perform matrix multiplications: (input @ adapterA) @ adapterB
        return MLX.matmul(MLX.matmul(input, adapterA), adapterB)
    }
}

func runExercise3() {
    print("--- Exercise 3: LoRA Adapter for On-Device Text Classification (Feature Request) ---")

    let inputFeatures = 768 // e.g., embedding dimension from a transformer
    let outputFeatures = 256 // e.g., hidden layer dimension
    let rank = 8 // Low rank for LoRA, typically much smaller than input/output features

    // MARK: - 2. Integrate with a Mock Pre-trained Layer
    // Create a mock pre-trained linear layer. In a real scenario, this would
    // be loaded from a pre-trained model checkpoint.
    let baseLinearLayer = MLXNN.Linear(inputSize: inputFeatures, outputSize: outputFeatures)
    
    // Conceptually, `baseLinearLayer`'s parameters are frozen.
    // In MLX, this means their `requiresGrad` property would be set to `false`
    // after loading, or simply that they are not passed to the optimizer.
    // For this demonstration, we rely on `MLX.valueAndGradient` only considering
    // parameters with `requiresGrad: true` for gradient computation.

    // Instantiate the LoRA adapter
    let loraAdapter = LoRAAdapter(inputFeatures: inputFeatures, outputFeatures: outputFeatures, rank: rank)

    // Simulate input to the layer (e.g., a single token embedding)
    let dummyInput = MLXArray.randomUniform(low: -1.0, high: 1.0, shape: [1, inputFeatures]) // Batch size 1

    // Perform forward pass with LoRA during fine-tuning:
    // The output of the base layer (frozen)
    let baseOutput = baseLinearLayer(dummyInput)
    // The low-rank update from the LoRA adapter (trainable)
    let loraUpdate = loraAdapter(dummyInput)
    // The combined output is used for loss calculation and gradient propagation
    let finalOutput = baseOutput + loraUpdate

    // Evaluate to ensure shapes are computed for printing
    MLX.eval(baseOutput, loraUpdate, finalOutput)

    print("Mock Base Layer Output Shape: \(baseOutput.shape)")
    print("LoRA Adapter Update Shape: \(loraUpdate.shape)")
    print("Combined Output Shape: \(finalOutput.shape)")

    print("\n// Discussion on Integration:")
    print("// During fine-tuning with LoRA, the `baseLinearLayer`'s weights would be loaded from a pre-trained model and marked as non-trainable (`requiresGrad: false`). Only the `adapterA` and `adapterB` matrices within the `LoRAAdapter` would have `requiresGrad: true`. The forward pass would compute both `baseLinearLayer(input)` and `loraAdapter(input)`, then add their results. The loss would be calculated based on this combined output, and gradients would only flow back through `adapterA` and `adapterB`, updating only these low-rank matrices. This significantly reduces the number of trainable parameters, making fine-tuning much more memory and computationally efficient.")

    // MARK: - 3. Discuss Unified Memory Benefits
    print("\n// Discussion on Unified Memory Benefits for LoRA:")
    print("// Apple's Unified Memory architecture is a game-changer for on-device ML, especially with techniques like LoRA. In a traditional discrete GPU setup, model weights and data would need to be copied between CPU (host) and GPU (device) memory, incurring significant latency and bandwidth overhead. With Unified Memory, CPU and GPU share the *same physical memory*. This means:")
    print("// 1. **Zero-Copy Transfers:** `MLXArray` instances directly reference memory accessible by both the CPU and the GPU. There's no need to copy the `baseLinearLayer` weights or the input data from host to device, or intermediate activations back and forth. This drastically reduces memory transfer bottlenecks.")
    print("// 2. **Reduced Memory Footprint:** LoRA itself is memory-efficient because it only adds a small number of parameters (`adapterA` and `adapterB`) compared to the full model. Unified Memory augments this by ensuring that even these small adapter weights, along with the large frozen base model weights, reside in a single memory pool, optimizing overall memory usage and reducing fragmentation.")
    print("// 3. **Faster Fine-tuning:** The combination of LoRA's parameter efficiency and Unified Memory's 'zero-copy' access leads to much faster gradient computations and parameter updates on-device, making personalized model adaptation feasible on iOS/macOS devices without offloading to cloud servers.")
    print("// 4. **Simplified Development:** Developers don't need to manage explicit memory transfers, simplifying the ML pipeline and reducing potential bugs related to memory management.")
    print("// The memory footprint difference is substantial: instead of storing gradients for potentially millions or billions of parameters in the `baseLinearLayer`, only gradients for the `rank * (inputFeatures + outputFeatures)` parameters of the `LoRAAdapter` need to be computed and stored, which is orders of magnitude smaller.")
}

runExercise3()
