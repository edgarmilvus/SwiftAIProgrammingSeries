
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation // For SemanticContentProvider and related types
import UIKit      // For UI elements

// MARK: - Hypothetical APIs for iOS 18.2

// These APIs are hypothetical and are included to demonstrate the concept
// of new capabilities introduced in iOS 18.2. In a real scenario, these
// would be provided by Apple's frameworks.

@available(iOS 18.2, *)
struct SemanticAction {
    let title: String
    let type: ActionType // e.g., .addToCalendar, .createReminder
    let payload: [String: Any]? // Data needed to perform the action

    enum ActionType {
        case addToCalendar
        case createReminder
        case openLocation
        case custom(String)
    }
}

@available(iOS 18.2, *)
class SemanticActionGenerator {
    static let shared = SemanticActionGenerator()

    /// Hypothetically suggests actionable buttons based on detected semantic entities.
    func suggestActions(for entities: [SemanticContentEntity]) async throws -> [SemanticAction] {
        var suggested: [SemanticAction] = []

        // Check for date/time entities to suggest adding to calendar
        if entities.contains(where: { $0.type == .date || $0.type == .time }) {
            suggested.append(SemanticAction(title: "Add to Calendar", type: .addToCalendar, payload: nil))
        }

        // Check for task entities to suggest creating a reminder
        if entities.contains(where: { $0.type == .task }) {
            suggested.append(SemanticAction(title: "Create Reminder", type: .createReminder, payload: nil))
        }

        // Check for location entities to suggest opening in Maps
        if entities.contains(where: { $0.type == .location }) {
            suggested.append(SemanticAction(title: "Open Location", type: .openLocation, payload: nil))
        }

        // In a real scenario, this logic would be much more sophisticated,
        // potentially involving natural language processing and context.
        return suggested
    }
}

// MARK: - SmartMessageViewController

// The class itself can be available from iOS 18.0, but its internal logic adapts.
class SmartMessageViewController: UIViewController {

    // MARK: - UI Elements

    private lazy var messageStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 15
        stackView.alignment = .leading
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        return scrollView
    }()

    // Example messages to simulate an incoming message thread
    let messages = [
        "Hey, let's grab lunch on Tuesday at 1 PM at the new Italian place.",
        "Remember to submit the project proposal by end of day tomorrow.",
        "I'll be at the conference in San Francisco from Oct 20-22. Don't forget my flight details.",
        "Can you pick up milk and eggs from the store by 6 PM today?",
        "Meeting with Sarah next Monday at 10 AM regarding the Q4 report."
    ]

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        displayMessages()
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Smart Messaging"

        view.addSubview(scrollView)
        scrollView.addSubview(messageStackView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            messageStackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            messageStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            messageStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            messageStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            messageStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor) // Important for vertical scrolling
        ])
    }

    // MARK: - Message Display and Semantic Analysis Logic

    func displayMessages() {
        for messageText in messages {
            // Create a container view for each message and its actions/entities
            let messageContainer = UIStackView()
            messageContainer.axis = .vertical
            messageContainer.spacing = 5
            messageContainer.alignment = .leading
            messageContainer.isLayoutMarginsRelativeArrangement = true
            messageContainer.layoutMargins = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
            messageContainer.backgroundColor = .systemGray6
            messageContainer.layer.cornerRadius = 10
            messageStackView.addArrangedSubview(messageContainer)

            // Add the original message label
            let messageLabel = UILabel()
            messageLabel.text = messageText
            messageLabel.numberOfLines = 0
            messageLabel.font = .preferredFont(forTextStyle: .body)
            messageContainer.addArrangedSubview(messageLabel)

            // Perform semantic analysis asynchronously
            Task {
                do {
                    // SemanticContentProvider is available from iOS 18.0
                    let request = SemanticContentRequest(text: messageText, options: .init())
                    let response = try await SemanticContentProvider.shared.analyze(request)

                    await MainActor.run {
                        // Conditional UI update based on OS version
                        if #available(iOS 18.2, *) {
                            // This block is only compiled and executed on iOS 18.2 and later.
                            // Use the hypothetical SemanticActionGenerator
                            let actionGenerator = SemanticActionGenerator.shared
                            let actions = try? await actionGenerator.suggestActions(for: response.entities) // Use try? for optional actions

                            if let actions = actions, !actions.isEmpty {
                                let actionsStack = UIStackView()
                                actionsStack.axis = .horizontal
                                actionsStack.spacing = 10
                                actionsStack.alignment = .center
                                actionsStack.distribution = .fillProportionally
                                messageContainer.addArrangedSubview(actionsStack)

                                for action in actions {
                                    let actionButton = UIButton(type: .system)
                                    actionButton.setTitle(action.title, for: .normal)
                                    actionButton.titleLabel?.font = .preferredFont(forTextStyle: .footnote)
                                    actionButton.layer.cornerRadius = 8
                                    actionButton.layer.borderWidth = 1
                                    actionButton.layer.borderColor = UIColor.systemBlue.cgColor
                                    actionButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
                                    // Attach a UIAction for modern target-action
                                    actionButton.addAction(UIAction { [weak self] _ in
                                        self?.performSemanticAction(action, for: messageText)
                                    }, for: .touchUpInside)
                                    actionsStack.addArrangedSubview(actionButton)
                                }
                            } else {
                                // If no specific actions, still show entities for context
                                addEntityLabel(to: messageContainer, entities: response.entities)
                            }
                            print("iOS 18.2+ actions suggested for: \(messageText)")
                        } else {
                            // Fallback for iOS 18.0 and 18.1: just display entities
                            // This block is compiled for iOS 18.1 and earlier.
                            addEntityLabel(to: messageContainer, entities: response.entities)
                            print("iOS 18.0/18.1 entities displayed for: \(messageText)")
                        }
                    }
                } catch {
                    await MainActor.run {
                        let errorLabel = UILabel()
                        errorLabel.text = "Error analyzing: \(error.localizedDescription)"
                        errorLabel.textColor = .red
                        errorLabel.font = .italicSystemFont(ofSize: 12)
                        messageContainer.addArrangedSubview(errorLabel)
                    }
                }
            }
        }
    }

    // Helper to add an entity label
    private func addEntityLabel(to container: UIStackView, entities: [SemanticContentEntity]) {
        if !entities.isEmpty {
            let entityLabel = UILabel()
            let entityDescriptions = entities.map { entity in
                "\(entity.type.debugDescription): \(entity.text)" // Use debugDescription for better output
            }.joined(separator: ", ")
            entityLabel.text = "Detected: \(entityDescriptions)"
            entityLabel.font = .italicSystemFont(ofSize: 12)
            entityLabel.textColor = .systemGray
            entityLabel.numberOfLines = 0
            container.addArrangedSubview(entityLabel)
        }
    }

    // Placeholder for performing the actual action (iOS 18.2+)
    @available(iOS 18.2, *)
    private func performSemanticAction(_ action: SemanticAction, for message: String) {
        let alert = UIAlertController(title: "Action Triggered", message: "You tapped '\(action.title)' for message: '\(message)'.\n(In a real app, this would integrate with Calendar/Reminders/Maps etc.)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)

        // Example of how you might use the payload
        if let payload = action.payload {
            print("Action payload: \(payload)")
        }
    }
}
