
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import WritingTools // Requires iOS 18.0 / macOS 15.0+

// MARK: - Custom Suggestion View

@available(iOS 18.0, *)
class CustomSuggestionView: UIView {
    private let suggestion: WritingToolsSuggestion
    private let applyAction: (WritingToolsSuggestion) -> Void

    private lazy var suggestionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = .label
        label.numberOfLines = 0
        return label
    }()

    private lazy var applyButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Apply", for: .normal)
        button.addTarget(self, action: #selector(applyTapped), for: .touchUpInside)
        return button
    }()

    init(suggestion: WritingToolsSuggestion, applyAction: @escaping (WritingToolsSuggestion) -> Void) {
        self.suggestion = suggestion
        self.applyAction = applyAction
        super.init(frame: .zero)
        setupView()
        updateContent()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        backgroundColor = .systemYellow.withAlphaComponent(0.2) // Subtle background
        layer.cornerRadius = 5
        layer.borderColor = UIColor.systemYellow.cgColor
        layer.borderWidth = 1

        addSubview(suggestionLabel)
        addSubview(applyButton)

        NSLayoutConstraint.activate([
            suggestionLabel.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            suggestionLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8),
            suggestionLabel.trailingAnchor.constraint(equalTo: applyButton.leadingAnchor, constant: -8),
            suggestionLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -5),

            applyButton.centerYAnchor.constraint(equalTo: suggestionLabel.centerYAnchor),
            applyButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
            applyButton.widthAnchor.constraint(equalToConstant: 60)
        ])
    }

    private func updateContent() {
        suggestionLabel.text = "Suggest: \(suggestion.text)"
        // For more complex suggestions, you might show original vs. replacement
        // e.g., "Change '\(original)' to '\(suggestion.replacementText ?? suggestion.text)'"
    }

    @objc private func applyTapped() {
        applyAction(suggestion)
        // Optionally dismiss the view after applying
        removeFromSuperview()
    }
}

// MARK: - UITextView Extension for Rect Mapping

@available(iOS 18.0, macOS 15.0, *)
extension UITextView { // Or NSTextView
    /// Returns an array of CGRects corresponding to the given NSRange in the text view's coordinate system.
    func rects(for range: NSRange) -> [CGRect] {
        guard let textLayoutManager = self.textLayoutManager else { return [] }
        var rects: [CGRect] = []

        // TextKit 2's enumerateRenderingRects is ideal for this
        textLayoutManager.enumerateRenderingRects(for: range, using: { rect, _, _, _ in
            rects.append(rect)
            return true // Continue enumeration
        })
        return rects
    }
}

// MARK: - Editor View Controller with Custom Suggestions

@available(iOS 18.0, macOS 15.0, *)
class CustomSuggestionsEditorViewController: UIViewController, WritingToolsServiceDelegate {

    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        // IMPORTANT: Disable the system UI for writing tools suggestions
        textView.isWritingToolsEnabled = false
        return textView
    }()

    var writingToolsService: WritingToolsService?
    private var activeSuggestionViews: [CustomSuggestionView] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Custom Suggestions Editor"

        setupUI()
        setupWritingToolsService()
    }

    private func setupUI() {
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        textView.text = "This is an exemple of a note. It contains some grammer and spellling mistakes. Hopefully, the writing tools will corect them."
    }

    private func setupWritingToolsService() {
        writingToolsService = WritingToolsService()
        writingToolsService?.delegate = self
        writingToolsService?.textInput = textView
        print("WritingToolsService initialized and connected to textView. System UI disabled.")
    }

    // MARK: - WritingToolsServiceDelegate

    func writingToolsService(_ service: WritingToolsService, didProvideSuggestions suggestions: [WritingToolsSuggestion], for textInput: any WritingToolsTextInput) {
        DispatchQueue.main.async {
            self.clearActiveSuggestionViews() // Remove old suggestions

            guard let textView = textInput as? UITextView else { return }

            for suggestion in suggestions {
                let textRects = textView.rects(for: suggestion.range)
                if let firstRect = textRects.first {
                    // Convert rect from text view's coordinate system to main view's
                    let convertedRect = textView.convert(firstRect, to: self.view)

                    let customSuggestionView = CustomSuggestionView(suggestion: suggestion) { [weak self] appliedSuggestion in
                        self?.applySuggestion(appliedSuggestion, to: textView)
                    }
                    self.view.addSubview(customSuggestionView)
                    self.activeSuggestionViews.append(customSuggestionView)

                    // Position the custom view below the suggested text
                    let viewWidth: CGFloat = 250 // Example fixed width
                    let viewHeight: CGFloat = 40 // Example fixed height
                    customSuggestionView.frame = CGRect(
                        x: convertedRect.minX,
                        y: convertedRect.maxY + 5, // 5 points below the text
                        width: viewWidth,
                        height: viewHeight
                    )
                    // Ensure the view is within bounds or adjust placement
                    if customSuggestionView.frame.maxX > self.view.bounds.maxX {
                        customSuggestionView.frame.origin.x = self.view.bounds.maxX - viewWidth - 20
                    }
                }
            }
            print("Displayed \(suggestions.count) custom suggestion views.")
        }
    }

    func writingToolsService(_ service: WritingToolsService, didFailWithError error: Error, for textInput: any WritingToolsTextInput) {
        DispatchQueue.main.async {
            print("Writing Tools Service failed with error: \(error.localizedDescription)")
        }
    }

    // MARK: - Custom Suggestion Handling

    private func clearActiveSuggestionViews() {
        activeSuggestionViews.forEach { $0.removeFromSuperview() }
        activeSuggestionViews.removeAll()
    }

    private func applySuggestion(_ suggestion: WritingToolsSuggestion, to textInput: any WritingToolsTextInput) {
        textInput.apply(suggestion: suggestion)
        print("Applied custom suggestion: '\(suggestion.text)' at range \(suggestion.range)")
        // After applying, clear all current suggestion views as ranges might change
        clearActiveSuggestionViews()
    }
}
