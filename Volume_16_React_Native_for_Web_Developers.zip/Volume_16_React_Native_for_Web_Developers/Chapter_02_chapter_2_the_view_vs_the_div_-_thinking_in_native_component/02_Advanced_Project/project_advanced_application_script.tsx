/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React from 'react';

/**
 * -----------------------------------------------------------------------------
 * Types & Interfaces
 * -----------------------------------------------------------------------------
 * Defining strict shapes for our data ensures type safety across the 
 * component tree, mimicking the strictness required in native development.
 */

interface MetricData {
  title: string;
  value: number;
  trend: 'up' | 'down' | 'neutral';
  prefix?: string;
}

interface MetricCardProps {
  data: MetricData;
  index: number;
}

/**
 * -----------------------------------------------------------------------------
 * Styling System (The "Native" Approach)
 * -----------------------------------------------------------------------------
 * In React Native, styles are defined as JavaScript objects (or StyleSheet objects).
 * This mimics that pattern in Next.js. We avoid CSS strings entirely.
 * 
 * Why this matters:
 * 1. Performance: Styles are resolved at the native bridge level, not parsed strings.
 * 2. Consistency: The layout logic (Flexbox) is identical to native.
 * 3. Encapsulation: Styles are co-located with the component logic.
 */

const styles = {
  container: {
    display: 'flex', // Explicit flex display (redundant in web, required in native)
    flexDirection: 'column' as const, // Vertical stack
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 24,
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)', // Shadow equivalent to elevation in native
    border: '1px solid #e5e7eb',
    flex: 1, // Allow growth within a flex container
    minWidth: 280, // Prevent squeezing on small screens
  },
  headerRow: {
    display: 'flex',
    flexDirection: 'row' as const,
    justifyContent: 'space-between', // Horizontal alignment
    alignItems: 'center', // Vertical alignment
    marginBottom: 12,
  },
  title: {
    fontSize: 14,
    fontWeight: '600' as const,
    color: '#6b7280', // Semantic gray
    textTransform: 'uppercase' as const,
    letterSpacing: 0.5,
  },
  valueContainer: {
    display: 'flex',
    flexDirection: 'row' as const,
    alignItems: 'baseline', // Align text baseline
    gap: 4,
  },
  value: {
    fontSize: 32,
    fontWeight: '700' as const,
    color: '#111827',
  },
  unit: {
    fontSize: 14,
    fontWeight: '500' as const,
    color: '#9ca3af',
  },
  trendIndicator: {
    display: 'flex',
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 9999, // Pill shape
    backgroundColor: string; // Dynamic based on trend
  },
  trendText: {
    fontSize: 12,
    fontWeight: '600' as const,
  },
} as const;

/**
 * -----------------------------------------------------------------------------
 * Helper Components
 * -----------------------------------------------------------------------------
 * Breaking down the UI into small, reusable blocks.
 */

/**
 * Renders the trend indicator (e.g., "+5%" or "-2%").
 * Note: In a real React Native app, this would use an SVG icon component.
 */
const TrendBadge: React.FC<{ trend: 'up' | 'down' | 'neutral' }> = ({ trend }) => {
  // Dynamic styling injection
  const trendStyle = {
    ...styles.trendIndicator,
    backgroundColor: trend === 'up' ? '#dcfce7' : trend === 'down' ? '#fee2e2' : '#f3f4f6',
    color: trend === 'up' ? '#166534' : trend === 'down' ? '#991b1b' : '#374151',
  };

  const symbol = trend === 'up' ? '↑' : trend === 'down' ? '↓' : '•';

  return (
    <div style={trendStyle as React.CSSProperties}>
      <span style={trendStyle}>{symbol}</span>
    </div>
  );
};

/**
 * -----------------------------------------------------------------------------
 * Main Component: Metric Card
 * -----------------------------------------------------------------------------
 * This component demonstrates the "View vs Div" concept.
 * 
 * UNDER THE HOOD:
 * In React Native, this entire block would be compiled to native UI primitives
 * (UIView on iOS, android.view.ViewGroup on Android). In Next.js, it renders
 * to semantic HTML, but the *structure* and *styling logic* mimic native.
 */

const MetricCard: React.FC<MetricCardProps> = ({ data, index }) => {
  // Simulate a delay to show async loading states (concept from Server Components)
  // In a real app, this data comes from props or context.
  
  return (
    // ROOT CONTAINER: Acts as the "View"
    // We use a div here for Next.js web rendering, but the styling logic
    // is strictly flex-based, adhering to native constraints.
    <div style={styles.container as React.CSSProperties}>
      
      {/* HEADER ROW: Flex Row Layout */}
      <div style={styles.headerRow as React.CSSProperties}>
        <span style={styles.title}>{data.title}</span>
        <TrendBadge trend={data.trend} />
      </div>

      {/* CONTENT ROW: Aligning value and unit */}
      <div style={styles.valueContainer as React.CSSProperties}>
        <span style={styles.value}>
          {/* Formatting the number with locale string */}
          {data.prefix ? data.prefix : ''}
          {data.value.toLocaleString()}
        </span>
        <span style={styles.unit}>USD</span>
      </div>

    </div>
  );
};

/**
 * -----------------------------------------------------------------------------
 * Dashboard Container (Server Component)
 * -----------------------------------------------------------------------------
 * This component fetches data on the server and renders the cards.
 * It represents the "SaaS Context" where data is king.
 */

// Mock Data Fetcher (Simulating a Server Action/DB Call)
const fetchMetrics = async (): Promise<MetricData[]> => {
  // In a real app: await db.query('SELECT * FROM metrics');
  return [
    { title: 'Monthly Recurring Revenue', value: 45230, trend: 'up', prefix: '$' },
    { title: 'Churn Rate', value: 2.4, trend: 'down', prefix: '' },
    { title: 'Active Users', value: 1240, trend: 'neutral', prefix: '' },
    { title: 'Net Promoter Score', value: 78, trend: 'up', prefix: '' },
  ];
};

/**
 * The main entry point for the dashboard view.
 * Marked as 'use server' implicitly in Next.js App Router if placed in a server file.
 */
export default async function DashboardMetrics() {
  const metrics = await fetchMetrics();

  // Layout Container: Flex Row wrapping for responsive grid
  const dashboardContainerStyle = {
    display: 'flex',
    flexDirection: 'row' as const, // Horizontal flow
    flexWrap: 'wrap' as const,     // Allow wrapping (Web behavior, but conceptually similar to Native FlexWrap)
    gap: 24,                       // Space between cards
    padding: 24,
    backgroundColor: '#f9fafb',
    minHeight: '100vh',
  };

  return (
    <div style={dashboardContainerStyle as React.CSSProperties}>
      {metrics.map((metric, index) => (
        // We pass the data down to the "Native-like" component
        <MetricCard key={metric.title} data={metric} index={index} />
      ))}
    </div>
  );
}
