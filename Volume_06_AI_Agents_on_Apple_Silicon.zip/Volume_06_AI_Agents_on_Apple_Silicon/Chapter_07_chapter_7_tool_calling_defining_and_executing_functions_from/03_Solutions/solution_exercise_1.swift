
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// MARK: - 1. Tool Definitions (Swift Functions)

enum CalculatorError: Error, CustomStringConvertible {
    case divisionByZero
    case invalidInput
    
    var description: String {
        switch self {
        case .divisionByZero: return "Division by zero is not allowed."
        case .invalidInput: return "Invalid input for calculation."
        }
    }
}

func add(a: Int, b: Int) -> Int {
    a + b
}

func subtract(a: Int, b: Int) -> Int {
    a - b
}

func multiply(a: Int, b: Int) -> Int {
    a * b
}

func divide(a: Int, b: Int) throws -> Int {
    guard b != 0 else {
        throw CalculatorError.divisionByZero
    }
    return a / b
}

// MARK: - 2. Tool Description (JSON Schema - Manual Representation)

// In a real scenario, these would be generated programmatically or loaded.
// For demonstration, we'll represent them as strings or dictionaries.
let calculatorToolSchemas: [String: [String: Any]] = [
    "add": [
        "type": "function",
        "function": [
            "name": "add",
            "description": "Adds two integers together.",
            "parameters": [
                "type": "object",
                "properties": [
                    "a": ["type": "integer", "description": "The first integer"],
                    "b": ["type": "integer", "description": "The second integer"]
                ],
                "required": ["a", "b"]
            ]
        ]
    ],
    "subtract": [
        "type": "function",
        "function": [
            "name": "subtract",
            "description": "Subtracts the second integer from the first.",
            "parameters": [
                "type": "object",
                "properties": [
                    "a": ["type": "integer", "description": "The first integer"],
                    "b": ["type": "integer", "description": "The second integer"]
                ],
                "required": ["a", "b"]
            ]
        ]
    ],
    "multiply": [
        "type": "function",
        "function": [
            "name": "multiply",
            "description": "Multiplies two integers together.",
            "parameters": [
                "type": "object",
                "properties": [
                    "a": ["type": "integer", "description": "The first integer"],
                    "b": ["type": "integer", "description": "The second integer"]
                ],
                "required": ["a", "b"]
            ]
        ]
    ],
    "divide": [
        "type": "function",
        "function": [
            "name": "divide",
            "description": "Divides the first integer by the second. Handles division by zero.",
            "parameters": [
                "type": "object",
                "properties": [
                    "a": ["type": "integer", "description": "The dividend"],
                    "b": ["type": "integer", "description": "The divisor"]
                ],
                "required": ["a", "b"]
            ]
        ]
    ]
]

// MARK: - 3. LLM Integration (Mocking LLM Output)

// Structs to decode the LLM's expected JSON tool call output
struct ToolCallArgument: Codable {
    let a: Int
    let b: Int
}

struct ToolCall: Codable {
    let toolName: String
    let arguments: ToolCallArgument
}

// Simulate LLM's response by returning a hardcoded tool call based on input prompt
func simulateLLMToolCall(for prompt: String) -> ToolCall? {
    if prompt.contains("plus") || prompt.contains("add") {
        return ToolCall(toolName: "add", arguments: ToolCallArgument(a: 123, b: 45))
    } else if prompt.contains("minus") || prompt.contains("subtract") {
        return ToolCall(toolName: "subtract", arguments: ToolCallArgument(a: 100, b: 25))
    } else if prompt.contains("times") || prompt.contains("multiply") {
        return ToolCall(toolName: "multiply", arguments: ToolCallArgument(a: 15, b: 7))
    } else if prompt.contains("divided by") || prompt.contains("divide") {
        if prompt.contains("by zero") {
            return ToolCall(toolName: "divide", arguments: ToolCallArgument(a: 50, b: 0)) // Simulate division by zero
        }
        return ToolCall(toolName: "divide", arguments: ToolCallArgument(a: 100, b: 4))
    }
    return nil
}

// MARK: - 4. Tool Call Parsing & 5. Tool Execution (Dispatcher)

func executeToolCall(toolCall: ToolCall) -> String {
    let a = toolCall.arguments.a
    let b = toolCall.arguments.b
    
    do {
        let result: Int
        switch toolCall.toolName {
        case "add":
            result = add(a: a, b: b)
        case "subtract":
            result = subtract(a: a, b: b)
        case "multiply":
            result = multiply(a: a, b: b)
        case "divide":
            result = try divide(a: a, b: b)
        default:
            return "Unknown tool: \(toolCall.toolName)"
        }
        return "Tool '\(toolCall.toolName)' executed successfully. Result: \(result)"
    } catch let error as CalculatorError {
        return "Error executing tool '\(toolCall.toolName)': \(error.description)"
    } catch {
        return "An unexpected error occurred: \(error.localizedDescription)"
    }
}

// MARK: - Main Interaction Flow (Simulation)

func processUserPrompt(prompt: String) {
    print("User: \(prompt)")
    
    if let toolCall = simulateLLMToolCall(for: prompt) {
        print("LLM suggests tool call: \(toolCall.toolName) with arguments a:\(toolCall.arguments.a), b:\(toolCall.arguments.b)")
        let executionResult = executeToolCall(toolCall: toolCall)
        print("Tool Execution Result: \(executionResult)")
        // In a real app, this result would be sent back to the LLM for summarization.
        // For this exercise, we'll just print it.
        print("AI Assistant: \(executionResult)")
    } else {
        print("AI Assistant: I can't find a suitable tool for that request.")
    }
    print("---")
}

// Test cases
processUserPrompt(prompt: "What is 123 plus 45?")
processUserPrompt(prompt: "Calculate 100 minus 25.")
processUserPrompt(prompt: "Can you tell me what 15 times 7 is?")
processUserPrompt(prompt: "Divide 100 by 4.")
processUserPrompt(prompt: "What is 50 divided by zero?") // Test division by zero
processUserPrompt(prompt: "Tell me a joke.") // No tool call
