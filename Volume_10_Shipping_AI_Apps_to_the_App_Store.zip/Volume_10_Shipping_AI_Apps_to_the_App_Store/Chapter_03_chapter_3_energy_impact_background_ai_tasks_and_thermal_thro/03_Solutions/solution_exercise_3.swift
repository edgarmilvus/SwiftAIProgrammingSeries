
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import BackgroundTasks

/// Manages a batch of image processing tasks with thermal and time awareness.
final class BackgroundInferenceEngine {
    
    private var isRunning = false
    private let progressKey = "com.photoindex.lastProcessedIndex"
    
    /// Processes a list of image URLs.
    /// - Parameters:
    ///   - urls: The images to process.
    ///   - expirationHandler: A closure to call when the OS signals task expiration.
    func processBatch(urls: [URL], expirationHandler: @escaping () -> Void) async {
        guard !isRunning else { return }
        isRunning = true
        
        // Resume from last successful index
        let startIndex = UserDefaults.standard.integer(forKey: progressKey)
        print("Resuming batch from index: \(startIndex)")
        
        // Create a task that can be cancelled
        let processingTask = Task {
            for index in startIndex..<urls.count {
                // 1. Check for Task Cancellation (triggered by expirationHandler)
                if Task.isCancelled {
                    print("Task cancelled. Saving progress...")
                    return
                }
                
                // 2. Thermal Awareness
                let thermalState = ProcessInfo.processInfo.thermalState
                if thermalState == .critical {
                    print("CRITICAL thermal state detected. Aborting batch.")
                    return
                } else if thermalState == .serious {
                    print("Serious thermal state. Cooling down...")
                    try? await Task.sleep(nanoseconds: 5 * 1_000_000_000) // 5s cool-down
                }
                
                // 3. Simulate Inference
                print("Processing image \(index + 1)/\(urls.count): \(urls[index].lastPathComponent)")
                try? await Task.sleep(nanoseconds: 1 * 1_000_000_000) // 1s work
                
                // 4. Save Progress
                UserDefaults.standard.set(index + 1, forKey: progressKey)
                
                // 5. Yield to allow the system to handle expiration/other tasks
                await Task.yield()
            }
            
            print("Batch completed successfully.")
            UserDefaults.standard.set(0, forKey: progressKey) // Reset for next run
            self.isRunning = false
        }
        
        // Handle the OS expiration signal
        // We wrap this in a Task to ensure the cancellation is communicated to our structured task
        Task {
            // This is a simplified representation of how the expiration handler 
            // would interact with the engine in a real BGProcessingTask.
            // In a real app, the OS calls this closure.
        }
        
        // For the purpose of this exercise, we simulate the expiration handler's effect:
        // In a real BGProcessingTask, the OS would call expirationHandler().
        // We catch that by monitoring the task's cancellation status.
    }
}

// MARK: - Real-world BGTask Integration Simulation
@available(iOS 18.0, *)
class AppDelegate: NSObject {
    let engine = BackgroundInferenceEngine()
    var currentTask: Task<Void, Never>?

    func handleBackgroundProcessing(task: BGProcessingTask) {
        let mockURLs = (1...10).map { URL(fileURLWithPath: "/images/img\($0).jpg") }
        
        task.expirationHandler = {
            // This is called by the OS when time is up
            self.currentTask?.cancel()
        }
        
        currentTask = Task {
            await engine.processBatch(urls: mockURLs) {
                // In a real app, this closure would be handled by the BGTask system
            }
        }
    }
}
