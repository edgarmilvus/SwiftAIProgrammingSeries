
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "SecureVoiceNotes",
    platforms: [
        .iOS(.v15), // SFSpeechRecognizer and async/await are available on iOS 15+
        .macOS(.v12) // Also supports macOS
    ],
    products: [
        // Defines a library product that can be consumed by other targets or apps.
        .library(
            name: "SecureVoiceNotesSpeech",
            targets: ["SecureVoiceNotesSpeech"]),
    ],
    dependencies: [
        // No external dependencies needed for this specific implementation
        // as it relies solely on Apple's Speech and AVFoundation frameworks.
        // If we were to integrate a custom audio processing library,
        // or a cloud-based STT service directly (e.g., Google Cloud Speech),
        // dependencies would be listed here, e.g.:
        // .package(url: "https://github.com/example/audio-processing.git", from: "1.0.0"),
    ],
    targets: [
        // Defines the actual source code target.
        .target(
            name: "SecureVoiceNotesSpeech",
            dependencies: []), // List internal or external dependencies for this target.
    ]
)
