
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Vision
import Observation

// MARK: - Dependencies

/*
 Package.swift snippet for required dependencies:
 
 dependencies: [
     .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
     .package(url: "https://github.com/apple/swift-collections", from: "1.1.0")
 ]
*/

// MARK: - Domain Models

/// Represents the metadata of a detected real-world object.
/// Conforms to `Sendable` to ensure safe transfer between the Intelligence Actor and the MainActor.
struct DetectedObject: Identifiable, Sendable, Hashable {
    let id: UUID
    let label: String
    let confidence: Float
    let boundingBox: CGRect
    let worldTransform: simd_float4x4
    
    init(id: UUID = UUID(), label: String, confidence: Float, boundingBox: CGRect, worldTransform: simd_float4x4) {
        self.id = id
        self.label = label
        self.confidence = confidence
        self.boundingBox = boundingBox
        self.worldTransform = worldTransform
    }
}

/// Errors specific to the Spatial Intelligence pipeline.
enum SpatialError: Error, LocalizedError {
    case visionInferenceFailed
    case sessionInterrupted
    case entityMappingError(String)
    
    var errorDescription: String? {
        switch self {
        case .visionInferenceFailed: return "AI failed to process the spatial frame."
        case .sessionInterrupted: return "ARKit session was interrupted."
        case .entityMappingError(let msg): return "Failed to link AI data to 3D entity: \(msg)"
        }
    }
}

// MARK: - Intelligence Layer (The Actor)

/// `SpatialIntelligenceActor` is responsible for the heavy lifting.
/// By using an `actor`, we ensure that high-frequency Vision/CoreML processing 
/// does not block the Main Thread, preventing UI stutter in visionOS.
@available(visionOS 1.0, *)
actor SpatialIntelligenceActor {
    
    private var isProcessing = false
    
    /// Processes a single frame from the ARKit stream.
    /// - Parameter pixelBuffer: The raw image data from the camera/sensor.
    /// - Returns: A collection of detected objects with their spatial context.
    /// - Throws: `SpatialError` if inference fails.
    func processFrame(_ pixelBuffer: CVPixelBuffer) async throws -> [DetectedObject] {
        // In a real implementation, this would involve a VNCoreMLRequest.
        // We simulate the latency of an on-device AI model here.
        guard !isProcessing else { return [] }
        isProcessing = true
        
        // Simulate AI latency
        try await Task.sleep(for: .milliseconds(33)) 
        
        // Mocking a detection: A 'Coffee Cup' detected in the user's space.
        let mockTransform = simd_float4x4(diagonal: [1, 1, 1, 1]) // Identity matrix
        let detection = DetectedObject(
            label: "Coffee Cup",
            confidence: 0.98,
            boundingBox: CGRect(x: 0.1, y: 0.1, width: 0.2, height: 0.2),
            worldTransform: mockTransform
        )
        
        isProcessing = false
        return [detection]
    }
}

// MARK: - State Management (The Coordinator)

/// `SpatialSceneCoordinator` manages the bridge between the AI intelligence 
/// and the RealityKit scene. It uses the `@Observable` macro for modern, 
/// efficient SwiftUI integration.
@available(visionOS 1.0, *)
@Observable
@MainActor
final class SpatialSceneCoordinator {
    
    /// The collection of objects currently "anchored" in the user's reality.
    private(set) var activeObjects: [DetectedObject] = []
    
    /// The root entity for the immersive space.
    let sceneRoot = Entity()
    
    /// The AI engine, isolated to its own actor.
    private let intelligenceEngine = SpatialIntelligenceActor()
    
    /// Tracks if the immersive session is currently active.
    var isImmersiveSessionActive: Bool = false
    
    /// Errors that have occurred during the spatial session.
    var lastError: SpatialError?

    /// Processes a new frame from the ARKit stream.
    /// This function is called from the ARKit session delegate.
    func update(with pixelBuffer: CVPixelBuffer) async {
        do {
            // 1. Offload inference to the Actor to keep the main thread free.
            let detections = try await intelligenceEngine.processFrame(pixelBuffer)
            
            // 2. Update the state on the MainActor.
            await updateScene(with: detections)
        } catch let error as SpatialError {
            self.lastError = error
        } catch {
            print("Unexpected error: \(error)")
        }
    }
    
    /// Synchronizes the RealityKit Entity hierarchy with the detected objects.
    /// This is the "How" of the spatial-reactive pattern.
    private func updateScene(with detections: [DetectedObject]) async {
        // Remove entities that are no longer detected (simplified logic)
        // In production, you would use a diffing algorithm to prevent flickering.
        
        for detection in detections {
            // Check if we already have a visual representation for this object
            if !activeObjects.contains(where: { $0.id == detection.id }) {
                createVisualOverlay(for: detection)
                activeObjects.append(detection)
            }
        }
    }
    
    /// Creates a 3D visual representation (a "Digital Twin") for a detected object.
    private func createVisualOverlay(for object: DetectedObject) {
        // Create a simple sphere to represent the object in 3D space.
        let mesh = MeshResource.generateSphere(radius: 0.05)
        let material = SimpleMaterial(color: .systemBlue.withAlphaComponent(0.5), isMetallic: true)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        
        // Set the position based on the AI's spatial estimation.
        entity.transform.matrix = object.worldTransform
        entity.name = object.id.uuidString
        
        // Add to the scene.
        sceneRoot.addChild(entity)
    }
    
    /// Cleans up the scene when the immersive session ends.
    func resetScene() {
        sceneRoot.children.removeAll()
        activeObjects.removeAll()
    }
}

// MARK: - View Layer (SwiftUI & RealityKit)

/// The primary entry point for the Immersive Space.
@available(visionOS 1.0, *)
struct ImmersiveView: View {
    @Environment(SpatialSceneCoordinator.self) private var coordinator
    
    var body: some View {
        RealityView { content in
            // Add the coordinator's root entity to the RealityView content.
            content.add(coordinator.sceneRoot)
        } update: { content in
            // Update logic if the coordinator's root changes.
        }
        .task {
            // Start the ARKit session simulation.
            await runSpatialLoop()
        }
    }
    
    /// Simulates the high-frequency loop of an ARKit session.
    private func runSpatialLoop() async {
        // In a real app, this would be driven by the ARKit Session Delegate.
        while coordinator.isImmersiveSessionActive {
            // Simulate grabbing a frame from the camera.
            if let dummyBuffer = createDummyPixelBuffer() {
                await coordinator.update(with: dummyBuffer)
            }
            
            // Maintain a ~60fps loop for the simulation.
            try? await Task.sleep(for: .milliseconds(16))
        }
    }
    
    /// Helper to create dummy data for demonstration.
    private func createDummyPixelBuffer() -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, 640, 480, kCVPixelFormatType_32BGRA, nil, &pixelBuffer)
        return pixelBuffer
    }
}

/// The 2D Window that provides user controls and object metadata.
@available(visionOS 1.0, *)
struct ControlPanelView: View {
    @Environment(SpatialSceneCoordinator.self) private var coordinator
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Spatial Intelligence")
                .font(.largeTitle)
                .bold()
            
            Divider()
            
            if coordinator.activeObjects.isEmpty {
                Text("Scanning environment...")
                    .italic()
                    .foregroundStyle(.secondary)
            } else {
                ForEach(coordinator.activeObjects) { object in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(object.label)
                                .font(.headline)
                            Text("Confidence: \(Int(object.confidence * 100))%")
                                .font(.caption)
                        }
                        Spacer()
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                    .padding(.vertical, 4)
                }
            }
            
            Spacer()
            
            Button("Reset Session") {
                coordinator.resetScene()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(30)
        .frame(width: 400, height: 500)
    }
}

// MARK: - App Entry Point

@main
struct SpatialAIApp: App {
    @State private var coordinator = SpatialSceneCoordinator()
    
    var body: some Scene {
        // The 2D Control Window
        WindowGroup {
            ControlPanelView()
                .environment(coordinator)
        }
        .windowStyle(.plain)

        // The 3D Immersive Space
        ImmersiveSpace(id: "SpatialIntelligenceSpace") {
            ImmersiveView()
                .environment(coordinator)
        }
    }
}
