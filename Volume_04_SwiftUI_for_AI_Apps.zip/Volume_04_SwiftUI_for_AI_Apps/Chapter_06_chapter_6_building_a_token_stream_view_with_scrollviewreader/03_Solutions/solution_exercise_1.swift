
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import Observation
import SwiftUI

// MARK: - Data Model

@available(iOS 18.0, *)
struct ChatToken: Identifiable, Hashable {
    let id = UUID()
    let content: String
}

// MARK: - ViewModel

@available(iOS 18.0, *)
@Observable
class ChatViewModel {
    var tokens: [ChatToken] = []
    private var streamingTask: Task<Void, Never>?

    func startStreamingResponse(for query: String) {
        reset() // Clear previous tokens
        streamingTask = Task {
            let sampleResponse = "Hello there! I am an AI assistant ready to help you today. How can I assist you further?"
            let words = sampleResponse.split(separator: " ").map(String.init)

            for word in words {
                // Simulate network delay
                await Task.sleep(nanoseconds: UInt64(0.1 * 1_000_000_000))
                
                // Ensure UI updates on the main actor
                await MainActor.run {
                    self.tokens.append(ChatToken(content: word + " "))
                }
            }
        }
    }

    func reset() {
        streamingTask?.cancel()
        tokens = []
    }
}

// MARK: - View

@available(iOS 18.0, *)
struct ChatView: View {
    @State private var viewModel = ChatViewModel()
    
    // Identifier for the very last item, used for scrolling
    // We use a String for the "bottom_anchor" as a fallback/marker
    private var lastTokenId: UUID? {
        viewModel.tokens.last?.id
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(viewModel.tokens) { token in
                            Text(token.content)
                                .font(.body)
                                .padding(.vertical, 1) // Small padding for readability
                                .id(token.id) // Crucial for ScrollViewReader
                        }
                        // An invisible anchor view at the very bottom to ensure scrolling to the absolute end
                        Color.clear
                            .frame(height: 1) // Minimal height
                            .id("bottom_anchor")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                }
                .onChange(of: viewModel.tokens.count) {
                    // Scroll to the latest token or the bottom anchor when new tokens arrive
                    withAnimation(.easeOut(duration: 0.3)) {
                        proxy.scrollTo(lastTokenId ?? "bottom_anchor", anchor: .bottom)
                    }
                }
            }

            Spacer()

            HStack {
                Button("Start Streaming") {
                    viewModel.startStreamingResponse(for: "Hello AI")
                }
                .buttonStyle(.borderedProminent)

                Button("Reset") {
                    viewModel.reset()
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
        .navigationTitle("AI Chatbot Stream")
        .onDisappear {
            viewModel.reset() // Clean up tasks when view disappears
        }
    }
}

// MARK: - Preview (for Xcode Canvas)

@available(iOS 18.0, *)
#Preview {
    ChatView()
}
