
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Placeholder Data Source and Evaluation (for demonstration purposes)
// In a real app, you would load data from directories:
// MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
extension MLImageClassifier.DataSource {
    // A simplified placeholder for demonstration.
    // In a real application, you'd load actual image data.
    static var placeholder: MLImageClassifier.DataSource {
        // This is a minimal, non-functional placeholder.
        // Create ML requires actual image data to train.
        // For a runnable example, you'd point to a directory structure like:
        // /data/training/plantA/image1.jpg
        // /data/training/plantB/image2.jpg
        // For the purpose of *demonstrating the augmentation configuration*,
        // we acknowledge this needs real data.
        // Let's assume we have a way to get a valid DataSource for the compiler.
        // A common way to create a minimal valid DataSource for testing is:
        // let tempDir = FileManager.default.temporaryDirectory.appendingPathComponent("temp_data_\(UUID().uuidString)")
        // try! FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)
        // let classA = tempDir.appendingPathComponent("classA")
        // try! FileManager.default.createDirectory(at: classA, withIntermediateDirectories: true)
        // // Add a dummy image file (e.g., a 1x1 black PNG) to make it valid
        // let dummyImage = UIImage(color: .black, size: CGSize(width: 1, height: 1))! // Requires UIKit/AppKit
        // try! dummyImage.pngData()?.write(to: classA.appendingPathComponent("dummy.png"))
        // return try! MLImageClassifier.DataSource.labeledDirectories(at: tempDir)
        
        // For this solution, we'll assume a valid DataSource is provided externally
        // and focus on the augmentation logic.
        fatalError("MLImageClassifier.DataSource.placeholder requires actual image data for training.")
    }
}

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
private func evaluateModel(_ model: MLImageClassifier, on dataSource: MLImageClassifier.DataSource) async throws -> (accuracy: Double, loss: Double) {
    // This is a simplified placeholder.
    // In a real application, you would load the trained model and use its prediction
    // methods on the validationData to calculate accuracy and loss.
    // For example:
    // let predictions = try await model.predictions(for: dataSource)
    // Then compare predictions to actual labels to calculate metrics.
    print("  (Simulating model evaluation for validation accuracy and loss...)")
    // Simulate some realistic-ish numbers for demonstration
    let accuracy = Double.random(in: 0.75...0.95)
    let loss = Double.random(in: 0.1...0.5)
    return (accuracy, loss)
}

// MARK: - Augmentation Configuration and Training Functions

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func configureBasicAugmentations() -> MLImageClassifier.DataSource.AugmentationOptions {
    var options = MLImageClassifier.DataSource.AugmentationOptions()
    options.rotation = .degrees(range: -15.0...15.0)
    options.flip = .horizontal
    options.randomCrop = .fraction(min: 0.85, max: 1.0)
    options.colorJitter = .fraction(brightness: 0.08, contrast: 0.08, saturation: 0.0, hue: 0.0) // Focus on brightness/contrast
    return options
}

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func trainPlantClassifier(
    trainingData: MLImageClassifier.DataSource,
    validationData: MLImageClassifier.DataSource,
    augmentations: MLImageClassifier.DataSource.AugmentationOptions?,
    epochs: Int = 20,
    label: String
) async throws -> MLImageClassifier {
    print("--- Training \(label) Model ---")
    let parameters = MLImageClassifier.ModelParameters(
        validationData: validationData,
        augmentationOptions: augmentations,
        epochs: epochs,
        shuffle: true,
        learningRate: 0.001,
        // Using a progress handler to get metrics during training
        progressHandler: { context in
            if let metrics = context.metrics {
                print("  Epoch \(metrics.epoch): Train Loss = \(String(format: "%.4f", metrics.trainingLoss)), Validation Loss = \(String(format: "%.4f", metrics.validationLoss))")
                print("  Epoch \(metrics.epoch): Train Acc = \(String(format: "%.2f", metrics.trainingAccuracy * 100))%, Validation Acc = \(String(format: "%.2f", metrics.validationAccuracy * 100))%")
            }
        }
    )
    let model = try await MLImageClassifier.train(
        trainingData: trainingData,
        parameters: parameters
    )
    print("--- \(label) Model Training Complete ---")
    return model
}

// MARK: - Main Execution Logic (Example)

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func runPlantClassifierExperiment() async throws {
    // --- IMPORTANT: Replace with your actual data sources ---
    // For demonstration, we'll use a placeholder and acknowledge it needs real data.
    // In a real scenario, you'd load your plant image dataset like this:
    // let trainingDataURL = URL(fileURLWithPath: "/path/to/your/plant_training_data")
    // let validationDataURL = URL(fileURLWithPath: "/path/to/your/plant_validation_data")
    // let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
    // let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: validationDataURL)
    
    // As a workaround for the placeholder, we'll create a dummy data source
    // that won't actually contain images but allows the code structure to compile.
    // For actual execution, this part MUST be replaced with valid image data.
    let dummyTrainingData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_training"))
    let dummyValidationData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_validation"))
    
    // Ensure dummy directories exist (Create ML needs valid paths even if empty for some operations)
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_training/classA"), withIntermediateDirectories: true, attributes: nil)
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_validation/classA"), withIntermediateDirectories: true, attributes: nil)

    // 1. Baseline Model Training
    let baselineModel = try await trainPlantClassifier(
        trainingData: dummyTrainingData,
        validationData: dummyValidationData,
        augmentations: nil,
        label: "Baseline (No Augmentation)"
    )
    let baselineMetrics = try await evaluateModel(baselineModel, on: dummyValidationData)
    print("\n--- Baseline Model Results ---")
    print("Validation Accuracy: \(String(format: "%.2f", baselineMetrics.accuracy * 100))%")
    print("Validation Loss: \(String(format: "%.4f", baselineMetrics.loss))")

    // 2. Augmented Model Training
    let augmentedOptions = configureBasicAugmentations()
    let augmentedModel = try await trainPlantClassifier(
        trainingData: dummyTrainingData,
        validationData: dummyValidationData,
        augmentations: augmentedOptions,
        label: "Augmented (Basic)"
    )
    let augmentedMetrics = try await evaluateModel(augmentedModel, on: dummyValidationData)
    print("\n--- Augmented Model Results ---")
    print("Validation Accuracy: \(String(format: "%.2f", augmentedMetrics.accuracy * 100))%")
    print("Validation Loss: \(String(format: "%.4f", augmentedMetrics.loss))")

    // 3. Analysis (Output will be based on the simulated metrics above)
    print("\n--- Analysis ---")
    print("Baseline Model Validation Accuracy: \(String(format: "%.2f", baselineMetrics.accuracy * 100))%, Loss: \(String(format: "%.4f", baselineMetrics.loss))")
    print("Augmented Model Validation Accuracy: \(String(format: "%.2f", augmentedMetrics.accuracy * 100))%, Loss: \(String(format: "%.4f", augmentedMetrics.loss))")
    print("The augmented model is expected to show improved validation accuracy and lower validation loss compared to the baseline model, indicating better generalization and reduced overfitting.")
    print("Rotations and flips simulate different camera angles and orientations. Random crops help the model focus on the object and handle slight variations in framing. Color jitter accounts for varying lighting conditions.")
    print("These augmentations are suitable for plant images because plants can be photographed from various angles, might be slightly rotated, or appear under different lighting (indoor vs. outdoor, time of day).")
    
    // Clean up dummy directories
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_training"))
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_validation"))
}

// To run this code in a playground or an app:
// import PlaygroundSupport // For playgrounds
// PlaygroundSupport.is                  .current.needsIndefiniteExecution = true // For playgrounds
// Task {
//     try await runPlantClassifierExperiment()
// }
