
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import RoomPlan
import Observation
import SwiftUI

/// An error type for RoomPlan operations
enum RoomPlanError: Error {
    case sessionFailed
    case invalidCapture
}

/// The 'SpatialCoordinator' actor manages the RoomCaptureSession.
/// By using an actor, we ensure that the high-frequency updates from the 
/// RoomCaptureSession do not cause data races when updating the 
/// internal geometric model.
@available(iOS 18.0, *)
actor RoomCaptureCoordinator {
    private var session: RoomCaptureSession?
    private let captureConfig = RoomCaptureSession.Configuration()
    
    // We use a delegate-based approach, but we must bridge the 
    // delegate callbacks into the actor's isolated context.
    private var delegate: RoomCaptureDelegateProxy?

    init() {
        // Initialization of the session
    }

    /// Starts the scanning process. 
    /// This is an async function, allowing the caller to await the start.
    func startSession(delegate: RoomCaptureDelegateProxy) async {
        self.delegate = delegate
        let session = RoomCaptureSession()
        self.session = session
        // In a real implementation, the session would be started here
        // session.run(configuration: captureConfig)
    }

    func stopSession() {
        session?.stopCapture()
        session = nil
    }
    
    /// Returns the final captured room. 
    /// The 'CapturedRoom' is Sendable, making it safe to pass across actor boundaries.
    func finalizeCapture() async throws -> CapturedRoom {
        guard let session = session else { throw RoomPlanError.sessionFailed }
        // In a real scenario, we would await the completion of the capture
        // and return the result.
        throw RoomPlanError.invalidCapture // Placeholder
    }
}

/// The 'ViewModel' uses @Observable to provide a thread-safe, 
/// reactive interface for the SwiftUI view.
@available(iOS 18.0, *)
@Observable
final class RoomPlanViewModel {
    var isScanning: Bool = false
    var capturedRoom: CapturedRoom?
    var errorMessage: String?
    
    // The coordinator is an actor, so we interact with it via async/await.
    private let coordinator = RoomCaptureCoordinator()

    @MainActor
    func toggleScanning() async {
        if isScanning {
            await coordinator.stopSession()
            isScanning = false
        } else {
            isScanning = true
            // Create a proxy to handle delegate calls and pipe them to the MainActor
            let proxy = RoomCaptureDelegateProxy(viewModel: self)
            await coordinator.startSession(delegate: proxy)
        }
    }
}

/// A Proxy object is necessary because RoomCaptureSessionDelegate 
/// requires a class-based object, but we want to maintain Swift 6 
/// concurrency safety.
@available(iOS 18.0, *)
final class RoomCaptureDelegateProxy: NSObject, RoomCaptureSessionDelegate {
    // We use a weak reference to avoid retain cycles with the ViewModel
    weak var viewModel: RoomPlanViewModel?

    init(viewModel: RoomPlanViewModel) {
        self.viewModel = viewModel
    }

    // RoomCaptureSessionDelegate method
    nonisolated func captureSession(_ session: RoomCaptureSession, didUpdate room: CapturedRoom) {
        // This method is called on a background thread by the system.
        // We must jump back to the @MainActor to update the UI-bound ViewModel.
        Task { @MainActor in
            viewModel?.capturedRoom = room
        }
    }
    
    // Implement other required delegate methods...
    nonisolated func captureSession(_ session: RoomCaptureSession, didFailWithError error: Error) {
        Task { @MainActor in
            viewModel?.errorMessage = error.localizedDescription
        }
    }
}
