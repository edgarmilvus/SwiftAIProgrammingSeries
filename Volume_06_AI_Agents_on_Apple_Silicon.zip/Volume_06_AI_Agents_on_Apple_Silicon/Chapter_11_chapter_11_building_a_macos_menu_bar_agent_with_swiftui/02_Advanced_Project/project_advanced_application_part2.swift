
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation

/// Represents a request payload for the Ollama inference API.
/// This structure aligns with the typical JSON format expected by Ollama's `/api/generate` or `/api/chat` endpoints.
struct OllamaGenerateRequest: Encodable {
    /// The name of the model to use for inference (e.g., "llama2", "mistral").
    let model: String
    /// The prompt string to send to the LLM.
    let prompt: String
    /// An optional flag to enable streaming responses. For this example, we'll assume non-streaming for simplicity.
    let stream: Bool = false
    /// Additional options for the model, such as temperature, top_k, top_p, etc.
    let options: [String: AnyEncodable]? // Using AnyEncodable for flexibility

    /// Custom initializer for convenience.
    init(model: String, prompt: String, options: [String: AnyEncodable]? = nil) {
        self.model = model
        self.prompt = prompt
        self.options = options
    }

    // Helper for encoding AnyEncodable (if needed, otherwise just use [String: String])
    struct AnyEncodable: Encodable {
        let value: Any

        func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            if let string = value as? String {
                try container.encode(string)
            } else if let int = value as? Int {
                try container.encode(int)
            } else if let double = value as? Double {
                try container.encode(double)
            } else if let bool = value as? Bool {
                try container.encode(bool)
            } else if let dict = value as? [String: AnyEncodable] {
                try container.encode(dict)
            } else if let array = value as? [AnyEncodable] {
                try container.encode(array)
            } else {
                throw EncodingError.invalidValue(value, EncodingError.Context(codingPath: encoder.codingPath, debugDescription: "Unsupported type for AnyEncodable"))
            }
        }
    }
}

/// Represents the response payload from the Ollama inference API.
/// This structure captures the generated text and potentially other metadata.
struct OllamaGenerateResponse: Decodable {
    /// The generated text from the LLM.
    let response: String
    /// The model that was used for the inference.
    let model: String
    /// Optional metadata about the generation process (e.g., timing, token counts).
    let done: Bool
    let totalDuration: Int?
    let loadDuration: Int?
    let promptEvalCount: Int?
    let evalCount: Int?
    let evalDuration: Int?
}
