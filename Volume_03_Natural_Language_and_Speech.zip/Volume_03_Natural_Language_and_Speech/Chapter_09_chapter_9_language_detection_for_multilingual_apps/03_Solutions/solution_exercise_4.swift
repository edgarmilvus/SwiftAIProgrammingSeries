
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import NaturalLanguage

// MARK: - Post Model
struct Post: Identifiable {
    let id = UUID()
    let text: String
    var detectedLanguage: NLLanguage?
}

class MultilingualContentFeedViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    private var allPosts: [Post] = [
        Post(text: "Hello, world! This is an English post."),
        Post(text: "¡Hola, mundo! Esta es una publicación en español."),
        Post(text: "Bonjour le monde! Ceci est un poste en français."),
        Post(text: "Guten Tag Welt! Dies ist ein deutscher Beitrag."),
        Post(text: "Swift is a powerful and intuitive programming language."),
        Post(text: "¿Cómo estás? Espero que tengas un buen día."),
        Post(text: "La Tour Eiffel est un monument emblématique de Paris."),
        Post(text: "Programmierer lieben es, effizienten Code zu schreiben."),
        Post(text: "This sentence is a bit of a mix, but mostly English."),
        Post(text: "¡Qué interesante! Me gustaría aprender más."),
        Post(text: "C'est magnifique! J'adore la culture française."),
        Post(text: "Ich verstehe nur Bahnhof. Das ist ein Sprichwort."),
        Post(text: "The quick brown fox jumps over the lazy dog."),
        Post(text: "El veloz murciélago hindú comía feliz cardillo y kiwi."),
        Post(text: "Portez ce vieux whisky au juge blond qui fume."),
        Post(text: "Franz jagt im komplett verwahrlosten Taxi quer durch Bayern.")
    ]

    private var filteredPosts: [Post] = []
    private var selectedFilterLanguage: NLLanguage? = nil // nil means "show all"

    private let tableView: UITableView = {
        let tv = UITableView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.register(PostCell.self, forCellReuseIdentifier: PostCell.reuseIdentifier)
        tv.rowHeight = UITableView.automaticDimension
        tv.estimatedRowHeight = 80
        return tv
    }()

    private let languageFilterSegmentedControl: UISegmentedControl = {
        let languages: [NLLanguage] = [.english, .spanish, .french, .german]
        let items = ["All"] + languages.map { Locale.current.localizedString(forLanguageCode: $0.rawValue)?.capitalized ?? $0.rawValue.capitalized }
        let sc = UISegmentedControl(items: items)
        sc.translatesAutoresizingMaskIntoConstraints = false
        sc.selectedSegmentIndex = 0 // "All" initially
        return sc
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Multilingual Content Feed"
        view.backgroundColor = .systemBackground

        tableView.dataSource = self
        tableView.delegate = self
        languageFilterSegmentedControl.addTarget(self, action: #selector(filterLanguageChanged), for: .valueChanged)

        view.addSubview(languageFilterSegmentedControl)
        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            languageFilterSegmentedControl.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            languageFilterSegmentedControl.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            languageFilterSegmentedControl.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            languageFilterSegmentedControl.heightAnchor.constraint(equalToConstant: 40),

            tableView.topAnchor.constraint(equalTo: languageFilterSegmentedControl.bottomAnchor, constant: 10),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])

        // Detect languages for all posts on a background queue
        detectLanguagesForPosts()
    }

    private func detectLanguagesForPosts() {
        // Use a Task for modern Swift concurrency
        Task {
            var updatedPosts = [Post]()
            for var post in allPosts {
                // Perform language detection, which can be computationally intensive for many posts
                // This will run on a background thread provided by the Task.
                if let dominantLanguage = NLLanguageRecognizer.dominantLanguage(for: post.text) {
                    post.detectedLanguage = dominantLanguage
                }
                updatedPosts.append(post)
            }

            // Update UI on the main actor
            await MainActor.run {
                self.allPosts = updatedPosts
                self.applyFilter() // Apply initial filter (show all)
                self.tableView.reloadData()
            }
        }
    }

    @objc private func filterLanguageChanged() {
        let selectedIndex = languageFilterSegmentedControl.selectedSegmentIndex
        let languages: [NLLanguage] = [.english, .spanish, .french, .german]

        if selectedIndex == 0 { // "All"
            selectedFilterLanguage = nil
        } else {
            selectedFilterLanguage = languages[selectedIndex - 1] // Adjust index for "All" option
        }
        applyFilter()
    }

    private func applyFilter() {
        if let filterLanguage = selectedFilterLanguage {
            filteredPosts = allPosts.filter { $0.detectedLanguage == filterLanguage }
        } else {
            filteredPosts = allPosts // Show all posts
        }
        tableView.reloadData()
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPosts.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: PostCell.reuseIdentifier, for: indexPath) as? PostCell else {
            return UITableViewCell()
        }
        let post = filteredPosts[indexPath.row]
        cell.configure(with: post)
        return cell
    }
}

// MARK: - PostCell for UITableView
class PostCell: UITableViewCell {
    static let reuseIdentifier = "PostCell"

    private let postTextLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 17)
        label.numberOfLines = 0
        return label
    }()

    private let languageIndicatorLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 14)
        label.textColor = .secondaryLabel
        label.textAlignment = .right
        return label
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(postTextLabel)
        contentView.addSubview(languageIndicatorLabel)

        NSLayoutConstraint.activate([
            languageIndicatorLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            languageIndicatorLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),
            languageIndicatorLabel.widthAnchor.constraint(equalToConstant: 50), // Fixed width for language code

            postTextLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            postTextLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            postTextLabel.trailingAnchor.constraint(equalTo: languageIndicatorLabel.leadingAnchor, constant: -10),
            postTextLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with post: Post) {
        postTextLabel.text = post.text
        if let language = post.detectedLanguage {
            languageIndicatorLabel.text = language.rawValue.uppercased() // e.g., "EN", "ES"
        } else {
            languageIndicatorLabel.text = "N/A"
        }
    }
}
