
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML // Required for custom Core ML models
import NaturalLanguage // Required for NLTagger

// NLTagger.TagScheme.sentimentScore and Core ML APIs are available from iOS 13.0, macOS 10.15.
// @available(iOS 18.0, macOS 15.0, *) is used here to align with the chapter's implied modern Swift 6 context.
@available(iOS 13.0, macOS 10.15, *)
struct AppReviewClassifier {
    private let model: MLModel // The loaded Core ML model

    // Define an enum for clarity of sentiment labels
    enum SentimentLabel: String, CaseIterable {
        case positive = "Positive"
        case negative = "Negative"
        case neutral = "Neutral"
        case unknown = "Unknown" // For error or unclassified cases
    }

    /// Initializes the classifier by loading the custom Core ML model.
    /// This initializer can fail if the model file is not found or cannot be loaded.
    init?() {
        // Attempt to find the compiled .mlmodelc file in the app bundle.
        // Replace "AppReviewSentiment" with the actual name of your .mlmodel file.
        // Xcode automatically compiles .mlmodel into .mlmodelc when added to the project target.
        guard let modelURL = Bundle.main.url(forResource: "AppReviewSentiment", withExtension: "mlmodelc") else {
            print("Error: AppReviewSentiment.mlmodelc not found in the app bundle.")
            return nil
        }
        
        do {
            // Load the compiled Core ML model.
            self.model = try MLModel(contentsOf: modelURL)
        } catch {
            print("Error loading MLModel from \(modelURL): \(error)")
            return nil
        }
    }

    /// Classifies the sentiment of a given app review text using the custom Core ML model.
    /// - Parameter text: The app review string to classify.
    /// - Returns: A tuple containing the predicted sentiment label and its confidence score.
    func classifyReview(text: String) -> (label: SentimentLabel, confidence: Double) {
        // Create an MLFeatureProvider for the input.
        // The input feature name ("text") must match the input expected by your Core ML model.
        do {
            let input = try MLDictionaryFeatureProvider(dictionary: ["text": text as MLFeatureValue])
            
            // Make a prediction using the loaded model.
            let prediction = try model.prediction(from: input)
            
            // Extract the predicted label (String) from the model's output.
            // The output feature name ("label") must match the output expected by your Core ML model.
            guard let labelString = prediction.featureValue(for: "label")?.stringValue,
                  let label = SentimentLabel(rawValue: labelString) else {
                return (.unknown, 0.0) // Return unknown if label is not found or recognized
            }
            
            // Extract the confidence scores (probabilities) for all labels.
            // The output feature name ("labelProbs") must match the output expected by your Core ML model.
            guard let labelProbs = prediction.featureValue(for: "labelProbs")?.dictionaryValue as? [String: Double] else {
                return (label, 0.0) // Return label with 0 confidence if probabilities are not found
            }
            
            // Get the confidence specifically for the predicted label.
            let confidence = labelProbs[labelString] ?? 0.0
            
            return (label, confidence)
            
        } catch {
            print("Error during prediction: \(error)")
            return (.unknown, 0.0) // Return unknown on prediction error
        }
    }
}

// Function to demonstrate comparison between custom model and built-in NLTagger
@available(iOS 13.0, macOS 10.15, *)
func demonstrateCustomSentimentComparison() {
    // Attempt to initialize the custom classifier. This might fail if the .mlmodelc isn't present.
    guard let customClassifier = AppReviewClassifier() else {
        print("Failed to initialize AppReviewClassifier. Please ensure 'AppReviewSentiment.mlmodel' is added to your Xcode project and its target membership is checked.")
        print("You can create a dummy text classifier .mlmodel using Apple's Create ML app for testing.")
        return
    }

    let reviews = [
        "This app is fantastic, the new dark mode is a game changer!", // Clearly positive
        "The latest update broke my widget, now it crashes constantly.", // App-specific negative
        "It's okay, nothing special. The UI is a bit clunky.", // Neutral/mildly negative
        "I love the new features, especially the integration with Reminders.", // Positive with specific feature
        "The developers are unresponsive, and the app has too many ads.", // Clearly negative
        "The app loads quickly but the search function is unreliable.", // Mixed
        "Great design, but it drains my battery too fast.", // Mixed
    ]

    print("--- Sentiment Analysis Comparison ---")
    for review in reviews {
        print("\nReview: \"\(review)\"")

        // 1. Built-in NLTagger sentiment
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = review
        let (nlSentimentTag, _) = tagger.tag(at: review.startIndex, unit: .document, scheme: .sentimentScore)
        let nlScore = Double(nlSentimentTag?.rawValue ?? "0.0") ?? 0.0
        let nlClassification: String
        // Using slightly wider neutral thresholds for NLTagger comparison
        if nlScore > 0.2 { nlClassification = "Positive" }
        else if nlScore < -0.2 { nlClassification = "Negative" }
        else { nlClassification = "Neutral" }
        print("  Built-in NLTagger: \(nlClassification) (Score: \(String(format: "%.2f", nlScore)))")

        // 2. Custom Core ML model sentiment
        let (customLabel, customConfidence) = customClassifier.classifyReview(text: review)
        print("  Custom Model:      \(customLabel.rawValue) (Confidence: \(String(format: "%.2f", customConfidence)))")

        // Highlight any significant differences or potential misclassifications
        let nlIsPositive = nlScore > 0.2
        let nlIsNegative = nlScore < -0.2
        let customIsPositive = customLabel == .positive
        let customIsNegative = customLabel == .negative

        if (nlIsPositive && customIsNegative) || (nlIsNegative && customIsPositive) ||
           (nlClassification == "Neutral" && (customIsPositive || customIsNegative)) {
            print("  ⚠️ Potential difference in classification observed!")
        }
    }
}

// To run the demonstration:
// demonstrateCustomSentimentComparison()
