
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation
import AppIntents

// MARK: - Models

/// A Sendable representation of a semantic embedding.
/// Ensuring Sendable allows this to be passed safely between the 
/// Semantic Index actor and the UI.
struct SemanticEmbedding: Sendable, Codable {
    let vector: [Float]
    let metadata: [String: String]
}

/// Represents a piece of financial data that the system can index.
struct Transaction: Sendable, Identifiable {
    let id: UUID
    let amount: Decimal
    let merchant: String
    let date: Date
}

// MARK: - The Intelligence Layer

/// The AgentActor manages the "reasoning" state of the app.
/// It uses Actor isolation to ensure that the conversation history
/// and the current inference task are never subject to data races.
@available(iOS 18.0, *)
actor FinancialAgentActor {
    private var conversationHistory: [String] = []
    private var isProcessing: Bool = false
    
    /// Simulates an asynchronous call to a Private Cloud Compute (PCC) instance.
    /// Note the use of async/await to prevent blocking the calling thread.
    func processIntent(_ userQuery: String, context: [Transaction]) async throws -> String {
        isProcessing = true
        defer { isProcessing = false }
        
        // 1. Append to history (Thread-safe due to Actor isolation)
        conversationHistory.append("User: \(userQuery)")
        
        // 2. Simulate heavy reasoning/inference delay
        // In a real scenario, this would involve a network call to PCC 
        // or a local call to the Apple Neural Engine.
        try await Task.sleep(for: .seconds(2))
        
        // 3. Generate a response based on context
        let response = "Based on your \(context.count) recent transactions, you spent \(context.reduce(0) { $0 + ($1.amount as NSDecimalNumber).doubleValue }) this week."
        
        conversationHistory.append("Agent: \(response)")
        return response
    }
    
    var processingStatus: Bool {
        isProcessing
    }
}

// MARK: - The UI Layer

/// The ViewModel uses @Observable to provide a seamless, 
/// reactive streaming experience to the SwiftUI view.
@available(iOS 18.0, *)
@Observable
class FinancialViewModel {
    var query: String = ""
    var response: String = ""
    var isThinking: Bool = false
    
    private let agent = FinancialAgentActor()
    private let transactions: [Transaction] = [
        Transaction(id: UUID(), amount: 45.50, merchant: "Coffee Shop", date: .now),
        Transaction(id: UUID(), amount: 120.00, merchant: "Grocery Store", date: .now)
    ]
    
    @MainActor
    func performQuery() async {
        isThinking = true
        response = "Thinking..."
        
        do {
            // We call the actor. The 'await' keyword marks the suspension point
            // where the MainActor yields control while the AgentActor works.
            let result = try await agent.processIntent(query, context: transactions)
            
            // Once the actor returns, we resume on the @MainActor to update the UI.
            self.response = result
        } catch {
            self.response = "Error: \(error.localizedDescription)"
        }
        
        isThinking = false
    }
}

// MARK: - App Intent Integration

/// This is the 'System-Centric' part. By defining an AppIntent, 
/// we allow Apple Intelligence to 'see' and 'use' our app's logic.
@available(iOS 18.0, *)
struct QueryFinancesIntent: AppIntent {
    static var title: LocalizedStringResource = "Query Finances"
    
    @Parameter(title: "Query")
    var query: String

    // The system calls this intent when the user asks Siri 
    // or uses Apple Intelligence to ask about their money.
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        // In a real app, you would resolve the ViewModel or a Data Controller here.
        // This bridges the gap between the OS-level Intent and your app's logic.
        return .result(value: "Querying financial data for: \(query)")
    }
}
