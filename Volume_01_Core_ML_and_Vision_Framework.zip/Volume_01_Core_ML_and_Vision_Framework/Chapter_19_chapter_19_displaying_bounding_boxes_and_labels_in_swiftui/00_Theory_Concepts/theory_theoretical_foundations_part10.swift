
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part10.swift
// Description: Theoretical Foundations
// ==========================================

    .onAppear {
        Task {
            // Assuming you have a Core ML model instance
            guard let mlModel = try? MyObjectDetector().model else { return } // MyObjectDetector is your generated Core ML model class
            let visionModel = try VNCoreMLModel(for: mlModel)

            let processor = ImageProcessor(model: visionModel)
            do {
                let observations = try await processor.performDetection(on: inputImage.cgImage!)
                // Use MainActor.run to ensure UI updates are on the main thread
                await MainActor.run {
                    viewModel.processObservations(
                        observations,
                        originalImageSize: inputImage.size,
                        viewSize: geometry.size
                    )
                }
            } catch {
                print("Error during detection: \(error)")
            }
        }
    }
    